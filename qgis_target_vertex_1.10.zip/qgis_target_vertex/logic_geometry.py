from qgis.core import (QgsProject, QgsGeometry, QgsCoordinateTransform, QgsRectangle,
                       QgsWkbTypes, Qgis, QgsFeatureRequest, QgsFeature, QgsPointXY, QgsMessageLog)
from qgis.PyQt.QtWidgets import QProgressBar
from qgis.PyQt.QtCore import QCoreApplication

def log_msg(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(msg, "QGIS Target", level)

# OPTIMIZATION KEPT: Fast Bounding Box Pre-Filter for 80k cutters
def get_combined_cutters(target_layer, target_feat_ids):
    geoms_to_combine = []
    
    target_bb = QgsRectangle()
    target_bb.setMinimal() 
    
    request = QgsFeatureRequest().setFilterFids(list(target_feat_ids)).setNoAttributes()
    for f in target_layer.getFeatures(request):
        if f.hasGeometry():
            target_bb.combineExtentWith(f.geometry().boundingBox())

    if target_bb.isEmpty():
        log_msg("Target bounding box is empty.", Qgis.Warning)
        return QgsGeometry()

    cutter_count = 0
    for lyr in QgsProject.instance().mapLayers().values():
        if lyr.type() == Qgis.LayerType.Vector and lyr.selectedFeatureCount() > 0:
            xform = QgsCoordinateTransform(lyr.crs(), target_layer.crs(), QgsProject.instance())
            
            try:
                xform_inv = QgsCoordinateTransform(target_layer.crs(), lyr.crs(), QgsProject.instance())
                cutter_search_bb = xform_inv.transformBoundingBox(target_bb)
                cutter_search_bb.grow(cutter_search_bb.width() * 0.01) 
            except Exception as e:
                log_msg(f"Transform failed for {lyr.name()}: {e}", Qgis.Warning)
                cutter_search_bb = None 

            for feat in lyr.getSelectedFeatures():
                if lyr.id() == target_layer.id() and feat.id() in target_feat_ids:
                    continue
                    
                if cutter_search_bb and not feat.geometry().boundingBox().intersects(cutter_search_bb):
                    continue

                c_geom = QgsGeometry(feat.geometry())
                if c_geom.isNull(): continue
                
                if not xform.isShortCircuited():
                    c_geom.transform(xform)
                
                geoms_to_combine.append(c_geom.makeValid())
                cutter_count += 1

    log_msg(f"Found {cutter_count} valid cutting geometries intersecting the target bounds.")

    if not geoms_to_combine:
        return QgsGeometry()
    
    return QgsGeometry.unaryUnion(geoms_to_combine).makeValid()

# --- REVERTED ORIGINAL MATH HELPERS ---

def iter_polygon_parts(geom):
    if geom.isNull() or geom.isEmpty(): return
    parts = geom.asGeometryCollection() if geom.isMultipart() else [geom]
    for part in parts:
        if QgsWkbTypes.geometryType(part.wkbType()) != QgsWkbTypes.PolygonGeometry: continue
        poly = part.asPolygon()
        if poly: yield poly

def collect_nodes(geom):
    nodes = []
    for poly in iter_polygon_parts(geom):
        for ring in poly:
            pts = [QgsPointXY(p) for p in ring]
            if len(pts) > 1 and pts[0] == pts[-1]: pts = pts[:-1]
            nodes.extend(pts)
    return nodes

def normalize_ring(points):
    cleaned = []
    for p in points:
        pt = QgsPointXY(p)
        if not cleaned or cleaned[-1] != pt: cleaned.append(pt)
    if len(cleaned) < 3: return None
    if cleaned[0] != cleaned[-1]: cleaned.append(QgsPointXY(cleaned[0]))
    if len(cleaned) < 4: return None
    return cleaned

def build_polygon_geom(polys, prefer_multi=False):
    if not polys: return QgsGeometry()
    if prefer_multi or len(polys) > 1: return QgsGeometry.fromMultiPolygonXY(polys).makeValid()
    return QgsGeometry.fromPolygonXY(polys[0]).makeValid()

def snap_point(pt, ref_pts, boundary_geom, limit):
    best_pt = QgsPointXY(pt)
    min_dist = limit

    for ref in ref_pts:
        dist = pt.distance(ref)
        if dist < min_dist:
            min_dist = dist
            best_pt = QgsPointXY(ref)

    if best_pt == pt and not boundary_geom.isNull() and not boundary_geom.isEmpty():
        dist_to_edge = boundary_geom.distance(QgsGeometry.fromPointXY(pt))
        if dist_to_edge < limit:
            nearest_info = boundary_geom.closestSegmentWithContext(pt)
            nearest_pt = nearest_info[1]
            if nearest_pt is not None:
                best_pt = QgsPointXY(nearest_pt)

    return best_pt

def fill_gaps(base_geom, ref_geom, limit, relaxed=False):
    if limit <= 0 or base_geom.isEmpty() or ref_geom.isEmpty():
        return base_geom

    segs = 12 if not relaxed else 8
    ratio_threshold = 0.50 if not relaxed else 0.35
    area_threshold = (limit ** 2) * (0.005 if not relaxed else 0.01)

    base_buf = base_geom.buffer(limit, segs, Qgis.EndCapStyle.Flat, Qgis.JoinStyle.Miter, 2.0).makeValid()
    ref_buf = ref_geom.buffer(limit, segs, Qgis.EndCapStyle.Flat, Qgis.JoinStyle.Miter, 2.0).makeValid()

    if base_buf.isEmpty() or ref_buf.isEmpty():
        return base_geom

    search_zone = base_buf.intersection(ref_buf).makeValid()
    occupied = base_geom.combine(ref_geom).makeValid()
    candidates = search_zone.difference(occupied).makeValid()

    if candidates.isEmpty():
        return base_geom

    base_bound = QgsGeometry(base_geom.constGet().boundary())
    ref_bound = QgsGeometry(ref_geom.constGet().boundary())

    valid_fills = []
    parts = candidates.asGeometryCollection() if candidates.isMultipart() else [candidates]

    for p in parts:
        if p.isNull() or p.isEmpty():
            continue
        if QgsWkbTypes.geometryType(p.wkbType()) != QgsWkbTypes.PolygonGeometry:
            continue

        p_bound = QgsGeometry(p.constGet().boundary())
        plen = p_bound.length()
        if plen <= 0:
            continue

        shared_base = p_bound.intersection(base_bound).length()
        shared_ref = p_bound.intersection(ref_bound).length()
        shared_ratio = (shared_base + shared_ref) / plen
        touches_both = shared_base > 0 and shared_ref > 0

        if (touches_both and shared_ratio >= ratio_threshold) or p.area() <= area_threshold:
            valid_fills.append(p)

    if not valid_fills:
        return base_geom

    return base_geom.combine(QgsGeometry.unaryUnion(valid_fills)).makeValid()

def find_best_rigid_fit(target_geom, neighbors_geom, limit):
    if limit <= 0 or neighbors_geom.isEmpty():
        return target_geom
    
    best_geom = QgsGeometry(target_geom)
    min_void = target_geom.buffer(limit, 5).difference(target_geom).difference(neighbors_geom).area()
    
    step = limit * 0.5
    offsets = [(step, 0), (-step, 0), (0, step), (0, -step), 
               (step, step), (step, -step), (-step, step), (-step, -step)]

    for dx, dy in offsets:
        test_geom = QgsGeometry(target_geom)
        test_geom.translate(dx, dy)
        
        if test_geom.intersection(neighbors_geom).area() > (target_geom.area() * 0.1):
            continue
            
        current_void = test_geom.buffer(limit, 5).difference(test_geom).difference(neighbors_geom).area()
        if current_void < min_void:
            min_void = current_void
            best_geom = test_geom
    
    return best_geom

# --- REVERTED ORIGINAL FIT TARGET LOOP ---

def execute_fit_target(iface, target_layer, target_feat_ids, stretch_limit):
    if not target_layer or not target_feat_ids:
        log_msg("Fit Target aborted: No target layer or features.", Qgis.Warning)
        return False

    if not target_layer.isEditable() and not target_layer.startEditing():
        log_msg(f"Fit Target aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    log_msg(f"Starting Fit Target for {len(target_feat_ids)} features.")
    static_neighbors_geom = get_combined_cutters(target_layer, target_feat_ids).makeValid()

    if static_neighbors_geom.isNull() or static_neighbors_geom.isEmpty():
        log_msg("Fit Target aborted: No reference features selected in proximity.", Qgis.Warning)
        iface.messageBar().pushMessage("QGIS Target", "No reference features selected.", Qgis.Warning)
        return False

    total = len(target_feat_ids)
    progress_message = iface.messageBar().createMessage("QGIS Target: Vertex Matching...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    self_target_layer = target_layer
    self_target_layer.beginEditCommand("QGIS Target Vertex Fit")
    
    request = QgsFeatureRequest().setFilterFids(list(target_feat_ids))
    request.setNoAttributes() # OPTIMIZATION KEPT
    
    target_geoms = {
        feat.id(): feat.geometry().makeValid()
        for feat in self_target_layer.getFeatures(request)
    }

    processed_tids = set()

    for i, tid in enumerate(list(target_feat_ids)):
        current_geom = target_geoms.get(tid, QgsGeometry())

        if current_geom.isNull() or current_geom.isEmpty():
            processed_tids.add(tid)
            progress_bar.setValue(i + 1)
            QCoreApplication.processEvents()
            continue

        all_other_targets = [
            geom.makeValid()
            for other_tid, geom in target_geoms.items()
            if other_tid != tid and not geom.isNull() and not geom.isEmpty()
        ]

        if all_other_targets:
            other_union = QgsGeometry.unaryUnion(all_other_targets).makeValid()
            snap_neighbors = static_neighbors_geom.combine(other_union).makeValid()
        else:
            snap_neighbors = static_neighbors_geom

        processed_geoms = [
            target_geoms[p_tid].makeValid()
            for p_tid in processed_tids
            if p_tid in target_geoms
            and not target_geoms[p_tid].isNull()
            and not target_geoms[p_tid].isEmpty()
        ]

        if processed_geoms:
            processed_union = QgsGeometry.unaryUnion(processed_geoms).makeValid()
            hard_boundaries = static_neighbors_geom.combine(processed_union).makeValid()
        else:
            hard_boundaries = static_neighbors_geom

        neighbor_nodes = collect_nodes(snap_neighbors)
        if not snap_neighbors.isNull() and not snap_neighbors.isEmpty():
            neighbor_boundary = QgsGeometry(snap_neighbors.constGet().boundary())
        else:
            neighbor_boundary = QgsGeometry()

        seated_geom = find_best_rigid_fit(current_geom, hard_boundaries, stretch_limit).makeValid()

        new_polys = []
        seated_parts = seated_geom.asGeometryCollection() if seated_geom.isMultipart() else [seated_geom]

        for part in seated_parts:
            if part.isNull() or part.isEmpty():
                continue
            if QgsWkbTypes.geometryType(part.wkbType()) != QgsWkbTypes.PolygonGeometry:
                continue

            poly = part.asPolygon()
            if not poly:
                continue

            new_poly = []
            for ring_idx, ring in enumerate(poly):
                raw_pts = [QgsPointXY(p) for p in ring]
                if len(raw_pts) > 1 and raw_pts[0] == raw_pts[-1]:
                    raw_pts = raw_pts[:-1]

                snapped_pts = [
                    snap_point(pt, neighbor_nodes, neighbor_boundary, stretch_limit)
                    for pt in raw_pts
                ]

                norm_ring = normalize_ring(snapped_pts)

                if norm_ring is None:
                    if ring_idx == 0:
                        new_poly = []
                        break
                    continue

                new_poly.append(norm_ring)

            if new_poly:
                new_polys.append(new_poly)

        if not new_polys:
            final_geom = current_geom.makeValid()
        else:
            snapped_geom = build_polygon_geom(
                new_polys,
                prefer_multi=seated_geom.isMultipart()
            ).makeValid()

            clean_geom = snapped_geom
            overlap = clean_geom.intersection(hard_boundaries)
            if not overlap.isNull() and not overlap.isEmpty() and overlap.area() > 0:
                clean_geom = clean_geom.difference(hard_boundaries).makeValid()

            final_geom = clean_geom

            if stretch_limit > 0 and not final_geom.isEmpty():
                final_geom = fill_gaps(final_geom, hard_boundaries, stretch_limit, relaxed=False)

                micro_limit = stretch_limit * 0.25
                if micro_limit > 0:
                    final_geom = fill_gaps(final_geom, hard_boundaries, micro_limit, relaxed=True)

            final_geom = final_geom.snappedToGrid(0.000001, 0.000001).makeValid()

        self_target_layer.changeGeometry(tid, final_geom)
        target_geoms[tid] = final_geom
        processed_tids.add(tid)

        progress_bar.setValue(i + 1)
        QCoreApplication.processEvents()

    self_target_layer.endEditCommand()
    self_target_layer.triggerRepaint()
    iface.messageBar().clearWidgets()
    log_msg("Fit Target completed successfully.")
    return True