def classFactory(iface):
    from .core_plugin import QgisTarget
    return QgisTarget(iface)