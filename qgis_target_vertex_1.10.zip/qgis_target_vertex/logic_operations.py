from qgis.core import QgsFeatureRequest, QgsFeature, Qgis, QgsMessageLog, QgsGeometry, QgsWkbTypes
from qgis.PyQt.QtWidgets import QProgressBar
from qgis.PyQt.QtCore import QCoreApplication
from .logic_geometry import get_combined_cutters, fill_gaps

def log_msg(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(msg, "QGIS Target", level)

def remove_tiny_interior_rings(geom, max_area):
    """Safely sweeps up interior slivers/holes without touching the exterior boundary."""
    if geom.isNull() or geom.isEmpty(): return geom
    parts = geom.asGeometryCollection() if geom.isMultipart() else [geom]
    
    new_parts = []
    for part in parts:
        if QgsWkbTypes.geometryType(part.wkbType()) != QgsWkbTypes.PolygonGeometry:
            new_parts.append(part)
            continue
        
        poly = part.asPolygon()
        if not poly: 
            continue
            
        new_poly = [poly[0]] # Always keep the exterior boundary safe
        
        # Check interior rings (holes)
        for ring in poly[1:]:
            ring_geom = QgsGeometry.fromPolygonXY([ring])
            if ring_geom.area() > max_area:
                new_poly.append(ring) # Keep it if it's a legitimate large hole
        
        if new_poly:
            new_parts.append(QgsGeometry.fromPolygonXY(new_poly))
    
    if not new_parts:
        return geom
        
    if geom.isMultipart() or len(new_parts) > 1:
        return QgsGeometry.unaryUnion(new_parts).makeValid()
    else:
        return new_parts[0].makeValid()

def execute_dissolve(iface, target_layer, target_feat_ids, master_fid):
    if not target_layer or len(target_feat_ids) < 2:
        log_msg("Dissolve aborted: Need at least 2 features to dissolve.", Qgis.Warning)
        return False
        
    if not target_layer.isEditable() and not target_layer.startEditing(): 
        log_msg(f"Dissolve aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    total = len(target_feat_ids)
    log_msg(f"Starting Dissolve on {total} features. Keeping attributes of Feature ID: {master_fid}")
    
    progress_message = iface.messageBar().createMessage("QGIS Target: Dissolving...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand("QGIS Target Dissolve")
    
    request = QgsFeatureRequest().setFilterFids(list(target_feat_ids)).setNoAttributes()
    geoms_to_dissolve = []
    
    for i, target_feat in enumerate(target_layer.getFeatures(request)):
        geom = target_feat.geometry().makeValid()
        if not geom.isNull():
            geoms_to_dissolve.append(geom)

        if i % max(1, total // 20) == 0:
            progress_bar.setValue(i)
            QCoreApplication.processEvents()

    if not geoms_to_dissolve:
        target_layer.destroyEditCommand()
        iface.messageBar().clearWidgets()
        return False

    # --- Pre-Union Bridge: Close microscopic shared boundary gaps ---
    # Hardcoded micro-limit prevents exterior spikes while catching topology slivers
    MICRO_LIMIT = 0.02
    if len(geoms_to_dissolve) > 1:
        log_msg("Bridging microscopic gaps between neighbors prior to dissolve...")
        for i in range(len(geoms_to_dissolve)):
            for j in range(len(geoms_to_dissolve)):
                if i != j:
                    geoms_to_dissolve[i] = fill_gaps(geoms_to_dissolve[i], geoms_to_dissolve[j], MICRO_LIMIT, relaxed=False)

    # Execute Union
    dissolved_geom = QgsGeometry.unaryUnion(geoms_to_dissolve).makeValid()
    
    # --- Post-Union Sweep: Remove tiny leftover interior rings (slivers) ---
    SLIVER_AREA = 0.05
    dissolved_geom = remove_tiny_interior_rings(dissolved_geom, SLIVER_AREA)
        
    dissolved_geom = dissolved_geom.snappedToGrid(0.000001, 0.000001).makeValid()
    
    # Ensure Multi-type compliance if layer requires it
    if QgsWkbTypes.isMultiType(target_layer.wkbType()) and not dissolved_geom.isMultipart():
        dissolved_geom.convertToMultiType()

    # Update the chosen master feature with the massive new geometry
    target_layer.changeGeometry(master_fid, dissolved_geom)
    
    # Purge the remaining features
    fids_to_delete = [fid for fid in target_feat_ids if fid != master_fid]
    target_layer.deleteFeatures(fids_to_delete)

    target_layer.endEditCommand()
    target_layer.triggerRepaint()
    iface.messageBar().clearWidgets()
    log_msg("Dissolve completed successfully.")
    return True

def execute_disaggregate(iface, target_layer, target_feat_ids):
    if not target_layer or not target_feat_ids: 
        log_msg("Disaggregate aborted: No target layer or features.", Qgis.Warning)
        return False
        
    if not target_layer.isEditable() and not target_layer.startEditing(): 
        log_msg(f"Disaggregate aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    total = len(target_feat_ids)
    log_msg(f"Starting Disaggregate on {total} features.")
    
    progress_message = iface.messageBar().createMessage("QGIS Target: Disaggregating...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand("QGIS Target Disaggregate")
    
    request = QgsFeatureRequest().setFilterFids(list(target_feat_ids))
    features_to_add = []
    fids_to_delete = []
    pk_indices = target_layer.primaryKeyAttributes()

    for i, target_feat in enumerate(target_layer.getFeatures(request)):
        geom = target_feat.geometry().makeValid()
        if not geom.isMultipart():
            geom.convertToMultiType()
        
        parts = geom.asGeometryCollection()
        if len(parts) > 1:
            for part_geom in parts:
                new_feat = QgsFeature(target_feat)
                new_feat.setGeometry(part_geom)
                for pk_idx in pk_indices:
                    new_feat.setAttribute(pk_idx, None)
                features_to_add.append(new_feat)
            fids_to_delete.append(target_feat.id())

        if i % max(1, total // 20) == 0:
            progress_bar.setValue(i)
            QCoreApplication.processEvents()

    if features_to_add: target_layer.addFeatures(features_to_add)
    if fids_to_delete: target_layer.deleteFeatures(fids_to_delete)

    target_layer.endEditCommand()
    target_layer.triggerRepaint()
    iface.messageBar().clearWidgets()
    log_msg("Disaggregate completed successfully.")
    return True

def execute_op(iface, target_layer, target_feat_ids, mode):
    if not target_layer or not target_feat_ids: 
        log_msg(f"{mode} aborted: No target layer or features.", Qgis.Warning)
        return False
        
    if not target_layer.isEditable() and not target_layer.startEditing(): 
        log_msg(f"{mode} aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    log_msg(f"Starting {mode} for {len(target_feat_ids)} target features.")
    combined_cutters = get_combined_cutters(target_layer, target_feat_ids)
    
    if combined_cutters.isNull() or combined_cutters.isEmpty(): 
        log_msg(f"{mode} aborted: No intersecting cutter geometries found. Make sure your cutters overlap the target bounding box.", Qgis.Warning)
        iface.messageBar().pushMessage("QGIS Target", "No overlapping cutting features found.", Qgis.Warning)
        return False
    
    combined_cutters = combined_cutters.makeValid()

    total = len(target_feat_ids)
    progress_message = iface.messageBar().createMessage(f"QGIS Target: {mode} in progress...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand(f"QGIS Target {mode}")
    
    request = QgsFeatureRequest().setFilterFids(list(target_feat_ids))
    request.setNoAttributes()

    for i, target_feat in enumerate(target_layer.getFeatures(request)):
        fid = target_feat.id()
        target_geom = target_feat.geometry().makeValid()
        
        if mode == "Erase": 
            new_geom = target_geom.difference(combined_cutters)
        else: 
            new_geom = target_geom.intersection(combined_cutters)
        
        if not new_geom.isNull(): new_geom = new_geom.makeValid()

        if new_geom.isNull() or new_geom.isEmpty(): 
            target_layer.deleteFeature(fid)
        else: 
            target_layer.changeGeometry(fid, new_geom)
        
        if i % max(1, total // 20) == 0:
            progress_bar.setValue(i)
            QCoreApplication.processEvents()

    target_layer.endEditCommand()
    target_layer.triggerRepaint()
    iface.messageBar().clearWidgets()
    log_msg(f"{mode} completed successfully.")
    return True