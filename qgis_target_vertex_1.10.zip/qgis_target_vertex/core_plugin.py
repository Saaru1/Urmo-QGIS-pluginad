import os
from qgis.core import (QgsProject, QgsWkbTypes, Qgis, QgsFeatureRequest, QgsFeature, 
                       QgsSettings, QgsVectorLayer, QgsFillSymbol, QgsMessageLog)
from qgis.gui import QgsRubberBand
from qgis.PyQt.QtWidgets import (QAction, QDoubleSpinBox, QCheckBox, QWidgetAction, 
                                 QWidget, QHBoxLayout, QLabel, QProgressBar, QDialog,
                                 QVBoxLayout, QListWidget, QListWidgetItem, QDialogButtonBox)
from qgis.PyQt.QtCore import QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon, QColor

from .logic_operations import execute_disaggregate, execute_op, execute_dissolve
from .logic_geometry import execute_fit_target

# Cross-compatibility for QGIS 3 (PyQt5) and QGIS 4 (PyQt6)
try:
    USER_ROLE = Qt.ItemDataRole.UserRole
    BTN_OK = QDialogButtonBox.StandardButton.Ok
    BTN_CANCEL = QDialogButtonBox.StandardButton.Cancel
except AttributeError:
    USER_ROLE = Qt.UserRole
    BTN_OK = QDialogButtonBox.Ok
    BTN_CANCEL = QDialogButtonBox.Cancel

def log_msg(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(msg, "QGIS Target UI", level)

class DissolveDialog(QDialog):
    def __init__(self, layer, feat_ids, canvas, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Master Feature")
        self.layer = layer
        self.canvas = canvas
        self.master_fid = None

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Select the feature whose attributes will be preserved.\nIt will highlight in Cyan on the map."))

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)
        
        self.rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setColor(QColor(0, 255, 255, 175)) # Cyan highlight
        self.rb.setWidth(3)

        self.feats = {}
        request = QgsFeatureRequest().setFilterFids(list(feat_ids)).setNoAttributes()
        for f in layer.getFeatures(request):
            self.feats[f.id()] = f.geometry()
            item = QListWidgetItem(f"Feature ID: {f.id()}")
            item.setData(USER_ROLE, f.id())
            self.list_widget.addItem(item)

        self.list_widget.itemSelectionChanged.connect(self.on_selection_changed)

        self.buttons = QDialogButtonBox(BTN_OK | BTN_CANCEL)
        self.buttons.button(BTN_OK).setText("Dissolve")
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        
        if self.list_widget.count() > 0:
            self.list_widget.setCurrentRow(0)

    def on_selection_changed(self):
        self.rb.reset(QgsWkbTypes.PolygonGeometry)
        items = self.list_widget.selectedItems()
        if items:
            fid = items[0].data(USER_ROLE)
            geom = self.feats.get(fid)
            if geom:
                self.rb.addGeometry(geom, self.layer)
                self.master_fid = fid

    def closeEvent(self, event):
        self.rb.reset()
        super().closeEvent(event)
        
    def reject(self):
        self.rb.reset()
        super().reject()
        
    def accept(self):
        self.rb.reset()
        super().accept()

class QgisTarget:
    def __init__(self, iface):
        self.iface = iface
        self.target_layer = None
        self.target_feat_ids = set() 
        self.target_crs = None
        self.ghost_layer = None 
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        settings = QgsSettings()
        saved_limit = float(settings.value("QgisTarget/stretchLimit", 1.0))
        saved_override = settings.value("QgisTarget/overrideLimit", False, type=bool)

        self.act_set = QAction(QIcon(os.path.join(self.plugin_dir, "set_target.png")), "Set Target", self.iface.mainWindow())
        self.act_set.setCheckable(True)
        self.act_clear = QAction(QIcon(os.path.join(self.plugin_dir, "clear_target.png")), "Clear Target", self.iface.mainWindow())
        self.act_erase = QAction(QIcon(os.path.join(self.plugin_dir, "erase.png")), "Erase Target", self.iface.mainWindow())
        self.act_erase_out = QAction(QIcon(os.path.join(self.plugin_dir, "erase_outside.png")), "Erase Outside Target", self.iface.mainWindow())
        self.act_disaggregate = QAction(QIcon(os.path.join(self.plugin_dir, "disaggregate.png")), "Disaggregate Target", self.iface.mainWindow())
        self.act_dissolve = QAction(QIcon(os.path.join(self.plugin_dir, "dissolve_target.png")), "Dissolve Target", self.iface.mainWindow())
        self.act_fit = QAction(QIcon(os.path.join(self.plugin_dir, "fit_target.png")), "Fit Target", self.iface.mainWindow())

        self.spin_limit = QDoubleSpinBox()
        self.spin_limit.setRange(0.0, 9999.0)
        self.spin_limit.setDecimals(2)
        self.spin_limit.setSingleStep(0.1)
        self.spin_limit.setValue(saved_limit)
        self.spin_limit.setToolTip("Stretch Limit (max gap fill distance)")
        self.spin_limit.valueChanged.connect(self.save_settings)

        self.chk_override = QCheckBox("")
        self.chk_override.setChecked(saved_override)
        self.chk_override.setToolTip("Enable Fit Target even if more than 1 features are targeted")
        self.chk_override.stateChanged.connect(self.save_settings)
        self.chk_override.stateChanged.connect(self.update_button_states)

        self.fit_widget = QWidget()
        layout = QHBoxLayout()
        layout.setContentsMargins(5, 0, 5, 0)
        layout.addWidget(QLabel(""))
        layout.addWidget(self.spin_limit)
        layout.addWidget(self.chk_override)
        self.fit_widget.setLayout(layout)

        self.act_fit_params = QWidgetAction(self.iface.mainWindow())
        self.act_fit_params.setDefaultWidget(self.fit_widget)

        self.act_set.triggered.connect(self.set_target)
        self.act_clear.triggered.connect(self.clear_target)
        self.act_erase.triggered.connect(lambda checked=False: self.run_op("Erase"))
        self.act_erase_out.triggered.connect(lambda checked=False: self.run_op("Erase Outside"))
        self.act_disaggregate.triggered.connect(self.disaggregate)
        self.act_dissolve.triggered.connect(self.dissolve_target)
        self.act_fit.triggered.connect(self.fit_target)

        self.iface.currentLayerChanged.connect(self.update_button_states)
        QgsProject.instance().layersAdded.connect(self.connect_selection_signals)
        self.connect_selection_signals()

        self.toolbar = self.iface.addToolBar("QGIS Target")
        self.toolbar.setObjectName("QGISTargetToolbar")
        self.toolbar.addAction(self.act_set)
        self.toolbar.addAction(self.act_clear)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.act_erase)
        self.toolbar.addAction(self.act_erase_out)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.act_disaggregate)
        self.toolbar.addAction(self.act_dissolve)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.act_fit_params)
        self.toolbar.addAction(self.act_fit)

        self.update_button_states()

    def save_settings(self):
        settings = QgsSettings()
        settings.setValue("QgisTarget/stretchLimit", self.spin_limit.value())
        settings.setValue("QgisTarget/overrideLimit", self.chk_override.isChecked())

    def connect_selection_signals(self):
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == Qgis.LayerType.Vector:
                try: layer.selectionChanged.disconnect(self.update_button_states)
                except: pass
                layer.selectionChanged.connect(self.update_button_states)

    def update_button_states(self):
        has_selection = any(lyr.selectedFeatureCount() > 0 for lyr in QgsProject.instance().mapLayers().values() if lyr.type() == Qgis.LayerType.Vector)
        target_exists = self.target_layer is not None and len(self.target_feat_ids) > 0
        
        cutter_exists = False
        if target_exists:
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr.type() == Qgis.LayerType.Vector and lyr.selectedFeatureCount() > 0:
                    if lyr.id() != self.target_layer.id() or not all(fid in self.target_feat_ids for fid in lyr.selectedFeatureIds()):
                        cutter_exists = True
                        break

        self.act_set.setEnabled(has_selection or target_exists)
        self.act_clear.setEnabled(target_exists)
        self.act_erase.setEnabled(target_exists and cutter_exists)
        self.act_erase_out.setEnabled(target_exists and cutter_exists)
        
        self.act_disaggregate.setEnabled(target_exists)
        self.act_dissolve.setEnabled(target_exists and len(self.target_feat_ids) > 1)

        allow_fit = target_exists and cutter_exists
        if allow_fit and len(self.target_feat_ids) > 1 and not self.chk_override.isChecked():
            allow_fit = False
        self.act_fit.setEnabled(allow_fit)

    def set_target(self):
        if not self.act_set.isChecked():
            self.clear_target()
            return

        layer = self.iface.activeLayer()
        if not layer or layer.selectedFeatureCount() == 0:
            self.act_set.setChecked(False)
            return

        if self.ghost_layer:
            QgsProject.instance().removeMapLayer(self.ghost_layer.id())

        total = layer.selectedFeatureCount()
        log_msg(f"Initiating Set Target for {total} features.")
        
        progress_message = self.iface.messageBar().createMessage("QGIS Target: Setting Target...")
        progress_bar = QProgressBar()
        progress_bar.setMaximum(total)
        progress_message.layout().addWidget(progress_bar)
        self.iface.messageBar().pushWidget(progress_message, Qgis.Info)

        try:
            self.target_layer = layer
            self.target_feat_ids = set(layer.selectedFeatureIds())
            self.target_crs = layer.crs()

            layer_geom_type = layer.geometryType()
            if layer_geom_type == Qgis.GeometryType.Point:
                geom_str = "MultiPoint"
            elif layer_geom_type == Qgis.GeometryType.Line:
                geom_str = "MultiLineString"
            elif layer_geom_type == Qgis.GeometryType.Polygon:
                geom_str = "MultiPolygon"
            else:
                raise Exception("Cannot set target on a layer without valid geometry.")

            crs_authid = layer.crs().authid()
            uri = f"{geom_str}?crs={crs_authid}" if crs_authid else geom_str
            
            self.ghost_layer = QgsVectorLayer(uri, "🎯 Target Preview [Do Not Edit]", "memory")
            if not self.ghost_layer.isValid():
                raise Exception(f"Failed to create memory layer with URI: {uri}")

            provider = self.ghost_layer.dataProvider()

            request = QgsFeatureRequest().setFilterFids(list(self.target_feat_ids))
            request.setNoAttributes() 
            
            features_to_add = []
            for i, feat in enumerate(self.target_layer.getFeatures(request)):
                new_feat = QgsFeature()
                new_feat.setGeometry(feat.geometry())
                features_to_add.append(new_feat)
                
                if i % max(1, total // 20) == 0:
                    progress_bar.setValue(i)
                    QCoreApplication.processEvents()
                
            provider.addFeatures(features_to_add)

            if layer_geom_type == Qgis.GeometryType.Polygon:
                symbol = QgsFillSymbol.createSimple({'color': '255,0,0,100', 'outline_color': '255,0,0,255', 'outline_width': '0.6'})
                self.ghost_layer.renderer().setSymbol(symbol)
            
            self.ghost_layer.setReadOnly(True)

            QgsProject.instance().addMapLayer(self.ghost_layer, False)
            
            root = QgsProject.instance().layerTreeRoot()
            group = root.findGroup("🎯 QGIS Target System")
            if not group:
                group = root.insertGroup(0, "🎯 QGIS Target System") 
                
            layer_node = group.addLayer(self.ghost_layer)
            
            if layer_node:
                layer_node.setItemVisibilityChecked(True)
                layer_node.setExpanded(False)
            group.setExpanded(False)

            self.ghost_layer.triggerRepaint()
            self.iface.mapCanvas().refresh()
            
            log_msg("Target successfully set and drawn.")

        except Exception as e:
            log_msg(f"Critical error setting target: {str(e)}", Qgis.Critical)
            self.iface.messageBar().pushMessage("Error setting target", str(e), Qgis.Critical)
            self.clear_target()
        finally:
            self.iface.messageBar().clearWidgets()

        self.update_button_states()

    def clear_target(self):
        self.target_layer = None
        self.target_feat_ids = set()
        self.act_set.setChecked(False)
        
        if self.ghost_layer:
            QgsProject.instance().removeMapLayer(self.ghost_layer.id())
            self.ghost_layer = None
            
        root = QgsProject.instance().layerTreeRoot()
        for group in root.findGroups():
            if group.name() == "🎯 QGIS Target System" and not group.children():
                root.removeChildNode(group)

        self.iface.mapCanvas().refresh()
        self.iface.mainWindow().statusBar().clearMessage()
        self.update_button_states()
        log_msg("Target cleared.")

    def disaggregate(self):
        if execute_disaggregate(self.iface, self.target_layer, self.target_feat_ids):
            self.clear_target()

    def dissolve_target(self):
        if not self.target_layer or len(self.target_feat_ids) < 2: return
        
        dialog = DissolveDialog(self.target_layer, self.target_feat_ids, self.iface.mapCanvas(), self.iface.mainWindow())
        if dialog.exec():
            master_fid = dialog.master_fid
            if master_fid is not None:
                # Removed the spin_limit parameter; Dissolve handles its own micro-tolerance now
                if execute_dissolve(self.iface, self.target_layer, self.target_feat_ids, master_fid):
                    self.clear_target()

    def run_op(self, mode):
        if execute_op(self.iface, self.target_layer, self.target_feat_ids, mode):
            self.clear_target()

    def fit_target(self):
        if execute_fit_target(self.iface, self.target_layer, self.target_feat_ids, self.spin_limit.value()):
            self.clear_target()

    def unload(self):
        if self.toolbar: self.iface.mainWindow().removeToolBar(self.toolbar)
        self.clear_target()