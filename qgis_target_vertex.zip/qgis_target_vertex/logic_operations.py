from qgis.core import QgsFeatureRequest, QgsFeature, Qgis, QgsMessageLog, QgsGeometry, QgsWkbTypes
from qgis.PyQt.QtWidgets import QProgressBar
from qgis.PyQt.QtCore import QCoreApplication
from .logic_geometry import build_cutter_index, fill_gaps

def log_msg(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(msg, "QGIS Target", level)

def _dismiss_progress(iface, progress_message):
    bar = iface.messageBar()
    if hasattr(bar, "popWidget"):
        bar.popWidget(progress_message)
    else:
        bar.clearWidgets()

def _extract_matching_geometry(geom, target_geom_type):
    """Sanitizes overlay output to match the target layer's geometry dimension without altering vertices.

    Strips degenerate lower-dimension leftovers (e.g. LineString/Point on a Polygon layer)
    and extracts the matching subclass from a GeometryCollection.
    """
    if geom.isNull() or geom.isEmpty():
        return QgsGeometry()

    if target_geom_type == Qgis.GeometryType.Polygon:
        expected_wkb_geom_type = QgsWkbTypes.PolygonGeometry
    elif target_geom_type == Qgis.GeometryType.Line:
        expected_wkb_geom_type = QgsWkbTypes.LineGeometry
    elif target_geom_type == Qgis.GeometryType.Point:
        expected_wkb_geom_type = QgsWkbTypes.PointGeometry
    else:
        return geom

    if geom.wkbType() == QgsWkbTypes.GeometryCollection:
        geom = QgsGeometry(geom)
        geom.convertGeometryCollectionToSubclass(expected_wkb_geom_type)

    if geom.isNull() or geom.isEmpty():
        return QgsGeometry()

    if QgsWkbTypes.geometryType(geom.wkbType()) != expected_wkb_geom_type:
        return QgsGeometry()

    if expected_wkb_geom_type == QgsWkbTypes.PolygonGeometry and geom.area() <= 0:
        return QgsGeometry()
    if expected_wkb_geom_type == QgsWkbTypes.LineGeometry and geom.length() <= 0:
        return QgsGeometry()

    return geom

def _warn_if_singlepart_gpkg_multipart(iface, target_layer, multi_count):
    """Shows a non-blocking warning if MultiPolygon/MultiLine geometries were written to a single-part GPKG header."""
    if multi_count <= 0 or target_layer is None:
        return
    if QgsWkbTypes.isMultiType(target_layer.wkbType()):
        return
    provider = target_layer.dataProvider()
    if provider is not None and provider.storageType() == "GPKG":
        msg = (
            f"{multi_count} feature(s) are multipart, but '{target_layer.name()}' has a single-part "
            f"GeoPackage schema header. Saving directly in QGIS may flatten extra parts into invalid rings; "
            f"export as MultiPolygon if needed."
        )
        log_msg(msg, Qgis.Warning)
        iface.messageBar().pushMessage("QGIS Target", msg, Qgis.Warning)

def remove_tiny_interior_rings(geom, max_area):
    """Safely sweeps up interior slivers/holes without touching the exterior boundary."""
    if geom.isNull() or geom.isEmpty(): return geom
    parts = geom.asGeometryCollection() if geom.isMultipart() else [geom]
    
    new_parts = []
    for part in parts:
        if QgsWkbTypes.geometryType(part.wkbType()) != QgsWkbTypes.PolygonGeometry:
            new_parts.append(part)
            continue
        
        poly = part.asPolygon()
        if not poly: 
            continue
            
        new_poly = [poly[0]] # Always keep the exterior boundary safe
        
        # Check interior rings (holes)
        for ring in poly[1:]:
            ring_geom = QgsGeometry.fromPolygonXY([ring])
            if ring_geom.area() > max_area:
                new_poly.append(ring) # Keep it if it's a legitimate large hole
        
        if new_poly:
            new_parts.append(QgsGeometry.fromPolygonXY(new_poly))
    
    if not new_parts:
        return geom
        
    if geom.isMultipart() or len(new_parts) > 1:
        return QgsGeometry.unaryUnion(new_parts).makeValid()
    else:
        return new_parts[0].makeValid()

def execute_dissolve(iface, target_layer, target_feat_ids, master_fid):
    if not target_layer or len(target_feat_ids) < 2:
        log_msg("Dissolve aborted: Need at least 2 features to dissolve.", Qgis.Warning)
        return False
        
    if not target_layer.isEditable() and not target_layer.startEditing(): 
        log_msg(f"Dissolve aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    total = len(target_feat_ids)
    log_msg(f"Starting Dissolve on {total} features. Keeping attributes of Feature ID: {master_fid}")
    
    progress_message = iface.messageBar().createMessage("QGIS Target: Dissolving...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    if progress_message and progress_message.layout():
        progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand("QGIS Target Dissolve")
    dissolved_is_multi = False
    
    try:
        request = QgsFeatureRequest().setFilterFids(list(target_feat_ids)).setNoAttributes()
        geoms_to_dissolve = []
        
        for i, target_feat in enumerate(target_layer.getFeatures(request)):
            geom = target_feat.geometry().makeValid()
            if not geom.isNull():
                geoms_to_dissolve.append(geom)

            if i % max(1, total // 20) == 0:
                progress_bar.setValue(i)
                QCoreApplication.processEvents()

        if not geoms_to_dissolve:
            target_layer.destroyEditCommand()
            _dismiss_progress(iface, progress_message)
            return False

        # --- Pre-Union Bridge: Close microscopic shared boundary gaps ---
        MICRO_LIMIT = 0.02
        if len(geoms_to_dissolve) > 1:
            log_msg("Bridging microscopic gaps between neighbors prior to dissolve...")
            for i in range(len(geoms_to_dissolve)):
                for j in range(len(geoms_to_dissolve)):
                    if i != j:
                        geoms_to_dissolve[i] = fill_gaps(geoms_to_dissolve[i], geoms_to_dissolve[j], MICRO_LIMIT, relaxed=False)

        # Execute Union
        dissolved_geom = QgsGeometry.unaryUnion(geoms_to_dissolve).makeValid()
        
        # --- Post-Union Sweep: Remove tiny leftover interior rings (slivers) ---
        SLIVER_AREA = 0.05
        dissolved_geom = remove_tiny_interior_rings(dissolved_geom, SLIVER_AREA)
            
        dissolved_geom = dissolved_geom.snappedToGrid(0.000001, 0.000001).makeValid()
        
        # Ensure Multi-type compliance if layer requires it
        if QgsWkbTypes.isMultiType(target_layer.wkbType()) and not dissolved_geom.isMultipart():
            dissolved_geom.convertToMultiType()
        dissolved_is_multi = dissolved_geom.isMultipart()

        # Update the chosen master feature with the massive new geometry
        target_layer.changeGeometry(master_fid, dissolved_geom)
        
        # Purge the remaining features
        fids_to_delete = [fid for fid in target_feat_ids if fid != master_fid]
        target_layer.deleteFeatures(fids_to_delete)

        target_layer.endEditCommand()
        target_layer.triggerRepaint()
        log_msg("Dissolve completed successfully.")
    except Exception as e:
        target_layer.destroyEditCommand()
        _dismiss_progress(iface, progress_message)
        log_msg(f"Critical error during Dissolve: {str(e)}", Qgis.Critical)
        iface.messageBar().pushMessage("QGIS Target", f"Dissolve failed: {str(e)}", Qgis.Critical)
        return False
    else:
        _dismiss_progress(iface, progress_message)
        if dissolved_is_multi:
            _warn_if_singlepart_gpkg_multipart(iface, target_layer, 1)
        return True

def execute_disaggregate(iface, target_layer, target_feat_ids):
    if not target_layer or not target_feat_ids: 
        log_msg("Disaggregate aborted: No target layer or features.", Qgis.Warning)
        return False
        
    if not target_layer.isEditable() and not target_layer.startEditing(): 
        log_msg(f"Disaggregate aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    total = len(target_feat_ids)
    log_msg(f"Starting Disaggregate on {total} features.")
    
    progress_message = iface.messageBar().createMessage("QGIS Target: Disaggregating...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    if progress_message and progress_message.layout():
        progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand("QGIS Target Disaggregate")
    
    try:
        request = QgsFeatureRequest().setFilterFids(list(target_feat_ids))
        features_to_add = []
        fids_to_delete = []
        pk_indices = target_layer.primaryKeyAttributes()

        for i, target_feat in enumerate(target_layer.getFeatures(request)):
            geom = target_feat.geometry().makeValid()
            if not geom.isMultipart():
                geom.convertToMultiType()
            
            parts = geom.asGeometryCollection()
            if len(parts) > 1:
                for part_geom in parts:
                    new_feat = QgsFeature(target_feat)
                    new_feat.setGeometry(part_geom)
                    for pk_idx in pk_indices:
                        new_feat.setAttribute(pk_idx, None)
                    features_to_add.append(new_feat)
                fids_to_delete.append(target_feat.id())

            if i % max(1, total // 20) == 0:
                progress_bar.setValue(i)
                QCoreApplication.processEvents()

        if features_to_add: target_layer.addFeatures(features_to_add)
        if fids_to_delete: target_layer.deleteFeatures(fids_to_delete)

        target_layer.endEditCommand()
        target_layer.triggerRepaint()
        log_msg("Disaggregate completed successfully.")
    except Exception as e:
        target_layer.destroyEditCommand()
        _dismiss_progress(iface, progress_message)
        log_msg(f"Critical error during Disaggregate: {str(e)}", Qgis.Critical)
        iface.messageBar().pushMessage("QGIS Target", f"Disaggregate failed: {str(e)}", Qgis.Critical)
        return False
    else:
        _dismiss_progress(iface, progress_message)
        return True

def execute_op(iface, target_layer, target_feat_ids, mode):
    if not target_layer or not target_feat_ids: 
        log_msg(f"{mode} aborted: No target layer or features.", Qgis.Warning)
        return False
        
    if not target_layer.isEditable() and not target_layer.startEditing(): 
        log_msg(f"{mode} aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    log_msg(f"Starting {mode} for {len(target_feat_ids)} target features.")
    spatial_index, cutter_geoms, cutter_types = build_cutter_index(target_layer, target_feat_ids)
    
    if not cutter_geoms: 
        log_msg(f"{mode} aborted: No intersecting cutter geometries found. Make sure your cutters overlap the target bounding box.", Qgis.Warning)
        iface.messageBar().pushMessage("QGIS Target", "No overlapping cutting features found.", Qgis.Warning)
        return False

    # Inform user if cutter geometries are exclusively lines being applied to a polygon
    target_geom_type = target_layer.geometryType()
    is_target_poly = (target_geom_type == Qgis.GeometryType.Polygon)
    if is_target_poly and cutter_types == {QgsWkbTypes.LineGeometry}:
        msg = f"Cannot {mode} a polygon using line cutters (lines have zero area). Use 'Split Target' to cut polygons with lines."
        log_msg(msg, Qgis.Warning)
        iface.messageBar().pushMessage("QGIS Target", msg, Qgis.Warning)
        return False

    total = len(target_feat_ids)
    progress_message = iface.messageBar().createMessage(f"QGIS Target: {mode} in progress...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    if progress_message and progress_message.layout():
        progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand(f"QGIS Target {mode}")
    is_multi_layer = QgsWkbTypes.isMultiType(target_layer.wkbType())
    fids_to_delete = []
    geoms_to_change = {}
    multi_result_count = 0
    step = max(1, total // 20)
    
    try:
        request = QgsFeatureRequest().setFilterFids(list(target_feat_ids))
        request.setNoAttributes()

        for i, target_feat in enumerate(target_layer.getFeatures(request)):
            if i % step == 0:
                progress_bar.setValue(i)
                QCoreApplication.processEvents()

            fid = target_feat.id()
            target_geom = target_feat.geometry()

            if target_geom.isNull() or target_geom.isEmpty():
                if mode != "Erase":
                    fids_to_delete.append(fid)
                continue

            cand_ids = spatial_index.intersects(target_geom.boundingBox())
            if not cand_ids:
                if mode != "Erase":
                    fids_to_delete.append(fid)
                # For Erase: untouched — skip completely without modifying the feature
                continue

            if not target_geom.isGeosValid():
                target_geom = target_geom.makeValid()

            engine = QgsGeometry.createGeometryEngine(target_geom.constGet())
            engine.prepareGeometry()

            hits = []
            for cid in cand_ids:
                cg = cutter_geoms[cid]
                if is_target_poly and QgsWkbTypes.geometryType(cg.wkbType()) != QgsWkbTypes.PolygonGeometry:
                    continue
                cg_raw = cg.constGet()
                if not engine.intersects(cg_raw):
                    continue
                # For Polygon x Polygon, skip pure boundary touches (0 area overlap):
                # prevents stray boundary vertices in Erase and LineString/Point artifacts in Erase Outside
                if is_target_poly and engine.touches(cg_raw):
                    continue
                hits.append(cg)

            if not hits:
                if mode != "Erase":
                    fids_to_delete.append(fid)
                continue

            if len(hits) == 1:
                local_cutter = hits[0]
            else:
                local_cutter = QgsGeometry.unaryUnion(hits)
                if not local_cutter.isNull() and not local_cutter.isEmpty() and not local_cutter.isGeosValid():
                    local_cutter = local_cutter.makeValid()

            # For Erase Outside: if target is 100% within cutter, keep original geometry untouched
            if mode != "Erase":
                if local_cutter.boundingBox().contains(target_geom.boundingBox()) and target_geom.within(local_cutter):
                    continue

            if mode == "Erase": 
                new_geom = target_geom.difference(local_cutter)
            else: 
                new_geom = target_geom.intersection(local_cutter)
            
            if not new_geom.isNull() and not new_geom.isEmpty() and not new_geom.isGeosValid():
                new_geom = new_geom.makeValid()

            new_geom = _extract_matching_geometry(new_geom, target_geom_type)

            if new_geom.isNull() or new_geom.isEmpty(): 
                fids_to_delete.append(fid)
            else: 
                if is_multi_layer and not new_geom.isMultipart():
                    new_geom.convertToMultiType()
                if new_geom.isMultipart():
                    multi_result_count += 1
                geoms_to_change[fid] = new_geom

        if fids_to_delete:
            target_layer.deleteFeatures(fids_to_delete)
        for fid, geom in geoms_to_change.items():
            target_layer.changeGeometry(fid, geom)

        target_layer.endEditCommand()
        target_layer.triggerRepaint()
        log_msg(f"{mode} completed successfully (changed={len(geoms_to_change)}, deleted={len(fids_to_delete)}).")
    except Exception as e:
        target_layer.destroyEditCommand()
        _dismiss_progress(iface, progress_message)
        log_msg(f"Critical error during {mode}: {str(e)}", Qgis.Critical)
        iface.messageBar().pushMessage("QGIS Target", f"{mode} failed: {str(e)}", Qgis.Critical)
        return False
    else:
        _dismiss_progress(iface, progress_message)
        _warn_if_singlepart_gpkg_multipart(iface, target_layer, multi_result_count)
        return True

def execute_split(iface, target_layer, target_feat_ids):
    if not target_layer or not target_feat_ids:
        log_msg("Split aborted: No target layer or features.", Qgis.Warning)
        return False

    if not target_layer.isEditable() and not target_layer.startEditing():
        log_msg(f"Split aborted: Could not start editing on {target_layer.name()}.", Qgis.Critical)
        return False

    log_msg(f"Starting Split for {len(target_feat_ids)} target features.")
    spatial_index, cutter_geoms, cutter_types = build_cutter_index(target_layer, target_feat_ids)

    if not cutter_geoms:
        log_msg("Split aborted: No intersecting cutter geometries found. Make sure your cutters overlap the target bounding box.", Qgis.Warning)
        iface.messageBar().pushMessage("QGIS Target", "No overlapping cutting features found.", Qgis.Warning)
        return False

    target_geom_type = target_layer.geometryType()
    is_multi_layer = QgsWkbTypes.isMultiType(target_layer.wkbType())

    total = len(target_feat_ids)
    progress_message = iface.messageBar().createMessage("QGIS Target: Split in progress...")
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total)
    if progress_message and progress_message.layout():
        progress_message.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(progress_message, Qgis.Info)

    target_layer.beginEditCommand("QGIS Target Split")

    pk_indices = target_layer.primaryKeyAttributes()
    request = QgsFeatureRequest().setFilterFids(list(target_feat_ids))
    features_to_add = []
    geoms_to_change = {}
    split_count = 0
    multi_result_count = 0
    step = max(1, total // 20)

    try:
        for i, target_feat in enumerate(target_layer.getFeatures(request)):
            if i % step == 0:
                progress_bar.setValue(i)
                QCoreApplication.processEvents()

            fid = target_feat.id()
            target_geom = target_feat.geometry()

            if target_geom.isNull() or target_geom.isEmpty():
                continue

            cand_ids = spatial_index.intersects(target_geom.boundingBox())
            if not cand_ids:
                continue

            if not target_geom.isGeosValid():
                target_geom = target_geom.makeValid()

            engine = QgsGeometry.createGeometryEngine(target_geom.constGet())
            engine.prepareGeometry()

            line_hits = []
            poly_hits = []
            for cid in cand_ids:
                cg = cutter_geoms[cid]
                if not engine.intersects(cg.constGet()):
                    continue
                gtype = QgsWkbTypes.geometryType(cg.wkbType())
                if gtype == QgsWkbTypes.LineGeometry:
                    line_hits.append(cg)
                elif gtype == QgsWkbTypes.PolygonGeometry:
                    poly_hits.append(cg)

            if not line_hits and not poly_hits:
                continue

            split_parts = []

            # Case 1: Polygon target split by Line cutter(s)
            if target_geom_type == Qgis.GeometryType.Polygon and line_hits:
                local_lines = line_hits[0] if len(line_hits) == 1 else QgsGeometry.unaryUnion(line_hits)
                orig_parts = target_geom.asGeometryCollection() if target_geom.isMultipart() else [target_geom]
                newly_split_parts = []
                unchanged_parts = []
                was_split = False

                for part in orig_parts:
                    if part.isNull() or part.isEmpty():
                        continue
                    if not part.intersects(local_lines):
                        unchanged_parts.append(part)
                        continue

                    boundary = QgsGeometry(part.constGet().boundary())
                    unioned_lines = QgsGeometry.unaryUnion([boundary, local_lines])
                    polygonized = QgsGeometry.polygonize([unioned_lines])
                    candidates = polygonized.asGeometryCollection() if polygonized.isMultipart() else [polygonized]
                    part_pieces = [
                        p for p in candidates
                        if not p.isNull() and not p.isEmpty() and part.contains(p.pointOnSurface())
                    ]

                    if len(part_pieces) > 1:
                        was_split = True
                        newly_split_parts.extend(part_pieces)
                    else:
                        # Incomplete cut or touch: keep original part 100% untouched (no stray nodes added)
                        unchanged_parts.append(part)

                if was_split and newly_split_parts:
                    if unchanged_parts:
                        first_combined = QgsGeometry.collectGeometry([newly_split_parts[0]] + unchanged_parts)
                        split_parts = [first_combined] + newly_split_parts[1:]
                    else:
                        split_parts = newly_split_parts

            # Case 2: Polygon target split by Polygon cutter(s) (Inside vs Outside, preserving MultiPolygons 1-to-1)
            elif target_geom_type == Qgis.GeometryType.Polygon and poly_hits:
                local_polys = poly_hits[0] if len(poly_hits) == 1 else QgsGeometry.unaryUnion(poly_hits)
                if len(poly_hits) > 1 and not local_polys.isGeosValid():
                    local_polys = local_polys.makeValid()

                p_inside = _extract_matching_geometry(
                    target_geom.intersection(local_polys), Qgis.GeometryType.Polygon
                )
                p_outside = _extract_matching_geometry(
                    target_geom.difference(local_polys), Qgis.GeometryType.Polygon
                )

                if not p_inside.isEmpty() and not p_outside.isEmpty():
                    split_parts = [p_inside, p_outside]

            # Case 3: Line target split by Line cutter(s) (slice at intersections)
            elif target_geom_type == Qgis.GeometryType.Line and line_hits:
                local_lines = line_hits[0] if len(line_hits) == 1 else QgsGeometry.unaryUnion(line_hits)
                orig_parts = target_geom.asGeometryCollection() if target_geom.isMultipart() else [target_geom]
                newly_split_parts = []
                unchanged_parts = []
                was_split = False

                for part in orig_parts:
                    if part.isNull() or part.isEmpty():
                        continue
                    if not part.intersects(local_lines):
                        unchanged_parts.append(part)
                        continue

                    diff = _extract_matching_geometry(part.difference(local_lines), Qgis.GeometryType.Line)
                    part_pieces = [
                        p for p in (diff.asGeometryCollection() if diff.isMultipart() else [diff])
                        if not p.isNull() and not p.isEmpty() and p.length() > 0
                    ]
                    if len(part_pieces) > 1:
                        was_split = True
                        newly_split_parts.extend(part_pieces)
                    else:
                        unchanged_parts.append(part)

                if was_split and newly_split_parts:
                    if unchanged_parts:
                        first_combined = QgsGeometry.collectGeometry([newly_split_parts[0]] + unchanged_parts)
                        split_parts = [first_combined] + newly_split_parts[1:]
                    else:
                        split_parts = newly_split_parts

            # Case 4: Line target split by Polygon cutter(s) (Inside vs Outside)
            elif target_geom_type == Qgis.GeometryType.Line and poly_hits:
                local_polys = poly_hits[0] if len(poly_hits) == 1 else QgsGeometry.unaryUnion(poly_hits)
                if len(poly_hits) > 1 and not local_polys.isGeosValid():
                    local_polys = local_polys.makeValid()

                l_inside = _extract_matching_geometry(
                    target_geom.intersection(local_polys), Qgis.GeometryType.Line
                )
                l_outside = _extract_matching_geometry(
                    target_geom.difference(local_polys), Qgis.GeometryType.Line
                )

                if not l_inside.isEmpty() and not l_outside.isEmpty():
                    split_parts = [l_inside, l_outside]

            # Apply splits if feature was divided into 2 or more pieces
            if len(split_parts) > 1:
                first_geom = split_parts[0]
                if is_multi_layer and not first_geom.isMultipart():
                    first_geom.convertToMultiType()
                if first_geom.isMultipart():
                    multi_result_count += 1
                geoms_to_change[fid] = first_geom

                for part_geom in split_parts[1:]:
                    new_feat = QgsFeature(target_feat)
                    if is_multi_layer and not part_geom.isMultipart():
                        part_geom.convertToMultiType()
                    if part_geom.isMultipart():
                        multi_result_count += 1
                    new_feat.setGeometry(part_geom)
                    for pk_idx in pk_indices:
                        new_feat.setAttribute(pk_idx, None)
                    features_to_add.append(new_feat)

                split_count += 1

        for fid, geom in geoms_to_change.items():
            target_layer.changeGeometry(fid, geom)
        if features_to_add:
            target_layer.addFeatures(features_to_add)

        target_layer.endEditCommand()
        target_layer.triggerRepaint()
    except Exception as e:
        target_layer.destroyEditCommand()
        _dismiss_progress(iface, progress_message)
        log_msg(f"Critical error during Split: {str(e)}", Qgis.Critical)
        iface.messageBar().pushMessage("QGIS Target", f"Split failed: {str(e)}", Qgis.Critical)
        return False
    else:
        _dismiss_progress(iface, progress_message)
        if split_count > 0:
            msg = f"Split completed: {split_count} feature(s) split into {split_count + len(features_to_add)} parts."
            log_msg(msg, Qgis.Success)
            iface.messageBar().pushMessage("QGIS Target", msg, Qgis.Success)
            _warn_if_singlepart_gpkg_multipart(iface, target_layer, multi_result_count)
        else:
            msg = "Split completed: No features were split. Ensure cutter lines completely cross the target features."
            log_msg(msg, Qgis.Warning)
            iface.messageBar().pushMessage("QGIS Target", msg, Qgis.Warning)
        return True
