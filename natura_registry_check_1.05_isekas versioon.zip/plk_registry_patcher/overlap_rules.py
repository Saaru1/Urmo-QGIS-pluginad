# overlap_rules.py

# A group of PLK codes where overlaps are strictly monitored
PLK_GROUP = {'1630', '4030', '5130', '6210', '6270', '6280', '6410', '6430', '6450', '6510', '6530', '7230', '9070'}

# Rule 1, 2, 5, 6, 7, 10, 11: Specific allowed overlaps
ALLOWED_PAIRS = [
    {'1130', '1110'}, {'1130', '1140'}, # Rule 1
    {'1160', '1110'}, {'1160', '1140'}, # Rule 2
    {'1640', '1210'},                   # Rule 5
    {'7150', '7110'},                   # Rule 6
    {'8240', '6280'}, {'8240', '5130'}, # Rule 7
    {'5130', '8210'},                   # Rule 10
    {'2130', '1210'}, {'2130', '1220'}  # Rule 11
]

def check_if_overlap_allowed(type1, type2):
    """Evaluates two habitat types against the official ecological rules."""
    if not type1 or not type2:
        return False 

    # Strip formatting for safe matching
    t1 = str(type1).strip().replace('*', '').replace(' ', '')
    t2 = str(type2).strip().replace('*', '').replace(' ', '')

    # Rule 12: General Rule, cannot overlap with itself
    if t1 == t2:
        return False

    pair = {t1, t2}

    # Rule 9: 3260 can overlap with everything
    if '3260' in pair: 
        return True

    # Rule 3: 1620 can overlap with everything EXCEPT 4030
    if '1620' in pair:
        if '4030' not in pair: return True

    # Rule 8: 3180 can overlap with all PLK EXCEPT 6270
    if '3180' in pair:
        other = list(pair - {'3180'})[0]
        if other in PLK_GROUP and other != '6270': return True

    # Direct Pair Matches
    if pair in ALLOWED_PAIRS: 
        return True

    # Rule 4: 1630 can overlap with a specific list
    r4_list = {'1210', '1310', '1110', '1130', '1140', '1150', '1160', '1170', '1220', '1230', '1640'}
    if '1630' in pair:
        other = list(pair - {'1630'})[0]
        if other in r4_list: return True

    # If it fails all rules, the overlap is an ERROR
    return False