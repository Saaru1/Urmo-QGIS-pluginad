import os
from qgis.PyQt.QtWidgets import QAction, QProgressDialog
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant, Qt, QCoreApplication
from qgis.core import (QgsProject, QgsFeatureRequest, QgsFeature, 
                       QgsField, QgsVectorLayer, NULL, QgsMessageLog, Qgis)

from .dialogs import RunParametersDialog, ResultsDialog
from .id_extractor import IDExtractor
from .wfs_handler import WFSDownloader
from .topology_checker import TopologyChecker
from .styler import LayerStyler

class PLKPatcherPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), "PLK Registry Patcher & QC", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        self.iface.addPluginToVectorMenu("PLK Patcher", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("PLK Patcher", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        dialog = RunParametersDialog(self.iface.mainWindow())
        if not dialog.exec():
            return

        layer_path = dialog.layer_widget.filePath()
        excel_path = dialog.file_widget.filePath()
        
        if not layer_path or not excel_path:
            self.iface.messageBar().pushWarning("PLK Patcher", "Both spatial layer and Excel files are required.")
            return

        max_gap = dialog.gap_input.value()
        min_section = dialog.section_input.value()
        min_angle = dialog.angle_input.value()
        noise_filter = dialog.noise_input.value() # --- Fetch the new UI parameter ---

        progress = QProgressDialog("Initializing...", "Cancel", 0, 100, self.iface.mainWindow())
        progress.setWindowTitle("PLK Patcher")
        progress.setModal(True)
        progress.setMinimumDuration(0)
        progress.show()

        def update_progress(value, text=None):
            if text:
                progress.setLabelText(text)
            progress.setValue(value)
            QCoreApplication.processEvents()
            return progress.wasCanceled()

        if update_progress(2, "Loading input files..."): return

        patch_layer = QgsVectorLayer(layer_path, "User Patches", "ogr")
        if not patch_layer.isValid():
            self.iface.messageBar().pushCritical("PLK Patcher", f"Failed to load spatial layer from: {layer_path}")
            return

        extractor = IDExtractor()
        raw_excel_data, raw_remove_ids = extractor.extract_ids(excel_path)
        
        if not raw_excel_data:
            self.iface.messageBar().pushCritical("PLK Patcher", "Could not extract valid IDs from the provided Excel/CSV file.")
            return

        # --- 1. Audit & Report Mismatches ---
        if update_progress(5, "Cross-referencing Excel and Layer IDs..."): return
        
        excel_ids = set()
        clean_excel_data = {}
        for raw_id, p_val in raw_excel_data.items():
            s = str(raw_id).strip()
            if s.endswith('.0'): s = s[:-2]
            if s: 
                excel_ids.add(s)
                clean_excel_data[s] = p_val

        ids_to_remove = set()
        for x in raw_remove_ids:
            s = str(x).strip()
            if s.endswith('.0'): s = s[:-2]
            if s: ids_to_remove.add(s)

        layer_ids = set()
        for feat in patch_layer.getFeatures():
            fid = self._get_id_string(feat)
            if fid: layer_ids.add(fid)

        missing_in_layer = excel_ids - layer_ids - ids_to_remove
        missing_in_excel = layer_ids - excel_ids

        if missing_in_layer or missing_in_excel:
            report_layer = QgsVectorLayer("None", "ID Mismatch Report", "memory")
            pr = report_layer.dataProvider()
            pr.addAttributes([QgsField("Issue", QVariant.String), QgsField("Feature_ID", QVariant.String)])
            report_layer.updateFields()
            
            report_feats = []
            for mid in missing_in_layer:
                f = QgsFeature(report_layer.fields())
                f.setAttributes(["Missing from Spatial Layer", mid])
                report_feats.append(f)
                
            for mid in missing_in_excel:
                f = QgsFeature(report_layer.fields())
                f.setAttributes(["Missing from Excel", mid])
                report_feats.append(f)
                
            if report_feats:
                pr.addFeatures(report_feats)
                QgsProject.instance().addMapLayer(report_layer)

        # --- 2. DOWNLOAD & PATCH ---
        if update_progress(10, "Initializing WFS download..."): return
        wfs_url = 'https://gsavalik.envir.ee/geoserver/eelis/ows?service=WFS&version=2.0.0&request=GetFeature&typeName=eelis:natura_elupaik&outputFormat=application/json'
        downloader = WFSDownloader(wfs_url)
        
        wfs_layer = downloader.get_clustered_wfs(patch_layer, update_progress)

        if progress.wasCanceled(): return
        if not wfs_layer:
            self.iface.messageBar().pushCritical("PLK Patcher", "WFS download failed or returned no features.")
            return
        
        patched_layer = self._patch_layer(wfs_layer, patch_layer, layer_ids, ids_to_remove, clean_excel_data, update_progress)
        if progress.wasCanceled(): return

        LayerStyler.apply_patch_style(patched_layer)
        QgsProject.instance().addMapLayer(patched_layer)

        # --- 3. TOPOLOGY CHECKS ---
        checker = TopologyChecker(patched_layer)
        # --- Pass the new parameter here ---
        results = checker.run_checks(max_gap, min_section, min_angle, noise_filter, update_progress)
        if progress.wasCanceled(): return

        progress.setValue(100)

        error_counts = {name: layer.featureCount() for name, layer in results.items()}

        res_dialog = ResultsDialog(error_counts, self.iface.mainWindow())
        if res_dialog.exec():
            selected = res_dialog.get_selected_layers()
            LayerStyler.apply_error_styles(results)
            for err_type in selected:
                QgsProject.instance().addMapLayer(results[err_type])

        self.iface.messageBar().pushSuccess("PLK Patcher", "Process completed successfully.")

    def _get_id_string(self, feat):
        valid_exact = ['id', 'jrknr', 'idjrknr', 'idjärjekorranumber', 'idvoijrjknr', 'tunnus', 'kood', 'nr', 'field1']
        for field in feat.fields():
            cname = str(field.name()).lower().replace('_', '').replace(' ', '').replace('/', '')
            if cname in valid_exact:
                val = feat.attribute(field.name())
                if val is not None:
                    s = str(val).strip()
                    if s.lower() != 'null' and s:
                        if s.endswith('.0'): s = s[:-2]
                        return s
        if feat.fields().count() > 0:
            val = feat.attribute(0)
            if val is not None:
                s = str(val).strip()
                if s.lower() != 'null' and s:
                    if s.endswith('.0'): s = s[:-2]
                    return s
        return str(feat.id())

    def _get_pohityyp_string(self, feat):
        keywords = ['pohityyp', 'põhityyp', 'põhityüp', 'elupaigatuubikood', 'elupaigatüübikood', 'naturakood']
        for field in feat.fields():
            cname = str(field.name()).lower().replace('_', '').replace(' ', '').replace('/', '').replace('(', '').replace(')', '')
            if any(kw in cname for kw in keywords):
                val = feat.attribute(field.name())
                if val is not None:
                    s = str(val).strip()
                    if s.lower() != 'null' and s:
                        if s.endswith('.0'): s = s[:-2]
                        return s
        return ""

    def _patch_layer(self, wfs_layer, patch_layer, layer_ids, ids_to_remove, excel_data, progress_cb=None):
        crs = wfs_layer.crs().authid()
        clean_layer = QgsVectorLayer(f"MultiPolygon?crs={crs}", "Patched Registry Extract", "memory")
        pr = clean_layer.dataProvider()

        pr.addAttributes([
            QgsField("ID", QVariant.String),
            QgsField("Allikas", QVariant.String),
            QgsField("Pohityyp", QVariant.String)
        ])
        clean_layer.updateFields()

        new_features = []

        if progress_cb:
            if progress_cb(35, "Building clean layer: Extracting WFS attributes..."): return None

        wfs_pohityyp_map = {}
        for feat in wfs_layer.getFeatures():
            wfs_id = self._get_id_string(feat)
            wfs_pohityyp_map[wfs_id] = self._get_pohityyp_string(feat)

        if progress_cb:
            if progress_cb(40, "Building clean layer: Adding WFS Base (Naabrid)..."): return None

        for feat in wfs_layer.getFeatures():
            wfs_id = self._get_id_string(feat)
            if wfs_id not in layer_ids and wfs_id not in ids_to_remove:
                new_feat = QgsFeature(clean_layer.fields())
                if feat.hasGeometry():
                    geom = feat.geometry()
                    geom.convertToMultiType()
                    new_feat.setGeometry(geom)
                
                new_feat.setAttribute("ID", wfs_id)
                new_feat.setAttribute("Allikas", "Naabrid")
                new_feat.setAttribute("Pohityyp", wfs_pohityyp_map.get(wfs_id, ""))
                new_features.append(new_feat)

        total_patches = patch_layer.featureCount()
        for idx, feat in enumerate(patch_layer.getFeatures()):
            if progress_cb and idx % 20 == 0:
                if progress_cb(45 + int((idx/total_patches)*15), "Building clean layer: Inserting User Patches..."): return None
                
            user_id = self._get_id_string(feat)
            new_feat = QgsFeature(clean_layer.fields())
            
            if feat.hasGeometry():
                geom = feat.geometry()
                geom.convertToMultiType()
                new_feat.setGeometry(geom)
                
            new_feat.setAttribute("ID", user_id)
            new_feat.setAttribute("Allikas", "Sinu parandused")
            
            if user_id in wfs_pohityyp_map and wfs_pohityyp_map[user_id]:
                new_feat.setAttribute("Pohityyp", wfs_pohityyp_map[user_id])
            elif user_id in excel_data and excel_data[user_id]:
                new_feat.setAttribute("Pohityyp", excel_data[user_id])
            else:
                new_feat.setAttribute("Pohityyp", self._get_pohityyp_string(feat))
                
            new_features.append(new_feat)

        pr.addFeatures(new_features)
        clean_layer.commitChanges()
        
        return clean_layer