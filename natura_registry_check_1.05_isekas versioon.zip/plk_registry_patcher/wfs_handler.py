import requests
import tempfile
from qgis.core import QgsVectorLayer, QgsGeometry, QgsMessageLog, Qgis

class WFSDownloader:
    def __init__(self, wfs_url):
        self.wfs_url = wfs_url

    def get_clustered_wfs(self, mask_layer, progress_cb=None):
        mask_geoms = []
        for feat in mask_layer.getFeatures():
            if feat.hasGeometry():
                geom = feat.geometry()
                if not geom.isGeosValid():
                    geom = geom.makeValid()
                mask_geoms.append(geom)
        
        if not mask_geoms:
            return None

        bbox_geoms = [QgsGeometry.fromRect(g.boundingBox()) for g in mask_geoms]
        merged_bboxes = QgsGeometry.unaryUnion(bbox_geoms)
        parts = merged_bboxes.asGeometryCollection() if merged_bboxes.isMultipart() else [merged_bboxes]

        mask_union = QgsGeometry.unaryUnion(mask_geoms)
        if not mask_union or mask_union.isEmpty():
            mask_union = QgsGeometry.collectGeometry(mask_geoms)

        all_features = []
        seen_wkt = set() # CRITICAL FIX: Memory bank for deduplication
        
        for idx, part in enumerate(parts):
            if progress_cb:
                # Track progress from 10% to 40%
                prog_val = 10 + int((idx / len(parts)) * 30)
                if progress_cb(prog_val, f"Downloading WFS cluster {idx+1} of {len(parts)}..."):
                    return None # User canceled
            
            extent = part.boundingBox()
            bbox_str = f"{extent.xMinimum()},{extent.yMinimum()},{extent.xMaximum()},{extent.yMaximum()}"
            request_url = f"{self.wfs_url}&srsName=EPSG:3301&bbox={bbox_str},EPSG:3301"
            
            try:
                response = requests.get(request_url, timeout=60)
                if response.status_code == 200:
                    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".geojson")
                    with open(temp_file.name, 'w', encoding='utf-8') as f:
                        f.write(response.text)
                    
                    temp_layer = QgsVectorLayer(temp_file.name, "temp", "ogr")
                    
                    for feat in temp_layer.getFeatures():
                        if feat.hasGeometry():
                            wfs_geom = feat.geometry()
                            if not wfs_geom.isGeosValid():
                                wfs_geom = wfs_geom.makeValid()
                            
                            if wfs_geom.intersects(mask_union):
                                # Deduplication Check: Only add if we haven't seen this exact shape yet
                                wkt = wfs_geom.asWkt()
                                if wkt not in seen_wkt:
                                    seen_wkt.add(wkt)
                                    all_features.append(feat)
            except Exception as e:
                continue

        mem_layer = QgsVectorLayer("MultiPolygon?crs=EPSG:3301", "WFS_Extract", "memory")
        pr = mem_layer.dataProvider()
        if all_features:
            pr.addAttributes(all_features[0].fields())
            mem_layer.updateFields()
            
            multi_feats = []
            for f in all_features:
                if f.hasGeometry():
                    geom = f.geometry()
                    geom.convertToMultiType()
                    f.setGeometry(geom)
                    multi_feats.append(f)
                    
            pr.addFeatures(multi_feats)
            
        return mem_layer