from qgis.core import (QgsSingleSymbolRenderer, QgsFillSymbol, QgsLineSymbol, 
                       QgsMarkerSymbol, QgsRuleBasedRenderer, QgsMarkerLineSymbolLayer)

class LayerStyler:
    @staticmethod
    def apply_patch_style(layer):
        symbol_wfs = QgsFillSymbol.createSimple({'color': '255,255,0,190', 'outline_color': 'black'})
        symbol_patch = QgsFillSymbol.createSimple({'color': '0,255,255,190', 'outline_color': 'black'})
        
        root_rule = QgsRuleBasedRenderer.Rule(None)
        
        # Updated to filter based on the new "Allikas" string column
        wfs_rule = QgsRuleBasedRenderer.Rule(symbol_wfs, 0, 0, filterExp='"Allikas" = \'Naabrid\'', label='Naabrid (WFS Base)')
        patch_rule = QgsRuleBasedRenderer.Rule(symbol_patch, 0, 0, filterExp='"Allikas" = \'Sinu parandused\'', label='Sinu parandused (User Patch)')
        
        root_rule.appendChild(wfs_rule)
        root_rule.appendChild(patch_rule)
        
        layer.setRenderer(QgsRuleBasedRenderer(root_rule))
        layer.triggerRepaint()

    @staticmethod
    def apply_error_styles(results_dict):
        if 'overlaps' in results_dict:
            sym = QgsFillSymbol.createSimple({'color': '255,165,0,255', 'outline_style': 'no'})
            results_dict['overlaps'].setRenderer(QgsSingleSymbolRenderer(sym))

        if 'gaps' in results_dict:
            sym = QgsFillSymbol.createSimple({'color': '0,0,139,255', 'outline_style': 'no'})
            results_dict['gaps'].setRenderer(QgsSingleSymbolRenderer(sym))

        if 'self_intersections' in results_dict:
            sym = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': 'red', 'size': '4'})
            results_dict['self_intersections'].setRenderer(QgsSingleSymbolRenderer(sym))

        if 'short_sections' in results_dict:
            # 1. Create the purple line
            sym = QgsLineSymbol.createSimple({'line_color': '128,0,128,255', 'line_width': '1'})
            
            # 2. Create the black circle markers for the endpoints
            marker_layer = QgsMarkerLineSymbolLayer.create({'placement': 'firstvertex,lastvertex'})
            marker_sym = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': 'black', 'outline_color': 'black', 'size': '2'})
            marker_layer.setSubSymbol(marker_sym)
            
            # 3. Add the markers to the line symbol
            sym.appendSymbolLayer(marker_layer)
            results_dict['short_sections'].setRenderer(QgsSingleSymbolRenderer(sym))

        if 'angles' in results_dict:
            sym = QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': '80,80,80,255', 'size': '4', 'angle': '180'})
            results_dict['angles'].setRenderer(QgsSingleSymbolRenderer(sym))