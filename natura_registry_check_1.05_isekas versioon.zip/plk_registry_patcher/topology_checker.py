import math
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, 
                       QgsSpatialIndex, QgsWkbTypes, QgsField, QgsMessageLog, Qgis)

try:
    from . import overlap_rules
except ImportError:
    QgsMessageLog.logMessage("overlap_rules.py not found! All overlaps will be flagged.", "PLK Patcher", Qgis.Warning)
    overlap_rules = None

class TopologyChecker:
    def __init__(self, layer):
        self.layer = layer

    def _get_id(self, feat):
        for field in feat.fields():
            if field.name().lower() == 'id':
                val = feat.attribute(field.name())
                return str(val) if val else str(feat.id())
        return str(feat.id())

    def _is_patch(self, feat):
        idx = feat.fields().indexOf("Allikas")
        if idx != -1:
            val = feat.attribute(idx)
            if val and "Sinu parandused" in str(val):
                return True
        return False

    def _get_pohityyp(self, feat):
        idx = feat.fields().indexOf("Pohityyp")
        if idx != -1:
            val = feat.attribute(idx)
            return str(val).strip() if val else ""
        return ""

    def _is_overlap_allowed(self, type1, type2):
        if not type1 or not type2:
            return False
            
        if overlap_rules and hasattr(overlap_rules, 'check_if_overlap_allowed'):
            return overlap_rules.check_if_overlap_allowed(type1, type2)
            
        return False

    # --- ADDED noise_filter_m2 parameter ---
    def run_checks(self, max_gap_ha, min_section_mm, min_angle_deg, noise_filter_m2, progress_cb=None):
        results = {}
        
        overlaps_layer = QgsVectorLayer("Polygon?crs=EPSG:3301", "Overlaps", "memory")
        gaps_layer = QgsVectorLayer("Polygon?crs=EPSG:3301", "Gaps", "memory")
        self_ints_layer = QgsVectorLayer("Point?crs=EPSG:3301", "Self Intersections", "memory")
        sections_layer = QgsVectorLayer("LineString?crs=EPSG:3301", "Short Sections", "memory")
        angles_layer = QgsVectorLayer("Point?crs=EPSG:3301", "Sharp Angles", "memory")
        
        ov_pr = overlaps_layer.dataProvider()
        gap_pr = gaps_layer.dataProvider()
        si_pr = self_ints_layer.dataProvider()
        sec_pr = sections_layer.dataProvider()
        ang_pr = angles_layer.dataProvider()

        ov_pr.addAttributes([QgsField("err_id", QVariant.Int), QgsField("area_m2", QVariant.Double), QgsField("feat_ids", QVariant.String)])
        overlaps_layer.updateFields()
        
        gap_pr.addAttributes([QgsField("err_id", QVariant.Int), QgsField("area_m2", QVariant.Double), QgsField("feat_ids", QVariant.String)])
        gaps_layer.updateFields()
        
        si_pr.addAttributes([QgsField("feat_id", QVariant.String)])
        self_ints_layer.updateFields()
        
        sec_pr.addAttributes([QgsField("err_id", QVariant.Int), QgsField("length_m", QVariant.Double), QgsField("feat_id", QVariant.String)])
        sections_layer.updateFields()
        
        ang_pr.addAttributes([QgsField("feat_id", QVariant.String), QgsField("angle_deg", QVariant.Double)])
        angles_layer.updateFields()

        max_gap_m2 = max_gap_ha * 10000
        min_section_m = min_section_mm / 1000.0

        all_features = list(self.layer.getFeatures())
        
        ov_id_counter = 1
        gap_id_counter = 1
        sec_id_counter = 1

        if progress_cb and progress_cb(60, "Running topology checks: Preparing geometries..."): return {}
        
        valid_geoms = []
        valid_feats = [] 
        index = QgsSpatialIndex()
        
        for f in all_features:
            if f.hasGeometry():
                geom = f.geometry()
                if not geom.isGeosValid():
                    geom = geom.makeValid()
                
                if geom and not geom.isEmpty() and geom.type() == QgsWkbTypes.PolygonGeometry:
                    valid_geoms.append(geom)
                    valid_feats.append(f)
        
        for idx, geom in enumerate(valid_geoms):
            dummy_f = QgsFeature()
            dummy_f.setId(idx)
            dummy_f.setGeometry(geom)
            index.addFeature(dummy_f)

        if progress_cb and progress_cb(70, "Running topology checks: Detecting overlaps..."): return {}
        
        checked_pairs = set()
        for idx1, geom1 in enumerate(valid_geoms):
            f1_is_patch = self._is_patch(valid_feats[idx1])
            f1_type = self._get_pohityyp(valid_feats[idx1])
            
            candidates = index.intersects(geom1.boundingBox())
            for idx2 in candidates:
                if idx1 == idx2: continue 
                
                f2_is_patch = self._is_patch(valid_feats[idx2])
                if not f1_is_patch and not f2_is_patch:
                    continue
                    
                pair = tuple(sorted([idx1, idx2]))
                if pair in checked_pairs: continue
                checked_pairs.add(pair)
                
                f2_type = self._get_pohityyp(valid_feats[idx2])
                if self._is_overlap_allowed(f1_type, f2_type):
                    continue 
                
                geom2 = valid_geoms[idx2]
                if geom1.intersects(geom2):
                    intersection = geom1.intersection(geom2)
                    if intersection and not intersection.isEmpty():
                        parts = intersection.asGeometryCollection() if intersection.isMultipart() else [intersection]
                        for part in parts:
                            if part.type() == QgsWkbTypes.PolygonGeometry:
                                area = part.area()
                                # --- Now using the dynamic parameter ---
                                if area >= noise_filter_m2:
                                    out_feat = QgsFeature(overlaps_layer.fields())
                                    out_feat.setGeometry(part)
                                    
                                    f1_id = self._get_id(valid_feats[idx1])
                                    f2_id = self._get_id(valid_feats[idx2])
                                    
                                    out_feat.setAttributes([ov_id_counter, round(area, 2), f"{f1_id};{f2_id}"])
                                    ov_pr.addFeatures([out_feat])
                                    ov_id_counter += 1

        if progress_cb and progress_cb(80, "Running topology checks: Finding gaps..."): return {}
        
        if valid_geoms:
            union_geom = QgsGeometry.unaryUnion(valid_geoms)
            if union_geom and not union_geom.isEmpty() and union_geom.type() == QgsWkbTypes.PolygonGeometry:
                filled_geoms = []
                
                parts = union_geom.asGeometryCollection() if union_geom.isMultipart() else [union_geom]
                for part in parts:
                    poly = part.asPolygon()
                    if poly and len(poly) > 0:
                        filled_geom = QgsGeometry.fromPolygonXY([poly[0]])
                        if filled_geom and not filled_geom.isEmpty():
                            filled_geoms.append(filled_geom)
                
                if filled_geoms:
                    filled_union = QgsGeometry.unaryUnion(filled_geoms)
                    if filled_union and not filled_union.isEmpty():
                        gaps_geom = filled_union.difference(union_geom)
                        
                        if gaps_geom and not gaps_geom.isEmpty() and gaps_geom.type() == QgsWkbTypes.PolygonGeometry:
                            gap_parts = gaps_geom.asGeometryCollection() if gaps_geom.isMultipart() else [gaps_geom]
                            for part in gap_parts:
                                area = part.area()
                                # --- Now using the dynamic parameter ---
                                if noise_filter_m2 <= area <= max_gap_m2:
                                    bordering_ids = set()
                                    touches_user_patch = False
                                    
                                    cand_idxs = index.intersects(part.boundingBox())
                                    for c_idx in cand_idxs:
                                        if valid_geoms[c_idx].intersects(part):
                                            bordering_ids.add(self._get_id(valid_feats[c_idx]))
                                            if self._is_patch(valid_feats[c_idx]):
                                                touches_user_patch = True
                                    
                                    if not touches_user_patch:
                                        continue
                                        
                                    out_feat = QgsFeature(gaps_layer.fields())
                                    out_feat.setGeometry(part)
                                    out_feat.setAttributes([gap_id_counter, round(area, 2), ";".join(sorted(bordering_ids))])
                                    gap_pr.addFeatures([out_feat])
                                    gap_id_counter += 1

        if progress_cb and progress_cb(90, "Running topology checks: Verifying geometry constraints..."): return {}
        
        for f in all_features:
            if not self._is_patch(f):
                continue
                
            geom = f.geometry()
            if not geom: continue
            
            f_id = self._get_id(f)
            
            errors = geom.validateGeometry()
            for err in errors:
                if "intersect" in err.what().lower():
                    out_feat = QgsFeature(self_ints_layer.fields())
                    out_feat.setGeometry(QgsGeometry.fromPointXY(err.where()))
                    out_feat.setAttributes([f_id])
                    si_pr.addFeatures([out_feat])

            if geom.type() == QgsWkbTypes.PolygonGeometry:
                polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
                for poly in polys:
                    for pts in poly:
                        for i in range(len(pts) - 1):
                            p1, p2 = pts[i], pts[i+1]
                            dist = math.sqrt((p2.x() - p1.x())**2 + (p2.y() - p1.y())**2)
                            if 0 < dist < min_section_m:
                                out_feat = QgsFeature(sections_layer.fields())
                                out_feat.setGeometry(QgsGeometry.fromPolylineXY([p1, p2]))
                                out_feat.setAttributes([sec_id_counter, round(dist, 2), f_id])
                                sec_pr.addFeatures([out_feat])
                                sec_id_counter += 1
                                
                        for i in range(len(pts) - 2):
                            p1, p2, p3 = pts[i], pts[i+1], pts[i+2]
                            ang = self._calc_angle(p1, p2, p3)
                            if ang < min_angle_deg:
                                out_feat = QgsFeature(angles_layer.fields())
                                out_feat.setGeometry(QgsGeometry.fromPointXY(p2))
                                out_feat.setAttributes([f_id, round(ang, 2)])
                                ang_pr.addFeatures([out_feat])

        results['overlaps'] = overlaps_layer
        results['self_intersections'] = self_ints_layer
        results['gaps'] = gaps_layer
        results['short_sections'] = sections_layer
        results['angles'] = angles_layer

        return results

    def _calc_angle(self, p1, p2, p3):
        ang1 = math.atan2(p1.y() - p2.y(), p1.x() - p2.x())
        ang2 = math.atan2(p3.y() - p2.y(), p3.x() - p2.x())
        deg = math.degrees(ang1 - ang2) % 360
        if deg > 180: deg = 360 - deg
        return deg