from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QPushButton, QFormLayout, QDoubleSpinBox, QCheckBox
from qgis.gui import QgsFileWidget

class RunParametersDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("PLK Patcher Inputs & Tolerances")
        layout = QFormLayout(self)
        self.setMinimumWidth(450)
        
        # File widget for spatial layer (prioritizing .tab and .gpkg)
        self.layer_widget = QgsFileWidget()
        self.layer_widget.setFilter("Vector Files (*.tab *.gpkg *.geojson);;All Files (*.*)")
        
        # File widget for Excel/CSV
        self.file_widget = QgsFileWidget()
        self.file_widget.setFilter("Excel or CSV Files (*.xlsx *.xls *.csv *.xlsm)")
        
        self.gap_input = QDoubleSpinBox()
        self.gap_input.setDecimals(3)
        self.gap_input.setValue(0.01)
        self.gap_input.setSingleStep(0.01)
        
        self.section_input = QDoubleSpinBox()
        self.section_input.setValue(20.0)
        
        self.angle_input = QDoubleSpinBox()
        self.angle_input.setValue(5.0)

        # --- Noise Filter Input ---
        self.noise_input = QDoubleSpinBox()
        self.noise_input.setDecimals(4)
        # Set to the MapInfo sweet spot!
        self.noise_input.setValue(0.0025) 
        self.noise_input.setSingleStep(0.001)
        
        layout.addRow("User Patch Layer File:", self.layer_widget)
        layout.addRow("Excel/CSV Patch File:", self.file_widget)
        layout.addRow("Maximum Gap Area (ha):", self.gap_input)
        layout.addRow("Min Section (mm):", self.section_input)
        layout.addRow("Min Angle (deg):", self.angle_input)
        layout.addRow("Noise Filter Area (m²):", self.noise_input)
        
        self.btn_run = QPushButton("Start Processing")
        self.btn_run.clicked.connect(self.accept)
        layout.addRow(self.btn_run)


class ResultsDialog(QDialog):
    def __init__(self, error_counts, parent=None):
        super().__init__(parent)
        self.setWindowTitle("QC Results")
        self.layout = QVBoxLayout(self)
        self.checkboxes = {}
        
        total_errors = sum(error_counts.values())
        
        for err_type, count in error_counts.items():
            chk = QCheckBox(f"{err_type.replace('_', ' ').title()} ({count} found)")
            chk.setEnabled(count > 0)
            chk.setChecked(count > 0)
            self.checkboxes[err_type] = chk
            self.layout.addWidget(chk)
            
        self.btn_show = QPushButton("Add Selected to Map")
        self.btn_show.setEnabled(total_errors > 0)
        self.btn_show.clicked.connect(self.accept)
        self.layout.addWidget(self.btn_show)
        
    def get_selected_layers(self):
        return [k for k, v in self.checkboxes.items() if v.isChecked()]