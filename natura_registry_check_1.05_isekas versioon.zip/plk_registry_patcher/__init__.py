def classFactory(iface):
    from .main_plugin import PLKPatcherPlugin
    return PLKPatcherPlugin(iface)