import os
import csv
import re
from qgis.core import QgsMessageLog, Qgis

class IDExtractor:
    def extract_ids(self, file_path):
        if not file_path or not os.path.exists(file_path):
            return {}, []

        ext = os.path.splitext(file_path)[1].lower()
        extracted_data = {} # Now a dictionary: {id: pohityyp}
        ids_to_remove = set()

        try:
            if ext == '.csv':
                extracted_data, ids_to_remove = self._read_csv(file_path)
            elif ext in ['.xlsx', '.xls', '.xlsm']:
                extracted_data, ids_to_remove = self._read_excel(file_path)
            else:
                QgsMessageLog.logMessage(f"Unsupported file format: {ext}", "PLK Patcher", Qgis.Warning)
        except Exception as e:
            QgsMessageLog.logMessage(f"Error reading {file_path}: {str(e)}", "PLK Patcher", Qgis.Critical)

        return extracted_data, list(ids_to_remove)

    def _clean_val(self, val):
        """Safely cleans values, explicitly catching Pandas NaN artifacts"""
        if val is None: return None
        
        # Catch pure math NaN just in case
        import math
        if isinstance(val, float) and math.isnan(val): return None
        
        s = str(val).strip()
        # Catch string representations of empty cells from pandas
        if s.lower() in ['null', 'nan', '<na>', ''] or not s: return None
        if s.endswith('.0'): s = s[:-2]
        return s

    def _is_id_column(self, col_name):
        if not col_name: return False
        
        # Strip ALL whitespace (including \n, \r, \t) and common separators
        cname = re.sub(r'[\s_/\-\n\r]+', '', str(col_name).lower())
        
        valid_exact = [
            'id', 'jrknr', 'idjrknr', 'idjärjekorranumber', 
            'idvoijrjknr', 'tunnus', 'kood', 'nr', 'field1'
        ]
        return cname in valid_exact or cname.startswith('id')

    def _is_klassif_column(self, col_name):
        if not col_name: return False
        
        cname = re.sub(r'[\s_/\-\n\r]+', '', str(col_name).lower())
        return 'parandus' in cname and 'klassif' in cname

    def _is_pohityyp_column(self, col_name):
        """Hunts for the specific pohityyp headers robustly."""
        if not col_name: return False
        
        # Strip whitespace, separators, AND parentheses for Natura codes
        cname = re.sub(r'[\s_/\-\n\r()]+', '', str(col_name).lower())
        
        valid_exact = [
            "elupaigatüübikoodnaturakood", 
            "elupaigatuubikoodnaturakood",
            "elupaiknatura", 
            "pohityypkood", 
            "põhityypkood",
            "pohityyp",
            "põhityyp"
        ]
        
        return cname in valid_exact or cname.startswith('pohityyp') or cname.startswith('põhityyp')

    def _read_csv(self, file_path):
        extracted_data = {}
        remove_ids = set()
        encodings = ['utf-8', 'utf-8-sig', 'windows-1257', 'latin1']
        delimiters = [';', ',', '\t']
        
        for enc in encodings:
            for delim in delimiters:
                try:
                    with open(file_path, 'r', encoding=enc) as f:
                        reader = csv.DictReader(f, delimiter=delim)
                        if not reader.fieldnames: continue
                        
                        id_fields = [fn for fn in reader.fieldnames if self._is_id_column(fn)]
                        klassif_fields = [fn for fn in reader.fieldnames if self._is_klassif_column(fn)]
                        pohityyp_fields = [fn for fn in reader.fieldnames if self._is_pohityyp_column(fn)]
                        
                        if not id_fields: continue
                        
                        for row in reader:
                            is_o = False
                            for k_field in klassif_fields:
                                k_val = self._clean_val(row[k_field])
                                if k_val and str(k_val).upper() == 'O':
                                    is_o = True
                                    break
                                    
                            # Extract pohityyp if available
                            p_val = ""
                            for p_field in pohityyp_fields:
                                v = self._clean_val(row[p_field])
                                if v:
                                    p_val = v
                                    break
                                    
                            for field in id_fields:
                                val = self._clean_val(row[field])
                                if val:
                                    extracted_data[val] = p_val
                                    if is_o:
                                        remove_ids.add(val)
                    if extracted_data: return extracted_data, remove_ids
                except:
                    pass
        return extracted_data, remove_ids

    def _read_excel(self, file_path):
        """
        Reads Excel files natively using QGIS's GDAL/OGR engine.
        This completely bypasses pandas/openpyxl and avoids libxml2 C-extension crashes.
        """
        extracted_data = {}
        remove_ids = set()
        
        try:
            from osgeo import ogr
            ds = ogr.Open(file_path)
            
            if not ds:
                raise Exception("OGR could not open the Excel file natively.")
                
            for i in range(ds.GetLayerCount()):
                layer = ds.GetLayerByIndex(i)
                layer.ResetReading()
                
                layer_defn = layer.GetLayerDefn()
                field_count = layer_defn.GetFieldCount()
                
                # Treat OGR's default header row as our first data row
                field_names = [layer_defn.GetFieldDefn(j).GetName() for j in range(field_count)]
                all_rows = [field_names]
                
                # Read all features into string rows
                for feat in layer:
                    row_data = []
                    for j in range(field_count):
                        row_data.append(feat.GetFieldAsString(j))
                    all_rows.append(row_data)
                    
                # Scan to find the true header row
                header_row_idx = -1
                max_scan = min(10, len(all_rows))
                
                for row_idx in range(max_scan):
                    for cell_value in all_rows[row_idx]:
                        if self._is_id_column(cell_value):
                            header_row_idx = row_idx
                            break
                    if header_row_idx != -1:
                        break
                        
                if header_row_idx == -1:
                    continue
                    
                header_row = all_rows[header_row_idx]
                id_cols = [c for c, val in enumerate(header_row) if self._is_id_column(val)]
                klassif_cols = [c for c, val in enumerate(header_row) if self._is_klassif_column(val)]
                pohityyp_cols = [c for c, val in enumerate(header_row) if self._is_pohityyp_column(val)]
                
                # Extract data below header
                for row_idx in range(header_row_idx + 1, len(all_rows)):
                    row = all_rows[row_idx]
                    row_ids = []
                    
                    p_val = ""
                    for p_col in pohityyp_cols:
                        if p_col < len(row):
                            v = self._clean_val(row[p_col])
                            if v:
                                p_val = v
                                break
                    
                    for c in id_cols:
                        if c < len(row):
                            clean_id = self._clean_val(row[c])
                            if clean_id:
                                extracted_data[clean_id] = p_val
                                row_ids.append(clean_id)
                                
                    is_o = False
                    for k_col in klassif_cols:
                        if k_col < len(row):
                            k_val = self._clean_val(row[k_col])
                            if k_val and str(k_val).upper() == 'O':
                                is_o = True
                                break
                                
                    if is_o:
                        for rid in row_ids:
                            remove_ids.add(rid)

            return extracted_data, remove_ids

        except Exception as e:
            QgsMessageLog.logMessage(f"OGR Excel read failed: {str(e)}. Falling back to Pandas.", "PLK Patcher", Qgis.Warning)
            return self._read_excel_pandas(file_path)

    def _read_excel_pandas(self, file_path):
        """Fallback method in case OGR is unavailable."""
        extracted_data = {}
        remove_ids = set()
        
        import os
        os.environ['OPENPYXL_LXML'] = 'False'
        
        try:
            import pandas as pd
            xls = pd.ExcelFile(file_path)
            
            for sheet_name in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet_name, header=None, dtype=str)
                
                header_row_idx = -1
                max_scan = min(10, len(df))
                for i in range(max_scan):
                    for val in df.iloc[i]:
                        if self._is_id_column(val):
                            header_row_idx = i
                            break
                    if header_row_idx != -1:
                        break
                
                if header_row_idx == -1: continue
                
                headers = df.iloc[header_row_idx]
                id_cols = [c for c in range(len(headers)) if self._is_id_column(headers[c])]
                klassif_cols = [c for c in range(len(headers)) if self._is_klassif_column(headers[c])]
                pohityyp_cols = [c for c in range(len(headers)) if self._is_pohityyp_column(headers[c])]
                
                for idx in range(header_row_idx + 1, len(df)):
                    row = df.iloc[idx]
                    row_ids = []
                    
                    p_val = ""
                    for p_col in pohityyp_cols:
                        v = self._clean_val(row[p_col])
                        if v:
                            p_val = v
                            break
                    
                    for c in id_cols:
                        clean_id = self._clean_val(row[c])
                        if clean_id:
                            extracted_data[clean_id] = p_val
                            row_ids.append(clean_id)
                    
                    is_o = False
                    for k_col in klassif_cols:
                        k_val = self._clean_val(row[k_col])
                        if k_val and str(k_val).upper() == 'O':
                            is_o = True
                            break
                    
                    if is_o:
                        for rid in row_ids:
                            remove_ids.add(rid)

        except ImportError:
            QgsMessageLog.logMessage("Pandas not available, using openpyxl fallback.", "PLK Patcher", Qgis.Info)
            try:
                import openpyxl
                wb = openpyxl.load_workbook(file_path, data_only=True, read_only=True)
                for sheet_name in wb.sheetnames:
                    ws = wb[sheet_name]
                    
                    headers_id = {}
                    klassif_indices = []
                    pohityyp_indices = []
                    header_row_idx = -1
                    
                    all_rows = list(ws.iter_rows(values_only=True))
                    max_scan = min(10, len(all_rows))
                    
                    for row_idx in range(max_scan):
                        for col_idx, cell_value in enumerate(all_rows[row_idx]):
                            if self._is_id_column(cell_value):
                                header_row_idx = row_idx
                                break
                        if header_row_idx != -1: break
                            
                    if header_row_idx == -1: continue
                        
                    header_row = all_rows[header_row_idx]
                    for col_idx, cell_value in enumerate(header_row):
                        if self._is_id_column(cell_value):
                            headers_id[col_idx] = cell_value
                        elif self._is_klassif_column(cell_value):
                            klassif_indices.append(col_idx)
                        elif self._is_pohityyp_column(cell_value):
                            pohityyp_indices.append(col_idx)
                    
                    for row_idx in range(header_row_idx + 1, len(all_rows)):
                        row = all_rows[row_idx]
                        
                        is_o = False
                        for k_idx in klassif_indices:
                            if k_idx < len(row):
                                k_val = self._clean_val(row[k_idx])
                                if k_val and str(k_val).upper() == 'O':
                                    is_o = True
                                    break
                                    
                        p_val = ""
                        for p_idx in pohityyp_indices:
                            if p_idx < len(row):
                                v = self._clean_val(row[p_idx])
                                if v:
                                    p_val = v
                                    break
                        
                        for col_idx in headers_id:
                            if col_idx < len(row):
                                clean_id = self._clean_val(row[col_idx])
                                if clean_id:
                                    extracted_data[clean_id] = p_val
                                    if is_o: remove_ids.add(clean_id)
            except Exception as e:
                QgsMessageLog.logMessage(f"Excel read failed: {str(e)}", "PLK Patcher", Qgis.Critical)

        return extracted_data, remove_ids