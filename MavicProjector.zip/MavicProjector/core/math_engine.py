import cv2
import math
import numpy as np
from math import radians, cos, sin, degrees, atan2
from qgis.core import QgsProject, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsCoordinateTransformContext
from ..compat_drone import IdentifyFormatValue

class MathEngine:
    # ADD transform_context=None to the arguments
    def __init__(self, telemetry, geoid_offset, yaw_offset, pitch_offset, transform_context=None):
        self.tel = telemetry
        self.camera_matrix = telemetry['camera_matrix']
        self.dist_coeffs = telemetry['dist_coeffs']
        
        self.crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        self.crs_est = QgsCoordinateReferenceSystem("EPSG:3301")
        
        # FIX: Use the provided thread-safe context. 
        # If none is provided (e.g., running directly in the main UI), fetch it safely.
        if transform_context is None:
            transform_context = QgsProject.instance().transformContext()
            
        self.transform = QgsCoordinateTransform(self.crs_wgs84, self.crs_est, transform_context)
        
        self.grid_yaw_raw = self.tel['yaw'] + self.get_grid_convergence()
        self.grid_yaw = self.grid_yaw_raw + yaw_offset
        self.grid_pitch = self.tel['pitch'] + pitch_offset
        
        drone_pt = QgsPointXY(self.tel['lon'], self.tel['lat'])
        drone_est = self.transform.transform(drone_pt)
        self.drone_pos = np.array([drone_est.x(), drone_est.y(), self.tel['rtk_alt'] + geoid_offset])
        
        self.rvec = self.create_rvec(self.grid_yaw, self.grid_pitch, self.tel['roll'])
        self.R_cam, _ = cv2.Rodrigues(self.rvec)

    def get_grid_convergence(self):
        p_drone = QgsPointXY(self.tel['lon'], self.tel['lat'])
        p_north = QgsPointXY(self.tel['lon'], self.tel['lat'] + 0.01) 
        d_est = self.transform.transform(p_drone)
        n_est = self.transform.transform(p_north)
        dx = n_est.x() - d_est.x()
        dy = n_est.y() - d_est.y()
        return degrees(atan2(dx, dy))

    def create_rvec(self, yaw, pitch, roll):
        y, p, r = radians(yaw), radians(pitch), radians(roll)
        R_roll_c2w = np.array([[cos(r), -sin(r), 0], [sin(r), cos(r), 0], [0, 0, 1]])
        R_pitch_c2w = np.array([[1, 0, 0], [0, cos(p), -sin(p)], [0, sin(p), cos(p)]])
        R_base_c2w = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]])
        R_yaw_c2w = np.array([[cos(y), sin(y), 0], [-sin(y), cos(y), 0], [0, 0, 1]])
        R_c2w = R_yaw_c2w @ R_base_c2w @ R_pitch_c2w @ R_roll_c2w
        R_w2c = R_c2w.T
        rvec, _ = cv2.Rodrigues(R_w2c)
        return rvec

    def get_simple_map_polygons(self, img_w=5280, img_h=3956):
        x, y = self.drone_pos[0], self.drone_pos[1]
        
        # Draw the drone marker
        d1 = QgsPointXY(x-1, y-1)
        d2 = QgsPointXY(x+1, y-1)
        d3 = QgsPointXY(x+1, y+1)
        d4 = QgsPointXY(x-1, y+1)
        drone_poly = [d1, d2, d3, d4]

        # REVERSE PROJECTION TEST: Project the 4 corners of the photo to the ground
        corners = [(0, 0), (img_w, 0), (img_w, img_h), (0, img_h)]
        fov_poly = []
        
        # Test against ground level Z (approximated as 0 for footprint testing)
        ground_z = 0.0 
        
        for u, v in corners:
            pt = self.pixel_to_world(u, v, ground_z) 
            if pt:
                fov_poly.append(pt)
                
        # If the horizon is in the shot, corners project to infinity (pt returns None). 
        # Fall back to generic triangle so it doesn't crash.
        if len(fov_poly) < 3:
            angle_rad = math.radians(90 - self.grid_yaw)
            fov_half_h = math.radians(35) # Approx horizontal half-FOV
            fov_half_v = 25.0             # Approx vertical half-FOV in degrees
            
            abs_pitch = abs(self.grid_pitch)
            alt = max(10.0, self.drone_pos[2])
            
            # Calculate the pitch of the TOP edge of the camera frame
            top_edge_pitch = abs_pitch - fov_half_v
            
            # If the top edge is looking at or above the horizon, cast it far out
            if top_edge_pitch <= 0.5:
                dist = 15000.0
            else:
                # Otherwise, calculate exactly where the top of the frame hits the ground
                dist = alt / math.tan(math.radians(top_edge_pitch))
                
            # Clamp it to prevent extreme memory overloads, but allow up to 15km
            dist = max(50.0, min(15000.0, dist))
            
            p1 = QgsPointXY(x, y)
            p2 = QgsPointXY(x + dist * math.cos(angle_rad + fov_half_h), y + dist * math.sin(angle_rad + fov_half_h))
            p3 = QgsPointXY(x + dist * math.cos(angle_rad - fov_half_h), y + dist * math.sin(angle_rad - fov_half_h))
            fov_poly = [p1, p2, p3]

        return drone_poly, fov_poly

    def get_3d_camera_points(self, points, fallback_z, dem_layer):
        world_pts = []
        for pt in points:
            z_val = fallback_z
            if dem_layer:
                # Use sample() instead of identify() for robust Raster/WCS reads
                val, ok = dem_layer.dataProvider().sample(QgsPointXY(pt.x(), pt.y()), 1)
                if ok and not math.isnan(val):
                    z_val = float(val)
                    
            rel_x = pt.x() - self.drone_pos[0]
            rel_y = pt.y() - self.drone_pos[1]
            rel_z = z_val - self.drone_pos[2]
            world_pts.append([rel_x, rel_y, rel_z])
            
        world_pts_np = np.array(world_pts, dtype=np.float32)
        cam_pts_3d = (self.R_cam @ world_pts_np.T).T 
        return cam_pts_3d.tolist()

    def project_world_to_2d(self, x, y, z):
        rel_x = x - self.drone_pos[0]
        rel_y = y - self.drone_pos[1]
        rel_z = z - self.drone_pos[2]
        
        world_pts_np = np.array([[rel_x, rel_y, rel_z]], dtype=np.float32)
        cam_pts_3d = (self.R_cam @ world_pts_np.T).T 
        
        if cam_pts_3d[0][2] <= 0:
            return None
            
        return self.project_3d_to_2d(cam_pts_3d[0])

    def project_3d_to_2d(self, pt_3d_cam):
        X, Y, Z = pt_3d_cam
        if Z <= 0: return None 
        
        objectPoints = np.array([[[X, Y, Z]]], dtype=np.float32)
        zero_vec = np.zeros((3, 1), dtype=np.float32) 
        
        try:
            img_pts, _ = cv2.projectPoints(objectPoints, zero_vec, zero_vec, self.camera_matrix, self.dist_coeffs)
            u, v = img_pts[0][0]
            
            if math.isnan(u) or math.isnan(v) or abs(u) > 50000 or abs(v) > 50000:
                return None
                
            return (int(u), int(v), float(Z))
        except Exception:
            return None

    def project_3d_to_2d_batch(self, pts_3d_cam):
        if not pts_3d_cam: return []
        
        objectPoints = np.array(pts_3d_cam, dtype=np.float32)
        zero_vec = np.zeros((3, 1), dtype=np.float32) 
        
        try:
            img_pts, _ = cv2.projectPoints(objectPoints, zero_vec, zero_vec, self.camera_matrix, self.dist_coeffs)
            
            results = []
            for i, pt in enumerate(img_pts):
                u, v = float(pt[0][0]), float(pt[0][1])
                
                if not math.isnan(u) and not math.isnan(v):
                    clamped_u = max(-1000000, min(1000000, int(u)))
                    clamped_v = max(-1000000, min(1000000, int(v)))
                    results.append((clamped_u, clamped_v, float(objectPoints[i][2])))
                else:
                    results.append(None) 
                    
            return results
        except Exception:
            return [None] * len(pts_3d_cam)

    def pixel_to_world(self, u, v, ground_z):
        pt = np.array([[[u, v]]], dtype=np.float32)
        
        pt_undist = cv2.undistortPoints(pt, self.camera_matrix, self.dist_coeffs)
        x_norm, y_norm = pt_undist[0][0]
        
        ray_cam = np.array([x_norm, y_norm, 1.0])
        
        R_inv = np.linalg.inv(self.R_cam)
        ray_world = R_inv.dot(ray_cam)
        
        rel_ground = ground_z - self.drone_pos[2]
        if ray_world[2] >= 0: return None 
        
        t = rel_ground / ray_world[2]
        world_x = self.drone_pos[0] + (t * ray_world[0])
        world_y = self.drone_pos[1] + (t * ray_world[1])
        
        return QgsPointXY(world_x, world_y)

    def calibrate_xy(self, tie_points):
        """Calculates precise XY map shift based on matching image pixels to map coordinates."""
        if len(tie_points) == 0: return None
        
        dx_sum, dy_sum = 0, 0
        valid_pts = 0
        for pt in tie_points:
            est_w = self.pixel_to_world(pt['u'], pt['v'], pt['z'])
            if est_w:
                shift_x = pt['x'] - est_w.x()
                shift_y = pt['y'] - est_w.y()
                
                if not math.isnan(shift_x) and not math.isnan(shift_y):
                    dx_sum += shift_x
                    dy_sum += shift_y
                    valid_pts += 1
                
        if valid_pts == 0: return None
        return (dx_sum/valid_pts, dy_sum/valid_pts)

    def calibrate_3d(self, tie_points):
        """Full 3D Camera Pose Estimation. Requires at least 4 coplanar points."""
        if len(tie_points) < 4: return None
        
        obj_pts = []
        img_pts = []
        for pt in tie_points:
            rel_x = pt['x'] - self.drone_pos[0]
            rel_y = pt['y'] - self.drone_pos[1]
            rel_z = pt['z'] - self.drone_pos[2]
            obj_pts.append([rel_x, rel_y, rel_z])
            img_pts.append([pt['u'], pt['v']])
            
        obj_pts = np.array(obj_pts, dtype=np.float32)
        img_pts = np.array(img_pts, dtype=np.float32)
        
        success, rvec_new, tvec_new = cv2.solvePnP(
            obj_pts, img_pts, self.camera_matrix, self.dist_coeffs, 
            rvec=self.rvec.copy(), tvec=np.zeros((3,1), dtype=np.float32), 
            useExtrinsicGuess=True, flags=cv2.SOLVEPNP_ITERATIVE
        )
        
        if not success: return None
        
        R_w2c_new, _ = cv2.Rodrigues(rvec_new)
        C_obj = -np.linalg.inv(R_w2c_new) @ tvec_new
        dx, dy, dz = float(C_obj[0][0]), float(C_obj[1][0]), float(C_obj[2][0])
        
        R_c2w_new = R_w2c_new.T
        r_rad = math.radians(self.tel['roll'])
        R_roll_inv = np.array([[math.cos(-r_rad), -math.sin(-r_rad), 0], 
                               [math.sin(-r_rad), math.cos(-r_rad), 0], 
                               [0, 0, 1]])
        M = R_c2w_new @ R_roll_inv
        
        sin_p = max(-1.0, min(1.0, M[2, 2]))
        new_pitch = math.degrees(math.asin(sin_p))
        new_yaw = math.degrees(math.atan2(-M[1, 0], M[0, 0]))
        
        dpitch = new_pitch - self.tel['pitch']
        dyaw = new_yaw - self.grid_yaw_raw
        
        return dx, dy, dz, dpitch, dyaw # dpitch & dyaw are now serving as total required offsets
        
    def calibrate_imu(self, tie_points):
        """Locks RTK X,Y,Z and finds optimal Pitch and Yaw via grid search."""
        if len(tie_points) < 1: return None
        
        obj_pts = []
        img_pts = []
        for pt in tie_points:
            rel_x = pt['x'] - self.drone_pos[0]
            rel_y = pt['y'] - self.drone_pos[1]
            rel_z = pt['z'] - self.drone_pos[2]
            obj_pts.append([rel_x, rel_y, rel_z])
            img_pts.append([pt['u'], pt['v']])
            
        obj_pts = np.array(obj_pts, dtype=np.float32)
        img_pts = np.array(img_pts, dtype=np.float32)
        
        best_err = float('inf')
        best_pitch_offset = 0.0
        best_yaw_offset = 0.0
        
        # Grid search bounds: +/- 15 degrees
        coarse_yaws = np.arange(-15.0, 16.0, 1.0)
        coarse_pitches = np.arange(-15.0, 16.0, 1.0)
        
        tvec = np.zeros((3,1), dtype=np.float32)
        
        def calculate_error(yaw_off, pitch_off):
            rvec = self.create_rvec(self.grid_yaw_raw + yaw_off, self.tel['pitch'] + pitch_off, self.tel['roll'])
            proj_pts, _ = cv2.projectPoints(obj_pts.reshape(-1,1,3), rvec, tvec, self.camera_matrix, self.dist_coeffs)
            proj_pts = proj_pts.reshape(-1, 2)
            # Calculate mean pixel reprojection error
            return np.mean(np.linalg.norm(proj_pts - img_pts, axis=1))

        # Pass 1: Coarse 1-degree search
        for yo in coarse_yaws:
            for po in coarse_pitches:
                err = calculate_error(yo, po)
                if err < best_err:
                    best_err = err
                    best_yaw_offset = yo
                    best_pitch_offset = po
                    
        fine_err = best_err
        fine_yo = best_yaw_offset
        fine_po = best_pitch_offset
        
        # Pass 2: Fine 0.1-degree search around the best coarse result
        for yo in np.arange(best_yaw_offset - 1.0, best_yaw_offset + 1.1, 0.1):
            for po in np.arange(best_pitch_offset - 1.0, best_pitch_offset + 1.1, 0.1):
                err = calculate_error(yo, po)
                if err < fine_err:
                    fine_err = err
                    fine_yo = yo
                    fine_po = po
                    
        return fine_po, fine_yo