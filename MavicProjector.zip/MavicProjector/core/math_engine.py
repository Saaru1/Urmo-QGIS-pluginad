import math
from math import atan2, cos, degrees, radians, sin
import cv2
import numpy as np
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
)


class MathEngine:
    def __init__(
        self,
        telemetry,
        geoid_offset,
        yaw_offset,
        pitch_offset,
        transform_context=None,
        roll_offset=0.0,
        focal_scale=1.0,
        alt_mode='auto',
        dem_under_drone=None,
    ):
        self.tel = telemetry
        self.focal_scale = float(focal_scale) if (focal_scale and focal_scale > 0.1) else 1.0
        self.base_camera_matrix = np.array(telemetry['camera_matrix'], dtype=np.float64).copy()
        self.camera_matrix = self.base_camera_matrix.copy()
        self.camera_matrix[0, 0] *= self.focal_scale
        self.camera_matrix[1, 1] *= self.focal_scale
        self.dist_coeffs = np.array(telemetry['dist_coeffs'], dtype=np.float64).copy()

        self.crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        self.crs_est = QgsCoordinateReferenceSystem("EPSG:3301")

        if transform_context is None:
            transform_context = QgsProject.instance().transformContext()
        self.transform_context = transform_context
        self.transform = QgsCoordinateTransform(self.crs_wgs84, self.crs_est, transform_context)

        self.yaw_offset = float(yaw_offset)
        self.pitch_offset = float(pitch_offset)
        self.roll_offset = float(roll_offset)
        self.geoid_offset = float(geoid_offset)
        self.alt_mode = alt_mode or 'auto'

        self.grid_convergence = self.get_grid_convergence()
        self.grid_yaw_raw = float(self.tel['yaw']) + self.grid_convergence
        self.grid_yaw = self.grid_yaw_raw + self.yaw_offset
        self.grid_pitch = float(self.tel['pitch']) + self.pitch_offset
        self.grid_roll = float(self.tel['roll']) + self.roll_offset

        drone_pt = QgsPointXY(self.tel['lon'], self.tel['lat'])
        drone_est = self.transform.transform(drone_pt)
        drone_z, self.resolved_alt_mode = self._resolve_drone_altitude(
            self.geoid_offset, self.alt_mode, dem_under_drone
        )
        self.drone_pos = np.array([drone_est.x(), drone_est.y(), drone_z], dtype=np.float64)

        self.rvec = self.create_rvec(self.grid_yaw, self.grid_pitch, self.grid_roll)
        self.R_cam, _ = cv2.Rodrigues(self.rvec)

    def _resolve_drone_altitude(self, geoid_offset, alt_mode, dem_under_drone):
        is_rtk = self.tel.get('is_rtk', True)
        abs_alt = float(self.tel.get('abs_alt', self.tel.get('rtk_alt', 0.0)))
        rel_alt = float(self.tel.get('rel_alt', 0.0))
        has_rel = bool(self.tel.get('has_rel_alt', rel_alt != 0.0))
        has_dem = (dem_under_drone is not None and not math.isnan(float(dem_under_drone)))

        mode = (alt_mode or 'auto').lower()
        if mode == 'rtk' or (mode == 'auto' and is_rtk):
            return abs_alt + geoid_offset, 'RTK + Geoid'
        if mode == 'rel_dem' or (mode == 'auto' and not is_rtk and has_rel and has_dem):
            ground = float(dem_under_drone) if has_dem else 0.0
            return ground + rel_alt + geoid_offset, 'RelAlt + DEM'
        if mode == 'msl' or (mode == 'auto' and not is_rtk):
            return abs_alt + geoid_offset, 'MSL (No Geoid)'
        return abs_alt + geoid_offset, 'RTK + Geoid'

    def get_grid_convergence(self):
        p_drone = QgsPointXY(self.tel['lon'], self.tel['lat'])
        p_north = QgsPointXY(self.tel['lon'], self.tel['lat'] + 0.01)
        d_est = self.transform.transform(p_drone)
        n_est = self.transform.transform(p_north)
        dx = n_est.x() - d_est.x()
        dy = n_est.y() - d_est.y()
        return degrees(atan2(dx, dy))

    @staticmethod
    def build_R_c2w(yaw_deg, pitch_deg, roll_deg):
        y, p, r = radians(yaw_deg), radians(pitch_deg), radians(roll_deg)
        R_roll_c2w = np.array([[cos(r), -sin(r), 0.0], [sin(r), cos(r), 0.0], [0.0, 0.0, 1.0]])
        R_pitch_c2w = np.array([[1.0, 0.0, 0.0], [0.0, cos(p), -sin(p)], [0.0, sin(p), cos(p)]])
        R_base_c2w = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, -1.0, 0.0]])
        R_yaw_c2w = np.array([[cos(y), sin(y), 0.0], [-sin(y), cos(y), 0.0], [0.0, 0.0, 1.0]])
        return R_yaw_c2w @ R_base_c2w @ R_pitch_c2w @ R_roll_c2w

    @staticmethod
    def decompose_R_c2w(R_c2w):
        """Exact analytical inverse of build_R_c2w(yaw, pitch, roll).
        Returns (yaw_deg, pitch_deg, roll_deg) matching build_R_c2w to machine precision.
        """
        # Column 2 of R_c2w is [sin(y)*cos(p), cos(y)*cos(p), sin(p)]^T (independent of roll)
        sin_p = max(-1.0, min(1.0, float(R_c2w[2, 2])))
        p_rad = math.asin(sin_p)
        pitch_deg = degrees(p_rad)

        if abs(math.cos(p_rad)) > 1e-6:
            yaw_deg = degrees(atan2(float(R_c2w[0, 2]), float(R_c2w[1, 2])))
        else:
            # Gimbal lock at exact nadir/zenith: absorb rotation into yaw with roll=0
            yaw_deg = degrees(atan2(-float(R_c2w[1, 0]), float(R_c2w[0, 0])))
            return yaw_deg, pitch_deg, 0.0

        R_no_roll = MathEngine.build_R_c2w(yaw_deg, pitch_deg, 0.0)
        R_roll = R_no_roll.T @ R_c2w
        roll_deg = degrees(atan2(float(R_roll[1, 0]), float(R_roll[0, 0])))
        return yaw_deg, pitch_deg, roll_deg

    def create_rvec(self, yaw, pitch, roll):
        R_c2w = self.build_R_c2w(yaw, pitch, roll)
        R_w2c = R_c2w.T
        rvec, _ = cv2.Rodrigues(R_w2c)
        return rvec

    def get_simple_map_polygons(self, img_w=None, img_h=None):
        if img_w is None:
            img_w = int(self.tel.get('img_w', 5280))
        if img_h is None:
            img_h = int(self.tel.get('img_h', 3956))

        x, y = float(self.drone_pos[0]), float(self.drone_pos[1])
        drone_poly = [
            QgsPointXY(x - 1, y - 1),
            QgsPointXY(x + 1, y - 1),
            QgsPointXY(x + 1, y + 1),
            QgsPointXY(x - 1, y + 1),
        ]

        corners = [(0, 0), (img_w, 0), (img_w, img_h), (0, img_h)]
        fov_poly = []
        ground_z = 0.0
        for u, v in corners:
            pt = self.pixel_to_world(u, v, ground_z)
            if pt:
                dist = math.hypot(pt.x() - x, pt.y() - y)
                if dist <= 15000.0:
                    fov_poly.append(pt)

        if len(fov_poly) < 4:
            angle_rad = math.radians(90.0 - self.grid_yaw)
            fx = max(200.0, float(self.camera_matrix[0, 0]))
            fy = max(200.0, float(self.camera_matrix[1, 1]))
            fov_half_h = math.atan((img_w / 2.0) / fx) + math.radians(5.0)
            fov_half_v = math.degrees(math.atan((img_h / 2.0) / fy))

            abs_pitch = abs(self.grid_pitch)
            alt = max(10.0, float(self.drone_pos[2]))
            top_edge_pitch = abs_pitch - fov_half_v

            if top_edge_pitch <= 0.5:
                dist = 8000.0
            else:
                dist = alt / math.tan(math.radians(top_edge_pitch))
            dist = max(50.0, min(8000.0, dist))

            p1 = QgsPointXY(x, y)
            p2 = QgsPointXY(x + dist * math.cos(angle_rad + fov_half_h), y + dist * math.sin(angle_rad + fov_half_h))
            p3 = QgsPointXY(x + dist * math.cos(angle_rad - fov_half_h), y + dist * math.sin(angle_rad - fov_half_h))
            fov_poly = [p1, p2, p3]

        return drone_poly, fov_poly

    def get_3d_camera_points(self, points, fallback_z, dem_source=None, z_offset=0.0):
        """Transforms 2D/3D world points into 3D OpenCV camera coordinates.
        `dem_source` may be a DEMSampler instance, a QgsRasterLayer, or None.
        """
        if points is None or len(points) == 0:
            return []

        n = len(points)
        xs = np.array([p.x() for p in points], dtype=np.float64)
        ys = np.array([p.y() for p in points], dtype=np.float64)

        if dem_source is not None and hasattr(dem_source, 'sample_array'):
            zs = dem_source.sample_array(xs, ys, fallback_override=fallback_z)
        elif dem_source is not None and hasattr(dem_source, 'dataProvider'):
            zs = np.full(n, float(fallback_z), dtype=np.float64)
            dp = dem_source.dataProvider()
            for i in range(n):
                val, ok = dp.sample(QgsPointXY(float(xs[i]), float(ys[i])), 1)
                if ok and not math.isnan(val):
                    zs[i] = float(val)
        else:
            zs = np.full(n, float(fallback_z), dtype=np.float64)

        if z_offset != 0.0:
            zs = zs + float(z_offset)

        rel = np.stack(
            [xs - self.drone_pos[0], ys - self.drone_pos[1], zs - self.drone_pos[2]],
            axis=1,
        )
        cam_pts_3d = (self.R_cam @ rel.T).T
        return cam_pts_3d.tolist()

    def get_3d_camera_points_xyz(self, xyz_list):
        """Transforms explicit (x, y, z) world coordinates into 3D OpenCV camera coordinates."""
        if xyz_list is None or len(xyz_list) == 0:
            return []
        pts = np.asarray(xyz_list, dtype=np.float64)
        rel = pts - self.drone_pos[None, :]
        return (self.R_cam @ rel.T).T.tolist()

    def project_world_to_2d(self, x, y, z):
        rel = np.array([x - self.drone_pos[0], y - self.drone_pos[1], z - self.drone_pos[2]], dtype=np.float64)
        cam_pt = self.R_cam @ rel
        if cam_pt[2] <= 0.0:
            return None
        return self.project_3d_to_2d(cam_pt)

    def project_3d_to_2d(self, pt_3d_cam):
        X, Y, Z = float(pt_3d_cam[0]), float(pt_3d_cam[1]), float(pt_3d_cam[2])
        if Z <= 0.0:
            return None

        objectPoints = np.array([[[X, Y, Z]]], dtype=np.float64)
        zero_vec = np.zeros((3, 1), dtype=np.float64)
        try:
            img_pts, _ = cv2.projectPoints(objectPoints, zero_vec, zero_vec, self.camera_matrix, self.dist_coeffs)
            u, v = float(img_pts[0][0][0]), float(img_pts[0][0][1])
            if math.isnan(u) or math.isnan(v) or abs(u) > 50000 or abs(v) > 50000:
                return None
            return (round(u), round(v), float(Z))
        except Exception:
            return None

    def project_3d_to_2d_float(self, pts_3d_cam):
        """Batch projects 3D camera-space points to sub-pixel float (u, v, Z) tuples."""
        if pts_3d_cam is None or len(pts_3d_cam) == 0:
            return []
        objectPoints = np.asarray(pts_3d_cam, dtype=np.float64).reshape(-1, 1, 3)
        zero_vec = np.zeros((3, 1), dtype=np.float64)
        try:
            img_pts, _ = cv2.projectPoints(objectPoints, zero_vec, zero_vec, self.camera_matrix, self.dist_coeffs)
            pts_2d = img_pts.reshape(-1, 2)
            zs = objectPoints[:, 0, 2]
            results = []
            for i in range(len(pts_2d)):
                u, v = float(pts_2d[i, 0]), float(pts_2d[i, 1])
                if not math.isnan(u) and not math.isnan(v):
                    cu = max(-1000000.0, min(1000000.0, u))
                    cv_val = max(-1000000.0, min(1000000.0, v))
                    results.append((cu, cv_val, float(zs[i])))
                else:
                    results.append(None)
            return results
        except Exception:
            return [None] * len(pts_3d_cam)

    def project_3d_to_2d_batch(self, pts_3d_cam):
        float_res = self.project_3d_to_2d_float(pts_3d_cam)
        out = []
        for item in float_res:
            if item is None:
                out.append(None)
            else:
                out.append((round(item[0]), round(item[1]), item[2]))
        return out

    def pixel_to_world(self, u, v, ground_z, dem_sampler=None):
        pt = np.array([[[float(u), float(v)]]], dtype=np.float64)
        pt_undist = cv2.undistortPoints(pt, self.camera_matrix, self.dist_coeffs)
        x_norm, y_norm = float(pt_undist[0][0][0]), float(pt_undist[0][0][1])

        ray_cam = np.array([x_norm, y_norm, 1.0], dtype=np.float64)
        ray_world = self.R_cam.T @ ray_cam

        if ray_world[2] >= -1e-5:
            return None

        z_est = float(ground_z)
        iters = 4 if (dem_sampler is not None and hasattr(dem_sampler, 'sample')) else 1
        world_x, world_y = 0.0, 0.0
        for _ in range(iters):
            rel_ground = z_est - self.drone_pos[2]
            if rel_ground >= 0.0:
                return None
            t = rel_ground / ray_world[2]
            if t <= 0.0 or t > 50000.0:
                return None
            world_x = self.drone_pos[0] + t * ray_world[0]
            world_y = self.drone_pos[1] + t * ray_world[1]
            if dem_sampler is not None and hasattr(dem_sampler, 'sample'):
                z_est = dem_sampler.sample(world_x, world_y, fallback_override=ground_z)

        return QgsPointXY(world_x, world_y)

    def pixels_to_world_grid(self, u_arr, v_arr, dem_sampler=None, fallback_z=0.0):
        """Vectorized ray-terrain intersection for 2D pixel grids (used for DEM-aware WMS/raster warp)."""
        orig_shape = u_arr.shape
        pts = np.stack([u_arr.ravel(), v_arr.ravel()], axis=1).astype(np.float64).reshape(-1, 1, 2)
        undist = cv2.undistortPoints(pts, self.camera_matrix, self.dist_coeffs).reshape(-1, 2)
        rays_cam = np.concatenate([undist, np.ones((len(undist), 1), dtype=np.float64)], axis=1)
        rays_world = (self.R_cam.T @ rays_cam.T).T

        rz = rays_world[:, 2]
        valid = rz < -1e-4

        wx = np.zeros(len(rz), dtype=np.float64)
        wy = np.zeros(len(rz), dtype=np.float64)
        if not np.any(valid):
            return wx.reshape(orig_shape), wy.reshape(orig_shape), valid.reshape(orig_shape)

        rx_v = rays_world[valid, 0]
        ry_v = rays_world[valid, 1]
        rz_v = rz[valid]

        z_est = np.full(len(rz_v), float(fallback_z), dtype=np.float64)
        n_iters = 4 if (dem_sampler is not None and hasattr(dem_sampler, 'sample_array')) else 1
        x_v = np.zeros_like(z_est)
        y_v = np.zeros_like(z_est)
        sub_ok = np.ones(len(z_est), dtype=bool)

        for _ in range(n_iters):
            rel_z = z_est - self.drone_pos[2]
            sub_ok = rel_z < -0.2
            t = np.where(sub_ok, rel_z / rz_v, 0.0)
            sub_ok &= (t > 0.0) & (t < 25000.0)
            x_v = self.drone_pos[0] + t * rx_v
            y_v = self.drone_pos[1] + t * ry_v
            if dem_sampler is not None and hasattr(dem_sampler, 'sample_array') and np.any(sub_ok):
                z_est[sub_ok] = dem_sampler.sample_array(x_v[sub_ok], y_v[sub_ok], fallback_override=fallback_z)

        wx[valid] = x_v
        wy[valid] = y_v
        full_valid = np.zeros(len(rz), dtype=bool)
        full_valid[valid] = sub_ok
        return wx.reshape(orig_shape), wy.reshape(orig_shape), full_valid.reshape(orig_shape)

    def calibrate_horizon(self, u1, v1, u2, v2):
        """Solves exact (pitch_offset, roll_offset) from 2 user clicks along the sea/distant horizon,
        accounting for lens distortion and geometric horizon dip at drone altitude.
        """
        if math.hypot(u2 - u1, v2 - v1) < 20.0:
            return None

        pts = np.array([[[float(u1), float(v1)]], [[float(u2), float(v2)]]], dtype=np.float64)
        undist = cv2.undistortPoints(pts, self.camera_matrix, self.dist_coeffs).reshape(2, 2)
        rays = np.column_stack([undist, np.ones(2, dtype=np.float64)])
        rays /= np.linalg.norm(rays, axis=1, keepdims=True)

        # Geometric horizon dip with standard terrestrial refraction k = 0.13
        alt_m = max(0.0, float(self.drone_pos[2]))
        r_eff = 6371000.0 / 0.87
        dip_rad = math.acos(min(1.0, r_eff / (r_eff + alt_m)))
        target_zw = -math.sin(dip_rad)

        # World Z of unit camera ray u = (ux, uy, uz) depends ONLY on (pitch, roll):
        # wz(p, r) = -ux * cos(p) * sin(r) - uy * cos(p) * cos(r) + uz * sin(p)
        p = radians(self.grid_pitch)
        r = radians(self.grid_roll)

        for _ in range(20):
            cp, sp = math.cos(p), math.sin(p)
            cr, sr = math.cos(r), math.sin(r)
            f_val = -rays[:, 0] * cp * sr - rays[:, 1] * cp * cr + rays[:, 2] * sp - target_zw
            if np.max(np.abs(f_val)) < 1e-9:
                break
            df_dp = rays[:, 0] * sp * sr + rays[:, 1] * sp * cr + rays[:, 2] * cp
            df_dr = -rays[:, 0] * cp * cr + rays[:, 1] * cp * sr
            J = np.column_stack([df_dp, df_dr])
            JTJ = J.T @ J + 1e-6 * np.eye(2)
            step = np.linalg.solve(JTJ, -J.T @ f_val)
            p = max(radians(-89.0), min(radians(45.0), p + float(step[0])))
            r = max(radians(-45.0), min(radians(45.0), r + float(step[1])))

        dpitch = degrees(p) - float(self.tel['pitch'])
        droll = degrees(r) - float(self.tel['roll'])
        return dpitch, droll

    def calibrate_xy(self, tie_points):
        """Calculates precise XY map shift based on matching image pixels to map coordinates."""
        if len(tie_points) == 0:
            return None

        dx_sum, dy_sum = 0.0, 0.0
        valid_pts = 0
        for pt in tie_points:
            est_w = self.pixel_to_world(pt['u'], pt['v'], pt['z'])
            if est_w:
                shift_x = pt['x'] - est_w.x()
                shift_y = pt['y'] - est_w.y()
                if not math.isnan(shift_x) and not math.isnan(shift_y):
                    dx_sum += shift_x
                    dy_sum += shift_y
                    valid_pts += 1

        if valid_pts == 0:
            return None
        return (dx_sum / valid_pts, dy_sum / valid_pts)

    def calibrate_imu(self, tie_points, solve_roll=None, solve_focal=False):
        """Locks drone XYZ and solves continuous least-squares camera orientation
        (Yaw + Pitch for 1 pt; Yaw + Pitch + Roll for >=2 pts; + Focal Scale if solve_focal and >=3 pts).
        Returns dict {'dpitch', 'dyaw', 'droll', 'focal_scale', 'rms_px'}.
        """
        n_pts = len(tie_points)
        if n_pts < 1:
            return None

        use_roll = (n_pts >= 2) if solve_roll is None else (bool(solve_roll) and n_pts >= 2)
        use_focal = bool(solve_focal) and (n_pts >= 3)

        obj_pts = np.array(
            [[pt['x'] - self.drone_pos[0], pt['y'] - self.drone_pos[1], pt['z'] - self.drone_pos[2]] for pt in tie_points],
            dtype=np.float64,
        ).reshape(-1, 1, 3)
        img_pts = np.array([[pt['u'], pt['v']] for pt in tie_points], dtype=np.float64)
        tvec = np.zeros((3, 1), dtype=np.float64)

        def eval_residuals(params):
            dy = float(params[0])
            dp = float(params[1])
            dr = float(params[2]) if use_roll else self.roll_offset
            log_fs = float(params[3]) if use_focal else math.log(self.focal_scale)
            fs = math.exp(max(-0.7, min(0.95, log_fs)))

            K = self.base_camera_matrix.copy()
            K[0, 0] *= fs
            K[1, 1] *= fs

            rvec = self.create_rvec(
                self.grid_yaw_raw + dy,
                float(self.tel['pitch']) + dp,
                float(self.tel['roll']) + dr,
            )
            R_w2c, _ = cv2.Rodrigues(rvec)
            cam_z = (R_w2c @ obj_pts.reshape(-1, 3).T)[2, :]
            if np.any(cam_z <= 0.2):
                return np.full(n_pts * 2 + (1 if use_focal else 0), 1e6, dtype=np.float64)

            proj, _ = cv2.projectPoints(obj_pts, rvec, tvec, K, self.dist_coeffs)
            res = (proj.reshape(-1, 2) - img_pts).ravel()
            if use_focal:
                # Mild prior keeping focal_scale stable on nearly-collinear points
                res = np.append(res, 4.0 * log_fs)
            return res

        # Fast coarse seed scan over +/-18 deg yaw & pitch so large compass errors never trap LM
        best_seed_cost = float('inf')
        best_dy, best_dp = self.yaw_offset, self.pitch_offset
        for yo in np.arange(self.yaw_offset - 18.0, self.yaw_offset + 18.1, 3.0):
            for po in np.arange(self.pitch_offset - 12.0, self.pitch_offset + 12.1, 3.0):
                seed_vec = [yo, po]
                if use_roll:
                    seed_vec.append(self.roll_offset)
                if use_focal:
                    seed_vec.append(math.log(self.focal_scale))
                r_vec = eval_residuals(seed_vec)
                c = float(np.dot(r_vec, r_vec))
                if c < best_seed_cost:
                    best_seed_cost = c
                    best_dy, best_dp = float(yo), float(po)

        x = [best_dy, best_dp]
        if use_roll:
            x.append(self.roll_offset)
        if use_focal:
            x.append(math.log(self.focal_scale))
        x = np.array(x, dtype=np.float64)

        # Damped Gauss-Newton / Levenberg-Marquardt refinement
        lam = 1e-3
        r_curr = eval_residuals(x)
        cost_curr = float(np.dot(r_curr, r_curr))
        eps = 1e-5
        m_dim = len(x)

        for _ in range(50):
            J = np.empty((len(r_curr), m_dim), dtype=np.float64)
            for k in range(m_dim):
                x_pert = x.copy()
                x_pert[k] += eps
                J[:, k] = (eval_residuals(x_pert) - r_curr) / eps

            JTJ = J.T @ J + lam * np.eye(m_dim)
            g = J.T @ r_curr
            try:
                step = np.linalg.solve(JTJ, -g)
            except np.linalg.LinAlgError:
                break

            if np.linalg.norm(step) < 1e-7:
                break

            x_cand = x + step
            if use_roll:
                x_cand[2] = max(-35.0, min(35.0, x_cand[2]))
            if use_focal:
                x_cand[3] = max(-0.6, min(0.85, x_cand[3]))

            r_cand = eval_residuals(x_cand)
            cost_cand = float(np.dot(r_cand, r_cand))
            if cost_cand < cost_curr:
                x = x_cand
                r_curr = r_cand
                cost_curr = cost_cand
                lam = max(1e-7, lam * 0.3)
            else:
                lam = min(1e6, lam * 5.0)

        dyaw = float(x[0])
        dpitch = float(x[1])
        droll = float(x[2]) if use_roll else self.roll_offset
        new_fscale = math.exp(float(x[3])) if use_focal else self.focal_scale

        pix_res = r_curr[: n_pts * 2].reshape(-1, 2)
        rms_px = float(np.sqrt(np.mean(np.sum(pix_res ** 2, axis=1))))
        return {
            'dpitch': dpitch,
            'dyaw': dyaw,
            'droll': droll,
            'focal_scale': new_fscale,
            'rms_px': rms_px,
        }

    def calibrate_3d(self, tie_points):
        """Full 6-DOF Camera Pose Estimation (XYZ + Yaw/Pitch/Roll) with exact roll extraction."""
        if len(tie_points) < 4:
            return None

        obj_pts = np.array(
            [[pt['x'] - self.drone_pos[0], pt['y'] - self.drone_pos[1], pt['z'] - self.drone_pos[2]] for pt in tie_points],
            dtype=np.float64,
        )
        img_pts = np.array([[pt['u'], pt['v']] for pt in tie_points], dtype=np.float64)

        success, rvec_new, tvec_new = cv2.solvePnP(
            obj_pts,
            img_pts,
            self.camera_matrix,
            self.dist_coeffs,
            rvec=self.rvec.copy().astype(np.float64),
            tvec=np.zeros((3, 1), dtype=np.float64),
            useExtrinsicGuess=True,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
        if not success:
            return None

        R_w2c_new, _ = cv2.Rodrigues(rvec_new)
        C_obj = -R_w2c_new.T @ tvec_new
        dx, dy, dz = float(C_obj[0][0]), float(C_obj[1][0]), float(C_obj[2][0])

        R_c2w_new = R_w2c_new.T
        new_yaw, new_pitch, new_roll = self.decompose_R_c2w(R_c2w_new)

        dpitch = new_pitch - float(self.tel['pitch'])
        dyaw = ((new_yaw - self.grid_yaw_raw + 180.0) % 360.0) - 180.0
        droll = new_roll - float(self.tel['roll'])

        proj, _ = cv2.projectPoints(
            obj_pts.reshape(-1, 1, 3), rvec_new, tvec_new, self.camera_matrix, self.dist_coeffs
        )
        rms_px = float(np.sqrt(np.mean(np.sum((proj.reshape(-1, 2) - img_pts) ** 2, axis=1))))

        return {
            'dx': dx,
            'dy': dy,
            'dz': dz,
            'dpitch': dpitch,
            'dyaw': dyaw,
            'droll': droll,
            'rms_px': rms_px,
        }
