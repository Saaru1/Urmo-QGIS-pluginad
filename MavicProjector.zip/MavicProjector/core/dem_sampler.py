"""
Fast in-memory raster DEM block sampler with two-tier (near fine + far coarse) caching,
CRS reprojection from EPSG:3301, and vectorized bilinear interpolation.
"""
import math
import numpy as np
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
    QgsRectangle,
)


class _RasterBlockGrid:
    def __init__(self, arr, xmin, xmax, ymin, ymax):
        self.arr = arr  # float32 (rows, cols) with np.nan for NoData
        self.rows, self.cols = arr.shape
        self.xmin = float(xmin)
        self.xmax = float(xmax)
        self.ymin = float(ymin)
        self.ymax = float(ymax)
        self.dx = (self.xmax - self.xmin) / max(1, self.cols)
        self.dy = (self.ymax - self.ymin) / max(1, self.rows)

    def sample_scalar(self, x, y):
        if x < self.xmin or x > self.xmax or y < self.ymin or y > self.ymax:
            return math.nan
        fc = (x - self.xmin) / self.dx - 0.5
        fr = (self.ymax - y) / self.dy - 0.5
        c0 = int(math.floor(fc))
        r0 = int(math.floor(fr))
        if c0 < 0 or r0 < 0 or c0 + 1 >= self.cols or r0 + 1 >= self.rows:
            cc = min(max(int((x - self.xmin) / self.dx), 0), self.cols - 1)
            rr = min(max(int((self.ymax - y) / self.dy), 0), self.rows - 1)
            return float(self.arr[rr, cc])

        wc = fc - c0
        wr = fr - r0
        v00 = self.arr[r0, c0]
        v01 = self.arr[r0, c0 + 1]
        v10 = self.arr[r0 + 1, c0]
        v11 = self.arr[r0 + 1, c0 + 1]
        val = (1.0 - wr) * ((1.0 - wc) * v00 + wc * v01) + wr * ((1.0 - wc) * v10 + wc * v11)
        if math.isnan(val):
            # Nearest-neighbor fallback near coastal NoData edges
            cc = min(max(round(fc), 0), self.cols - 1)
            rr = min(max(round(fr), 0), self.rows - 1)
            return float(self.arr[rr, cc])
        return float(val)

    def sample_array(self, xs, ys):
        out = np.full(xs.shape, np.nan, dtype=np.float64)
        inside = (xs >= self.xmin) & (xs <= self.xmax) & (ys >= self.ymin) & (ys <= self.ymax)
        if not np.any(inside):
            return out

        xi = xs[inside]
        yi = ys[inside]
        fc = (xi - self.xmin) / self.dx - 0.5
        fr = (self.ymax - yi) / self.dy - 0.5

        c0 = np.clip(np.floor(fc).astype(np.int32), 0, max(0, self.cols - 2))
        r0 = np.clip(np.floor(fr).astype(np.int32), 0, max(0, self.rows - 2))
        wc = np.clip(fc - c0, 0.0, 1.0)
        wr = np.clip(fr - r0, 0.0, 1.0)

        c1 = min(self.cols - 1, 1)
        r1 = min(self.rows - 1, 1)
        v00 = self.arr[r0, c0]
        v01 = self.arr[r0, np.minimum(c0 + c1, self.cols - 1)]
        v10 = self.arr[np.minimum(r0 + r1, self.rows - 1), c0]
        v11 = self.arr[np.minimum(r0 + r1, self.rows - 1), np.minimum(c0 + c1, self.cols - 1)]

        interp = (1.0 - wr) * ((1.0 - wc) * v00 + wc * v01) + wr * ((1.0 - wc) * v10 + wc * v11)
        nan_mask = np.isnan(interp)
        if np.any(nan_mask):
            cn = np.clip(np.round(fc[nan_mask]).astype(np.int32), 0, self.cols - 1)
            rn = np.clip(np.round(fr[nan_mask]).astype(np.int32), 0, self.rows - 1)
            interp[nan_mask] = self.arr[rn, cn]

        out[inside] = interp
        return out


class DEMSampler:
    """Fetches at most two raster blocks (high-res foreground + medium-res far field)
    into RAM so thousands of densified vertices or screen rays sample in microseconds.
    """

    def __init__(
        self,
        dem_layer,
        focus_x,
        focus_y,
        far_bbox_3301=None,
        fallback_z=0.0,
        fine_half_m=700.0,
        fine_res_m=1.5,
        coarse_max_half_m=5000.0,
        coarse_res_m=8.0,
        transform_context=None,
    ):
        self.fallback_z = float(fallback_z)
        self.fine_grid = None
        self.coarse_grid = None
        self._to_dem = None

        if dem_layer is None or not dem_layer.isValid():
            return

        if transform_context is None:
            transform_context = QgsProject.instance().transformContext()

        crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
        dem_crs = dem_layer.crs()
        if dem_crs.isValid() and dem_crs != crs_3301:
            self._to_dem = QgsCoordinateTransform(crs_3301, dem_crs, transform_context)

        dp = dem_layer.dataProvider()
        if dp is None:
            return

        # 1. Fine foreground grid around drone / look target
        fine_rect_3301 = QgsRectangle(
            focus_x - fine_half_m,
            focus_y - fine_half_m,
            focus_x + fine_half_m,
            focus_y + fine_half_m,
        )
        self.fine_grid = self._fetch_block(dp, fine_rect_3301, fine_res_m, max_dim=1024)

        # 2. Coarse far-field grid if requested bbox extends beyond fine_rect_3301
        if far_bbox_3301 is not None and not far_bbox_3301.isEmpty():
            clamped = QgsRectangle(
                max(far_bbox_3301.xMinimum(), focus_x - coarse_max_half_m),
                max(far_bbox_3301.yMinimum(), focus_y - coarse_max_half_m),
                min(far_bbox_3301.xMaximum(), focus_x + coarse_max_half_m),
                min(far_bbox_3301.yMaximum(), focus_y + coarse_max_half_m),
            )
            if (
                clamped.xMinimum() < fine_rect_3301.xMinimum()
                or clamped.xMaximum() > fine_rect_3301.xMaximum()
                or clamped.yMinimum() < fine_rect_3301.yMinimum()
                or clamped.yMaximum() > fine_rect_3301.yMaximum()
            ):
                self.coarse_grid = self._fetch_block(dp, clamped, coarse_res_m, max_dim=1024)

    def _fetch_block(self, provider, rect_3301, res_m, max_dim=1024):
        try:
            rect_dem = self._to_dem.transformBoundingBox(rect_3301) if self._to_dem else rect_3301
            # Intersect with raster extent if finite
            ext = provider.extent()
            if ext and not ext.isEmpty() and ext.width() > 0 and ext.height() > 0:
                rect_dem = rect_dem.intersect(ext)
                if rect_dem.isEmpty() or rect_dem.width() <= 0 or rect_dem.height() <= 0:
                    return None

            # Estimate pixel count from 3301 metric span
            cols = max(8, min(max_dim, int(math.ceil(rect_3301.width() / res_m))))
            rows = max(8, min(max_dim, int(math.ceil(rect_3301.height() / res_m))))

            blk = provider.block(1, rect_dem, cols, rows)
            if blk is None or not blk.isValid():
                return None

            raw_bytes = bytes(blk.data())
            n_px = rows * cols
            if len(raw_bytes) == n_px * 4:
                arr = np.frombuffer(raw_bytes, dtype=np.float32).reshape((rows, cols)).copy()
            elif len(raw_bytes) == n_px * 8:
                arr = np.frombuffer(raw_bytes, dtype=np.float64).reshape((rows, cols)).astype(np.float32)
            elif len(raw_bytes) == n_px * 2:
                arr = np.frombuffer(raw_bytes, dtype=np.int16).reshape((rows, cols)).astype(np.float32)
            else:
                # Fallback cell read if unusual data type
                arr = np.empty((rows, cols), dtype=np.float32)
                for r in range(rows):
                    for c in range(cols):
                        arr[r, c] = blk.value(r, c)

            if blk.hasNoDataValue():
                nd = blk.noDataValue()
                if not math.isnan(nd):
                    arr[np.isclose(arr, nd, rtol=1e-5, atol=1e-4)] = np.nan

            arr[(arr < -500.0) | (arr > 9000.0)] = np.nan
            return _RasterBlockGrid(
                arr,
                rect_dem.xMinimum(),
                rect_dem.xMaximum(),
                rect_dem.yMinimum(),
                rect_dem.yMaximum(),
            )
        except Exception:
            return None

    def sample(self, x, y, fallback_override=None):
        fb = self.fallback_z if fallback_override is None else float(fallback_override)
        qx, qy = float(x), float(y)
        if self._to_dem:
            try:
                pt = self._to_dem.transform(QgsPointXY(qx, qy))
                qx, qy = pt.x(), pt.y()
            except Exception:
                return fb

        if self.fine_grid is not None:
            v = self.fine_grid.sample_scalar(qx, qy)
            if not math.isnan(v):
                return v
        if self.coarse_grid is not None:
            v = self.coarse_grid.sample_scalar(qx, qy)
            if not math.isnan(v):
                return v
        return fb

    def sample_raw(self, x, y):
        """Like sample(), but returns math.nan instead of fallback_z when outside DEM / on NoData."""
        qx, qy = float(x), float(y)
        if self._to_dem:
            try:
                pt = self._to_dem.transform(QgsPointXY(qx, qy))
                qx, qy = pt.x(), pt.y()
            except Exception:
                return math.nan

        if self.fine_grid is not None:
            v = self.fine_grid.sample_scalar(qx, qy)
            if not math.isnan(v):
                return v
        if self.coarse_grid is not None:
            v = self.coarse_grid.sample_scalar(qx, qy)
            if not math.isnan(v):
                return v
        return math.nan

    def sample_array(self, xs, ys, fallback_override=None):
        fb = self.fallback_z if fallback_override is None else float(fallback_override)
        xs_arr = np.asarray(xs, dtype=np.float64)
        ys_arr = np.asarray(ys, dtype=np.float64)
        orig_shape = xs_arr.shape
        xf = xs_arr.ravel()
        yf = ys_arr.ravel()

        if self._to_dem:
            qx = np.empty_like(xf)
            qy = np.empty_like(yf)
            for i in range(len(xf)):
                try:
                    pt = self._to_dem.transform(QgsPointXY(float(xf[i]), float(yf[i])))
                    qx[i], qy[i] = pt.x(), pt.y()
                except Exception:
                    qx[i], qy[i] = np.nan, np.nan
        else:
            qx, qy = xf, yf

        res = np.full(xf.shape, np.nan, dtype=np.float64)
        if self.fine_grid is not None:
            res = self.fine_grid.sample_array(qx, qy)
        if self.coarse_grid is not None:
            missing = np.isnan(res)
            if np.any(missing):
                res[missing] = self.coarse_grid.sample_array(qx[missing], qy[missing])

        nan_mask = np.isnan(res)
        if np.any(nan_mask):
            res[nan_mask] = fb
        return res.reshape(orig_shape)
