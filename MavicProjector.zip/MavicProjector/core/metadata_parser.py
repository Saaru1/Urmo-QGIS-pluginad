import math
import os
import re
import numpy as np
from qgis.PyQt.QtGui import QImage

from .geoid_est import get_estonian_geoid_offset
from .jpeg_meta import read_exif_tags


class MetadataParser:
    # Calibrated 1x horizontal focal-length multipliers (fx / image_width) for DJI Enterprise sensors.
    # 'dewarped' applies when in-camera lens distortion correction was performed (DewarpFlag=1 or SurveyingMode=0);
    # 'raw' applies when un-dewarped (DewarpFlag=0) if DewarpData is somehow missing.
    DJI_WIDE_PROFILES = {
        'M3E':  {'dewarped': 0.7632, 'raw': 0.70535, 'base_f35': 24.0},
        'M3M':  {'dewarped': 0.7632, 'raw': 0.70535, 'base_f35': 24.0},
        'M3T':  {'dewarped': 0.7580, 'raw': 0.69500, 'base_f35': 24.0},
        'M4E':  {'dewarped': 0.7632, 'raw': 0.70535, 'base_f35': 24.0},
        'M4T':  {'dewarped': 0.7580, 'raw': 0.69500, 'base_f35': 24.0},
        'M30':  {'dewarped': 0.7580, 'raw': 0.69500, 'base_f35': 24.0},
        'M30T': {'dewarped': 0.7580, 'raw': 0.69500, 'base_f35': 24.0},
    }

    @staticmethod
    def calculate_est_geoid(lat, lon):
        """Returns Estonian EH2000 geoid offset (-N in meters) using offline bilinear grid."""
        return get_estonian_geoid_offset(lat, lon)

    @staticmethod
    def _effective_zoom(zoom_ratio, focal_35mm, base_f35):
        """Prevents double-applying zoom_ratio when firmware already scaled FocalLengthIn35mmFilm."""
        if zoom_ratio <= 1.005:
            return 1.0
        if focal_35mm > 0.0 and base_f35 > 0.0:
            ratio_f35 = focal_35mm / base_f35
            if abs(ratio_f35 - zoom_ratio) < 0.15 * zoom_ratio:
                return 1.0
        return zoom_ratio

    @staticmethod
    def _compute_fallback_focal_px(w, h, model, make, source, focal_mm, focal_35mm, zoom_ratio, surveying_mode, dewarp_flag, lens_override):
        diag_px = math.hypot(w, h)
        diag_35mm = 43.266615305567875  # hypot(36, 24)
        model_up = (model or '').upper().strip()
        make_up = (make or '').upper().strip()
        src_low = (source or '').lower()

        if lens_override in ('Wide', 'Force Wide'):
            prof = MetadataParser.DJI_WIDE_PROFILES.get(model_up, {'dewarped': 0.7632})
            return w * prof['dewarped'] * max(1.0, zoom_ratio)
        if lens_override in ('Zoom', 'Force Zoom'):
            return w * 4.66 * max(1.0, zoom_ratio)

        # 1. Thermal / IR sensors (e.g. 640x512 or 1280x1024 on M3T / M4T / M30T / H20T)
        if 'infrared' in src_low or 'thermal' in src_low or 'ir' == src_low or w <= 1280:
            if focal_35mm > 0:
                eff_z = MetadataParser._effective_zoom(zoom_ratio, focal_35mm, 40.0)
                return (focal_35mm / diag_35mm) * diag_px * eff_z
            return w * 1.155 * max(1.0, zoom_ratio)

        # 2. Tele & Medium-Tele optical cameras (detected via 35mm-eq >= 55mm or physical focal >= 18mm)
        if focal_35mm >= 55.0 or focal_mm >= 18.0:
            if focal_35mm > 0:
                base_f35 = 70.0 if focal_35mm < 115.0 else 162.0
                eff_z = MetadataParser._effective_zoom(zoom_ratio, focal_35mm, base_f35)
                return (focal_35mm / diag_35mm) * diag_px * eff_z
            return w * 4.66 * max(1.0, zoom_ratio)

        # 3. Known DJI Enterprise Wide cameras (M3E, M3M, M3T, M4E, M4T, M30, M30T)
        for key, prof in MetadataParser.DJI_WIDE_PROFILES.items():
            if key in model_up:
                is_raw = (dewarp_flag == 0) or (surveying_mode == 1 and dewarp_flag is None)
                mult = prof['raw'] if is_raw else prof['dewarped']
                eff_z = MetadataParser._effective_zoom(zoom_ratio, focal_35mm, prof['base_f35'])
                return w * mult * eff_z

        # 4. Universal EXIF FocalLengthIn35mmFilm fallback (other DJI / Autel / consumer drones)
        if focal_35mm > 0:
            eff_z = zoom_ratio
            if zoom_ratio > 1.01 and focal_mm > 0:
                # Typical crop factor for 1" to 1/2.3" drone sensors is 2.7x..5.6x; if f35/fmm > 7.5, f35 was already zoomed
                if (focal_35mm / focal_mm) > 7.5:
                    eff_z = 1.0
            fx_pinhole = (focal_35mm / diag_35mm) * diag_px * eff_z
            # DJI wide lenses (<=26mm eq) in normal dewarped mode crop ~8.8% inward when removing barrel distortion
            if 'DJI' in make_up and focal_35mm <= 26.0 and dewarp_flag != 0:
                fx_pinhole *= 1.092
            return fx_pinhole

        # 5. Last-resort resolution heuristic
        base_mult = 0.7632 if w >= 5000 else 0.755
        return w * base_mult * max(1.0, zoom_ratio)

    @staticmethod
    def extract_xmp(image_path, dist_offsets=None, lens_override=None):
        with open(image_path, 'rb') as f:
            head_bytes = f.read(524288)

        xmp_start = head_bytes.find(b'<x:xmpmeta')
        xmp_end = head_bytes.find(b'</x:xmpmeta>')
        has_xmp_block = (xmp_start != -1 and xmp_end != -1)

        if has_xmp_block:
            header_data = head_bytes[xmp_start:xmp_end + 12].decode('utf-8', errors='ignore')
        else:
            header_data = ''

        exif_tags = read_exif_tags(image_path)

        telemetry = {}
        xmp_patterns = {
            'yaw': r'GimbalYawDegree[=">]+([-+\d\.]+)',
            'pitch': r'GimbalPitchDegree[=">]+([-+\d\.]+)',
            'roll': r'GimbalRollDegree[=">]+([-+\d\.]+)',
            'abs_alt': r'AbsoluteAltitude[=">]+([-+\d\.]+)',
            'rel_alt': r'RelativeAltitude[=">]+([-+\d\.]+)',
            'lat': r'GpsLatitude[=">]+([-+\d\.]+)',
            'lon': r'GpsLongitude[=">]+([-+\d\.]+)',
            'model': r'(?:DroneModel|tiff:Model|Model)[=">]+([^<\"]+)',
            'source': r'ImageSource[=">]+([^<\"]+)',
            'gps_status': r'GpsStatus[=">]+([^<\"]+)',
            'alt_type': r'AltitudeType[=">]+([^<\"]+)',
            'surveying_mode': r'SurveyingMode[=">]+([\d]+)',
            'dewarp_flag': r'DewarpFlag[=">]+([\d]+)',
            'cal_f': r'CalibratedFocalLength[=">]+([\d\.]+)',
            'cal_cx': r'CalibratedOpticalCenterX[=">]+([\d\.]+)',
            'cal_cy': r'CalibratedOpticalCenterY[=">]+([\d\.]+)',
        }

        found_keys = set()
        for key, pattern in xmp_patterns.items():
            match = re.search(pattern, header_data)
            if match:
                found_keys.add(key)
                val = match.group(1).strip()
                if key in ('model', 'source', 'gps_status', 'alt_type'):
                    telemetry[key] = val
                elif key in ('surveying_mode', 'dewarp_flag'):
                    try:
                        telemetry[key] = int(val)
                    except ValueError:
                        telemetry[key] = None
                else:
                    try:
                        telemetry[key] = float(val)
                    except ValueError:
                        telemetry[key] = 0.0
            else:
                if key in ('model', 'source', 'gps_status', 'alt_type'):
                    telemetry[key] = 'Unknown'
                elif key in ('surveying_mode', 'dewarp_flag', 'cal_f', 'cal_cx', 'cal_cy'):
                    telemetry[key] = None
                else:
                    telemetry[key] = 0.0

        # Fallbacks from binary EXIF when XMP tags are missing (e.g. consumer DJI drones)
        if telemetry['model'] == 'Unknown' and exif_tags.get('model'):
            telemetry['model'] = exif_tags['model']
        telemetry['make'] = exif_tags.get('make', 'DJI' if has_xmp_block else '')

        if 'lat' not in found_keys and 'gps_lat' in exif_tags:
            telemetry['lat'] = exif_tags['gps_lat']
        if 'lon' not in found_keys and 'gps_lon' in exif_tags:
            telemetry['lon'] = exif_tags['gps_lon']
        if 'abs_alt' not in found_keys and 'gps_alt' in exif_tags:
            telemetry['abs_alt'] = exif_tags['gps_alt']
            found_keys.add('abs_alt')

        telemetry['has_abs_alt'] = ('abs_alt' in found_keys)
        telemetry['has_rel_alt'] = ('rel_alt' in found_keys)

        # RTK vs Non-RTK classification
        alt_type_str = str(telemetry.get('alt_type', '')).lower()
        gps_status_str = str(telemetry.get('gps_status', '')).upper()
        telemetry['is_rtk'] = ('rtk' in alt_type_str) or ('RTK' in gps_status_str)

        # Maintain legacy 'rtk_alt' key for compatibility
        if telemetry['has_abs_alt']:
            telemetry['rtk_alt'] = telemetry['abs_alt']
        elif telemetry['has_rel_alt']:
            telemetry['rtk_alt'] = telemetry['rel_alt']
        else:
            telemetry['rtk_alt'] = 0.0

        # Detect if image was already projected by MavicProjector
        base_lower = os.path.basename(image_path).lower()
        already_flag = ('AlreadyProjected="True"' in header_data) or (
            '_projected.' in base_lower and not has_xmp_block and 'gps_lat' not in exif_tags
        )
        telemetry['already_projected'] = already_flag

        # Zoom & EXIF focal lengths
        zoom_ratio = exif_tags.get('zoom_ratio')
        if zoom_ratio is None:
            match_zoom = re.search(r'DigitalZoomRatio[=">]+([\d\.]+)', header_data)
            zoom_ratio = float(match_zoom.group(1)) if match_zoom else 1.0
        if zoom_ratio <= 0.0:
            zoom_ratio = 1.0
        telemetry['zoom_ratio'] = zoom_ratio
        telemetry['focal_mm'] = exif_tags.get('focal_mm', 0.0)
        telemetry['focal_35mm'] = exif_tags.get('focal_35mm', 0.0)

        # Image dimensions
        img = QImage(image_path)
        w, h = img.width(), img.height()
        if w <= 0 or h <= 0:
            w = exif_tags.get('exif_w', 5280)
            h = exif_tags.get('exif_h', 3956)
        telemetry['img_w'] = w
        telemetry['img_h'] = h

        base_cx = telemetry['cal_cx'] if telemetry['cal_cx'] else (w / 2.0)
        base_cy = telemetry['cal_cy'] if telemetry['cal_cy'] else (h / 2.0)

        parsed_matrix = False
        match_dewarp = re.search(r'DewarpData[=">]+([\d\.\,\;\-\+]+)', header_data)

        if match_dewarp and lens_override not in ('Wide', 'Zoom', 'Force Wide', 'Force Zoom'):
            parts = match_dewarp.group(1).replace(';', ',').split(',')
            try:
                fx, fy = float(parts[1]), float(parts[2])
                raw_cx, raw_cy = float(parts[3]), float(parts[4])
                k1 = float(parts[5]) if len(parts) > 5 else 0.0
                k2 = float(parts[6]) if len(parts) > 6 else 0.0
                p1 = float(parts[7]) if len(parts) > 7 else 0.0
                p2 = float(parts[8]) if len(parts) > 8 else 0.0
                k3 = float(parts[9]) if len(parts) > 9 else 0.0

                if fx > 100.0 and fy > 100.0:
                    # DJI DewarpData cx, cy are pixel offsets from the calibrated/image center
                    cx = (base_cx + raw_cx) if abs(raw_cx) < (w * 0.25) else raw_cx
                    cy = (base_cy + raw_cy) if abs(raw_cy) < (h * 0.25) else raw_cy
                    if not (0.0 < cx < w) or not (0.0 < cy < h):
                        cx, cy = w / 2.0, h / 2.0

                    dewarp_flag = telemetry.get('dewarp_flag')
                    if dewarp_flag == 0:
                        # Image is NOT dewarped: apply factory lens distortion coefficients
                        dist_arr = np.array([[k1], [k2], [p1], [p2], [k3]], dtype=np.float64)
                        telemetry['has_dewarp'] = False
                    else:
                        # Image was already flattened in camera
                        dist_arr = np.zeros((5, 1), dtype=np.float64)
                        telemetry['has_dewarp'] = True

                    telemetry['camera_matrix'] = np.array(
                        [[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64
                    )
                    telemetry['dist_coeffs'] = dist_arr
                    telemetry['fx_px'] = fx
                    telemetry['fy_px'] = fy
                    parsed_matrix = True
            except Exception:
                pass

        if not parsed_matrix:
            fx = MetadataParser._compute_fallback_focal_px(
                w=w,
                h=h,
                model=telemetry.get('model', ''),
                make=telemetry.get('make', ''),
                source=telemetry.get('source', ''),
                focal_mm=telemetry['focal_mm'],
                focal_35mm=telemetry['focal_35mm'],
                zoom_ratio=zoom_ratio,
                surveying_mode=telemetry.get('surveying_mode'),
                dewarp_flag=telemetry.get('dewarp_flag'),
                lens_override=lens_override,
            )
            fy = fx
            cx, cy = base_cx, base_cy
            telemetry['has_dewarp'] = (telemetry.get('dewarp_flag') != 0)
            telemetry['camera_matrix'] = np.array(
                [[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64
            )
            telemetry['dist_coeffs'] = np.zeros((5, 1), dtype=np.float64)
            telemetry['fx_px'] = fx
            telemetry['fy_px'] = fy

        if dist_offsets:
            telemetry['dist_coeffs'][0][0] += float(dist_offsets.get('k1', 0.0))
            telemetry['dist_coeffs'][1][0] += float(dist_offsets.get('k2', 0.0))
            telemetry['dist_coeffs'][2][0] += float(dist_offsets.get('p1', 0.0))
            telemetry['dist_coeffs'][3][0] += float(dist_offsets.get('p2', 0.0))
            telemetry['dist_coeffs'][4][0] += float(dist_offsets.get('k3', 0.0))

        telemetry['auto_geoid'] = MetadataParser.calculate_est_geoid(telemetry['lat'], telemetry['lon'])
        return telemetry
