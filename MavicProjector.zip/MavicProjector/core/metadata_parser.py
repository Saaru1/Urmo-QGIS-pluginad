import os
import re
import numpy as np
from qgis.PyQt.QtGui import QImage

class MetadataParser:
    @staticmethod
    def calculate_est_geoid(lat, lon):
        n_value = 18.0 + (lat - 58.5) * 2.5 - (lon - 24.5) * 1.5
        return -round(n_value, 2)

    @staticmethod
    def extract_xmp(image_path, dist_offsets=None, lens_override=None):
        with open(image_path, 'rb') as f:
            img_data = f.read()
            
        xmp_start = img_data.find(b'<x:xmpmeta')
        xmp_end = img_data.find(b'</x:xmpmeta>')
        
        if xmp_start != -1 and xmp_end != -1:
            header_data = img_data[xmp_start:xmp_end+12].decode('utf-8', errors='ignore')
        else:
            header_data = img_data.decode('utf-8', errors='ignore')
            
        telemetry = {}
        
        tags = {
            'yaw': r'GimbalYawDegree[=">]+([-+\d\.]+)',
            'pitch': r'GimbalPitchDegree[=">]+([-+\d\.]+)',
            'roll': r'GimbalRollDegree[=">]+([-+\d\.]+)',
            'rtk_alt': r'AbsoluteAltitude[=">]+([-+\d\.]+)',
            'lat': r'GpsLatitude[=">]+([-+\d\.]+)',
            'lon': r'GpsLongitude[=">]+([-+\d\.]+)',
            'model': r'Model[=">]+([^<\"]+)',
            'source': r'ImageSource[=">]+([^<\"]+)'  
        }
        
        for key, pattern in tags.items():
            match = re.search(pattern, header_data)
            if match:
                val = match.group(1)
                try: telemetry[key] = float(val)
                except ValueError: telemetry[key] = val.strip()
            else:
                telemetry[key] = 0.0 if key not in ['model', 'source'] else 'Unknown'

        # Safely extract RTK if available, fallback to RelativeAltitude
        if 'AbsoluteAltitude' not in header_data:
            match_rel = re.search(r'RelativeAltitude[=">]+([-+\d\.]+)', header_data)
            if match_rel: telemetry['rtk_alt'] = float(match_rel.group(1))

        zoom_ratio = 1.0
        match_zoom = re.search(r'DigitalZoomRatio[=">]+([\d\.]+)', header_data)
        if match_zoom: zoom_ratio = float(match_zoom.group(1))

        parsed_matrix = False
        match_dewarp = re.search(r'DewarpData[=">]+([\d\.\,\;-]+)', header_data)
        
        # THE HYBRID ZOOM FIX:
        # We MUST read fx and fy from DewarpData! DJI dynamically calculates these 
        # based on the exact zoom level (1x, 2x, 7x, 56x) used at the moment of capture.
        if match_dewarp and lens_override not in ['Wide', 'Zoom']:
            parts = match_dewarp.group(1).replace(';', ',').split(',')
            try:
                fx, fy = float(parts[1]), float(parts[2])
                cx, cy = float(parts[3]), float(parts[4])
                
                if fx > 100: 
                    img = QImage(image_path)
                    w, h = img.width(), img.height()
                    if w > 0:
                        if cx > w or cy > h:
                            cx, cy = w / 2.0, h / 2.0

                    # 1. Use DJI's perfectly calculated focal lengths to capture exact zoom levels
                    telemetry['camera_matrix'] = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.0]], dtype=np.float32)
                    
                    # 2. CRITICAL: Force distortions to zero because the JPEG is already flattened!
                    # This prevents the "diagonal creeping" scale error.
                    telemetry['dist_coeffs'] = np.array([[0.0], [0.0], [0.0], [0.0], [0.0]], dtype=np.float32)
                    telemetry['has_dewarp'] = True
                    parsed_matrix = True
            except Exception:
                pass

        if not parsed_matrix:
            telemetry['has_dewarp'] = False
            img = QImage(image_path)
            w, h = img.width(), img.height()
            if w == 0: 
                w, h = 5280, 3956 
                
            cx, cy = w / 2.0, h / 2.0
            
            # --- TRUE LENS DETECTION (THE BULLETPROOF FIX) ---
            # DJI's XMP tags (ImageSource="ZoomCamera") lie when using Hybrid Zoom between 1x and 6.9x.
            # It uses the 20MP Wide sensor but tags it as Zoom. It also strips DewarpData and FocalLength tags.
            # The ONLY ground truth is the physical image resolution.
            # Mavic 3E Wide Sensor = 5280x3956 (20MP) -> FOV multiplier ~ 0.71
            # Mavic 3E Tele Sensor = 4000x3000 (12MP) -> FOV multiplier ~ 4.5
            
            is_wide_sensor = (w > 5000)
            
            if lens_override == 'Wide':
                fx = fy = w * 0.71
            elif lens_override == 'Zoom':
                fx = fy = w * 4.5
            else: # Auto (From File)
                if is_wide_sensor:
                    fx = fy = w * 0.71
                else:
                    fx = fy = w * 4.5
            
            telemetry['camera_matrix'] = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.0]], dtype=np.float32)
            telemetry['dist_coeffs'] = np.array([[0.0], [0.0], [0.0], [0.0], [0.0]], dtype=np.float32)

        if dist_offsets:
            telemetry['dist_coeffs'][0][0] += dist_offsets.get('k1', 0.0)
            telemetry['dist_coeffs'][1][0] += dist_offsets.get('k2', 0.0)
            telemetry['dist_coeffs'][2][0] += dist_offsets.get('p1', 0.0)
            telemetry['dist_coeffs'][3][0] += dist_offsets.get('p2', 0.0)
            telemetry['dist_coeffs'][4][0] += dist_offsets.get('k3', 0.0)

        telemetry['auto_geoid'] = MetadataParser.calculate_est_geoid(telemetry['lat'], telemetry['lon'])
        return telemetry