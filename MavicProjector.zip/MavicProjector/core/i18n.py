"""
Centralized English (en) / Estonian (et) localization and live UI preferences manager.
Persists language and theme choices via QSettings and notifies open windows live.
"""
from ..compat_drone import QObject, QSettings, pyqtSignal


class _UIPrefsManager(QObject):
    languageChanged = pyqtSignal(str)
    themeChanged = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._settings = QSettings("MavicProjectorPlugin", "UI_Settings")
        self._lang = str(self._settings.value("ui_language", "en")).lower()
        if self._lang not in ("en", "et"):
            self._lang = "en"
        self._theme = str(self._settings.value("ui_theme", "dark")).lower()
        if self._theme not in ("dark", "light"):
            self._theme = "dark"

    @property
    def language(self):
        return self._lang

    def set_language(self, lang):
        lang = str(lang).lower()
        if lang not in ("en", "et") or lang == self._lang:
            return
        self._lang = lang
        self._settings.setValue("ui_language", lang)
        self.languageChanged.emit(lang)

    def toggle_language(self):
        self.set_language("et" if self._lang == "en" else "en")

    @property
    def theme(self):
        return self._theme

    def set_theme(self, theme):
        theme = str(theme).lower()
        if theme not in ("dark", "light") or theme == self._theme:
            return
        self._theme = theme
        self._settings.setValue("ui_theme", theme)
        self.themeChanged.emit(theme)

    def toggle_theme(self):
        self.set_theme("light" if self._theme == "dark" else "dark")


ui_prefs = _UIPrefsManager()


TR = {
    # --- Common / Header ---
    "app_title": ("Mavic Projector", "Mavic Projector"),
    "theme_dark": ("🌙 Dark", "🌙 Tume"),
    "theme_light": ("☀️ Light", "☀️ Hele"),
    "lang_toggle": ("🇪🇪 EST", "🇬🇧 ENG"),
    "lang_tooltip": ("Switch interface language (English / Estonian)", "Vaheta kasutajaliidese keelt (eesti / inglise)"),
    "theme_tooltip": ("Switch Dark / Light theme", "Vaheta tumeda / heleda teema vahel"),
    "btn_close": ("Close", "Sulge"),
    "btn_cancel": ("CANCEL", "KATKESTA"),
    "btn_reset": ("↺ Reset", "↺ Lähtesta"),
    "btn_reset_all": ("↺ Reset All", "↺ Lähtesta kõik"),
    "btn_apply": ("🔄 Apply Offsets", "🔄 Rakenda nihked"),
    "btn_apply_render": ("✅ Apply && Render", "✅ Rakenda ja arvuta"),
    "btn_save": ("Save", "Salvesta"),
    "yes": ("Yes", "Jah"),
    "no": ("No", "Ei"),

    # --- Dashboard (MavicDockPanel) ---
    "dock_title": ("Mavic Projector Dashboard", "Mavic Projector töölaud"),
    "tab_active_job": ("Active Job", "Aktiivne töö"),
    "tab_archive": ("Archive", "Arhiiv"),
    "sec_layers": ("1. Layers (Vectors & WMS)", "1. Kihid (vektorid ja WMS)"),
    "btn_add": ("+ Add", "+ Lisa"),
    "hint_layers": (
        "☑ = selected only • Double-click = Style / Sync",
        "☑ = ainult valitud • Topeltklõps = Stiil / Sünk",
    ),
    "btn_rem_layer": ("− Remove Selected Layer", "− Eemalda valitud kiht"),
    "sec_photos": ("2. Drone Photos (.JPG)", "2. Droonifotod (.JPG)"),
    "btn_browse_photos": ("+ Browse Photos...", "+ Vali fotod..."),
    "btn_rem_photo": ("− Remove", "− Eemalda"),
    "hint_photos": (
        "Drop .JPGs here  •  Double-click = Per-photo overrides",
        "Lohista .JPG failid siia  •  Topeltklõps = Foto eriseaded",
    ),
    "btn_open_viewer": ("👁️ Open Interactive Viewer", "👁️ Ava interaktiivne vaatur"),
    "btn_dump_xmp": ("📝 Dump XMP / EXIF", "📝 Salvesta XMP / EXIF"),
    "btn_show_cams": ("🗺️ Show Cameras on Map", "🗺️ Kuva kaamerad kaardil"),
    "btn_hide_cams": ("🗺️ Hide Cameras from Map", "🗺️ Peida kaamerad kaardilt"),
    "sec_global": ("3. Global Settings", "3. Globaalsed seaded"),
    "subtab_elev_pose": ("Elevation && Pose", "Kõrgus ja orientatsioon"),
    "subtab_distortion": ("Lens Distortion", "Objektiivi moonutus"),
    "lbl_fallback_z": ("Fallback Z (m):", "Varukõrgus Z (m):"),
    "lbl_elev_src": ("Elevation Source:", "Kõrgusmudel:"),
    "dem_dtm": ("Maa-amet DTM (Ground WCS)", "Maa-amet DTM (Maapind WCS)"),
    "dem_dsm": ("Maa-amet DSM (Trees/Roofs WCS)", "Maa-amet DSM (Kõrgusmudel WCS)"),
    "dem_none": ("None (Flat Fallback Z Only)", "Puudub (ainult tasane varukõrgus Z)"),
    "dem_project_prefix": ("Project DEM", "Projekti DEM"),
    "lbl_alt_mode": ("Altitude Mode:", "Kõrguse režiim:"),
    "alt_auto": ("Auto (RTK+Geoid / Rel+DEM)", "Automaatne (RTK+geoid / suhteline+DEM)"),
    "alt_rtk": ("RTK Ellipsoid + Geoid", "RTK ellipsoid + geoid"),
    "alt_rel": ("Relative Alt + Ground DEM", "Suhteline kõrgus + maapinna DEM"),
    "alt_msl": ("MSL Altitude (No Geoid)", "Merepinna kõrgus (geoidita)"),
    "chk_auto_geoid": ("Auto Geoid:", "Auto geoid:"),
    "lbl_pitch": ("Pitch (°):", "Kalle (°):"),
    "lbl_yaw": ("Yaw (°):", "Suund (°):"),
    "lbl_roll": ("Roll (°):", "Rull (°):"),
    "lbl_focal_pct": ("Focal (%):", "Fookus (%):"),
    "lbl_x_east": ("X East (m):", "X ida (m):"),
    "lbl_y_north": ("Y North (m):", "Y põhi (m):"),
    "sec_logs": ("4. Processing Logs", "4. Töötluse logi"),
    "progress_ready": ("%p% - Ready", "%p% - Valmis"),
    "progress_init": ("%p% - Initializing...", "%p% - Käivitan..."),
    "progress_done": ("100% - Finished!", "100% - Valmis!"),
    "btn_start_batch": ("▶ Start Batch Processing", "▶ Alusta pakktöötlust"),
    "btn_export_folder": ("💾 Save to Folder...", "💾 Salvesta kausta..."),
    "arch_header": ("Saved Processing Jobs", "Salvestatud töötlused"),
    "arch_hint": (
        "Every completed batch job is saved here automatically for one-click restore.",
        "Iga lõpetatud pakktöötlus salvestatakse siia automaatselt taastamiseks.",
    ),
    "btn_restore": ("📂 Restore", "📂 Taasta"),
    "btn_refresh": ("🔄 Refresh", "🔄 Värskenda"),
    "btn_del_job": ("🗑️ Delete Selected", "🗑️ Kustuta valitud"),
    "btn_del_all": ("🗑️ Delete All", "🗑️ Kustuta kõik"),

    # --- Photo Properties Dialog ---
    "dlg_photo_title": ("Photo Overrides: {name}", "Foto seaded: {name}"),
    "lbl_force_lens": ("Force Lens Type:", "Sunni objektiiv:"),
    "lens_auto": ("Auto (From File)", "Automaatne (failist)"),
    "lens_wide": ("Force Wide", "Sunni lainurk (Wide)"),
    "lens_zoom": ("Force Zoom", "Sunni suum (Zoom)"),
    "lbl_focal_zoom_scale": ("Focal / Zoom Scale (%):", "Fookuse / suumi skaala (%):"),
    "lbl_custom_pitch": ("Custom Pitch Offset (°):", "Kaldenurga nihe / Pitch (°):"),
    "lbl_custom_yaw": ("Yaw (Heading) Offset (°):", "Suunanurga nihe / Yaw (°):"),
    "lbl_custom_roll": ("Custom Roll Offset (°):", "Rullumisnurga nihe / Roll (°):"),
    "lbl_custom_k1": ("Radial Distortion (k1):", "Radiaalmoonutus (k1):"),
    "btn_clear_overrides": ("Clear Overrides", "Tühjenda seaded"),
    "btn_save_overrides": ("Save Overrides", "Salvesta seaded"),
    "meta_extracting": ("Extracting metadata...", "Loen metaandmeid..."),
    "meta_error": ("Could not read DJI XMP/EXIF metadata.", "DJI XMP/EXIF metaandmete lugemine ebaõnnestus."),
    "meta_warn_projected": ("⚠️ Already Projected Output Photo!", "⚠️ See foto on juba projitseeritud!"),

    # --- Layer Style Dialog ---
    "dlg_layer_title": ("Style & Labels: {name}", "Stiil ja sildid: {name}"),
    "chk_live_sync": ("🔗 Mirror QGIS Canvas Style Live", "🔗 Sünkrooni QGIS kihi stiiliga reaalajas"),
    "btn_sync_now": ("🔄 Sync Style Now", "🔄 Sünkrooni stiil"),
    "tab_symbology": ("Symbology", "Sümboloogia"),
    "tab_labels": ("Labels", "Sildid"),
    "lbl_line_color": ("Line / Point Color:", "Joone / punkti värv:"),
    "lbl_fill_color": ("Polygon Fill Color:", "Polügooni täitevärv:"),
    "lbl_opacity": ("Layer Opacity (%):", "Kihi läbipaistmatus (%):"),
    "lbl_line_width": ("Line Width (px):", "Joone laius (px):"),
    "lbl_point_size": ("Point Size (px):", "Punkti suurus (px):"),
    "chk_fade": ("Enable Atmospheric Depth Fading", "Luba kaugushägustus (sügavus)"),
    "lbl_z_offset": ("Vertical Z Offset (m):", "Vertikaalne Z-nihe (m):"),
    "chk_use_3dz": ("Use Feature 3D Z Coordinates (if layer has Z)", "Kasuta objekti 3D Z-koordinaate (kui olemas)"),
    "lbl_label_designer": ("<b>Label Designer:</b> Drag or double-click fields to insert.", "<b>Sildikujundaja:</b> Lohista või tee topeltklõps väljal lisamiseks."),
    "lbl_max_labels": ("Max Nearest Labels:", "Maks. lähimaid silte:"),
    "lbl_font_size": ("Font Size (px):", "Fondi suurus (px):"),
    "lbl_text_color": ("Text Color:", "Teksti värv:"),
    "lbl_halo_color": ("Halo Color:", "Kontuuri värv:"),
    "lbl_callout_w": ("Callout / Leader Width:", "Viitejoone laius:"),
    "btn_color": ("Color", "Värv"),
    "chk_shadow": ("Enable Directional Ground Shadow", "Luba suunatud maapinna vari"),
    "lbl_preset": ("Rendering Preset:", "Sildi stiil:"),
    "lbl_angle": ("Angle:", "Nurk:"),
    "lbl_dist": ("Dist:", "Kaugus:"),
    "lbl_blur": ("Blur:", "Hägusus:"),
    "btn_save_layer": ("Save Layer Settings", "Salvesta kihi seaded"),

    # --- Interactive Viewer ---
    "viewer_title": ("Interactive Viewer: {name}", "Interaktiivne vaatur: {name}"),
    "viewer_title_gallery": ("Interactive Viewer - Gallery Mode", "Interaktiivne vaatur – galerii"),
    "tool_pan": ("🤚 Pan", "🤚 Liiguta"),
    "tool_edit": ("↖️ Labels", "↖️ Sildid"),
    "tool_place": ("🏷️ Place", "🏷️ Aseta"),
    "tool_pin": ("📍 Pin", "📍 Nõel"),
    "tool_line": ("📏 Line", "📏 Joon"),
    "tool_poly": ("⬟ Poly", "⬟ Polügoon"),
    "tool_remove": ("🗑️ Erase", "🗑️ Kustuta"),
    "tool_tie": ("🔗 Tie Pt", "🔗 Tugipunkt"),
    "tool_horizon": ("🌅 Horizon", "🌅 Horisont"),
    "tool_drag_align": ("✥ Drag Align", "✥ Joonda"),
    "tool_recalc": ("🔄 Render", "🔄 Arvuta"),
    "chk_show_all_drawn": ("All photos", "Kõigil fotodel"),
    "tip_show_all_drawn": ("Show user-drawn features across ALL photos", "Kuva joonistatud objekte KÕIGIL fotodel"),
    "btn_undo": ("↩ Undo", "↩ Tagasi"),
    "btn_redo": ("↪ Redo", "↪ Edasi"),
    "btn_clear_photo": ("🗑️ Clear", "🗑️ Tühjenda"),
    "tab_raw_photo": ("1. Raw Original Photo", "1. Algne toorfoto"),
    "tab_proj_photo": ("2. Projected Vectors", "2. Projitseeritud kihid"),
    "tab_proj_missing": ("2. Projected Vectors (Not Rendered)", "2. Projitseeritud kihid (puudub)"),
    "side_tab_labels": ("Labels", "Sildid"),
    "side_tab_draw": ("Draw", "Joonista"),
    "side_tab_align": ("Calibrate", "Kalibreeri"),
    "side_tab_drag_align": ("Drag Align", "Joonda"),
    "btn_tog_labels": ("👁️ Labels", "👁️ Sildid"),
    "btn_tog_shadows": ("🌘 Shadows", "🌘 Varjud"),
    "btn_tog_callouts": ("📏 Callouts", "📏 Viitejooned"),
    "lbl_active_layer": ("Active Layer:", "Aktiivne kiht:"),
    "lbl_expr_hint": ("Label Expression (Double-click field):", "Sildi avaldis (topeltklõps väljal):"),
    "btn_fast_refresh": ("⚡ Refresh Labels Only", "⚡ Värskenda ainult silte"),
    "lbl_manual_title": ("Camera Pose & Lens Overrides", "Kaamera asendi ja objektiivi nihked"),
    "btn_open_drag_align": ("✥ Open Interactive Drag Align Window...", "✥ Ava interaktiivne joondusaken..."),
    "lbl_tie_title": ("Georeferencer Tie Points", "Georefereerija tugipunktid"),
    "chk_refine_focal": ("Refine Zoom/Focal in IMU Solve (≥3 pts)", "Täpsusta ka suumi/fookust IMU lahenduses (≥3 p)"),
    "btn_calc_xy": ("Calibrate XY", "Kalibreeri XY"),
    "btn_calc_imu": ("Calibrate IMU", "Kalibreeri IMU"),
    "btn_calc_3d": ("Full 3D", "Täis-3D"),
    "lbl_export_title": ("Export Projected Image", "Ekspordi projitseeritud pilt"),
    "btn_exp_curr": ("💾 Save Current", "💾 Salvesta praegune"),
    "btn_exp_all": ("💾 Batch Save All", "💾 Salvesta kõik"),
    "hint_edit": (
        "↖️ Drag labels to reposition. Click a label to reveal its anchor handle. Right-click for color/size.",
        "↖️ Lohista silte ümberpaigutamiseks. Klõpsa sildil ankru nägemiseks. Paremklõps muudab värvi/suurust.",
    ),
    "hint_place": (
        "🏷️ Click near a vector feature to restore or place its label directly under your mouse.",
        "🏷️ Klõpsa vektorobjekti lähedal, et silt otse kursori alla taastada või asetada.",
    ),
    "hint_pin": (
        "📍 Left-click to drop a Pin. Click & drag to set directional arrow.",
        "📍 Vasakklõps lisab nõela. Klõpsa ja lohista suunanoole määramiseks.",
    ),
    "hint_line": (
        "📏 Left-click to add vertices. Right-click to finish line.",
        "📏 Vasakklõps lisab sõlmpunkte. Paremklõps lõpetab joone.",
    ),
    "hint_poly": (
        "⬟ Left-click to add vertices. Right-click to finish polygon.",
        "⬟ Vasakklõps lisab sõlmpunkte. Paremklõps lõpetab polügooni.",
    ),
    "hint_remove": (
        "🗑️ Left-click a drawn feature or label to delete/hide it.",
        "🗑️ Vasakklõps joonistatud objektil või sildil kustutab/peidab selle.",
    ),
    "hint_tie": (
        "🔗 TIE POINT: Click a distinct landmark on the photo, then click the matching point on the QGIS map.",
        "🔗 TUGIPUNKT: Klõpsa selgel orientiiril fotol, seejärel samal punktil QGIS kaardil.",
    ),
    "hint_horizon_1": (
        "🌅 HORIZON ALIGN: Click 2 points along a visible sea or distant flat horizon to lock Pitch & Roll.",
        "🌅 HORISONDI JOONDUS: Klõpsa 2 punkti nähtaval mere- või tasasel horisondil Pitch ja Roll lukustamiseks.",
    ),
    "hint_horizon_2": (
        "🌅 HORIZON ALIGN: Now click a second point far across the horizon.",
        "🌅 HORISONDI JOONDUS: Klõpsa nüüd teisel punktil kaugemal horisondil.",
    ),
    "hint_drag_align": (
        "✥ DRAG ALIGN: Select an alignment plane in the Drag Align tab and left-drag directly on the photo.",
        "✥ JOONDAMINE: Vali 'Joonda' vahekaardil joondustasand ja lohista vasaku nupuga otse fotol.",
    ),

    # --- Drag Align Panel ---
    "da_title": ("Interactive Drag Align", "Interaktiivne joondamine"),
    "da_subtitle": (
        "Choose a plane below, then left-drag directly on the photo (all visible features are highlighted as a live wireframe).",
        "Vali allpool tasand ning lohista vasaku nupuga fotol (kõik vaates olevad objektid kuvatakse reaalajas abijoontena).",
    ),
    "da_sec_mode": ("1. Alignment Plane (Left-Drag on Photo)", "1. Joondustasand (lohista fotol)"),
    "da_mode_pan": ("✥ Pan (Yaw && Pitch)", "✥ Nihuta (Yaw/Pitch)"),
    "da_mode_fpitch": ("⤢ Forward Pitch", "⤢ Edasikalle"),
    "da_mode_roll": ("↻ Roll (Rotate)", "↻ Rullumine (Roll)"),
    "da_mode_focal": ("🔍 Focal / Zoom", "🔍 Fookus / suum"),
    "da_mode_xy": ("📍 Ground XY", "📍 Maapinna XY"),
    "da_mode_horizon": ("🌅 2-Click Horizon", "🌅 2-klõpsu horisont"),
    "da_desc_pan": (
        "Left-drag Left/Right to rotate camera Yaw (heading) and Up/Down to aim Pitch up or down.",
        "Lohista vasakule/paremale kaamera suuna (Yaw) muutmiseks ja üles/alla kalde (Pitch) suunamiseks.",
    ),
    "da_desc_fpitch": (
        "Left-drag Up/Down to tilt the projected ground plane forward or backward in 3D perspective while keeping the center of the photo anchored.",
        "Lohista üles/alla projitseeritud maapinnatasandi ette- või tahapoole kallutamiseks 3D-perspektiivis, hoides foto keskpunkti paigal.",
    ),
    "da_desc_roll": (
        "Left-drag around the photo center to rotate (roll) the projected plane clockwise or counter-clockwise.",
        "Lohista ümber foto keskpunkti, et projitseeritud tasandit päri- või vastupäeva pöörata (Roll).",
    ),
    "da_desc_focal": (
        "Left-drag Up/Down (or Ctrl+Scroll) to expand or shrink the overlay radially (adjusts camera focal length / zoom scale).",
        "Lohista üles/alla (või Ctrl+kerimine) kihi radiaalseks suurendamiseks/vähendamiseks (fookuskaugus / suum).",
    ),
    "da_desc_xy": (
        "Left-drag on the photo to slide the ground map coordinates horizontally in East/North meters.",
        "Lohista fotol, et nihutada kaardikoordinaate horisontaalselt ida/põhja meetrites.",
    ),
    "da_desc_horizon": (
        "Click 2 widely spaced points along a visible sea/flat horizon on the photo to automatically level Pitch and Roll.",
        "Klõpsa fotol kahel kaugel punktil piki nähtavat mere- või tasast horisonti, et automaatselt seada Pitch ja Roll.",
    ),
    "da_sec_sliders": ("2. Fine-Tuning Sliders", "2. Täppisliugurid"),
    "da_lbl_yaw": ("Yaw:", "Suund (Yaw):"),
    "da_lbl_pitch": ("Pitch:", "Kalle (Pitch):"),
    "da_lbl_fpitch": ("Fwd Pitch:", "Edasikalle:"),
    "da_lbl_roll": ("Roll:", "Rull (Roll):"),
    "da_lbl_focal": ("Focal:", "Fookus:"),
    "da_lbl_height": ("Height Z:", "Kõrgus Z:"),
    "da_lbl_xy": ("Shift XY:", "Nihe XY:"),
    "da_sec_wireframe": ("Wireframe Preview", "Abijoonte eelvaade"),
    "da_chk_show_wf": ("Wireframe", "Abijooned"),
    "da_chk_hide_baked": ("Hide old overlay while dragging", "Peida vana kiht lohistamisel"),
    "tip_hide_baked": (
        "Shows the clean raw photo underneath while you drag the live wireframe so ground landmarks stay clear",
        "Kuvab abijoonte liigutamise ajal all puhta algfoto, et maamärgid oleksid selgelt näha",
    ),
    "da_lbl_wf_color": ("Color:", "Värv:"),
    "da_lbl_wf_width": ("W:", "Joon:"),
    "da_shortcut_note": (
        "Tip: Right-Drag adjusts Roll • Ctrl+Wheel adjusts Focal % • Enter applies.",
        "Vihje: Paremklõps+lohistus = Roll • Ctrl+kerimine = fookus % • Enter rakendab.",
    ),

    # --- Unified Studio (v1.3+) ---
    "btn_toggle_left_hide": ("◀ Inputs", "◀ Paneel"),
    "btn_toggle_left_show": ("▶ Inputs", "▶ Paneel"),
    "tip_toggle_left": (
        "Collapse or expand the left Photos & Layers panel for extra canvas space on laptop screens",
        "Ahenda või ava vasak fotode ja kihtide paneel lisaruumi saamiseks sülearvuti ekraanil",
    ),
    "btn_horizon_menu": ("🌅 Horizon ▾", "🌅 Horisont ▾"),
    "tip_horizon_menu": (
        "Horizon leveling: 1-Click Auto-Detect Horizon or 2-Click Horizon Line",
        "Horisondi joondamine: 1-klõpsu automaatne tuvastus või 2-klõpsu horisondijoon",
    ),
    "act_auto_horizon": ("🪄 Auto-Detect Horizon (1-Click)", "🪄 Tuvasta horisont automaatselt (1 klõps)"),
    "act_manual_horizon": ("🌅 2-Click Horizon Line", "🌅 2-klõpsu horisondijoon"),
    "studio_title": ("Mavic Projector Studio", "Mavic Projector stuudio"),
    "studio_title_photo": ("Mavic Projector Studio — {name}", "Mavic Projector stuudio — {name}"),
    "left_tab_project": ("Project", "Projekt"),
    "left_tab_archive": ("Archive", "Arhiiv"),
    "sec_studio_photos": ("1. Drone Photos (.JPG)", "1. Droonifotod (.JPG)"),
    "sec_studio_layers": ("2. QGIS Layers", "2. QGIS kihid"),
    "sec_studio_terrain": ("3. Terrain & Range", "3. Kõrgusmudel ja ulatus"),
    "lbl_max_dist": ("Max Distance (km):", "Maks. kaugus (km):"),
    "btn_overlay_toggle": ("👁️ Overlay", "👁️ Kihid"),
    "tip_overlay_toggle": (
        "Show/hide projected layers & labels (or hold Space to peek at raw photo)",
        "Kuva/peida projitseeritud kihid ja sildid (või hoia tühikut algfoto nägemiseks)",
    ),
    "tool_auto_horizon": ("🪄 Auto-Horizon", "🪄 Auto-horisont"),
    "tip_auto_horizon": (
        "Automatically detect visible sky/sea horizon (including curved DewarpFlag=0) and level Pitch & Roll",
        "Tuvasta automaatselt nähtav horisont (sh kõver DewarpFlag=0) ning sea Pitch ja Roll",
    ),
    "da_btn_auto_horizon": ("🪄 Auto-Detect Horizon (1-Click)", "🪄 Tuvasta horisont automaatselt (1 klõps)"),
    "btn_copy_all_photos": ("📋 Apply Offsets to All Photos", "📋 Rakenda nihked kõigile fotodele"),
    "tip_copy_all_photos": (
        "Copy this photo's camera pose & lens offsets to every loaded photo",
        "Kopeeri selle foto kaamera asendi ja objektiivi nihked kõigile fotodele",
    ),
    "msg_copied_all": (
        "Applied current pose & lens offsets to all {n} photos.",
        "Praegused asendi ja objektiivi nihked rakendati kõigile ({n}) fotodele.",
    ),
    "msg_auto_horizon_ok": (
        "🪄 Auto-Horizon locked ({n} pts)! Pitch {dp:+.2f}°, Roll {dr:+.2f}°",
        "🪄 Auto-horisont lukustatud ({n} p)! Pitch {dp:+.2f}°, Roll {dr:+.2f}°",
    ),
    "msg_auto_horizon_none": (
        "No clear horizon detected in this photo. Use Drag Align (Forward Pitch) or Tie Points instead.",
        "Selget horisonti sellel fotol ei tuvastatud. Kasuta joondusakent (Edasisuunaline kalle) või tugipunkte.",
    ),
    "empty_canvas_hint": (
        "Drop .JPG drone photos on the left or click '+ Browse Photos...' to begin.",
        "Alustamiseks lohista vasakule .JPG droonifotod või klõpsa '+ Vali fotod...'.",
    ),
    "btn_export_curr": ("💾 Export Current...", "💾 Ekspordi praegune..."),
    "btn_batch_export_all": ("💾 Batch Export All...", "💾 Ekspordi kõik..."),
}


def tr(key, **kwargs):
    lang = ui_prefs.language
    pair = TR.get(key)
    if pair is None:
        text = key
    else:
        text = pair[1] if lang == "et" else pair[0]
    if kwargs:
        try:
            return text.format(**kwargs)
        except Exception:
            return text
    return text
