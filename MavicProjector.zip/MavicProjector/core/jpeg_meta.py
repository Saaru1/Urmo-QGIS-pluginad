"""
Pure-Python JPEG APP1 (EXIF + XMP) reader and lossless metadata preserver.
"""
import os
import struct


_TIFF_TYPE_SIZES = {
    1: 1,   # BYTE
    2: 1,   # ASCII
    3: 2,   # SHORT
    4: 4,   # LONG
    5: 8,   # RATIONAL
    6: 1,   # SBYTE
    7: 1,   # UNDEFINED
    8: 2,   # SSHORT
    9: 4,   # SLONG
    10: 8,  # SRATIONAL
}


def _decode_tiff_value(tiff, endian, val_type, count, inline_bytes):
    size = _TIFF_TYPE_SIZES.get(val_type)
    if size is None or count <= 0:
        return None
    total = size * count
    if total <= 4:
        raw = inline_bytes[:total]
    else:
        off = struct.unpack(endian + 'I', inline_bytes)[0]
        if off + total > len(tiff):
            return None
        raw = tiff[off:off + total]

    if val_type == 2:  # ASCII
        return raw.rstrip(b'\x00').decode('utf-8', errors='ignore').strip()
    if val_type == 1:
        vals = list(raw)
    elif val_type == 3:
        vals = struct.unpack(endian + f'{count}H', raw)
    elif val_type == 4:
        vals = struct.unpack(endian + f'{count}I', raw)
    elif val_type == 9:
        vals = struct.unpack(endian + f'{count}i', raw)
    elif val_type == 5:
        pairs = struct.unpack(endian + f'{count * 2}I', raw)
        vals = [
            (pairs[2 * i] / pairs[2 * i + 1]) if pairs[2 * i + 1] != 0 else 0.0
            for i in range(count)
        ]
    elif val_type == 10:
        pairs = struct.unpack(endian + f'{count * 2}i', raw)
        vals = [
            (pairs[2 * i] / pairs[2 * i + 1]) if pairs[2 * i + 1] != 0 else 0.0
            for i in range(count)
        ]
    else:
        return raw

    return vals[0] if count == 1 else tuple(vals)


def _parse_ifd(tiff, endian, offset):
    result = {}
    if offset + 2 > len(tiff):
        return result
    num_entries = struct.unpack(endian + 'H', tiff[offset:offset + 2])[0]
    pos = offset + 2
    for _ in range(num_entries):
        if pos + 12 > len(tiff):
            break
        tag, val_type, count = struct.unpack(endian + 'HHI', tiff[pos:pos + 8])
        inline_bytes = tiff[pos + 8:pos + 12]
        val = _decode_tiff_value(tiff, endian, val_type, count, inline_bytes)
        if val is not None:
            result[tag] = val
        pos += 12
    return result


def _dms_to_deg(dms, ref):
    if not isinstance(dms, (tuple, list)) or len(dms) < 3:
        return None
    deg = float(dms[0]) + float(dms[1]) / 60.0 + float(dms[2]) / 3600.0
    if str(ref).upper().startswith(('S', 'W')):
        deg = -deg
    return deg


def read_exif_tags(image_path):
    """Reads key camera and GPS EXIF tags directly from binary JPEG APP1 segments."""
    tags = {}
    try:
        with open(image_path, 'rb') as f:
            data = f.read(524288)
    except OSError:
        return tags

    if len(data) < 4 or data[:2] != b'\xff\xd8':
        return tags

    pos = 2
    n = len(data)
    while pos + 4 <= n:
        if data[pos] != 0xFF:
            break
        while pos < n and data[pos] == 0xFF:
            pos += 1
        if pos >= n:
            break
        marker = data[pos]
        pos += 1
        if marker in (0xDA, 0xD9):  # SOS or EOI
            break
        if marker == 0x00 or (0xD0 <= marker <= 0xD8):
            continue
        if pos + 2 > n:
            break
        seg_len = struct.unpack('>H', data[pos:pos + 2])[0]
        if seg_len < 2 or pos + seg_len > n:
            break
        seg = data[pos + 2:pos + seg_len]
        pos += seg_len

        if marker == 0xE1 and seg.startswith(b'Exif\x00\x00') and len(seg) >= 14:
            tiff = seg[6:]
            bo = tiff[:2]
            endian = '<' if bo == b'II' else ('>' if bo == b'MM' else None)
            if not endian:
                continue
            magic, ifd0_off = struct.unpack(endian + 'HI', tiff[2:8])
            if magic != 42:
                continue
            ifd0 = _parse_ifd(tiff, endian, ifd0_off)
            if 0x010F in ifd0:
                tags['make'] = str(ifd0[0x010F])
            if 0x0110 in ifd0:
                tags['model'] = str(ifd0[0x0110])
            if 0x0112 in ifd0 and isinstance(ifd0[0x0112], (int, float)):
                tags['orientation'] = int(ifd0[0x0112])

            exif_off = ifd0.get(0x8769)
            if isinstance(exif_off, int):
                exif_ifd = _parse_ifd(tiff, endian, exif_off)
                if 0x920A in exif_ifd and isinstance(exif_ifd[0x920A], (int, float)):
                    tags['focal_mm'] = float(exif_ifd[0x920A])
                if 0xA405 in exif_ifd and isinstance(exif_ifd[0xA405], (int, float)):
                    tags['focal_35mm'] = float(exif_ifd[0xA405])
                if 0xA404 in exif_ifd and isinstance(exif_ifd[0xA404], (int, float)):
                    zr = float(exif_ifd[0xA404])
                    if zr > 0.0:
                        tags['zoom_ratio'] = zr
                if 0xA002 in exif_ifd and isinstance(exif_ifd[0xA002], (int, float)):
                    tags['exif_w'] = int(exif_ifd[0xA002])
                if 0xA003 in exif_ifd and isinstance(exif_ifd[0xA003], (int, float)):
                    tags['exif_h'] = int(exif_ifd[0xA003])

            gps_off = ifd0.get(0x8825)
            if isinstance(gps_off, int):
                gps_ifd = _parse_ifd(tiff, endian, gps_off)
                lat = _dms_to_deg(gps_ifd.get(0x0002), gps_ifd.get(0x0001, 'N'))
                lon = _dms_to_deg(gps_ifd.get(0x0004), gps_ifd.get(0x0003, 'E'))
                if lat is not None and lon is not None:
                    tags['gps_lat'] = lat
                    tags['gps_lon'] = lon
                if 0x0006 in gps_ifd and isinstance(gps_ifd[0x0006], (int, float)):
                    alt = float(gps_ifd[0x0006])
                    alt_ref = gps_ifd.get(0x0005, 0)
                    if alt_ref == 1 or alt_ref == b'\x01':
                        alt = -alt
                    tags['gps_alt'] = alt
            break

    return tags


def _extract_app1_segments(jpeg_bytes):
    """Returns list of raw APP1 payload bytes (excluding FF E1 + 2B length) from a JPEG."""
    segments = []
    if len(jpeg_bytes) < 4 or jpeg_bytes[:2] != b'\xff\xd8':
        return segments
    pos = 2
    n = len(jpeg_bytes)
    while pos + 4 <= n:
        if jpeg_bytes[pos] != 0xFF:
            break
        while pos < n and jpeg_bytes[pos] == 0xFF:
            pos += 1
        if pos >= n:
            break
        marker = jpeg_bytes[pos]
        pos += 1
        if marker in (0xDA, 0xD9):
            break
        if marker == 0x00 or (0xD0 <= marker <= 0xD8):
            continue
        if pos + 2 > n:
            break
        seg_len = struct.unpack('>H', jpeg_bytes[pos:pos + 2])[0]
        if seg_len < 2 or pos + seg_len > n:
            break
        if marker == 0xE1:
            segments.append(jpeg_bytes[pos + 2:pos + seg_len])
        pos += seg_len
    return segments


def _inject_projected_flag(xmp_payload):
    """Adds MavicProjector:AlreadyProjected="True" into an APP1 XMP segment payload."""
    prefix = b'http://ns.adobe.com/xap/1.0/\x00'
    if not xmp_payload.startswith(prefix):
        return xmp_payload
    body = xmp_payload[len(prefix):]
    if b'AlreadyProjected="True"' in body:
        return xmp_payload
    target = b'<rdf:Description '
    idx = body.find(target)
    if idx != -1:
        attr = (
            b'xmlns:MavicProjector="http://keskkonnaamet.ee/mavicprojector/1.0/" '
            b'MavicProjector:AlreadyProjected="True" '
        )
        new_body = body[:idx + len(target)] + attr + body[idx + len(target):]
        candidate = prefix + new_body
        if len(candidate) + 2 <= 65535:
            return candidate
    return xmp_payload


def copy_jpeg_metadata(src_jpeg_path, dst_jpeg_path, mark_projected=True):
    """Losslessly copies EXIF and XMP APP1 segments from src_jpeg_path into dst_jpeg_path."""
    try:
        with open(src_jpeg_path, 'rb') as f:
            src_header = f.read(524288)
        app1_list = _extract_app1_segments(src_header)
        if not app1_list and not mark_projected:
            return False

        new_app1_chunks = []
        has_xmp = False
        xmp_prefix = b'http://ns.adobe.com/xap/1.0/\x00'
        for payload in app1_list:
            if payload.startswith(xmp_prefix):
                has_xmp = True
                if mark_projected:
                    payload = _inject_projected_flag(payload)
            if len(payload) + 2 <= 65535:
                new_app1_chunks.append(b'\xff\xe1' + struct.pack('>H', len(payload) + 2) + payload)

        if mark_projected and not has_xmp:
            minimal_xmp = (
                xmp_prefix
                + b'<x:xmpmeta xmlns:x="adobe:ns:meta/">'
                + b'<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
                + b'<rdf:Description rdf:about="" '
                + b'xmlns:MavicProjector="http://keskkonnaamet.ee/mavicprojector/1.0/" '
                + b'MavicProjector:AlreadyProjected="True"/>'
                + b'</rdf:RDF></x:xmpmeta>'
            )
            new_app1_chunks.append(b'\xff\xe1' + struct.pack('>H', len(minimal_xmp) + 2) + minimal_xmp)

        if not new_app1_chunks:
            return False

        with open(dst_jpeg_path, 'rb') as f:
            dst_bytes = f.read()

        if len(dst_bytes) < 4 or dst_bytes[:2] != b'\xff\xd8':
            return False

        # Keep SOI + leading APP0 (JFIF) if present; strip any existing APP1 in dst before SOS
        pos = 2
        n = len(dst_bytes)
        keep_prefix = bytearray(b'\xff\xd8')
        while pos + 4 <= n and dst_bytes[pos] == 0xFF:
            m_pos = pos
            while pos < n and dst_bytes[pos] == 0xFF:
                pos += 1
            if pos >= n:
                break
            marker = dst_bytes[pos]
            pos += 1
            if marker == 0xE0:  # APP0 (JFIF)
                seg_len = struct.unpack('>H', dst_bytes[pos:pos + 2])[0]
                keep_prefix.extend(dst_bytes[m_pos:pos + seg_len])
                pos += seg_len
            elif marker == 0xE1:  # Skip existing APP1 in dst
                seg_len = struct.unpack('>H', dst_bytes[pos:pos + 2])[0]
                pos += seg_len
            else:
                pos = m_pos
                break

        out_bytes = bytes(keep_prefix) + b''.join(new_app1_chunks) + dst_bytes[pos:]
        tmp_path = dst_jpeg_path + '.meta_tmp'
        with open(tmp_path, 'wb') as f:
            f.write(out_bytes)
        os.replace(tmp_path, dst_jpeg_path)
        return True
    except Exception:
        return False
