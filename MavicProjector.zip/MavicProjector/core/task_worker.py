import os
import time
import math
import cv2
import numpy as np

from qgis.core import QgsFeatureRequest, QgsMapSettings, QgsMapRendererSequentialJob, QgsRasterLayer
from qgis.PyQt.QtCore import QSize

from ..compat_drone import (
    QgsTask, QObject, pyqtSignal, QImage, QPainter, QPen, QColor, QRect, 
    AlignCenter, RenderHintAntialiasing, RoundCap, TaskCanCancel, QFont,
    QgsExpression, QgsExpressionContext, QgsExpressionContextUtils, QTransform,
    WkbPolygon, WkbMultiPolygon, WkbLineString, WkbMultiLineString, GeomPolygon,
    WkbPoint, WkbMultiPoint, QPainterPath,
    QBrush, QPolygonF, QPointF, NoPen, NoBrush, QgsGeometry, QgsPointXY, Format_ARGB32,
    SolidLine
)
from .metadata_parser import MetadataParser
from .math_engine import MathEngine

def clip_ring_to_near_plane(ring_3d, z_near=1.0):
    if not ring_3d: return []
    clipped = []
    for i in range(len(ring_3d)):
        p1 = ring_3d[i]
        p2 = ring_3d[(i + 1) % len(ring_3d)]
        z1, z2 = p1[2], p2[2]
        
        if z1 >= z_near:
            clipped.append(p1)
        
        if (z1 >= z_near > z2) or (z1 < z_near <= z2):
            t = (z_near - z1) / (z2 - z1)
            ix = p1[0] + t * (p2[0] - p1[0])
            iy = p1[1] + t * (p2[1] - p1[1])
            clipped.append([ix, iy, z_near])
    return clipped

def get_rect_intersection(rect_x, rect_y, rect_w, rect_h, line_x1, line_y1):
    cx = rect_x + rect_w / 2.0
    cy = rect_y + rect_h / 2.0
    dx = line_x1 - cx
    dy = line_y1 - cy
    if dx == 0 and dy == 0: return cx, cy
    x_scale = (rect_w / 2.0) / abs(dx) if dx != 0 else float('inf')
    y_scale = (rect_h / 2.0) / abs(dy) if dy != 0 else float('inf')
    scale = min(x_scale, y_scale)
    if scale >= 1.0: return line_x1, line_y1
    return cx + dx * scale, cy + dy * scale

class TaskSignals(QObject):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, str)
    max_progress_signal = pyqtSignal(int)
    eta_signal = pyqtSignal(str, float)

class ProjectionTask(QgsTask):
    def __init__(self, photo_items, layer_items, dem_layer, settings_dict, transform_context=None, interactive_mode=False):
        super().__init__("Mavic Batch Projection", TaskCanCancel)
        self.signals = TaskSignals()
        self.photo_items = photo_items
        self.layer_items = layer_items
        
        self.dem_uri = dem_layer.source() if dem_layer else None
        self.dem_name = dem_layer.name() if dem_layer else None
        self.dem_provider = dem_layer.providerType() if dem_layer else None
        
        self.global_settings = settings_dict
        self.transform_context = transform_context  
        self.exception = None
        
        self.interactive_mode = interactive_mode
        self.projected_labels_data = {} 

    def run(self):
        start_time = time.time()
        
        thread_dem = None
        if self.dem_uri:
            thread_dem = QgsRasterLayer(self.dem_uri, self.dem_name, self.dem_provider)
            if not thread_dem.isValid():
                thread_dem = None
        
        self.signals.max_progress_signal.emit(100) 
        
        total_photos = len(self.photo_items)
        total_layers = len(self.layer_items)
        features_processed = 0

        for idx, p_item in enumerate(self.photo_items):
            if self.isCanceled(): return False
                
            photo_path = p_item['path']
            overrides = p_item['overrides'] or {}
            label_offsets = overrides.get('label_offsets', {})
            
            active_pitch = overrides.get('pitch_offset', self.global_settings['pitch_offset'])
            active_yaw = overrides.get('yaw_offset', self.global_settings['yaw_offset'])
            active_geoid = overrides.get('geoid_offset', self.global_settings['geoid_offset'])
            active_x = overrides.get('x_offset', self.global_settings.get('x_offset', 0.0))
            active_y = overrides.get('y_offset', self.global_settings.get('y_offset', 0.0))
            
            active_dists = overrides.get('dist_offsets', self.global_settings.get('dist_offsets', {}))
            lens_override = overrides.get('lens_override', 'Auto (From File)')
            
            self.signals.log_signal.emit(f"\n--- Processing Photo {idx+1}/{len(self.photo_items)}: {os.path.basename(photo_path)} ---")
            
            try:
                tel = MetadataParser.extract_xmp(photo_path, active_dists, lens_override)
                
                geoid_source = "Manual Override"
                if active_geoid == 0.0:
                    active_geoid = tel.get('auto_geoid', -18.0)
                    geoid_source = "Auto-Calculated"
                    
                self.signals.log_signal.emit(f"   -> Geoid: {active_geoid}m ({geoid_source}) | Z-Fallback: {self.global_settings['fallback_z']}m")
                self.signals.log_signal.emit(f"   -> Pitch: {active_pitch}° | Yaw: {active_yaw}°")
                self.signals.log_signal.emit(f"   -> Map Shift: X {active_x:.2f}m, Y {active_y:.2f}m")
                
                engine = MathEngine(tel, active_geoid, active_yaw, active_pitch, transform_context=self.transform_context)
                engine.drone_pos[0] -= active_x
                engine.drone_pos[1] -= active_y
                
                self.signals.log_signal.emit("Preparing image canvas...")
                img = QImage(photo_path)
                if img.isNull(): raise ValueError(f"Could not load image: {photo_path}")
                    
                painter = QPainter(img)
                painter.setRenderHint(RenderHintAntialiasing)
                
                for l_idx, l_item in enumerate(self.layer_items):
                    layer = l_item['layer']
                    style = l_item['style']
                    selected_only = l_item['selected_only']
                    
                    is_raster = layer.type() == 1

                    opacity = style.get('opacity', 60 if is_raster else 100) / 100.0
                    
                    r, g, b, raw_a = style.get('color', (255, 255, 0, 255))
                    clamped_a = max(150, raw_a)  
                    base_color = (r, g, b, int(clamped_a * opacity))
                    
                    fr, fg, fb, fa = style.get('fill_color', (255, 255, 0, 0))
                    fill_color = (fr, fg, fb, int(fa * opacity))

                    raw_width = style.get('width', 6)
                    base_width = max(4, int(raw_width)) 
                    
                    pt_size = style.get('point_size', 10)
                    use_fade = style.get('fade', True)
                    
                    max_lbls = style.get('max_labels', 0)
                    font_size = style.get('font_size', 48)
                    lbl_c = style.get('label_color', (255,255,0,255))
                    halo_c = style.get('halo_color', (0,0,0,255))
                    
                    c_c = style.get('callout_color', (150, 150, 150, 200))
                    callout_color = QColor(c_c[0], c_c[1], c_c[2], c_c[3])
                    callout_width = style.get('callout_width', 2)
                    
                    use_shadow = style.get('shadow', False)
                    preset = style.get('preset', "Standard (Flat)")
                    shape_type = style.get('billboard_shape', "Rounded")
                    shadow_angle = style.get('light_angle', 45)
                    shadow_dist = style.get('shadow_dist', 15)
                    
                    self.signals.log_signal.emit(f"Projecting Layer: {layer.name()}...")
                    
                    if not is_raster:
                        _, fov_poly = engine.get_simple_map_polygons()
                        fov_geom = QgsGeometry.fromPolygonXY([[QgsPointXY(p.x(), p.y()) for p in fov_poly]])
                        
                        bbox = fov_geom.boundingBox()
                        nadir_radius = max(200.0, engine.drone_pos[2] * 2.0)
                        
                        from qgis.core import QgsRectangle
                        final_bbox = QgsRectangle(
                            min(bbox.xMinimum(), engine.drone_pos[0] - nadir_radius),
                            min(bbox.yMinimum(), engine.drone_pos[1] - nadir_radius),
                            max(bbox.xMaximum(), engine.drone_pos[0] + nadir_radius),
                            max(bbox.yMaximum(), engine.drone_pos[1] + nadir_radius)
                        )
                        
                        request = QgsFeatureRequest()
                        if not selected_only:
                            request.setFilterRect(final_bbox)
                        
                        features = list(layer.selectedFeatures()) if selected_only else list(layer.getFeatures(request))
                        
                        if not features: 
                            self.signals.log_signal.emit(f"   -> No features found in camera view. Skipping.")
                            continue
                        
                        projected_labels = []
                        lines_drawn = 0
                        
                        for f_idx, feature in enumerate(features):
                            if self.isCanceled(): 
                                painter.end()
                                del painter
                                return False
                            
                            geom = feature.geometry()
                            geom = geom.simplify(0.5) 

                            feature_2d_x = []
                            feature_2d_y = []
                            feature_z_sum = 0
                            lines_3d = []

                            if geom.wkbType() in [WkbPoint, WkbMultiPoint]:
                                pts = geom.asMultiPoint() if geom.isMultipart() else [geom.asPoint()]
                                pts_3d = engine.get_3d_camera_points(pts, self.global_settings['fallback_z'], thread_dem)
                                valid_3d = [p for p in pts_3d if p[2] >= 1.0]
                                
                                if valid_3d:
                                    proj_pts = engine.project_3d_to_2d_batch(valid_3d)
                                    for p_res in proj_pts:
                                        if p_res is None: continue
                                        x, y, z = p_res
                                        
                                        scale_factor = max(0.4, min(2.0, 50 / max(1, z))) if use_fade else 1.0
                                        rad = max(4, int((pt_size / 2.0) * scale_factor))
                                        
                                        painter.setPen(QPen(QColor(*base_color), max(2, int(base_width * scale_factor))))
                                        if base_color[3] > 0:
                                            painter.setBrush(QBrush(QColor(*base_color)))
                                        else:
                                            painter.setBrush(NoBrush)
                                            
                                        painter.drawEllipse(int(x - rad), int(y - rad), rad * 2, rad * 2)

                                        feature_2d_x.append(x)
                                        feature_2d_y.append(y)
                                        feature_z_sum += z
                                        lines_drawn += 1

                            elif geom.wkbType() in [WkbPolygon, WkbMultiPolygon]:
                                parts = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
                                for poly in parts:
                                    path = QPainterPath()
                                    has_fill_path = False
                                    for ring_idx, ring in enumerate(poly):
                                        ring_3d = engine.get_3d_camera_points(ring, self.global_settings['fallback_z'], thread_dem)
                                        lines_3d.append(ring_3d)
                                        
                                        if fill_color[3] > 0:
                                            clipped_3d = clip_ring_to_near_plane(ring_3d, 1.0)
                                            poly_pts = []
                                            if clipped_3d:
                                                proj_pts = engine.project_3d_to_2d_batch(clipped_3d)
                                                for p_res in proj_pts: 
                                                    if p_res is not None:
                                                        poly_pts.append(QPointF(p_res[0], p_res[1]))
                                                
                                            if len(poly_pts) > 2:
                                                path.addPolygon(QPolygonF(poly_pts))
                                                has_fill_path = True
                                                
                                    if fill_color[3] > 0 and has_fill_path:
                                        painter.setBrush(QBrush(QColor(*fill_color)))
                                        painter.setPen(QPen(QColor(0,0,0,0)))
                                        painter.drawPath(path)

                            elif geom.wkbType() in [WkbLineString, WkbMultiLineString]:
                                parts = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
                                for line in parts:
                                    lines_3d.append(engine.get_3d_camera_points(line, self.global_settings['fallback_z'], thread_dem))
                            
                            for line_3d in lines_3d:
                                calc_pts_1 = []
                                calc_pts_2 = []
                                
                                for i in range(len(line_3d) - 1):
                                    P1, P2 = line_3d[i], line_3d[i+1]
                                    Z1, Z2 = P1[2], P2[2]
                                    if Z1 < 1.0 and Z2 < 1.0: continue
                                        
                                    p1_calc, p2_calc = P1, P2
                                    if Z1 < 1.0:
                                        t = (1.0 - Z1) / (Z2 - Z1)
                                        p1_calc = [P1[0] + t*(P2[0]-P1[0]), P1[1] + t*(P2[1]-P1[1]), 1.0]
                                    elif Z2 < 1.0:
                                        t = (1.0 - Z2) / (Z1 - Z2)
                                        p2_calc = [P2[0] + t*(P1[0]-P2[0]), P2[1] + t*(P1[1]-P2[1]), 1.0]
                                        
                                    calc_pts_1.append(p1_calc)
                                    calc_pts_2.append(p2_calc)
                                    
                                if calc_pts_1:
                                    proj1 = engine.project_3d_to_2d_batch(calc_pts_1)
                                    proj2 = engine.project_3d_to_2d_batch(calc_pts_2)
                                    
                                    for j in range(len(proj1)):
                                        if proj1[j] is None or proj2[j] is None:
                                            continue
                                            
                                        x1, y1, z1 = proj1[j]
                                        x2, y2, z2 = proj2[j]
                                        
                                        feature_2d_x.extend([x1, x2])
                                        feature_2d_y.extend([y1, y2])
                                        feature_z_sum += (z1 + z2)
                                        
                                        w = base_width
                                        a = base_color[3]
                                        
                                        if use_fade:
                                            avg_z = (z1 + z2) / 2.0
                                            if avg_z > 300 and avg_z < 800:
                                                ratio = (avg_z - 300) / 500.0 
                                                w = int(max(2, base_width - (base_width * ratio)))
                                                a = int(max(min(150, base_color[3]), base_color[3] - (150 * ratio)))
                                            elif avg_z >= 800:
                                                w = 2
                                                a = min(150, base_color[3])
                                                
                                        pen = QPen(QColor(base_color[0], base_color[1], base_color[2], a))
                                        pen.setWidth(w)
                                        pen.setCapStyle(RoundCap) 
                                        painter.setPen(pen)
                                        painter.drawLine(x1, y1, x2, y2)
                                        lines_drawn += 1

                            if feature_2d_x:
                                screen_x = [x for x in feature_2d_x if -500 < x < img.width() + 500]
                                screen_y = [y for y in feature_2d_y if -500 < y < img.height() + 500]
                                
                                if screen_x and screen_y:
                                    cx = sum(screen_x) / len(screen_x)
                                    cy = sum(screen_y) / len(screen_y)
                                    cz = feature_z_sum / len(feature_2d_x)
                                    
                                    tx = max(50.0, min(float(img.width() - 50), cx))
                                    ty = max(50.0, min(float(img.height() - 50), cy))
                                    
                                    feature_key = f"{layer.id()}_{feature.id()}"
                                    saved_override = label_offsets.get(feature_key, {})
                                    
                                    if not saved_override.get("hidden", False):
                                        projected_labels.append({
                                            'fid': feature.id(),
                                            'anchor_x': tx,
                                            'anchor_y': ty,
                                            'cx_off': saved_override.get("cx_off", None),
                                            'cy_off': saved_override.get("cy_off", None),
                                            'adx': saved_override.get("adx", 0.0),
                                            'ady': saved_override.get("ady", 0.0),
                                            'color': saved_override.get("color"),
                                            'size': saved_override.get("size", 1.0),
                                            'z': cz
                                        })

                            features_processed += 1
                            
                            total_f = len(features)
                            p_frac = idx / total_photos if total_photos > 0 else 0
                            l_frac = l_idx / total_layers if total_layers > 0 else 0
                            f_frac = (f_idx + 1) / total_f if total_f > 0 else 1.0
                            overall_frac = p_frac + (1.0 / total_photos) * (l_frac + (1.0 / total_layers) * f_frac)
                            overall_percent = overall_frac * 100.0
                            self.setProgress(overall_percent)

                            # --- NEW ETA CALCULATION ---
                            elapsed = time.time() - start_time
                            if overall_frac > 0.02: # Wait until 2% to get a stable read
                                total_est = elapsed / overall_frac
                                eta_sec = total_est - elapsed
                                m, s = divmod(int(eta_sec), 60)
                                eta_str = f"ETA: {m}m {s}s" if eta_sec > 0 else "Almost done..."
                                self.signals.eta_signal.emit(f"%p% - {eta_str}", eta_sec)
                            else:
                                self.signals.eta_signal.emit("%p% - Calculating ETA...", 0.0)

                        if max_lbls > 0 and projected_labels:
                            projected_labels.sort(key=lambda item: item['z'])
                            projected_labels = projected_labels[:max_lbls]
                            
                            if self.interactive_mode:
                                self.projected_labels_data[layer.id()] = projected_labels
                                continue 
                            
                            halo_pen = QPen(QColor(halo_c[0], halo_c[1], halo_c[2], halo_c[3])) 
                            label_expr_str = style.get('label_expr', "")
                            occupied_rects = []
                            is_billboard = (preset == "Billboard (Stand-up)")
                            shape_type = style.get('billboard_shape', "Rounded")
                            
                            fids = [ld['fid'] for ld in projected_labels]
                            feature_dict = {f.id(): f for f in layer.getFeatures(QgsFeatureRequest().setFilterFids(fids))}
                            
                            for lbl in projected_labels:
                                feat = feature_dict.get(lbl['fid'])
                                if not feat: continue
                                
                                text = label_expr_str
                                if text:
                                    for fld in feat.fields():
                                        placeholder = f"[{fld.name()}]"
                                        if placeholder in text:
                                            val = feat.attribute(fld.name())
                                            text = text.replace(placeholder, str(val) if val is not None else "")
                                else:
                                    text = str(feat.attribute(0))
                                    
                                if not text.strip():
                                    continue
                                
                                anchor_x = lbl['anchor_x']
                                anchor_y = lbl['anchor_y']
                                
                                true_anchor_x = anchor_x + lbl['adx']
                                true_anchor_y = anchor_y + lbl['ady']
                                
                                custom_scale = lbl.get("size", 1.0)
                                custom_color_tup = lbl.get("color", None)
                                
                                fnt = QFont(painter.font().family(), int(font_size * custom_scale))
                                fnt.setBold(True)
                                painter.setFont(fnt)
                                fm = painter.fontMetrics()
                                
                                if custom_color_tup:
                                    text_pen = QPen(QColor(*custom_color_tup))
                                else:
                                    text_pen = QPen(QColor(lbl_c[0], lbl_c[1], lbl_c[2], lbl_c[3]))
                                
                                lines = text.split('\n')
                                th = len(lines) * fm.height() + 20
                                try:
                                    tw = max(fm.horizontalAdvance(line) for line in lines) + 40
                                except AttributeError:
                                    tw = max(fm.boundingRect(line).width() for line in lines) + 40
                                
                                cx_off = lbl.get("cx_off")
                                cy_off = lbl.get("cy_off")
                                
                                if cx_off is not None and cy_off is not None:
                                    cx = anchor_x + cx_off
                                    cy = anchor_y + cy_off
                                    final_rect = QRect(int(cx - tw/2), int(cy - th/2), int(tw), int(th))
                                else:
                                    placed = False
                                    cx = anchor_x
                                    if is_billboard:
                                        cy = anchor_y - max(15, abs(shadow_dist)) * custom_scale - th/2
                                    else:
                                        cy = anchor_y - th/2 - (15 * custom_scale)
                                        
                                    for radius in range(0, 1500, 50):
                                        for angle_deg in range(0, 360, 45):
                                            if radius == 0 and angle_deg > 0: continue
                                            
                                            rad = math.radians(angle_deg)
                                            test_cx = anchor_x + radius * math.cos(rad)
                                            test_cy = anchor_y + radius * math.sin(rad)
                                            
                                            test_cx = max(tw/2, min(img.width() - tw/2, test_cx))
                                            test_cy = max(th/2, min(img.height() - th/2, test_cy))
                                            
                                            test_rect = QRect(int(test_cx - tw/2), int(test_cy - th/2), int(tw), int(th))
                                            collision = any(test_rect.intersects(occ) for occ in occupied_rects)
                                            
                                            if not collision:
                                                cx, cy = test_cx, test_cy
                                                placed = True
                                                break
                                        if placed: break
                                        
                                    final_rect = QRect(int(cx - tw/2), int(cy - th/2), int(tw), int(th))
                                    
                                occupied_rects.append(final_rect.adjusted(-20, -20, 20, 20))
                                rect_x, rect_y = final_rect.x(), final_rect.y()
                                
                                if is_billboard:
                                    board_path = QPainterPath()
                                    if shape_type == "Rounded":
                                        board_path.addRoundedRect(rect_x, rect_y, tw, th, 15 * custom_scale, 15 * custom_scale)
                                    else:
                                        board_path.addRect(rect_x, rect_y, tw, th)
                                        
                                    dx = cx - true_anchor_x
                                    dy = cy - true_anchor_y
                                    dist = math.hypot(dx, dy)
                                    pole_path = QPainterPath()
                                    if dist > 0:
                                        nx, ny = -dy/dist, dx/dist
                                        pole_w = max(4, int(10 * custom_scale))
                                        w = pole_w / 2.0
                                        # Fix: Route pole connection to the nearest edge
                                        edge_x, edge_y = get_rect_intersection(rect_x, rect_y, tw, th, true_anchor_x, true_anchor_y)
                                        pole_path.addPolygon(QPolygonF([
                                            QPointF(true_anchor_x + nx*w, true_anchor_y + ny*w),
                                            QPointF(true_anchor_x - nx*w, true_anchor_y - ny*w),
                                            QPointF(edge_x - nx*w, edge_y - ny*w),
                                            QPointF(edge_x + nx*w, edge_y + ny*w)
                                        ]))
                                        
                                    shadow_path = QPainterPath()
                                    try:
                                        from ..compat_drone import Qt
                                        shadow_path.setFillRule(Qt.WindingFill)
                                    except Exception:
                                        pass
                                    shadow_path.addPath(pole_path)
                                    shadow_path.addPath(board_path)
                                    
                                    if use_shadow:
                                        painter.save() 
                                        transform = QTransform()
                                        transform.translate(true_anchor_x, true_anchor_y)
                                        safe_shear = math.cos(math.radians(shadow_angle)) * (abs(shadow_dist) / 30.0)
                                        transform.shear(safe_shear, 0.0)
                                        
                                        scale_y = -0.4 * (shadow_dist / 15.0)
                                        if abs(scale_y) < 0.01:
                                            scale_y = -0.01 if shadow_dist >= 0 else 0.01
                                        transform.scale(1.0, scale_y)
                                        
                                        transform.translate(-true_anchor_x, -true_anchor_y)
                                        painter.setTransform(transform, True)
                                        painter.setPen(QPen(QColor(0,0,0,0)))
                                        painter.setBrush(QBrush(QColor(0, 0, 0, 120)))
                                        painter.drawPath(shadow_path)
                                        painter.restore() 
                                        
                                    painter.setPen(QPen(QColor(0, 0, 0), max(2, int(4 * custom_scale))))
                                    painter.setBrush(QBrush(QColor(255, 255, 255)))
                                    
                                    # Again, the order is critical. Draw pole first.
                                    painter.drawPath(pole_path)
                                    painter.drawPath(board_path)
                                    text_pen = QPen(QColor(0, 0, 0))
                                    
                                else:
                                    if callout_width > 0:
                                        edge_x, edge_y = get_rect_intersection(rect_x, rect_y, tw, th, true_anchor_x, true_anchor_y)
                                        dist = math.hypot(edge_x - true_anchor_x, edge_y - true_anchor_y)
                                        if dist > 5:
                                            pole_pen = QPen(callout_color, max(1, int(callout_width * custom_scale)), SolidLine, RoundCap)
                                            painter.setPen(pole_pen)
                                            painter.drawLine(int(true_anchor_x), int(true_anchor_y), int(edge_x), int(edge_y))

                                    if use_shadow:
                                        painter.setPen(QPen(QColor(0, 0, 0, 150)))
                                        rad = math.radians(shadow_angle)
                                        sx = math.cos(rad) * shadow_dist
                                        sy = -math.sin(rad) * shadow_dist
                                        painter.drawText(final_rect.translated(int(sx), int(sy)), AlignCenter, text)

                                painter.setPen(halo_pen)
                                for o_dx, o_dy in [(-3,-3), (3,-3), (-3,3), (3,3), (0,-3), (0,3), (-3,0), (3,0)]:
                                    painter.drawText(final_rect.translated(o_dx, o_dy), AlignCenter, text)
                                    
                                painter.setPen(text_pen)
                                painter.drawText(final_rect, AlignCenter, text)
                                
                    else:
                        self.signals.log_signal.emit(f"   -> Initiating WMS Canvas Render...")
                        
                        _, fov_poly = engine.get_simple_map_polygons()
                        fov_geom = QgsGeometry.fromPolygonXY([[QgsPointXY(p.x(), p.y()) for p in fov_poly]])
                        
                        bbox = fov_geom.boundingBox()
                        nadir_radius = max(200.0, engine.drone_pos[2] * 2.0)
                        
                        from qgis.core import QgsRectangle
                        final_bbox = QgsRectangle(
                            min(bbox.xMinimum(), engine.drone_pos[0] - nadir_radius),
                            min(bbox.yMinimum(), engine.drone_pos[1] - nadir_radius),
                            max(bbox.xMaximum(), engine.drone_pos[0] + nadir_radius),
                            max(bbox.yMaximum(), engine.drone_pos[1] + nadir_radius)
                        )
                        
                        map_settings = QgsMapSettings()
                        map_settings.setLayers([layer])
                        map_settings.setExtent(final_bbox)
                        
                        job = QgsMapRendererSequentialJob(map_settings)
                        job.start()
                        job.waitForFinished()
                        
                        rendered_img = job.renderedImage()
                        if rendered_img.isNull():
                            continue
                            
                        rendered_img = rendered_img.convertToFormat(Format_ARGB32)
                        w, h = rendered_img.width(), rendered_img.height()
                        
                        b = rendered_img.bits()
                        b.setsize(h * w * 4)
                        arr = np.frombuffer(b, np.uint8).reshape((h, w, 4))
                        
                        z_val = self.global_settings['fallback_z']
                        tl = QgsPointXY(bbox.xMinimum(), bbox.yMaximum())
                        tr = QgsPointXY(bbox.xMaximum(), bbox.yMaximum())
                        bl = QgsPointXY(bbox.xMinimum(), bbox.yMinimum())
                        br = QgsPointXY(bbox.xMinimum(), bbox.yMinimum())
                        
                        corners_3d = engine.get_3d_camera_points([tl, tr, bl, br], z_val, thread_dem)
                        
                        valid_corners = [c for c in corners_3d if c[2] >= 1.0]
                        if len(valid_corners) == 4:
                            proj_pts = engine.project_3d_to_2d_batch(corners_3d)
                            if len(proj_pts) == 4:
                                dst_pts = np.array([
                                    [proj_pts[0][0], proj_pts[0][1]],
                                    [proj_pts[1][0], proj_pts[1][1]],
                                    [proj_pts[2][0], proj_pts[2][1]],
                                    [proj_pts[3][0], proj_pts[3][1]]
                                ], dtype=np.float32)
                                
                                src_pts = np.array([
                                    [0, 0], [w, 0], [0, h], [w, h]        
                                ], dtype=np.float32)
                                
                                H, _ = cv2.findHomography(src_pts, dst_pts)
                                if H is not None:
                                    warped = cv2.warpPerspective(arr, H, (img.width(), img.height()))
                                    
                                    warped_h, warped_w, _ = warped.shape
                                    qimg_warped = QImage(warped.data, warped_w, warped_h, warped.strides[0], Format_ARGB32)
                                    
                                    painter.setOpacity(opacity)
                                    painter.drawImage(0, 0, qimg_warped)
                                    painter.setOpacity(1.0)

                painter.end()
                
                if not self.interactive_mode:
                    out_dir = self.global_settings.get('out_folder', "")
                    base_name = os.path.basename(photo_path)
                    out_name = base_name.replace(".jpg", "_PROJECTED.jpg").replace(".JPG", "_PROJECTED.jpg")
                    out_path = os.path.join(out_dir, out_name)
                    img.save(out_path)
                    self.signals.log_signal.emit(f"💾 Saved to: {os.path.basename(out_path)}")
                else:
                    cache_dir = os.path.join(os.path.dirname(photo_path), ".mavic_cache")
                    os.makedirs(cache_dir, exist_ok=True)
                    out_path = os.path.join(cache_dir, os.path.basename(photo_path).replace(".jpg", "_TEMP.jpg"))
                    img.save(out_path)
                    
            except Exception as e:
                self.exception = e
                return False
                
        return True

    def finished(self, result):
        if result:
            self.signals.log_signal.emit("\n✅ Batch Processing Completed Successfully!")
            self.signals.finished_signal.emit(True, "")
        else:
            err = str(self.exception) if self.exception else "Canceled by user."
            self.signals.log_signal.emit(f"\n❌ Task Ended: {err}")
            self.signals.finished_signal.emit(False, err)