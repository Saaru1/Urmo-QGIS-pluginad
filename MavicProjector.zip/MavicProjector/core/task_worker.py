import math
import os
import time
import cv2
import numpy as np

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsMapRendererSequentialJob,
    QgsMapSettings,
    QgsRasterLayer,
    QgsRectangle,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QPointF, QRect, QSize

from ..compat_drone import (
    AlignCenter,
    Format_ARGB32,
    NoBrush,
    QBrush,
    QColor,
    QFont,
    QImage,
    QObject,
    QPainter,
    QPainterPath,
    QPen,
    QPointF as CompatPointF,
    QPolygonF,
    QTransform,
     QgsGeometry,
    QgsPointXY,
    QgsTask,
    RenderHintAntialiasing,
    RoundCap,
    SolidLine,
    TaskCanCancel,
    pyqtSignal,
)
from .dem_sampler import DEMSampler
from .jpeg_meta import copy_jpeg_metadata
from .math_engine import MathEngine
from .metadata_parser import MetadataParser


def is_point_in_frustum(pt, planes):
    x, y, z = float(pt[0]), float(pt[1]), float(pt[2])
    for a, b, c, d in planes:
        if a * x + b * y + c * z + d < -1e-9:
            return False
    return True


def _clip_ring_to_plane(ring_pts, plane):
    a, b, c, d = plane
    arr = np.asarray(ring_pts, dtype=np.float64)
    dists = a * arr[:, 0] + b * arr[:, 1] + c * arr[:, 2] + d
    if np.all(dists < 0.0):
        return []
    if np.all(dists >= 0.0):
        return ring_pts

    out = []
    n = len(ring_pts)
    for i in range(n):
        p1 = ring_pts[i]
        j = (i + 1) % n
        p2 = ring_pts[j]
        d1 = float(dists[i])
        d2 = float(dists[j])
        if d1 >= 0.0:
            out.append(p1)
        if (d1 >= 0.0 > d2) or (d1 < 0.0 <= d2):
            denom = d1 - d2
            if abs(denom) > 1e-12:
                t = d1 / denom
                out.append([
                    p1[0] + t * (p2[0] - p1[0]),
                    p1[1] + t * (p2[1] - p1[1]),
                    p1[2] + t * (p2[2] - p1[2]),
                ])
    return out


def clip_ring_to_frustum(ring_3d, planes):
    """Sutherland-Hodgman 3D polygon ring clipping against all camera frustum planes."""
    if ring_3d is None or len(ring_3d) < 3:
        return []
    pts = ring_3d
    for plane in planes:
        pts = _clip_ring_to_plane(pts, plane)
        if len(pts) < 3:
            return []
    return pts


def _clip_polyline_to_plane(line_pts, plane):
    a, b, c, d = plane
    arr = np.asarray(line_pts, dtype=np.float64)
    dists = a * arr[:, 0] + b * arr[:, 1] + c * arr[:, 2] + d
    if np.all(dists < 0.0):
        return []
    if np.all(dists >= 0.0):
        return [line_pts]

    segments = []
    current = []
    for i in range(len(line_pts) - 1):
        p1 = line_pts[i]
        p2 = line_pts[i + 1]
        d1 = float(dists[i])
        d2 = float(dists[i + 1])
        if d1 < 0.0 and d2 < 0.0:
            if len(current) >= 2:
                segments.append(current)
            current = []
            continue

        if d1 >= 0.0 and d2 >= 0.0:
            if not current:
                current.append(p1)
            current.append(p2)
        elif d1 < 0.0 <= d2:
            t = d1 / (d1 - d2)
            inter = [
                p1[0] + t * (p2[0] - p1[0]),
                p1[1] + t * (p2[1] - p1[1]),
                p1[2] + t * (p2[2] - p1[2]),
            ]
            if len(current) >= 2:
                segments.append(current)
            current = [inter, p2]
        else:  # d1 >= 0.0 > d2
            t = d1 / (d1 - d2)
            inter = [
                p1[0] + t * (p2[0] - p1[0]),
                p1[1] + t * (p2[1] - p1[1]),
                p1[2] + t * (p2[2] - p1[2]),
            ]
            if not current:
                current.append(p1)
            current.append(inter)
            if len(current) >= 2:
                segments.append(current)
            current = []

    if len(current) >= 2:
        segments.append(current)
    return segments


def clip_polyline_to_frustum(line_3d, planes):
    """Clips a 3D camera-space polyline against all frustum planes into visible contiguous sub-polylines."""
    if line_3d is None or len(line_3d) < 2:
        return []
    sublines = [line_3d]
    for plane in planes:
        next_sublines = []
        for sub in sublines:
            next_sublines.extend(_clip_polyline_to_plane(sub, plane))
        sublines = next_sublines
        if not sublines:
            return []
    return sublines


def clip_ring_to_near_plane(ring_3d, z_near=1.0):
    return clip_ring_to_frustum(ring_3d, [(0.0, 0.0, 1.0, -float(z_near))])


def clip_polyline_to_near_plane(line_3d, z_near=1.0):
    return clip_polyline_to_frustum(line_3d, [(0.0, 0.0, 1.0, -float(z_near))])


def get_rect_intersection(rect_x, rect_y, rect_w, rect_h, line_x1, line_y1):
    cx = rect_x + rect_w / 2.0
    cy = rect_y + rect_h / 2.0
    dx = line_x1 - cx
    dy = line_y1 - cy
    if dx == 0 and dy == 0:
        return cx, cy
    x_scale = (rect_w / 2.0) / abs(dx) if dx != 0 else float('inf')
    y_scale = (rect_h / 2.0) / abs(dy) if dy != 0 else float('inf')
    scale = min(x_scale, y_scale)
    if scale >= 1.0:
        return line_x1, line_y1
    return cx + dx * scale, cy + dy * scale


def _fill_invalid_border_cells(map_arr, valid_mask):
    """Propagates valid neighbor coordinates 1 cell into invalid sky/horizon cells
    so bilinear upsampling never blends invalid sentinel values into valid boundary pixels.
    """
    filled = map_arr.copy()
    inv = ~valid_mask
    if not np.any(inv) or not np.any(valid_mask):
        return filled
    rows, cols = map_arr.shape
    for _ in range(2):
        curr_valid = ~inv
        acc = np.zeros_like(filled)
        cnt = np.zeros((rows, cols), dtype=np.int32)
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)):
            r_src = np.clip(np.arange(rows) + dr, 0, rows - 1)
            c_src = np.clip(np.arange(cols) + dc, 0, cols - 1)
            v_nb = curr_valid[np.ix_(r_src, c_src)]
            val_nb = filled[np.ix_(r_src, c_src)]
            acc += np.where(v_nb, val_nb, 0.0)
            cnt += v_nb.astype(np.int32)
        fillable = inv & (cnt > 0)
        if not np.any(fillable):
            break
        filled[fillable] = acc[fillable] / cnt[fillable]
        inv[fillable] = False
    return filled


def _extract_part_xyz_or_dem(pts_seq, has_z_geom, use_feature_z, dem_sampler, fallback_z, z_offset):
    """Extracts 3D world (x, y, z) list for a sequence of QgsPoint / QgsPointXY vertices."""
    n = len(pts_seq)
    if n == 0:
        return []
    xs = np.array([p.x() for p in pts_seq], dtype=np.float64)
    ys = np.array([p.y() for p in pts_seq], dtype=np.float64)

    zs = None
    if has_z_geom and use_feature_z:
        raw_zs = []
        valid_z = True
        for p in pts_seq:
            if hasattr(p, 'z'):
                zv = p.z()
                if not math.isnan(zv):
                    raw_zs.append(float(zv))
                    continue
            valid_z = False
            break
        if valid_z and len(raw_zs) == n:
            zs = np.array(raw_zs, dtype=np.float64)

    if zs is None:
        if dem_sampler is not None:
            zs = dem_sampler.sample_array(xs, ys, fallback_override=fallback_z)
        else:
            zs = np.full(n, float(fallback_z), dtype=np.float64)

    if z_offset != 0.0:
        zs = zs + float(z_offset)

    return np.stack([xs, ys, zs], axis=1)


class TaskSignals(QObject):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, str)
    max_progress_signal = pyqtSignal(int)
    eta_signal = pyqtSignal(str, float)


class ProjectionTask(QgsTask):
    def __init__(self, photo_items, layer_items, dem_layer, settings_dict, transform_context=None, interactive_mode=False):
        super().__init__("Mavic Batch Projection", TaskCanCancel)
        self.signals = TaskSignals()
        self.photo_items = photo_items
        self.layer_items = layer_items

        self.dem_uri = dem_layer.source() if dem_layer else None
        self.dem_name = dem_layer.name() if dem_layer else None
        self.dem_provider = dem_layer.providerType() if dem_layer else None

        self.global_settings = settings_dict
        self.transform_context = transform_context
        self.exception = None

        self.interactive_mode = interactive_mode
        self.projected_labels_data = {}

    def run(self):
        start_time = time.time()

        thread_dem = None
        if self.dem_uri and self.dem_provider:
            thread_dem = QgsRasterLayer(self.dem_uri, self.dem_name, self.dem_provider)
            if not thread_dem.isValid():
                thread_dem = None

        self.signals.max_progress_signal.emit(100)

        total_photos = len(self.photo_items)
        total_layers = max(1, len(self.layer_items))

        for idx, p_item in enumerate(self.photo_items):
            if self.isCanceled():
                return False

            photo_path = p_item['path']
            overrides = p_item['overrides'] or {}
            label_offsets = overrides.get('label_offsets', {})

            active_pitch = overrides.get('pitch_offset', self.global_settings.get('pitch_offset', 0.0))
            active_yaw = overrides.get('yaw_offset', self.global_settings.get('yaw_offset', 0.0))
            active_roll = overrides.get('roll_offset', self.global_settings.get('roll_offset', 0.0))
            active_focal_scale = overrides.get('focal_scale', self.global_settings.get('focal_scale', 1.0))
            active_x = overrides.get('x_offset', self.global_settings.get('x_offset', 0.0))
            active_y = overrides.get('y_offset', self.global_settings.get('y_offset', 0.0))
            alt_mode = overrides.get('alt_mode', self.global_settings.get('alt_mode', 'auto'))

            active_dists = dict(self.global_settings.get('dist_offsets', {}))
            if 'dist_offsets' in overrides and isinstance(overrides['dist_offsets'], dict):
                active_dists.update(overrides['dist_offsets'])
            elif 'dist_offset' in overrides:
                active_dists['k1'] = float(overrides['dist_offset'])

            lens_override = overrides.get('lens_override', 'Auto (From File)')
            fallback_z = float(self.global_settings.get('fallback_z', 0.0))

            self.signals.log_signal.emit(
                f"\n--- Processing Photo {idx + 1}/{total_photos}: {os.path.basename(photo_path)} ---"
            )

            try:
                tel = MetadataParser.extract_xmp(photo_path, active_dists, lens_override)
                if tel.get('already_projected'):
                    self.signals.log_signal.emit(
                        "   ⚠️ Warning: Input photo appears to be an already-projected output image!"
                    )

                # Resolve Auto vs Manual Geoid cleanly without hijacking intentional 0.0m overrides
                if 'use_auto_geoid' in overrides:
                    use_auto_geoid = bool(overrides['use_auto_geoid'])
                elif 'geoid_offset' in overrides:
                    use_auto_geoid = False
                else:
                    use_auto_geoid = bool(self.global_settings.get('use_auto_geoid', True))

                if use_auto_geoid:
                    use_eh2000 = (alt_mode == 'rtk') or (alt_mode == 'auto' and tel.get('is_rtk', True))
                    active_geoid = tel.get('auto_geoid', -19.0) if use_eh2000 else 0.0
                    geoid_source = "Auto (EH2000 Grid)" if use_eh2000 else "Auto (0.0m)"
                else:
                    active_geoid = float(overrides.get('geoid_offset', self.global_settings.get('geoid_offset', 0.0)))
                    geoid_source = "Manual Override"

                # Preliminary engine to locate drone XY and camera FOV bbox for local DEM block pre-fetch
                prelim_engine = MathEngine(
                    tel,
                    active_geoid,
                    active_yaw,
                    active_pitch,
                    transform_context=self.transform_context,
                    roll_offset=active_roll,
                    focal_scale=active_focal_scale,
                    alt_mode=alt_mode,
                )
                prelim_engine.drone_pos[0] -= active_x
                prelim_engine.drone_pos[1] -= active_y

                img = QImage(photo_path)
                if img.isNull():
                    raise ValueError(f"Could not load image: {photo_path}")
                img_w, img_h = img.width(), img.height()

                _, fov_poly = prelim_engine.get_simple_map_polygons(img_w, img_h)
                fov_geom = QgsGeometry.fromPolygonXY([[QgsPointXY(p.x(), p.y()) for p in fov_poly]])
                bbox = fov_geom.boundingBox()
                nadir_radius = max(250.0, abs(prelim_engine.drone_pos[2]) * 2.5)
                final_bbox = QgsRectangle(
                    min(bbox.xMinimum(), prelim_engine.drone_pos[0] - nadir_radius),
                    min(bbox.yMinimum(), prelim_engine.drone_pos[1] - nadir_radius),
                    max(bbox.xMaximum(), prelim_engine.drone_pos[0] + nadir_radius),
                    max(bbox.yMaximum(), prelim_engine.drone_pos[1] + nadir_radius),
                )

                # Look-ahead focus point ~300m in front of drone for high-res 1.5m foreground DEM block
                az_rad = math.radians(90.0 - prelim_engine.grid_yaw)
                focus_x = prelim_engine.drone_pos[0] + 250.0 * math.cos(az_rad)
                focus_y = prelim_engine.drone_pos[1] + 250.0 * math.sin(az_rad)

                dem_sampler = None
                dem_under_drone = None
                if thread_dem is not None:
                    dem_sampler = DEMSampler(
                        thread_dem,
                        focus_x=focus_x,
                        focus_y=focus_y,
                        far_bbox_3301=final_bbox,
                        fallback_z=fallback_z,
                        fine_half_m=800.0,
                        fine_res_m=1.5,
                        coarse_max_half_m=5500.0,
                        coarse_res_m=8.0,
                        transform_context=self.transform_context,
                    )
                    raw_z = dem_sampler.sample_raw(prelim_engine.drone_pos[0], prelim_engine.drone_pos[1])
                    if not math.isnan(raw_z):
                        dem_under_drone = raw_z

                engine = MathEngine(
                    tel,
                    active_geoid,
                    active_yaw,
                    active_pitch,
                    transform_context=self.transform_context,
                    roll_offset=active_roll,
                    focal_scale=active_focal_scale,
                    alt_mode=alt_mode,
                    dem_under_drone=dem_under_drone,
                )
                engine.drone_pos[0] -= active_x
                engine.drone_pos[1] -= active_y

                self.signals.log_signal.emit(
                    f"   -> Alt: {engine.drone_pos[2]:.2f}m ({engine.resolved_alt_mode}, Geoid {active_geoid:+.2f}m [{geoid_source}])"
                )
                self.signals.log_signal.emit(
                    f"   -> Lens fx: {engine.camera_matrix[0, 0]:.1f}px (Zoom {tel.get('zoom_ratio', 1.0):.2f}x, Scale {active_focal_scale * 100:.1f}%)"
                )
                self.signals.log_signal.emit(
                    f"   -> Offsets: Pitch {active_pitch:+.2f}° | Yaw {active_yaw:+.2f}° | Roll {active_roll:+.2f}° | XY ({active_x:+.2f}m, {active_y:+.2f}m)"
                )

                painter = QPainter(img)
                painter.setRenderHint(RenderHintAntialiasing)

                for l_idx, l_item in enumerate(self.layer_items):
                    if self.isCanceled():
                        painter.end()
                        return False

                    layer = l_item['layer']
                    if layer is None or not layer.isValid():
                        continue
                    style = l_item['style'] or {}
                    selected_only = l_item['selected_only']
                    is_raster = (layer.type() == 1)

                    opacity = style.get('opacity', 60 if is_raster else 100) / 100.0
                    r, g, b, raw_a = style.get('color', (255, 255, 0, 255))
                    clamped_a = max(150, raw_a)
                    base_color = (r, g, b, int(clamped_a * opacity))

                    fr, fg, fb, fa = style.get('fill_color', (255, 255, 0, 0))
                    fill_color = (fr, fg, fb, int(fa * opacity))

                    raw_width = style.get('width', 6)
                    base_width = max(2, int(raw_width))
                    pt_size = style.get('point_size', 10)
                    use_fade = style.get('fade', True)
                    z_offset = float(style.get('z_offset', 0.0))
                    use_feature_z = bool(style.get('use_feature_z', True))

                    max_lbls = style.get('max_labels', 0)
                    font_size = style.get('font_size', 48)
                    lbl_c = style.get('label_color', (255, 255, 0, 255))
                    halo_c = style.get('halo_color', (0, 0, 0, 255))

                    c_c = style.get('callout_color', (150, 150, 150, 200))
                    callout_color = QColor(c_c[0], c_c[1], c_c[2], c_c[3])
                    callout_width = style.get('callout_width', 2)

                    use_shadow = style.get('shadow', False)
                    preset = style.get('preset', "Standard (Flat)")
                    shape_type = style.get('billboard_shape', "Rounded")
                    shadow_angle = style.get('light_angle', 45)
                    shadow_dist = style.get('shadow_dist', 15)

                    self.signals.log_signal.emit(f"Projecting Layer: {layer.name()}...")

                    if not is_raster:
                        layer_crs = layer.crs()
                        to_3301 = None
                        to_layer_crs = None
                        if layer_crs.isValid() and layer_crs != engine.crs_est:
                            to_3301 = QgsCoordinateTransform(layer_crs, engine.crs_est, self.transform_context)
                            to_layer_crs = QgsCoordinateTransform(engine.crs_est, layer_crs, self.transform_context)

                        request = QgsFeatureRequest()
                        if not selected_only:
                            try:
                                req_bbox = to_layer_crs.transformBoundingBox(final_bbox) if to_layer_crs else final_bbox
                                request.setFilterRect(req_bbox)
                            except Exception:
                                pass

                        features = list(layer.selectedFeatures()) if selected_only else list(layer.getFeatures(request))
                        if not features:
                            self.signals.log_signal.emit("   -> No features found in camera view. Skipping.")
                            continue

                        projected_labels = []
                        geom_cat = layer.geometryType()  # 0=Point, 1=Line, 2=Polygon
                        frustum_planes = engine.get_frustum_bounds(img_w, img_h, margin_px=48.0, z_near=1.0)

                        for f_idx, feature in enumerate(features):
                            if self.isCanceled():
                                painter.end()
                                return False

                            geom = QgsGeometry(feature.geometry())
                            if geom.isNull() or geom.isEmpty():
                                continue

                            if to_3301 is not None:
                                try:
                                    geom.transform(to_3301)
                                except Exception:
                                    continue

                            has_z = QgsWkbTypes.hasZ(geom.wkbType())

                            feature_2d_x = []
                            feature_2d_y = []
                            feature_z_sum = 0.0
                            lines_3d = []

                            if geom_cat == 0:  # Point / MultiPoint (including PointZ)
                                abs_geom = geom.constGet()
                                pts_raw = []
                                if abs_geom is not None:
                                    for v in abs_geom.vertices():
                                        pts_raw.append(v)
                                if pts_raw:
                                    xyz_arr = _extract_part_xyz_or_dem(
                                        pts_raw, has_z, use_feature_z, dem_sampler, fallback_z, z_offset
                                    )
                                    pts_3d = engine.get_3d_camera_points_xyz(xyz_arr)
                                    valid_3d = [p for p in pts_3d if is_point_in_frustum(p, frustum_planes)]
                                    if valid_3d:
                                        proj_pts = engine.project_3d_to_2d_float(valid_3d)
                                        for p_res in proj_pts:
                                            if p_res is None:
                                                continue
                                            x, y, z = p_res
                                            scale_factor = max(0.4, min(2.0, 50.0 / max(1.0, z))) if use_fade else 1.0
                                            rad = max(4.0, (pt_size / 2.0) * scale_factor)

                                            painter.setPen(QPen(QColor(*base_color), max(2, int(base_width * scale_factor))))
                                            if base_color[3] > 0:
                                                painter.setBrush(QBrush(QColor(*base_color)))
                                            else:
                                                painter.setBrush(NoBrush)
                                            painter.drawEllipse(QPointF(x, y), rad, rad)

                                            feature_2d_x.append(x)
                                            feature_2d_y.append(y)
                                            feature_z_sum += z

                            elif geom_cat == 2:  # Polygon / MultiPolygon (including PolygonZ)
                                clipped_geom = geom.clipped(final_bbox)
                                if clipped_geom.isNull() or clipped_geom.isEmpty():
                                    continue
                                dens_geom = clipped_geom.densifyByDistance(5.0)
                                parts = dens_geom.asMultiPolygon() if dens_geom.isMultipart() else [dens_geom.asPolygon()]

                                # For outline drawing, clip original boundary rings (without artificial bbox frame edges!)
                                abs_poly = geom.constGet()
                                boundary_geom = QgsGeometry(abs_poly.boundary()).clipped(final_bbox) if abs_poly else QgsGeometry()
                                if not boundary_geom.isNull() and not boundary_geom.isEmpty():
                                    dens_bound = boundary_geom.densifyByDistance(5.0)
                                    b_parts = dens_bound.asMultiPolyline() if dens_bound.isMultipart() else [dens_bound.asPolyline()]
                                    for b_line in b_parts:
                                        if len(b_line) >= 2:
                                            xyz_b = _extract_part_xyz_or_dem(
                                                b_line, False, False, dem_sampler, fallback_z, z_offset
                                            )
                                            lines_3d.append(engine.get_3d_camera_points_xyz(xyz_b))

                                if fill_color[3] > 0:
                                    for poly in parts:
                                        path = QPainterPath()
                                        has_fill_path = False
                                        for ring in poly:
                                            if len(ring) < 3:
                                                continue
                                            xyz_r = _extract_part_xyz_or_dem(
                                                ring, False, False, dem_sampler, fallback_z, z_offset
                                            )
                                            ring_3d = engine.get_3d_camera_points_xyz(xyz_r)
                                            clipped_3d = clip_ring_to_frustum(ring_3d, frustum_planes)
                                            if clipped_3d:
                                                proj_pts = engine.project_3d_to_2d_float(clipped_3d)
                                                poly_pts = [
                                                    CompatPointF(p_res[0], p_res[1])
                                                    for p_res in proj_pts
                                                    if p_res is not None
                                                ]
                                                if len(poly_pts) > 2:
                                                    path.addPolygon(QPolygonF(poly_pts))
                                                    has_fill_path = True
                                        if has_fill_path:
                                            painter.setBrush(QBrush(QColor(*fill_color)))
                                            painter.setPen(QPen(QColor(0, 0, 0, 0)))
                                            painter.drawPath(path)

                            elif geom_cat == 1:  # LineString / MultiLineString (including LineStringZ)
                                clipped_geom = geom.clipped(final_bbox)
                                if clipped_geom.isNull() or clipped_geom.isEmpty():
                                    continue
                                dens_geom = clipped_geom.densifyByDistance(5.0)
                                if has_z and use_feature_z:
                                    abs_g = dens_geom.constGet()
                                    if abs_g is not None:
                                        n_parts = abs_g.partCount() if hasattr(abs_g, 'partCount') else 1
                                        for p_i in range(n_parts):
                                            part = abs_g.geometryN(p_i) if hasattr(abs_g, 'geometryN') else abs_g
                                            verts = list(part.vertices())
                                            if len(verts) >= 2:
                                                xyz_l = _extract_part_xyz_or_dem(
                                                    verts, True, True, dem_sampler, fallback_z, z_offset
                                                )
                                                lines_3d.append(engine.get_3d_camera_points_xyz(xyz_l))
                                else:
                                    parts = dens_geom.asMultiPolyline() if dens_geom.isMultipart() else [dens_geom.asPolyline()]
                                    for line in parts:
                                        if len(line) >= 2:
                                            xyz_l = _extract_part_xyz_or_dem(
                                                line, False, False, dem_sampler, fallback_z, z_offset
                                            )
                                            lines_3d.append(engine.get_3d_camera_points_xyz(xyz_l))

                            # Draw 3D polylines / polygon boundaries with sub-pixel antialiasing
                            for line_3d in lines_3d:
                                vis_sublines = clip_polyline_to_frustum(line_3d, frustum_planes)
                                for sub_3d in vis_sublines:
                                    proj_seq = engine.project_3d_to_2d_float(sub_3d)
                                    for j in range(len(proj_seq) - 1):
                                        p_a, p_b = proj_seq[j], proj_seq[j + 1]
                                        if p_a is None or p_b is None:
                                            continue
                                        x1, y1, z1 = p_a
                                        x2, y2, z2 = p_b

                                        # Skip segments completely outside image bounds
                                        if (
                                            (x1 < -500 and x2 < -500)
                                            or (x1 > img_w + 500 and x2 > img_w + 500)
                                            or (y1 < -500 and y2 < -500)
                                            or (y1 > img_h + 500 and y2 > img_h + 500)
                                        ):
                                            continue

                                        feature_2d_x.extend([x1, x2])
                                        feature_2d_y.extend([y1, y2])
                                        feature_z_sum += (z1 + z2)

                                        w_pen = base_width
                                        a_pen = base_color[3]
                                        if use_fade:
                                            avg_z = (z1 + z2) * 0.5
                                            if 300.0 < avg_z < 800.0:
                                                ratio = (avg_z - 300.0) / 500.0
                                                w_pen = max(2, int(round(base_width * (1.0 - ratio))))
                                                a_pen = int(max(min(150, base_color[3]), base_color[3] - 150.0 * ratio))
                                            elif avg_z >= 800.0:
                                                w_pen = 2
                                                a_pen = min(150, base_color[3])

                                        pen = QPen(QColor(base_color[0], base_color[1], base_color[2], a_pen))
                                        pen.setWidth(w_pen)
                                        pen.setCapStyle(RoundCap)
                                        painter.setPen(pen)
                                        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))

                            if feature_2d_x:
                                in_view = [
                                    (x, y)
                                    for x, y in zip(feature_2d_x, feature_2d_y)
                                    if 0.0 <= x <= img_w and 0.0 <= y <= img_h
                                ]
                                if in_view:
                                    cx_lbl = sum(p[0] for p in in_view) / len(in_view)
                                    cy_lbl = sum(p[1] for p in in_view) / len(in_view)
                                    cz_lbl = feature_z_sum / len(feature_2d_x)

                                    tx = max(50.0, min(float(img_w - 50), cx_lbl))
                                    ty = max(50.0, min(float(img_h - 50), cy_lbl))

                                    feature_key = f"{layer.id()}_{feature.id()}"
                                    saved_override = label_offsets.get(feature_key, {})

                                    if not saved_override.get("hidden", False):
                                        projected_labels.append(
                                            {
                                                'fid': feature.id(),
                                                'anchor_x': tx,
                                                'anchor_y': ty,
                                                'cx_off': saved_override.get("cx_off", None),
                                                'cy_off': saved_override.get("cy_off", None),
                                                'adx': saved_override.get("adx", 0.0),
                                                'ady': saved_override.get("ady", 0.0),
                                                'color': saved_override.get("color"),
                                                'size': saved_override.get("size", 1.0),
                                                'z': cz_lbl,
                                            }
                                        )

                            total_f = len(features)
                            p_frac = idx / total_photos if total_photos > 0 else 0.0
                            l_frac = l_idx / total_layers
                            f_frac = (f_idx + 1) / total_f if total_f > 0 else 1.0
                            overall_frac = p_frac + (1.0 / total_photos) * (l_frac + (1.0 / total_layers) * f_frac)
                            self.setProgress(overall_frac * 100.0)

                            elapsed = time.time() - start_time
                            if overall_frac > 0.02:
                                total_est = elapsed / overall_frac
                                eta_sec = max(0.0, total_est - elapsed)
                                m, s = divmod(int(eta_sec), 60)
                                eta_str = f"ETA: {m}m {s}s" if eta_sec > 0 else "Almost done..."
                                self.signals.eta_signal.emit(f"%p% - {eta_str}", eta_sec)
                            else:
                                self.signals.eta_signal.emit("%p% - Calculating ETA...", 0.0)

                        # Render labels for batch export (or store for interactive viewer)
                        if max_lbls > 0 and projected_labels:
                            projected_labels.sort(key=lambda item: item['z'])
                            projected_labels = projected_labels[:max_lbls]

                            if self.interactive_mode:
                                self.projected_labels_data[layer.id()] = projected_labels
                                continue

                            label_expr_str = (style.get('label_expr') or "").strip()
                            label_field_str = (style.get('label_field') or "").strip()
                            if not label_expr_str and label_field_str:
                                label_expr_str = f"[{label_field_str}]"
                            labels_enabled = bool(style.get('labels_enabled', True))

                            if not labels_enabled or not label_expr_str:
                                continue

                            halo_pen = QPen(QColor(halo_c[0], halo_c[1], halo_c[2], halo_c[3]))
                            occupied_rects = []
                            is_billboard = (preset == "Billboard (Stand-up)")

                            fids = [ld['fid'] for ld in projected_labels]
                            feature_dict = {
                                f.id(): f for f in layer.getFeatures(QgsFeatureRequest().setFilterFids(fids))
                            }

                            for lbl in projected_labels:
                                feat = feature_dict.get(lbl['fid'])
                                if not feat:
                                    continue

                                text = label_expr_str
                                for fld in feat.fields():
                                    placeholder = f"[{fld.name()}]"
                                    if placeholder in text:
                                        val = feat.attribute(fld.name())
                                        text = text.replace(placeholder, str(val) if val is not None else "")

                                if not text.strip():
                                    continue

                                anchor_x = lbl['anchor_x']
                                anchor_y = lbl['anchor_y']
                                true_anchor_x = anchor_x + lbl['adx']
                                true_anchor_y = anchor_y + lbl['ady']

                                custom_scale = lbl.get("size", 1.0)
                                custom_color_tup = lbl.get("color", None)

                                fnt = QFont(painter.font().family(), max(6, int(font_size * custom_scale)))
                                fnt.setBold(True)
                                painter.setFont(fnt)
                                fm = painter.fontMetrics()

                                if custom_color_tup:
                                    text_pen = QPen(QColor(*custom_color_tup))
                                else:
                                    text_pen = QPen(QColor(lbl_c[0], lbl_c[1], lbl_c[2], lbl_c[3]))

                                lines_txt = text.split('\n')
                                th = len(lines_txt) * fm.height() + 20
                                try:
                                    tw = max(fm.horizontalAdvance(line) for line in lines_txt) + 40
                                except AttributeError:
                                    tw = max(fm.boundingRect(line).width() for line in lines_txt) + 40

                                cx_off = lbl.get("cx_off")
                                cy_off = lbl.get("cy_off")

                                if cx_off is not None and cy_off is not None:
                                    cx_pos = anchor_x + cx_off
                                    cy_pos = anchor_y + cy_off
                                    final_rect = QRect(int(cx_pos - tw / 2), int(cy_pos - th / 2), int(tw), int(th))
                                else:
                                    placed = False
                                    cx_pos = anchor_x
                                    if is_billboard:
                                        cy_pos = anchor_y - max(15, abs(shadow_dist)) * custom_scale - th / 2
                                    else:
                                        cy_pos = anchor_y - th / 2 - (15 * custom_scale)

                                    for radius in range(0, 1500, 50):
                                        for angle_deg in range(0, 360, 45):
                                            if radius == 0 and angle_deg > 0:
                                                continue
                                            rad = math.radians(angle_deg)
                                            test_cx = max(tw / 2, min(img_w - tw / 2, anchor_x + radius * math.cos(rad)))
                                            test_cy = max(th / 2, min(img_h - th / 2, anchor_y + radius * math.sin(rad)))
                                            test_rect = QRect(
                                                int(test_cx - tw / 2), int(test_cy - th / 2), int(tw), int(th)
                                            )
                                            if not any(test_rect.intersects(occ) for occ in occupied_rects):
                                                cx_pos, cy_pos = test_cx, test_cy
                                                placed = True
                                                break
                                        if placed:
                                            break
                                    final_rect = QRect(int(cx_pos - tw / 2), int(cy_pos - th / 2), int(tw), int(th))

                                occupied_rects.append(final_rect.adjusted(-20, -20, 20, 20))
                                rect_x, rect_y = final_rect.x(), final_rect.y()

                                if is_billboard:
                                    board_path = QPainterPath()
                                    if shape_type == "Rounded":
                                        board_path.addRoundedRect(
                                            rect_x, rect_y, tw, th, 15 * custom_scale, 15 * custom_scale
                                        )
                                    else:
                                        board_path.addRect(rect_x, rect_y, tw, th)

                                    dx = cx_pos - true_anchor_x
                                    dy = cy_pos - true_anchor_y
                                    dist = math.hypot(dx, dy)
                                    pole_path = QPainterPath()
                                    if dist > 0:
                                        nx, ny = -dy / dist, dx / dist
                                        pole_w = max(4, int(10 * custom_scale))
                                        hw = pole_w / 2.0
                                        edge_x, edge_y = get_rect_intersection(
                                            rect_x, rect_y, tw, th, true_anchor_x, true_anchor_y
                                        )
                                        pole_path.addPolygon(
                                            QPolygonF(
                                                [
                                                    CompatPointF(true_anchor_x + nx * hw, true_anchor_y + ny * hw),
                                                    CompatPointF(true_anchor_x - nx * hw, true_anchor_y - ny * hw),
                                                    CompatPointF(edge_x - nx * hw, edge_y - ny * hw),
                                                    CompatPointF(edge_x + nx * hw, edge_y + ny * hw),
                                                ]
                                            )
                                        )

                                    shadow_path = QPainterPath()
                                    try:
                                        from ..compat_drone import Qt
                                        shadow_path.setFillRule(Qt.WindingFill)
                                    except Exception:
                                        pass
                                    shadow_path.addPath(pole_path)
                                    shadow_path.addPath(board_path)

                                    if use_shadow:
                                        painter.save()
                                        transform = QTransform()
                                        transform.translate(true_anchor_x, true_anchor_y)
                                        safe_shear = math.cos(math.radians(shadow_angle)) * (abs(shadow_dist) / 30.0)
                                        transform.shear(safe_shear, 0.0)
                                        scale_y = -0.4 * (shadow_dist / 15.0)
                                        if abs(scale_y) < 0.01:
                                            scale_y = -0.01 if shadow_dist >= 0 else 0.01
                                        transform.scale(1.0, scale_y)
                                        transform.translate(-true_anchor_x, -true_anchor_y)
                                        painter.setTransform(transform, True)
                                        painter.setPen(QPen(QColor(0, 0, 0, 0)))
                                        painter.setBrush(QBrush(QColor(0, 0, 0, 120)))
                                        painter.drawPath(shadow_path)
                                        painter.restore()

                                    painter.setPen(QPen(QColor(0, 0, 0), max(2, int(4 * custom_scale))))
                                    painter.setBrush(QBrush(QColor(255, 255, 255)))
                                    painter.drawPath(pole_path)
                                    painter.drawPath(board_path)
                                    text_pen = QPen(QColor(0, 0, 0))
                                else:
                                    if callout_width > 0:
                                        edge_x, edge_y = get_rect_intersection(
                                            rect_x, rect_y, tw, th, true_anchor_x, true_anchor_y
                                        )
                                        dist = math.hypot(edge_x - true_anchor_x, edge_y - true_anchor_y)
                                        if dist > 5:
                                            pole_pen = QPen(
                                                callout_color,
                                                max(1, int(callout_width * custom_scale)),
                                                SolidLine,
                                                RoundCap,
                                            )
                                            painter.setPen(pole_pen)
                                            painter.drawLine(
                                                int(true_anchor_x), int(true_anchor_y), int(edge_x), int(edge_y)
                                            )

                                    if use_shadow:
                                        painter.setPen(QPen(QColor(0, 0, 0, 150)))
                                        rad = math.radians(shadow_angle)
                                        sx = math.cos(rad) * shadow_dist
                                        sy = -math.sin(rad) * shadow_dist
                                        painter.drawText(final_rect.translated(int(sx), int(sy)), AlignCenter, text)

                                painter.setPen(halo_pen)
                                for o_dx, o_dy in (
                                    (-3, -3), (3, -3), (-3, 3), (3, 3), (0, -3), (0, 3), (-3, 0), (3, 0)
                                ):
                                    painter.drawText(final_rect.translated(o_dx, o_dy), AlignCenter, text)

                                painter.setPen(text_pen)
                                painter.drawText(final_rect, AlignCenter, text)

                    else:
                        # DEM-Aware Inverse Raycasting for WMS / Raster Overlays (works even with sky/horizon in view!)
                        self.signals.log_signal.emit("   -> Draping WMS/Raster Layer over 3D Terrain...")

                        step = 16
                        us_1d = np.append(np.arange(0, img_w, step, dtype=np.float64), float(img_w))
                        vs_1d = np.append(np.arange(0, img_h, step, dtype=np.float64), float(img_h))
                        uu, vv = np.meshgrid(us_1d, vs_1d)

                        wx, wy, valid = engine.pixels_to_world_grid(
                            uu, vv, dem_sampler=dem_sampler, fallback_z=fallback_z + z_offset
                        )

                        # Clamp ground query extent to +/-4000m around drone so WMS stays high-resolution
                        max_wms_dist = 4000.0
                        in_range = valid & (
                            np.hypot(wx - engine.drone_pos[0], wy - engine.drone_pos[1]) <= max_wms_dist
                        )
                        if not np.any(in_range):
                            self.signals.log_signal.emit("   -> Raster view contains no ground pixels in range.")
                            continue

                        xmin_r = float(np.min(wx[in_range])) - 15.0
                        xmax_r = float(np.max(wx[in_range])) + 15.0
                        ymin_r = float(np.min(wy[in_range])) - 15.0
                        ymax_r = float(np.max(wy[in_range])) + 15.0
                        wms_bbox = QgsRectangle(xmin_r, ymin_r, xmax_r, ymax_r)

                        span_x = max(10.0, xmax_r - xmin_r)
                        span_y = max(10.0, ymax_r - ymin_r)
                        max_tex = 1800
                        if span_x >= span_y:
                            tex_w = max_tex
                            tex_h = max(64, int(round(max_tex * (span_y / span_x))))
                        else:
                            tex_h = max_tex
                            tex_w = max(64, int(round(max_tex * (span_x / span_y))))

                        map_settings = QgsMapSettings()
                        map_settings.setDestinationCrs(engine.crs_est)
                        if self.transform_context is not None:
                            map_settings.setTransformContext(self.transform_context)
                        map_settings.setLayers([layer])
                        map_settings.setBackgroundColor(QColor(0, 0, 0, 0))
                        map_settings.setOutputSize(QSize(tex_w, tex_h))
                        map_settings.setExtent(wms_bbox)

                        vis_ext = map_settings.visibleExtent()
                        job = QgsMapRendererSequentialJob(map_settings)
                        job.start()
                        job.waitForFinished()

                        rendered_img = job.renderedImage()
                        if rendered_img.isNull():
                            continue

                        rendered_img = rendered_img.convertToFormat(Format_ARGB32)
                        rw, rh = rendered_img.width(), rendered_img.height()
                        b_ptr = rendered_img.bits()
                        b_ptr.setsize(rh * rw * 4)
                        src_arr = np.frombuffer(b_ptr, np.uint8).reshape((rh, rw, 4)).copy()

                        map_x_coarse = (wx - vis_ext.xMinimum()) / vis_ext.width() * rw
                        map_y_coarse = (vis_ext.yMaximum() - wy) / vis_ext.height() * rh

                        map_x_coarse = _fill_invalid_border_cells(map_x_coarse, in_range).astype(np.float32)
                        map_y_coarse = _fill_invalid_border_cells(map_y_coarse, in_range).astype(np.float32)

                        map_x_full = cv2.resize(map_x_coarse, (img_w, img_h), interpolation=cv2.INTER_LINEAR)
                        map_y_full = cv2.resize(map_y_coarse, (img_w, img_h), interpolation=cv2.INTER_LINEAR)
                        valid_full = cv2.resize(
                            in_range.astype(np.float32), (img_w, img_h), interpolation=cv2.INTER_LINEAR
                        )

                        warped = cv2.remap(
                            src_arr,
                            map_x_full,
                            map_y_full,
                            interpolation=cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_CONSTANT,
                            borderValue=(0, 0, 0, 0),
                        )
                        warped[valid_full < 0.98, 3] = 0

                        qimg_warped = QImage(
                            warped.data, img_w, img_h, warped.strides[0], Format_ARGB32
                        ).copy()
                        painter.setOpacity(opacity)
                        painter.drawImage(0, 0, qimg_warped)
                        painter.setOpacity(1.0)

                painter.end()

                if not self.interactive_mode:
                    out_dir = self.global_settings.get('out_folder', "")
                    base_name = os.path.basename(photo_path)
                    stem, _ = os.path.splitext(base_name)
                    out_name = f"{stem}_PROJECTED.jpg"
                    out_path = os.path.join(out_dir, out_name)
                    img.save(out_path, "JPG", 95)
                    copy_jpeg_metadata(photo_path, out_path, mark_projected=True)
                    self.signals.log_signal.emit(f"💾 Saved (with EXIF/XMP preserved): {os.path.basename(out_path)}")
                else:
                    cache_dir = os.path.join(os.path.dirname(photo_path), ".mavic_cache")
                    os.makedirs(cache_dir, exist_ok=True)
                    stem, _ = os.path.splitext(os.path.basename(photo_path))
                    out_path = os.path.join(cache_dir, f"{stem}_TEMP.jpg")
                    img.save(out_path, "JPG", 92)

            except Exception as e:
                self.exception = e
                return False

        return True

    def finished(self, result):
        if result:
            self.signals.log_signal.emit("\n✅ Batch Processing Completed Successfully!")
            self.signals.finished_signal.emit(True, "")
        else:
            err = str(self.exception) if self.exception else "Canceled by user."
            self.signals.log_signal.emit(f"\n❌ Task Ended: {err}")
            self.signals.finished_signal.emit(False, err)
