import os
from .compat_drone import QAction, QIcon, BottomDockWidgetArea
from .ui.dock_panel import MavicDockPanel 

class MavicProjectorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dock_widget = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), "Mavic RTK Dashboard", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Mavic Projector", self.action)

    def unload(self):
        # 1. Safely disconnect and stop the GIF movie inside the dock widget if it exists
        if self.dock_widget:
            try:
                if hasattr(self.dock_widget, 'gif_movie') and self.dock_widget.gif_movie:
                    self.dock_widget.gif_movie.stop()
                    # Disconnect the movie from its label to drop file handles
                    if hasattr(self.dock_widget, 'gif_label'):
                        self.dock_widget.gif_label.setMovie(None)
                    self.dock_widget.gif_movie = None
                
                # 2. Cancel any running background threads gracefully
                if hasattr(self.dock_widget, 'cancel_processing'):
                    self.dock_widget.cancel_processing()
            except Exception:
                pass

        # 3. Standard QGIS UI cleanup
        self.iface.removePluginMenu("&Mavic Projector", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater() # Explicitly signal memory cleanup

    def run(self):
        if not self.dock_widget:
            self.dock_widget = MavicDockPanel(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(BottomDockWidgetArea, self.dock_widget)
        
        self.dock_widget.show()