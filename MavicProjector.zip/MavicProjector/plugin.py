import os
from .compat_drone import NonModal, QAction, QIcon, Window
from .ui.viewer_dialog import MavicStudioWindow


class MavicProjectorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.studio_window = None
        self.dock_widget = None  # Kept as None for legacy safety

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path), "Mavic Projector Studio", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Mavic Projector", self.action)

    def unload(self):
        if self.studio_window is not None:
            try:
                self.studio_window.cancel_active_tasks()
                self.studio_window.close()
                self.studio_window.deleteLater()
            except Exception:
                pass
            self.studio_window = None

        if self.action is not None:
            self.iface.removePluginMenu("&Mavic Projector", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        if self.studio_window is None:
            parent_win = self.iface.mainWindow() if hasattr(self.iface, "mainWindow") else None
            self.studio_window = MavicStudioWindow(iface=self.iface, parent=parent_win)
            self.studio_window.setWindowModality(NonModal)
            self.studio_window.setWindowFlags(Window)

        self.studio_window.showNormal()
        self.studio_window.raise_()
        self.studio_window.activateWindow()
