import sys
import os
import subprocess

def classFactory(iface):
    from .compat_drone import QMessageBox, MsgYes, MsgNo, exec_dialog
    
    try:
        import cv2
    except ImportError:
        msg = QMessageBox(iface.mainWindow())
        msg.setWindowTitle("Missing Dependency: OpenCV")
        msg.setText(
            "The Mavic Projector plugin requires 'opencv-python' (cv2), "
            "which is missing in this QGIS environment.\n\n"
            "Would you like the plugin to try installing it automatically via pip?"
        )
        msg.setStandardButtons(MsgYes | MsgNo)
        
        if exec_dialog(msg) == MsgYes:
            try:
                # Resolve the correct Python executable for the QGIS environment
                python_exe = os.path.join(sys.prefix, 'python.exe')
                if not os.path.exists(python_exe):
                    python_exe = sys.executable
                    
                # Run pip install in a subprocess
                subprocess.check_call([python_exe, "-m", "pip", "install", "opencv-python"])
                
                QMessageBox.information(
                    iface.mainWindow(), 
                    "Success", 
                    "OpenCV installed successfully! The plugin will now load."
                )
            except Exception as e:
                QMessageBox.critical(
                    iface.mainWindow(), 
                    "Installation Failed", 
                    f"Could not install OpenCV automatically. Please open the OSGeo4W Shell and run:\n\n"
                    f"python -m pip install opencv-python\n\n"
                    f"Error details: {str(e)}"
                )
                return _build_dummy_plugin(iface)
        else:
            return _build_dummy_plugin(iface)

    # If OpenCV is present (or was just installed successfully), load the real plugin
    from .plugin import MavicProjectorPlugin
    return MavicProjectorPlugin(iface)

def _build_dummy_plugin(iface):
    """Returns a harmless dummy plugin to prevent QGIS from crashing if dependencies fail."""
    class DummyPlugin:
        def __init__(self, iface): pass
        def initGui(self): pass
        def unload(self): pass
    return DummyPlugin(iface)