import os
import glob
import json
import math
import traceback
import shutil
from datetime import datetime
from functools import partial

from qgis.PyQt.QtWidgets import (
    QListWidget, QListWidgetItem, QButtonGroup, QColorDialog, QCheckBox,
    QSpinBox, QTabWidget, QVBoxLayout, QWidget, QGridLayout, QDoubleSpinBox,
    QFileDialog, QTableWidget, QTableWidgetItem, QAbstractItemView, QHeaderView, QSlider,
    QMenu, QInputDialog, QDial, QScrollArea, QProgressBar
)
from qgis.PyQt.QtCore import QSize, QRectF
from qgis.PyQt.QtGui import QIcon, QPainterPath, QPixmapCache, QPixmap, QPainter, QImage

from qgis.core import (
    QgsLineSymbol, QgsFillSymbol, QgsPointXY, QgsProject, QgsVectorLayer, 
    QgsFeature, QgsGeometry, QgsField, QgsPalLayerSettings, QgsTextFormat, 
    QgsTextBufferSettings, QgsVectorLayerSimpleLabeling, QgsMarkerSymbol, 
    QgsSimpleMarkerSymbolLayer, QgsProperty, QgsMessageLog, Qgis,
    QgsSymbolLayer, QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFeatureRequest,
    QgsDefaultValue, QgsWkbTypes, QgsApplication, QgsTask, QgsRasterLayer,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsRectangle
)
import numpy as np

from ..compat_drone import (
    QAction, QApplication, QDialog, QHBoxLayout, QPushButton, QToolButton, QLabel, QGraphicsView, QGraphicsScene, 
    Qt, pyqtSignal, QMessageBox, KeepAspectRatio, ScrollHandDrag, NoDrag,
    AnchorUnderMouse, LeftButton, RightButton, QVariant, QColor, 
    QGraphicsEllipseItem, QGraphicsTextItem, QGraphicsLineItem, QGraphicsPolygonItem, 
    QPolygonF, QPointF, QBrush, QPen, QFont, MsgYes, MsgNo, QFrame, QLineEdit, 
    StyledPanel, QComboBox, QuadrantAbove, DashLine, SolidLine, RoundCap, 
    Key_Return, Key_Enter, Key_Escape, Key_Up, Key_Down, Key_Space,
    IdentifyFormatValue, LabelPlacementOverPoint, HLine,
    NonModal, Window, Transparent, QTransform, QTimer, QgsRubberBand, QgsMapToolEmitPoint,
    WindowMinimized, UserRole, QgsVertexMarker, QGraphicsPathItem, QSplitter, Horizontal,
    QGraphicsItem, GraphicsItemIsSelectable, GraphicsItemIsMovable, GraphicsItemSendsGeometryChanges,
    Checked, Unchecked, ItemIsUserCheckable, QSettings, exec_dialog,
    FilterPoint, FilterPolygon, FilterLine, FilterRaster, QgsMapLayerComboBox,
    Format_ARGB32_Premultiplied, RenderHintAntialiasing, SmoothPixmapTransform, ShowAlphaChannel, QGraphicsBlurEffect, BlurPerformanceHint, DeviceCoordinateCache, NoPen,
    ShiftModifier, ControlModifier, AltModifier, CrossCursor, SizeAllCursor, ArrowCursor,
    InstantPopup, ScrollBarAlwaysOff, SizePolicyIgnored, SizePolicyPreferred
)
from .custom_widgets import LayerListWidget, PhotoListWidget
from .dlg_layer_style import DropTextEdit, LayerStyleDialog, get_rect_intersection
from .dlg_photo_props import PhotoPropertiesDialog
from .dlg_drag_align import DragAlignDialog, DragAlignPanel
from .dock_panel import (
    _has_meaningful_overrides,
    extract_qgis_layer_style,
    format_layer_item_label,
    make_default_layer_style,
    make_layer_list_icon,
)
from .theme import apply_theme
from ..core.i18n import tr, ui_prefs
from ..core.dem_sampler import DEMSampler
from ..core.jpeg_meta import copy_jpeg_metadata
from ..core.task_worker import (
    clip_ring_to_frustum,
    clip_polyline_to_frustum,
)

class InteractiveAnchorItem(QGraphicsPathItem):
    def __init__(self, anchor_x, anchor_y, feature_key, parent_viewer, label_item):
        super().__init__()
        self.base_anchor_x = anchor_x
        self.base_anchor_y = anchor_y
        self.feature_key = feature_key
        self.parent_viewer = parent_viewer
        self.label_item = label_item
        
        path = QPainterPath()
        s = 8
        path.moveTo(-s, -s)
        path.lineTo(s, s)
        path.moveTo(-s, s)
        path.lineTo(s, -s)
        path.addRect(-12, -12, 24, 24)
        
        self.setPath(path)
        self.setPen(QPen(QColor(255, 0, 0), 3))
        self.setBrush(QBrush(QColor(255, 255, 255, 1))) 
        
        self.setZValue(101)
        self.setFlags(GraphicsItemIsSelectable | GraphicsItemIsMovable | GraphicsItemSendsGeometryChanges)
        
    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if self.label_item and getattr(self.label_item, 'shadow_item', None):
            if self.label_item.shadow_item.graphicsEffect():
                # Fix: Turn it off completely, do not use radius 0
                self.label_item.shadow_item.graphicsEffect().setEnabled(False)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if self.label_item:
            self.label_item.update_visuals()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        
        # Restore blur when you drop the anchor
        if self.label_item and getattr(self.label_item, 'shadow_item', None):
            effect = self.label_item.shadow_item.graphicsEffect()
            if effect:
                blur_val = self.label_item.style_dict.get('shadow_blur', 0)
                effect.setBlurRadius(blur_val)
                effect.setEnabled(blur_val > 0)
                
        if self.scene():
            self.scene().update() # Wipe away any remaining visual artifacts
            
        if self.parent_viewer:
            # Correct relative offset math: Current absolute X minus original base X
            adx = self.x() - self.base_anchor_x
            ady = self.y() - self.base_anchor_y
            self.parent_viewer.save_anchor_override(self.feature_key, adx, ady)

class InteractiveLabelItem(QGraphicsTextItem):
    def __init__(self, text, base_anchor_x, base_anchor_y, feature_key, parent_viewer, style_dict, custom_scale=1.0):
        super().__init__(text)
        self.base_anchor_x = base_anchor_x
        self.base_anchor_y = base_anchor_y
        self.feature_key = feature_key
        self.parent_viewer = parent_viewer
        self.style_dict = style_dict
        self.custom_scale = custom_scale
        
        self.anchor_item = None
        self.bg_item = None
        self.shadow_item = None
        
        self.setFlags(GraphicsItemIsSelectable | GraphicsItemIsMovable | GraphicsItemSendsGeometryChanges)
        self.setAcceptedMouseButtons(LeftButton | RightButton)
        
    def set_initial_center(self, cx, cy):
        br = self.boundingRect()
        self.setPos(cx - br.width()/2, cy - br.height()/2)

    def update_visuals(self):
        br = self.boundingRect()
        tw, th = br.width(), br.height()
        cx, cy = self.x() + tw/2, self.y() + th/2
        
        # Read the true coordinates directly from the anchor's physical position
        true_ax = self.anchor_item.x() if self.anchor_item else self.base_anchor_x
        true_ay = self.anchor_item.y() if self.anchor_item else self.base_anchor_y
        
        is_billboard = self.style_dict.get('preset') == "Billboard (Stand-up)"
        shape_type = self.style_dict.get('billboard_shape', "Rounded")
        
        if is_billboard and isinstance(self.bg_item, QGraphicsPathItem):
            board_path = QPainterPath()
            if shape_type == "Rounded":
                board_path.addRoundedRect(self.x(), self.y(), tw, th, 15 * self.custom_scale, 15 * self.custom_scale)
            else:
                board_path.addRect(self.x(), self.y(), tw, th)
            
            dx = cx - true_ax
            dy = cy - true_ay
            dist = math.hypot(dx, dy)
            pole_path = QPainterPath()
            if dist > 0:
                nx, ny = -dy/dist, dx/dist
                pole_w = max(4, int(10 * self.custom_scale))
                w = pole_w / 2.0
                # Fix: Connect to the edge of the bounding box, not the centroid
                edge_x, edge_y = get_rect_intersection(self.x(), self.y(), tw, th, true_ax, true_ay)
                pole_path.addPolygon(QPolygonF([
                    QPointF(true_ax + nx*w, true_ay + ny*w),
                    QPointF(true_ax - nx*w, true_ay - ny*w),
                    QPointF(edge_x - nx*w, edge_y - ny*w),
                    QPointF(edge_x + nx*w, edge_y + ny*w)
                ]))
                
            combined_path = QPainterPath()
            try:
                from ..compat_drone import Qt
                combined_path.setFillRule(Qt.WindingFill)
            except Exception:
                pass
            combined_path.addPath(pole_path)
            combined_path.addPath(board_path)

            # CRITICAL FIX 1: Simplify the path!
            combined_path = combined_path.simplified()

            self.bg_item.setPath(combined_path)
            
            if isinstance(self.shadow_item, QGraphicsPathItem):
                transform = QTransform()
                transform.translate(true_ax, true_ay)
                shadow_dist = self.style_dict.get('shadow_dist', 15)
                shadow_angle = self.style_dict.get('light_angle', 45)
                safe_shear = math.cos(math.radians(shadow_angle)) * (abs(shadow_dist) / 30.0)
                transform.shear(safe_shear, 0.0)
                
                scale_y = -0.4 * (shadow_dist / 15.0 if shadow_dist != 0 else 0.1)
                if abs(scale_y) < 0.01: scale_y = -0.01 if shadow_dist >= 0 else 0.01
                
                transform.scale(1.0, scale_y)
                transform.translate(-true_ax, -true_ay)
                
                # CRITICAL FIX 2: Simplify again after the extreme shear/scale mapping
                mapped_shadow = transform.map(combined_path).simplified()
                
                local_offset = mapped_shadow.boundingRect().topLeft()
                shift_transform = QTransform().translate(-local_offset.x(), -local_offset.y())
                local_shadow_path = shift_transform.map(mapped_shadow)
                
                self.shadow_item.setPath(local_shadow_path)
                self.shadow_item.setPos(local_offset.x(), local_offset.y())
                self.shadow_item.setTransform(QTransform())
                
        elif not is_billboard:
            if isinstance(self.bg_item, QGraphicsLineItem):
                edge_x, edge_y = get_rect_intersection(self.x(), self.y(), tw, th, true_ax, true_ay)
                self.bg_item.setLine(true_ax, true_ay, edge_x, edge_y)
                
            if isinstance(self.shadow_item, QGraphicsTextItem):
                sx = getattr(self.shadow_item, 'base_sx', 0)
                sy = getattr(self.shadow_item, 'base_sy', 0)
                self.shadow_item.setPos(self.x() + sx + 3, self.y() + sy + 3)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if getattr(self, 'shadow_item', None) and self.shadow_item.graphicsEffect():
            # Fix: Turn it off completely, do not use radius 0
            self.shadow_item.graphicsEffect().setEnabled(False)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        self.update_visuals()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        
        # Restore blur when you drop the label, but disable the effect entirely if blur is 0
        if getattr(self, 'shadow_item', None):
            effect = self.shadow_item.graphicsEffect()
            if effect:
                blur_val = self.style_dict.get('shadow_blur', 0)
                effect.setBlurRadius(blur_val)
                effect.setEnabled(blur_val > 0) # <--- The critical addition
                
        if self.scene():
            self.scene().update() # Wipe away any remaining visual artifacts
            
        if self.parent_viewer:
            br = self.boundingRect()
            cx = self.x() + br.width()/2.0
            cy = self.y() + br.height()/2.0
            cx_off = cx - self.base_anchor_x
            cy_off = cy - self.base_anchor_y
            self._save_overrides(cx_off=cx_off, cy_off=cy_off)

    def itemChange(self, change, value):
        try:
            target_change = QGraphicsItem.GraphicsItemChange.ItemSelectedHasChanged
        except AttributeError:
            target_change = QGraphicsItem.ItemSelectedHasChanged
            
        if change == target_change:
            # We purposely do nothing here anymore.
            # Anchor visibility is handled centrally by InteractiveViewer._on_scene_selection_changed
            # to prevent flickering when transitioning clicks between the label and the anchor.
            pass
        return super().itemChange(change, value)

    def contextMenuEvent(self, event):
        if not self.parent_viewer or self.parent_viewer.current_tool != 'edit':
            super().contextMenuEvent(event)
            return
            
        event.accept()
        menu = QMenu()
        action_color = menu.addAction("🎨 Change Specific Color")
        action_size = menu.addAction("📏 Change Specific Size")
        action_reset = menu.addAction("↺ Reset to Layer Style")
        menu.addSeparator()
        action_hide = menu.addAction("🗑️ Hide this Label")

        try:
            action = menu.exec(event.screenPos())
        except AttributeError:
            action = menu.exec_(event.screenPos())
        
        if action == action_color:
            color = QColorDialog.getColor(self.defaultTextColor(), self.parent_viewer, "Pick Label Color", ShowAlphaChannel)
            if color.isValid():
                self.setDefaultTextColor(color)
                c = color.getRgb()
                self._save_overrides(color=(c[0], c[1], c[2], c[3]))
        elif action == action_size:
            val, ok = QInputDialog.getDouble(self.parent_viewer, "Change Size", "Scale Multiplier (e.g., 1.5 for 50% larger):", self.custom_scale, 0.1, 10.0, 2)
            if ok:
                self.custom_scale = val
                self._save_overrides(size=val)
                self.parent_viewer.render_projected_labels() 
        elif action == action_reset:
            self._save_overrides(reset=True)
            self.parent_viewer.render_projected_labels()
        elif action == action_hide:
            self.hide_label()

    def _save_overrides(self, cx_off=None, cy_off=None, hidden=None, color=None, size=None, reset=False):
        if self.parent_viewer:
            self.parent_viewer.save_label_override(self.feature_key, cx_off, cy_off, hidden, color, size, reset)

    def hide_label(self):
        if self.bg_item: self.bg_item.hide()
        if hasattr(self, 'bg_item_pole') and self.bg_item_pole: self.bg_item_pole.hide()
        if self.shadow_item: self.shadow_item.hide()
        if self.anchor_item: self.anchor_item.hide()
        self.hide()
        self._save_overrides(hidden=True)
        # Fix: Force scene repaint to wipe away orphaned blurred pixels
        if self.scene():
            self.scene().update()

class PointMapTool(QgsMapToolEmitPoint):
    canvasClicked = pyqtSignal(object, object)
    def __init__(self, canvas):
        super().__init__(canvas)
    def canvasReleaseEvent(self, event):
        pt = self.toMapCoordinates(event.pos())
        self.canvasClicked.emit(pt, event.button())

class ReverseProjectionView(QGraphicsView):
    scenePressed = pyqtSignal(float, float, object)
    sceneMoved = pyqtSignal(float, float, object)
    sceneReleased = pyqtSignal(float, float, object)
    focalWheelAdjusted = pyqtSignal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTransformationAnchor(AnchorUnderMouse)
        self.last_modifiers = Qt.KeyboardModifier(0) if hasattr(Qt, 'KeyboardModifier') else 0

    def wheelEvent(self, event):
        if event.modifiers() & ControlModifier:
            factor = 1.004 if event.angleDelta().y() > 0 else (1.0 / 1.004)
            self.focalWheelAdjusted.emit(factor)
            event.accept()
            return
        zoom_in_factor = 1.15
        zoom_out_factor = 1.0 / zoom_in_factor
        if event.angleDelta().y() > 0:
            zoom_factor = zoom_in_factor
        else:
            zoom_factor = zoom_out_factor
        self.scale(zoom_factor, zoom_factor)

    def mousePressEvent(self, event):
        self.last_modifiers = event.modifiers()
        scene_pos = self.mapToScene(event.pos())
        self.scenePressed.emit(scene_pos.x(), scene_pos.y(), event.button())
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        self.last_modifiers = event.modifiers()
        scene_pos = self.mapToScene(event.pos())
        self.sceneMoved.emit(scene_pos.x(), scene_pos.y(), event.buttons())
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self.last_modifiers = event.modifiers()
        scene_pos = self.mapToScene(event.pos())
        self.sceneReleased.emit(scene_pos.x(), scene_pos.y(), event.button())
        super().mouseReleaseEvent(event)

class InteractiveViewer(QDialog):
    def __init__(self, gallery_data=None, start_index=0, global_settings=None, dem_layer=None, parent=None, iface=None):
        super().__init__(parent)
        self.iface = iface if iface is not None else getattr(parent, 'iface', None)
        self.settings = QSettings("MavicProjectorPlugin", "UI_Settings")
        self.gallery_data = list(gallery_data) if gallery_data else []

        default_gs = {
            'fallback_z': float(self.settings.value("fallback_z", 0.0)),
            'geoid_offset': float(self.settings.value("geoid_offset", -19.0)),
            'use_auto_geoid': str(self.settings.value("use_auto_geoid", "true")).lower() in ("true", "1", "yes"),
            'alt_mode': str(self.settings.value("alt_mode", "auto")),
            'max_dist_km': float(self.settings.value("max_dist_km", 4.0)),
            'yaw_offset': 0.0,
            'pitch_offset': 0.0,
            'roll_offset': 0.0,
            'focal_scale': 1.0,
            'x_offset': 0.0,
            'y_offset': 0.0,
            'dist_offsets': {},
        }
        if isinstance(global_settings, dict):
            default_gs.update(global_settings)
        self.global_settings = default_gs
        self._explicit_dem_layer = dem_layer
        self.dem_layer = dem_layer
        self.fallback_z = float(self.global_settings.get('fallback_z', 0.0))
        self.connected_layers = {}
        self.batch_task = None
        self._batch_export_dir = None

        self.photo_name = ""
        self.engine = None
        self.temp_task = None
        self._is_silent_projection = False

        self._projected_label_data = {}
        self._projected_label_cache = {}
        self._projected_graphics = []

        self.undo_stack = []
        self.redo_stack = []
        self._persistent_graphics = []
        self.active_qgis_fid = None
        self.active_qgis_layer = None
        self._is_plugin_editing = False

        self.current_tool = 'pan'
        self.temp_points = []
        self.temp_graphics = []
        self.pin_start_u = None
        self.pin_start_v = None

        self.tie_points = []
        self.tie_point_graphics = []
        self.map_tie_markers = []
        self.pending_u = None
        self.pending_v = None
        self.pending_z = None

        self.dem_sampler = None
        self._auto_geoid_curr = -19.0
        self.horizon_pts = []
        self.horizon_graphics = []
        self._wireframe_world_lines = []
        self._wireframe_item_proj = None
        self._drag_align_start = None
        self.drag_align_dialog = None
        self.drag_align_panel = None
        self._drag_align_mode = 'pan_rot'
        self._wf_color = QColor(0, 255, 140, 235)
        self._wf_width = 4
        self._wf_visible = True
        self._hide_baked_during_da = True
        self._wireframe_dirty_since_render = False
        self._left_panel_saved_width = 245
        self._initial_layout_applied = False
        self._fpitch_anchor = None
        self._curr_fpitch_deg = 0.0
        self._base_drone_pos = None
        self._raw_pixmap = QPixmap()
        self._proj_pixmap = QPixmap()
        self._space_peeking = False
        self.proj_bg_item = None

        self.map_canvas = self.iface.mapCanvas() if (self.iface and hasattr(self.iface, 'mapCanvas')) else None
        if self.map_canvas:
            self.map_tool = PointMapTool(self.map_canvas)
            self.map_tool.canvasClicked.connect(self.on_map_clicked)
        self.prev_map_tool = None

        self.live_sync_timer = QTimer(self)
        self.live_sync_timer.setSingleShot(True)
        self.live_sync_timer.setInterval(400)
        self.live_sync_timer.timeout.connect(self._execute_live_sync)

        self.setWindowTitle(tr("studio_title"))
        self.setMinimumSize(940, 580)
        self.setup_drawing_layers()

        root_vbox = QVBoxLayout(self)
        root_vbox.setContentsMargins(6, 5, 6, 6)
        root_vbox.setSpacing(4)

        # =====================================================================
        # FULL-WIDTH COMPACT TOP HEADER (Fits 1280px / 1366px Laptop Screens!)
        # =====================================================================
        toolbar1 = QHBoxLayout()
        toolbar1.setSpacing(3)
        toolbar2 = QHBoxLayout()
        toolbar2.setSpacing(5)

        self.btn_toggle_left = QPushButton(tr("btn_toggle_left_hide"))
        self.btn_toggle_left.setProperty("role", "pill")
        self.btn_toggle_left.setToolTip(tr("tip_toggle_left"))
        self.btn_toggle_left.clicked.connect(self.toggle_left_panel)
        toolbar1.addWidget(self.btn_toggle_left)

        self.btn_toggle_overlay = QPushButton(tr("btn_overlay_toggle"))
        self.btn_toggle_overlay.setProperty("role", "toggleChip")
        self.btn_toggle_overlay.setCheckable(True)
        self.btn_toggle_overlay.setChecked(True)
        self.btn_toggle_overlay.setToolTip(tr("tip_overlay_toggle"))
        self.btn_toggle_overlay.toggled.connect(self._on_overlay_toggled)
        toolbar1.addWidget(self.btn_toggle_overlay)

        self.tool_group = QButtonGroup(self)

        self.btn_pan = QPushButton(tr("tool_pan"))
        self.btn_pan.setCheckable(True)
        self.btn_pan.setChecked(True)
        self.tool_group.addButton(self.btn_pan, 0)

        self.btn_drag_align = QPushButton(tr("tool_drag_align"))
        self.btn_drag_align.setProperty("role", "accent")
        self.btn_drag_align.setToolTip("Interactive Drag Align: highlights ALL features in view as a live wireframe.")
        self.btn_drag_align.setCheckable(True)
        self.tool_group.addButton(self.btn_drag_align, 9)

        # Unified Horizon button list (1-Click Auto-Horizon + 2-Click Manual Horizon)
        self.btn_horizon_menu = QToolButton()
        self.btn_horizon_menu.setPopupMode(InstantPopup)
        self.btn_horizon_menu.setCheckable(True)
        self.btn_horizon_menu.setProperty("role", "toolBtn")
        self.btn_horizon_menu.setText(tr("btn_horizon_menu"))
        self.btn_horizon_menu.setToolTip(tr("tip_horizon_menu"))
        self.horizon_menu = QMenu(self.btn_horizon_menu)
        self.act_auto_horizon = QAction(tr("act_auto_horizon"), self)
        self.act_auto_horizon.triggered.connect(self.run_auto_horizon)
        self.act_manual_horizon = QAction(tr("act_manual_horizon"), self)
        self.act_manual_horizon.triggered.connect(self.activate_manual_horizon_tool)
        self.horizon_menu.addAction(self.act_auto_horizon)
        self.horizon_menu.addAction(self.act_manual_horizon)
        self.btn_horizon_menu.setMenu(self.horizon_menu)

        self.btn_tie_point = QPushButton(tr("tool_tie"))
        self.btn_tie_point.setCheckable(True)
        self.tool_group.addButton(self.btn_tie_point, 5)

        self.btn_edit = QPushButton(tr("tool_edit"))
        self.btn_edit.setCheckable(True)
        self.btn_edit.setToolTip("Select, drag, and right-click projected labels.")
        self.tool_group.addButton(self.btn_edit, 6)

        self.btn_place = QPushButton(tr("tool_place"))
        self.btn_place.setCheckable(True)
        self.tool_group.addButton(self.btn_place, 7)

        self.btn_pin = QPushButton(tr("tool_pin"))
        self.btn_pin.setCheckable(True)
        self.tool_group.addButton(self.btn_pin, 1)

        self.btn_line = QPushButton(tr("tool_line"))
        self.btn_line.setCheckable(True)
        self.tool_group.addButton(self.btn_line, 2)

        self.btn_poly = QPushButton(tr("tool_poly"))
        self.btn_poly.setCheckable(True)
        self.tool_group.addButton(self.btn_poly, 3)

        self.btn_remove = QPushButton(tr("tool_remove"))
        self.btn_remove.setCheckable(True)
        self.tool_group.addButton(self.btn_remove, 4)

        for b_tb in (
            self.btn_pan, self.btn_edit, self.btn_place, self.btn_pin,
            self.btn_line, self.btn_poly, self.btn_remove, self.btn_tie_point,
        ):
            b_tb.setProperty("role", "toolBtn")

        self.tool_group.buttonClicked.connect(self.on_tool_changed)

        toolbar1.addWidget(self.btn_pan)
        toolbar1.addWidget(self.btn_drag_align)
        toolbar1.addWidget(self.btn_horizon_menu)
        toolbar1.addWidget(self.btn_tie_point)
        toolbar1.addWidget(self.btn_edit)
        toolbar1.addWidget(self.btn_place)
        toolbar1.addWidget(self.btn_pin)
        toolbar1.addWidget(self.btn_line)
        toolbar1.addWidget(self.btn_poly)
        toolbar1.addWidget(self.btn_remove)

        self.btn_refresh = QPushButton(tr("tool_recalc"))
        self.btn_refresh.setProperty("role", "primary")
        self.btn_refresh.clicked.connect(self._execute_live_sync)
        toolbar1.addWidget(self.btn_refresh)
        toolbar1.addStretch(1)

        self.btn_lang = QPushButton()
        self.btn_lang.setProperty("role", "pill")
        self.btn_lang.clicked.connect(ui_prefs.toggle_language)
        toolbar1.addWidget(self.btn_lang)

        self.btn_theme = QPushButton()
        self.btn_theme.setProperty("role", "pill")
        self.btn_theme.clicked.connect(ui_prefs.toggle_theme)
        toolbar1.addWidget(self.btn_theme)

        self.hint = QLabel("")
        self.hint.setProperty("role", "hint")
        self.hint.setSizePolicy(SizePolicyIgnored, SizePolicyPreferred)
        self.hint.setMinimumWidth(80)
        toolbar2.addWidget(self.hint, stretch=1)

        self.chk_show_all = QCheckBox(tr("chk_show_all_drawn"))
        self.chk_show_all.setToolTip(tr("tip_show_all_drawn"))
        self.chk_show_all.setChecked(False)
        self.chk_show_all.stateChanged.connect(self.load_existing_features)
        toolbar2.addWidget(self.chk_show_all)

        self.btn_undo = QPushButton(tr("btn_undo"))
        self.btn_undo.setProperty("role", "toolBtn")
        self.btn_undo.clicked.connect(self.undo_action)
        self.btn_undo.setEnabled(False)

        self.btn_redo = QPushButton(tr("btn_redo"))
        self.btn_redo.setProperty("role", "toolBtn")
        self.btn_redo.clicked.connect(self.redo_action)
        self.btn_redo.setEnabled(False)

        self.btn_clear = QPushButton(tr("btn_clear_photo"))
        self.btn_clear.setProperty("role", "danger")
        self.btn_clear.clicked.connect(self.clear_all_features)

        toolbar2.addWidget(self.btn_undo)
        toolbar2.addWidget(self.btn_redo)
        toolbar2.addWidget(self.btn_clear)

        root_vbox.addLayout(toolbar1)
        root_vbox.addLayout(toolbar2)

        self.main_splitter = QSplitter(Horizontal)
        root_vbox.addWidget(self.main_splitter, stretch=1)

        # =====================================================================
        # COL 0 — LEFT RAIL: Photos + Layers + Terrain + Archive (Collapsible)
        # =====================================================================
        self.left_tabs = QTabWidget()
        self.left_tabs.setMinimumWidth(215)

        proj_scroll = QScrollArea()
        proj_scroll.setWidgetResizable(True)
        proj_scroll.setHorizontalScrollBarPolicy(ScrollBarAlwaysOff)
        left_proj_widget = QWidget()
        left_proj_lay = QVBoxLayout(left_proj_widget)
        left_proj_lay.setContentsMargins(4, 4, 4, 4)
        left_proj_lay.setSpacing(4)

        # Card 1: Drone Photos (.JPG)
        card_photos = QFrame()
        card_photos.setProperty("role", "card")
        cp_lay = QVBoxLayout(card_photos)
        cp_lay.setContentsMargins(5, 5, 5, 5)
        cp_lay.setSpacing(3)

        self.lbl_sec_photos = QLabel(tr("sec_studio_photos"))
        self.lbl_sec_photos.setProperty("role", "section")
        cp_lay.addWidget(self.lbl_sec_photos)

        ph_btn_row = QHBoxLayout()
        ph_btn_row.setSpacing(4)
        self.btn_browse_photos = QPushButton(tr("btn_browse_photos"))
        self.btn_browse_photos.setProperty("role", "primary")
        self.btn_browse_photos.clicked.connect(self.browse_photos)
        self.btn_rem_photo = QPushButton(tr("btn_rem_photo"))
        self.btn_rem_photo.clicked.connect(self.remove_selected_photos)
        ph_btn_row.addWidget(self.btn_browse_photos, stretch=2)
        ph_btn_row.addWidget(self.btn_rem_photo, stretch=1)
        cp_lay.addLayout(ph_btn_row)

        self.lbl_hint_photos = QLabel(tr("hint_photos"))
        self.lbl_hint_photos.setProperty("role", "muted")
        self.lbl_hint_photos.setWordWrap(True)
        cp_lay.addWidget(self.lbl_hint_photos)

        self.filmstrip = PhotoListWidget()
        self.filmstrip.setMinimumHeight(68)
        self.filmstrip.setIconSize(QSize(64, 44))
        self.filmstrip.setSpacing(2)
        self.filmstrip.filesDropped.connect(self.add_photos_to_studio)
        self.filmstrip.itemDoubleClicked.connect(self.open_photo_properties)
        cp_lay.addWidget(self.filmstrip, stretch=1)

        ph_util_row = QHBoxLayout()
        ph_util_row.setSpacing(4)
        self.btn_show_cams = QPushButton(tr("btn_show_cams"))
        self.btn_show_cams.setProperty("role", "toolBtn")
        self.btn_show_cams.clicked.connect(self.toggle_cameras_on_map)
        self.btn_dump_xmp = QPushButton(tr("btn_dump_xmp"))
        self.btn_dump_xmp.setProperty("role", "toolBtn")
        self.btn_dump_xmp.clicked.connect(self.dump_xmp_for_selected)
        ph_util_row.addWidget(self.btn_show_cams)
        ph_util_row.addWidget(self.btn_dump_xmp)
        cp_lay.addLayout(ph_util_row)
        left_proj_lay.addWidget(card_photos, stretch=2)

        # Card 2: QGIS Layers (Live Sync ON by default)
        card_layers = QFrame()
        card_layers.setProperty("role", "card")
        cl_lay = QVBoxLayout(card_layers)
        cl_lay.setContentsMargins(5, 5, 5, 5)
        cl_lay.setSpacing(3)

        self.lbl_sec_layers = QLabel(tr("sec_studio_layers"))
        self.lbl_sec_layers.setProperty("role", "section")
        cl_lay.addWidget(self.lbl_sec_layers)

        ly_add_row = QHBoxLayout()
        ly_add_row.setSpacing(4)
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(FilterPoint | FilterPolygon | FilterLine | FilterRaster)
        self.btn_add_layer = QPushButton(tr("btn_add"))
        self.btn_add_layer.setProperty("role", "primary")
        self.btn_add_layer.clicked.connect(self.add_combo_layer_to_list)
        ly_add_row.addWidget(self.layer_combo, stretch=1)
        ly_add_row.addWidget(self.btn_add_layer)
        cl_lay.addLayout(ly_add_row)

        self.lbl_hint_layers = QLabel(tr("hint_layers"))
        self.lbl_hint_layers.setProperty("role", "muted")
        self.lbl_hint_layers.setWordWrap(True)
        cl_lay.addWidget(self.lbl_hint_layers)

        self.layer_list = LayerListWidget()
        self.layer_list.setMinimumHeight(60)
        self.layer_list.layersDropped.connect(self.add_dropped_layers_to_list)
        self.layer_list.itemDoubleClicked.connect(self.open_layer_properties)
        self.layer_list.itemChanged.connect(self._on_layer_item_checked_changed)
        cl_lay.addWidget(self.layer_list, stretch=1)

        self.btn_rem_layer = QPushButton(tr("btn_rem_layer"))
        self.btn_rem_layer.setProperty("role", "toolBtn")
        self.btn_rem_layer.clicked.connect(self.remove_selected_layers)
        cl_lay.addWidget(self.btn_rem_layer)
        left_proj_lay.addWidget(card_layers, stretch=2)

        # Card 3: Terrain & Max Distance
        card_terr = QFrame()
        card_terr.setProperty("role", "card")
        ct_lay = QGridLayout(card_terr)
        ct_lay.setContentsMargins(6, 6, 6, 6)
        ct_lay.setSpacing(4)

        self.lbl_sec_terrain = QLabel(tr("sec_studio_terrain"))
        self.lbl_sec_terrain.setProperty("role", "section")
        ct_lay.addWidget(self.lbl_sec_terrain, 0, 0, 1, 2)

        self.lbl_elev_src = QLabel(tr("lbl_elev_src"))
        self.dem_combo = QComboBox()
        self.dem_combo.setMinimumWidth(90)
        self.refresh_dem_sources()
        self.dem_combo.currentIndexChanged.connect(self._on_terrain_settings_changed)
        ct_lay.addWidget(self.lbl_elev_src, 1, 0)
        ct_lay.addWidget(self.dem_combo, 1, 1)

        self.lbl_alt_mode = QLabel(tr("lbl_alt_mode"))
        self.alt_mode_combo = QComboBox()
        self.alt_mode_combo.setMinimumWidth(90)
        self.alt_mode_combo.addItem(tr("alt_auto"), "auto")
        self.alt_mode_combo.addItem(tr("alt_rtk"), "rtk")
        self.alt_mode_combo.addItem(tr("alt_rel"), "rel_dem")
        self.alt_mode_combo.addItem(tr("alt_msl"), "msl")
        idx_am = self.alt_mode_combo.findData(self.global_settings.get("alt_mode", "auto"))
        if idx_am >= 0:
            self.alt_mode_combo.setCurrentIndex(idx_am)
        self.alt_mode_combo.currentIndexChanged.connect(self._on_terrain_settings_changed)
        ct_lay.addWidget(self.lbl_alt_mode, 2, 0)
        ct_lay.addWidget(self.alt_mode_combo, 2, 1)

        self.lbl_fallback_z = QLabel(tr("lbl_fallback_z"))
        self.spin_fallback_z = QDoubleSpinBox()
        self.spin_fallback_z.setRange(-500.0, 9000.0)
        self.spin_fallback_z.setDecimals(2)
        self.spin_fallback_z.setSingleStep(0.5)
        self.spin_fallback_z.setValue(self.fallback_z)
        self.spin_fallback_z.valueChanged.connect(self._on_terrain_settings_changed)
        ct_lay.addWidget(self.lbl_fallback_z, 3, 0)
        ct_lay.addWidget(self.spin_fallback_z, 3, 1)

        self.lbl_max_dist = QLabel(tr("lbl_max_dist"))
        self.spin_max_dist = QDoubleSpinBox()
        self.spin_max_dist.setRange(0.5, 15.0)
        self.spin_max_dist.setDecimals(1)
        self.spin_max_dist.setSingleStep(0.5)
        self.spin_max_dist.setSuffix(" km")
        self.spin_max_dist.setValue(float(self.global_settings.get("max_dist_km", 4.0)))
        self.spin_max_dist.valueChanged.connect(self._on_terrain_settings_changed)
        ct_lay.addWidget(self.lbl_max_dist, 4, 0)
        ct_lay.addWidget(self.spin_max_dist, 4, 1)

        left_proj_lay.addWidget(card_terr)
        proj_scroll.setWidget(left_proj_widget)
        self.left_tabs.addTab(proj_scroll, tr("left_tab_project"))

        # --- Left Tab 1: Jobs Archive ---
        arch_widget = QWidget()
        arch_lay = QVBoxLayout(arch_widget)
        arch_lay.setContentsMargins(6, 6, 6, 6)
        arch_lay.setSpacing(5)

        self.lbl_arch_header = QLabel(tr("arch_header"))
        self.lbl_arch_header.setProperty("role", "section")
        arch_lay.addWidget(self.lbl_arch_header)

        self.lbl_arch_hint = QLabel(tr("arch_hint"))
        self.lbl_arch_hint.setProperty("role", "muted")
        self.lbl_arch_hint.setWordWrap(True)
        arch_lay.addWidget(self.lbl_arch_hint)

        self.archive_list = QListWidget()
        self.archive_list.setIconSize(QSize(64, 44))
        self.archive_list.itemDoubleClicked.connect(self.restore_job)
        arch_lay.addWidget(self.archive_list, stretch=1)

        arch_btns1 = QHBoxLayout()
        self.btn_arch_restore = QPushButton(tr("btn_restore"))
        self.btn_arch_restore.setProperty("role", "primary")
        self.btn_arch_restore.clicked.connect(self.restore_job)
        self.btn_arch_refresh = QPushButton(tr("btn_refresh"))
        self.btn_arch_refresh.clicked.connect(self.refresh_archive_list)
        arch_btns1.addWidget(self.btn_arch_restore)
        arch_btns1.addWidget(self.btn_arch_refresh)
        arch_lay.addLayout(arch_btns1)

        arch_btns2 = QHBoxLayout()
        self.btn_arch_del = QPushButton(tr("btn_del_job"))
        self.btn_arch_del.clicked.connect(self.delete_selected_job)
        self.btn_arch_del_all = QPushButton(tr("btn_del_all"))
        self.btn_arch_del_all.setProperty("role", "danger")
        self.btn_arch_del_all.clicked.connect(self.delete_all_jobs)
        arch_btns2.addWidget(self.btn_arch_del)
        arch_btns2.addWidget(self.btn_arch_del_all)
        arch_lay.addLayout(arch_btns2)

        self.left_tabs.addTab(arch_widget, tr("left_tab_archive"))
        self.main_splitter.addWidget(self.left_tabs)

        # Import any layers from legacy parent dock if launched via MavicDockPanel
        if hasattr(parent, 'layer_list') and parent.layer_list is not None:
            self.layer_list.blockSignals(True)
            for i in range(parent.layer_list.count()):
                p_it = parent.layer_list.item(i)
                lyr = p_it.data(UserRole)
                st = dict(p_it.data(UserRole + 1) or {})
                if lyr is not None and lyr.isValid():
                    n_it = QListWidgetItem(format_layer_item_label(lyr, st))
                    n_it.setData(UserRole, lyr)
                    n_it.setData(UserRole + 1, st)
                    n_it.setFlags(n_it.flags() | ItemIsUserCheckable)
                    n_it.setCheckState(p_it.checkState())
                    n_it.setIcon(make_layer_list_icon(lyr, st))
                    self.layer_list.addItem(n_it)
                    self._connect_layer_live_sync(lyr)
            self.layer_list.blockSignals(False)

        # =====================================================================
        # COL 1 — CENTER PHOTO CANVAS
        # =====================================================================
        self.proj_view = ReverseProjectionView()
        self.proj_view.setMinimumWidth(380)
        self.proj_scene = QGraphicsScene()
        self.proj_scene.selectionChanged.connect(self._on_scene_selection_changed)
        self.proj_view.setScene(self.proj_scene)
        self.proj_view.setDragMode(ScrollHandDrag)
        self.proj_view.scenePressed.connect(self.on_scene_pressed)
        self.proj_view.sceneMoved.connect(self.on_scene_moved)
        self.proj_view.sceneReleased.connect(self.on_scene_released)
        self.proj_view.focalWheelAdjusted.connect(self.on_focal_wheel_adjusted)
        self.main_splitter.addWidget(self.proj_view)

        # =====================================================================
        # COL 2 — RIGHT INSPECTOR (Labels | Draw | Calibrate | Drag Align + Export)
        # =====================================================================
        self.side_panel = QFrame()
        self.side_panel.setProperty("role", "card")
        self.side_panel.setMinimumWidth(305)
        side_layout = QVBoxLayout(self.side_panel)
        side_layout.setContentsMargins(6, 6, 6, 6)
        side_layout.setSpacing(6)
        
        self.main_side_tabs = QTabWidget()
        try:
            self.main_side_tabs.setUsesScrollButtons(True)
        except Exception:
            pass

        # TAB 0: Projected Labels
        scroll_proj = QScrollArea()
        scroll_proj.setWidgetResizable(True)
        self.tab_projected = QWidget()
        proj_lay = QVBoxLayout(self.tab_projected)
        proj_lay.setContentsMargins(6, 6, 6, 6)
        proj_lay.setSpacing(6)
        
        h_tog = QHBoxLayout()
        h_tog.setSpacing(4)
        self.btn_toggle_labels = QPushButton(tr("btn_tog_labels"))
        self.btn_toggle_labels.setProperty("role", "toggleChip")
        self.btn_toggle_labels.setCheckable(True)
        self.btn_toggle_labels.setChecked(True)
        self.btn_toggle_labels.clicked.connect(self.toggle_all_labels)
        
        self.btn_toggle_shadows = QPushButton(tr("btn_tog_shadows"))
        self.btn_toggle_shadows.setProperty("role", "toggleChip")
        self.btn_toggle_shadows.setCheckable(True)
        self.btn_toggle_shadows.setChecked(True)
        self.btn_toggle_shadows.clicked.connect(self.toggle_all_shadows)
        
        self.btn_toggle_callouts = QPushButton(tr("btn_tog_callouts"))
        self.btn_toggle_callouts.setProperty("role", "toggleChip")
        self.btn_toggle_callouts.setCheckable(True)
        self.btn_toggle_callouts.setChecked(True)
        self.btn_toggle_callouts.clicked.connect(self.toggle_all_callouts)

        h_tog.addWidget(self.btn_toggle_labels)
        h_tog.addWidget(self.btn_toggle_shadows)
        h_tog.addWidget(self.btn_toggle_callouts)
        proj_lay.addLayout(h_tog)
        
        h_layer = QHBoxLayout()
        self.lbl_active_layer = QLabel(tr("lbl_active_layer"))
        h_layer.addWidget(self.lbl_active_layer)
        self.combo_proj_layer = QComboBox()
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer = item.data(UserRole)
            if layer:
                self.combo_proj_layer.addItem(layer.name(), layer.id())
        self.combo_proj_layer.currentIndexChanged.connect(self._sync_ui_from_proj_style)
        h_layer.addWidget(self.combo_proj_layer, stretch=1)
        proj_lay.addLayout(h_layer)
        
        self.proj_lbl_canvas = DropTextEdit()
        self.proj_lbl_canvas.setPlaceholderText("[id] - [name]")
        self.proj_lbl_canvas.setMaximumHeight(52)
        self.proj_lbl_canvas.textChanged.connect(self._on_proj_style_changed)
        self.lbl_expr_hint = QLabel(tr("lbl_expr_hint"))
        self.lbl_expr_hint.setProperty("role", "muted")
        proj_lay.addWidget(self.lbl_expr_hint)
        proj_lay.addWidget(self.proj_lbl_canvas)
        
        self.proj_list_fields = QListWidget()
        self.proj_list_fields.setMaximumHeight(68)
        self.proj_list_fields.itemDoubleClicked.connect(self._on_proj_field_dblclicked)
        proj_lay.addWidget(self.proj_list_fields)

        h_sz = QHBoxLayout()
        self.lbl_proj_font = QLabel(tr("lbl_font_size"))
        h_sz.addWidget(self.lbl_proj_font)
        self.spin_proj_font = QSpinBox()
        self.spin_proj_font.setRange(8, 200)
        self.spin_proj_font.valueChanged.connect(self._on_proj_style_changed)
        h_sz.addWidget(self.spin_proj_font)
        
        self.btn_proj_color = QPushButton()
        self.btn_proj_color.setFixedWidth(36)
        self.btn_proj_color.clicked.connect(partial(self._pick_proj_color, "text"))
        h_sz.addWidget(self.btn_proj_color)
        
        self.btn_proj_halo = QPushButton()
        self.btn_proj_halo.setFixedWidth(36)
        self.btn_proj_halo.clicked.connect(partial(self._pick_proj_color, "halo"))
        h_sz.addWidget(self.btn_proj_halo)
        proj_lay.addLayout(h_sz)
        
        h_callout = QHBoxLayout()
        self.lbl_proj_callout_w = QLabel(tr("lbl_callout_w"))
        h_callout.addWidget(self.lbl_proj_callout_w)
        self.spin_callout_w = QSpinBox()
        self.spin_callout_w.setRange(0, 50)
        self.spin_callout_w.valueChanged.connect(self._on_proj_style_changed)
        h_callout.addWidget(self.spin_callout_w)
        
        self.btn_callout_color = QPushButton(tr("btn_color"))
        self.btn_callout_color.clicked.connect(partial(self._pick_proj_color, "callout"))
        h_callout.addWidget(self.btn_callout_color)
        proj_lay.addLayout(h_callout)
        
        h_preset = QHBoxLayout()
        self.lbl_proj_preset = QLabel(tr("lbl_preset"))
        h_preset.addWidget(self.lbl_proj_preset)
        self.combo_proj_preset = QComboBox()
        self.combo_proj_preset.addItems(["Standard (Flat)", "Billboard (Stand-up)"])
        self.combo_proj_preset.currentTextChanged.connect(self._on_proj_style_changed)
        h_preset.addWidget(self.combo_proj_preset, stretch=1)
        
        self.combo_proj_bb_shape = QComboBox()
        self.combo_proj_bb_shape.addItems(["Rounded", "Rectangle"])
        self.combo_proj_bb_shape.currentTextChanged.connect(self._on_proj_style_changed)
        h_preset.addWidget(self.combo_proj_bb_shape)
        proj_lay.addLayout(h_preset)
        
        h_ang = QGridLayout()
        h_ang.setSpacing(4)
        self.lbl_proj_angle = QLabel(tr("lbl_angle"))
        self.dial_proj_angle = QDial()
        self.dial_proj_angle.setRange(-180, 180)
        self.dial_proj_angle.setNotchesVisible(True)
        self.dial_proj_angle.setFixedSize(40, 40)
        
        self.lbl_proj_angle_val = QLabel("45°")
        self.dial_proj_angle.valueChanged.connect(self._on_proj_angle_changed)
        self.dial_proj_angle.valueChanged.connect(self._on_proj_style_changed)
        h_ang.addWidget(self.lbl_proj_angle, 0, 0)
        h_ang.addWidget(self.dial_proj_angle, 0, 1)
        h_ang.addWidget(self.lbl_proj_angle_val, 0, 2)
        
        self.lbl_proj_dist = QLabel(tr("lbl_dist"))
        self.slider_shadow_dist = QSlider(Horizontal)
        self.slider_shadow_dist.setRange(-100, 100)
        self.spin_shadow_dist = QSpinBox()
        self.spin_shadow_dist.setRange(-100, 100)
        self.spin_shadow_dist.setFixedWidth(56)
        self.slider_shadow_dist.valueChanged.connect(self.spin_shadow_dist.setValue)
        self.spin_shadow_dist.valueChanged.connect(self.slider_shadow_dist.setValue)
        self.slider_shadow_dist.valueChanged.connect(self._on_proj_style_changed)
        h_ang.addWidget(self.lbl_proj_dist, 1, 0)
        h_ang.addWidget(self.slider_shadow_dist, 1, 1)
        h_ang.addWidget(self.spin_shadow_dist, 1, 2)

        self.lbl_proj_blur = QLabel(tr("lbl_blur"))
        self.slider_shadow_blur = QSlider(Horizontal)
        self.slider_shadow_blur.setRange(0, 30)
        self.spin_shadow_blur = QSpinBox()
        self.spin_shadow_blur.setRange(0, 30)
        self.spin_shadow_blur.setFixedWidth(56)
        self.slider_shadow_blur.valueChanged.connect(self.spin_shadow_blur.setValue)
        self.spin_shadow_blur.valueChanged.connect(self.slider_shadow_blur.setValue)
        self.slider_shadow_blur.valueChanged.connect(self._on_proj_style_changed)
        h_ang.addWidget(self.lbl_proj_blur, 2, 0)
        h_ang.addWidget(self.slider_shadow_blur, 2, 1)
        h_ang.addWidget(self.spin_shadow_blur, 2, 2)
        proj_lay.addLayout(h_ang)

        self.btn_fast_refresh = QPushButton(tr("btn_fast_refresh"))
        self.btn_fast_refresh.setProperty("role", "success")
        self.btn_fast_refresh.setToolTip("Applies these visual settings to the labels immediately without recalculating vectors.")
        self.btn_fast_refresh.clicked.connect(self.render_projected_labels)
        proj_lay.addWidget(self.btn_fast_refresh)
        proj_lay.addStretch()
        scroll_proj.setWidget(self.tab_projected)
        self.main_side_tabs.addTab(scroll_proj, tr("side_tab_labels"))

        # TAB 1: User-Drawn Annotations
        scroll_user = QScrollArea()
        scroll_user.setWidgetResizable(True)
        self.tab_user_drawn = QWidget()
        user_lay = QVBoxLayout(self.tab_user_drawn)
        user_lay.setContentsMargins(6, 6, 6, 6)
        user_lay.setSpacing(6)
        
        self.sym_tabs = QTabWidget()
        self.sym_ui = {}
        tool_configs = [
            ('pin', tr("tool_pin"), QColor(255, 0, 0)),
            ('line', tr("tool_line"), QColor(255, 255, 0)),
            ('polygon', tr("tool_poly"), QColor(0, 255, 255))
        ]
        
        for t_key, t_name, default_col in tool_configs:
            tab = QWidget()
            lay = QVBoxLayout(tab)
            lay.setContentsMargins(8, 10, 8, 8)
            lay.setSpacing(6)
            
            c_row = QHBoxLayout()
            c_row.addWidget(QLabel(tr("btn_color") + ":"))
            btn_col = QPushButton()
            btn_col.setStyleSheet(f"background-color: {default_col.name()}; border: 1px solid #888; min-height: 22px;")
            c_row.addWidget(btn_col)
            lay.addLayout(c_row)
            
            s_row = QHBoxLayout()
            s_row.addWidget(QLabel("Size / Width:"))
            spin_sz = QSpinBox()
            spin_sz.setRange(1, 50)
            spin_sz.setValue(6)
            s_row.addWidget(spin_sz)
            lay.addLayout(s_row)
            
            chk_p = QCheckBox("Apply 3D Perspective")
            chk_p.setChecked(True)
            chk_p.stateChanged.connect(self.load_existing_features)
            lay.addWidget(chk_p)
            
            lay.addWidget(QLabel("Map Label Field:"))
            combo_lbl = QComboBox()
            combo_lbl.addItems(["id", "note", "photo", "measurement"])
            lay.addWidget(combo_lbl)
            lay.addStretch()
            
            self.sym_tabs.addTab(tab, t_name)
            
            self.sym_ui[t_key] = {
                'color': default_col,
                'btn_color': btn_col,
                'spin_size': spin_sz,
                'chk_persp': chk_p,
                'combo_label': combo_lbl
            }
            
            btn_col.clicked.connect(partial(self.pick_color, t_key))
            combo_lbl.currentTextChanged.connect(partial(self.change_map_label, t_key))

        user_lay.addWidget(self.sym_tabs)
        
        self.lbl_detail_title = QLabel("<b>Feature Details</b><br><span style='font-size:10px;'>Select a tool and draw.</span>")
        user_lay.addWidget(self.lbl_detail_title)
        
        user_lay.addWidget(QLabel("Note / ID:"))
        self.txt_feature_note = QLineEdit()
        self.txt_feature_note.setEnabled(False)
        self.txt_feature_note.textEdited.connect(self.on_note_typing)
        self.txt_feature_note.editingFinished.connect(self.save_note_to_qgis)
        user_lay.addWidget(self.txt_feature_note)
        user_lay.addStretch()
        scroll_user.setWidget(self.tab_user_drawn)
        self.main_side_tabs.addTab(scroll_user, tr("side_tab_draw"))

        # TAB 2: Calibrate (Pose Offsets + Tie Points)
        scroll_align = QScrollArea()
        scroll_align.setWidgetResizable(True)
        self.tab_align = QWidget()
        align_lay = QVBoxLayout(self.tab_align)
        align_lay.setContentsMargins(5, 5, 5, 5)
        align_lay.setSpacing(5)

        self.lbl_manual_title = QLabel(tr("lbl_manual_title"))
        self.lbl_manual_title.setProperty("role", "section")
        align_lay.addWidget(self.lbl_manual_title)
        
        h_lens = QHBoxLayout()
        self.lbl_force_lens = QLabel(tr("lbl_force_lens"))
        h_lens.addWidget(self.lbl_force_lens)
        self.combo_lens = QComboBox()
        self.combo_lens.addItem(tr("lens_auto"), "Auto")
        self.combo_lens.addItem(tr("lens_wide"), "Wide")
        self.combo_lens.addItem(tr("lens_zoom"), "Zoom")
        self.combo_lens.currentIndexChanged.connect(self.apply_manual_offsets)
        h_lens.addWidget(self.combo_lens, stretch=1)
        align_lay.addLayout(h_lens)

        grid_manual = QGridLayout()
        grid_manual.setContentsMargins(0, 0, 0, 0)
        grid_manual.setSpacing(5)
        
        self.spin_man_pitch = QDoubleSpinBox()
        self.spin_man_pitch.setRange(-45.0, 45.0)
        self.spin_man_pitch.setDecimals(2)
        self.spin_man_pitch.setSingleStep(0.1)
        
        self.spin_man_yaw = QDoubleSpinBox()
        self.spin_man_yaw.setRange(-180.0, 180.0)
        self.spin_man_yaw.setDecimals(2)
        self.spin_man_yaw.setSingleStep(0.1)

        self.spin_man_roll = QDoubleSpinBox()
        self.spin_man_roll.setRange(-45.0, 45.0)
        self.spin_man_roll.setDecimals(2)
        self.spin_man_roll.setSingleStep(0.1)

        self.spin_man_focal = QDoubleSpinBox()
        self.spin_man_focal.setRange(50.0, 250.0)
        self.spin_man_focal.setDecimals(2)
        self.spin_man_focal.setSingleStep(0.5)
        self.spin_man_focal.setValue(100.0)
        
        self.spin_man_x = QDoubleSpinBox()
        self.spin_man_x.setRange(-500.0, 500.0)
        self.spin_man_x.setDecimals(2)
        self.spin_man_x.setSingleStep(0.5)
        
        self.spin_man_y = QDoubleSpinBox()
        self.spin_man_y.setRange(-500.0, 500.0)
        self.spin_man_y.setDecimals(2)
        self.spin_man_y.setSingleStep(0.5)
        
        self.chk_man_auto_geoid = QCheckBox(tr("chk_auto_geoid"))
        self.chk_man_auto_geoid.setChecked(True)
        self.spin_man_geoid = QDoubleSpinBox()
        self.spin_man_geoid.setRange(-100.0, 100.0)
        self.spin_man_geoid.setDecimals(2)
        self.spin_man_geoid.setSingleStep(0.2)
        self.spin_man_geoid.setEnabled(False)
        self.chk_man_auto_geoid.toggled.connect(self._on_man_auto_geoid_toggled)

        self.spin_man_k1 = QDoubleSpinBox(); self.spin_man_k1.setRange(-0.5, 0.5); self.spin_man_k1.setDecimals(3); self.spin_man_k1.setSingleStep(0.01)
        self.spin_man_k2 = QDoubleSpinBox(); self.spin_man_k2.setRange(-0.5, 0.5); self.spin_man_k2.setDecimals(3); self.spin_man_k2.setSingleStep(0.01)
        self.spin_man_p1 = QDoubleSpinBox(); self.spin_man_p1.setRange(-0.5, 0.5); self.spin_man_p1.setDecimals(3); self.spin_man_p1.setSingleStep(0.01)
        self.spin_man_p2 = QDoubleSpinBox(); self.spin_man_p2.setRange(-0.5, 0.5); self.spin_man_p2.setDecimals(3); self.spin_man_p2.setSingleStep(0.01)
        self.spin_man_k3 = QDoubleSpinBox(); self.spin_man_k3.setRange(-0.5, 0.5); self.spin_man_k3.setDecimals(3); self.spin_man_k3.setSingleStep(0.01)
        
        self.lbl_man_pitch = QLabel(tr("lbl_pitch"))
        self.lbl_man_yaw = QLabel(tr("lbl_yaw"))
        self.lbl_man_roll = QLabel(tr("lbl_roll"))
        self.lbl_man_focal = QLabel(tr("lbl_focal_pct"))
        self.lbl_man_x = QLabel(tr("lbl_x_east"))
        self.lbl_man_y = QLabel(tr("lbl_y_north"))

        h_geoid = QHBoxLayout()
        h_geoid.addWidget(self.chk_man_auto_geoid)
        h_geoid.addWidget(self.spin_man_geoid, stretch=1)
        align_lay.addLayout(h_geoid)

        grid_manual.addWidget(self.lbl_man_pitch, 0, 0)
        grid_manual.addWidget(self.spin_man_pitch, 0, 1)
        grid_manual.addWidget(self.lbl_man_yaw, 0, 2)
        grid_manual.addWidget(self.spin_man_yaw, 0, 3)

        grid_manual.addWidget(self.lbl_man_roll, 1, 0)
        grid_manual.addWidget(self.spin_man_roll, 1, 1)
        grid_manual.addWidget(self.lbl_man_focal, 1, 2)
        grid_manual.addWidget(self.spin_man_focal, 1, 3)
        
        grid_manual.addWidget(self.lbl_man_x, 2, 0)
        grid_manual.addWidget(self.spin_man_x, 2, 1)
        grid_manual.addWidget(self.lbl_man_y, 2, 2)
        grid_manual.addWidget(self.spin_man_y, 2, 3)
        
        grid_manual.addWidget(QLabel("k1:"), 3, 0)
        grid_manual.addWidget(self.spin_man_k1, 3, 1)
        grid_manual.addWidget(QLabel("k2:"), 3, 2)
        grid_manual.addWidget(self.spin_man_k2, 3, 3)
        
        grid_manual.addWidget(QLabel("k3:"), 4, 0)
        grid_manual.addWidget(self.spin_man_k3, 4, 1)
        grid_manual.addWidget(QLabel("p1:"), 4, 2)
        grid_manual.addWidget(self.spin_man_p1, 4, 3)
        
        grid_manual.addWidget(QLabel("p2:"), 5, 0)
        grid_manual.addWidget(self.spin_man_p2, 5, 1)
        
        align_lay.addLayout(grid_manual)
        
        btn_lay = QHBoxLayout()
        self.btn_reset_manual = QPushButton(tr("btn_reset"))
        self.btn_reset_manual.clicked.connect(self.reset_manual_offsets)
        
        self.btn_apply_manual = QPushButton(tr("btn_apply"))
        self.btn_apply_manual.setProperty("role", "primary")
        self.btn_apply_manual.clicked.connect(self.apply_manual_offsets)
        
        btn_lay.addWidget(self.btn_reset_manual)
        btn_lay.addWidget(self.btn_apply_manual, stretch=2)
        align_lay.addLayout(btn_lay)

        self.btn_copy_all_photos = QPushButton(tr("btn_copy_all_photos"))
        self.btn_copy_all_photos.setToolTip(tr("tip_copy_all_photos"))
        self.btn_copy_all_photos.clicked.connect(self.apply_offsets_to_all_photos)
        align_lay.addWidget(self.btn_copy_all_photos)

        self.lbl_tie_title = QLabel(tr("lbl_tie_title"))
        self.lbl_tie_title.setProperty("role", "section")
        align_lay.addWidget(self.lbl_tie_title)
        
        self.tbl_ties = QTableWidget()
        self.tbl_ties.setColumnCount(4)
        self.tbl_ties.setHorizontalHeaderLabels(["img U", "img V", "map X", "map Y"])
        try:
            self.tbl_ties.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        except AttributeError:
            self.tbl_ties.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        try:
            self.tbl_ties.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.tbl_ties.setSelectionBehavior(QAbstractItemView.SelectRows)
        except AttributeError:
            self.tbl_ties.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            self.tbl_ties.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl_ties.setMinimumHeight(76)
        self.tbl_ties.setMaximumHeight(125)
        self.tbl_ties.keyPressEvent = self.tbl_ties_keyPressEvent
        align_lay.addWidget(self.tbl_ties)

        self.chk_refine_focal = QCheckBox(tr("chk_refine_focal"))
        self.chk_refine_focal.setChecked(False)
        align_lay.addWidget(self.chk_refine_focal)
        
        tie_btns = QHBoxLayout()
        tie_btns.setSpacing(4)
        self.btn_calc_xy = QPushButton(tr("btn_calc_xy"))
        self.btn_calc_xy.setProperty("role", "primary")
        self.btn_calc_xy.clicked.connect(self.calculate_xy_alignment)
        
        self.btn_calc_imu = QPushButton(tr("btn_calc_imu"))
        self.btn_calc_imu.setProperty("role", "primary")
        self.btn_calc_imu.clicked.connect(self.calculate_imu_alignment)
        
        self.btn_calc_3d = QPushButton(tr("btn_calc_3d"))
        self.btn_calc_3d.clicked.connect(self.calculate_3d_alignment)
        
        self.btn_clear_ties = QPushButton("🗑️")
        self.btn_clear_ties.setMaximumWidth(32)
        self.btn_clear_ties.clicked.connect(self.clear_tie_points)
        
        tie_btns.addWidget(self.btn_calc_xy)
        tie_btns.addWidget(self.btn_calc_imu)
        tie_btns.addWidget(self.btn_calc_3d)
        tie_btns.addWidget(self.btn_clear_ties)
        align_lay.addLayout(tie_btns)
        align_lay.addStretch()

        scroll_align.setWidget(self.tab_align)
        self.main_side_tabs.addTab(scroll_align, tr("side_tab_align"))

        # TAB 3: Embedded Drag Align Panel (No Floating Dialog!)
        scroll_da = QScrollArea()
        scroll_da.setWidgetResizable(True)
        scroll_da.setHorizontalScrollBarPolicy(ScrollBarAlwaysOff)
        self.drag_align_panel = DragAlignPanel(self)
        self.drag_align_panel.modeChanged.connect(self._on_da_mode_changed)
        self.drag_align_panel.poseSlidersChanged.connect(self._on_da_pose_sliders)
        self.drag_align_panel.forwardPitchChanged.connect(self._on_da_forward_pitch)
        self.drag_align_panel.wireframeStyleChanged.connect(self._on_da_wireframe_style)
        self.drag_align_panel.hideBakedChanged.connect(self._on_da_hide_baked_changed)
        self.drag_align_panel.autoHorizonRequested.connect(self.run_auto_horizon)
        self.drag_align_panel.applyRequested.connect(self.apply_manual_offsets)
        self.drag_align_panel.resetRequested.connect(self.reset_manual_offsets)
        self._wf_color, self._wf_width, self._wf_visible = self.drag_align_panel.current_wireframe_style()
        self._hide_baked_during_da = self.drag_align_panel.hide_baked_overlay
        scroll_da.setWidget(self.drag_align_panel)
        self.main_side_tabs.addTab(scroll_da, tr("side_tab_drag_align"))

        self.main_side_tabs.setCurrentIndex(2)
        self.main_side_tabs.currentChanged.connect(self._on_side_tab_changed)
        side_layout.addWidget(self.main_side_tabs, stretch=1)

        # Pinned Export & Batch Progress Footer Card
        exp_card = QFrame()
        exp_card.setProperty("role", "card")
        exp_lay = QVBoxLayout(exp_card)
        exp_lay.setContentsMargins(6, 5, 6, 5)
        exp_lay.setSpacing(4)
        self.lbl_export_title = QLabel(tr("lbl_export_title"))
        self.lbl_export_title.setProperty("role", "section")
        exp_lay.addWidget(self.lbl_export_title)

        prog_row = QHBoxLayout()
        self.export_progress = QProgressBar()
        self.export_progress.setValue(0)
        self.export_progress.setFormat(tr("progress_ready"))
        self.export_progress.setVisible(False)
        self.btn_cancel_task = QPushButton(tr("btn_cancel"))
        self.btn_cancel_task.setProperty("role", "danger")
        self.btn_cancel_task.clicked.connect(self.cancel_active_tasks)
        self.btn_cancel_task.setVisible(False)
        prog_row.addWidget(self.export_progress, stretch=1)
        prog_row.addWidget(self.btn_cancel_task)
        exp_lay.addLayout(prog_row)
        
        btn_exp_lay = QHBoxLayout()
        btn_exp_lay.setSpacing(4)
        self.btn_exp_curr = QPushButton(tr("btn_export_curr"))
        self.btn_exp_curr.clicked.connect(self.export_current)
        
        self.btn_exp_all = QPushButton(tr("btn_batch_export_all"))
        self.btn_exp_all.setProperty("role", "primary")
        self.btn_exp_all.clicked.connect(self.export_all)
        
        btn_exp_lay.addWidget(self.btn_exp_curr)
        btn_exp_lay.addWidget(self.btn_exp_all)
        exp_lay.addLayout(btn_exp_lay)
        side_layout.addWidget(exp_card)

        self.main_splitter.addWidget(self.side_panel)
        self.main_splitter.setCollapsible(0, True)
        self.main_splitter.setCollapsible(1, False)
        self.main_splitter.setCollapsible(2, False)
        self.main_splitter.setStretchFactor(0, 0)
        self.main_splitter.setStretchFactor(1, 1)
        self.main_splitter.setStretchFactor(2, 0)
        self._apply_initial_screen_geometry()
        
        for item_data in self.gallery_data:
            base_n = os.path.basename(item_data['raw_path'])
            label_txt = f"{base_n} [Custom Offsets]" if _has_meaningful_overrides(item_data.get('overrides')) else base_n
            list_item = QListWidgetItem(label_txt)
            list_item.setToolTip(item_data['raw_path'])
            list_item.setData(UserRole, item_data['raw_path'])
            list_item.setData(UserRole + 1, item_data.get('overrides', {}))
            icon_path = item_data['proj_path'] if os.path.exists(item_data.get('proj_path', '')) else item_data['raw_path']
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                list_item.setIcon(QIcon(pixmap.scaled(68, 46, KeepAspectRatio)))
            self.filmstrip.addItem(list_item)
            
        self.filmstrip.currentRowChanged.connect(self.load_photo)
        
        self.map_rubberband = QgsRubberBand(self.map_canvas, QgsWkbTypes.LineGeometry) if self.map_canvas else None
        if self.map_rubberband:
            self.map_rubberband.setWidth(3)
            self.map_rubberband.setColor(QColor(255, 255, 0, 150))

        self.refresh_archive_list()
        if self._explicit_dem_layer is None:
            self.dem_layer = self.get_or_create_dem_layer()

        if 0 <= start_index < len(self.gallery_data):
            self.filmstrip.setCurrentRow(start_index)
        elif len(self.gallery_data) > 0:
            self.filmstrip.setCurrentRow(0)
        else:
            self._show_empty_canvas_message()
            
        self._sync_ui_from_proj_style()
        self.retranslate_ui()
        self.apply_current_theme()

        ui_prefs.languageChanged.connect(self.retranslate_ui)
        ui_prefs.themeChanged.connect(self.apply_current_theme)
        QgsProject.instance().layersAdded.connect(self.refresh_dem_sources)
        QgsProject.instance().layersRemoved.connect(self.refresh_dem_sources)

    def _on_proj_field_dblclicked(self, item):
        if item is not None:
            self.proj_lbl_canvas.insertPlainText(f"[{item.text()}]")

    def _on_proj_angle_changed(self, v):
        self.lbl_proj_angle_val.setText(f"{v}°")

    def _log_task_message(self, msg):
        QgsMessageLog.logMessage(msg, "MavicProjector", Qgis.Info)

    def apply_current_theme(self, *_args):
        apply_theme(self)
        self.btn_theme.setText(tr("theme_light") if ui_prefs.theme == "dark" else tr("theme_dark"))

    def retranslate_ui(self, *_args):
        if self.photo_name:
            self.setWindowTitle(tr("studio_title_photo", name=self.photo_name))
        else:
            self.setWindowTitle(tr("studio_title"))

        # Left Rail
        self.left_tabs.setTabText(0, tr("left_tab_project"))
        self.left_tabs.setTabText(1, tr("left_tab_archive"))
        self.lbl_sec_photos.setText(tr("sec_studio_photos"))
        self.btn_browse_photos.setText(tr("btn_browse_photos"))
        self.btn_rem_photo.setText(tr("btn_rem_photo"))
        self.lbl_hint_photos.setText(tr("hint_photos"))
        has_cam = bool(QgsProject.instance().mapLayersByName("Drone Cameras"))
        self.btn_show_cams.setText(tr("btn_hide_cams") if has_cam else tr("btn_show_cams"))
        self.btn_dump_xmp.setText(tr("btn_dump_xmp"))

        self.lbl_sec_layers.setText(tr("sec_studio_layers"))
        self.btn_add_layer.setText(tr("btn_add"))
        self.lbl_hint_layers.setText(tr("hint_layers"))
        self.btn_rem_layer.setText(tr("btn_rem_layer"))

        self.lbl_sec_terrain.setText(tr("sec_studio_terrain"))
        self.lbl_elev_src.setText(tr("lbl_elev_src"))
        self.refresh_dem_sources()
        self.lbl_alt_mode.setText(tr("lbl_alt_mode"))
        self.alt_mode_combo.setItemText(0, tr("alt_auto"))
        self.alt_mode_combo.setItemText(1, tr("alt_rtk"))
        self.alt_mode_combo.setItemText(2, tr("alt_rel"))
        self.alt_mode_combo.setItemText(3, tr("alt_msl"))
        self.lbl_fallback_z.setText(tr("lbl_fallback_z"))
        self.lbl_max_dist.setText(tr("lbl_max_dist"))

        self.lbl_arch_header.setText(tr("arch_header"))
        self.lbl_arch_hint.setText(tr("arch_hint"))
        self.btn_arch_restore.setText(tr("btn_restore"))
        self.btn_arch_refresh.setText(tr("btn_refresh"))
        self.btn_arch_del.setText(tr("btn_del_job"))
        self.btn_arch_del_all.setText(tr("btn_del_all"))

        # Center Toolbars
        left_hidden = self.left_tabs.isHidden() or (self.main_splitter.sizes()[0] == 0)
        self.btn_toggle_left.setText(tr("btn_toggle_left_show") if left_hidden else tr("btn_toggle_left_hide"))
        self.btn_toggle_left.setToolTip(tr("tip_toggle_left"))
        self.btn_toggle_overlay.setText(tr("btn_overlay_toggle"))
        self.btn_toggle_overlay.setToolTip(tr("tip_overlay_toggle"))
        self.btn_horizon_menu.setText(tr("btn_horizon_menu"))
        self.btn_horizon_menu.setToolTip(tr("tip_horizon_menu"))
        self.act_auto_horizon.setText(tr("act_auto_horizon"))
        self.act_manual_horizon.setText(tr("act_manual_horizon"))

        self.btn_lang.setText(tr("lang_toggle"))
        self.btn_lang.setToolTip(tr("lang_tooltip"))
        self.btn_theme.setText(tr("theme_light") if ui_prefs.theme == "dark" else tr("theme_dark"))
        self.btn_theme.setToolTip(tr("theme_tooltip"))

        self.btn_pan.setText(tr("tool_pan"))
        self.btn_edit.setText(tr("tool_edit"))
        self.btn_place.setText(tr("tool_place"))
        self.btn_pin.setText(tr("tool_pin"))
        self.btn_line.setText(tr("tool_line"))
        self.btn_poly.setText(tr("tool_poly"))
        self.btn_remove.setText(tr("tool_remove"))
        self.btn_tie_point.setText(tr("tool_tie"))
        self.btn_drag_align.setText(tr("tool_drag_align"))
        self.btn_refresh.setText(tr("tool_recalc"))

        self.chk_show_all.setText(tr("chk_show_all_drawn"))
        self.chk_show_all.setToolTip(tr("tip_show_all_drawn"))
        self.btn_undo.setText(tr("btn_undo"))
        self.btn_redo.setText(tr("btn_redo"))
        self.btn_clear.setText(tr("btn_clear_photo"))

        # Right Inspector
        self.main_side_tabs.setTabText(0, tr("side_tab_labels"))
        self.main_side_tabs.setTabText(1, tr("side_tab_draw"))
        self.main_side_tabs.setTabText(2, tr("side_tab_align"))
        self.main_side_tabs.setTabText(3, tr("side_tab_drag_align"))

        self.btn_toggle_labels.setText(tr("btn_tog_labels"))
        self.btn_toggle_shadows.setText(tr("btn_tog_shadows"))
        self.btn_toggle_callouts.setText(tr("btn_tog_callouts"))
        self.lbl_active_layer.setText(tr("lbl_active_layer"))
        self.lbl_expr_hint.setText(tr("lbl_expr_hint"))
        self.lbl_proj_font.setText(tr("lbl_font_size"))
        self.lbl_proj_callout_w.setText(tr("lbl_callout_w"))
        self.btn_callout_color.setText(tr("btn_color"))
        self.lbl_proj_preset.setText(tr("lbl_preset"))
        self.lbl_proj_angle.setText(tr("lbl_angle"))
        self.lbl_proj_dist.setText(tr("lbl_dist"))
        self.lbl_proj_blur.setText(tr("lbl_blur"))
        self.btn_fast_refresh.setText(tr("btn_fast_refresh"))

        self.sym_tabs.setTabText(0, tr("tool_pin"))
        self.sym_tabs.setTabText(1, tr("tool_line"))
        self.sym_tabs.setTabText(2, tr("tool_poly"))

        self.lbl_manual_title.setText(tr("lbl_manual_title"))
        self.lbl_force_lens.setText(tr("lbl_force_lens"))
        self.combo_lens.setItemText(0, tr("lens_auto"))
        self.combo_lens.setItemText(1, tr("lens_wide"))
        self.combo_lens.setItemText(2, tr("lens_zoom"))

        self.lbl_man_pitch.setText(tr("lbl_pitch"))
        self.lbl_man_yaw.setText(tr("lbl_yaw"))
        self.lbl_man_roll.setText(tr("lbl_roll"))
        self.lbl_man_focal.setText(tr("lbl_focal_pct"))
        self.lbl_man_x.setText(tr("lbl_x_east"))
        self.lbl_man_y.setText(tr("lbl_y_north"))
        self.chk_man_auto_geoid.setText(tr("chk_auto_geoid"))
        self.btn_reset_manual.setText(tr("btn_reset"))
        self.btn_apply_manual.setText(tr("btn_apply"))
        self.btn_copy_all_photos.setText(tr("btn_copy_all_photos"))
        self.btn_copy_all_photos.setToolTip(tr("tip_copy_all_photos"))

        self.lbl_tie_title.setText(tr("lbl_tie_title"))
        self.chk_refine_focal.setText(tr("chk_refine_focal"))
        self.btn_calc_xy.setText(tr("btn_calc_xy"))
        self.btn_calc_imu.setText(tr("btn_calc_imu"))
        self.btn_calc_3d.setText(tr("btn_calc_3d"))

        self.lbl_export_title.setText(tr("lbl_export_title"))
        self.btn_exp_curr.setText(tr("btn_export_curr"))
        self.btn_exp_all.setText(tr("btn_batch_export_all"))
        self.btn_cancel_task.setText(tr("btn_cancel"))
        if self.drag_align_panel is not None:
            self.drag_align_panel.retranslate_ui()

        tool_hint_keys = {
            'edit': 'hint_edit',
            'place_label': 'hint_place',
            'pin': 'hint_pin',
            'line': 'hint_line',
            'polygon': 'hint_poly',
            'remove': 'hint_remove',
            'tie_point': 'hint_tie',
            'horizon': 'hint_horizon_1',
            'drag_align': 'hint_drag_align',
        }
        if self.current_tool in tool_hint_keys:
            self.hint.setText(tr(tool_hint_keys[self.current_tool]))

        if len(self.gallery_data) == 0:
            self._show_empty_canvas_message()

    def _compute_splitter_sizes_for_width(self, total_w):
        left_w = max(220, min(265, int(total_w * 0.185)))
        right_w = max(310, min(365, int(total_w * 0.255)))
        center_w = max(390, total_w - left_w - right_w - 20)
        return [left_w, center_w, right_w]

    def _apply_initial_screen_geometry(self):
        screen = self.screen() or QApplication.primaryScreen()
        if screen is not None:
            avail = screen.availableGeometry()
            target_w = min(1540, max(1020, int(avail.width() * 0.94)))
            target_h = min(880, max(620, int(avail.height() * 0.91)))
            target_w = min(target_w, avail.width())
            target_h = min(target_h, avail.height())
            self.resize(target_w, target_h)
            x = avail.x() + max(0, (avail.width() - target_w) // 2)
            y = avail.y() + max(0, (avail.height() - target_h) // 2)
            self.move(x, y)
        else:
            self.resize(1360, 760)
        sizes = self._compute_splitter_sizes_for_width(self.width())
        self._left_panel_saved_width = sizes[0]
        self.main_splitter.setSizes(sizes)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._initial_layout_applied:
            self._initial_layout_applied = True
            sizes = self._compute_splitter_sizes_for_width(self.width())
            self._left_panel_saved_width = sizes[0]
            self.main_splitter.setSizes(sizes)
            if self.proj_bg_item is not None:
                self.proj_view.fitInView(self.proj_scene.sceneRect(), KeepAspectRatio)

    def toggle_left_panel(self, *_args):
        sizes = self.main_splitter.sizes()
        if self.left_tabs.isHidden() or sizes[0] == 0:
            self.left_tabs.show()
            restore_w = max(220, self._left_panel_saved_width)
            rem = max(700, sum(sizes) - restore_w)
            right_w = sizes[2] if sizes[2] >= 305 else max(310, int(rem * 0.31))
            center_w = max(390, rem - right_w)
            self.main_splitter.setSizes([restore_w, center_w, right_w])
            self.btn_toggle_left.setText(tr("btn_toggle_left_hide"))
        else:
            self._left_panel_saved_width = max(220, sizes[0])
            self.left_tabs.hide()
            self.main_splitter.setSizes([0, sizes[1] + sizes[0], sizes[2]])
            self.btn_toggle_left.setText(tr("btn_toggle_left_show"))

    def _on_side_tab_changed(self, idx):
        if idx == 3:
            if self.current_tool not in ('drag_align', 'horizon'):
                self.btn_drag_align.setChecked(True)
                self.on_tool_changed(self.btn_drag_align)
        else:
            if self.current_tool == 'drag_align':
                self.btn_pan.setChecked(True)
                self.on_tool_changed(self.btn_pan)

    def activate_manual_horizon_tool(self, *_args):
        self.tool_group.setExclusive(False)
        for b in self.tool_group.buttons():
            b.setChecked(False)
        self.tool_group.setExclusive(True)
        self.btn_horizon_menu.setChecked(True)
        self.current_tool = 'horizon'
        self._clear_horizon_graphics()
        self._set_wireframe_visible(False)
        self.proj_view.setDragMode(NoDrag)
        self.proj_view.setCursor(CrossCursor)
        self.hint.setText(tr("hint_horizon_1"))
        if self.drag_align_panel is not None:
            self.drag_align_panel.set_active_mode('horizon', emit_signal=False)
        self._apply_overlay_visibility()

    # =========================================================================
    # STUDIO PROJECT INPUTS, UNIFIED OVERLAY CANVAS & ARCHIVE MANAGEMENT
    # =========================================================================

    def _show_empty_canvas_message(self):
        self.proj_scene.clear()
        self.proj_bg_item = None
        self._wireframe_item_proj = None
        self._projected_graphics.clear()
        self._persistent_graphics.clear()
        self._raw_pixmap = QPixmap()
        self._proj_pixmap = QPixmap()

        msg_item = QGraphicsTextItem(tr("empty_canvas_hint"))
        fnt = QFont("Segoe UI", 14)
        fnt.setBold(True)
        msg_item.setFont(fnt)
        msg_item.setDefaultTextColor(QColor("#8899ac") if ui_prefs.theme == "dark" else QColor("#526275"))
        self.proj_scene.addItem(msg_item)
        br = msg_item.boundingRect()
        self.proj_scene.setSceneRect(QRectF(-40.0, -40.0, br.width() + 80.0, br.height() + 80.0))

    def _on_overlay_toggled(self, _checked):
        self._apply_overlay_visibility()

    def _apply_overlay_visibility(self):
        show_ov = self.btn_toggle_overlay.isChecked() and not self._space_peeking
        hide_stale_baked = (
            self.current_tool == 'drag_align'
            and self._wf_visible
            and self._hide_baked_during_da
            and self._wireframe_dirty_since_render
        )
        if self.proj_bg_item is not None and self.proj_bg_item.scene() == self.proj_scene:
            use_proj = (
                show_ov
                and not hide_stale_baked
                and self.layer_list.count() > 0
                and not self._proj_pixmap.isNull()
            )
            target_pix = self._proj_pixmap if use_proj else self._raw_pixmap
            if not target_pix.isNull():
                self.proj_bg_item.setPixmap(target_pix)

        for it in self._persistent_graphics:
            try:
                it.setVisible(show_ov and not hide_stale_baked)
            except RuntimeError:
                pass

        if not show_ov or hide_stale_baked:
            for it in self._projected_graphics:
                try:
                    it.setVisible(False)
                except RuntimeError:
                    pass
        else:
            self.toggle_all_labels()

    def _sync_filmstrip_item_label(self, row):
        if row < 0 or row >= len(self.gallery_data):
            return
        data = self.gallery_data[row]
        overrides = data.get('overrides', {})
        base_n = os.path.basename(data['raw_path'])
        lbl = f"{base_n} [Custom Offsets]" if _has_meaningful_overrides(overrides) else base_n
        if row < self.filmstrip.count():
            f_it = self.filmstrip.item(row)
            f_it.setData(UserRole + 1, overrides)
            f_it.setText(lbl)
        if hasattr(self.parent(), 'photo_list') and self.parent().photo_list is not None:
            if row < self.parent().photo_list.count():
                p_it = self.parent().photo_list.item(row)
                p_it.setData(UserRole + 1, overrides)
                p_it.setText(lbl)

    def browse_photos(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Select DJI Photos", "", "JPEG Images (*.jpg *.jpeg *.JPG *.JPEG)"
        )
        if files:
            self.add_photos_to_studio(files)

    def add_photos_to_studio(self, file_paths):
        from ..core.metadata_parser import MetadataParser

        temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
        os.makedirs(temp_dir, exist_ok=True)

        existing = {os.path.normcase(os.path.abspath(d['raw_path'])) for d in self.gallery_data}
        added_any = False
        warned_projected = False

        self.filmstrip.blockSignals(True)
        try:
            for path in file_paths:
                if not path or not os.path.exists(path):
                    continue
                norm_p = os.path.normcase(os.path.abspath(path))
                if norm_p in existing:
                    continue
                existing.add(norm_p)
                name = os.path.basename(path)
                stem, _ = os.path.splitext(name)
                proj_path = os.path.join(temp_dir, f"{stem}_PROJECTED.jpg")
                entry = {
                    'name': name,
                    'raw_path': path,
                    'proj_path': proj_path,
                    'overrides': {},
                }
                self.gallery_data.append(entry)

                list_item = QListWidgetItem(name)
                list_item.setToolTip(path)
                list_item.setData(UserRole, path)
                list_item.setData(UserRole + 1, {})
                pix = QPixmap(path)
                if not pix.isNull():
                    list_item.setIcon(QIcon(pix.scaled(68, 46, KeepAspectRatio)))
                self.filmstrip.addItem(list_item)
                added_any = True

                try:
                    tel = MetadataParser.extract_xmp(path)
                    if tel.get('already_projected'):
                        warned_projected = True
                except Exception:
                    pass
        finally:
            self.filmstrip.blockSignals(False)

        if warned_projected:
            self.hint.setText(tr("meta_warn_projected"))

        if added_any and self.filmstrip.currentRow() < 0 and len(self.gallery_data) > 0:
            self.filmstrip.setCurrentRow(0)

    def remove_selected_photos(self):
        sel_rows = sorted({self.filmstrip.row(it) for it in self.filmstrip.selectedItems()}, reverse=True)
        if not sel_rows and self.filmstrip.currentRow() >= 0:
            sel_rows = [self.filmstrip.currentRow()]
        if not sel_rows:
            return

        prev_row = min(sel_rows)
        self.filmstrip.blockSignals(True)
        try:
            for r in sel_rows:
                if 0 <= r < len(self.gallery_data):
                    rem = self.gallery_data.pop(r)
                    self._projected_label_cache.pop(rem.get('raw_path', ''), None)
                if 0 <= r < self.filmstrip.count():
                    self.filmstrip.takeItem(r)
        finally:
            self.filmstrip.blockSignals(False)

        if len(self.gallery_data) == 0:
            self.photo_name = ""
            self.engine = None
            self.setWindowTitle(tr("studio_title"))
            self._show_empty_canvas_message()
        else:
            next_row = min(prev_row, len(self.gallery_data) - 1)
            self.filmstrip.blockSignals(True)
            self.filmstrip.setCurrentRow(next_row)
            self.filmstrip.blockSignals(False)
            self.load_photo(next_row)

    def open_photo_properties(self, item):
        row = self.filmstrip.row(item)
        if row < 0 or row >= len(self.gallery_data):
            return
        data = self.gallery_data[row]
        dialog = PhotoPropertiesDialog(data['raw_path'], data.get('overrides', {}), self)
        if exec_dialog(dialog):
            overrides = dialog.get_overrides()
            keep_lbl = data.get('overrides', {}).get('label_offsets', {})
            if keep_lbl:
                overrides['label_offsets'] = keep_lbl
            data['overrides'] = overrides
            self._sync_filmstrip_item_label(row)
            self._projected_label_cache.pop(data['raw_path'], None)
            if row == self.filmstrip.currentRow():
                self.load_photo(row, keep_snaps=True)
                self._run_single_projection(data)

    def dump_xmp_for_selected(self):
        row = self.filmstrip.currentRow()
        if row < 0 or row >= len(self.gallery_data):
            return
        path = self.gallery_data[row]['raw_path']
        base_name = os.path.basename(path)
        suggested_filename = f"XMP_DUMP_{os.path.splitext(base_name)[0]}.txt"
        save_path, _ = QFileDialog.getSaveFileName(
            self, "Save XMP Dump File", suggested_filename, "Text Files (*.txt)"
        )
        if not save_path:
            return
        try:
            with open(path, 'rb') as f:
                img_data = f.read(524288)
            xmp_start = img_data.find(b'<x:xmpmeta')
            xmp_end = img_data.find(b'</x:xmpmeta>')
            raw_header_data = "No XMP tags found in file."
            if xmp_start != -1 and xmp_end != -1:
                raw_header_data = img_data[xmp_start:xmp_end + 12].decode('utf-8', errors='ignore')

            from ..core.metadata_parser import MetadataParser
            parsed_dict = MetadataParser.extract_xmp(path)
            report = [
                "=" * 60,
                "MAVIC PROJECTOR - DETAILED XMP & EXIF DUMP",
                f"Target File: {path}",
                f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "=" * 60,
                "\n💡 HOW THE PLUGIN INTERPRETS THIS PHOTO:",
            ]
            for k, v in parsed_dict.items():
                report.append(f"  -> {k}:\n{v}" if isinstance(v, np.ndarray) else f"  -> {k}: {v}")
            report.extend(["\n" + "=" * 60, "🔍 RAW UNPROCESSED XMP HEADER DATA:", "=" * 60, raw_header_data])
            with open(save_path, 'w', encoding='utf-8') as out_f:
                out_f.write("\n".join(report))
            self.hint.setText(f"📝 Saved XMP dump: {os.path.basename(save_path)}")
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to save XMP dump: {e}", "MavicProjector", Qgis.Warning)

    def toggle_cameras_on_map(self):
        existing_cam = QgsProject.instance().mapLayersByName("Drone Cameras")
        if existing_cam:
            QgsProject.instance().removeMapLayer(existing_cam[0].id())
            self.btn_show_cams.setText(tr("btn_show_cams"))
            if self.map_canvas:
                self.map_canvas.refresh()
            return

        if len(self.gallery_data) == 0:
            return

        vl = QgsVectorLayer("MultiPolygon?crs=EPSG:3301", "Drone Cameras", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("photo", QVariant.String)])
        vl.updateFields()

        sym = QgsFillSymbol.createSimple({
            'color': '160,32,240,60',
            'outline_color': '160,32,240,200',
            'outline_width': '0.4',
            'outline_style': 'dash',
        })
        vl.renderer().setSymbol(sym)

        settings = QgsPalLayerSettings()
        settings.fieldName = 'photo'
        settings.placement = LabelPlacementOverPoint
        text_format = QgsTextFormat()
        text_format.setSize(10)
        halo = QgsTextBufferSettings()
        halo.setEnabled(True)
        halo.setSize(1)
        halo.setColor(QColor("white"))
        text_format.setBuffer(halo)
        settings.setFormat(text_format)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        vl.setLabelsEnabled(True)

        for d in self.gallery_data:
            try:
                eng, _, _, _, _, _ = self._construct_engine_for_photo(
                    d['raw_path'], d.get('overrides', {}), build_dem_sampler=False
                )
                drone_poly, fov_poly = eng.get_simple_map_polygons()
                f = QgsFeature(vl.fields())
                f.setGeometry(QgsGeometry.fromMultiPolygonXY([[drone_poly], [fov_poly]]))
                f.setAttribute("photo", f"{os.path.basename(d['raw_path'])} (P:{eng.grid_pitch:.1f}°)")
                pr.addFeature(f)
            except Exception as e:
                QgsMessageLog.logMessage(f"Camera footprint error for {d['name']}: {e}", "MavicProjector", Qgis.Warning)

        vl.updateExtents()
        QgsProject.instance().addMapLayer(vl)
        self.btn_show_cams.setText(tr("btn_hide_cams"))
        if self.map_canvas:
            self.map_canvas.refresh()

    def _connect_layer_live_sync(self, layer):
        """Connects QgsMapLayer.styleChanged safely using functools.partial (PyQt6-safe)."""
        if layer is None or not self.is_layer_valid(layer):
            return
        lid = layer.id()
        if lid not in self.connected_layers:
            slot = partial(self.handle_live_style_sync, lid)
            layer.styleChanged.connect(slot)
            self.connected_layers[lid] = (layer, slot)

    def _sync_proj_layer_combo(self):
        prev_lid = self.combo_proj_layer.currentData()
        self.combo_proj_layer.blockSignals(True)
        self.combo_proj_layer.clear()
        for i in range(self.layer_list.count()):
            it = self.layer_list.item(i)
            lyr = it.data(UserRole)
            if self.is_layer_valid(lyr) and lyr.type() == 0:
                self.combo_proj_layer.addItem(lyr.name(), lyr.id())
        if prev_lid:
            idx = self.combo_proj_layer.findData(prev_lid)
            if idx >= 0:
                self.combo_proj_layer.setCurrentIndex(idx)
        self.combo_proj_layer.blockSignals(False)
        self._sync_ui_from_proj_style()

    def _add_layer_to_studio(self, layer, style=None, selected_only=False, trigger_refresh=True):
        if not self.is_layer_valid(layer):
            return False
        existing_ids = {
            self.layer_list.item(i).data(UserRole).id()
            for i in range(self.layer_list.count())
            if self.is_layer_valid(self.layer_list.item(i).data(UserRole))
        }
        if layer.id() in existing_ids:
            return False

        st = dict(style) if isinstance(style, dict) else make_default_layer_style(layer, live_sync_default=True)
        self.layer_list.blockSignals(True)
        try:
            item = QListWidgetItem(format_layer_item_label(layer, st))
            item.setData(UserRole, layer)
            item.setData(UserRole + 1, st)
            item.setFlags(item.flags() | ItemIsUserCheckable)
            item.setCheckState(Checked if selected_only else Unchecked)
            item.setIcon(make_layer_list_icon(layer, st))
            self.layer_list.addItem(item)
        finally:
            self.layer_list.blockSignals(False)

        self._connect_layer_live_sync(layer)
        self._sync_proj_layer_combo()
        self._wireframe_world_lines = []
        if self.current_tool == 'drag_align' and self.engine:
            self._build_wireframe_cache()
            self._update_wireframe_overlay()
        if trigger_refresh and len(self.gallery_data) > 0:
            self.refresh_live_sync()
        return True

    def add_combo_layer_to_list(self):
        layer = self.layer_combo.currentLayer()
        if layer:
            self._add_layer_to_studio(layer, trigger_refresh=True)

    def add_dropped_layers_to_list(self, layers):
        added = False
        for layer in layers:
            if self._add_layer_to_studio(layer, trigger_refresh=False):
                added = True
        if added and len(self.gallery_data) > 0:
            self.refresh_live_sync()

    def remove_selected_layers(self):
        sel_items = list(self.layer_list.selectedItems())
        if not sel_items and self.layer_list.currentItem() is not None:
            sel_items = [self.layer_list.currentItem()]
        if not sel_items:
            return
        self.layer_list.blockSignals(True)
        try:
            for it in sel_items:
                self.layer_list.takeItem(self.layer_list.row(it))
        finally:
            self.layer_list.blockSignals(False)
        self._sync_proj_layer_combo()
        self._wireframe_world_lines = []
        if self.current_tool == 'drag_align' and self.engine:
            self._build_wireframe_cache()
            self._update_wireframe_overlay()
        self.refresh_live_sync()

    def open_layer_properties(self, item):
        layer = item.data(UserRole)
        if not self.is_layer_valid(layer):
            return
        current_style = item.data(UserRole + 1) or {}
        dialog = LayerStyleDialog(layer, current_style, self)
        if exec_dialog(dialog):
            new_style = dialog.get_style()
            self.layer_list.blockSignals(True)
            try:
                item.setData(UserRole + 1, new_style)
                item.setIcon(make_layer_list_icon(layer, new_style))
                item.setText(format_layer_item_label(layer, new_style))
            finally:
                self.layer_list.blockSignals(False)
            self._sync_ui_from_proj_style()
            self._wireframe_world_lines = []
            if self.current_tool == 'drag_align' and self.engine:
                self._build_wireframe_cache()
                self._update_wireframe_overlay()
            self.refresh_live_sync()

    def _on_layer_item_checked_changed(self, _item):
        self._wireframe_world_lines = []
        if self.current_tool == 'drag_align' and self.engine:
            self._build_wireframe_cache()
            self._update_wireframe_overlay()
        self.refresh_live_sync()

    def handle_live_style_sync(self, layer_id, *_args):
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer = item.data(UserRole)
            if self.is_layer_valid(layer) and layer.id() == layer_id:
                current_style = item.data(UserRole + 1) or {}
                if current_style.get('live_sync', True):
                    updated_style = extract_qgis_layer_style(layer, current_style)
                    self.layer_list.blockSignals(True)
                    try:
                        item.setData(UserRole + 1, updated_style)
                        item.setIcon(make_layer_list_icon(layer, updated_style))
                    finally:
                        self.layer_list.blockSignals(False)
                    if self.combo_proj_layer.currentData() == layer_id:
                        self._sync_ui_from_proj_style()
                    self.refresh_live_sync()
                break

    def refresh_dem_sources(self, *_args):
        # Prune any removed layers from Studio's layer_list cleanly
        if hasattr(self, 'layer_list') and self.layer_list is not None:
            pruned = False
            self.layer_list.blockSignals(True)
            try:
                for idx in range(self.layer_list.count() - 1, -1, -1):
                    lyr_chk = self.layer_list.item(idx).data(UserRole)
                    if not self.is_layer_valid(lyr_chk):
                        self.layer_list.takeItem(idx)
                        pruned = True
            finally:
                self.layer_list.blockSignals(False)
            if pruned and hasattr(self, 'combo_proj_layer'):
                self._sync_proj_layer_combo()

        prev_data = self.dem_combo.currentData() if self.dem_combo.count() > 0 else ("wcs", "dtm-1")
        self.dem_combo.blockSignals(True)
        self.dem_combo.clear()
        self.dem_combo.addItem(tr("dem_dtm"), ("wcs", "dtm-1"))
        self.dem_combo.addItem(tr("dem_dsm"), ("wcs", "dsm-1"))
        self.dem_combo.addItem(tr("dem_none"), ("none", None))

        prefix = tr("dem_project_prefix")
        for lyr in QgsProject.instance().mapLayers().values():
            if self.is_layer_valid(lyr) and lyr.type() == 1:
                prov = lyr.providerType().lower()
                if prov in ('gdal', 'wcs'):
                    self.dem_combo.addItem(f"{prefix}: {lyr.name()}", ("layer", lyr.id()))

        for i in range(self.dem_combo.count()):
            if self.dem_combo.itemData(i) == prev_data:
                self.dem_combo.setCurrentIndex(i)
                break
        self.dem_combo.blockSignals(False)

    def get_or_create_dem_layer(self):
        if self._explicit_dem_layer is not None and self.is_layer_valid(self._explicit_dem_layer):
            return self._explicit_dem_layer
        sel = self.dem_combo.currentData()
        if not sel:
            sel = ("wcs", "dtm-1")
        kind, ident = sel
        if kind == "none":
            return None
        if kind == "layer":
            lyr = QgsProject.instance().mapLayer(ident)
            return lyr if self.is_layer_valid(lyr) else None

        uri = f"dpiMode=7&identifier={ident}&tilePixelRatio=0&url=https://teenus.maaamet.ee/ows/wcs-dtm"
        if "dsm" in str(ident):
            uri = uri.replace("wcs-dtm", "wcs-dsm")
        raster_layer = QgsRasterLayer(uri, f"Kogu Eesti {str(ident).upper()}", "wcs")
        return raster_layer if raster_layer.isValid() else None

    def save_studio_settings(self):
        self.settings.setValue("fallback_z", self.spin_fallback_z.value())
        self.settings.setValue("alt_mode", self.alt_mode_combo.currentData() or "auto")
        self.settings.setValue("max_dist_km", self.spin_max_dist.value())

    def _on_terrain_settings_changed(self, *_args):
        self.fallback_z = float(self.spin_fallback_z.value())
        self.global_settings['fallback_z'] = self.fallback_z
        self.global_settings['alt_mode'] = self.alt_mode_combo.currentData() or 'auto'
        self.global_settings['max_dist_km'] = float(self.spin_max_dist.value())
        self._explicit_dem_layer = None
        self.dem_layer = self.get_or_create_dem_layer()
        self.dem_sampler = None
        self._wireframe_world_lines = []
        self.save_studio_settings()

        row = self.filmstrip.currentRow()
        if 0 <= row < len(self.gallery_data):
            data = self.gallery_data[row]
            try:
                self.engine, _, self._auto_geoid_curr, use_auto_g, active_geoid, self.dem_sampler = self._construct_engine_for_photo(
                    data['raw_path'], data.get('overrides', {}), build_dem_sampler=True
                )
            except Exception:
                pass
            if self.current_tool == 'drag_align' and self.engine:
                self._build_wireframe_cache()
                self._update_wireframe_overlay()
            self.refresh_live_sync()

    def save_job_to_archive(self):
        try:
            job_data = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "global_settings": dict(self.global_settings),
                "layers": [],
                "photos": [],
            }
            for i in range(self.layer_list.count()):
                it = self.layer_list.item(i)
                lyr = it.data(UserRole)
                if self.is_layer_valid(lyr):
                    job_data["layers"].append({
                        "name": lyr.name(),
                        "id": lyr.id(),
                        "style": it.data(UserRole + 1) or {},
                        "selected_only": it.checkState() == Checked,
                    })
            for d in self.gallery_data:
                job_data["photos"].append({
                    "path": d['raw_path'],
                    "overrides": d.get('overrides', {}),
                })
            jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
            os.makedirs(jobs_dir, exist_ok=True)
            filename = f"Job_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(os.path.join(jobs_dir, filename), 'w', encoding='utf-8') as f:
                json.dump(job_data, f, indent=4)
            self.refresh_archive_list()
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to save job archive: {e}", "MavicProjector", Qgis.Warning)

    def refresh_archive_list(self):
        self.archive_list.clear()
        jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
        if not os.path.exists(jobs_dir):
            return
        for job_file in sorted(glob.glob(os.path.join(jobs_dir, "*.json")), reverse=True):
            try:
                with open(job_file, 'r', encoding='utf-8') as f:
                    job_data = json.load(f)
                ts = job_data.get("timestamp", "Unknown Date")
                photo_count = len(job_data.get("photos", []))
                layer_count = len(job_data.get("layers", []))
                item = QListWidgetItem(f"Job: {ts}\n{photo_count} Photos, {layer_count} Layers")
                item.setData(UserRole, job_file)
                if photo_count > 0:
                    first_photo = job_data["photos"][0].get("path", "")
                    out_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
                    stem, _ = os.path.splitext(os.path.basename(first_photo))
                    proj_path = os.path.join(out_dir, f"{stem}_PROJECTED.jpg")
                    cand = proj_path if os.path.exists(proj_path) else first_photo
                    if cand and os.path.exists(cand):
                        pix = QPixmap(cand)
                        if not pix.isNull():
                            item.setIcon(QIcon(pix.scaled(72, 50, KeepAspectRatio)))
                self.archive_list.addItem(item)
            except Exception:
                pass

    def restore_job(self, *_args):
        item = self.archive_list.currentItem()
        if not item:
            return
        job_path = item.data(UserRole)
        try:
            with open(job_path, 'r', encoding='utf-8') as f:
                job_data = json.load(f)

            gs = job_data.get("global_settings", {})
            for ctrl in (self.spin_fallback_z, self.alt_mode_combo, self.spin_max_dist):
                ctrl.blockSignals(True)
            try:
                self.spin_fallback_z.setValue(float(gs.get("fallback_z", 0.0)))
                idx_am = self.alt_mode_combo.findData(gs.get("alt_mode", "auto"))
                if idx_am >= 0:
                    self.alt_mode_combo.setCurrentIndex(idx_am)
                self.spin_max_dist.setValue(float(gs.get("max_dist_km", 4.0)))
            finally:
                for ctrl in (self.spin_fallback_z, self.alt_mode_combo, self.spin_max_dist):
                    ctrl.blockSignals(False)

            self.fallback_z = float(self.spin_fallback_z.value())
            self.global_settings.update(gs)
            self.global_settings['fallback_z'] = self.fallback_z
            self.global_settings['alt_mode'] = self.alt_mode_combo.currentData() or 'auto'
            self.global_settings['max_dist_km'] = float(self.spin_max_dist.value())

            self.layer_list.blockSignals(True)
            self.layer_list.clear()
            self.layer_list.blockSignals(False)
            proj = QgsProject.instance()
            for l_entry in job_data.get("layers", []):
                lyr = proj.mapLayer(l_entry.get("id"))
                if not lyr:
                    cands = proj.mapLayersByName(l_entry.get("name", ""))
                    if cands:
                        lyr = cands[0]
                if self.is_layer_valid(lyr):
                    self._add_layer_to_studio(
                        lyr,
                        style=l_entry.get("style"),
                        selected_only=bool(l_entry.get("selected_only", False)),
                        trigger_refresh=False,
                    )

            temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
            os.makedirs(temp_dir, exist_ok=True)
            new_gallery = []
            for p_entry in job_data.get("photos", []):
                p_path = p_entry.get("path", "")
                if p_path and os.path.exists(p_path):
                    stem, _ = os.path.splitext(os.path.basename(p_path))
                    new_gallery.append({
                        'name': os.path.basename(p_path),
                        'raw_path': p_path,
                        'proj_path': os.path.join(temp_dir, f"{stem}_PROJECTED.jpg"),
                        'overrides': p_entry.get("overrides", {}) or {},
                    })
            self.update_gallery(new_gallery, 0)
            self.left_tabs.setCurrentIndex(0)
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to restore archived job: {e}", "MavicProjector", Qgis.Warning)

    def delete_selected_job(self):
        item = self.archive_list.currentItem()
        if not item:
            return
        job_path = item.data(UserRole)
        reply = QMessageBox.question(
            self, "Delete Job", "Are you sure you want to delete this saved setup?", MsgYes | MsgNo, MsgNo
        )
        if reply == MsgYes:
            try:
                os.remove(job_path)
                self.refresh_archive_list()
            except Exception:
                pass

    def delete_all_jobs(self):
        reply = QMessageBox.question(
            self, "Delete All Jobs", "Are you sure you want to delete ALL saved setups?", MsgYes | MsgNo, MsgNo
        )
        if reply == MsgYes:
            jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
            if os.path.exists(jobs_dir):
                for jf in glob.glob(os.path.join(jobs_dir, "*.json")):
                    try:
                        os.remove(jf)
                    except Exception:
                        pass
                self.refresh_archive_list()

    def _on_scene_selection_changed(self):
        is_edit = (self.current_tool == 'edit')
        labels_on = self.btn_toggle_labels.isChecked()
        callouts_on = self.btn_toggle_callouts.isChecked()
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveAnchorItem):
                # Keep anchor active if either the label OR the anchor itself is selected
                is_active = False
                if item.label_item and item.label_item.isSelected():
                    is_active = True
                if item.isSelected():
                    is_active = True
                
                # Billboards always need their anchor because of the physical pole
                is_bb = False
                if item.label_item and isinstance(item.label_item.style_dict, dict):
                    is_bb = item.label_item.style_dict.get('preset') == "Billboard (Stand-up)"
                    
                if is_edit and labels_on and is_active and (callouts_on or is_bb):
                    item.setVisible(True)
                else:
                    item.setVisible(False)

    def toggle_all_labels(self):
        visible = self.btn_toggle_labels.isChecked()
        shadows_on = self.btn_toggle_shadows.isChecked()
        callouts_on = self.btn_toggle_callouts.isChecked()

        # Persist toggle state on layer styles so Batch Processing / Batch Save All obey it too
        for i in range(self.layer_list.count()):
            l_item = self.layer_list.item(i)
            st = l_item.data(UserRole + 1)
            if isinstance(st, dict):
                st['labels_enabled'] = bool(visible)
                l_item.setData(UserRole + 1, st)
        parent_ll = getattr(self.parent(), 'layer_list', None)
        if parent_ll is not None:
            for i in range(parent_ll.count()):
                p_item = parent_ll.item(i)
                pst = p_item.data(UserRole + 1)
                if isinstance(pst, dict):
                    pst['labels_enabled'] = bool(visible)
                    p_item.setData(UserRole + 1, pst)
        
        show_ov = self.btn_toggle_overlay.isChecked() and not self._space_peeking
        effective_vis = visible and show_ov
        row = self.filmstrip.currentRow()
        overrides = self.gallery_data[row].get('overrides', {}).get('label_offsets', {}) if row >= 0 else {}
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveLabelItem):
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                actual_vis = effective_vis and not is_hidden
                
                item.setVisible(actual_vis)
                if item.shadow_item: 
                    item.shadow_item.setVisible(actual_vis and shadows_on)
                
                is_bb = item.style_dict.get('preset') == "Billboard (Stand-up)"
                if item.bg_item:
                    item.bg_item.setVisible(actual_vis if is_bb else (actual_vis and callouts_on))
                if getattr(item, 'bg_item_pole', None):
                    item.bg_item_pole.setVisible(actual_vis)
                    
            elif isinstance(item, InteractiveAnchorItem):
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                is_edit = (self.current_tool == 'edit')
                is_active = item.label_item and item.label_item.isSelected()
                item.setVisible(effective_vis and is_edit and is_active and not is_hidden)

    def toggle_all_shadows(self):
        visible = self.btn_toggle_shadows.isChecked()
        labels_on = self.btn_toggle_labels.isChecked()
        
        row = self.filmstrip.currentRow()
        overrides = self.gallery_data[row].get('overrides', {}).get('label_offsets', {}) if row >= 0 else {}
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveLabelItem) and item.shadow_item:
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                item.shadow_item.setVisible(visible and labels_on and not is_hidden)

    def toggle_all_callouts(self):
        visible = self.btn_toggle_callouts.isChecked()
        labels_on = self.btn_toggle_labels.isChecked()
        
        row = self.filmstrip.currentRow()
        overrides = self.gallery_data[row].get('overrides', {}).get('label_offsets', {}) if row >= 0 else {}
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveLabelItem):
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                is_bb = item.style_dict.get('preset') == "Billboard (Stand-up)"
                if not is_bb and item.bg_item:
                    item.bg_item.setVisible(visible and labels_on and not is_hidden)

    def _sync_ui_from_proj_style(self):
        layer_id = self.combo_proj_layer.currentData()
        if not layer_id:
            return
        
        self.proj_lbl_canvas.blockSignals(True)
        self.spin_proj_font.blockSignals(True)
        self.combo_proj_preset.blockSignals(True)
        self.combo_proj_bb_shape.blockSignals(True)
        self.dial_proj_angle.blockSignals(True)
        self.spin_callout_w.blockSignals(True)
        
        # Block signals for the new slider + spinbox combos
        self.slider_shadow_dist.blockSignals(True)
        self.spin_shadow_dist.blockSignals(True)
        self.slider_shadow_blur.blockSignals(True)
        self.spin_shadow_blur.blockSignals(True)
        
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer:
            self.proj_list_fields.clear()
            for f in layer.fields():
                self.proj_list_fields.addItem(f.name())
        
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            lyr_it = item.data(UserRole)
            if self.is_layer_valid(lyr_it) and lyr_it.id() == layer_id:
                style = item.data(UserRole + 1) or {}
                
                expr = style.get('label_expr', '')
                self.proj_lbl_canvas.setText(expr)
                if not expr.strip():
                    self.btn_toggle_labels.setChecked(False)
                else:
                    self.btn_toggle_labels.setChecked(bool(style.get('labels_enabled', True)))
                    
                self.spin_proj_font.setValue(style.get('font_size', 48))
                
                c = style.get('label_color', (255, 255, 0, 255))
                self.btn_proj_color.setStyleSheet(f"background-color: rgba({c[0]},{c[1]},{c[2]},{c[3]}); border: 1px solid white;")
                
                hc = style.get('halo_color', (0, 0, 0, 255))
                self.btn_proj_halo.setStyleSheet(f"background-color: rgba({hc[0]},{hc[1]},{hc[2]},{hc[3]}); border: 1px solid white;")
                
                co = style.get('callout_color', (255, 255, 255, 255))
                self.btn_callout_color.setStyleSheet(f"background-color: rgba({co[0]},{co[1]},{co[2]},{co[3]}); border: 1px solid white;")
                self.spin_callout_w.setValue(style.get('callout_width', 5))
                
                idx = self.combo_proj_preset.findText(style.get('preset', 'Standard (Flat)'))
                if idx >= 0: self.combo_proj_preset.setCurrentIndex(idx)
                
                idx_shp = self.combo_proj_bb_shape.findText(style.get('billboard_shape', 'Rounded'))
                if idx_shp >= 0: self.combo_proj_bb_shape.setCurrentIndex(idx_shp)
                
                self.dial_proj_angle.setValue(style.get('light_angle', 45))
                
                # Update both the slider AND the spinbox together
                dist_val = style.get('shadow_dist', 15)
                self.slider_shadow_dist.setValue(dist_val)
                self.spin_shadow_dist.setValue(dist_val)
                
                blur_val = style.get('shadow_blur', 0)
                self.slider_shadow_blur.setValue(blur_val)
                self.spin_shadow_blur.setValue(blur_val)
                break
                
        self.proj_lbl_canvas.blockSignals(False)
        self.spin_proj_font.blockSignals(False)
        self.combo_proj_preset.blockSignals(False)
        self.combo_proj_bb_shape.blockSignals(False)
        self.dial_proj_angle.blockSignals(False)
        self.spin_callout_w.blockSignals(False)
        
        # Unblock signals for the new slider + spinbox combos
        self.slider_shadow_dist.blockSignals(False)
        self.spin_shadow_dist.blockSignals(False)
        self.slider_shadow_blur.blockSignals(False)
        self.spin_shadow_blur.blockSignals(False)

    def _pick_proj_color(self, target, *_args):
        layer_id = self.combo_proj_layer.currentData()
        if not layer_id:
            return
        
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            lyr_it = item.data(UserRole)
            if self.is_layer_valid(lyr_it) and lyr_it.id() == layer_id:
                style = item.data(UserRole + 1) or {}
                
                if target == 'text': c_tup = style.get('label_color', (255,255,0,255))
                elif target == 'callout': c_tup = style.get('callout_color', (255, 255, 255, 255))
                else: c_tup = style.get('halo_color', (0,0,0,255))
                
                init_c = QColor(*c_tup)
                color = QColorDialog.getColor(init_c, self, "Pick Color", ShowAlphaChannel)
                if color.isValid():
                    c_rgba = color.getRgb()
                    if target == 'text':
                        style['label_color'] = c_rgba
                        self.btn_proj_color.setStyleSheet(f"background-color: rgba({c_rgba[0]},{c_rgba[1]},{c_rgba[2]},{c_rgba[3]}); border: 1px solid white;")
                    elif target == 'callout':
                        style['callout_color'] = c_rgba
                        self.btn_callout_color.setStyleSheet(f"background-color: rgba({c_rgba[0]},{c_rgba[1]},{c_rgba[2]},{c_rgba[3]}); border: 1px solid white;")
                    else:
                        style['halo_color'] = c_rgba
                        self.btn_proj_halo.setStyleSheet(f"background-color: rgba({c_rgba[0]},{c_rgba[1]},{c_rgba[2]},{c_rgba[3]}); border: 1px solid white;")
                    self.layer_list.blockSignals(True)
                    item.setData(UserRole + 1, style)
                    self.layer_list.blockSignals(False)
                    self.render_projected_labels() 
                break

    def _on_proj_style_changed(self):
        layer_id = self.combo_proj_layer.currentData()
        if not layer_id:
            return
        
        style = {}
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            lyr_it = item.data(UserRole)
            if self.is_layer_valid(lyr_it) and lyr_it.id() == layer_id:
                style = item.data(UserRole + 1) or {}
                style['label_expr'] = self.proj_lbl_canvas.toPlainText()
                if style['label_expr'].strip():
                    style['labels_enabled'] = self.btn_toggle_labels.isChecked()
                style['font_size'] = self.spin_proj_font.value()
                style['preset'] = self.combo_proj_preset.currentText()
                style['billboard_shape'] = self.combo_proj_bb_shape.currentText()
                style['light_angle'] = self.dial_proj_angle.value()
                style['shadow_dist'] = self.slider_shadow_dist.value()
                style['shadow_blur'] = self.slider_shadow_blur.value()
                style['callout_width'] = self.spin_callout_w.value()
                self.layer_list.blockSignals(True)
                item.setData(UserRole + 1, style)
                item.setText(format_layer_item_label(lyr_it, style))
                self.layer_list.blockSignals(False)
                break
                
        # Check if the change came from a rapid-fire slider/dial
        sender = self.sender()
        is_slider = sender and sender in [self.slider_shadow_dist, self.spin_shadow_dist, 
                                          self.slider_shadow_blur, self.spin_shadow_blur, 
                                          self.dial_proj_angle]
        
        if is_slider:
            # Update live items smoothly without recreating them
            for item in self._projected_graphics:
                if isinstance(item, InteractiveLabelItem):
                    item.style_dict = style
                    blur_val = style.get('shadow_blur', 0)
                    
                    if getattr(item, 'shadow_item', None):
                        effect = item.shadow_item.graphicsEffect()
                        if blur_val > 0:
                            if effect:
                                effect.setBlurRadius(blur_val)
                                effect.setEnabled(True)
                            else:
                                new_effect = QGraphicsBlurEffect()
                                new_effect.setBlurRadius(blur_val)
                                item.shadow_item.setGraphicsEffect(new_effect)
                        elif effect:
                            effect.setEnabled(False)
                            
                    item.update_visuals()
            self.proj_scene.update()
        else:
            # Only do a heavy structural rebuild if text, preset, or font size changed
            self.render_projected_labels()

    def save_anchor_override(self, feature_key, adx=0.0, ady=0.0):
        row = self.filmstrip.currentRow()
        if row < 0: return
        data = self.gallery_data[row]
        overrides = data.get('overrides', {})
        if 'label_offsets' not in overrides: overrides['label_offsets'] = {}
        
        current = overrides['label_offsets'].get(feature_key, {"cx_off": 0.0, "cy_off": 0.0, "hidden": False})
        current['adx'] = adx
        current['ady'] = ady
        overrides['label_offsets'][feature_key] = current
        data['overrides'] = overrides
        self._sync_filmstrip_item_label(row)

    def save_label_override(self, feature_key, cx_off=None, cy_off=None, hidden=None, color=None, size=None, reset=False):
        row = self.filmstrip.currentRow()
        if row < 0: return
        
        data = self.gallery_data[row]
        overrides = data.get('overrides', {})
        
        if 'label_offsets' not in overrides:
            overrides['label_offsets'] = {}
            
        if reset:
            if feature_key in overrides['label_offsets']:
                del overrides['label_offsets'][feature_key]
        else:
            current = overrides['label_offsets'].get(feature_key, {"cx_off": 0.0, "cy_off": 0.0, "hidden": False})
            if cx_off is not None: current['cx_off'] = cx_off
            if cy_off is not None: current['cy_off'] = cy_off
            if hidden is not None: current['hidden'] = hidden
            if color is not None: current['color'] = color
            if size is not None: current['size'] = size
            overrides['label_offsets'][feature_key] = current
            
        data['overrides'] = overrides
        self._sync_filmstrip_item_label(row)

    def tbl_ties_keyPressEvent(self, event):
        try:
            key_del = Qt.Key.Key_Delete
        except AttributeError:
            key_del = Qt.Key_Delete
            
        if event.key() == key_del:
            self.delete_selected_tie_point()
        else:
            QTableWidget.keyPressEvent(self.tbl_ties, event)

    def delete_selected_tie_point(self):
        selected_rows = [item.row() for item in self.tbl_ties.selectedItems()]
        if not selected_rows: return
        row = list(set(selected_rows))[0]
        reply = QMessageBox.question(self, "Delete Tie Point", f"Are you sure you want to delete Tie Point {row + 1}?", MsgYes | MsgNo, MsgNo)
        
        if reply == MsgYes:
            self.tie_points.pop(row)
            self.update_tie_point_table()
            self.draw_tie_points()

    def closeEvent(self, event):
        try:
            ui_prefs.languageChanged.disconnect(self.retranslate_ui)
            ui_prefs.themeChanged.disconnect(self.apply_current_theme)
        except Exception:
            pass
        try:
            QgsProject.instance().layersAdded.disconnect(self.refresh_dem_sources)
            QgsProject.instance().layersRemoved.disconnect(self.refresh_dem_sources)
        except Exception:
            pass
        for lid, (lyr, slot) in list(self.connected_layers.items()):
            try:
                if self.is_layer_valid(lyr):
                    lyr.styleChanged.disconnect(slot)
            except Exception:
                pass
        self.connected_layers.clear()
        if self.temp_task:
            try:
                self.temp_task.cancel()
            except Exception:
                pass
            self.temp_task = None
        if getattr(self, 'drag_align_dialog', None) is not None:
            try:
                self.drag_align_dialog.blockSignals(True)
                self.drag_align_dialog.close()
            except Exception:
                pass
            self.drag_align_dialog = None
        if hasattr(self, 'map_tie_markers') and self.map_canvas:
            for marker in self.map_tie_markers:
                self.map_canvas.scene().removeItem(marker)
        self.map_tie_markers = []
        if getattr(self, 'map_rubberband', None):
            try:
                self.map_rubberband.reset()
            except Exception:
                pass
        super().closeEvent(event)

    def update_gallery(self, new_gallery_data, start_index):
        self.gallery_data = list(new_gallery_data) if new_gallery_data else []
        self._projected_label_cache.clear()
        self._projected_label_data = {}
        self.filmstrip.blockSignals(True)
        self.filmstrip.clear()
        
        for item_data in self.gallery_data:
            base_n = os.path.basename(item_data['raw_path'])
            lbl = f"{base_n} [Custom Offsets]" if _has_meaningful_overrides(item_data.get('overrides')) else base_n
            list_item = QListWidgetItem(lbl)
            list_item.setToolTip(item_data['raw_path'])
            list_item.setData(UserRole, item_data['raw_path'])
            list_item.setData(UserRole + 1, item_data.get('overrides', {}))
            icon_path = item_data['proj_path'] if os.path.exists(item_data.get('proj_path', '')) else item_data['raw_path']
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                list_item.setIcon(QIcon(pixmap.scaled(68, 46, KeepAspectRatio)))
            self.filmstrip.addItem(list_item)
            
        self.filmstrip.blockSignals(False)
        
        if 0 <= start_index < len(self.gallery_data):
            self.filmstrip.setCurrentRow(start_index)
        elif len(self.gallery_data) > 0:
            self.filmstrip.setCurrentRow(0)
        else:
            self.photo_name = ""
            self.engine = None
            self.setWindowTitle(tr("studio_title"))
            self._show_empty_canvas_message()

    def refresh_live_sync(self):
        self._projected_label_cache.clear()
        self._projected_label_data = {}
        self.live_sync_timer.start()

    def _execute_live_sync(self):
        row = self.filmstrip.currentRow()
        if 0 <= row < len(self.gallery_data):
            self._run_single_projection(self.gallery_data[row], silent=True)

    def is_layer_valid(self, layer):
        try:
            return layer is not None and layer.isValid()
        except RuntimeError:
            return False

    def ensure_layers_valid(self):
        if not (self.is_layer_valid(getattr(self, 'pin_layer', None)) and 
                self.is_layer_valid(getattr(self, 'line_layer', None)) and 
                self.is_layer_valid(getattr(self, 'poly_layer', None))):
            self.setup_drawing_layers()

    def _on_man_auto_geoid_toggled(self, checked):
        self.spin_man_geoid.setEnabled(not checked)
        if checked:
            self.spin_man_geoid.setValue(self._auto_geoid_curr)

    def _construct_engine_for_photo(self, raw_path, overrides, build_dem_sampler=False):
        from ..core.metadata_parser import MetadataParser
        from ..core.math_engine import MathEngine

        active_pitch = overrides.get('pitch_offset', self.global_settings.get('pitch_offset', 0.0))
        active_yaw = overrides.get('yaw_offset', self.global_settings.get('yaw_offset', 0.0))
        active_roll = overrides.get('roll_offset', self.global_settings.get('roll_offset', 0.0))
        active_fscale = overrides.get('focal_scale', self.global_settings.get('focal_scale', 1.0))
        active_x = overrides.get('x_offset', self.global_settings.get('x_offset', 0.0))
        active_y = overrides.get('y_offset', self.global_settings.get('y_offset', 0.0))
        alt_mode = overrides.get('alt_mode', self.global_settings.get('alt_mode', 'auto'))

        active_dists = dict(self.global_settings.get('dist_offsets', {}))
        if isinstance(overrides.get('dist_offsets'), dict):
            active_dists.update(overrides['dist_offsets'])
        elif 'dist_offset' in overrides:
            active_dists['k1'] = float(overrides['dist_offset'])

        lens_override = overrides.get('lens_override', 'Auto (From File)')
        tel = MetadataParser.extract_xmp(raw_path, active_dists, lens_override)

        is_rtk = tel.get('is_rtk', True)
        use_eh2000 = (alt_mode == 'rtk') or (alt_mode == 'auto' and is_rtk)
        auto_g = tel.get('auto_geoid', -19.0) if use_eh2000 else 0.0

        if 'use_auto_geoid' in overrides:
            use_auto_g = bool(overrides['use_auto_geoid'])
        elif 'geoid_offset' in overrides:
            use_auto_g = False
        else:
            use_auto_g = bool(self.global_settings.get('use_auto_geoid', True))

        active_geoid = auto_g if use_auto_g else float(overrides.get('geoid_offset', self.global_settings.get('geoid_offset', 0.0)))
        safe_context = QgsProject.instance().transformContext()

        prelim = MathEngine(
            tel, active_geoid, active_yaw, active_pitch,
            transform_context=safe_context, roll_offset=active_roll,
            focal_scale=active_fscale, alt_mode=alt_mode
        )
        prelim.drone_pos[0] -= active_x
        prelim.drone_pos[1] -= active_y

        dem_sampler = self.dem_sampler
        if build_dem_sampler:
            if self.dem_layer and self.dem_layer.isValid():
                max_dist_m = max(500.0, float(self.global_settings.get('max_dist_km', 4.0)) * 1000.0)
                az_rad = math.radians(90.0 - prelim.grid_yaw)
                fx_pt = prelim.drone_pos[0] + 250.0 * math.cos(az_rad)
                fy_pt = prelim.drone_pos[1] + 250.0 * math.sin(az_rad)
                far_rect = QgsRectangle(
                    prelim.drone_pos[0] - max_dist_m, prelim.drone_pos[1] - max_dist_m,
                    prelim.drone_pos[0] + max_dist_m, prelim.drone_pos[1] + max_dist_m
                )
                dem_sampler = DEMSampler(
                    self.dem_layer, fx_pt, fy_pt, far_bbox_3301=far_rect,
                    fallback_z=self.fallback_z, fine_half_m=min(800.0, max_dist_m), fine_res_m=1.5,
                    coarse_max_half_m=max(1200.0, max_dist_m + 500.0), coarse_res_m=8.0, transform_context=safe_context
                )
            else:
                dem_sampler = None

        dem_under_drone = None
        if dem_sampler is not None:
            rz = dem_sampler.sample_raw(prelim.drone_pos[0], prelim.drone_pos[1])
            if not math.isnan(rz):
                dem_under_drone = rz

        engine = MathEngine(
            tel, active_geoid, active_yaw, active_pitch,
            transform_context=safe_context, roll_offset=active_roll,
            focal_scale=active_fscale, alt_mode=alt_mode, dem_under_drone=dem_under_drone
        )
        self._base_drone_pos = np.array([
            float(engine.drone_pos[0]),
            float(engine.drone_pos[1]),
            float(engine.drone_pos[2]) - float(active_geoid),
        ], dtype=np.float64)
        engine.drone_pos[0] -= active_x
        engine.drone_pos[1] -= active_y
        return engine, tel, auto_g, use_auto_g, active_geoid, dem_sampler

    def _collect_studio_layer_items(self, respect_label_toggle=True):
        labels_on = self.btn_toggle_labels.isChecked()
        layer_items = []
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            lyr = item.data(UserRole)
            if not self.is_layer_valid(lyr):
                continue
            st = dict(item.data(UserRole + 1) or {})
            if respect_label_toggle:
                st['labels_enabled'] = bool(labels_on and st.get('labels_enabled', True))
            layer_items.append({
                'layer': lyr,
                'style': st,
                'selected_only': item.checkState() == Checked,
            })
        return layer_items

    def _render_photo_to_disk(self, data, dest_path):
        raw_path = data['raw_path']
        curr_row = self.filmstrip.currentRow()
        is_current = (0 <= curr_row < len(self.gallery_data)) and (
            self.gallery_data[curr_row]['raw_path'] == raw_path
        )

        # Fast-path for active photo when background projection is already ready in proj_scene
        if (
            is_current
            and self.temp_task is None
            and self.proj_bg_item is not None
            and self.proj_bg_item.scene() == self.proj_scene
            and (self.layer_list.count() == 0 or not self._proj_pixmap.isNull())
        ):
            was_peeking = self._space_peeking
            was_ov_checked = self.btn_toggle_overlay.isChecked()
            if was_peeking or not was_ov_checked:
                self._space_peeking = False
                self.btn_toggle_overlay.blockSignals(True)
                self.btn_toggle_overlay.setChecked(True)
                self.btn_toggle_overlay.blockSignals(False)
                self._apply_overlay_visibility()

            pix = self.proj_bg_item.pixmap()
            if not pix.isNull():
                w_img, h_img = pix.width(), pix.height()
                hidden_helpers = []
                for hl in (self.tie_point_graphics, self.horizon_graphics):
                    for it in hl:
                        if it and it.isVisible():
                            it.setVisible(False)
                            hidden_helpers.append(it)
                if self._wireframe_item_proj and self._wireframe_item_proj.isVisible():
                    self._wireframe_item_proj.setVisible(False)
                    hidden_helpers.append(self._wireframe_item_proj)
                for it in self._projected_graphics:
                    if isinstance(it, InteractiveAnchorItem) and it.isVisible():
                        it.setVisible(False)
                        hidden_helpers.append(it)

                try:
                    rect = QRectF(0, 0, w_img, h_img)
                    export_image = QImage(w_img, h_img, Format_ARGB32_Premultiplied)
                    export_image.fill(Transparent)
                    painter = QPainter(export_image)
                    painter.setRenderHint(RenderHintAntialiasing)
                    painter.setRenderHint(SmoothPixmapTransform)
                    self.proj_scene.render(painter, target=rect, source=rect)
                    painter.end()
                finally:
                    for it in hidden_helpers:
                        try:
                            it.setVisible(True)
                        except RuntimeError:
                            pass
                    if was_peeking or not was_ov_checked:
                        self._space_peeking = was_peeking
                        self.btn_toggle_overlay.blockSignals(True)
                        self.btn_toggle_overlay.setChecked(was_ov_checked)
                        self.btn_toggle_overlay.blockSignals(False)
                        self._apply_overlay_visibility()

                ok = export_image.save(dest_path, "JPG", 95)
                if ok:
                    copy_jpeg_metadata(raw_path, dest_path, mark_projected=True)
                return ok

        # Fresh projection path for non-active batch photos (always reflects latest layers, styles & offsets)
        layer_items = self._collect_studio_layer_items(respect_label_toggle=True)
        bg_source = raw_path
        batch_tmp_dir = None
        if layer_items:
            from ..core.task_worker import ProjectionTask
            batch_tmp_dir = os.path.join(os.path.dirname(raw_path), ".mavic_cache")
            os.makedirs(batch_tmp_dir, exist_ok=True)
            gs_batch = dict(self.global_settings)
            gs_batch['out_folder'] = batch_tmp_dir
            sync_task = ProjectionTask(
                [{'path': raw_path, 'overrides': data.get('overrides', {})}],
                layer_items,
                self.dem_layer,
                gs_batch,
                transform_context=QgsProject.instance().transformContext(),
                interactive_mode=False,
            )
            if sync_task.run():
                stem, _ = os.path.splitext(os.path.basename(raw_path))
                cand_proj = os.path.join(batch_tmp_dir, f"{stem}_PROJECTED.jpg")
                if os.path.exists(cand_proj):
                    bg_source = cand_proj

        base_img = QImage(bg_source)
        if batch_tmp_dir and bg_source != raw_path and os.path.exists(bg_source):
            try:
                os.remove(bg_source)
            except Exception:
                pass
        if base_img.isNull():
            return False

        scene = QGraphicsScene()
        scene.addPixmap(QPixmap.fromImage(base_img))
        overrides = data.get('overrides', {})

        try:
            engine, _, _, _, _, _ = self._construct_engine_for_photo(raw_path, overrides, build_dem_sampler=False)
            self._populate_scene_with_features(scene, engine, data['name'], tracking_list=None)

            rect = QRectF(0, 0, base_img.width(), base_img.height())
            export_image = QImage(base_img.width(), base_img.height(), Format_ARGB32_Premultiplied)
            export_image.fill(Transparent)

            painter = QPainter(export_image)
            painter.setRenderHint(RenderHintAntialiasing)
            painter.setRenderHint(SmoothPixmapTransform)
            scene.render(painter, target=rect, source=rect)
            painter.end()

            ok = export_image.save(dest_path, "JPG", 95)
            if ok:
                copy_jpeg_metadata(raw_path, dest_path, mark_projected=True)
            return ok
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to render export for {data['name']}: {e}", "MavicProjector", Qgis.Warning)
            return False

    def cancel_active_tasks(self):
        self._cancel_export_requested = True
        if self.temp_task:
            try:
                self.temp_task.cancel()
            except Exception:
                pass

    def export_current(self, target_dir=None):
        row = self.filmstrip.currentRow()
        if row < 0 or row >= len(self.gallery_data):
            return False
        data = self.gallery_data[row]
        if isinstance(target_dir, str) and target_dir:
            dir_path = target_dir
        else:
            start_dir = os.path.dirname(data['raw_path'])
            dir_path = QFileDialog.getExistingDirectory(self, "Select Folder to Save Photo", start_dir)
        if not dir_path:
            return False

        stem, _ = os.path.splitext(os.path.basename(data['raw_path']))
        dest_path = os.path.join(dir_path, f"{stem}_PROJECTED.jpg")

        self.btn_exp_curr.setText("⏳ Saving...")
        self.btn_exp_curr.setEnabled(False)
        QgsApplication.processEvents()

        success = self._render_photo_to_disk(data, dest_path)

        self.btn_exp_curr.setText(tr("btn_export_curr"))
        self.btn_exp_curr.setEnabled(True)

        if not isinstance(target_dir, str):
            if success:
                QMessageBox.information(self, "Export", f"Exported to:\n{dest_path}")
            else:
                QMessageBox.warning(self, "Export Error", "Failed to render and save image.")
        return success

    def export_all(self, target_dir=None):
        if len(self.gallery_data) == 0:
            return 0
        if isinstance(target_dir, str) and target_dir:
            dir_path = target_dir
        else:
            start_dir = os.path.dirname(self.gallery_data[0]['raw_path'])
            dir_path = QFileDialog.getExistingDirectory(self, "Select Folder for Batch Export", start_dir)
        if not dir_path:
            return 0

        self._cancel_export_requested = False
        self.save_studio_settings()
        total = len(self.gallery_data)
        self.export_progress.setMaximum(total)
        self.export_progress.setValue(0)
        self.export_progress.setFormat(tr("progress_init"))
        self.export_progress.setVisible(True)
        self.btn_cancel_task.setVisible(True)
        self.btn_exp_all.setEnabled(False)
        self.btn_exp_curr.setEnabled(False)

        success_count = 0
        for idx, data in enumerate(self.gallery_data):
            if getattr(self, '_cancel_export_requested', False):
                break
            self.export_progress.setFormat(f"{idx + 1}/{total} — {data['name']}")
            QgsApplication.processEvents()

            stem, _ = os.path.splitext(os.path.basename(data['raw_path']))
            dest_path = os.path.join(dir_path, f"{stem}_PROJECTED.jpg")
            if self._render_photo_to_disk(data, dest_path):
                success_count += 1
            self.export_progress.setValue(idx + 1)
            QgsApplication.processEvents()

        self.btn_exp_all.setText(tr("btn_batch_export_all"))
        self.btn_exp_all.setEnabled(True)
        self.btn_exp_curr.setEnabled(True)
        self.btn_cancel_task.setVisible(False)
        self.export_progress.setFormat(tr("progress_done") if success_count > 0 else tr("progress_ready"))

        if success_count > 0:
            self.save_job_to_archive()

        if not isinstance(target_dir, str):
            if success_count > 0:
                QMessageBox.information(
                    self, "Batch Export", f"Successfully exported {success_count}/{total} photos to:\n{dir_path}"
                )
            elif not getattr(self, '_cancel_export_requested', False):
                QMessageBox.warning(self, "Batch Export", "Failed to render and save images.")
        return success_count

    def show_parameter_help(self):
        msg = (
            "<b>Manual Offset Parameters Guide</b><br><br>"
            "<b>Pitch:</b> Adjusts the camera's up/down tilt. Example: If the horizon is too high/low.<br>"
            "<b>Yaw (Crab Angle):</b> Adjusts the camera's left/right heading to counteract wind crabbing. Example: If features are systematically rotated left/right.<br>"
            "<b>X (E) / Y (N):</b> Nudges the camera's GPS position in meters (East/West or North/South). Example: If RTK drifted.<br>"
            "<b>Geoid Z:</b> Offsets the drone's altitude. Example: Adjusting RTK height to local ground level.<br>"
            "<b>k1, k2, k3:</b> Radial distortion coefficients. Example: Fixes 'fisheye' bulging or shrinking at the edges.<br>"
            "<b>p1, p2:</b> Tangential distortion coefficients. Example: Fixes lens misalignment causing slanted distortion."
        )
        QMessageBox.information(self, "Parameter Help", msg)

    def on_qgis_layer_changed(self, *args, **kwargs):
        if not self._is_plugin_editing:
            QTimer.singleShot(50, self.load_existing_features)

    def calculate_metrics_for_feature(self, layer, type_key, fid, *_args):
        if self._is_plugin_editing: 
            return
            
        self._is_plugin_editing = True
        try:
            feat = layer.getFeature(fid)
            if not feat.isValid(): return
            
            geom = feat.geometry()
            if geom.isNull(): return

            was_editable = layer.isEditable()
            if not was_editable: layer.startEditing()
            
            if type_key == 'line':
                length_m = geom.length()
                layer.changeAttributeValue(fid, layer.fields().indexOf("length_m"), round(length_m, 2))
                layer.changeAttributeValue(fid, layer.fields().indexOf("measurement"), f"{length_m:.1f} m")
            elif type_key == 'polygon':
                area_m2 = geom.area()
                length_m = geom.length()
                layer.changeAttributeValue(fid, layer.fields().indexOf("area_m2"), round(area_m2, 2))
                layer.changeAttributeValue(fid, layer.fields().indexOf("length_m"), round(length_m, 2))
                if area_m2 > 10000:
                    meas = f"{area_m2 / 10000:.2f} ha\nPeri: {length_m:.1f} m"
                else:
                    meas = f"{area_m2:.1f} m²\nPeri: {length_m:.1f} m"
                layer.changeAttributeValue(fid, layer.fields().indexOf("measurement"), meas)
            elif type_key == 'pin':
                pt = geom.asPoint() if not geom.isMultipart() else geom.asMultiPoint()[0]
                layer.changeAttributeValue(fid, layer.fields().indexOf("coord_xy"), f"{pt.x():.2f}, {pt.y():.2f}")
                layer.changeAttributeValue(fid, layer.fields().indexOf("measurement"), f"X: {pt.x():.1f}\nY: {pt.y():.1f}")
                
            if not was_editable: layer.commitChanges()
        finally:
            self._is_plugin_editing = False
            QTimer.singleShot(50, self.load_existing_features)

    def ensure_color_category(self, layer, geom_type, color_hex):
        renderer = layer.renderer()
        if not isinstance(renderer, QgsCategorizedSymbolRenderer):
            renderer = QgsCategorizedSymbolRenderer("color")
            
        has_color = False
        has_empty = False
        for cat in renderer.categories():
            if cat.value() == color_hex:
                has_color = True
            if cat.value() == "" or cat.value() is None:
                has_empty = True
                
        if has_color and has_empty:
            return 
            
        def _add_cat(hex_val, is_empty_fallback):
            c = QColor(255, 255, 0) if is_empty_fallback else QColor(hex_val)
            actual_hex = c.name()
            
            if geom_type == 'Point':
                sym = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': actual_hex, 'outline_color': '255,255,255,255', 'size': '4'})
                arrow = QgsSimpleMarkerSymbolLayer.create({'name': 'arrowhead', 'color': actual_hex, 'size': '8'})
                arrow.setOffset(QPointF(6, 0))
                arrow.setDataDefinedProperty(QgsSymbolLayer.PropertyAngle, QgsProperty.fromExpression("\"angle\" - 90")) 
                arrow.setDataDefinedProperty(QgsSymbolLayer.PropertySize, QgsProperty.fromExpression("if(\"angle\" IS NULL, 0, max(4, \"size\"))"))
                sym.appendSymbolLayer(arrow)
                sym.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.PropertySize, QgsProperty.fromExpression("max(2, \"size\" / 1.5)"))
                
            elif geom_type == 'LineString':
                sym = QgsLineSymbol.createSimple({'color': actual_hex, 'width': '1'})
                sym.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.PropertyStrokeWidth, QgsProperty.fromExpression("\"size\" / 5.0"))
                
            elif geom_type == 'Polygon':
                fill_c = QColor(c)
                fill_c.setAlpha(60)
                sym = QgsFillSymbol.createSimple({'color': '255,255,255,255', 'outline_color': actual_hex, 'outline_width': '1'})
                sym.symbolLayer(0).setFillColor(fill_c)
                sym.symbolLayer(0).setStrokeColor(c)
                sym.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.PropertyStrokeWidth, QgsProperty.fromExpression("\"size\" / 5.0"))

            cat_val = "" if is_empty_fallback else hex_val
            cat_label = "Default (Map Drawn)" if is_empty_fallback else f"Color: {hex_val.upper()}"
            cat = QgsRendererCategory(cat_val, sym, cat_label)
            renderer.addCategory(cat)

        if not has_color and color_hex:
            _add_cat(color_hex, False)
        if not has_empty:
            _add_cat("", True)
            
        layer.setRenderer(renderer.clone())
        layer.triggerRepaint()

    def setup_drawing_layers(self):
        def _get_or_create(layer_name, geom_type, fields):
            layers = QgsProject.instance().mapLayersByName(layer_name)
            layer = None
            for l in layers:
                try:
                    if l.isValid():
                        layer = l
                        break
                except RuntimeError:
                    pass
            
            if not layer:
                layer = QgsVectorLayer(f"{geom_type}?crs=EPSG:3301", layer_name, "memory")
                pr = layer.dataProvider()
                pr.addAttributes(fields)
                layer.updateFields()
                QgsProject.instance().addMapLayer(layer)
                
                settings = QgsPalLayerSettings()
                settings.fieldName = 'id'
                settings.placement = LabelPlacementOverPoint 
                text_format = QgsTextFormat()
                text_format.setSize(11)
                text_format.setColor(QColor(255, 255, 0))
                fnt = QFont()
                fnt.setBold(True)
                text_format.setFont(fnt)
                halo = QgsTextBufferSettings()
                halo.setEnabled(True)
                halo.setSize(1)
                halo.setColor(QColor("black"))
                text_format.setBuffer(halo)
                settings.setFormat(text_format)
                layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
                layer.setLabelsEnabled(True)
                
                try:
                    idx_c = layer.fields().indexOf("color")
                    if idx_c >= 0: layer.setDefaultValueDefinition(idx_c, QgsDefaultValue("'#FFFF00'"))
                    
                    idx_s = layer.fields().indexOf("size")
                    if idx_s >= 0: layer.setDefaultValueDefinition(idx_s, QgsDefaultValue("6"))
                    
                    idx_p = layer.fields().indexOf("persp")
                    if idx_p >= 0: layer.setDefaultValueDefinition(idx_p, QgsDefaultValue("true"))
                    
                    idx_ph = layer.fields().indexOf("photo")
                    if idx_ph >= 0: layer.setDefaultValueDefinition(idx_ph, QgsDefaultValue("'Map ' || format_date(now(), 'yyyy-MM-dd HH:mm:ss')"))
                except Exception:
                    pass
                    
            try:
                layer.featureAdded.disconnect()
                layer.featureDeleted.disconnect()
                layer.geometryChanged.disconnect()
                layer.attributeValueChanged.disconnect()
            except (TypeError, RuntimeError):
                pass
                
            return layer

        base_fields = [
            QgsField("id", QVariant.Int),
            QgsField("date", QVariant.String),
            QgsField("note", QVariant.String),
            QgsField("photo", QVariant.String),
            QgsField("measurement", QVariant.String), 
            QgsField("length_m", QVariant.Double),   
            QgsField("area_m2", QVariant.Double),     
            QgsField("color", QVariant.String),
            QgsField("size", QVariant.Int),
            QgsField("persp", QVariant.Bool)
        ]
        pin_fields = base_fields + [
            QgsField("angle", QVariant.Double), 
            QgsField("coord_xy", QVariant.String)     
        ]

        self.pin_layer = _get_or_create("Reverse Projection Pins", "Point", pin_fields)
        self.line_layer = _get_or_create("Reverse Projection Lines", "LineString", base_fields)
        self.poly_layer = _get_or_create("Reverse Projection Polygons", "Polygon", base_fields)

        self.current_ids = {'pin': 1, 'line': 1, 'polygon': 1}
        layer_mappings = [
            (self.pin_layer, 'pin', 'Point'), 
            (self.line_layer, 'line', 'LineString'), 
            (self.poly_layer, 'polygon', 'Polygon')
        ]

        for layer, type_key, geom_type in layer_mappings:
            if not isinstance(layer.renderer(), QgsCategorizedSymbolRenderer):
                layer.setRenderer(QgsCategorizedSymbolRenderer("color"))
            
            self.ensure_color_category(layer, geom_type, "")
            
            layer.featureDeleted.connect(self.on_qgis_layer_changed)
            layer.attributeValueChanged.connect(self.on_qgis_layer_changed)
            
            layer.featureAdded.connect(partial(self.calculate_metrics_for_feature, layer, type_key))
            layer.geometryChanged.connect(partial(self.calculate_metrics_for_feature, layer, type_key))
            
            max_id = 0
            for f in layer.getFeatures():
                if f['id'] and isinstance(f['id'], int) and f['id'] > max_id:
                    max_id = f['id']
                col = f['color']
                if col:
                    self.ensure_color_category(layer, geom_type, col)
                    
            self.current_ids[type_key] = max_id + 1

    def on_tool_changed(self, button):
        tools = {
            0: 'pan', 1: 'pin', 2: 'line', 3: 'polygon', 4: 'remove',
            5: 'tie_point', 6: 'edit', 7: 'place_label', 8: 'horizon', 9: 'drag_align'
        }
        
        if self.tool_group.id(button) not in tools:
            return
            
        self.current_tool = tools[self.tool_group.id(button)]
        if self.current_tool != 'horizon':
            self.btn_horizon_menu.setChecked(False)
        is_edit = (self.current_tool == 'edit')
        labels_on = self.btn_toggle_labels.isChecked()
        
        # Toggle label interactivity based on the current tool
        for item in self._projected_graphics:
            if isinstance(item, InteractiveAnchorItem):
                item.setFlag(GraphicsItemIsMovable, is_edit)
                if is_edit and labels_on and item.label_item and item.label_item.isSelected():
                    item.setVisible(True)
                else:
                    item.setVisible(False)
            elif isinstance(item, InteractiveLabelItem):
                item.setFlag(GraphicsItemIsMovable, is_edit)

        self._clear_horizon_graphics()
        self._set_wireframe_visible(self.current_tool == 'drag_align' and self._wf_visible)
        
        if self.current_tool == 'pan':
            self.proj_view.setDragMode(ScrollHandDrag)
            self.proj_view.unsetCursor()
            self.hint.setText("")
            if self.main_side_tabs.currentIndex() == 3:
                self.main_side_tabs.blockSignals(True)
                self.main_side_tabs.setCurrentIndex(2)
                self.main_side_tabs.blockSignals(False)
        else:
            self.proj_view.setDragMode(NoDrag)
            self.proj_view.unsetCursor()
            
            if self.current_tool == 'edit':
                self.hint.setText(tr("hint_edit"))
                self.main_side_tabs.setCurrentIndex(0)
            elif self.current_tool == 'place_label':
                self.hint.setText(tr("hint_place"))
                self.main_side_tabs.setCurrentIndex(0)
            elif self.current_tool == 'pin':
                self.hint.setText(tr("hint_pin"))
                self.main_side_tabs.setCurrentIndex(1)
                self.sym_tabs.setCurrentIndex(0)
            elif self.current_tool == 'line':
                self.hint.setText(tr("hint_line"))
                self.main_side_tabs.setCurrentIndex(1)
                self.sym_tabs.setCurrentIndex(1)
            elif self.current_tool == 'polygon':
                self.hint.setText(tr("hint_poly"))
                self.main_side_tabs.setCurrentIndex(1)
                self.sym_tabs.setCurrentIndex(2)
            elif self.current_tool == 'remove':
                self.hint.setText(tr("hint_remove"))
            elif self.current_tool == 'tie_point':
                self.proj_view.setCursor(CrossCursor)
                self.main_side_tabs.setCurrentIndex(2)
                self.hint.setText(tr("hint_tie"))
            elif self.current_tool == 'horizon':
                self.proj_view.setCursor(CrossCursor)
                self.btn_horizon_menu.setChecked(True)
                self.hint.setText(tr("hint_horizon_1"))
            elif self.current_tool == 'drag_align':
                self.proj_view.setCursor(SizeAllCursor)
                if self.drag_align_panel is not None and self.drag_align_panel.active_mode == 'horizon':
                    self.drag_align_panel.set_active_mode('pan_rot', emit_signal=False)
                    self._drag_align_mode = 'pan_rot'
                self.main_side_tabs.blockSignals(True)
                self.main_side_tabs.setCurrentIndex(3)
                self.main_side_tabs.blockSignals(False)
                self._build_wireframe_cache()
                self._curr_fpitch_deg = 0.0
                self._fpitch_anchor = self._snapshot_fpitch_anchor()
                self._sync_drag_align_dialog(include_fpitch=True)
                self._update_wireframe_overlay()
                self.hint.setText(tr("hint_drag_align"))
            
        self._apply_overlay_visibility()
        self.clear_temp_drawing()

    def pick_color(self, t_key, *_args):
        ui = self.sym_ui[t_key]
        color = QColorDialog.getColor(ui['color'], self, f"Pick {t_key.title()} Color")
        if color.isValid():
            ui['color'] = color
            ui['btn_color'].setStyleSheet(f"background-color: {color.name()}; border: 1px solid white; height: 20px;")

    def keyPressEvent(self, event):
        if event.key() == Key_Space and not self.txt_feature_note.hasFocus() and not self.proj_lbl_canvas.hasFocus():
            if not event.isAutoRepeat() and not self._space_peeking:
                self._space_peeking = True
                self._apply_overlay_visibility()
            event.accept()
            return

        if event.key() in (Key_Return, Key_Enter):
            if self.current_tool == 'drag_align' or any(
                sb.hasFocus() for sb in [
                    self.spin_man_pitch, self.spin_man_yaw, self.spin_man_roll, self.spin_man_focal,
                    self.spin_man_x, self.spin_man_y, self.spin_man_geoid,
                    self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3, self.combo_lens
                ]
            ):
                self.apply_manual_offsets()
                event.accept()
                return
            self.txt_feature_note.clearFocus()
            event.ignore()
            return
            
        elif event.key() == Key_Escape:
            self.clear_temp_drawing()
            self._clear_horizon_graphics()
            event.accept()
            return
            
        elif event.key() == Key_Up and not self.txt_feature_note.hasFocus():
            r = self.filmstrip.currentRow()
            if r > 0: self.filmstrip.setCurrentRow(r - 1)
            event.accept()
            return
            
        elif event.key() == Key_Down and not self.txt_feature_note.hasFocus():
            r = self.filmstrip.currentRow()
            if r < self.filmstrip.count() - 1: self.filmstrip.setCurrentRow(r + 1)
            event.accept()
            return
            
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == Key_Space and self._space_peeking:
            if not event.isAutoRepeat():
                self._space_peeking = False
                self._apply_overlay_visibility()
            event.accept()
            return
        super().keyReleaseEvent(event)

    def _collect_pose_overrides_from_ui(self, existing_overrides=None):
        overrides = dict(existing_overrides or {})
        overrides['pitch_offset'] = self.spin_man_pitch.value()
        overrides['yaw_offset'] = self.spin_man_yaw.value()
        overrides['roll_offset'] = self.spin_man_roll.value()
        overrides['focal_scale'] = round(self.spin_man_focal.value() / 100.0, 5)
        overrides['x_offset'] = self.spin_man_x.value()
        overrides['y_offset'] = self.spin_man_y.value()
        overrides['use_auto_geoid'] = self.chk_man_auto_geoid.isChecked()
        if not self.chk_man_auto_geoid.isChecked():
            overrides['geoid_offset'] = self.spin_man_geoid.value()
        else:
            overrides.pop('geoid_offset', None)

        lens_code = self.combo_lens.currentData()
        if lens_code == "Wide":
            overrides['lens_override'] = 'Wide'
        elif lens_code == "Zoom":
            overrides['lens_override'] = 'Zoom'
        else:
            overrides.pop('lens_override', None)

        overrides['dist_offsets'] = {
            'k1': self.spin_man_k1.value(),
            'k2': self.spin_man_k2.value(),
            'p1': self.spin_man_p1.value(),
            'p2': self.spin_man_p2.value(),
            'k3': self.spin_man_k3.value(),
        }
        return overrides

    def reset_manual_offsets(self):
        row = self.filmstrip.currentRow()
        if row < 0 or row >= len(self.gallery_data):
            return
        data = self.gallery_data[row]
        keep_lbl = data.get('overrides', {}).get('label_offsets', {})
        data['overrides'] = {'label_offsets': keep_lbl} if keep_lbl else {}
        
        for w_ctrl in [
            self.spin_man_pitch, self.spin_man_yaw, self.spin_man_roll, self.spin_man_focal,
            self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid,
            self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3,
            self.combo_lens
        ]:
            w_ctrl.blockSignals(True)
        
        self.spin_man_pitch.setValue(0.0)
        self.spin_man_yaw.setValue(0.0)
        self.spin_man_roll.setValue(0.0)
        self.spin_man_focal.setValue(100.0)
        self.spin_man_x.setValue(0.0)
        self.spin_man_y.setValue(0.0)
        self.spin_man_k1.setValue(0.0)
        self.spin_man_k2.setValue(0.0)
        self.spin_man_p1.setValue(0.0)
        self.spin_man_p2.setValue(0.0)
        self.spin_man_k3.setValue(0.0)
        self.combo_lens.setCurrentIndex(0)
        self.chk_man_auto_geoid.setChecked(True)
        self.spin_man_geoid.setEnabled(False)
        self.spin_man_geoid.setValue(self._auto_geoid_curr)
            
        for w_ctrl in [
            self.spin_man_pitch, self.spin_man_yaw, self.spin_man_roll, self.spin_man_focal,
            self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid,
            self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3,
            self.combo_lens
        ]:
            w_ctrl.blockSignals(False)
        
        self._sync_filmstrip_item_label(row)
        self.apply_manual_offsets()

    def apply_manual_offsets(self):
        row = self.filmstrip.currentRow()
        if row < 0 or row >= len(self.gallery_data):
            return
        data = self.gallery_data[row]
        overrides = self._collect_pose_overrides_from_ui(data.get('overrides', {}))
        data['overrides'] = overrides
        self._sync_filmstrip_item_label(row)
        self._projected_label_cache.pop(data['raw_path'], None)

        try:
            self.engine, _, self._auto_geoid_curr, _, _, _ = self._construct_engine_for_photo(
                data['raw_path'], overrides, build_dem_sampler=False
            )
            self._curr_fpitch_deg = 0.0
            self._fpitch_anchor = self._snapshot_fpitch_anchor()
            self._sync_drag_align_dialog(include_fpitch=True)
            if self.current_tool == 'drag_align':
                self._update_wireframe_overlay()
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to update viewer engine: {e}", "MavicProjector", Qgis.Warning)
            
        self._run_single_projection(data)

    def apply_offsets_to_all_photos(self):
        row = self.filmstrip.currentRow()
        if row < 0 or len(self.gallery_data) == 0:
            return 0
        pose_template = self._collect_pose_overrides_from_ui()
        for idx, d in enumerate(self.gallery_data):
            merged = dict(pose_template)
            keep_lbl = d.get('overrides', {}).get('label_offsets', {})
            if keep_lbl:
                merged['label_offsets'] = keep_lbl
            d['overrides'] = merged
            self._sync_filmstrip_item_label(idx)

        self._projected_label_cache.clear()
        self.apply_manual_offsets()
        self.hint.setText(tr("msg_copied_all", n=len(self.gallery_data)))
        return len(self.gallery_data)

    def _run_single_projection(self, data, silent=False):
        if self.temp_task:
            try:
                self.temp_task.cancel()
            except Exception:
                pass
            self.temp_task = None
                
        layer_items = self._collect_studio_layer_items(respect_label_toggle=False)
        if not layer_items:
            self._proj_pixmap = self._raw_pixmap
            self._projected_label_data = {}
            self._projected_label_cache.clear()
            self._apply_overlay_visibility()
            self.load_existing_features()
            self.render_projected_labels()
            return
            
        photo_items = [{
            'path': data['raw_path'],
            'overrides': data.get('overrides', {})
        }]
        
        self._is_silent_projection = silent
        if not silent:
            self.btn_apply_manual.setText("⏳ Reprojecting Image...")
            self.btn_apply_manual.setEnabled(False)
            self.btn_reset_manual.setEnabled(False)
            
        self.btn_fast_refresh.setText("⏳ Extracting Labels...")
        self.btn_fast_refresh.setEnabled(False)
        
        from ..core.task_worker import ProjectionTask
        safe_context = QgsProject.instance().transformContext()
        
        self.temp_task = ProjectionTask(photo_items, layer_items, self.dem_layer, self.global_settings, transform_context=safe_context, interactive_mode=True)
        self.temp_task._target_raw_path = data['raw_path']
        
        self.temp_task.progressChanged.connect(self._update_refresh_btn_progress)
        self.temp_task.signals.log_signal.connect(self._log_task_message)
        self.temp_task.signals.finished_signal.connect(self._on_single_projection_finished)
        QgsApplication.taskManager().addTask(self.temp_task)
        
    def _update_refresh_btn_progress(self, progress):
        self.btn_fast_refresh.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
            f"stop:0 #059669, stop:{progress/100.0} #059669, "
            f"stop:{min(1.0, (progress/100.0)+0.001)} #444, stop:1 #444); "
            f"color: white; font-weight: bold; text-align: center;"
        )
        self.btn_fast_refresh.setText(f"⏳ Extracting Labels... {int(progress)}%")

    def _on_single_projection_finished(self, success, err):
        task_obj = self.temp_task
        self.temp_task = None
        
        if not self._is_silent_projection:
            self.btn_apply_manual.setText(tr("btn_apply"))
            self.btn_apply_manual.setEnabled(True)
            self.btn_reset_manual.setEnabled(True)
            
        self.btn_fast_refresh.setText(tr("btn_fast_refresh"))
        self.btn_fast_refresh.setStyleSheet("")
        self.btn_fast_refresh.setEnabled(True)
        
        if success:
            QPixmapCache.clear() 
            target_raw = getattr(task_obj, '_target_raw_path', None)
            lbl_data = getattr(task_obj, 'projected_labels_data', {}) if task_obj else {}
            if target_raw:
                self._projected_label_cache[target_raw] = lbl_data

            row = self.filmstrip.currentRow()
            if row >= 0:
                data = self.gallery_data[row]
                if target_raw and data['raw_path'] != target_raw:
                    return
                
                self._projected_label_data = lbl_data
                
                cache_dir = os.path.join(os.path.dirname(data['raw_path']), ".mavic_cache")
                stem, _ = os.path.splitext(os.path.basename(data['raw_path']))
                cache_path = os.path.join(cache_dir, f"{stem}_TEMP.jpg")
                
                img = QImage()
                if os.path.exists(cache_path): img.load(cache_path)
                elif os.path.exists(data['proj_path']): img.load(data['proj_path'])
                
                proj_pix = QPixmap.fromImage(img)
                
                if not proj_pix.isNull():
                    self._proj_pixmap = proj_pix
                    self._wireframe_dirty_since_render = False
                    if row < self.filmstrip.count():
                        self.filmstrip.item(row).setIcon(QIcon(proj_pix.scaled(68, 46, KeepAspectRatio)))
                    if self.proj_bg_item is not None and self.proj_bg_item.scene() == self.proj_scene:
                        self._apply_overlay_visibility()
                        QgsApplication.processEvents()
                        self.load_existing_features()
                        self.render_projected_labels()
                        self._apply_overlay_visibility()
                    else:
                        self.load_photo(row, keep_snaps=True)
        else:
            if not self._is_silent_projection:
                QMessageBox.warning(self, "Reprojection Failed", f"Failed to reproject image:\n{err}")

    def render_projected_labels(self):
        import math
        from qgis.PyQt.QtCore import QTimer
        from qgis.PyQt.QtWidgets import QPushButton
        
        # 1. The 5-Second Cooldown Lock
        if getattr(self, '_is_rendering_labels', False):
            return
        self._is_rendering_labels = True

        # Grab the sender to see if a manual button click triggered this
        trigger_btn = self.sender()
        is_button = isinstance(trigger_btn, QPushButton)
        
        original_text = ""
        original_style = ""
        if is_button:
            try:
                original_text = trigger_btn.text()
                original_style = trigger_btn.styleSheet()
                trigger_btn.setEnabled(False)
            except RuntimeError:
                is_button = False

        if not hasattr(self, '_graphics_trash_bin'):
            self._graphics_trash_bin = []

        # Use 5 seconds (50 ticks) for manual clicks, or 0.2s for automated system calls
        self._cooldown_ticks = 50 if is_button else 2 

        def tick_cooldown():
            # Safety check in case the user closes the dialog early
            if not hasattr(self, '_is_rendering_labels'): return 

            if self._cooldown_ticks > 0:
                if is_button:
                    try:
                        sec_left = math.ceil(self._cooldown_ticks / 10.0)
                        trigger_btn.setText(f"Refreshing... {sec_left}s")
                        
                        # Simulate a progress bar using a dynamic linear gradient
                        progress = 1.0 - (self._cooldown_ticks / 50.0)
                        progress = max(0.001, min(0.999, progress))
                        css = (
                            f"QPushButton {{"
                            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
                            f"stop:0 #0078D7, stop:{progress} #0078D7, "
                            f"stop:{progress + 0.001} #333333, stop:1 #333333); "
                            f"color: white; border: 1px solid #555; border-radius: 3px; padding: 5px;"
                            f"}}"
                        )
                        trigger_btn.setStyleSheet(css)
                    except RuntimeError:
                        pass
                        
                self._cooldown_ticks -= 1
                QTimer.singleShot(100, tick_cooldown)
            else:
                # Cooldown complete: restore button and empty the memory trash
                if is_button:
                    try:
                        trigger_btn.setText(original_text)
                        trigger_btn.setStyleSheet(original_style)
                        trigger_btn.setEnabled(True)
                    except RuntimeError:
                        pass
                
                self._is_rendering_labels = False
                if hasattr(self, '_graphics_trash_bin'):
                    self._graphics_trash_bin.clear()

        # Start the countdown and progress bar animation
        tick_cooldown()

        # --- 2. Proceed with Immediate Rendering ---
        row_curr = self.filmstrip.currentRow()
        curr_raw = self.gallery_data[row_curr]['raw_path'] if 0 <= row_curr < len(self.gallery_data) else None
        if (
            self.layer_list.count() > 0
            and curr_raw
            and curr_raw not in self._projected_label_cache
            and not self._projected_label_data
        ):
            self._run_single_projection(self.gallery_data[row_curr], silent=True)
            return

        self.proj_scene.blockSignals(True)

        selected_keys = set()
        for item in self.proj_scene.selectedItems():
            if hasattr(item, 'feature_key'):
                selected_keys.add(item.feature_key)

        for item in self._projected_graphics:
            try: 
                if hasattr(item, 'setGraphicsEffect'):
                    item.setGraphicsEffect(None)
                if item.scene() == self.proj_scene:
                    item.setSelected(False) 
                    item.hide() 
                    self.proj_scene.removeItem(item)
            except Exception: 
                pass
                
        # Move dead items to the trash bin to prevent C++ Access Violations
        self._graphics_trash_bin.extend(self._projected_graphics)
        self._projected_graphics.clear()
        
        if hasattr(self, 'proj_scene') and self.proj_scene:
            self.proj_scene.invalidate()

        row = self.filmstrip.currentRow()
        if row < 0 or self.layer_list.count() == 0: 
            self.proj_scene.blockSignals(False)
            return
            
        data = self.gallery_data[row]
        label_offsets = data.get('overrides', {}).get('label_offsets', {})
        
        is_edit_mode = (self.current_tool == 'edit')
        show_ov = self.btn_toggle_overlay.isChecked() and not self._space_peeking
        global_shadows_on = self.btn_toggle_shadows.isChecked()
        global_labels_on = self.btn_toggle_labels.isChecked() and show_ov
        global_callouts_on = self.btn_toggle_callouts.isChecked()
        
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer = item.data(UserRole)
            style = item.data(UserRole + 1) or {}
            
            if not layer or not layer.isValid(): continue
            layer_id = layer.id()
            
            if layer_id not in self._projected_label_data: continue
            lbl_data_list = self._projected_label_data[layer_id]
            
            base_font_size = style.get('font_size', 48)
            base_color = style.get('label_color', (255, 255, 0, 255))
            c_c = style.get('callout_color', (150, 150, 150, 200))
            callout_color = QColor(c_c[0], c_c[1], c_c[2], c_c[3])
            
            callout_width = max(2, style.get('callout_width', 2)) 
            
            preset = style.get('preset', "Standard (Flat)")
            shadow_angle = style.get('light_angle', 45)
            shadow_dist = style.get('shadow_dist', 15)
            label_expr_str = style.get('label_expr', "")
            
            fids = [ld['fid'] for ld in lbl_data_list]
            request = QgsFeatureRequest().setFilterFids(fids)
            feature_dict = {f.id(): f for f in layer.getFeatures(request)}
            
            for ld in lbl_data_list:
                fid = ld['fid']
                feature_key = f"{layer_id}_{fid}"
                
                saved_override = label_offsets.get(feature_key, {})
                if saved_override.get("hidden", False): continue
                    
                feat = feature_dict.get(fid)
                if not feat: continue
                
                custom_scale = saved_override.get("size", 1.0)
                custom_color_tup = saved_override.get("color", None)
                final_color = QColor(*custom_color_tup) if custom_color_tup else QColor(*base_color)
                
                fnt = QFont()
                fnt.setPointSize(int(base_font_size * custom_scale))
                fnt.setBold(True)
                
                text_str = label_expr_str
                if text_str:
                    for fld in feat.fields():
                        placeholder = f"[{fld.name()}]"
                        if placeholder in text_str:
                            val = feat.attribute(fld.name())
                            text_str = text_str.replace(placeholder, str(val) if val is not None else "")
                            
                if not text_str.strip():
                    continue

                dummy_item = QGraphicsTextItem(text_str)
                dummy_item.setFont(fnt)
                br = dummy_item.boundingRect()
                del dummy_item

                anchor_x = ld['anchor_x']
                anchor_y = ld['anchor_y']
                
                cx_off = saved_override.get("cx_off")
                cy_off = saved_override.get("cy_off")
                adx = saved_override.get("adx", 0.0)
                ady = saved_override.get("ady", 0.0)
                
                true_anchor_x = anchor_x + adx
                true_anchor_y = anchor_y + ady
                
                is_billboard = (preset == "Billboard (Stand-up)")
                
                if cx_off is not None and cy_off is not None:
                    cx = anchor_x + cx_off
                    cy = anchor_y + cy_off
                else:
                    cx = anchor_x
                    cy = anchor_y - (max(15, abs(shadow_dist)) * custom_scale if is_billboard else 15 * custom_scale) - br.height() / 2.0

                lbl_item = InteractiveLabelItem(text_str, anchor_x, anchor_y, feature_key, self, style, custom_scale)
                lbl_item.setFont(fnt)
                lbl_item.setZValue(100)
                lbl_item.set_initial_center(cx, cy)
                
                anchor_item = InteractiveAnchorItem(anchor_x, anchor_y, feature_key, self, lbl_item)
                anchor_item.setPos(true_anchor_x, true_anchor_y) 
                anchor_item.setVisible(False) 
                anchor_item.setFlag(GraphicsItemIsMovable, is_edit_mode) 
                self.proj_scene.addItem(anchor_item)
                self._projected_graphics.append(anchor_item)
                lbl_item.anchor_item = anchor_item
                
                if is_billboard:
                    lbl_item.setDefaultTextColor(QColor("black"))
                    
                    bg_item = QGraphicsPathItem()
                    bg_item.setBrush(QBrush(QColor("white")))
                    bg_item.setPen(QPen(QColor("black"), max(2, int(4 * custom_scale))))
                    bg_item.setZValue(98)
                    bg_item.setVisible(global_labels_on)
                    self.proj_scene.addItem(bg_item)
                    self._projected_graphics.append(bg_item)
                    lbl_item.bg_item = bg_item
                    
                    bg_item_pole = QGraphicsPathItem()
                    bg_item_pole.setBrush(QBrush(QColor("white")))
                    bg_item_pole.setPen(QPen(QColor("black"), max(2, int(4 * custom_scale))))
                    bg_item_pole.setZValue(97.5) 
                    bg_item_pole.setVisible(global_labels_on)
                    self.proj_scene.addItem(bg_item_pole)
                    self._projected_graphics.append(bg_item_pole)
                    lbl_item.bg_item_pole = bg_item_pole
                    
                    shadow_item = QGraphicsPathItem()
                    shadow_item.setBrush(QBrush(QColor(0, 0, 0, 120)))
                    shadow_item.setPen(QPen(QColor(0, 0, 0, 0))) 
                    shadow_item.setZValue(97)
                    shadow_item.setVisible(global_shadows_on and global_labels_on)
                    
                    shadow_blur = style.get('shadow_blur', 0)
                    if shadow_blur > 0:
                        blur_effect = QGraphicsBlurEffect()
                        blur_effect.setBlurRadius(shadow_blur)
                        shadow_item.setGraphicsEffect(blur_effect)
                        
                    self.proj_scene.addItem(shadow_item)
                    self._projected_graphics.append(shadow_item)
                    lbl_item.shadow_item = shadow_item
                else:
                    lbl_item.setDefaultTextColor(final_color)
                    
                    bg_item = QGraphicsLineItem()
                    bg_item.setPen(QPen(callout_color, max(1, int(callout_width * custom_scale)), SolidLine, RoundCap))
                    bg_item.setZValue(98)
                    bg_item.setVisible(global_callouts_on and global_labels_on)
                    self.proj_scene.addItem(bg_item)
                    self._projected_graphics.append(bg_item)
                    lbl_item.bg_item = bg_item
                        
                    shadow_item = QGraphicsTextItem(text_str)
                    shadow_item.setFont(fnt)
                    shadow_item.setDefaultTextColor(QColor(0, 0, 0, 150))
                    shadow_item.setZValue(97)
                    rad = math.radians(shadow_angle)
                    shadow_item.base_sx = math.cos(rad) * shadow_dist
                    shadow_item.base_sy = -math.sin(rad) * shadow_dist
                    shadow_item.setVisible(global_shadows_on and global_labels_on)
                    shadow_blur = style.get('shadow_blur', 0)
                    if shadow_blur > 0:
                        blur_effect = QGraphicsBlurEffect()
                        blur_effect.setBlurRadius(shadow_blur)
                        blur_effect.setBlurHints(BlurPerformanceHint) 
                        shadow_item.setGraphicsEffect(blur_effect)
                        shadow_item.setCacheMode(DeviceCoordinateCache) 
                    self.proj_scene.addItem(shadow_item)
                    self._projected_graphics.append(shadow_item)
                    lbl_item.shadow_item = shadow_item

                lbl_item.setFlag(GraphicsItemIsMovable, is_edit_mode) 
                lbl_item.update_visuals()
                lbl_item.setVisible(global_labels_on)
                self.proj_scene.addItem(lbl_item)
                self._projected_graphics.append(lbl_item)
                
                if feature_key in selected_keys:
                    lbl_item.setSelected(True)

        self.proj_scene.blockSignals(False)
        self._on_scene_selection_changed()
        
        if hasattr(self, 'proj_scene') and self.proj_scene:
            self.proj_scene.update()

    def load_photo(self, index, keep_snaps=False):
        if index < 0 or index >= len(self.gallery_data):
            self._show_empty_canvas_message()
            return
        
        self.txt_feature_note.blockSignals(True)
        self.update_buttons()
        self.clear_temp_drawing()
        
        if not keep_snaps:
            self.active_qgis_fid = None
            if self.current_tool == 'tie_point':
                self.btn_pan.setChecked(True)
                self.on_tool_changed(self.btn_pan)
        
        self.lbl_detail_title.setText("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
        self.txt_feature_note.setText("")
        self.txt_feature_note.setEnabled(False)
        self.txt_feature_note.blockSignals(False)

        data = self.gallery_data[index]
        self.photo_name = data['name']
        self.setWindowTitle(tr("studio_title_photo", name=self.photo_name))
        
        raw_path = data['raw_path']
        proj_path = data['proj_path']
        overrides = data.get('overrides', {})
        
        active_pitch = overrides.get('pitch_offset', self.global_settings.get('pitch_offset', 0.0))
        active_yaw = overrides.get('yaw_offset', self.global_settings.get('yaw_offset', 0.0))
        active_roll = overrides.get('roll_offset', self.global_settings.get('roll_offset', 0.0))
        active_fscale = overrides.get('focal_scale', self.global_settings.get('focal_scale', 1.0))
        
        active_x = overrides.get('x_offset', self.global_settings.get('x_offset', 0.0))
        active_y = overrides.get('y_offset', self.global_settings.get('y_offset', 0.0))
        
        active_dists = dict(self.global_settings.get('dist_offsets', {}))
        if isinstance(overrides.get('dist_offsets'), dict):
            active_dists.update(overrides['dist_offsets'])
        elif 'dist_offset' in overrides:
            active_dists['k1'] = float(overrides['dist_offset'])
        lens_override = overrides.get('lens_override', 'Auto (From File)')
        
        for w_ctrl in [
            self.spin_man_pitch, self.spin_man_yaw, self.spin_man_roll, self.spin_man_focal,
            self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid,
            self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3,
            self.combo_lens
        ]:
            w_ctrl.blockSignals(True)
        
        self.spin_man_pitch.setValue(active_pitch)
        self.spin_man_yaw.setValue(active_yaw)
        self.spin_man_roll.setValue(active_roll)
        self.spin_man_focal.setValue(active_fscale * 100.0)
        self.spin_man_x.setValue(active_x)
        self.spin_man_y.setValue(active_y)
        self.spin_man_k1.setValue(active_dists.get('k1', 0.0))
        self.spin_man_k2.setValue(active_dists.get('k2', 0.0))
        self.spin_man_p1.setValue(active_dists.get('p1', 0.0))
        self.spin_man_p2.setValue(active_dists.get('p2', 0.0))
        self.spin_man_k3.setValue(active_dists.get('k3', 0.0))
        
        if lens_override in ('Wide', 'Force Wide'):
            self.combo_lens.setCurrentIndex(1)
        elif lens_override in ('Zoom', 'Force Zoom'):
            self.combo_lens.setCurrentIndex(2)
        else:
            self.combo_lens.setCurrentIndex(0)
        
        try:
            self.engine, tel, self._auto_geoid_curr, use_auto_g, active_geoid, self.dem_sampler = self._construct_engine_for_photo(
                raw_path, overrides, build_dem_sampler=(not keep_snaps or self.dem_sampler is None)
            )
            self.chk_man_auto_geoid.setChecked(use_auto_g)
            self.spin_man_geoid.setEnabled(not use_auto_g)
            self.spin_man_geoid.setValue(active_geoid)
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to build engine for {self.photo_name}: {e}", "MavicProjector", Qgis.Warning)
            
        for w_ctrl in [
            self.spin_man_pitch, self.spin_man_yaw, self.spin_man_roll, self.spin_man_focal,
            self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid,
            self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3,
            self.combo_lens
        ]:
            w_ctrl.blockSignals(False)
            
        self.proj_scene.clear()
        self.proj_bg_item = None
        self._wireframe_item_proj = None
        self._projected_graphics.clear()
        self._persistent_graphics.clear()
        self._projected_label_data = {}

        self._raw_pixmap = QPixmap(raw_path)
        self._proj_pixmap = QPixmap()
        self._wireframe_dirty_since_render = False

        cache_dir = os.path.join(os.path.dirname(raw_path), ".mavic_cache")
        stem, _ = os.path.splitext(os.path.basename(raw_path))
        cache_path = os.path.join(cache_dir, f"{stem}_TEMP.jpg")

        cache_fresh = (
            self.layer_list.count() > 0
            and raw_path in self._projected_label_cache
            and os.path.exists(cache_path)
        )
        load_path = cache_path if cache_fresh else (proj_path if (self.layer_list.count() > 0 and os.path.exists(proj_path)) else "")
        if load_path and os.path.exists(load_path):
            self._proj_pixmap = QPixmap(load_path)

        init_pix = self._proj_pixmap if (
            self.btn_toggle_overlay.isChecked() and not self._space_peeking and not self._proj_pixmap.isNull()
        ) else self._raw_pixmap

        if not init_pix.isNull():
            self.proj_bg_item = self.proj_scene.addPixmap(init_pix)
            self.proj_bg_item.setZValue(0)
            self.proj_scene.setSceneRect(QRectF(init_pix.rect()))
            if not keep_snaps:
                self.proj_view.fitInView(self.proj_scene.sceneRect(), KeepAspectRatio)
            QgsApplication.processEvents()
            
        self.load_existing_features()
        self._curr_fpitch_deg = 0.0
        self._fpitch_anchor = self._snapshot_fpitch_anchor()
        self._sync_drag_align_dialog(include_fpitch=True)
        if self.current_tool == 'drag_align':
            self._build_wireframe_cache()
            self._update_wireframe_overlay()
        
        if self.layer_list.count() > 0:
            if cache_fresh:
                self._projected_label_data = self._projected_label_cache[raw_path]
                self.render_projected_labels()
            else:
                self.btn_fast_refresh.setText("⏳ Extracting Labels...")
                self._run_single_projection(data, silent=True)
        self._apply_overlay_visibility()

    def get_world_z(self, x, y):
        if self.dem_sampler is not None:
            return self.dem_sampler.sample(x, y, fallback_override=self.fallback_z)
        z = self.fallback_z
        if self.dem_layer and self.dem_layer.isValid():
            val, ok = self.dem_layer.dataProvider().sample(QgsPointXY(x, y), 1)
            if ok and not math.isnan(val):
                z = float(val)
        return z

    def _clear_horizon_graphics(self):
        for item in self.horizon_graphics:
            try:
                if item.scene():
                    item.scene().removeItem(item)
            except RuntimeError:
                pass
        self.horizon_graphics.clear()
        self.horizon_pts.clear()

    def open_drag_align_dialog(self):
        self.btn_drag_align.setChecked(True)
        self.on_tool_changed(self.btn_drag_align)

    def _ensure_drag_align_dialog(self):
        self._sync_drag_align_dialog(include_fpitch=True)
        if self.main_side_tabs.currentIndex() != 3:
            self.main_side_tabs.blockSignals(True)
            self.main_side_tabs.setCurrentIndex(3)
            self.main_side_tabs.blockSignals(False)

    def run_auto_horizon(self, *_args):
        row = self.filmstrip.currentRow()
        if row < 0 or row >= len(self.gallery_data) or not self.engine:
            return None
        raw_path = self.gallery_data[row]['raw_path']
        self._clear_horizon_graphics()
        res = self.engine.detect_horizon_ransac(raw_path)
        if res is None:
            self.hint.setText(tr("msg_auto_horizon_none"))
            if self.iface and hasattr(self.iface, 'messageBar') and self.iface.messageBar():
                try:
                    self.iface.messageBar().pushMessage(
                        tr("tool_auto_horizon"), tr("msg_auto_horizon_none"), Qgis.Warning, 5
                    )
                except Exception:
                    pass
            return None

        dpitch = float(res['dpitch'])
        droll = float(res['droll'])
        n_pts = int(res['inliers'])
        curve_uv = res.get('curve_uv', [])

        if len(curve_uv) >= 2:
            h_path = QPainterPath()
            h_path.moveTo(float(curve_uv[0][0]), float(curve_uv[0][1]))
            for ux, vy in curve_uv[1:]:
                h_path.lineTo(float(ux), float(vy))
            curve_item = QGraphicsPathItem(h_path)
            curve_item.setPen(QPen(QColor(0, 238, 255, 230), 6, DashLine, RoundCap))
            curve_item.setZValue(112)
            self.proj_scene.addItem(curve_item)
            self.horizon_graphics.append(curve_item)
            QTimer.singleShot(4500, self._clear_horizon_graphics)

        self.spin_man_pitch.setValue(dpitch)
        self.spin_man_roll.setValue(droll)
        self.apply_manual_offsets()
        self.hint.setText(tr("msg_auto_horizon_ok", n=n_pts, dp=dpitch, dr=droll))
        return res

    def _sync_drag_align_dialog(self, include_fpitch=True):
        vals = (
            self.spin_man_yaw.value(),
            self.spin_man_pitch.value(),
            self.spin_man_roll.value(),
            self.spin_man_focal.value(),
            self.spin_man_geoid.value(),
            self.spin_man_x.value(),
            self.spin_man_y.value(),
        )
        fp_kw = {'forward_pitch_deg': (self._curr_fpitch_deg if include_fpitch else None)}
        if self.drag_align_panel is not None:
            self.drag_align_panel.sync_from_viewer(*vals, **fp_kw)
        if self.drag_align_dialog is not None:
            self.drag_align_dialog.sync_from_viewer(*vals, **fp_kw)

    def _get_effective_drone_pos(self, x_off=None, y_off=None, geoid_off=None):
        if not self.engine:
            return None
        xo = self.spin_man_x.value() if x_off is None else float(x_off)
        yo = self.spin_man_y.value() if y_off is None else float(y_off)
        gz = self.spin_man_geoid.value() if geoid_off is None else float(geoid_off)
        if self._base_drone_pos is not None:
            return np.array([
                self._base_drone_pos[0] - xo,
                self._base_drone_pos[1] - yo,
                self._base_drone_pos[2] + gz,
            ], dtype=np.float64)
        return self.engine.drone_pos.copy()

    def _snapshot_fpitch_anchor(self):
        """Captures current pose & ground point projected at optical center (cx, cy)
        for center-anchored orbital Forward Pitch (Ground Tilt).
        """
        if not self.engine:
            return None
        yaw_off = self.spin_man_yaw.value()
        pitch_off = self.spin_man_pitch.value()
        x_off = self.spin_man_x.value()
        y_off = self.spin_man_y.value()
        geoid_off = self.spin_man_geoid.value()

        C0 = self._get_effective_drone_pos(x_off, y_off, geoid_off)
        if C0 is None:
            return None

        yaw_eff = self.engine.grid_yaw_raw + yaw_off
        pitch_eff = float(self.engine.tel['pitch']) + pitch_off
        y_rad = math.radians(yaw_eff)
        p_rad = math.radians(pitch_eff)

        f_horiz = np.array([math.sin(y_rad), math.cos(y_rad)], dtype=np.float64)
        d_world = np.array([
            math.sin(y_rad) * math.cos(p_rad),
            math.cos(y_rad) * math.cos(p_rad),
            math.sin(p_rad),
        ], dtype=np.float64)

        if d_world[2] < -0.02:
            z_est = self.get_world_z(float(C0[0]), float(C0[1]))
            t_hit = max(10.0, min(4000.0, (z_est - float(C0[2])) / float(d_world[2])))
            for _ in range(6):
                px = float(C0[0]) + t_hit * float(d_world[0])
                py = float(C0[1]) + t_hit * float(d_world[1])
                z_est = self.get_world_z(px, py)
                t_new = (z_est - float(C0[2])) / float(d_world[2])
                if t_new <= 5.0:
                    break
                t_hit = max(5.0, min(4000.0, t_new))
            P_center = C0 + t_hit * d_world
            P_center[2] = self.get_world_z(float(P_center[0]), float(P_center[1]))
            D0 = max(1.0, float((P_center[0] - C0[0]) * f_horiz[0] + (P_center[1] - C0[1]) * f_horiz[1]))
            H0 = max(2.0, float(C0[2] - P_center[2]))
        else:
            z_gnd = self.get_world_z(float(C0[0]), float(C0[1]))
            H0 = max(20.0, float(C0[2] - z_gnd))
            D0 = max(150.0, H0 / math.tan(math.radians(15.0)))
            P_center = np.array([
                float(C0[0]) + D0 * float(f_horiz[0]),
                float(C0[1]) + D0 * float(f_horiz[1]),
                z_gnd,
            ], dtype=np.float64)

        R_slant = math.hypot(D0, H0)
        theta0 = math.atan2(H0, D0)
        return {
            'C0': C0,
            'P_center': P_center,
            'f_horiz': f_horiz,
            'D0': D0,
            'H0': H0,
            'R_slant': R_slant,
            'theta0': theta0,
            'base_pitch_off': pitch_off,
            'base_x_off': x_off,
            'base_y_off': y_off,
            'base_geoid_off': geoid_off,
        }

    @staticmethod
    def compute_fpitch_pose(anchor, delta_deg):
        """Orbits camera along vertical circle around P_center by delta_deg:
        keeps optical center pixel (cx, cy) and center ground scale locked while
        tilting the projected ground plane steeper (+delta) or flatter (-delta).
        """
        theta0 = float(anchor['theta0'])
        theta1 = max(math.radians(5.0), min(math.radians(85.0), theta0 + math.radians(float(delta_deg))))
        dtheta = theta1 - theta0
        R_slant = float(anchor['R_slant'])
        D0 = float(anchor['D0'])
        H0 = float(anchor['H0'])
        fh = anchor['f_horiz']

        D1 = R_slant * math.cos(theta1)
        H1 = R_slant * math.sin(theta1)

        new_x_off = max(-500.0, min(500.0, float(anchor['base_x_off']) - (D0 - D1) * float(fh[0])))
        new_y_off = max(-500.0, min(500.0, float(anchor['base_y_off']) - (D0 - D1) * float(fh[1])))
        new_geoid_off = max(-100.0, min(100.0, float(anchor['base_geoid_off']) + (H1 - H0)))
        new_pitch_off = max(-45.0, min(45.0, float(anchor['base_pitch_off']) - math.degrees(dtheta)))
        return new_pitch_off, new_x_off, new_y_off, new_geoid_off, math.degrees(dtheta)

    def _on_da_mode_changed(self, mode_key):
        self._drag_align_mode = mode_key
        if mode_key == 'horizon':
            self.activate_manual_horizon_tool()
        else:
            self.btn_horizon_menu.setChecked(False)
            self.current_tool = 'drag_align'
            self.btn_drag_align.setChecked(True)
            self._clear_horizon_graphics()
            self.proj_view.setDragMode(NoDrag)
            self.proj_view.setCursor(SizeAllCursor)
            if mode_key == 'forward_pitch':
                self._curr_fpitch_deg = 0.0
                self._fpitch_anchor = self._snapshot_fpitch_anchor()
                self._sync_drag_align_dialog(include_fpitch=True)
            if not self._wireframe_world_lines:
                self._build_wireframe_cache()
            self._update_wireframe_overlay()
            self._apply_overlay_visibility()
            self.hint.setText(tr("hint_drag_align"))

    def _on_da_pose_sliders(self, pose_dict):
        if not self.engine:
            return
        for sb in (
            self.spin_man_yaw, self.spin_man_pitch, self.spin_man_roll,
            self.spin_man_focal, self.spin_man_geoid, self.spin_man_x, self.spin_man_y,
            self.chk_man_auto_geoid,
        ):
            sb.blockSignals(True)
        try:
            self.spin_man_yaw.setValue(float(pose_dict['yaw']))
            self.spin_man_pitch.setValue(float(pose_dict['pitch']))
            self.spin_man_roll.setValue(float(pose_dict['roll']))
            self.spin_man_focal.setValue(float(pose_dict['focal_pct']))
            self.spin_man_x.setValue(float(pose_dict['x_off']))
            self.spin_man_y.setValue(float(pose_dict['y_off']))
            if pose_dict.get('manual_geoid'):
                self.chk_man_auto_geoid.setChecked(False)
                self.spin_man_geoid.setEnabled(True)
                self.spin_man_geoid.setValue(float(pose_dict['geoid_z']))
        finally:
            for sb in (
                self.spin_man_yaw, self.spin_man_pitch, self.spin_man_roll,
                self.spin_man_focal, self.spin_man_geoid, self.spin_man_x, self.spin_man_y,
                self.chk_man_auto_geoid,
            ):
                sb.blockSignals(False)

        self._curr_fpitch_deg = 0.0
        self._fpitch_anchor = self._snapshot_fpitch_anchor()
        self._sync_drag_align_dialog(include_fpitch=True)
        self._mark_wireframe_dirty()
        if not self._wireframe_world_lines:
            self._build_wireframe_cache()
        self._update_wireframe_overlay()

    def _on_da_forward_pitch(self, delta_deg):
        if not self.engine:
            return
        if self._fpitch_anchor is None:
            self._fpitch_anchor = self._snapshot_fpitch_anchor()
        if self._fpitch_anchor is None:
            return

        new_pitch, new_x, new_y, new_geoid, actual_deg = self.compute_fpitch_pose(self._fpitch_anchor, delta_deg)
        self._curr_fpitch_deg = actual_deg

        for sb in (self.spin_man_pitch, self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid):
            sb.blockSignals(True)
        try:
            self.spin_man_pitch.setValue(new_pitch)
            self.spin_man_x.setValue(new_x)
            self.spin_man_y.setValue(new_y)
            self.chk_man_auto_geoid.setChecked(False)
            self.spin_man_geoid.setEnabled(True)
            self.spin_man_geoid.setValue(new_geoid)
        finally:
            for sb in (self.spin_man_pitch, self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid):
                sb.blockSignals(False)

        self._sync_drag_align_dialog(include_fpitch=False)
        self._mark_wireframe_dirty()
        if not self._wireframe_world_lines:
            self._build_wireframe_cache()
        self._update_wireframe_overlay()
        self.hint.setText(
            f"⤢ Forward Pitch {actual_deg:+.2f}° | Pitch {new_pitch:+.2f}° | Z {new_geoid:+.2f}m | XY ({new_x:+.1f}, {new_y:+.1f})m"
        )

    def _on_da_hide_baked_changed(self, hide_val):
        self._hide_baked_during_da = bool(hide_val)
        self._apply_overlay_visibility()

    def _mark_wireframe_dirty(self):
        if not self._wireframe_dirty_since_render:
            self._wireframe_dirty_since_render = True
            self._apply_overlay_visibility()

    def _on_da_wireframe_style(self, col, width, vis):
        if isinstance(col, QColor):
            self._wf_color = col
        self._wf_width = max(1, int(width))
        self._wf_visible = bool(vis)
        pen_wf = QPen(self._wf_color, self._wf_width, SolidLine, RoundCap)
        if self._wireframe_item_proj is not None:
            try:
                self._wireframe_item_proj.setPen(pen_wf)
            except RuntimeError:
                pass
        self._set_wireframe_visible(self.current_tool == 'drag_align' and self._wf_visible)
        self._apply_overlay_visibility()

    def _on_da_dialog_closed(self):
        if self.current_tool in ('drag_align', 'horizon'):
            self.btn_pan.setChecked(True)
            self.on_tool_changed(self.btn_pan)

    def _ensure_wireframe_items(self):
        pen_wf = QPen(self._wf_color, self._wf_width, SolidLine, RoundCap)
        if self._wireframe_item_proj is None or self._wireframe_item_proj.scene() != self.proj_scene:
            self._wireframe_item_proj = QGraphicsPathItem()
            self._wireframe_item_proj.setPen(pen_wf)
            self._wireframe_item_proj.setZValue(95)
            self.proj_scene.addItem(self._wireframe_item_proj)
        else:
            self._wireframe_item_proj.setPen(pen_wf)

    def _set_wireframe_visible(self, vis):
        if self._wireframe_item_proj is not None:
            try:
                self._wireframe_item_proj.setVisible(vis)
            except RuntimeError:
                pass

    def _build_wireframe_cache(self):
        """Extracts clipped, distance-sorted, adaptively densified 3D world polylines
        for ALL vector features visible in (or near) the camera's field of view so
        foreground, midground, interior holes, lines, and points are all highlighted.
        """
        self._wireframe_world_lines = []
        if not self.engine or self.layer_list.count() == 0:
            return

        drone_pos = self._get_effective_drone_pos()
        cx_d, cy_d, cz_d = float(drone_pos[0]), float(drone_pos[1]), float(drone_pos[2])
        clip_r = max(500.0, float(self.global_settings.get('max_dist_km', 4.0)) * 1000.0)
        safe_ctx = QgsProject.instance().transformContext()

        yaw_center = self.engine.grid_yaw_raw + self.spin_man_yaw.value()
        pitch_eff = float(self.engine.tel.get('pitch', -25.0)) + self.spin_man_pitch.value()
        y_rad = math.radians(yaw_center)
        fx_h, fy_h = math.sin(y_rad), math.cos(y_rad)
        rx_h, ry_h = math.cos(y_rad), -math.sin(y_rad)

        drone_pt_xy = QgsPointXY(cx_d, cy_d)
        drone_pt_geom = QgsGeometry.fromPointXY(drone_pt_xy)

        # Build a forward viewing sector (with ±88° horizontal half-angle + 300m rear buffer)
        # so behind-camera features in nationwide layers (e.g. PRIA Pärandniidud) never starve foreground features!
        is_steep_nadir = (pitch_eff < -58.0)
        if is_steep_nadir:
            nadir_r = min(clip_r, max(800.0, abs(cz_d) * 4.5))
            wf_bbox = QgsRectangle(cx_d - nadir_r, cy_d - nadir_r, cx_d + nadir_r, cy_d + nadir_r)
            sector_geom = QgsGeometry.fromRect(wf_bbox)
        else:
            rear_buf = 300.0
            fan_pts = [
                QgsPointXY(
                    cx_d - rear_buf * fx_h - rear_buf * rx_h,
                    cy_d - rear_buf * fy_h - rear_buf * ry_h,
                )
            ]
            for deg_off in range(-88, 89, 11):
                ang = y_rad + math.radians(deg_off)
                fan_pts.append(QgsPointXY(cx_d + clip_r * math.sin(ang), cy_d + clip_r * math.cos(ang)))
            fan_pts.append(
                QgsPointXY(
                    cx_d - rear_buf * fx_h + rear_buf * rx_h,
                    cy_d - rear_buf * fy_h + rear_buf * ry_h,
                )
            )
            fan_pts.append(fan_pts[0])
            sector_geom = QgsGeometry.fromPolygonXY([fan_pts])
            wf_bbox = sector_geom.boundingBox()

        from ..core.math_engine import MathEngine
        R_c2w = MathEngine.build_R_c2w(
            yaw_center,
            pitch_eff,
            float(self.engine.tel.get('roll', 0.0)) + self.spin_man_roll.value(),
        )
        R_w2c = R_c2w.T
        K_wf = self.engine.base_camera_matrix.copy()
        fs_curr = max(0.2, self.spin_man_focal.value() / 100.0)
        K_wf[0, 0] *= fs_curr
        K_wf[1, 1] *= fs_curr
        img_w = int(self.engine.tel.get('img_w', 5280))
        img_h = int(self.engine.tel.get('img_h', 3956))
        # Wide padded frustum (+2200 px on all sides ≈ ±30° drag headroom) to keep all viewable features
        wide_planes = MathEngine.compute_frustum_bounds(
            K_wf, self.engine.dist_coeffs, img_w, img_h, margin_px=2200.0, z_near=0.5, z_far=clip_r * 1.15
        )
        inv_2r = 1.0 / (2.0 * MathEngine.EARTH_R_EFF)

        candidates = []
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer = item.data(UserRole)
            style = item.data(UserRole + 1) or {}
            selected_only = (item.checkState() == Checked)
            if not self.is_layer_valid(layer) or layer.type() != 0:
                continue

            z_off = float(style.get('z_offset', 0.0))
            layer_crs = layer.crs()
            to_3301 = None
            to_layer = None
            if layer_crs.isValid() and layer_crs != self.engine.crs_est:
                to_3301 = QgsCoordinateTransform(layer_crs, self.engine.crs_est, safe_ctx)
                to_layer = QgsCoordinateTransform(self.engine.crs_est, layer_crs, safe_ctx)

            req = QgsFeatureRequest()
            if not selected_only:
                try:
                    req.setFilterRect(to_layer.transformBoundingBox(wf_bbox) if to_layer else wf_bbox)
                except Exception:
                    pass

            feats = list(layer.selectedFeatures()) if selected_only else list(layer.getFeatures(req))
            gcat = layer.geometryType()

            for feat in feats:
                geom = QgsGeometry(feat.geometry())
                if geom.isNull() or geom.isEmpty():
                    continue
                if to_3301:
                    try:
                        geom.transform(to_3301)
                    except Exception:
                        continue
                if not is_steep_nadir and not geom.intersects(sector_geom):
                    continue
                dist_2d = float(geom.distance(drone_pt_geom))
                if dist_2d > clip_r:
                    continue
                candidates.append((dist_2d, gcat, z_off, geom))

        # Sort nearest-first so foreground & midground features are ALWAYS included first!
        candidates.sort(key=lambda t: t[0])

        max_total_verts = 80000
        vert_count = 0

        for dist_2d, gcat, z_off, geom in candidates:
            if vert_count >= max_total_verts:
                break

            if gcat == 0:
                # Point geometry -> crisp 3D ground crosshair
                clipped_pt = geom.clipped(wf_bbox)
                if clipped_pt.isNull() or clipped_pt.isEmpty():
                    continue
                pts = clipped_pt.asMultiPoint() if clipped_pt.isMultipart() else [clipped_pt.asPoint()]
                for pt in pts:
                    px, py = float(pt.x()), float(pt.y())
                    d_pt = math.hypot(px - cx_d, py - cy_d)
                    arm = max(2.0, min(25.0, d_pt * 0.008))
                    pz = self.get_world_z(px, py) + z_off
                    self._wireframe_world_lines.append(
                        np.array([[px - arm, py, pz], [px + arm, py, pz]], dtype=np.float64)
                    )
                    self._wireframe_world_lines.append(
                        np.array([[px, py - arm, pz], [px, py + arm, pz]], dtype=np.float64)
                    )
                    vert_count += 4
                continue

            if gcat == 2:
                clipped_poly = geom.clipped(wf_bbox)
                if clipped_poly.isNull() or clipped_poly.isEmpty():
                    continue
                abs_poly = clipped_poly.constGet()
                b_geom = QgsGeometry(abs_poly.boundary()) if abs_poly else QgsGeometry()
            elif gcat == 1:
                b_geom = geom.clipped(wf_bbox)
            else:
                continue

            if b_geom.isNull() or b_geom.isEmpty():
                continue

            # Adaptive terrain densification: fine up close, lightweight in the far distance
            if dist_2d < 500.0:
                dens_step = 8.0
            elif dist_2d < 1500.0:
                dens_step = 20.0
            else:
                dens_step = 50.0

            dens = b_geom.densifyByDistance(dens_step)
            parts = dens.asMultiPolyline() if dens.isMultipart() else [dens.asPolyline()]
            for pl in parts:
                if len(pl) < 2:
                    continue
                xs = np.array([p.x() for p in pl], dtype=np.float64)
                ys = np.array([p.y() for p in pl], dtype=np.float64)
                if self.dem_sampler is not None:
                    zs = self.dem_sampler.sample_array(xs, ys, fallback_override=self.fallback_z) + z_off
                else:
                    zs = np.full(len(pl), self.fallback_z + z_off, dtype=np.float64)

                w_arr = np.stack([xs, ys, zs], axis=1)

                # Reject polylines that lie completely outside the wide (±30° padded) camera frustum
                # unless very close (<250m) to the drone
                if dist_2d > 250.0:
                    rel_chk = w_arr.copy() - drone_pos[None, :]
                    rel_chk[:, 2] -= (rel_chk[:, 0] ** 2 + rel_chk[:, 1] ** 2) * inv_2r
                    cam_chk = (R_w2c @ rel_chk.T).T
                    if np.max(cam_chk[:, 2]) < 0.5:
                        continue
                    if not clip_polyline_to_frustum(cam_chk.tolist(), wide_planes):
                        continue

                self._wireframe_world_lines.append(w_arr)
                vert_count += len(pl)
                if vert_count >= max_total_verts:
                    break

    def _update_wireframe_overlay(
        self, yaw_off=None, pitch_off=None, roll_off=None, fscale=None,
        x_off=None, y_off=None, geoid_off=None
    ):
        if not self.engine:
            return
        self._ensure_wireframe_items()

        yo = self.spin_man_yaw.value() if yaw_off is None else float(yaw_off)
        po = self.spin_man_pitch.value() if pitch_off is None else float(pitch_off)
        ro = self.spin_man_roll.value() if roll_off is None else float(roll_off)
        fs = (self.spin_man_focal.value() / 100.0) if fscale is None else float(fscale)
        drone_pos = self._get_effective_drone_pos(x_off=x_off, y_off=y_off, geoid_off=geoid_off)

        from ..core.math_engine import MathEngine
        import cv2

        R_c2w = MathEngine.build_R_c2w(
            self.engine.grid_yaw_raw + yo,
            float(self.engine.tel['pitch']) + po,
            float(self.engine.tel['roll']) + ro,
        )
        R_w2c = R_c2w.T
        K = self.engine.base_camera_matrix.copy()
        K[0, 0] *= fs
        K[1, 1] *= fs
        fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
        has_dist = bool(np.any(np.abs(self.engine.dist_coeffs) > 1e-7))
        z_vec = np.zeros((3, 1), dtype=np.float64)

        img_w = int(self.engine.tel.get('img_w', 5280))
        img_h = int(self.engine.tel.get('img_h', 3956))
        max_dist_m = max(500.0, float(self.global_settings.get('max_dist_km', 4.0)) * 1000.0)
        wf_planes = MathEngine.compute_frustum_bounds(
            K, self.engine.dist_coeffs, img_w, img_h, margin_px=48.0, z_near=1.0, z_far=max_dist_m
        )

        path = QPainterPath()
        inv_2r = 1.0 / (2.0 * MathEngine.EARTH_R_EFF)
        for w_line in self._wireframe_world_lines:
            rel = w_line.copy() - drone_pos[None, :]
            rel[:, 2] -= (rel[:, 0] ** 2 + rel[:, 1] ** 2) * inv_2r
            cam_pts = (R_w2c @ rel.T).T
            if np.max(cam_pts[:, 2]) < 1.0:
                continue

            sublines = clip_polyline_to_frustum(cam_pts.tolist(), wf_planes)
            for sub in sublines:
                sub_arr = np.asarray(sub, dtype=np.float64)
                if has_dist:
                    proj, _ = cv2.projectPoints(sub_arr.reshape(-1, 1, 3), z_vec, z_vec, K, self.engine.dist_coeffs)
                    uv = proj.reshape(-1, 2)
                else:
                    inv_z = 1.0 / sub_arr[:, 2]
                    u_arr = cx + fx * sub_arr[:, 0] * inv_z
                    v_arr = cy + fy * sub_arr[:, 1] * inv_z
                    uv = np.column_stack([u_arr, v_arr])

                started = False
                for k in range(len(uv)):
                    ux, vy = float(uv[k, 0]), float(uv[k, 1])
                    if -500.0 <= ux <= img_w + 500.0 and -500.0 <= vy <= img_h + 500.0:
                        if not started:
                            path.moveTo(ux, vy)
                            started = True
                        else:
                            path.lineTo(ux, vy)
                    else:
                        started = False

        self._wireframe_item_proj.setPath(path)
        self._set_wireframe_visible(self.current_tool == 'drag_align' and self._wf_visible)

    def on_focal_wheel_adjusted(self, factor):
        if self.current_tool != 'drag_align' or not self.engine:
            return
        new_pct = max(50.0, min(250.0, self.spin_man_focal.value() * float(factor)))
        self.spin_man_focal.setValue(new_pct)
        self._mark_wireframe_dirty()
        self._sync_drag_align_dialog(include_fpitch=False)
        self._update_wireframe_overlay()
        self.hint.setText(
            f"✥ Focal Scale: {new_pct:.2f}% | Pitch {self.spin_man_pitch.value():+.2f}° | Yaw {self.spin_man_yaw.value():+.2f}° | Roll {self.spin_man_roll.value():+.2f}°"
        )

    def on_scene_pressed(self, u, v, button):
        if self.current_tool == 'pan': return
            
        if self.current_tool == 'remove' and button == LeftButton:
            item = self.proj_scene.itemAt(u, v, QTransform())
            if isinstance(item, InteractiveLabelItem):
                item.hide_label()
                return
            if item and item in self._persistent_graphics:
                self.remove_clicked_feature(item)
            return
            
        if self.current_tool == 'place_label' and button == LeftButton:
            layer_id = self.combo_proj_layer.currentData()
            if not layer_id or layer_id not in self._projected_label_data: return
            
            closest_ld = None
            min_dist = float('inf')
            
            for ld in self._projected_label_data[layer_id]:
                dist = math.hypot(ld['anchor_x'] - u, ld['anchor_y'] - v)
                if dist < min_dist:
                    min_dist = dist
                    closest_ld = ld
                    
            if closest_ld and min_dist < 1000:
                feature_key = f"{layer_id}_{closest_ld['fid']}"
                cx_off = u - closest_ld['anchor_x']
                cy_off = v - closest_ld['anchor_y']
                self.save_label_override(feature_key, cx_off=cx_off, cy_off=cy_off, hidden=False)
                self.render_projected_labels()
            return

        if self.current_tool == 'horizon' and button == LeftButton:
            if not self.engine:
                return
            self.horizon_pts.append((u, v))
            if len(self.horizon_pts) == 1:
                dot = QGraphicsEllipseItem(u - 8, v - 8, 16, 16)
                dot.setBrush(QBrush(QColor(77, 208, 225)))
                dot.setPen(QPen(QColor(255, 255, 255), 2))
                dot.setZValue(110)
                ln = QGraphicsLineItem(u, v, u, v)
                ln.setPen(QPen(QColor(77, 208, 225), 4, DashLine))
                ln.setZValue(109)
                self.proj_scene.addItem(dot)
                self.proj_scene.addItem(ln)
                self.horizon_graphics.extend([dot, ln])
                self.hint.setText(tr("hint_horizon_2"))
            elif len(self.horizon_pts) >= 2:
                (u1, v1), (u2, v2) = self.horizon_pts[0], self.horizon_pts[1]
                self._clear_horizon_graphics()
                res = self.engine.calibrate_horizon(u1, v1, u2, v2)
                if res is None:
                    QMessageBox.warning(self, "Horizon Alignment", "Click two horizon points spaced further apart.")
                    return
                dpitch, droll = res
                self.spin_man_pitch.setValue(dpitch)
                self.spin_man_roll.setValue(droll)
                self.apply_manual_offsets()
                self.hint.setText(f"🌅 Horizon Locked! Pitch Offset: {dpitch:+.2f}°, Roll Offset: {droll:+.2f}°")
            return

        if self.current_tool == 'drag_align':
            if not self.engine:
                return
            if not self._wireframe_world_lines:
                self._build_wireframe_cache()
            mods = getattr(self.proj_view, 'last_modifiers', 0)
            if button == RightButton or bool(mods & ShiftModifier):
                drag_mode = 'roll'
            else:
                drag_mode = self._drag_align_mode or 'pan_rot'
            if button in (LeftButton, RightButton):
                if drag_mode == 'forward_pitch':
                    if self._fpitch_anchor is None:
                        self._fpitch_anchor = self._snapshot_fpitch_anchor()
                xy_anchor = self._snapshot_fpitch_anchor() if drag_mode == 'xy_shift' else None
                self._drag_align_start = {
                    'u': u,
                    'v': v,
                    'yaw': self.spin_man_yaw.value(),
                    'pitch': self.spin_man_pitch.value(),
                    'roll': self.spin_man_roll.value(),
                    'focal': self.spin_man_focal.value(),
                    'x_off': self.spin_man_x.value(),
                    'y_off': self.spin_man_y.value(),
                    'geoid': self.spin_man_geoid.value(),
                    'fpitch_start': self._curr_fpitch_deg,
                    'xy_anchor': xy_anchor,
                    'mode': drag_mode,
                }
            return

        if self.current_tool == 'tie_point' and button == LeftButton:
            if not self.engine: return
            self.pending_u = u
            self.pending_v = v
            self.pending_z = None
            
            if self.map_canvas:
                self.hide()
                self.prev_map_tool = self.map_canvas.mapTool()
                self.map_canvas.setMapTool(self.map_tool)
                if self.iface and hasattr(self.iface, 'messageBar') and self.iface.messageBar():
                    self.iface.messageBar().pushMessage("Georeferencer", "Click on the QGIS Map Canvas to match this point.", Qgis.Info, 5)
            return
            
        if not self.engine or button != LeftButton: return
            
        world_pt = self.engine.pixel_to_world(u, v, self.fallback_z, dem_sampler=self.dem_sampler)
        if not world_pt: return
        world_z = self.get_world_z(world_pt.x(), world_pt.y())

        if self.current_tool == 'pin':
            self.pin_start_u = u
            self.pin_start_v = v
            self.temp_points = [{'u': u, 'v': v, 'x': world_pt.x(), 'y': world_pt.y(), 'z': world_z}]
            
        elif self.current_tool in ['line', 'polygon']:
            self.temp_points.append({'u': u, 'v': v, 'x': world_pt.x(), 'y': world_pt.y(), 'z': world_z})
            self.redraw_temp_graphics()

    def on_map_clicked(self, point, button):
        if self.prev_map_tool:
            self.map_canvas.setMapTool(self.prev_map_tool)
        self.show()
        
        if self.pending_u is None or self.pending_v is None:
            return

        # Reproject clicked map coordinate from Map Canvas CRS into EPSG:3301
        pt_3301 = QgsPointXY(point.x(), point.y())
        if self.map_canvas:
            canvas_crs = self.map_canvas.mapSettings().destinationCrs()
            crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
            if canvas_crs.isValid() and canvas_crs != crs_3301:
                try:
                    ct = QgsCoordinateTransform(canvas_crs, crs_3301, QgsProject.instance().transformContext())
                    pt_3301 = ct.transform(pt_3301)
                except Exception:
                    pass

        # Sample true ground/surface elevation at the clicked map coordinate!
        true_z = self.get_world_z(pt_3301.x(), pt_3301.y())
        
        tp = {
            'u': self.pending_u,
            'v': self.pending_v,
            'x': pt_3301.x(),
            'y': pt_3301.y(),
            'z': true_z,
        }
        self.tie_points.append(tp)
        self.update_tie_point_table()
        self.draw_tie_points()
        
        self.pending_u = None
        self.pending_v = None

    def update_tie_point_table(self):
        self.tbl_ties.setRowCount(len(self.tie_points))
        for row, tp in enumerate(self.tie_points):
            self.tbl_ties.setItem(row, 0, QTableWidgetItem(f"{tp['u']:.0f}"))
            self.tbl_ties.setItem(row, 1, QTableWidgetItem(f"{tp['v']:.0f}"))
            self.tbl_ties.setItem(row, 2, QTableWidgetItem(f"{tp['x']:.2f}"))
            self.tbl_ties.setItem(row, 3, QTableWidgetItem(f"{tp['y']:.2f}"))
            
        self.btn_calc_xy.setEnabled(len(self.tie_points) >= 1)
        self.btn_calc_imu.setEnabled(len(self.tie_points) >= 1) 
        self.btn_calc_3d.setEnabled(len(self.tie_points) >= 4)

    def draw_tie_points(self):
        for item in self.tie_point_graphics:
            try:
                if item.scene() == self.proj_scene:
                    self.proj_scene.removeItem(item)
            except RuntimeError:
                pass 
        self.tie_point_graphics.clear()
        
        if hasattr(self, 'map_tie_markers') and self.map_canvas:
            for marker in self.map_tie_markers:
                self.map_canvas.scene().removeItem(marker)
        self.map_tie_markers = []
        
        crosshair_size = 40
        for i, tp in enumerate(self.tie_points):
            l1 = QGraphicsLineItem(tp['u']-crosshair_size, tp['v'], tp['u']+crosshair_size, tp['v'])
            l2 = QGraphicsLineItem(tp['u'], tp['v']-crosshair_size, tp['u'], tp['v']+crosshair_size)
            l1.setPen(QPen(QColor(0, 255, 0), 4))
            l2.setPen(QPen(QColor(0, 255, 0), 4))
            l1.setZValue(108)
            l2.setZValue(108)
            
            txt = QGraphicsTextItem(f"TP {i+1}")
            txt.setDefaultTextColor(QColor(0, 255, 0))
            fnt = QFont()
            fnt.setPointSize(20)
            fnt.setBold(True)
            txt.setFont(fnt)
            txt.setPos(tp['u']+5, tp['v']+5)
            txt.setZValue(109)
            
            self.proj_scene.addItem(l1)
            self.proj_scene.addItem(l2)
            self.proj_scene.addItem(txt)
            self.tie_point_graphics.extend([l1, l2, txt])
                
            if self.map_canvas:
                from ..compat_drone import QgsVertexMarker
                marker_pt = QgsPointXY(tp['x'], tp['y'])
                canvas_crs = self.map_canvas.mapSettings().destinationCrs()
                crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
                if canvas_crs.isValid() and canvas_crs != crs_3301:
                    try:
                        ct_back = QgsCoordinateTransform(crs_3301, canvas_crs, QgsProject.instance().transformContext())
                        marker_pt = ct_back.transform(marker_pt)
                    except Exception:
                        pass
                marker = QgsVertexMarker(self.map_canvas)
                marker.setCenter(marker_pt)
                marker.setColor(QColor(0, 255, 0))
                marker.setIconSize(15)
                marker.setIconType(QgsVertexMarker.ICON_CROSS)
                marker.setPenWidth(3)
                self.map_tie_markers.append(marker)

    def clear_tie_points(self):
        self.tie_points.clear()
        self.update_tie_point_table()
        self.draw_tie_points()

    def calculate_xy_alignment(self):
        if not self.engine or len(self.tie_points) == 0: return
        
        result = self.engine.calibrate_xy(self.tie_points)
        if not result:
            QMessageBox.warning(self, "Calibration Failed", "Could not calculate XY shift.")
            return
            
        dx, dy = result
        
        self.spin_man_x.setValue(self.spin_man_x.value() - dx)
        self.spin_man_y.setValue(self.spin_man_y.value() - dy)
        self.apply_manual_offsets()
        
        QMessageBox.information(self, "Calibration Success", f"XY Shift Applied:\ndx: {dx:.2f}m\ndy: {dy:.2f}m")
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"XY Calibration Success: dx={dx:.2f}, dy={dy:.2f}", "MavicProjector", Qgis.Info)

    def calculate_imu_alignment(self):
        if not self.engine or len(self.tie_points) == 0: return
        
        solve_roll = len(self.tie_points) >= 2
        solve_focal = self.chk_refine_focal.isChecked() and len(self.tie_points) >= 3
        result = self.engine.calibrate_imu(self.tie_points, solve_roll=solve_roll, solve_focal=solve_focal)
        if not result:
            QMessageBox.warning(self, "Calibration Failed", "Could not calculate IMU alignment.")
            return
            
        new_pitch_offset = result['dpitch']
        new_yaw_offset = result['dyaw']
        new_roll_offset = result['droll']
        new_fscale = result['focal_scale']
        rms_px = result['rms_px']
        
        self.spin_man_pitch.setValue(new_pitch_offset)
        self.spin_man_yaw.setValue(new_yaw_offset)
        self.spin_man_roll.setValue(new_roll_offset)
        if solve_focal:
            self.spin_man_focal.setValue(new_fscale * 100.0)
        self.apply_manual_offsets()
        
        focal_msg = f"\nFocal Scale: {new_fscale * 100.0:.2f}%" if solve_focal else ""
        QMessageBox.information(self, "IMU Calibration Success", 
            f"Locked RTK XYZ and solved continuous camera orientation ({len(self.tie_points)} tie pt(s)):\n\n"
            f"Pitch Offset: {new_pitch_offset:+.2f}°\n"
            f"Yaw (Crab) Offset: {new_yaw_offset:+.2f}°\n"
            f"Roll Offset: {new_roll_offset:+.2f}°{focal_msg}\n\n"
            f"Residual Error: {rms_px:.1f} px RMS")
        
        QgsMessageLog.logMessage(
            f"IMU Calibration Success: dPitch={new_pitch_offset:.2f}, dYaw={new_yaw_offset:.2f}, dRoll={new_roll_offset:.2f}, RMS={rms_px:.1f}px",
            "MavicProjector", Qgis.Info
        )

    def calculate_3d_alignment(self):
        if not self.engine or len(self.tie_points) < 4: return
        
        result = self.engine.calibrate_3d(self.tie_points)
        if not result:
            QMessageBox.warning(self, "Calibration Failed", "Could not converge on a 3D solution.")
            return
            
        dx = result['dx']
        dy = result['dy']
        dz = result['dz']
        new_pitch_offset = result['dpitch']
        new_yaw_offset = result['dyaw']
        new_roll_offset = result['droll']
        rms_px = result['rms_px']
        
        current_alt = self.engine.drone_pos[2]
        if current_alt + dz < 10.0 or abs(dz) > (current_alt * 0.25):
            reply = QMessageBox.question(self, "Planar Tie-Point Depth Ambiguity", 
                f"The 6-DOF solver wants to shift drone altitude by {dz:+.1f}m.\n\n"
                "When tie points lie on nearly flat ground, camera height and pitch trade off against each other. If your photo has RTK GPS, 'Calibrate IMU' is strongly recommended instead.\n\n"
                "Apply full 6-DOF XYZ + Rotation shift anyway?", 
                MsgYes | MsgNo, MsgNo)
            if reply == MsgNo:
                return

        self.spin_man_x.setValue(self.spin_man_x.value() - dx)
        self.spin_man_y.setValue(self.spin_man_y.value() - dy)
        self.chk_man_auto_geoid.setChecked(False)
        self.spin_man_geoid.setEnabled(True)
        self.spin_man_geoid.setValue(self.spin_man_geoid.value() + dz)
        self.spin_man_pitch.setValue(new_pitch_offset)
        self.spin_man_yaw.setValue(new_yaw_offset)
        self.spin_man_roll.setValue(new_roll_offset)
        self.apply_manual_offsets()
        
        msg = (
            f"Full 3D Pose Applied:\n"
            f"dx: {dx:+.2f}m | dy: {dy:+.2f}m | dz: {dz:+.2f}m\n"
            f"Pitch Offset: {new_pitch_offset:+.2f}°\n"
            f"Yaw Offset: {new_yaw_offset:+.2f}°\n"
            f"Roll Offset: {new_roll_offset:+.2f}°\n"
            f"Residual Error: {rms_px:.1f} px RMS"
        )
        QMessageBox.information(self, "Calibration Success", msg)
        QgsMessageLog.logMessage(f"3D Calibration Success: dx={dx:.2f}, dy={dy:.2f}, dz={dz:.2f}, RMS={rms_px:.1f}px", "MavicProjector", Qgis.Info)

    def on_scene_moved(self, u, v, buttons):
        if self.current_tool == 'pan': return
        if self.current_tool == 'remove': return
        if self.current_tool == 'edit': return
        if self.current_tool == 'place_label': return

        if self.current_tool == 'horizon' and len(self.horizon_pts) == 1:
            u1, v1 = self.horizon_pts[0]
            for item in self.horizon_graphics:
                if isinstance(item, QGraphicsLineItem):
                    item.setLine(u1, v1, u, v)
            return

        if self.current_tool == 'drag_align' and self._drag_align_start is not None and self.engine:
            self._mark_wireframe_dirty()
            st = self._drag_align_start
            fx = max(200.0, float(self.engine.camera_matrix[0, 0]))
            fy = max(200.0, float(self.engine.camera_matrix[1, 1]))
            cx = float(self.engine.camera_matrix[0, 2])
            cy = float(self.engine.camera_matrix[1, 2])
            mode = st['mode']

            if mode == 'roll':
                a0 = math.atan2(st['v'] - cy, st['u'] - cx)
                a1 = math.atan2(v - cy, u - cx)
                da = math.degrees(a1 - a0)
                if da > 180.0: da -= 360.0
                elif da < -180.0: da += 360.0
                new_roll = max(-45.0, min(45.0, st['roll'] - da))
                self.spin_man_roll.blockSignals(True)
                self.spin_man_roll.setValue(new_roll)
                self.spin_man_roll.blockSignals(False)
                self._update_wireframe_overlay(roll_off=new_roll)
                self._sync_drag_align_dialog(include_fpitch=False)

            elif mode == 'forward_pitch':
                if self._fpitch_anchor is not None:
                    dv = v - st['v']
                    # Drag DOWN -> steeper (+delta), drag UP -> flatter/more oblique (-delta)
                    delta_fpitch = max(-30.0, min(30.0, st['fpitch_start'] + (dv / max(400.0, fy)) * 35.0))
                    new_pitch, new_x, new_y, new_geoid, actual_deg = self.compute_fpitch_pose(
                        self._fpitch_anchor, delta_fpitch
                    )
                    self._curr_fpitch_deg = actual_deg
                    for sb in (self.spin_man_pitch, self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid):
                        sb.blockSignals(True)
                    try:
                        self.spin_man_pitch.setValue(new_pitch)
                        self.spin_man_x.setValue(new_x)
                        self.spin_man_y.setValue(new_y)
                        self.chk_man_auto_geoid.setChecked(False)
                        self.spin_man_geoid.setEnabled(True)
                        self.spin_man_geoid.setValue(new_geoid)
                    finally:
                        for sb in (self.spin_man_pitch, self.spin_man_x, self.spin_man_y, self.spin_man_geoid, self.chk_man_auto_geoid):
                            sb.blockSignals(False)
                    self._update_wireframe_overlay()
                    self._sync_drag_align_dialog(include_fpitch=True)

            elif mode == 'focal':
                dv = v - st['v']
                new_focal = max(50.0, min(250.0, st['focal'] * (1.0 - dv / 1800.0)))
                self.spin_man_focal.blockSignals(True)
                self.spin_man_focal.setValue(new_focal)
                self.spin_man_focal.blockSignals(False)
                self._update_wireframe_overlay(fscale=new_focal / 100.0)
                self._sync_drag_align_dialog(include_fpitch=False)

            elif mode == 'xy_shift':
                du = u - st['u']
                dv = v - st['v']
                roll_rad = math.radians(float(self.engine.tel['roll']) + st['roll'])
                cr, sr = math.cos(roll_rad), math.sin(roll_rad)
                du_r = du * cr + dv * sr
                dv_r = -du * sr + dv * cr

                anc = st.get('xy_anchor')
                R_slant = anc['R_slant'] if anc else max(50.0, abs(float(self.engine.drone_pos[2])))
                theta0 = anc['theta0'] if anc else math.radians(30.0)
                yaw_rad = math.radians(self.engine.grid_yaw_raw + st['yaw'])
                f_horiz = np.array([math.sin(yaw_rad), math.cos(yaw_rad)], dtype=np.float64)
                r_horiz = np.array([math.cos(yaw_rad), -math.sin(yaw_rad)], dtype=np.float64)

                m_per_px = R_slant / fx
                right_m = du_r * m_per_px
                fwd_m = dv_r * m_per_px / max(0.2, abs(math.sin(theta0)))
                dC_xy = -right_m * r_horiz + fwd_m * f_horiz
                new_x = max(-500.0, min(500.0, st['x_off'] - float(dC_xy[0])))
                new_y = max(-500.0, min(500.0, st['y_off'] - float(dC_xy[1])))

                self.spin_man_x.blockSignals(True)
                self.spin_man_y.blockSignals(True)
                self.spin_man_x.setValue(new_x)
                self.spin_man_y.setValue(new_y)
                self.spin_man_x.blockSignals(False)
                self.spin_man_y.blockSignals(False)
                self._update_wireframe_overlay(x_off=new_x, y_off=new_y)
                self._sync_drag_align_dialog(include_fpitch=False)

            else:
                du = u - st['u']
                dv = v - st['v']
                roll_rad = math.radians(float(self.engine.tel['roll']) + st['roll'])
                cr, sr = math.cos(roll_rad), math.sin(roll_rad)
                du_r = du * cr + dv * sr
                dv_r = -du * sr + dv * cr
                pitch_eff = float(self.engine.tel['pitch']) + st['pitch']
                cos_p = max(0.25, abs(math.cos(math.radians(pitch_eff))))

                new_yaw = ((st['yaw'] - math.degrees(du_r / fx) / cos_p + 180.0) % 360.0) - 180.0
                new_pitch = max(-45.0, min(45.0, st['pitch'] + math.degrees(dv_r / fy)))

                self.spin_man_yaw.blockSignals(True)
                self.spin_man_pitch.blockSignals(True)
                self.spin_man_yaw.setValue(new_yaw)
                self.spin_man_pitch.setValue(new_pitch)
                self.spin_man_yaw.blockSignals(False)
                self.spin_man_pitch.blockSignals(False)
                self._update_wireframe_overlay(yaw_off=new_yaw, pitch_off=new_pitch)
                self._sync_drag_align_dialog(include_fpitch=False)

            self.hint.setText(
                f"✥ Pitch {self.spin_man_pitch.value():+.2f}° | Yaw {self.spin_man_yaw.value():+.2f}° | Roll {self.spin_man_roll.value():+.2f}° | Focal {self.spin_man_focal.value():.1f}% | Z {self.spin_man_geoid.value():+.1f}m"
            )
            return
        
        if self.current_tool == 'pin' and self.pin_start_u is not None:
            self.redraw_temp_graphics(cursor_u=u, cursor_v=v)
            
        elif self.current_tool in ['line', 'polygon'] and len(self.temp_points) > 0:
            self.redraw_temp_graphics(cursor_u=u, cursor_v=v)

    def on_scene_released(self, u, v, button):
        if self.current_tool == 'pan': return
        if self.current_tool == 'tie_point': return
        if self.current_tool == 'horizon': return
        if self.current_tool == 'drag_align':
            prev_mode = self._drag_align_start.get('mode') if isinstance(self._drag_align_start, dict) else None
            self._drag_align_start = None
            if prev_mode and prev_mode != 'forward_pitch':
                self._curr_fpitch_deg = 0.0
                self._fpitch_anchor = self._snapshot_fpitch_anchor()
                self._sync_drag_align_dialog(include_fpitch=True)
            return
        if self.current_tool == 'remove': return
        if self.current_tool == 'edit': return
        if self.current_tool == 'place_label': return
        
        if button == RightButton:
            if self.current_tool == 'line' and len(self.temp_points) >= 2:
                self.save_line_feature()
            elif self.current_tool == 'polygon' and len(self.temp_points) >= 3:
                self.save_polygon_feature()
            self.clear_temp_drawing()
            
        elif button == LeftButton and self.current_tool == 'pin' and self.pin_start_u is not None:
            self.save_pin_feature(u, v)
            self.clear_temp_drawing()

    def get_dynamic_scale(self, v, use_persp):
        return max(0.4, min(3.0, 0.4 + (v / 3000.0) * 2.0)) if use_persp else 1.0

    def redraw_temp_graphics(self, cursor_u=None, cursor_v=None):
        for item in self.temp_graphics:
            self.proj_scene.removeItem(item)
        self.temp_graphics.clear()

        ui = self.sym_ui[self.current_tool]
        curr_col = ui['color']
        base_size = ui['spin_size'].value()
        use_persp = ui['chk_persp'].isChecked()
        
        if self.current_tool == 'pin' and self.pin_start_u is not None and cursor_u is not None:
            scale = self.get_dynamic_scale(self.pin_start_v, use_persp)
            pen = QPen(curr_col, max(2, (base_size/1.5) * scale), SolidLine, RoundCap)
            
            line = QGraphicsLineItem(self.pin_start_u, self.pin_start_v, cursor_u, cursor_v)
            line.setPen(pen)
            self.proj_scene.addItem(line)
            self.temp_graphics.append(line)
            
            screen_angle = math.atan2(cursor_v - self.pin_start_v, cursor_u - self.pin_start_u)
            arr_size = (base_size * 3) * scale
            p1 = QPointF(cursor_u, cursor_v)
            p2 = QPointF(cursor_u - arr_size * math.cos(screen_angle - math.pi/6), cursor_v - arr_size * math.sin(screen_angle - math.pi/6))
            p3 = QPointF(cursor_u - arr_size * math.cos(screen_angle + math.pi/6), cursor_v - arr_size * math.sin(screen_angle + math.pi/6))
            arrowhead = QGraphicsPolygonItem(QPolygonF([p1, p2, p3]))
            arrowhead.setBrush(QBrush(curr_col))
            arrowhead.setPen(QPen(QColor(0,0,0,0)))
            self.proj_scene.addItem(arrowhead)
            self.temp_graphics.append(arrowhead)
            
        elif self.current_tool in ['line', 'polygon'] and self.temp_points:
            pts = [(p['u'], p['v']) for p in self.temp_points]
            world_pts = [(p['x'], p['y']) for p in self.temp_points]
            
            if cursor_u is not None:
                pts.append((cursor_u, cursor_v))
                
                live_world_pt = self.engine.pixel_to_world(cursor_u, cursor_v, self.fallback_z, dem_sampler=self.dem_sampler)
                if live_world_pt:
                    world_pts.append((live_world_pt.x(), live_world_pt.y()))
                
            total_length_m = 0.0
            for i in range(len(pts) - 1):
                scale = self.get_dynamic_scale(pts[i][1], use_persp)
                pen = QPen(curr_col, base_size * scale, SolidLine, RoundCap)
                line = QGraphicsLineItem(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])
                line.setPen(pen)
                self.proj_scene.addItem(line)
                self.temp_graphics.append(line)
                
                if i < len(world_pts) - 1:
                    dx = world_pts[i+1][0] - world_pts[i][0]
                    dy = world_pts[i+1][1] - world_pts[i][1]
                    total_length_m += math.hypot(dx, dy)
                
            if self.current_tool == 'polygon' and len(pts) >= 3:
                scale = self.get_dynamic_scale(pts[-1][1], use_persp)
                pen = QPen(curr_col, base_size * scale, DashLine, RoundCap)
                line = QGraphicsLineItem(pts[-1][0], pts[-1][1], pts[0][0], pts[0][1])
                line.setPen(pen)
                self.proj_scene.addItem(line)
                self.temp_graphics.append(line)
                
            for p in pts:
                scale = self.get_dynamic_scale(p[1], use_persp)
                rad = max(4, base_size) * scale
                ellipse = QGraphicsEllipseItem(p[0] - rad/2, p[1] - rad/2, rad, rad)
                ellipse.setBrush(QBrush(curr_col))
                self.proj_scene.addItem(ellipse)
                self.temp_graphics.append(ellipse)

            if self.map_rubberband and world_pts:
                geom_type = QgsWkbTypes.PolygonGeometry if self.current_tool == 'polygon' else QgsWkbTypes.LineGeometry
                self.map_rubberband.reset(geom_type)
                for wp in world_pts:
                    self.map_rubberband.addPoint(QgsPointXY(wp[0], wp[1]))

            if cursor_u is not None and cursor_v is not None and len(world_pts) > 1:
                display_text = f"{total_length_m:.1f} m"
                
                if self.current_tool == 'polygon' and len(world_pts) >= 3:
                    area = 0.0
                    for i in range(len(world_pts)):
                        j = (i + 1) % len(world_pts)
                        area += world_pts[i][0] * world_pts[j][1]
                        area -= world_pts[j][0] * world_pts[i][1]
                    area = abs(area) / 2.0
                    
                    if area > 10000: display_text = f"{area / 10000:.2f} ha\nPeri: {total_length_m:.1f} m"
                    else: display_text = f"{area:.1f} m²\nPeri: {total_length_m:.1f} m"

                meas_text = QGraphicsTextItem(display_text)
                meas_text.setDefaultTextColor(curr_col)
                fnt = QFont()
                fnt.setPointSize(int(14 * self.get_dynamic_scale(cursor_v, use_persp)))
                fnt.setBold(True)
                meas_text.setFont(fnt)
                
                shadow = QGraphicsTextItem(display_text)
                shadow.setFont(fnt)
                shadow.setDefaultTextColor(QColor(0,0,0, 200))
                
                meas_text.setPos(cursor_u + 15, cursor_v + 15)
                shadow.setPos(cursor_u + 17, cursor_v + 17)
                
                self.proj_scene.addItem(shadow)
                self.proj_scene.addItem(meas_text)
                self.temp_graphics.extend([shadow, meas_text])

    def clear_temp_drawing(self):
        for item in self.temp_graphics:
            self.proj_scene.removeItem(item)
        self.temp_graphics.clear()
        self.temp_points.clear()
        self.pin_start_u = None
        self.pin_start_v = None
        
        if self.map_rubberband:
            self.map_rubberband.reset()

    def save_pin_feature(self, end_u, end_v):
        self.ensure_layers_valid()
        pt = self.temp_points[0]
        world_angle = None
        screen_dist = math.hypot(end_u - pt['u'], end_v - pt['v'])
        
        if screen_dist > 5:
            world_pt2 = self.engine.pixel_to_world(end_u, end_v, pt['z'])
            if world_pt2:
                dx_w = world_pt2.x() - pt['x']
                dy_w = world_pt2.y() - pt['y']
                world_angle = (90.0 - math.degrees(math.atan2(dy_w, dx_w))) % 360.0

        ui = self.sym_ui['pin']
        color_hex = ui['color'].name()
        
        f = QgsFeature(self.pin_layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt['x'], pt['y'])))
        f.setAttribute("id", self.current_ids['pin'])
        f.setAttribute("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.setAttribute("note", "")
        f.setAttribute("photo", self.photo_name)
        f.setAttribute("angle", world_angle)
        f.setAttribute("color", color_hex)
        f.setAttribute("size", ui['spin_size'].value())
        f.setAttribute("persp", ui['chk_persp'].isChecked())
        f.setAttribute("coord_xy", f"{pt['x']:.2f}, {pt['y']:.2f}")
        f.setAttribute("measurement", f"X: {pt['x']:.1f}\nY: {pt['y']:.1f}")

        self._is_plugin_editing = True
        was_editable = self.pin_layer.isEditable()
        if not was_editable: self.pin_layer.startEditing()
        self.pin_layer.addFeature(f)
        if not was_editable: self.pin_layer.commitChanges()
        self._is_plugin_editing = False
        
        self.ensure_color_category(self.pin_layer, 'Point', color_hex)
        self.finalize_feature_save(self.pin_layer, 'pin', f)

    def save_line_feature(self):
        self.ensure_layers_valid()
        qgis_pts = [QgsPointXY(p['x'], p['y']) for p in self.temp_points]
        geom = QgsGeometry.fromPolylineXY(qgis_pts)
        
        length_m = geom.length()

        ui = self.sym_ui['line']
        color_hex = ui['color'].name()
        
        f = QgsFeature(self.line_layer.fields())
        f.setGeometry(geom)
        f.setAttribute("id", self.current_ids['line'])
        f.setAttribute("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.setAttribute("photo", self.photo_name)
        f.setAttribute("color", color_hex)
        f.setAttribute("size", ui['spin_size'].value())
        f.setAttribute("persp", ui['chk_persp'].isChecked())
        f.setAttribute("length_m", round(length_m, 2))
        f.setAttribute("measurement", f"{length_m:.1f} m")

        self._is_plugin_editing = True
        was_editable = self.line_layer.isEditable()
        if not was_editable: self.line_layer.startEditing()
        self.line_layer.addFeature(f)
        if not was_editable: self.line_layer.commitChanges()
        self._is_plugin_editing = False
        
        self.ensure_color_category(self.line_layer, 'LineString', color_hex)
        self.finalize_feature_save(self.line_layer, 'line', f)

    def save_polygon_feature(self):
        self.ensure_layers_valid()
        qgis_pts = [QgsPointXY(p['x'], p['y']) for p in self.temp_points]
        qgis_pts.append(qgis_pts[0]) 
        geom = QgsGeometry.fromPolygonXY([qgis_pts])
        
        area_m2 = geom.area()
        perimeter_m = geom.length()

        ui = self.sym_ui['polygon']
        color_hex = ui['color'].name()
        
        f = QgsFeature(self.poly_layer.fields())
        f.setGeometry(geom)
        f.setAttribute("id", self.current_ids['polygon'])
        f.setAttribute("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.setAttribute("photo", self.photo_name)
        f.setAttribute("color", color_hex)
        f.setAttribute("size", ui['spin_size'].value())
        f.setAttribute("persp", ui['chk_persp'].isChecked())
        f.setAttribute("area_m2", round(area_m2, 2))
        f.setAttribute("length_m", round(perimeter_m, 2))
        
        if area_m2 > 10000:
            f.setAttribute("measurement", f"{area_m2 / 10000:.2f} ha\nPeri: {perimeter_m:.1f} m")
        else:
            f.setAttribute("measurement", f"{area_m2:.1f} m²\nPeri: {perimeter_m:.1f} m")

        self._is_plugin_editing = True
        was_editable = self.poly_layer.isEditable()
        if not was_editable: self.poly_layer.startEditing()
        self.poly_layer.addFeature(f)
        if not was_editable: self.poly_layer.commitChanges()
        self._is_plugin_editing = False
        
        self.ensure_color_category(self.poly_layer, 'Polygon', color_hex)
        self.finalize_feature_save(self.poly_layer, 'polygon', f)

    def finalize_feature_save(self, layer, type_key, f):
        target_id = f["id"]
        
        real_fid = None
        for feat in layer.getFeatures():
            if feat["id"] == target_id:
                real_fid = feat.id()
                break
                
        new_fid = real_fid if real_fid is not None else f.id()
        
        self.active_qgis_layer = layer
        self.active_qgis_fid = new_fid
        self.lbl_detail_title.setText(f"<b>Editing {type_key.title()} {target_id}</b>")
        
        self.txt_feature_note.blockSignals(True)
        self.txt_feature_note.setEnabled(True)
        self.txt_feature_note.setText("")
        self.txt_feature_note.blockSignals(False)
        self.txt_feature_note.setFocus()
        
        action = {'layer': layer, 'feature_obj': QgsFeature(f)}
        self.undo_stack.append(action)
        if len(self.undo_stack) > 20: self.undo_stack.pop(0) 
        self.redo_stack.clear()
        self.update_buttons()
        
        self.current_ids[type_key] += 1
            
        layer.triggerRepaint()
        self.load_existing_features()

    def load_existing_features(self):
        self.ensure_layers_valid()
        for item in self._persistent_graphics:
            try:
                self.proj_scene.removeItem(item)
            except RuntimeError:
                pass
        self._persistent_graphics.clear()
        
        self._populate_scene_with_features(self.proj_scene, self.engine, self.photo_name, self._persistent_graphics)

    def _populate_scene_with_features(self, target_scene, engine, target_photo_name, tracking_list=None):
        if not engine: return
        self.ensure_layers_valid()
        
        layers = [
            (self.pin_layer, 'pin'),
            (self.line_layer, 'line'),
            (self.poly_layer, 'polygon')
        ]
        
        show_all = self.chk_show_all.isChecked()
        
        for layer, l_type in layers:
            if not self.is_layer_valid(layer): continue
                
            for feat in layer.getFeatures():
                photo_val = feat["photo"]
                is_map_feat = not photo_val or str(photo_val).strip() == "" or str(photo_val).startswith("Map")
                
                if not show_all and not is_map_feat and photo_val != target_photo_name: 
                    continue
                
                geom = feat.geometry()
                if geom.isNull(): continue
                
                col_attr = feat["color"]
                col = QColor(col_attr) if col_attr else QColor(255, 255, 0)
                
                base_size = feat["size"] if feat["size"] else 6
                use_persp = feat["persp"] if feat["persp"] is not None else True
                
                graphics_to_add = []
                avg_u, avg_v, avg_z, valid_pts = 0, 0, 0, 0
                
                if l_type == 'pin':
                    pt = geom.asPoint()
                    ground_z = self.get_world_z(pt.x(), pt.y())
                    uv = engine.project_world_to_2d(pt.x(), pt.y(), ground_z)
                    if not uv: continue
                    u, v, z = uv
                    avg_u, avg_v, avg_z, valid_pts = u, v, ground_z, 1
                    
                    scale = self.get_dynamic_scale(v, use_persp)
                    
                    angle = feat["angle"]
                    if isinstance(angle, (int, float)):
                        ex = pt.x() + 15.0 * math.sin(math.radians(angle))
                        ey = pt.y() + 15.0 * math.cos(math.radians(angle))
                        end_ground_z = self.get_world_z(ex, ey)
                        end_uv = engine.project_world_to_2d(ex, ey, end_ground_z)
                        
                        if end_uv:
                            eu, ev, _ = end_uv
                            screen_angle = math.atan2(ev - v, eu - u)
                            
                            tick_len = max(20.0, 40.0 * scale)
                            arr_u = u + tick_len * math.cos(screen_angle)
                            arr_v = v + tick_len * math.sin(screen_angle)
                            
                            line = QGraphicsLineItem(u, v, arr_u, arr_v)
                            line.setPen(QPen(col, max(2, (base_size/1.5) * scale), SolidLine, RoundCap))
                            line.setZValue(50)
                            target_scene.addItem(line)
                            graphics_to_add.append(line)
                            
                            arr_size = (base_size * 3) * scale
                            p1 = QPointF(arr_u, arr_v)
                            p2 = QPointF(arr_u - arr_size * math.cos(screen_angle - math.pi/6), arr_v - arr_size * math.sin(screen_angle - math.pi/6))
                            p3 = QPointF(arr_u - arr_size * math.cos(screen_angle + math.pi/6), arr_v - arr_size * math.sin(screen_angle + math.pi/6))
                            arrowhead = QGraphicsPolygonItem(QPolygonF([p1, p2, p3]))
                            arrowhead.setBrush(QBrush(col))
                            arrowhead.setPen(QPen(QColor(0,0,0,0)))
                            arrowhead.setZValue(50)
                            target_scene.addItem(arrowhead)
                            graphics_to_add.append(arrowhead)

                    rad = (base_size * 4) * scale
                    ellipse = QGraphicsEllipseItem(u - rad/2, v - rad/2, rad, rad)
                    ellipse.setBrush(QBrush(col))
                    ellipse.setPen(QPen(QColor(255,255,255), max(1, (base_size/2) * scale))) 
                    ellipse.setZValue(50)
                    target_scene.addItem(ellipse)
                    graphics_to_add.append(ellipse)

                elif l_type in ['line', 'polygon']:
                    is_multi = geom.isMultipart()
                    if l_type == 'polygon':
                        parts = [ring for poly in geom.asMultiPolygon() for ring in poly] if is_multi else [geom.asPolygon()[0]]
                    else:
                        parts = geom.asMultiPolyline() if is_multi else [geom.asPolyline()]
                    
                    frustum_planes = engine.get_frustum_bounds(margin_px=48.0, z_near=1.0)
                    for ring in parts:
                        dem_src = self.dem_sampler if self.dem_sampler is not None else self.dem_layer
                        ring_3d = engine.get_3d_camera_points(
                            [QgsPointXY(pt.x(), pt.y()) for pt in ring], self.fallback_z, dem_src
                        )
                        if l_type == 'polygon':
                            clipped_3d = clip_ring_to_frustum(ring_3d, frustum_planes)
                            if clipped_3d:
                                proj_pts = engine.project_3d_to_2d_float(clipped_3d)
                                poly_pts = []
                                for p_res in proj_pts:
                                    if p_res is None:
                                        continue
                                    u, v, z = p_res
                                    poly_pts.append(QPointF(u, v))
                                    avg_u += u
                                    avg_v += v
                                    avg_z += z
                                    valid_pts += 1
                                if len(poly_pts) > 2:
                                    p_item = QGraphicsPolygonItem(QPolygonF(poly_pts))
                                    fill_col = QColor(col)
                                    fill_col.setAlpha(60)
                                    p_item.setBrush(QBrush(fill_col))
                                    scale = self.get_dynamic_scale(poly_pts[0].y(), use_persp)
                                    p_item.setPen(QPen(col, base_size * scale, SolidLine, RoundCap))
                                    p_item.setZValue(40)
                                    target_scene.addItem(p_item)
                                    graphics_to_add.append(p_item)
                        else:
                            vis_sublines = clip_polyline_to_frustum(ring_3d, frustum_planes)
                            for sub_3d in vis_sublines:
                                proj_pts = engine.project_3d_to_2d_float(sub_3d)
                                poly_pts = []
                                for p_res in proj_pts:
                                    if p_res is None:
                                        continue
                                    u, v, z = p_res
                                    poly_pts.append(QPointF(u, v))
                                    avg_u += u
                                    avg_v += v
                                    avg_z += z
                                    valid_pts += 1
                                for i in range(len(poly_pts) - 1):
                                    scale = self.get_dynamic_scale(poly_pts[i].y(), use_persp)
                                    l_item = QGraphicsLineItem(
                                        poly_pts[i].x(), poly_pts[i].y(),
                                        poly_pts[i + 1].x(), poly_pts[i + 1].y()
                                    )
                                    l_item.setPen(QPen(col, base_size * scale, SolidLine, RoundCap))
                                    l_item.setZValue(40)
                                    target_scene.addItem(l_item)
                                    graphics_to_add.append(l_item)

                if valid_pts > 0:
                    avg_u /= valid_pts
                    avg_v /= valid_pts
                    scale = self.get_dynamic_scale(avg_v, use_persp)
                    
                    field_name = self.sym_ui[l_type]['combo_label'].currentText()
                    lbl_val = feat.attribute(field_name)
                    lbl_item = QGraphicsTextItem(str(lbl_val) if lbl_val else "")
                    fnt = QFont()
                    fnt.setPointSize(int(36 * scale))
                    fnt.setBold(True)
                    lbl_item.setFont(fnt)
                    lbl_item.setDefaultTextColor(QColor("white"))
                    
                    shadow = QGraphicsTextItem(str(lbl_val) if lbl_val else "")
                    shadow.setFont(fnt)
                    shadow.setDefaultTextColor(QColor(0,0,0,150))
                    
                    br = lbl_item.boundingRect()
                    y_offset = avg_v - br.height() - (15 * scale)
                    shadow.setPos(avg_u - (br.width() / 2) + 3, y_offset + 3)
                    lbl_item.setPos(avg_u - (br.width() / 2), y_offset)
                    
                    shadow.setZValue(49)
                    lbl_item.setZValue(50)
                    
                    target_scene.addItem(shadow)
                    target_scene.addItem(lbl_item)
                    graphics_to_add.extend([shadow, lbl_item])
                
                for g_item in graphics_to_add:
                    g_item.setData(0, feat.id())
                    g_item.setData(1, layer.id())
                    
                if tracking_list is not None:
                    tracking_list.extend(graphics_to_add)

    def change_map_label(self, t_key, field_name, *_args):
        self.ensure_layers_valid()
        layer_map = {'pin': self.pin_layer, 'line': self.line_layer, 'polygon': self.poly_layer}
        layer = layer_map.get(t_key)
        if not self.is_layer_valid(layer): return
        
        labeling = layer.labeling()
        if labeling:
            settings = labeling.settings()
            settings.fieldName = field_name
            layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            layer.triggerRepaint()
            self.load_existing_features()

    def on_note_typing(self, text):
        if not getattr(self, 'active_qgis_fid', None) or not getattr(self, 'active_qgis_layer', None): return
        for action in self.undo_stack:
            if hasattr(action.get('feature_obj'), 'id') and action['feature_obj'].id() == self.active_qgis_fid:
                action['feature_obj'].setAttribute("note", text)
                break

    def save_note_to_qgis(self):
        if not getattr(self, 'active_qgis_fid', None) or not self.is_layer_valid(getattr(self, 'active_qgis_layer', None)): return
        text = self.txt_feature_note.text()
        note_idx = self.active_qgis_layer.fields().indexOf("note")
        if note_idx != -1:
            self._is_plugin_editing = True
            was_editable = self.active_qgis_layer.isEditable()
            if not was_editable: self.active_qgis_layer.startEditing()
            self.active_qgis_layer.changeAttributeValue(self.active_qgis_fid, note_idx, text)
            if not was_editable: self.active_qgis_layer.commitChanges()
            self._is_plugin_editing = False
            
            self.active_qgis_layer.triggerRepaint()
            self.load_existing_features()

    def update_buttons(self):
        self.btn_undo.setEnabled(len(self.undo_stack) > 0)
        self.btn_redo.setEnabled(len(self.redo_stack) > 0)

    def undo_action(self):
        self.txt_feature_note.clearFocus()
        layer = None
        while self.undo_stack:
            action = self.undo_stack.pop()
            layer = action.get('layer')
            if self.is_layer_valid(layer):
                break
            else:
                layer = None
                
        if not layer:
            self.update_buttons()
            return
            
        custom_id = action['feature_obj'].attribute("id")
        
        real_fid = None
        for feat in layer.getFeatures():
            if feat["id"] == custom_id:
                real_fid = feat.id()
                break
                
        if real_fid is not None:
            self._is_plugin_editing = True
            was_editable = layer.isEditable()
            if not was_editable: layer.startEditing()
            layer.deleteFeature(real_fid)
            if not was_editable: layer.commitChanges()
            layer.triggerRepaint()
            self._is_plugin_editing = False
            
        if self.active_qgis_fid == real_fid:
            self.active_qgis_fid = None
            self.active_qgis_layer = None
            self.lbl_detail_title.setText("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
            self.txt_feature_note.setText("")
            self.txt_feature_note.setEnabled(False)

        self.redo_stack.append(action)
        self.load_existing_features()
        self.update_buttons()

    def redo_action(self):
        layer = None
        while self.redo_stack:
            action = self.redo_stack.pop()
            layer = action.get('layer')
            if self.is_layer_valid(layer):
                break
            else:
                layer = None
                
        if not layer:
            self.update_buttons()
            return
        
        self._is_plugin_editing = True
        was_editable = layer.isEditable()
        if not was_editable: layer.startEditing()
        
        new_feat = QgsFeature(action['feature_obj'])
        layer.addFeature(new_feat)
        
        if not was_editable: layer.commitChanges()
        layer.triggerRepaint()
        self._is_plugin_editing = False
        
        action['feature_obj'] = QgsFeature(new_feat)
        
        self.undo_stack.append(action)
        self.load_existing_features()
        self.update_buttons()

    def remove_clicked_feature(self, item):
        layer_id = item.data(1)
        feat_id = item.data(0)
        
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer and layer.isValid():
            self._is_plugin_editing = True
            was_editable = layer.isEditable()
            if not was_editable: layer.startEditing()
            layer.deleteFeature(feat_id)
            if not was_editable: layer.commitChanges()
            self._is_plugin_editing = False
            layer.triggerRepaint()
            self.load_existing_features()

    def clear_all_features(self):
        reply = QMessageBox.question(self, 'Clear Photo', f'Are you sure you want to delete all drawn objects on {self.photo_name}?',
                                     MsgYes | MsgNo, MsgNo)
        if reply == MsgYes:
            self.txt_feature_note.blockSignals(True)
            
            self._is_plugin_editing = True
            self.ensure_layers_valid()
            for layer in [self.pin_layer, self.line_layer, self.poly_layer]:
                if not self.is_layer_valid(layer): continue
                fids = [f.id() for f in layer.getFeatures() if f["photo"] == self.photo_name]
                if fids:
                    was_editable = layer.isEditable()
                    if not was_editable: layer.startEditing()
                    layer.deleteFeatures(fids)
                    if not was_editable: layer.commitChanges()
                    layer.triggerRepaint()
            self._is_plugin_editing = False
                
            for item in self._persistent_graphics:
                try: 
                    self.proj_scene.removeItem(item)
                except RuntimeError: 
                    pass
            self._persistent_graphics.clear()
                
            self.active_qgis_fid = None
            self.active_qgis_layer = None
            self.lbl_detail_title.setText("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
            self.txt_feature_note.setText("")
            self.txt_feature_note.setEnabled(False)
            self.txt_feature_note.blockSignals(False)

            self.undo_stack.clear()
            self.redo_stack.clear()
            self.update_buttons()


MavicStudioWindow = InteractiveViewer
