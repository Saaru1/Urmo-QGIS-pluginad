import os
import math
import traceback
import shutil
from datetime import datetime

from qgis.PyQt.QtWidgets import (
    QListWidget, QListWidgetItem, QButtonGroup, QColorDialog, QCheckBox,
    QSpinBox, QTabWidget, QVBoxLayout, QWidget, QGridLayout, QDoubleSpinBox,
    QFileDialog, QTableWidget, QTableWidgetItem, QAbstractItemView, QHeaderView, QSlider,
    QMenu, QInputDialog, QDial
)
from qgis.PyQt.QtCore import QSize, QRectF
from qgis.PyQt.QtGui import QIcon, QPainterPath, QPixmapCache, QPixmap, QPainter, QImage

from qgis.core import (
    QgsLineSymbol, QgsFillSymbol, QgsPointXY, QgsProject, QgsVectorLayer, 
    QgsFeature, QgsGeometry, QgsField, QgsPalLayerSettings, QgsTextFormat, 
    QgsTextBufferSettings, QgsVectorLayerSimpleLabeling, QgsMarkerSymbol, 
    QgsSimpleMarkerSymbolLayer, QgsProperty, QgsMessageLog, Qgis,
    QgsSymbolLayer, QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFeatureRequest,
    QgsDefaultValue, QgsWkbTypes, QgsApplication, QgsTask
)

from ..compat_drone import (
    QDialog, QHBoxLayout, QPushButton, QLabel, QGraphicsView, QGraphicsScene, 
    Qt, pyqtSignal, QMessageBox, KeepAspectRatio, ScrollHandDrag, NoDrag,
    AnchorUnderMouse, LeftButton, RightButton, QVariant, QColor, 
    QGraphicsEllipseItem, QGraphicsTextItem, QGraphicsLineItem, QGraphicsPolygonItem, 
    QPolygonF, QPointF, QBrush, QPen, QFont, MsgYes, MsgNo, QFrame, QLineEdit, 
    StyledPanel, QComboBox, QuadrantAbove, DashLine, SolidLine, RoundCap, 
    Key_Return, Key_Enter, Key_Escape, Key_Up, Key_Down, IdentifyFormatValue, LabelPlacementOverPoint, HLine,
    NonModal, Window, Transparent, QTransform, QTimer, QgsRubberBand, QgsMapToolEmitPoint,
    WindowMinimized, UserRole, QgsVertexMarker, QGraphicsPathItem, QSplitter, Horizontal,
    QGraphicsItem, GraphicsItemIsSelectable, GraphicsItemIsMovable, GraphicsItemSendsGeometryChanges,
    Checked, Format_ARGB32_Premultiplied, RenderHintAntialiasing, SmoothPixmapTransform, ShowAlphaChannel, QGraphicsBlurEffect, BlurPerformanceHint, DeviceCoordinateCache, NoPen
)
from .dlg_layer_style import DropTextEdit, COMBO_CSS, INPUT_CSS, get_rect_intersection

class InteractiveAnchorItem(QGraphicsPathItem):
    def __init__(self, anchor_x, anchor_y, feature_key, parent_viewer, label_item):
        super().__init__()
        self.base_anchor_x = anchor_x
        self.base_anchor_y = anchor_y
        self.feature_key = feature_key
        self.parent_viewer = parent_viewer
        self.label_item = label_item
        
        path = QPainterPath()
        s = 8
        path.moveTo(-s, -s)
        path.lineTo(s, s)
        path.moveTo(-s, s)
        path.lineTo(s, -s)
        path.addRect(-12, -12, 24, 24)
        
        self.setPath(path)
        self.setPen(QPen(QColor(255, 0, 0), 3))
        self.setBrush(QBrush(QColor(255, 255, 255, 1))) 
        
        self.setZValue(101)
        self.setFlags(GraphicsItemIsSelectable | GraphicsItemIsMovable | GraphicsItemSendsGeometryChanges)
        
    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if self.label_item and getattr(self.label_item, 'shadow_item', None):
            if self.label_item.shadow_item.graphicsEffect():
                # Fix: Turn it off completely, do not use radius 0
                self.label_item.shadow_item.graphicsEffect().setEnabled(False)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if self.label_item:
            self.label_item.update_visuals()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        
        # Restore blur when you drop the anchor
        if self.label_item and getattr(self.label_item, 'shadow_item', None):
            effect = self.label_item.shadow_item.graphicsEffect()
            if effect:
                blur_val = self.label_item.style_dict.get('shadow_blur', 0)
                effect.setBlurRadius(blur_val)
                effect.setEnabled(blur_val > 0)
                
        if self.scene():
            self.scene().update() # Wipe away any remaining visual artifacts
            
        if self.parent_viewer:
            # Correct relative offset math: Current absolute X minus original base X
            adx = self.x() - self.base_anchor_x
            ady = self.y() - self.base_anchor_y
            self.parent_viewer.save_anchor_override(self.feature_key, adx, ady)

class InteractiveLabelItem(QGraphicsTextItem):
    def __init__(self, text, base_anchor_x, base_anchor_y, feature_key, parent_viewer, style_dict, custom_scale=1.0):
        super().__init__(text)
        self.base_anchor_x = base_anchor_x
        self.base_anchor_y = base_anchor_y
        self.feature_key = feature_key
        self.parent_viewer = parent_viewer
        self.style_dict = style_dict
        self.custom_scale = custom_scale
        
        self.anchor_item = None
        self.bg_item = None
        self.shadow_item = None
        
        self.setFlags(GraphicsItemIsSelectable | GraphicsItemIsMovable | GraphicsItemSendsGeometryChanges)
        self.setAcceptedMouseButtons(LeftButton | RightButton)
        
    def set_initial_center(self, cx, cy):
        br = self.boundingRect()
        self.setPos(cx - br.width()/2, cy - br.height()/2)

    def update_visuals(self):
        br = self.boundingRect()
        tw, th = br.width(), br.height()
        cx, cy = self.x() + tw/2, self.y() + th/2
        
        # Read the true coordinates directly from the anchor's physical position
        true_ax = self.anchor_item.x() if self.anchor_item else self.base_anchor_x
        true_ay = self.anchor_item.y() if self.anchor_item else self.base_anchor_y
        
        is_billboard = self.style_dict.get('preset') == "Billboard (Stand-up)"
        shape_type = self.style_dict.get('billboard_shape', "Rounded")
        
        if is_billboard and isinstance(self.bg_item, QGraphicsPathItem):
            board_path = QPainterPath()
            if shape_type == "Rounded":
                board_path.addRoundedRect(self.x(), self.y(), tw, th, 15 * self.custom_scale, 15 * self.custom_scale)
            else:
                board_path.addRect(self.x(), self.y(), tw, th)
            
            dx = cx - true_ax
            dy = cy - true_ay
            dist = math.hypot(dx, dy)
            pole_path = QPainterPath()
            if dist > 0:
                nx, ny = -dy/dist, dx/dist
                pole_w = max(4, int(10 * self.custom_scale))
                w = pole_w / 2.0
                # Fix: Connect to the edge of the bounding box, not the centroid
                edge_x, edge_y = get_rect_intersection(self.x(), self.y(), tw, th, true_ax, true_ay)
                pole_path.addPolygon(QPolygonF([
                    QPointF(true_ax + nx*w, true_ay + ny*w),
                    QPointF(true_ax - nx*w, true_ay - ny*w),
                    QPointF(edge_x - nx*w, edge_y - ny*w),
                    QPointF(edge_x + nx*w, edge_y + ny*w)
                ]))
                
            combined_path = QPainterPath()
            try:
                from ..compat_drone import Qt
                combined_path.setFillRule(Qt.WindingFill)
            except Exception:
                pass
            combined_path.addPath(pole_path)
            combined_path.addPath(board_path)

            # CRITICAL FIX 1: Simplify the path!
            combined_path = combined_path.simplified()

            self.bg_item.setPath(combined_path)
            
            if isinstance(self.shadow_item, QGraphicsPathItem):
                transform = QTransform()
                transform.translate(true_ax, true_ay)
                shadow_dist = self.style_dict.get('shadow_dist', 15)
                shadow_angle = self.style_dict.get('light_angle', 45)
                safe_shear = math.cos(math.radians(shadow_angle)) * (abs(shadow_dist) / 30.0)
                transform.shear(safe_shear, 0.0)
                
                scale_y = -0.4 * (shadow_dist / 15.0 if shadow_dist != 0 else 0.1)
                if abs(scale_y) < 0.01: scale_y = -0.01 if shadow_dist >= 0 else 0.01
                
                transform.scale(1.0, scale_y)
                transform.translate(-true_ax, -true_ay)
                
                # CRITICAL FIX 2: Simplify again after the extreme shear/scale mapping
                mapped_shadow = transform.map(combined_path).simplified()
                
                local_offset = mapped_shadow.boundingRect().topLeft()
                shift_transform = QTransform().translate(-local_offset.x(), -local_offset.y())
                local_shadow_path = shift_transform.map(mapped_shadow)
                
                self.shadow_item.setPath(local_shadow_path)
                self.shadow_item.setPos(local_offset.x(), local_offset.y())
                self.shadow_item.setTransform(QTransform())
                
        elif not is_billboard:
            if isinstance(self.bg_item, QGraphicsLineItem):
                edge_x, edge_y = get_rect_intersection(self.x(), self.y(), tw, th, true_ax, true_ay)
                self.bg_item.setLine(true_ax, true_ay, edge_x, edge_y)
                
            if isinstance(self.shadow_item, QGraphicsTextItem):
                sx = getattr(self.shadow_item, 'base_sx', 0)
                sy = getattr(self.shadow_item, 'base_sy', 0)
                self.shadow_item.setPos(self.x() + sx + 3, self.y() + sy + 3)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if getattr(self, 'shadow_item', None) and self.shadow_item.graphicsEffect():
            # Fix: Turn it off completely, do not use radius 0
            self.shadow_item.graphicsEffect().setEnabled(False)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        self.update_visuals()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        
        # Restore blur when you drop the label, but disable the effect entirely if blur is 0
        if getattr(self, 'shadow_item', None):
            effect = self.shadow_item.graphicsEffect()
            if effect:
                blur_val = self.style_dict.get('shadow_blur', 0)
                effect.setBlurRadius(blur_val)
                effect.setEnabled(blur_val > 0) # <--- The critical addition
                
        if self.scene():
            self.scene().update() # Wipe away any remaining visual artifacts
            
        if self.parent_viewer:
            br = self.boundingRect()
            cx = self.x() + br.width()/2.0
            cy = self.y() + br.height()/2.0
            cx_off = cx - self.base_anchor_x
            cy_off = cy - self.base_anchor_y
            self._save_overrides(cx_off=cx_off, cy_off=cy_off)

    def itemChange(self, change, value):
        try:
            target_change = QGraphicsItem.GraphicsItemChange.ItemSelectedHasChanged
        except AttributeError:
            target_change = QGraphicsItem.ItemSelectedHasChanged
            
        if change == target_change:
            # We purposely do nothing here anymore.
            # Anchor visibility is handled centrally by InteractiveViewer._on_scene_selection_changed
            # to prevent flickering when transitioning clicks between the label and the anchor.
            pass
        return super().itemChange(change, value)

    def contextMenuEvent(self, event):
        if not self.parent_viewer or self.parent_viewer.current_tool != 'edit':
            super().contextMenuEvent(event)
            return
            
        event.accept()
        menu = QMenu()
        action_color = menu.addAction("🎨 Change Specific Color")
        action_size = menu.addAction("📏 Change Specific Size")
        action_reset = menu.addAction("↺ Reset to Layer Style")
        menu.addSeparator()
        action_hide = menu.addAction("🗑️ Hide this Label")

        try:
            action = menu.exec(event.screenPos())
        except AttributeError:
            action = menu.exec_(event.screenPos())
        
        if action == action_color:
            color = QColorDialog.getColor(self.defaultTextColor(), self.parent_viewer, "Pick Label Color", ShowAlphaChannel)
            if color.isValid():
                self.setDefaultTextColor(color)
                c = color.getRgb()
                self._save_overrides(color=(c[0], c[1], c[2], c[3]))
        elif action == action_size:
            val, ok = QInputDialog.getDouble(self.parent_viewer, "Change Size", "Scale Multiplier (e.g., 1.5 for 50% larger):", self.custom_scale, 0.1, 10.0, 2)
            if ok:
                self.custom_scale = val
                self._save_overrides(size=val)
                self.parent_viewer.render_projected_labels() 
        elif action == action_reset:
            self._save_overrides(reset=True)
            self.parent_viewer.render_projected_labels()
        elif action == action_hide:
            self.hide_label()

    def _save_overrides(self, cx_off=None, cy_off=None, hidden=None, color=None, size=None, reset=False):
        if self.parent_viewer:
            self.parent_viewer.save_label_override(self.feature_key, cx_off, cy_off, hidden, color, size, reset)

    def hide_label(self):
        if self.bg_item: self.bg_item.hide()
        if hasattr(self, 'bg_item_pole') and self.bg_item_pole: self.bg_item_pole.hide()
        if self.shadow_item: self.shadow_item.hide()
        if self.anchor_item: self.anchor_item.hide()
        self.hide()
        self._save_overrides(hidden=True)
        # Fix: Force scene repaint to wipe away orphaned blurred pixels
        if self.scene():
            self.scene().update()

class PointMapTool(QgsMapToolEmitPoint):
    canvasClicked = pyqtSignal(object, object)
    def __init__(self, canvas):
        super().__init__(canvas)
    def canvasReleaseEvent(self, event):
        pt = self.toMapCoordinates(event.pos())
        self.canvasClicked.emit(pt, event.button())

class ReverseProjectionView(QGraphicsView):
    scenePressed = pyqtSignal(float, float, object)
    sceneMoved = pyqtSignal(float, float, object)
    sceneReleased = pyqtSignal(float, float, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTransformationAnchor(AnchorUnderMouse)

    def wheelEvent(self, event):
        zoom_in_factor = 1.15
        zoom_out_factor = 1.0 / zoom_in_factor
        if event.angleDelta().y() > 0:
            zoom_factor = zoom_in_factor
        else:
            zoom_factor = zoom_out_factor
        self.scale(zoom_factor, zoom_factor)

    def mousePressEvent(self, event):
        scene_pos = self.mapToScene(event.pos())
        self.scenePressed.emit(scene_pos.x(), scene_pos.y(), event.button())
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        scene_pos = self.mapToScene(event.pos())
        self.sceneMoved.emit(scene_pos.x(), scene_pos.y(), event.buttons())
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        scene_pos = self.mapToScene(event.pos())
        self.sceneReleased.emit(scene_pos.x(), scene_pos.y(), event.button())
        super().mouseReleaseEvent(event)

class InteractiveViewer(QDialog):
    def __init__(self, gallery_data, start_index, global_settings, dem_layer, parent=None):
        super().__init__(parent)
        self.gallery_data = gallery_data
        self.global_settings = global_settings
        self.dem_layer = dem_layer
        self.fallback_z = global_settings.get('fallback_z', 0.0)
        
        self.photo_name = ""
        self.engine = None
        self.temp_task = None
        self._is_silent_projection = False
        
        self._projected_label_data = {} 
        self._projected_graphics = []   
        
        self.undo_stack = [] 
        self.redo_stack = []
        self._persistent_graphics = [] 
        self.active_qgis_fid = None
        self.active_qgis_layer = None
        self._is_plugin_editing = False 
        
        self.current_tool = 'pan'
        self.temp_points = []
        self.temp_graphics = []
        self.pin_start_u = None
        self.pin_start_v = None
        
        self.tie_points = []
        self.tie_point_graphics = []
        self.map_tie_markers = []
        self.pending_u = None
        self.pending_v = None
        self.pending_z = None
        
        self.map_canvas = self.parent().iface.mapCanvas() if hasattr(self.parent(), 'iface') else None
        if self.map_canvas:
            self.map_tool = PointMapTool(self.map_canvas)
            self.map_tool.canvasClicked.connect(self.on_map_clicked)
        self.prev_map_tool = None

        self.live_sync_timer = QTimer(self)
        self.live_sync_timer.setSingleShot(True)
        self.live_sync_timer.setInterval(400) 
        self.live_sync_timer.timeout.connect(self._execute_live_sync)

        self.setWindowTitle("Interactive Viewer - Gallery Mode")
        self.resize(1400, 850)
        self.setup_drawing_layers()

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_splitter = QSplitter(Horizontal)
        main_layout.addWidget(self.main_splitter)
        
        self.filmstrip = QListWidget()
        self.filmstrip.setMinimumWidth(150)
        self.filmstrip.setIconSize(QSize(160, 110))
        self.filmstrip.setSpacing(8)
        self.filmstrip.setStyleSheet("background-color: #1e1e1e; color: #ccc; border: none; outline: none;")
        self.main_splitter.addWidget(self.filmstrip)
        
        center_widget = QWidget()
        center_widget.setMinimumWidth(500)  
        center_col = QVBoxLayout(center_widget)
        
        toolbar1 = QHBoxLayout()
        toolbar2 = QHBoxLayout()
        
        self.tool_group = QButtonGroup(self)
        
        self.btn_pan = QPushButton("🤚 Pan")
        self.btn_pan.setCheckable(True)
        self.btn_pan.setChecked(True)
        self.tool_group.addButton(self.btn_pan, 0)
        
        self.btn_edit = QPushButton("↖️ Select/Edit")
        self.btn_edit.setCheckable(True)
        self.btn_edit.setToolTip("Disable panning so you can freely select, drag, and right-click labels.")
        self.btn_edit.setStyleSheet("font-weight: bold; color: #ffcc00;")
        self.tool_group.addButton(self.btn_edit, 6)
        
        self.btn_place = QPushButton("🏷️ Place/Restore")
        self.btn_place.setCheckable(True)
        self.tool_group.addButton(self.btn_place, 7)
        
        self.btn_pin = QPushButton("📍 Pin")
        self.btn_pin.setCheckable(True)
        self.tool_group.addButton(self.btn_pin, 1)
        
        self.btn_line = QPushButton("📏 Line")
        self.btn_line.setCheckable(True)
        self.tool_group.addButton(self.btn_line, 2)
        
        self.btn_poly = QPushButton("⬟ Polygon")
        self.btn_poly.setCheckable(True)
        self.tool_group.addButton(self.btn_poly, 3)

        self.btn_remove = QPushButton("🗑️ Remove")
        self.btn_remove.setCheckable(True)
        self.tool_group.addButton(self.btn_remove, 4)
        
        self.btn_tie_point = QPushButton("🔗 Georeferencer (Tie Point)")
        self.btn_tie_point.setStyleSheet("font-weight: bold; color: #00FF00;")
        self.btn_tie_point.setCheckable(True)
        self.tool_group.addButton(self.btn_tie_point, 5)

        self.tool_group.buttonClicked.connect(self.on_tool_changed)
        
        toolbar1.addWidget(self.btn_pan)
        toolbar1.addWidget(self.btn_edit)
        toolbar1.addWidget(self.btn_place)
        toolbar1.addWidget(self.btn_pin)
        toolbar1.addWidget(self.btn_line)
        toolbar1.addWidget(self.btn_poly)
        toolbar1.addWidget(self.btn_remove)
        toolbar1.addWidget(self.btn_tie_point)
        
        self.btn_refresh = QPushButton("🔄 Re-Calculate Math")
        self.btn_refresh.setStyleSheet("background-color: #2b579a; color: white;")
        self.btn_refresh.clicked.connect(self._execute_live_sync)
        toolbar1.addWidget(self.btn_refresh)
        toolbar1.addStretch()
        
        self.hint = QLabel("")
        self.hint.setStyleSheet("color: #ADD8E6; font-weight: bold; padding-left: 10px;")
        toolbar2.addWidget(self.hint)
        toolbar2.addStretch()

        self.chk_show_all = QCheckBox("Show features drawn on a photo in ALL photos")
        self.chk_show_all.setChecked(False)
        self.chk_show_all.setStyleSheet("""
            QCheckBox { spacing: 8px; font-size: 13px; color: #e0e0e0; }
            QCheckBox::indicator { width: 18px; height: 18px; border-radius: 4px; border: 2px solid #666; background-color: #333; }
            QCheckBox::indicator:hover { border: 2px solid #888; }
            QCheckBox::indicator:checked { background-color: #0078D7; border: 2px solid #0078D7; }
        """)
        self.chk_show_all.stateChanged.connect(self.load_existing_features)
        toolbar2.addWidget(self.chk_show_all)
        
        self.btn_undo = QPushButton("↩ Undo")
        self.btn_undo.clicked.connect(self.undo_action)
        self.btn_undo.setEnabled(False)
        
        self.btn_redo = QPushButton("↪ Redo")
        self.btn_redo.clicked.connect(self.redo_action)
        self.btn_redo.setEnabled(False)
        
        self.btn_clear = QPushButton("🗑️ Clear Photo")
        self.btn_clear.setStyleSheet("background-color: #A00000; color: white;")
        self.btn_clear.clicked.connect(self.clear_all_features)

        toolbar2.addWidget(self.btn_undo)
        toolbar2.addWidget(self.btn_redo)
        toolbar2.addWidget(self.btn_clear)
        
        center_col.addLayout(toolbar1)
        center_col.addLayout(toolbar2)

        self.view_splitter = QSplitter(Horizontal)

        self.tabs = QTabWidget()
        self.tabs.currentChanged.connect(self.on_tab_changed)
        
        raw_tab = QWidget()
        raw_layout = QVBoxLayout(raw_tab)
        self.raw_view = ReverseProjectionView()
        self.raw_scene = QGraphicsScene()
        self.raw_view.setScene(self.raw_scene)
        self.raw_view.setDragMode(ScrollHandDrag)
        self.raw_view.scenePressed.connect(self.on_scene_pressed)
        self.raw_view.sceneMoved.connect(self.on_scene_moved)
        self.raw_view.sceneReleased.connect(self.on_scene_released)
        raw_layout.addWidget(self.raw_view)
        self.tabs.addTab(raw_tab, "1. Raw Original Photo")

        proj_tab = QWidget()
        proj_layout = QVBoxLayout(proj_tab)
        self.proj_view = ReverseProjectionView()
        self.proj_scene = QGraphicsScene()
        self.proj_scene.selectionChanged.connect(self._on_scene_selection_changed)
        self.proj_view.setScene(self.proj_scene)
        self.proj_view.setDragMode(ScrollHandDrag)
        self.proj_view.scenePressed.connect(self.on_scene_pressed)
        self.proj_view.sceneMoved.connect(self.on_scene_moved)
        self.proj_view.sceneReleased.connect(self.on_scene_released)
        proj_layout.addWidget(self.proj_view)
        self.tabs.addTab(proj_tab, "2. Projected Vectors")
            
        self.view_splitter.addWidget(self.tabs)

        self.side_panel = QFrame()
        self.side_panel.setFrameShape(StyledPanel)
        self.side_panel.setMinimumWidth(320)
        self.side_panel.setStyleSheet("QFrame { background-color: #2b2b2b; border-radius: 5px; } QLabel { color: white; } QCheckBox { color: white; }")
        side_layout = QVBoxLayout(self.side_panel)
        side_layout.setContentsMargins(10, 10, 10, 10)
        
        self.main_side_tabs = QTabWidget()
        self.main_side_tabs.setStyleSheet("QTabWidget::pane { border: 1px solid #444; } QTabBar::tab { background: #333; color: #ccc; padding: 5px; } QTabBar::tab:selected { background: #555; color: white; font-weight: bold; }")
        
        self.tab_projected = QWidget()
        proj_lay = QVBoxLayout(self.tab_projected)
        
        h_tog = QHBoxLayout()
        self.btn_toggle_labels = QPushButton("👁️ Labels")
        self.btn_toggle_labels.setCheckable(True)
        self.btn_toggle_labels.setChecked(True)
        self.btn_toggle_labels.clicked.connect(self.toggle_all_labels)
        
        self.btn_toggle_shadows = QPushButton("🌘 Shadows")
        self.btn_toggle_shadows.setCheckable(True)
        self.btn_toggle_shadows.setChecked(True)
        self.btn_toggle_shadows.clicked.connect(self.toggle_all_shadows)
        
        self.btn_toggle_callouts = QPushButton("📏 Callouts")
        self.btn_toggle_callouts.setCheckable(True)
        self.btn_toggle_callouts.setChecked(True)
        self.btn_toggle_callouts.clicked.connect(self.toggle_all_callouts)
        
        toggle_css = """
            QPushButton { background-color: #444; color: #888; border: 2px solid #555; padding: 6px; border-radius: 4px; font-weight: normal; }
            QPushButton:checked { background-color: #28a745; color: white; font-weight: bold; border: 2px solid #00ff00; }
        """
        self.btn_toggle_labels.setStyleSheet(toggle_css)
        self.btn_toggle_shadows.setStyleSheet(toggle_css)
        self.btn_toggle_callouts.setStyleSheet(toggle_css)

        h_tog.addWidget(self.btn_toggle_labels)
        h_tog.addWidget(self.btn_toggle_shadows)
        h_tog.addWidget(self.btn_toggle_callouts)
        proj_lay.addLayout(h_tog)
        
        h_layer = QHBoxLayout()
        h_layer.addWidget(QLabel("Active Layer:"))
        self.combo_proj_layer = QComboBox()
        self.combo_proj_layer.setStyleSheet(COMBO_CSS)
        if hasattr(self.parent(), 'layer_list'):
            for i in range(self.parent().layer_list.count()):
                item = self.parent().layer_list.item(i)
                layer = item.data(UserRole)
                if layer: self.combo_proj_layer.addItem(layer.name(), layer.id())
        self.combo_proj_layer.currentIndexChanged.connect(self._sync_ui_from_proj_style)
        h_layer.addWidget(self.combo_proj_layer)
        proj_lay.addLayout(h_layer)
        
        self.proj_lbl_canvas = DropTextEdit()
        self.proj_lbl_canvas.setPlaceholderText("Label layout (e.g. [id] - [name])")
        self.proj_lbl_canvas.setMaximumHeight(50)
        self.proj_lbl_canvas.setStyleSheet(INPUT_CSS)
        self.proj_lbl_canvas.textChanged.connect(self._on_proj_style_changed)
        proj_lay.addWidget(QLabel("Label Expression (Double-click field):"))
        proj_lay.addWidget(self.proj_lbl_canvas)
        
        self.proj_list_fields = QListWidget()
        self.proj_list_fields.setMaximumHeight(60)
        self.proj_list_fields.setStyleSheet(INPUT_CSS)
        self.proj_list_fields.itemDoubleClicked.connect(lambda item: self.proj_lbl_canvas.insertPlainText(f"[{item.text()}]"))
        proj_lay.addWidget(self.proj_list_fields)

        h_sz = QHBoxLayout()
        h_sz.addWidget(QLabel("Font:"))
        self.spin_proj_font = QSpinBox()
        self.spin_proj_font.setStyleSheet(INPUT_CSS)
        self.spin_proj_font.setRange(8, 200)
        self.spin_proj_font.valueChanged.connect(self._on_proj_style_changed)
        h_sz.addWidget(self.spin_proj_font)
        
        self.btn_proj_color = QPushButton()
        self.btn_proj_color.clicked.connect(lambda: self._pick_proj_color("text"))
        h_sz.addWidget(self.btn_proj_color)
        
        self.btn_proj_halo = QPushButton()
        self.btn_proj_halo.clicked.connect(lambda: self._pick_proj_color("halo"))
        h_sz.addWidget(self.btn_proj_halo)
        proj_lay.addLayout(h_sz)
        
        h_callout = QHBoxLayout()
        h_callout.addWidget(QLabel("Callout Width:"))
        self.spin_callout_w = QSpinBox()
        self.spin_callout_w.setStyleSheet(INPUT_CSS)
        self.spin_callout_w.setRange(0, 50)
        self.spin_callout_w.valueChanged.connect(self._on_proj_style_changed)
        h_callout.addWidget(self.spin_callout_w)
        
        self.btn_callout_color = QPushButton("Color")
        self.btn_callout_color.clicked.connect(lambda: self._pick_proj_color("callout"))
        h_callout.addWidget(self.btn_callout_color)
        proj_lay.addLayout(h_callout)
        
        h_preset = QHBoxLayout()
        h_preset.addWidget(QLabel("Preset:"))
        self.combo_proj_preset = QComboBox()
        self.combo_proj_preset.setStyleSheet(COMBO_CSS)
        self.combo_proj_preset.addItems(["Standard (Flat)", "Billboard (Stand-up)"])
        self.combo_proj_preset.currentTextChanged.connect(self._on_proj_style_changed)
        h_preset.addWidget(self.combo_proj_preset)
        
        self.combo_proj_bb_shape = QComboBox()
        self.combo_proj_bb_shape.setStyleSheet(COMBO_CSS)
        self.combo_proj_bb_shape.addItems(["Rounded", "Rectangle"])
        self.combo_proj_bb_shape.currentTextChanged.connect(self._on_proj_style_changed)
        h_preset.addWidget(self.combo_proj_bb_shape)
        proj_lay.addLayout(h_preset)
        
        h_ang = QHBoxLayout()
        h_ang.addWidget(QLabel("Angle:"))
        self.dial_proj_angle = QDial()
        self.dial_proj_angle.setRange(-180, 180)
        self.dial_proj_angle.setNotchesVisible(True)
        self.dial_proj_angle.setFixedSize(40, 40)
        
        self.lbl_proj_angle_val = QLabel("45°")
        self.dial_proj_angle.valueChanged.connect(lambda v: self.lbl_proj_angle_val.setText(f"{v}°"))
        self.dial_proj_angle.valueChanged.connect(self._on_proj_style_changed)
        h_ang.addWidget(self.dial_proj_angle)
        h_ang.addWidget(self.lbl_proj_angle_val)
        
        h_ang.addWidget(QLabel("Dist:"))
        self.slider_shadow_dist = QSlider(Horizontal)
        self.slider_shadow_dist.setRange(-100, 100) # SAFE RANGE
        self.slider_shadow_dist.setFixedWidth(60)
        
        self.spin_shadow_dist = QSpinBox() # NEW EDITABLE BOX
        self.spin_shadow_dist.setRange(-100, 100)
        self.spin_shadow_dist.setFixedWidth(50)
        self.spin_shadow_dist.setStyleSheet(INPUT_CSS)
        
        # Link them together
        self.slider_shadow_dist.valueChanged.connect(self.spin_shadow_dist.setValue)
        self.spin_shadow_dist.valueChanged.connect(self.slider_shadow_dist.setValue)
        self.slider_shadow_dist.valueChanged.connect(self._on_proj_style_changed)
        
        h_ang.addWidget(self.slider_shadow_dist)
        h_ang.addWidget(self.spin_shadow_dist)

        h_ang.addWidget(QLabel("Blur:"))
        self.slider_shadow_blur = QSlider(Horizontal)
        self.slider_shadow_blur.setRange(0, 30) # SAFE RANGE
        self.slider_shadow_blur.setFixedWidth(60)
        
        self.spin_shadow_blur = QSpinBox() # NEW EDITABLE BOX
        self.spin_shadow_blur.setRange(0, 30)
        self.spin_shadow_blur.setFixedWidth(40)
        self.spin_shadow_blur.setStyleSheet(INPUT_CSS)
        
        # Link them together
        self.slider_shadow_blur.valueChanged.connect(self.spin_shadow_blur.setValue)
        self.spin_shadow_blur.valueChanged.connect(self.slider_shadow_blur.setValue)
        self.slider_shadow_blur.valueChanged.connect(self._on_proj_style_changed)
        
        h_ang.addWidget(self.slider_shadow_blur)
        h_ang.addWidget(self.spin_shadow_blur)
        
        proj_lay.addLayout(h_ang)

        self.btn_fast_refresh = QPushButton("⚡ Refresh Labels Only")
        self.btn_fast_refresh.setStyleSheet("background-color: #28a745; color: white; font-weight: bold;")
        self.btn_fast_refresh.setToolTip("Applies these visual settings to the labels immediately without calculating lines.")
        self.btn_fast_refresh.clicked.connect(self.render_projected_labels)
        proj_lay.addWidget(self.btn_fast_refresh)
        
        proj_lay.addStretch()
        self.main_side_tabs.addTab(self.tab_projected, "Projected Vectors")

        self.tab_user_drawn = QWidget()
        user_lay = QVBoxLayout(self.tab_user_drawn)
        
        self.sym_tabs = QTabWidget()
        self.sym_tabs.setStyleSheet("QTabBar::tab { padding: 4px; font-size: 10px; }")
        self.sym_ui = {}
        tool_configs = [
            ('pin', '📍 Pin', QColor(255, 0, 0)),
            ('line', '📏 Line', QColor(255, 255, 0)),
            ('polygon', '⬟ Poly', QColor(0, 255, 255))
        ]
        
        for t_key, t_name, default_col in tool_configs:
            tab = QWidget()
            lay = QVBoxLayout(tab)
            lay.setContentsMargins(10, 15, 10, 10)
            
            c_row = QHBoxLayout()
            c_row.addWidget(QLabel("Color:"))
            btn_col = QPushButton()
            btn_col.setStyleSheet(f"background-color: {default_col.name()}; border: 1px solid white; height: 20px;")
            c_row.addWidget(btn_col)
            lay.addLayout(c_row)
            
            s_row = QHBoxLayout()
            s_row.addWidget(QLabel("Size/Thickness:"))
            spin_sz = QSpinBox()
            spin_sz.setRange(1, 50)
            spin_sz.setValue(6)
            spin_sz.setStyleSheet(INPUT_CSS)
            s_row.addWidget(spin_sz)
            lay.addLayout(s_row)
            
            chk_p = QCheckBox("Apply 3D Perspective")
            chk_p.setChecked(True)
            chk_p.stateChanged.connect(self.load_existing_features)
            lay.addWidget(chk_p)
            
            lay.addSpacing(10)
            lay.addWidget(QLabel("Map Label Content:"))
            combo_lbl = QComboBox()
            combo_lbl.addItems(["id", "note", "photo", "measurement"])
            combo_lbl.setStyleSheet(COMBO_CSS)
            lay.addWidget(combo_lbl)
            lay.addStretch()
            
            self.sym_tabs.addTab(tab, t_name)
            
            self.sym_ui[t_key] = {
                'color': default_col,
                'btn_color': btn_col,
                'spin_size': spin_sz,
                'chk_persp': chk_p,
                'combo_label': combo_lbl
            }
            
            btn_col.clicked.connect(lambda checked, tk=t_key: self.pick_color(tk))
            combo_lbl.currentTextChanged.connect(lambda txt, tk=t_key: self.change_map_label(tk, txt))

        user_lay.addWidget(self.sym_tabs)
        
        div = QFrame()
        div.setFrameShape(HLine)
        div.setStyleSheet("color: #555; margin-top: 5px; margin-bottom: 5px;")
        user_lay.addWidget(div)
        
        self.lbl_detail_title = QLabel("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
        user_lay.addWidget(self.lbl_detail_title)
        
        user_lay.addWidget(QLabel("Note / ID:"))
        self.txt_feature_note = QLineEdit()
        self.txt_feature_note.setEnabled(False)
        self.txt_feature_note.setStyleSheet(INPUT_CSS)
        self.txt_feature_note.textEdited.connect(self.on_note_typing)
        self.txt_feature_note.editingFinished.connect(self.save_note_to_qgis)
        user_lay.addWidget(self.txt_feature_note)
        
        self.main_side_tabs.addTab(self.tab_user_drawn, "User-Drawn")
        side_layout.addWidget(self.main_side_tabs)

        div2 = QFrame()
        div2.setFrameShape(HLine)
        div2.setStyleSheet("color: #555; margin-top: 10px; margin-bottom: 10px;")
        side_layout.addWidget(div2)

        self.lbl_manual_title = QLabel("<b>Photo Overrides & Calibration</b>")
        side_layout.addWidget(self.lbl_manual_title)
        
        h_lens = QHBoxLayout()
        h_lens.addWidget(QLabel("Force Lens:"))
        self.combo_lens = QComboBox()
        self.combo_lens.addItems(["Auto (From File)", "Force Wide", "Force Zoom"])
        self.combo_lens.setStyleSheet(COMBO_CSS)
        self.combo_lens.currentTextChanged.connect(self.apply_manual_offsets)
        h_lens.addWidget(self.combo_lens)
        side_layout.addLayout(h_lens)

        grid_manual = QGridLayout()
        grid_manual.setContentsMargins(0, 0, 0, 0)
        
        self.spin_man_pitch = QDoubleSpinBox()
        self.spin_man_pitch.setRange(-45.0, 45.0)
        self.spin_man_pitch.setSingleStep(0.1)
        
        self.spin_man_yaw = QDoubleSpinBox()
        self.spin_man_yaw.setRange(-180.0, 180.0)
        self.spin_man_yaw.setSingleStep(0.1)
        
        self.spin_man_x = QDoubleSpinBox()
        self.spin_man_x.setRange(-500.0, 500.0)
        self.spin_man_x.setSingleStep(0.5)
        
        self.spin_man_y = QDoubleSpinBox()
        self.spin_man_y.setRange(-500.0, 500.0)
        self.spin_man_y.setSingleStep(0.5)
        
        self.spin_man_geoid = QDoubleSpinBox()
        self.spin_man_geoid.setRange(-100.0, 100.0)
        self.spin_man_geoid.setSingleStep(0.5)

        self.spin_man_k1 = QDoubleSpinBox(); self.spin_man_k1.setRange(-0.5, 0.5); self.spin_man_k1.setDecimals(3); self.spin_man_k1.setSingleStep(0.01)
        self.spin_man_k2 = QDoubleSpinBox(); self.spin_man_k2.setRange(-0.5, 0.5); self.spin_man_k2.setDecimals(3); self.spin_man_k2.setSingleStep(0.01)
        self.spin_man_p1 = QDoubleSpinBox(); self.spin_man_p1.setRange(-0.5, 0.5); self.spin_man_p1.setDecimals(3); self.spin_man_p1.setSingleStep(0.01)
        self.spin_man_p2 = QDoubleSpinBox(); self.spin_man_p2.setRange(-0.5, 0.5); self.spin_man_p2.setDecimals(3); self.spin_man_p2.setSingleStep(0.01)
        self.spin_man_k3 = QDoubleSpinBox(); self.spin_man_k3.setRange(-0.5, 0.5); self.spin_man_k3.setDecimals(3); self.spin_man_k3.setSingleStep(0.01)
        
        for sb in [self.spin_man_pitch, self.spin_man_yaw, self.spin_man_x, self.spin_man_y, self.spin_man_geoid, 
                   self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3]:
            sb.setStyleSheet(INPUT_CSS)
            
        grid_manual.addWidget(QLabel("Pitch:"), 0, 0)
        grid_manual.addWidget(self.spin_man_pitch, 0, 1)
        grid_manual.addWidget(QLabel("Yaw (Crab):"), 0, 2)
        grid_manual.addWidget(self.spin_man_yaw, 0, 3)
        
        grid_manual.addWidget(QLabel("X (E):"), 1, 0)
        grid_manual.addWidget(self.spin_man_x, 1, 1)
        grid_manual.addWidget(QLabel("Y (N):"), 1, 2)
        grid_manual.addWidget(self.spin_man_y, 1, 3)
        
        grid_manual.addWidget(QLabel("Geoid Z:"), 2, 0)
        grid_manual.addWidget(self.spin_man_geoid, 2, 1)
        grid_manual.addWidget(QLabel("k1:"), 2, 2)
        grid_manual.addWidget(self.spin_man_k1, 2, 3)
        
        grid_manual.addWidget(QLabel("k2:"), 3, 0)
        grid_manual.addWidget(self.spin_man_k2, 3, 1)
        grid_manual.addWidget(QLabel("k3:"), 3, 2)
        grid_manual.addWidget(self.spin_man_k3, 3, 3)
        
        grid_manual.addWidget(QLabel("p1:"), 4, 0)
        grid_manual.addWidget(self.spin_man_p1, 4, 1)
        grid_manual.addWidget(QLabel("p2:"), 4, 2)
        grid_manual.addWidget(self.spin_man_p2, 4, 3)
        
        side_layout.addLayout(grid_manual)
        
        btn_lay = QHBoxLayout()
        self.btn_reset_manual = QPushButton("↺ Reset")
        self.btn_reset_manual.setStyleSheet("background-color: #555; color: white;")
        self.btn_reset_manual.clicked.connect(self.reset_manual_offsets)
        
        self.btn_apply_manual = QPushButton("🔄 Apply Offsets")
        self.btn_apply_manual.setStyleSheet("background-color: #2b579a; color: white; font-weight: bold;")
        self.btn_apply_manual.clicked.connect(self.apply_manual_offsets)
        
        btn_lay.addWidget(self.btn_reset_manual)
        btn_lay.addWidget(self.btn_apply_manual)
        
        side_layout.addLayout(btn_lay)

        div3b = QFrame()
        div3b.setFrameShape(HLine)
        div3b.setStyleSheet("color: #555; margin-top: 10px; margin-bottom: 10px;")
        side_layout.addWidget(div3b)

        self.lbl_tie_title = QLabel("<b>Georeferencer Tie Points</b>")
        side_layout.addWidget(self.lbl_tie_title)
        
        self.tbl_ties = QTableWidget()
        self.tbl_ties.setColumnCount(4)
        self.tbl_ties.setHorizontalHeaderLabels(["img U", "img V", "map X", "map Y"])
        try:
            self.tbl_ties.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        except AttributeError:
            self.tbl_ties.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        try:
            self.tbl_ties.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.tbl_ties.setSelectionBehavior(QAbstractItemView.SelectRows)
        except AttributeError:
            self.tbl_ties.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            self.tbl_ties.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl_ties.setMaximumHeight(150)
        self.tbl_ties.setStyleSheet("""
            QTableWidget { background-color: #333333; color: #FFFFFF; gridline-color: #666666; border: 1px solid #555555; }
            QTableWidget::item { color: #FFFFFF; }
            QHeaderView::section { background-color: #444444; color: #FFFFFF; padding: 4px; border: 1px solid #555555; font-weight: bold; }
            QTableCornerButton::section { background-color: #444444; border: 1px solid #555555; }
        """)
        self.tbl_ties.keyPressEvent = self.tbl_ties_keyPressEvent
        side_layout.addWidget(self.tbl_ties)
        
        tie_btns = QHBoxLayout()
        self.btn_calc_xy = QPushButton("Calibrate XY")
        self.btn_calc_xy.setStyleSheet("background-color: #0078D7; color: white; font-weight: bold;")
        self.btn_calc_xy.clicked.connect(self.calculate_xy_alignment)
        
        self.btn_calc_imu = QPushButton("Calibrate IMU")
        self.btn_calc_imu.setStyleSheet("background-color: #0078D7; color: white; font-weight: bold;")
        self.btn_calc_imu.clicked.connect(self.calculate_imu_alignment)
        
        self.btn_calc_3d = QPushButton("Full 3D")
        self.btn_calc_3d.setStyleSheet("background-color: #444; color: white;")
        self.btn_calc_3d.clicked.connect(self.calculate_3d_alignment)
        
        self.btn_clear_ties = QPushButton("🗑️")
        self.btn_clear_ties.setMaximumWidth(30)
        self.btn_clear_ties.clicked.connect(self.clear_tie_points)
        
        tie_btns.addWidget(self.btn_calc_xy)
        tie_btns.addWidget(self.btn_calc_imu)
        tie_btns.addWidget(self.btn_calc_3d)
        tie_btns.addWidget(self.btn_clear_ties)
        side_layout.addLayout(tie_btns)

        div4 = QFrame()
        div4.setFrameShape(HLine)
        div4.setStyleSheet("color: #555; margin-top: 10px; margin-bottom: 10px;")
        side_layout.addWidget(div4)
        
        self.lbl_export_title = QLabel("<b>Export Images</b>")
        side_layout.addWidget(self.lbl_export_title)
        
        btn_exp_lay = QHBoxLayout()
        self.btn_exp_curr = QPushButton("💾 Save Current")
        self.btn_exp_curr.setStyleSheet("background-color: #444; color: white;")
        self.btn_exp_curr.clicked.connect(self.export_current)
        
        self.btn_exp_all = QPushButton("💾 Batch Save All")
        self.btn_exp_all.setStyleSheet("background-color: #0078D7; color: white; font-weight: bold;")
        self.btn_exp_all.clicked.connect(self.export_all)
        
        btn_exp_lay.addWidget(self.btn_exp_curr)
        btn_exp_lay.addWidget(self.btn_exp_all)
        side_layout.addLayout(btn_exp_lay)

        side_layout.addStretch()
        self.view_splitter.addWidget(self.side_panel)

        center_col.addWidget(self.view_splitter, stretch=1)
        self.main_splitter.addWidget(center_widget)
        
        self.main_splitter.setSizes([200, 1200])
        self.view_splitter.setSizes([900, 300])
        
        for item_data in self.gallery_data:
            list_item = QListWidgetItem(item_data['name'])
            icon_path = item_data['proj_path'] if os.path.exists(item_data['proj_path']) else item_data['raw_path']
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                list_item.setIcon(QIcon(pixmap.scaled(160, 110, KeepAspectRatio)))
            self.filmstrip.addItem(list_item)
            
        self.filmstrip.currentRowChanged.connect(self.load_photo)
        
        self.map_rubberband = QgsRubberBand(self.map_canvas, QgsWkbTypes.LineGeometry) if self.map_canvas else None
        if self.map_rubberband:
            self.map_rubberband.setWidth(3)
            self.map_rubberband.setColor(QColor(255, 255, 0, 150))
            
        if 0 <= start_index < len(self.gallery_data):
            self.filmstrip.setCurrentRow(start_index)
        elif len(self.gallery_data) > 0:
            self.filmstrip.setCurrentRow(0)
            
        self.on_tab_changed(self.tabs.currentIndex())
        self._sync_ui_from_proj_style()

    def _on_scene_selection_changed(self):
        is_edit = (self.current_tool == 'edit')
        labels_on = self.btn_toggle_labels.isChecked()
        callouts_on = self.btn_toggle_callouts.isChecked()
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveAnchorItem):
                # Keep anchor active if either the label OR the anchor itself is selected
                is_active = False
                if item.label_item and item.label_item.isSelected():
                    is_active = True
                if item.isSelected():
                    is_active = True
                
                # Billboards always need their anchor because of the physical pole
                is_bb = False
                if item.label_item and isinstance(item.label_item.style_dict, dict):
                    is_bb = item.label_item.style_dict.get('preset') == "Billboard (Stand-up)"
                    
                if is_edit and labels_on and is_active and (callouts_on or is_bb):
                    item.setVisible(True)
                else:
                    item.setVisible(False)

    def toggle_all_labels(self):
        visible = self.btn_toggle_labels.isChecked()
        shadows_on = self.btn_toggle_shadows.isChecked()
        callouts_on = self.btn_toggle_callouts.isChecked()
        
        row = self.filmstrip.currentRow()
        overrides = self.gallery_data[row].get('overrides', {}).get('label_offsets', {}) if row >= 0 else {}
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveLabelItem):
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                actual_vis = visible and not is_hidden
                
                item.setVisible(actual_vis)
                if item.shadow_item: 
                    item.shadow_item.setVisible(actual_vis and shadows_on)
                
                is_bb = item.style_dict.get('preset') == "Billboard (Stand-up)"
                if item.bg_item:
                    item.bg_item.setVisible(actual_vis if is_bb else (actual_vis and callouts_on))
                    
            elif isinstance(item, InteractiveAnchorItem):
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                is_edit = (self.current_tool == 'edit')
                is_active = item.label_item and item.label_item.isSelected()
                item.setVisible(visible and is_edit and is_active and not is_hidden)

    def toggle_all_shadows(self):
        visible = self.btn_toggle_shadows.isChecked()
        labels_on = self.btn_toggle_labels.isChecked()
        
        row = self.filmstrip.currentRow()
        overrides = self.gallery_data[row].get('overrides', {}).get('label_offsets', {}) if row >= 0 else {}
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveLabelItem) and item.shadow_item:
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                item.shadow_item.setVisible(visible and labels_on and not is_hidden)

    def toggle_all_callouts(self):
        visible = self.btn_toggle_callouts.isChecked()
        labels_on = self.btn_toggle_labels.isChecked()
        
        row = self.filmstrip.currentRow()
        overrides = self.gallery_data[row].get('overrides', {}).get('label_offsets', {}) if row >= 0 else {}
        
        for item in self._projected_graphics:
            if isinstance(item, InteractiveLabelItem):
                is_hidden = overrides.get(item.feature_key, {}).get('hidden', False)
                is_bb = item.style_dict.get('preset') == "Billboard (Stand-up)"
                if not is_bb and item.bg_item:
                    item.bg_item.setVisible(visible and labels_on and not is_hidden)

    def _sync_ui_from_proj_style(self):
        layer_id = self.combo_proj_layer.currentData()
        if not layer_id or not hasattr(self.parent(), 'layer_list'): return
        
        self.proj_lbl_canvas.blockSignals(True)
        self.spin_proj_font.blockSignals(True)
        self.combo_proj_preset.blockSignals(True)
        self.combo_proj_bb_shape.blockSignals(True)
        self.dial_proj_angle.blockSignals(True)
        self.spin_callout_w.blockSignals(True)
        
        # Block signals for the new slider + spinbox combos
        self.slider_shadow_dist.blockSignals(True)
        self.spin_shadow_dist.blockSignals(True)
        self.slider_shadow_blur.blockSignals(True)
        self.spin_shadow_blur.blockSignals(True)
        
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer:
            self.proj_list_fields.clear()
            for f in layer.fields():
                self.proj_list_fields.addItem(f.name())
        
        for i in range(self.parent().layer_list.count()):
            item = self.parent().layer_list.item(i)
            if item.data(UserRole).id() == layer_id:
                style = item.data(UserRole + 1) or {}
                
                expr = style.get('label_expr', '')
                self.proj_lbl_canvas.setText(expr)
                if not expr.strip():
                    self.btn_toggle_labels.setChecked(False)
                else:
                    self.btn_toggle_labels.setChecked(True)
                    
                self.spin_proj_font.setValue(style.get('font_size', 48))
                
                c = style.get('label_color', (255, 255, 0, 255))
                self.btn_proj_color.setStyleSheet(f"background-color: rgba({c[0]},{c[1]},{c[2]},{c[3]}); border: 1px solid white;")
                
                hc = style.get('halo_color', (0, 0, 0, 255))
                self.btn_proj_halo.setStyleSheet(f"background-color: rgba({hc[0]},{hc[1]},{hc[2]},{hc[3]}); border: 1px solid white;")
                
                co = style.get('callout_color', (255, 255, 255, 255))
                self.btn_callout_color.setStyleSheet(f"background-color: rgba({co[0]},{co[1]},{co[2]},{co[3]}); border: 1px solid white;")
                self.spin_callout_w.setValue(style.get('callout_width', 5))
                
                idx = self.combo_proj_preset.findText(style.get('preset', 'Standard (Flat)'))
                if idx >= 0: self.combo_proj_preset.setCurrentIndex(idx)
                
                idx_shp = self.combo_proj_bb_shape.findText(style.get('billboard_shape', 'Rounded'))
                if idx_shp >= 0: self.combo_proj_bb_shape.setCurrentIndex(idx_shp)
                
                self.dial_proj_angle.setValue(style.get('light_angle', 45))
                
                # Update both the slider AND the spinbox together
                dist_val = style.get('shadow_dist', 15)
                self.slider_shadow_dist.setValue(dist_val)
                self.spin_shadow_dist.setValue(dist_val)
                
                blur_val = style.get('shadow_blur', 0)
                self.slider_shadow_blur.setValue(blur_val)
                self.spin_shadow_blur.setValue(blur_val)
                break
                
        self.proj_lbl_canvas.blockSignals(False)
        self.spin_proj_font.blockSignals(False)
        self.combo_proj_preset.blockSignals(False)
        self.combo_proj_bb_shape.blockSignals(False)
        self.dial_proj_angle.blockSignals(False)
        self.spin_callout_w.blockSignals(False)
        
        # Unblock signals for the new slider + spinbox combos
        self.slider_shadow_dist.blockSignals(False)
        self.spin_shadow_dist.blockSignals(False)
        self.slider_shadow_blur.blockSignals(False)
        self.spin_shadow_blur.blockSignals(False)

    def _pick_proj_color(self, target):
        layer_id = self.combo_proj_layer.currentData()
        if not layer_id or not hasattr(self.parent(), 'layer_list'): return
        
        for i in range(self.parent().layer_list.count()):
            item = self.parent().layer_list.item(i)
            if item.data(UserRole).id() == layer_id:
                style = item.data(UserRole + 1) or {}
                
                if target == 'text': c_tup = style.get('label_color', (255,255,0,255))
                elif target == 'callout': c_tup = style.get('callout_color', (255, 255, 255, 255))
                else: c_tup = style.get('halo_color', (0,0,0,255))
                
                init_c = QColor(*c_tup)
                color = QColorDialog.getColor(init_c, self, "Pick Color", ShowAlphaChannel)
                if color.isValid():
                    c_rgba = color.getRgb()
                    if target == 'text':
                        style['label_color'] = c_rgba
                        self.btn_proj_color.setStyleSheet(f"background-color: rgba({c_rgba[0]},{c_rgba[1]},{c_rgba[2]},{c_rgba[3]}); border: 1px solid white;")
                    elif target == 'callout':
                        style['callout_color'] = c_rgba
                        self.btn_callout_color.setStyleSheet(f"background-color: rgba({c_rgba[0]},{c_rgba[1]},{c_rgba[2]},{c_rgba[3]}); border: 1px solid white;")
                    else:
                        style['halo_color'] = c_rgba
                        self.btn_proj_halo.setStyleSheet(f"background-color: rgba({c_rgba[0]},{c_rgba[1]},{c_rgba[2]},{c_rgba[3]}); border: 1px solid white;")
                    item.setData(UserRole + 1, style)
                    self.render_projected_labels() 
                break

    def _on_proj_style_changed(self):
        layer_id = self.combo_proj_layer.currentData()
        if not layer_id or not hasattr(self.parent(), 'layer_list'): return
        
        for i in range(self.parent().layer_list.count()):
            item = self.parent().layer_list.item(i)
            if item.data(UserRole).id() == layer_id:
                style = item.data(UserRole + 1) or {}
                style['label_expr'] = self.proj_lbl_canvas.toPlainText()
                style['font_size'] = self.spin_proj_font.value()
                style['preset'] = self.combo_proj_preset.currentText()
                style['billboard_shape'] = self.combo_proj_bb_shape.currentText()
                style['light_angle'] = self.dial_proj_angle.value()
                style['shadow_dist'] = self.slider_shadow_dist.value()
                style['shadow_blur'] = self.slider_shadow_blur.value()
                style['callout_width'] = self.spin_callout_w.value()
                item.setData(UserRole + 1, style)
                break
                
        # Check if the change came from a rapid-fire slider/dial
        sender = self.sender()
        is_slider = sender and sender in [self.slider_shadow_dist, self.spin_shadow_dist, 
                                          self.slider_shadow_blur, self.spin_shadow_blur, 
                                          self.dial_proj_angle]
        
        if is_slider:
            # Update live items smoothly without recreating them
            for item in self._projected_graphics:
                if isinstance(item, InteractiveLabelItem):
                    item.style_dict = style
                    blur_val = style.get('shadow_blur', 0)
                    
                    if getattr(item, 'shadow_item', None):
                        effect = item.shadow_item.graphicsEffect()
                        if blur_val > 0:
                            if effect:
                                effect.setBlurRadius(blur_val)
                                effect.setEnabled(True)
                            else:
                                new_effect = QGraphicsBlurEffect()
                                new_effect.setBlurRadius(blur_val)
                                item.shadow_item.setGraphicsEffect(new_effect)
                        elif effect:
                            effect.setEnabled(False)
                            
                    item.update_visuals()
            self.proj_scene.update()
        else:
            # Only do a heavy structural rebuild if text, preset, or font size changed
            self.render_projected_labels()

    def save_anchor_override(self, feature_key, adx=0.0, ady=0.0):
        row = self.filmstrip.currentRow()
        if row < 0: return
        data = self.gallery_data[row]
        overrides = data.get('overrides', {})
        if 'label_offsets' not in overrides: overrides['label_offsets'] = {}
        
        current = overrides['label_offsets'].get(feature_key, {"cx_off": 0.0, "cy_off": 0.0, "hidden": False})
        current['adx'] = adx
        current['ady'] = ady
        overrides['label_offsets'][feature_key] = current
        data['overrides'] = overrides
        if hasattr(self.parent(), 'photo_list'):
            self.parent().photo_list.item(row).setData(UserRole + 1, overrides)

    def save_label_override(self, feature_key, cx_off=None, cy_off=None, hidden=None, color=None, size=None, reset=False):
        row = self.filmstrip.currentRow()
        if row < 0: return
        
        data = self.gallery_data[row]
        overrides = data.get('overrides', {})
        
        if 'label_offsets' not in overrides:
            overrides['label_offsets'] = {}
            
        if reset:
            if feature_key in overrides['label_offsets']:
                del overrides['label_offsets'][feature_key]
        else:
            current = overrides['label_offsets'].get(feature_key, {"cx_off": 0.0, "cy_off": 0.0, "hidden": False})
            if cx_off is not None: current['cx_off'] = cx_off
            if cy_off is not None: current['cy_off'] = cy_off
            if hidden is not None: current['hidden'] = hidden
            if color is not None: current['color'] = color
            if size is not None: current['size'] = size
            overrides['label_offsets'][feature_key] = current
            
        data['overrides'] = overrides
        
        if hasattr(self.parent(), 'photo_list'):
            list_item = self.parent().photo_list.item(row)
            list_item.setData(UserRole + 1, overrides)

    def tbl_ties_keyPressEvent(self, event):
        try:
            key_del = Qt.Key.Key_Delete
        except AttributeError:
            key_del = Qt.Key_Delete
            
        if event.key() == key_del:
            self.delete_selected_tie_point()
        else:
            QTableWidget.keyPressEvent(self.tbl_ties, event)

    def delete_selected_tie_point(self):
        selected_rows = [item.row() for item in self.tbl_ties.selectedItems()]
        if not selected_rows: return
        row = list(set(selected_rows))[0]
        reply = QMessageBox.question(self, "Delete Tie Point", f"Are you sure you want to delete Tie Point {row + 1}?", MsgYes | MsgNo, MsgNo)
        
        if reply == MsgYes:
            self.tie_points.pop(row)
            self.update_tie_point_table()
            self.draw_tie_points()

    def closeEvent(self, event):
        if hasattr(self, 'map_tie_markers'):
            for marker in self.map_tie_markers:
                self.map_canvas.scene().removeItem(marker)
        self.map_tie_markers = []
        super().closeEvent(event)

    def update_gallery(self, new_gallery_data, start_index):
        self.gallery_data = new_gallery_data
        self.filmstrip.blockSignals(True)
        self.filmstrip.clear()
        
        for item_data in self.gallery_data:
            list_item = QListWidgetItem(item_data['name'])
            icon_path = item_data['proj_path'] if os.path.exists(item_data['proj_path']) else item_data['raw_path']
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                list_item.setIcon(QIcon(pixmap.scaled(160, 110, KeepAspectRatio)))
            self.filmstrip.addItem(list_item)
            
        self.filmstrip.blockSignals(False)
        
        if 0 <= start_index < len(self.gallery_data):
            self.filmstrip.setCurrentRow(start_index)
        elif len(self.gallery_data) > 0:
            self.filmstrip.setCurrentRow(0)

    def refresh_live_sync(self):
        self.live_sync_timer.start()

    def _execute_live_sync(self):
        row = self.filmstrip.currentRow()
        if row >= 0 and row < len(self.gallery_data):
            self._run_single_projection(self.gallery_data[row], silent=True)

    def is_layer_valid(self, layer):
        try:
            return layer is not None and layer.isValid()
        except RuntimeError:
            return False

    def ensure_layers_valid(self):
        if not (self.is_layer_valid(getattr(self, 'pin_layer', None)) and 
                self.is_layer_valid(getattr(self, 'line_layer', None)) and 
                self.is_layer_valid(getattr(self, 'poly_layer', None))):
            self.setup_drawing_layers()

    def on_tab_changed(self, index):
        is_projected = (index == 1)
        self.btn_pin.setEnabled(is_projected)
        self.btn_line.setEnabled(is_projected)
        self.btn_poly.setEnabled(is_projected)
        self.btn_remove.setEnabled(is_projected)
        self.btn_edit.setEnabled(is_projected)
        self.btn_place.setEnabled(is_projected)
        
        if hasattr(self, 'btn_exp_curr'):
            self.btn_exp_curr.setEnabled(is_projected)
            self.btn_exp_all.setEnabled(is_projected)
        
        for i in range(self.filmstrip.count()):
            item_data = self.gallery_data[i]
            icon_path = item_data['proj_path'] if (is_projected and os.path.exists(item_data['proj_path'])) else item_data['raw_path']
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                self.filmstrip.item(i).setIcon(QIcon(pixmap.scaled(160, 110, KeepAspectRatio)))
            
            base_name = os.path.basename(item_data['raw_path'])
            if is_projected:
                self.filmstrip.item(i).setText(f"{base_name} [PROJ]")
            else:
                self.filmstrip.item(i).setText(f"{base_name} [RAW]")

        if not is_projected and self.current_tool not in ['pan', 'tie_point']:
            self.btn_pan.setChecked(True)
            self.on_tool_changed(self.btn_pan)

    def _render_photo_to_disk(self, data, dest_path):
        raw_path = data['raw_path']
        base_img = QImage(raw_path)
        if base_img.isNull(): return False
        
        scene = QGraphicsScene()
        scene.addPixmap(QPixmap.fromImage(base_img))
        
        overrides = data.get('overrides', {})
        active_pitch = overrides.get('pitch_offset', self.global_settings.get('pitch_offset', 0.0))
        active_yaw = overrides.get('yaw_offset', self.global_settings.get('yaw_offset', 0.0))
        active_dists = overrides.get('dist_offsets', self.global_settings.get('dist_offsets', {}))
        
        try:
            from ..core.metadata_parser import MetadataParser
            from ..core.math_engine import MathEngine
            from qgis.core import QgsProject
            
            lens_override = overrides.get('lens_override', None)
            tel = MetadataParser.extract_xmp(raw_path, active_dists, lens_override)
            active_geoid = overrides.get('geoid_offset', self.global_settings.get('geoid_offset', 0.0))
            if active_geoid == 0.0: 
                active_geoid = tel.get('auto_geoid', -18.0)
                
            safe_context = QgsProject.instance().transformContext()
            engine = MathEngine(tel, active_geoid, active_yaw, active_pitch, transform_context=safe_context)
            engine.drone_pos[0] -= overrides.get('x_offset', self.global_settings.get('x_offset', 0.0))
            engine.drone_pos[1] -= overrides.get('y_offset', self.global_settings.get('y_offset', 0.0))
            
            self._populate_scene_with_features(scene, engine, data['name'], tracking_list=None)
            
            rect = QRectF(0, 0, base_img.width(), base_img.height())
            
            export_image = QImage(base_img.width(), base_img.height(), Format_ARGB32_Premultiplied)
            export_image.fill(Transparent)
            
            painter = QPainter(export_image)
            painter.setRenderHint(RenderHintAntialiasing)
            painter.setRenderHint(SmoothPixmapTransform)
            
            scene.render(painter, target=rect, source=rect)
            painter.end()
            
            return export_image.save(dest_path, "JPG", 95)
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to render export for {data['name']}: {e}", "MavicProjector", Qgis.Warning)
            return False

    def export_current(self):
        data = self.gallery_data[self.filmstrip.currentRow()]
        dir_path = QFileDialog.getExistingDirectory(self, "Select Folder to Save Photo")
        if not dir_path: return
            
        out_name = os.path.basename(data['raw_path']).replace(".jpg", "_PROJECTED.jpg").replace(".JPG", "_PROJECTED.jpg")
        dest_path = os.path.join(dir_path, out_name)
        
        self.btn_exp_curr.setText("⏳ Saving...")
        self.btn_exp_curr.setEnabled(False)
        QgsApplication.processEvents()
        
        success = self._render_photo_to_disk(data, dest_path)
        
        self.btn_exp_curr.setText("💾 Save Current")
        self.btn_exp_curr.setEnabled(True)
        
        if success:
            QMessageBox.information(self, "Export", f"Exported to:\n{dest_path}")
        else:
            QMessageBox.warning(self, "Export Error", "Failed to render and save image. Please check directory permissions or logs.")

    def export_all(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Select Folder for Batch Export")
        if not dir_path: return
            
        self.btn_exp_all.setText("⏳ Saving All...")
        self.btn_exp_all.setEnabled(False)
        
        success_count = 0
        for data in self.gallery_data:
            out_name = os.path.basename(data['raw_path']).replace(".jpg", "_PROJECTED.jpg").replace(".JPG", "_PROJECTED.jpg")
            dest_path = os.path.join(dir_path, out_name)
            
            if self._render_photo_to_disk(data, dest_path):
                success_count += 1
            QgsApplication.processEvents()
                    
        self.btn_exp_all.setText("💾 Batch Save All")
        self.btn_exp_all.setEnabled(True)
        
        if success_count > 0:
            QMessageBox.information(self, "Batch Export", f"Successfully exported {success_count} photos (with visible viewer features) to:\n{dir_path}")
        else:
            QMessageBox.warning(self, "Batch Export", "Failed to render and save images. Please check directory permissions or logs.")

    def show_parameter_help(self):
        msg = (
            "<b>Manual Offset Parameters Guide</b><br><br>"
            "<b>Pitch:</b> Adjusts the camera's up/down tilt. Example: If the horizon is too high/low.<br>"
            "<b>Yaw (Crab Angle):</b> Adjusts the camera's left/right heading to counteract wind crabbing. Example: If features are systematically rotated left/right.<br>"
            "<b>X (E) / Y (N):</b> Nudges the camera's GPS position in meters (East/West or North/South). Example: If RTK drifted.<br>"
            "<b>Geoid Z:</b> Offsets the drone's altitude. Example: Adjusting RTK height to local ground level.<br>"
            "<b>k1, k2, k3:</b> Radial distortion coefficients. Example: Fixes 'fisheye' bulging or shrinking at the edges.<br>"
            "<b>p1, p2:</b> Tangential distortion coefficients. Example: Fixes lens misalignment causing slanted distortion."
        )
        QMessageBox.information(self, "Parameter Help", msg)

    def on_qgis_layer_changed(self, *args, **kwargs):
        if not self._is_plugin_editing:
            QTimer.singleShot(50, self.load_existing_features)

    def calculate_metrics_for_feature(self, layer, type_key, fid):
        if self._is_plugin_editing: 
            return
            
        self._is_plugin_editing = True
        try:
            feat = layer.getFeature(fid)
            if not feat.isValid(): return
            
            geom = feat.geometry()
            if geom.isNull(): return

            was_editable = layer.isEditable()
            if not was_editable: layer.startEditing()
            
            if type_key == 'line':
                length_m = geom.length()
                layer.changeAttributeValue(fid, layer.fields().indexOf("length_m"), round(length_m, 2))
                layer.changeAttributeValue(fid, layer.fields().indexOf("measurement"), f"{length_m:.1f} m")
            elif type_key == 'polygon':
                area_m2 = geom.area()
                length_m = geom.length()
                layer.changeAttributeValue(fid, layer.fields().indexOf("area_m2"), round(area_m2, 2))
                layer.changeAttributeValue(fid, layer.fields().indexOf("length_m"), round(length_m, 2))
                if area_m2 > 10000:
                    meas = f"{area_m2 / 10000:.2f} ha\nPeri: {length_m:.1f} m"
                else:
                    meas = f"{area_m2:.1f} m²\nPeri: {length_m:.1f} m"
                layer.changeAttributeValue(fid, layer.fields().indexOf("measurement"), meas)
            elif type_key == 'pin':
                pt = geom.asPoint() if not geom.isMultipart() else geom.asMultiPoint()[0]
                layer.changeAttributeValue(fid, layer.fields().indexOf("coord_xy"), f"{pt.x():.2f}, {pt.y():.2f}")
                layer.changeAttributeValue(fid, layer.fields().indexOf("measurement"), f"X: {pt.x():.1f}\nY: {pt.y():.1f}")
                
            if not was_editable: layer.commitChanges()
        finally:
            self._is_plugin_editing = False
            QTimer.singleShot(50, self.load_existing_features)

    def ensure_color_category(self, layer, geom_type, color_hex):
        renderer = layer.renderer()
        if not isinstance(renderer, QgsCategorizedSymbolRenderer):
            renderer = QgsCategorizedSymbolRenderer("color")
            
        has_color = False
        has_empty = False
        for cat in renderer.categories():
            if cat.value() == color_hex:
                has_color = True
            if cat.value() == "" or cat.value() is None:
                has_empty = True
                
        if has_color and has_empty:
            return 
            
        def _add_cat(hex_val, is_empty_fallback):
            c = QColor(255, 255, 0) if is_empty_fallback else QColor(hex_val)
            actual_hex = c.name()
            
            if geom_type == 'Point':
                sym = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': actual_hex, 'outline_color': '255,255,255,255', 'size': '4'})
                arrow = QgsSimpleMarkerSymbolLayer.create({'name': 'arrowhead', 'color': actual_hex, 'size': '8'})
                arrow.setOffset(QPointF(6, 0))
                arrow.setDataDefinedProperty(QgsSymbolLayer.PropertyAngle, QgsProperty.fromExpression("\"angle\" - 90")) 
                arrow.setDataDefinedProperty(QgsSymbolLayer.PropertySize, QgsProperty.fromExpression("if(\"angle\" IS NULL, 0, max(4, \"size\"))"))
                sym.appendSymbolLayer(arrow)
                sym.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.PropertySize, QgsProperty.fromExpression("max(2, \"size\" / 1.5)"))
                
            elif geom_type == 'LineString':
                sym = QgsLineSymbol.createSimple({'color': actual_hex, 'width': '1'})
                sym.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.PropertyStrokeWidth, QgsProperty.fromExpression("\"size\" / 5.0"))
                
            elif geom_type == 'Polygon':
                fill_c = QColor(c)
                fill_c.setAlpha(60)
                sym = QgsFillSymbol.createSimple({'color': '255,255,255,255', 'outline_color': actual_hex, 'outline_width': '1'})
                sym.symbolLayer(0).setFillColor(fill_c)
                sym.symbolLayer(0).setStrokeColor(c)
                sym.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.PropertyStrokeWidth, QgsProperty.fromExpression("\"size\" / 5.0"))

            cat_val = "" if is_empty_fallback else hex_val
            cat_label = "Default (Map Drawn)" if is_empty_fallback else f"Color: {hex_val.upper()}"
            cat = QgsRendererCategory(cat_val, sym, cat_label)
            renderer.addCategory(cat)

        if not has_color and color_hex:
            _add_cat(color_hex, False)
        if not has_empty:
            _add_cat("", True)
            
        layer.setRenderer(renderer.clone())
        layer.triggerRepaint()

    def setup_drawing_layers(self):
        def _get_or_create(layer_name, geom_type, fields):
            layers = QgsProject.instance().mapLayersByName(layer_name)
            layer = None
            for l in layers:
                try:
                    if l.isValid():
                        layer = l
                        break
                except RuntimeError:
                    pass
            
            if not layer:
                layer = QgsVectorLayer(f"{geom_type}?crs=EPSG:3301", layer_name, "memory")
                pr = layer.dataProvider()
                pr.addAttributes(fields)
                layer.updateFields()
                QgsProject.instance().addMapLayer(layer)
                
                settings = QgsPalLayerSettings()
                settings.fieldName = 'id'
                settings.placement = LabelPlacementOverPoint 
                text_format = QgsTextFormat()
                text_format.setSize(11)
                text_format.setColor(QColor(255, 255, 0))
                fnt = QFont()
                fnt.setBold(True)
                text_format.setFont(fnt)
                halo = QgsTextBufferSettings()
                halo.setEnabled(True)
                halo.setSize(1)
                halo.setColor(QColor("black"))
                text_format.setBuffer(halo)
                settings.setFormat(text_format)
                layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
                layer.setLabelsEnabled(True)
                
                try:
                    idx_c = layer.fields().indexOf("color")
                    if idx_c >= 0: layer.setDefaultValueDefinition(idx_c, QgsDefaultValue("'#FFFF00'"))
                    
                    idx_s = layer.fields().indexOf("size")
                    if idx_s >= 0: layer.setDefaultValueDefinition(idx_s, QgsDefaultValue("6"))
                    
                    idx_p = layer.fields().indexOf("persp")
                    if idx_p >= 0: layer.setDefaultValueDefinition(idx_p, QgsDefaultValue("true"))
                    
                    idx_ph = layer.fields().indexOf("photo")
                    if idx_ph >= 0: layer.setDefaultValueDefinition(idx_ph, QgsDefaultValue("'Map ' || format_date(now(), 'yyyy-MM-dd HH:mm:ss')"))
                except Exception:
                    pass
                    
            try:
                layer.featureAdded.disconnect()
                layer.featureDeleted.disconnect()
                layer.geometryChanged.disconnect()
                layer.attributeValueChanged.disconnect()
            except (TypeError, RuntimeError):
                pass
                
            return layer

        base_fields = [
            QgsField("id", QVariant.Int),
            QgsField("date", QVariant.String),
            QgsField("note", QVariant.String),
            QgsField("photo", QVariant.String),
            QgsField("measurement", QVariant.String), 
            QgsField("length_m", QVariant.Double),   
            QgsField("area_m2", QVariant.Double),     
            QgsField("color", QVariant.String),
            QgsField("size", QVariant.Int),
            QgsField("persp", QVariant.Bool)
        ]
        pin_fields = base_fields + [
            QgsField("angle", QVariant.Double), 
            QgsField("coord_xy", QVariant.String)     
        ]

        self.pin_layer = _get_or_create("Reverse Projection Pins", "Point", pin_fields)
        self.line_layer = _get_or_create("Reverse Projection Lines", "LineString", base_fields)
        self.poly_layer = _get_or_create("Reverse Projection Polygons", "Polygon", base_fields)

        self.current_ids = {'pin': 1, 'line': 1, 'polygon': 1}
        layer_mappings = [
            (self.pin_layer, 'pin', 'Point'), 
            (self.line_layer, 'line', 'LineString'), 
            (self.poly_layer, 'polygon', 'Polygon')
        ]

        for layer, type_key, geom_type in layer_mappings:
            if not isinstance(layer.renderer(), QgsCategorizedSymbolRenderer):
                layer.setRenderer(QgsCategorizedSymbolRenderer("color"))
            
            self.ensure_color_category(layer, geom_type, "")
            
            layer.featureDeleted.connect(self.on_qgis_layer_changed)
            layer.attributeValueChanged.connect(self.on_qgis_layer_changed)
            
            layer.featureAdded.connect(lambda fid, l=layer, tk=type_key: self.calculate_metrics_for_feature(l, tk, fid))
            layer.geometryChanged.connect(lambda fid, geom, l=layer, tk=type_key: self.calculate_metrics_for_feature(l, tk, fid))
            
            max_id = 0
            for f in layer.getFeatures():
                if f['id'] and isinstance(f['id'], int) and f['id'] > max_id:
                    max_id = f['id']
                col = f['color']
                if col:
                    self.ensure_color_category(layer, geom_type, col)
                    
            self.current_ids[type_key] = max_id + 1

    def on_tool_changed(self, button):
        tools = {0: 'pan', 1: 'pin', 2: 'line', 3: 'polygon', 4: 'remove', 5: 'tie_point', 6: 'edit', 7: 'place_label'}
        
        if self.tool_group.id(button) not in tools:
            return
            
        self.current_tool = tools[self.tool_group.id(button)]
        is_edit = (self.current_tool == 'edit')
        labels_on = self.btn_toggle_labels.isChecked()
        
        # Toggle label interactivity based on the current tool
        for item in self._projected_graphics:
            if isinstance(item, InteractiveAnchorItem):
                item.setFlag(GraphicsItemIsMovable, is_edit)
                if is_edit and labels_on and item.label_item and item.label_item.isSelected():
                    item.setVisible(True)
                else:
                    item.setVisible(False)
            elif isinstance(item, InteractiveLabelItem):
                item.setFlag(GraphicsItemIsMovable, is_edit)
        
        if self.current_tool == 'pan':
            self.proj_view.setDragMode(ScrollHandDrag)
            self.raw_view.setDragMode(ScrollHandDrag)
            self.hint.setText("")
        else:
            self.proj_view.setDragMode(NoDrag)
            self.raw_view.setDragMode(NoDrag)
            
            if self.current_tool == 'edit':
                self.hint.setText("↖️ Drag labels to move them. Select a label to reveal its anchor point. Right-click for colors.")
                self.main_side_tabs.setCurrentIndex(0)
            elif self.current_tool == 'place_label':
                self.hint.setText("🏷️ Click near a vector feature to restore/place its label directly under your mouse.")
                self.main_side_tabs.setCurrentIndex(0)
            elif self.current_tool == 'pin':
                self.hint.setText("📍 Left-click to Pin. Left-click & Drag to set Arrow direction.")
                self.main_side_tabs.setCurrentIndex(1)
                self.sym_tabs.setCurrentIndex(0)
            elif self.current_tool == 'line':
                self.hint.setText("📏 Left-click to drop points. Right-click to finish shape.")
                self.main_side_tabs.setCurrentIndex(1)
                self.sym_tabs.setCurrentIndex(1)
            elif self.current_tool == 'polygon':
                self.hint.setText("⬟ Left-click to drop points. Right-click to finish shape.")
                self.main_side_tabs.setCurrentIndex(1)
                self.sym_tabs.setCurrentIndex(2)
            elif self.current_tool == 'remove':
                self.hint.setText("🗑️ Left-click a drawn feature or label to delete/hide it.")
            elif self.current_tool == 'tie_point':
                self.hint.setText("🔗 GEOREFERENCER: Click a distinct point on the photo, then click the matching point on the Map.")
            
        self.clear_temp_drawing()

    def pick_color(self, t_key):
        ui = self.sym_ui[t_key]
        color = QColorDialog.getColor(ui['color'], self, f"Pick {t_key.title()} Color")
        if color.isValid():
            ui['color'] = color
            ui['btn_color'].setStyleSheet(f"background-color: {color.name()}; border: 1px solid white; height: 20px;")

    def keyPressEvent(self, event):
        if event.key() in (Key_Return, Key_Enter):
            if any(sb.hasFocus() for sb in [self.spin_man_pitch, self.spin_man_yaw, self.spin_man_x, self.spin_man_y, self.spin_man_geoid,
                                            self.spin_man_k1, self.spin_man_k2, self.spin_man_p1, self.spin_man_p2, self.spin_man_k3, self.combo_lens]):
                self.apply_manual_offsets()
                event.accept()
                return
            self.txt_feature_note.clearFocus()
            event.ignore()
            return
            
        elif event.key() == Key_Escape:
            self.clear_temp_drawing()
            event.accept()
            return
            
        elif event.key() == Key_Up and not self.txt_feature_note.hasFocus():
            r = self.filmstrip.currentRow()
            if r > 0: self.filmstrip.setCurrentRow(r - 1)
            event.accept()
            return
            
        elif event.key() == Key_Down and not self.txt_feature_note.hasFocus():
            r = self.filmstrip.currentRow()
            if r < self.filmstrip.count() - 1: self.filmstrip.setCurrentRow(r + 1)
            event.accept()
            return
            
        super().keyPressEvent(event)

    def reset_manual_offsets(self):
        data = self.gallery_data[self.filmstrip.currentRow()]
        data['overrides'] = {} 
        
        self.spin_man_pitch.blockSignals(True)
        self.spin_man_yaw.blockSignals(True)
        self.spin_man_x.blockSignals(True)
        self.spin_man_y.blockSignals(True)
        self.spin_man_geoid.blockSignals(True)
        self.combo_lens.blockSignals(True)
        
        self.spin_man_pitch.setValue(0.0)
        self.spin_man_yaw.setValue(0.0)
        self.spin_man_x.setValue(0.0)
        self.spin_man_y.setValue(0.0)
        self.combo_lens.setCurrentIndex(0)
        
        try:
            from ..core.metadata_parser import MetadataParser
            tel = MetadataParser.extract_xmp(data['raw_path'])
            self.spin_man_geoid.setValue(tel.get('auto_geoid', -18.0))
        except Exception:
            self.spin_man_geoid.setValue(0.0)
            
        self.spin_man_pitch.blockSignals(False)
        self.spin_man_yaw.blockSignals(False)
        self.spin_man_x.blockSignals(False)
        self.spin_man_y.blockSignals(False)
        self.spin_man_geoid.blockSignals(False)
        self.combo_lens.blockSignals(False)
        
        from ..compat_drone import UserRole
        if hasattr(self.parent(), 'photo_list'):
            list_item = self.parent().photo_list.item(self.filmstrip.currentRow())
            list_item.setData(UserRole + 1, {})
            import os
            list_item.setText(os.path.basename(data['raw_path']))
        
        self.apply_manual_offsets()

    def apply_manual_offsets(self):
        data = self.gallery_data[self.filmstrip.currentRow()]
        overrides = data.get('overrides', {})
        
        overrides['pitch_offset'] = self.spin_man_pitch.value()
        overrides['yaw_offset'] = self.spin_man_yaw.value()
        overrides['x_offset'] = self.spin_man_x.value()
        overrides['y_offset'] = self.spin_man_y.value()
        overrides['geoid_offset'] = self.spin_man_geoid.value()
        
        lens_val = self.combo_lens.currentText()
        if lens_val == "Force Wide": overrides['lens_override'] = 'Wide'
        elif lens_val == "Force Zoom": overrides['lens_override'] = 'Zoom'
        else: overrides.pop('lens_override', None)
        
        dist_offsets = {
            'k1': self.spin_man_k1.value(),
            'k2': self.spin_man_k2.value(),
            'p1': self.spin_man_p1.value(),
            'p2': self.spin_man_p2.value(),
            'k3': self.spin_man_k3.value()
        }
        overrides['dist_offsets'] = dist_offsets
        
        data['overrides'] = overrides
        
        if hasattr(self.parent(), 'photo_list'):
            list_item = self.parent().photo_list.item(self.filmstrip.currentRow())
            list_item.setData(UserRole + 1, overrides)
            import os
            base_name = os.path.basename(data['raw_path'])
            list_item.setText(f"{base_name} [Custom Offsets]")

        try:
            from ..core.metadata_parser import MetadataParser
            from ..core.math_engine import MathEngine
            from qgis.core import QgsProject
            
            raw_path = data['raw_path']
            lens_override = overrides.get('lens_override', 'Auto (From File)')
            tel = MetadataParser.extract_xmp(raw_path, dist_offsets, lens_override)
            
            active_geoid = overrides.get('geoid_offset', 0.0)
            if active_geoid == 0.0:
                active_geoid = tel.get('auto_geoid', -18.0)
                
            safe_context = QgsProject.instance().transformContext()
            
            self.engine = MathEngine(tel, active_geoid, overrides['yaw_offset'], overrides['pitch_offset'], transform_context=safe_context)
            self.engine.drone_pos[0] -= overrides['x_offset']
            self.engine.drone_pos[1] -= overrides['y_offset']
        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"Failed to update viewer engine: {e}", "MavicProjector", Qgis.Warning)
            
        self._run_single_projection(data)

    def _run_single_projection(self, data, silent=False):
        if self.temp_task:
            try:
                self.temp_task.cancel()
            except Exception:
                pass
            self.temp_task = None
                
        layer_items = []
        if hasattr(self.parent(), 'layer_list'):
            for i in range(self.parent().layer_list.count()):
                item = self.parent().layer_list.item(i)
                layer_items.append({
                    'layer': item.data(UserRole),
                    'style': item.data(UserRole + 1),
                    'selected_only': item.checkState() == Checked
                })
                
        if not layer_items:
            self.load_photo(self.filmstrip.currentRow(), keep_snaps=True)
            return
            
        photo_items = [{
            'path': data['raw_path'],
            'overrides': data.get('overrides', {})
        }]
        
        self._is_silent_projection = silent
        if not silent:
            self.btn_apply_manual.setText("⏳ Reprojecting Image...")
            self.btn_apply_manual.setEnabled(False)
            self.btn_reset_manual.setEnabled(False)
            
        self.btn_fast_refresh.setText("⏳ Extracting Labels...")
        self.btn_fast_refresh.setEnabled(False)
        
        from ..core.task_worker import ProjectionTask
        safe_context = QgsProject.instance().transformContext()
        
        self.temp_task = ProjectionTask(photo_items, layer_items, self.dem_layer, self.global_settings, transform_context=safe_context, interactive_mode=True)
        
        # Connect the progress bar signal
        self.temp_task.progressChanged.connect(self._update_refresh_btn_progress)
        
        self.temp_task.signals.log_signal.connect(lambda msg: QgsMessageLog.logMessage(msg, "MavicProjector", Qgis.Info))
        self.temp_task.signals.finished_signal.connect(self._on_single_projection_finished)
        QgsApplication.taskManager().addTask(self.temp_task)
        
    def _update_refresh_btn_progress(self, progress):
        self.btn_fast_refresh.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
            f"stop:0 #28a745, stop:{progress/100.0} #28a745, "
            f"stop:{min(1.0, (progress/100.0)+0.001)} #444, stop:1 #444); "
            f"color: white; font-weight: bold; text-align: center;"
        )
        self.btn_fast_refresh.setText(f"⏳ Extracting Labels... {int(progress)}%")

    def _on_single_projection_finished(self, success, err):
        
        if not self._is_silent_projection:
            self.btn_apply_manual.setText("🔄 Apply Offsets")
            self.btn_apply_manual.setEnabled(True)
            self.btn_reset_manual.setEnabled(True)
            
        self.btn_fast_refresh.setText("⚡ Refresh Labels Only")
        self.btn_fast_refresh.setStyleSheet("background-color: #28a745; color: white; font-weight: bold;")
        self.btn_fast_refresh.setEnabled(True)
        
        if success:
            QPixmapCache.clear() 
            row = self.filmstrip.currentRow()
            if row >= 0:
                data = self.gallery_data[row]
                
                if self.temp_task and hasattr(self.temp_task, 'projected_labels_data'):
                    self._projected_label_data = self.temp_task.projected_labels_data
                
                cache_dir = os.path.join(os.path.dirname(data['raw_path']), ".mavic_cache")
                cache_path = os.path.join(cache_dir, os.path.basename(data['raw_path']).replace(".jpg", "_TEMP.jpg"))
                
                img = QImage()
                if os.path.exists(cache_path): img.load(cache_path)
                elif os.path.exists(data['proj_path']): img.load(data['proj_path'])
                
                proj_pix = QPixmap.fromImage(img)
                
                if not proj_pix.isNull():
                    if hasattr(self, 'proj_bg_item') and self.proj_bg_item in self.proj_scene.items():
                        self.proj_bg_item.setPixmap(proj_pix)
                        QgsApplication.processEvents()
                        self.load_existing_features() 
                        self.render_projected_labels() 
                    else:
                        self.load_photo(row, keep_snaps=True)
        else:
            if not self._is_silent_projection:
                QMessageBox.warning(self, "Reprojection Failed", f"Failed to reproject image:\n{err}")
                
        self.temp_task = None

    def render_projected_labels(self):
        import math
        from qgis.PyQt.QtCore import QTimer
        from qgis.PyQt.QtWidgets import QPushButton
        
        # 1. The 5-Second Cooldown Lock
        if getattr(self, '_is_rendering_labels', False):
            return
        self._is_rendering_labels = True

        # Grab the sender to see if a manual button click triggered this
        trigger_btn = self.sender()
        is_button = isinstance(trigger_btn, QPushButton)
        
        original_text = ""
        original_style = ""
        if is_button:
            try:
                original_text = trigger_btn.text()
                original_style = trigger_btn.styleSheet()
                trigger_btn.setEnabled(False)
            except RuntimeError:
                is_button = False

        if not hasattr(self, '_graphics_trash_bin'):
            self._graphics_trash_bin = []

        # Use 5 seconds (50 ticks) for manual clicks, or 0.2s for automated system calls
        self._cooldown_ticks = 50 if is_button else 2 

        def tick_cooldown():
            # Safety check in case the user closes the dialog early
            if not hasattr(self, '_is_rendering_labels'): return 

            if self._cooldown_ticks > 0:
                if is_button:
                    try:
                        sec_left = math.ceil(self._cooldown_ticks / 10.0)
                        trigger_btn.setText(f"Refreshing... {sec_left}s")
                        
                        # Simulate a progress bar using a dynamic linear gradient
                        progress = 1.0 - (self._cooldown_ticks / 50.0)
                        progress = max(0.001, min(0.999, progress))
                        css = (
                            f"QPushButton {{"
                            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
                            f"stop:0 #0078D7, stop:{progress} #0078D7, "
                            f"stop:{progress + 0.001} #333333, stop:1 #333333); "
                            f"color: white; border: 1px solid #555; border-radius: 3px; padding: 5px;"
                            f"}}"
                        )
                        trigger_btn.setStyleSheet(css)
                    except RuntimeError:
                        pass
                        
                self._cooldown_ticks -= 1
                QTimer.singleShot(100, tick_cooldown)
            else:
                # Cooldown complete: restore button and empty the memory trash
                if is_button:
                    try:
                        trigger_btn.setText(original_text)
                        trigger_btn.setStyleSheet(original_style)
                        trigger_btn.setEnabled(True)
                    except RuntimeError:
                        pass
                
                self._is_rendering_labels = False
                if hasattr(self, '_graphics_trash_bin'):
                    self._graphics_trash_bin.clear()

        # Start the countdown and progress bar animation
        tick_cooldown()

        # --- 2. Proceed with Immediate Rendering ---
        if not self._projected_label_data:
            row = self.filmstrip.currentRow()
            if row >= 0:
                self._run_single_projection(self.gallery_data[row], silent=True)
            return

        self.proj_scene.blockSignals(True)

        selected_keys = set()
        for item in self.proj_scene.selectedItems():
            if hasattr(item, 'feature_key'):
                selected_keys.add(item.feature_key)

        for item in self._projected_graphics:
            try: 
                if hasattr(item, 'setGraphicsEffect'):
                    item.setGraphicsEffect(None)
                if item.scene() == self.proj_scene:
                    item.setSelected(False) 
                    item.hide() 
                    self.proj_scene.removeItem(item)
            except Exception: 
                pass
                
        # Move dead items to the trash bin to prevent C++ Access Violations
        self._graphics_trash_bin.extend(self._projected_graphics)
        self._projected_graphics.clear()
        
        if hasattr(self, 'proj_scene') and self.proj_scene:
            self.proj_scene.invalidate()

        row = self.filmstrip.currentRow()
        if row < 0: 
            self.proj_scene.blockSignals(False)
            return
            
        data = self.gallery_data[row]
        label_offsets = data.get('overrides', {}).get('label_offsets', {})

        if not hasattr(self.parent(), 'layer_list'): 
            self.proj_scene.blockSignals(False)
            return
        
        is_edit_mode = (self.current_tool == 'edit')
        global_shadows_on = self.btn_toggle_shadows.isChecked()
        global_labels_on = self.btn_toggle_labels.isChecked()
        global_callouts_on = self.btn_toggle_callouts.isChecked()
        
        for i in range(self.parent().layer_list.count()):
            item = self.parent().layer_list.item(i)
            layer = item.data(UserRole)
            style = item.data(UserRole + 1) or {}
            
            if not layer or not layer.isValid(): continue
            layer_id = layer.id()
            
            if layer_id not in self._projected_label_data: continue
            lbl_data_list = self._projected_label_data[layer_id]
            
            base_font_size = style.get('font_size', 48)
            base_color = style.get('label_color', (255, 255, 0, 255))
            c_c = style.get('callout_color', (150, 150, 150, 200))
            callout_color = QColor(c_c[0], c_c[1], c_c[2], c_c[3])
            
            callout_width = max(2, style.get('callout_width', 2)) 
            
            preset = style.get('preset', "Standard (Flat)")
            shadow_angle = style.get('light_angle', 45)
            shadow_dist = style.get('shadow_dist', 15)
            label_expr_str = style.get('label_expr', "")
            
            fids = [ld['fid'] for ld in lbl_data_list]
            request = QgsFeatureRequest().setFilterFids(fids)
            feature_dict = {f.id(): f for f in layer.getFeatures(request)}
            
            for ld in lbl_data_list:
                fid = ld['fid']
                feature_key = f"{layer_id}_{fid}"
                
                saved_override = label_offsets.get(feature_key, {})
                if saved_override.get("hidden", False): continue
                    
                feat = feature_dict.get(fid)
                if not feat: continue
                
                custom_scale = saved_override.get("size", 1.0)
                custom_color_tup = saved_override.get("color", None)
                final_color = QColor(*custom_color_tup) if custom_color_tup else QColor(*base_color)
                
                fnt = QFont()
                fnt.setPointSize(int(base_font_size * custom_scale))
                fnt.setBold(True)
                
                text_str = label_expr_str
                if text_str:
                    for fld in feat.fields():
                        placeholder = f"[{fld.name()}]"
                        if placeholder in text_str:
                            val = feat.attribute(fld.name())
                            text_str = text_str.replace(placeholder, str(val) if val is not None else "")
                            
                if not text_str.strip():
                    continue

                dummy_item = QGraphicsTextItem(text_str)
                dummy_item.setFont(fnt)
                br = dummy_item.boundingRect()
                del dummy_item

                anchor_x = ld['anchor_x']
                anchor_y = ld['anchor_y']
                
                cx_off = saved_override.get("cx_off")
                cy_off = saved_override.get("cy_off")
                adx = saved_override.get("adx", 0.0)
                ady = saved_override.get("ady", 0.0)
                
                true_anchor_x = anchor_x + adx
                true_anchor_y = anchor_y + ady
                
                is_billboard = (preset == "Billboard (Stand-up)")
                
                if cx_off is not None and cy_off is not None:
                    cx = anchor_x + cx_off
                    cy = anchor_y + cy_off
                else:
                    cx = anchor_x
                    cy = anchor_y - (max(15, abs(shadow_dist)) * custom_scale if is_billboard else 15 * custom_scale) - br.height() / 2.0

                lbl_item = InteractiveLabelItem(text_str, anchor_x, anchor_y, feature_key, self, style, custom_scale)
                lbl_item.setFont(fnt)
                lbl_item.setZValue(100)
                lbl_item.set_initial_center(cx, cy)
                
                anchor_item = InteractiveAnchorItem(anchor_x, anchor_y, feature_key, self, lbl_item)
                anchor_item.setPos(true_anchor_x, true_anchor_y) 
                anchor_item.setVisible(False) 
                anchor_item.setFlag(GraphicsItemIsMovable, is_edit_mode) 
                self.proj_scene.addItem(anchor_item)
                self._projected_graphics.append(anchor_item)
                lbl_item.anchor_item = anchor_item
                
                if is_billboard:
                    lbl_item.setDefaultTextColor(QColor("black"))
                    
                    bg_item = QGraphicsPathItem()
                    bg_item.setBrush(QBrush(QColor("white")))
                    bg_item.setPen(QPen(QColor("black"), max(2, int(4 * custom_scale))))
                    bg_item.setZValue(98)
                    bg_item.setVisible(global_labels_on)
                    self.proj_scene.addItem(bg_item)
                    self._projected_graphics.append(bg_item)
                    lbl_item.bg_item = bg_item
                    
                    bg_item_pole = QGraphicsPathItem()
                    bg_item_pole.setBrush(QBrush(QColor("white")))
                    bg_item_pole.setPen(QPen(QColor("black"), max(2, int(4 * custom_scale))))
                    bg_item_pole.setZValue(97.5) 
                    bg_item_pole.setVisible(global_labels_on)
                    self.proj_scene.addItem(bg_item_pole)
                    self._projected_graphics.append(bg_item_pole)
                    lbl_item.bg_item_pole = bg_item_pole
                    
                    shadow_item = QGraphicsPathItem()
                    shadow_item.setBrush(QBrush(QColor(0, 0, 0, 120)))
                    shadow_item.setPen(QPen(QColor(0, 0, 0, 0))) 
                    shadow_item.setZValue(97)
                    shadow_item.setVisible(global_shadows_on and global_labels_on)
                    
                    shadow_blur = style.get('shadow_blur', 0)
                    if shadow_blur > 0:
                        blur_effect = QGraphicsBlurEffect()
                        blur_effect.setBlurRadius(shadow_blur)
                        shadow_item.setGraphicsEffect(blur_effect)
                        
                    self.proj_scene.addItem(shadow_item)
                    self._projected_graphics.append(shadow_item)
                    lbl_item.shadow_item = shadow_item
                else:
                    lbl_item.setDefaultTextColor(final_color)
                    
                    bg_item = QGraphicsLineItem()
                    bg_item.setPen(QPen(callout_color, max(1, int(callout_width * custom_scale)), SolidLine, RoundCap))
                    bg_item.setZValue(98)
                    bg_item.setVisible(global_callouts_on and global_labels_on)
                    self.proj_scene.addItem(bg_item)
                    self._projected_graphics.append(bg_item)
                    lbl_item.bg_item = bg_item
                        
                    shadow_item = QGraphicsTextItem(text_str)
                    shadow_item.setFont(fnt)
                    shadow_item.setDefaultTextColor(QColor(0, 0, 0, 150))
                    shadow_item.setZValue(97)
                    rad = math.radians(shadow_angle)
                    shadow_item.base_sx = math.cos(rad) * shadow_dist
                    shadow_item.base_sy = -math.sin(rad) * shadow_dist
                    shadow_item.setVisible(global_shadows_on and global_labels_on)
                    shadow_blur = style.get('shadow_blur', 0)
                    if shadow_blur > 0:
                        blur_effect = QGraphicsBlurEffect()
                        blur_effect.setBlurRadius(shadow_blur)
                        blur_effect.setBlurHints(BlurPerformanceHint) 
                        shadow_item.setGraphicsEffect(blur_effect)
                        shadow_item.setCacheMode(DeviceCoordinateCache) 
                    self.proj_scene.addItem(shadow_item)
                    self._projected_graphics.append(shadow_item)
                    lbl_item.shadow_item = shadow_item

                lbl_item.setFlag(GraphicsItemIsMovable, is_edit_mode) 
                lbl_item.update_visuals()
                lbl_item.setVisible(global_labels_on)
                self.proj_scene.addItem(lbl_item)
                self._projected_graphics.append(lbl_item)
                
                if feature_key in selected_keys:
                    lbl_item.setSelected(True)

        self.proj_scene.blockSignals(False)
        self._on_scene_selection_changed()
        
        if hasattr(self, 'proj_scene') and self.proj_scene:
            self.proj_scene.update()

    def load_photo(self, index, keep_snaps=False):
        if index < 0 or index >= len(self.gallery_data): return
        
        current_tab_index = self.tabs.currentIndex()
        
        self.txt_feature_note.blockSignals(True)
        self.update_buttons()
        self.clear_temp_drawing()
        
        if not keep_snaps:
            self.active_qgis_fid = None
            if self.current_tool == 'tie_point':
                self.btn_pan.setChecked(True)
                self.on_tool_changed(self.btn_pan)
        
        self.lbl_detail_title.setText("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
        self.txt_feature_note.setText("")
        self.txt_feature_note.setEnabled(False)
        self.txt_feature_note.blockSignals(False)

        data = self.gallery_data[index]
        self.photo_name = data['name']
        self.setWindowTitle(f"Interactive Viewer: {self.photo_name}")
        
        raw_path = data['raw_path']
        proj_path = data['proj_path']
        overrides = data.get('overrides', {})
        
        active_pitch = overrides.get('pitch_offset', self.global_settings.get('pitch_offset', 0.0))
        active_yaw = overrides.get('yaw_offset', self.global_settings.get('yaw_offset', 0.0))
        active_geoid = overrides.get('geoid_offset', self.global_settings.get('geoid_offset', 0.0))
        
        active_x = overrides.get('x_offset', self.global_settings.get('x_offset', 0.0))
        active_y = overrides.get('y_offset', self.global_settings.get('y_offset', 0.0))
        
        active_dists = overrides.get('dist_offsets', self.global_settings.get('dist_offsets', {}))
        lens_override = overrides.get('lens_override', 'Auto (From File)')
        
        self.spin_man_pitch.blockSignals(True)
        self.spin_man_yaw.blockSignals(True)
        self.spin_man_x.blockSignals(True)
        self.spin_man_y.blockSignals(True)
        self.spin_man_geoid.blockSignals(True)
        self.spin_man_k1.blockSignals(True)
        self.spin_man_k2.blockSignals(True)
        self.spin_man_p1.blockSignals(True)
        self.spin_man_p2.blockSignals(True)
        self.spin_man_k3.blockSignals(True)
        self.combo_lens.blockSignals(True)
        
        self.spin_man_pitch.setValue(active_pitch)
        self.spin_man_yaw.setValue(active_yaw)
        self.spin_man_x.setValue(active_x)
        self.spin_man_y.setValue(active_y)
        self.spin_man_k1.setValue(active_dists.get('k1', 0.0))
        self.spin_man_k2.setValue(active_dists.get('k2', 0.0))
        self.spin_man_p1.setValue(active_dists.get('p1', 0.0))
        self.spin_man_p2.setValue(active_dists.get('p2', 0.0))
        self.spin_man_k3.setValue(active_dists.get('k3', 0.0))
        
        idx = self.combo_lens.findText(lens_override)
        if idx >= 0:
            self.combo_lens.setCurrentIndex(idx)
        elif lens_override == 'Wide':
            self.combo_lens.setCurrentIndex(1)
        elif lens_override == 'Zoom':
            self.combo_lens.setCurrentIndex(2)
        else:
            self.combo_lens.setCurrentIndex(0)
        
        try:
            from ..core.metadata_parser import MetadataParser
            from ..core.math_engine import MathEngine
            from qgis.core import QgsProject
            
            tel = MetadataParser.extract_xmp(raw_path, active_dists, lens_override)
            if active_geoid == 0.0:
                active_geoid = tel.get('auto_geoid', -18.0)
                
            self.spin_man_geoid.setValue(active_geoid)    
            safe_context = QgsProject.instance().transformContext()
            self.engine = MathEngine(tel, active_geoid, active_yaw, active_pitch, transform_context=safe_context)
            self.engine.drone_pos[0] -= active_x
            self.engine.drone_pos[1] -= active_y
            
        except Exception as e:
            QgsMessageLog.logMessage(f"Failed to build engine for {self.photo_name}: {e}", "DronePlugin", Qgis.Warning)
            
        self.spin_man_pitch.blockSignals(False)
        self.spin_man_yaw.blockSignals(False)
        self.spin_man_x.blockSignals(False)
        self.spin_man_y.blockSignals(False)
        self.spin_man_geoid.blockSignals(False)
        self.spin_man_k1.blockSignals(False)
        self.spin_man_k2.blockSignals(False)
        self.spin_man_p1.blockSignals(False)
        self.spin_man_p2.blockSignals(False)
        self.spin_man_k3.blockSignals(False)
        self.combo_lens.blockSignals(False)
            
        self.raw_scene.clear()
        raw_pix = QPixmap(raw_path)
        if not raw_pix.isNull():
            self.raw_bg_item = self.raw_scene.addPixmap(raw_pix)
            self.raw_view.fitInView(self.raw_scene.sceneRect(), KeepAspectRatio)
            
        self.proj_scene.clear()
        
        cache_dir = os.path.join(os.path.dirname(raw_path), ".mavic_cache")
        cache_path = os.path.join(cache_dir, os.path.basename(raw_path).replace(".jpg", "_TEMP.jpg"))
        
        load_path = cache_path if os.path.exists(cache_path) else proj_path
        
        if os.path.exists(load_path):
            proj_pix = QPixmap(load_path)
            if not proj_pix.isNull():
                self.proj_bg_item = self.proj_scene.addPixmap(proj_pix)
                self.proj_bg_item.setZValue(0)
                self.proj_view.fitInView(self.proj_scene.sceneRect(), KeepAspectRatio)
                self.tabs.setTabText(1, "2. Projected Vectors")
                if current_tab_index == 1:
                    self.tabs.setCurrentIndex(1)
                    
                QgsApplication.processEvents()
        else:
            self.tabs.setTabText(1, "2. Projected Vectors (Missing)")
            self.tabs.setCurrentIndex(0) 
            
        self.load_existing_features()
        
        if not self._projected_label_data:
            self.btn_fast_refresh.setText("⏳ Extracting Labels...")
            self._run_single_projection(data, silent=True)
        else:
            self.render_projected_labels()

    def get_world_z(self, x, y):
        z = self.fallback_z
        if self.dem_layer:
            ident = self.dem_layer.dataProvider().identify(QgsPointXY(x, y), IdentifyFormatValue)
            if ident.isValid() and ident.results() and 1 in ident.results() and ident.results()[1] is not None:
                z = float(ident.results()[1])
        return z

    def on_scene_pressed(self, u, v, button):
        if self.current_tool == 'pan': return
            
        if self.current_tool == 'remove' and button == LeftButton:
            item = self.proj_scene.itemAt(u, v, QTransform())
            if isinstance(item, InteractiveLabelItem):
                item.hide_label()
                return
            if item and item in self._persistent_graphics:
                self.remove_clicked_feature(item)
            return
            
        if self.current_tool == 'place_label' and button == LeftButton:
            layer_id = self.combo_proj_layer.currentData()
            if not layer_id or layer_id not in self._projected_label_data: return
            
            closest_ld = None
            min_dist = float('inf')
            
            for ld in self._projected_label_data[layer_id]:
                dist = math.hypot(ld['anchor_x'] - u, ld['anchor_y'] - v)
                if dist < min_dist:
                    min_dist = dist
                    closest_ld = ld
                    
            if closest_ld and min_dist < 1000:
                feature_key = f"{layer_id}_{closest_ld['fid']}"
                cx_off = u - closest_ld['anchor_x']
                cy_off = v - closest_ld['anchor_y']
                self.save_label_override(feature_key, cx_off=cx_off, cy_off=cy_off, hidden=False)
                self.render_projected_labels()
            return

        if self.current_tool == 'tie_point' and button == LeftButton:
            if not self.engine: return
            
            world_pt = self.engine.pixel_to_world(u, v, self.fallback_z)
            self.pending_u = u
            self.pending_v = v
            self.pending_z = self.get_world_z(world_pt.x(), world_pt.y()) if world_pt else self.fallback_z
            
            if hasattr(self.parent(), 'iface'):
                self.hide()
                self.prev_map_tool = self.map_canvas.mapTool()
                self.map_canvas.setMapTool(self.map_tool)
                self.parent().iface.messageBar().pushMessage("Georeferencer", "Click on the QGIS Map Canvas to match this point.", Qgis.Info, 5)
            return
            
        if not self.engine or button != LeftButton: return
            
        world_pt = self.engine.pixel_to_world(u, v, self.fallback_z)
        if not world_pt: return
        world_z = self.get_world_z(world_pt.x(), world_pt.y())
        world_pt = self.engine.pixel_to_world(u, v, world_z) 
        if not world_pt: return

        if self.current_tool == 'pin':
            self.pin_start_u = u
            self.pin_start_v = v
            self.temp_points = [{'u': u, 'v': v, 'x': world_pt.x(), 'y': world_pt.y(), 'z': world_z}]
            
        elif self.current_tool in ['line', 'polygon']:
            self.temp_points.append({'u': u, 'v': v, 'x': world_pt.x(), 'y': world_pt.y(), 'z': world_z})
            self.redraw_temp_graphics()

    def on_map_clicked(self, point, button):
        if self.prev_map_tool:
            self.map_canvas.setMapTool(self.prev_map_tool)
        self.show()
        
        if self.pending_u is None or self.pending_v is None:
            return
        
        tp = {
            'u': self.pending_u,
            'v': self.pending_v,
            'x': point.x(),
            'y': point.y(),
            'z': self.pending_z
        }
        self.tie_points.append(tp)
        self.update_tie_point_table()
        self.draw_tie_points()
        
        self.pending_u = None
        self.pending_v = None

    def update_tie_point_table(self):
        self.tbl_ties.setRowCount(len(self.tie_points))
        for row, tp in enumerate(self.tie_points):
            self.tbl_ties.setItem(row, 0, QTableWidgetItem(f"{tp['u']:.0f}"))
            self.tbl_ties.setItem(row, 1, QTableWidgetItem(f"{tp['v']:.0f}"))
            self.tbl_ties.setItem(row, 2, QTableWidgetItem(f"{tp['x']:.2f}"))
            self.tbl_ties.setItem(row, 3, QTableWidgetItem(f"{tp['y']:.2f}"))
            
        self.btn_calc_xy.setEnabled(len(self.tie_points) >= 1)
        self.btn_calc_imu.setEnabled(len(self.tie_points) >= 1) 
        self.btn_calc_3d.setEnabled(len(self.tie_points) >= 4)

    def draw_tie_points(self):
        for item in self.tie_point_graphics:
            try:
                if item.scene() == self.raw_scene: self.raw_scene.removeItem(item)
                if item.scene() == self.proj_scene: self.proj_scene.removeItem(item)
            except RuntimeError:
                pass 
        self.tie_point_graphics.clear()
        
        if hasattr(self, 'map_tie_markers'):
            for marker in self.map_tie_markers:
                self.map_canvas.scene().removeItem(marker)
        self.map_tie_markers = []
        
        crosshair_size = 40
        for i, tp in enumerate(self.tie_points):
            for scene in [self.raw_scene, self.proj_scene]:
                l1 = QGraphicsLineItem(tp['u']-crosshair_size, tp['v'], tp['u']+crosshair_size, tp['v'])
                l2 = QGraphicsLineItem(tp['u'], tp['v']-crosshair_size, tp['u'], tp['v']+crosshair_size)
                l1.setPen(QPen(QColor(0, 255, 0), 4))
                l2.setPen(QPen(QColor(0, 255, 0), 4))
                
                txt = QGraphicsTextItem(f"TP {i+1}")
                txt.setDefaultTextColor(QColor(0, 255, 0))
                fnt = QFont()
                fnt.setPointSize(20)
                fnt.setBold(True)
                txt.setFont(fnt)
                txt.setPos(tp['u']+5, tp['v']+5)
                
                scene.addItem(l1)
                scene.addItem(l2)
                scene.addItem(txt)
                self.tie_point_graphics.extend([l1, l2, txt])
                
            if self.map_canvas:
                from ..compat_drone import QgsVertexMarker
                marker = QgsVertexMarker(self.map_canvas)
                marker.setCenter(QgsPointXY(tp['x'], tp['y']))
                marker.setColor(QColor(0, 255, 0))
                marker.setIconSize(15)
                marker.setIconType(QgsVertexMarker.ICON_CROSS)
                marker.setPenWidth(3)
                self.map_tie_markers.append(marker)

    def clear_tie_points(self):
        self.tie_points.clear()
        self.update_tie_point_table()
        self.draw_tie_points()

    def calculate_xy_alignment(self):
        if not self.engine or len(self.tie_points) == 0: return
        
        result = self.engine.calibrate_xy(self.tie_points)
        if not result:
            QMessageBox.warning(self, "Calibration Failed", "Could not calculate XY shift.")
            return
            
        dx, dy = result
        
        self.spin_man_x.setValue(self.spin_man_x.value() - dx)
        self.spin_man_y.setValue(self.spin_man_y.value() - dy)
        self.apply_manual_offsets()
        
        QMessageBox.information(self, "Calibration Success", f"XY Shift Applied:\ndx: {dx:.2f}m\ndy: {dy:.2f}m")
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"XY Calibration Success: dx={dx:.2f}, dy={dy:.2f}", "MavicProjector", Qgis.Info)

    def calculate_imu_alignment(self):
        if not self.engine or len(self.tie_points) == 0: return
        
        result = self.engine.calibrate_imu(self.tie_points)
        if not result:
            QMessageBox.warning(self, "Calibration Failed", "Could not calculate IMU alignment.")
            return
            
        new_pitch_offset, new_yaw_offset = result
        
        self.spin_man_pitch.setValue(new_pitch_offset)
        self.spin_man_yaw.setValue(new_yaw_offset)
        self.apply_manual_offsets()
        
        QMessageBox.information(self, "IMU Calibration Success", 
            f"Locked RTK XYZ and mathematically solved for camera rotation:\n\n"
            f"New Pitch Offset: {new_pitch_offset:.2f}°\n"
            f"New Yaw (Crab) Offset: {new_yaw_offset:.2f}°")
        
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"IMU Calibration Success: dPitch={new_pitch_offset:.2f}, dYaw={new_yaw_offset:.2f}", "MavicProjector", Qgis.Info)

    def calculate_3d_alignment(self):
        if not self.engine or len(self.tie_points) < 4: return
        
        result = self.engine.calibrate_3d(self.tie_points)
        if not result:
            QMessageBox.warning(self, "Calibration Failed", "Could not converge on a 3D solution.")
            return
            
        dx, dy, dz, new_pitch_offset, new_yaw_offset = result
        
        current_alt = self.engine.drone_pos[2]
        if current_alt + dz < 10.0 or abs(dz) > (current_alt * 0.3):
            from ..compat_drone import MsgYes, MsgNo
            reply = QMessageBox.question(self, "Unstable 3D Math Detected", 
                f"The solver wants to alter the drone altitude by {abs(dz):.1f}m.\n\n"
                "Because your tie points are mostly flat on the ground, the 3D math cannot reliably determine depth, resulting in a wildly incorrect altitude shift. If applied, the vector lines will likely stretch or vanish.\n\n"
                "It is HIGHLY recommended to cancel this and use 'Calibrate XY Shift' instead. Apply anyway?", 
                MsgYes | MsgNo, MsgNo)
            if reply == MsgNo:
                return

        self.spin_man_x.setValue(self.spin_man_x.value() - dx)
        self.spin_man_y.setValue(self.spin_man_y.value() - dy)
        self.spin_man_geoid.setValue(self.spin_man_geoid.value() + dz)
        self.spin_man_pitch.setValue(new_pitch_offset)
        self.spin_man_yaw.setValue(new_yaw_offset)
        self.apply_manual_offsets()
        
        msg = f"3D Shift Applied:\ndx: {dx:.2f}m\ndy: {dy:.2f}m\ndz: {dz:.2f}m\nNew Pitch Offset: {new_pitch_offset:.2f}°\nNew Yaw Offset: {new_yaw_offset:.2f}°"
        QMessageBox.information(self, "Calibration Success", msg)
        
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"3D Calibration Success: dx={dx:.2f}, dy={dy:.2f}, dz={dz:.2f}", "MavicProjector", Qgis.Info)

    def on_scene_moved(self, u, v, buttons):
        if self.current_tool == 'pan': return
        if self.current_tool == 'remove': return
        if self.current_tool == 'edit': return
        if self.current_tool == 'place_label': return
        
        if self.current_tool == 'pin' and self.pin_start_u is not None:
            self.redraw_temp_graphics(cursor_u=u, cursor_v=v)
            
        elif self.current_tool in ['line', 'polygon'] and len(self.temp_points) > 0:
            self.redraw_temp_graphics(cursor_u=u, cursor_v=v)

    def on_scene_released(self, u, v, button):
        if self.current_tool == 'pan': return
        if self.current_tool == 'tie_point': return
        if self.current_tool == 'remove': return
        if self.current_tool == 'edit': return
        if self.current_tool == 'place_label': return
        
        if button == RightButton:
            if self.current_tool == 'line' and len(self.temp_points) >= 2:
                self.save_line_feature()
            elif self.current_tool == 'polygon' and len(self.temp_points) >= 3:
                self.save_polygon_feature()
            self.clear_temp_drawing()
            
        elif button == LeftButton and self.current_tool == 'pin' and self.pin_start_u is not None:
            self.save_pin_feature(u, v)
            self.clear_temp_drawing()

    def get_dynamic_scale(self, v, use_persp):
        return max(0.4, min(3.0, 0.4 + (v / 3000.0) * 2.0)) if use_persp else 1.0

    def redraw_temp_graphics(self, cursor_u=None, cursor_v=None):
        for item in self.temp_graphics:
            self.proj_scene.removeItem(item)
        self.temp_graphics.clear()

        ui = self.sym_ui[self.current_tool]
        curr_col = ui['color']
        base_size = ui['spin_size'].value()
        use_persp = ui['chk_persp'].isChecked()
        
        if self.current_tool == 'pin' and self.pin_start_u is not None and cursor_u is not None:
            scale = self.get_dynamic_scale(self.pin_start_v, use_persp)
            pen = QPen(curr_col, max(2, (base_size/1.5) * scale), SolidLine, RoundCap)
            
            line = QGraphicsLineItem(self.pin_start_u, self.pin_start_v, cursor_u, cursor_v)
            line.setPen(pen)
            self.proj_scene.addItem(line)
            self.temp_graphics.append(line)
            
            screen_angle = math.atan2(cursor_v - self.pin_start_v, cursor_u - self.pin_start_u)
            arr_size = (base_size * 3) * scale
            p1 = QPointF(cursor_u, cursor_v)
            p2 = QPointF(cursor_u - arr_size * math.cos(screen_angle - math.pi/6), cursor_v - arr_size * math.sin(screen_angle - math.pi/6))
            p3 = QPointF(cursor_u - arr_size * math.cos(screen_angle + math.pi/6), cursor_v - arr_size * math.sin(screen_angle + math.pi/6))
            arrowhead = QGraphicsPolygonItem(QPolygonF([p1, p2, p3]))
            arrowhead.setBrush(QBrush(curr_col))
            arrowhead.setPen(QPen(QColor(0,0,0,0)))
            self.proj_scene.addItem(arrowhead)
            self.temp_graphics.append(arrowhead)
            
        elif self.current_tool in ['line', 'polygon'] and self.temp_points:
            pts = [(p['u'], p['v']) for p in self.temp_points]
            world_pts = [(p['x'], p['y']) for p in self.temp_points]
            
            if cursor_u is not None:
                pts.append((cursor_u, cursor_v))
                
                live_world_pt = self.engine.pixel_to_world(cursor_u, cursor_v, self.fallback_z)
                if live_world_pt:
                    world_pts.append((live_world_pt.x(), live_world_pt.y()))
                
            total_length_m = 0.0
            for i in range(len(pts) - 1):
                scale = self.get_dynamic_scale(pts[i][1], use_persp)
                pen = QPen(curr_col, base_size * scale, SolidLine, RoundCap)
                line = QGraphicsLineItem(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])
                line.setPen(pen)
                self.proj_scene.addItem(line)
                self.temp_graphics.append(line)
                
                if i < len(world_pts) - 1:
                    dx = world_pts[i+1][0] - world_pts[i][0]
                    dy = world_pts[i+1][1] - world_pts[i][1]
                    total_length_m += math.hypot(dx, dy)
                
            if self.current_tool == 'polygon' and len(pts) >= 3:
                scale = self.get_dynamic_scale(pts[-1][1], use_persp)
                pen = QPen(curr_col, base_size * scale, DashLine, RoundCap)
                line = QGraphicsLineItem(pts[-1][0], pts[-1][1], pts[0][0], pts[0][1])
                line.setPen(pen)
                self.proj_scene.addItem(line)
                self.temp_graphics.append(line)
                
            for p in pts:
                scale = self.get_dynamic_scale(p[1], use_persp)
                rad = max(4, base_size) * scale
                ellipse = QGraphicsEllipseItem(p[0] - rad/2, p[1] - rad/2, rad, rad)
                ellipse.setBrush(QBrush(curr_col))
                self.proj_scene.addItem(ellipse)
                self.temp_graphics.append(ellipse)

            if self.map_rubberband and world_pts:
                geom_type = QgsWkbTypes.PolygonGeometry if self.current_tool == 'polygon' else QgsWkbTypes.LineGeometry
                self.map_rubberband.reset(geom_type)
                for wp in world_pts:
                    self.map_rubberband.addPoint(QgsPointXY(wp[0], wp[1]))

            if cursor_u is not None and cursor_v is not None and len(world_pts) > 1:
                display_text = f"{total_length_m:.1f} m"
                
                if self.current_tool == 'polygon' and len(world_pts) >= 3:
                    area = 0.0
                    for i in range(len(world_pts)):
                        j = (i + 1) % len(world_pts)
                        area += world_pts[i][0] * world_pts[j][1]
                        area -= world_pts[j][0] * world_pts[i][1]
                    area = abs(area) / 2.0
                    
                    if area > 10000: display_text = f"{area / 10000:.2f} ha\nPeri: {total_length_m:.1f} m"
                    else: display_text = f"{area:.1f} m²\nPeri: {total_length_m:.1f} m"

                meas_text = QGraphicsTextItem(display_text)
                meas_text.setDefaultTextColor(curr_col)
                fnt = QFont()
                fnt.setPointSize(int(14 * self.get_dynamic_scale(cursor_v, use_persp)))
                fnt.setBold(True)
                meas_text.setFont(fnt)
                
                shadow = QGraphicsTextItem(display_text)
                shadow.setFont(fnt)
                shadow.setDefaultTextColor(QColor(0,0,0, 200))
                
                meas_text.setPos(cursor_u + 15, cursor_v + 15)
                shadow.setPos(cursor_u + 17, cursor_v + 17)
                
                self.proj_scene.addItem(shadow)
                self.proj_scene.addItem(meas_text)
                self.temp_graphics.extend([shadow, meas_text])

    def clear_temp_drawing(self):
        for item in self.temp_graphics:
            self.proj_scene.removeItem(item)
        self.temp_graphics.clear()
        self.temp_points.clear()
        self.pin_start_u = None
        self.pin_start_v = None
        
        if self.map_rubberband:
            self.map_rubberband.reset()

    def save_pin_feature(self, end_u, end_v):
        self.ensure_layers_valid()
        pt = self.temp_points[0]
        world_angle = None
        screen_dist = math.hypot(end_u - pt['u'], end_v - pt['v'])
        
        if screen_dist > 5:
            world_pt2 = self.engine.pixel_to_world(end_u, end_v, pt['z'])
            if world_pt2:
                dx_w = world_pt2.x() - pt['x']
                dy_w = world_pt2.y() - pt['y']
                world_angle = (90.0 - math.degrees(math.atan2(dy_w, dx_w))) % 360.0

        ui = self.sym_ui['pin']
        color_hex = ui['color'].name()
        
        f = QgsFeature(self.pin_layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt['x'], pt['y'])))
        f.setAttribute("id", self.current_ids['pin'])
        f.setAttribute("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.setAttribute("note", "")
        f.setAttribute("photo", self.photo_name)
        f.setAttribute("angle", world_angle)
        f.setAttribute("color", color_hex)
        f.setAttribute("size", ui['spin_size'].value())
        f.setAttribute("persp", ui['chk_persp'].isChecked())
        f.setAttribute("coord_xy", f"{pt['x']:.2f}, {pt['y']:.2f}")
        f.setAttribute("measurement", f"X: {pt['x']:.1f}\nY: {pt['y']:.1f}")

        self._is_plugin_editing = True
        was_editable = self.pin_layer.isEditable()
        if not was_editable: self.pin_layer.startEditing()
        self.pin_layer.addFeature(f)
        if not was_editable: self.pin_layer.commitChanges()
        self._is_plugin_editing = False
        
        self.ensure_color_category(self.pin_layer, 'Point', color_hex)
        self.finalize_feature_save(self.pin_layer, 'pin', f)

    def save_line_feature(self):
        self.ensure_layers_valid()
        qgis_pts = [QgsPointXY(p['x'], p['y']) for p in self.temp_points]
        geom = QgsGeometry.fromPolylineXY(qgis_pts)
        
        length_m = geom.length()

        ui = self.sym_ui['line']
        color_hex = ui['color'].name()
        
        f = QgsFeature(self.line_layer.fields())
        f.setGeometry(geom)
        f.setAttribute("id", self.current_ids['line'])
        f.setAttribute("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.setAttribute("photo", self.photo_name)
        f.setAttribute("color", color_hex)
        f.setAttribute("size", ui['spin_size'].value())
        f.setAttribute("persp", ui['chk_persp'].isChecked())
        f.setAttribute("length_m", round(length_m, 2))
        f.setAttribute("measurement", f"{length_m:.1f} m")

        self._is_plugin_editing = True
        was_editable = self.line_layer.isEditable()
        if not was_editable: self.line_layer.startEditing()
        self.line_layer.addFeature(f)
        if not was_editable: self.line_layer.commitChanges()
        self._is_plugin_editing = False
        
        self.ensure_color_category(self.line_layer, 'LineString', color_hex)
        self.finalize_feature_save(self.line_layer, 'line', f)

    def save_polygon_feature(self):
        self.ensure_layers_valid()
        qgis_pts = [QgsPointXY(p['x'], p['y']) for p in self.temp_points]
        qgis_pts.append(qgis_pts[0]) 
        geom = QgsGeometry.fromPolygonXY([qgis_pts])
        
        area_m2 = geom.area()
        perimeter_m = geom.length()

        ui = self.sym_ui['polygon']
        color_hex = ui['color'].name()
        
        f = QgsFeature(self.poly_layer.fields())
        f.setGeometry(geom)
        f.setAttribute("id", self.current_ids['polygon'])
        f.setAttribute("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.setAttribute("photo", self.photo_name)
        f.setAttribute("color", color_hex)
        f.setAttribute("size", ui['spin_size'].value())
        f.setAttribute("persp", ui['chk_persp'].isChecked())
        f.setAttribute("area_m2", round(area_m2, 2))
        f.setAttribute("length_m", round(perimeter_m, 2))
        
        if area_m2 > 10000:
            f.setAttribute("measurement", f"{area_m2 / 10000:.2f} ha\nPeri: {perimeter_m:.1f} m")
        else:
            f.setAttribute("measurement", f"{area_m2:.1f} m²\nPeri: {perimeter_m:.1f} m")

        self._is_plugin_editing = True
        was_editable = self.poly_layer.isEditable()
        if not was_editable: self.poly_layer.startEditing()
        self.poly_layer.addFeature(f)
        if not was_editable: self.poly_layer.commitChanges()
        self._is_plugin_editing = False
        
        self.ensure_color_category(self.poly_layer, 'Polygon', color_hex)
        self.finalize_feature_save(self.poly_layer, 'polygon', f)

    def finalize_feature_save(self, layer, type_key, f):
        target_id = f["id"]
        
        real_fid = None
        for feat in layer.getFeatures():
            if feat["id"] == target_id:
                real_fid = feat.id()
                break
                
        new_fid = real_fid if real_fid is not None else f.id()
        
        self.active_qgis_layer = layer
        self.active_qgis_fid = new_fid
        self.lbl_detail_title.setText(f"<b>Editing {type_key.title()} {target_id}</b>")
        
        self.txt_feature_note.blockSignals(True)
        self.txt_feature_note.setEnabled(True)
        self.txt_feature_note.setText("")
        self.txt_feature_note.blockSignals(False)
        self.txt_feature_note.setFocus()
        
        action = {'layer': layer, 'feature_obj': QgsFeature(f)}
        self.undo_stack.append(action)
        if len(self.undo_stack) > 20: self.undo_stack.pop(0) 
        self.redo_stack.clear()
        self.update_buttons()
        
        self.current_ids[type_key] += 1
            
        layer.triggerRepaint()
        self.load_existing_features()

    def load_existing_features(self):
        self.ensure_layers_valid()
        for item in self._persistent_graphics:
            try:
                self.proj_scene.removeItem(item)
            except RuntimeError:
                pass
        self._persistent_graphics.clear()
        
        self._populate_scene_with_features(self.proj_scene, self.engine, self.photo_name, self._persistent_graphics)

    def _populate_scene_with_features(self, target_scene, engine, target_photo_name, tracking_list=None):
        if not engine: return
        self.ensure_layers_valid()
        
        layers = [
            (self.pin_layer, 'pin'),
            (self.line_layer, 'line'),
            (self.poly_layer, 'polygon')
        ]
        
        show_all = self.chk_show_all.isChecked()
        
        for layer, l_type in layers:
            if not self.is_layer_valid(layer): continue
                
            for feat in layer.getFeatures():
                photo_val = feat["photo"]
                is_map_feat = not photo_val or str(photo_val).strip() == "" or str(photo_val).startswith("Map")
                
                if not show_all and not is_map_feat and photo_val != target_photo_name: 
                    continue
                
                geom = feat.geometry()
                if geom.isNull(): continue
                
                col_attr = feat["color"]
                col = QColor(col_attr) if col_attr else QColor(255, 255, 0)
                
                base_size = feat["size"] if feat["size"] else 6
                use_persp = feat["persp"] if feat["persp"] is not None else True
                
                graphics_to_add = []
                avg_u, avg_v, avg_z, valid_pts = 0, 0, 0, 0
                
                if l_type == 'pin':
                    pt = geom.asPoint()
                    ground_z = self.get_world_z(pt.x(), pt.y())
                    uv = engine.project_world_to_2d(pt.x(), pt.y(), ground_z)
                    if not uv: continue
                    u, v, z = uv
                    avg_u, avg_v, avg_z, valid_pts = u, v, ground_z, 1
                    
                    scale = self.get_dynamic_scale(v, use_persp)
                    
                    angle = feat["angle"]
                    if isinstance(angle, (int, float)):
                        ex = pt.x() + 15.0 * math.sin(math.radians(angle))
                        ey = pt.y() + 15.0 * math.cos(math.radians(angle))
                        end_ground_z = self.get_world_z(ex, ey)
                        end_uv = engine.project_world_to_2d(ex, ey, end_ground_z)
                        
                        if end_uv:
                            eu, ev, _ = end_uv
                            screen_angle = math.atan2(ev - v, eu - u)
                            
                            tick_len = max(20.0, 40.0 * scale)
                            arr_u = u + tick_len * math.cos(screen_angle)
                            arr_v = v + tick_len * math.sin(screen_angle)
                            
                            line = QGraphicsLineItem(u, v, arr_u, arr_v)
                            line.setPen(QPen(col, max(2, (base_size/1.5) * scale), SolidLine, RoundCap))
                            line.setZValue(50)
                            target_scene.addItem(line)
                            graphics_to_add.append(line)
                            
                            arr_size = (base_size * 3) * scale
                            p1 = QPointF(arr_u, arr_v)
                            p2 = QPointF(arr_u - arr_size * math.cos(screen_angle - math.pi/6), arr_v - arr_size * math.sin(screen_angle - math.pi/6))
                            p3 = QPointF(arr_u - arr_size * math.cos(screen_angle + math.pi/6), arr_v - arr_size * math.sin(screen_angle + math.pi/6))
                            arrowhead = QGraphicsPolygonItem(QPolygonF([p1, p2, p3]))
                            arrowhead.setBrush(QBrush(col))
                            arrowhead.setPen(QPen(QColor(0,0,0,0)))
                            arrowhead.setZValue(50)
                            target_scene.addItem(arrowhead)
                            graphics_to_add.append(arrowhead)

                    rad = (base_size * 4) * scale
                    ellipse = QGraphicsEllipseItem(u - rad/2, v - rad/2, rad, rad)
                    ellipse.setBrush(QBrush(col))
                    ellipse.setPen(QPen(QColor(255,255,255), max(1, (base_size/2) * scale))) 
                    ellipse.setZValue(50)
                    target_scene.addItem(ellipse)
                    graphics_to_add.append(ellipse)

                elif l_type in ['line', 'polygon']:
                    is_multi = geom.isMultipart()
                    if l_type == 'polygon':
                        parts = [ring for poly in geom.asMultiPolygon() for ring in poly] if is_multi else [geom.asPolygon()[0]]
                    else:
                        parts = geom.asMultiPolyline() if is_multi else [geom.asPolyline()]
                    
                    for ring in parts:
                        poly_pts = []
                        ring_3d_cam = []
                        for pt in ring:
                            rel_x = pt.x() - engine.drone_pos[0]
                            rel_y = pt.y() - engine.drone_pos[1]
                            rel_z = self.get_world_z(pt.x(), pt.y()) - engine.drone_pos[2]
                            ring_3d_cam.append([rel_x, rel_y, rel_z])
                            
                        ring_3d = engine.get_3d_camera_points([QgsPointXY(pt.x(), pt.y()) for pt in ring], self.fallback_z, self.dem_layer)
                            
                        valid_3d = []
                        for pt in ring_3d:
                            if pt[2] > 0: valid_3d.append(pt)
                            
                        if valid_3d:
                            proj_pts = engine.project_3d_to_2d_batch(valid_3d)
                            for (u, v, z) in proj_pts:
                                poly_pts.append(QPointF(u, v))
                                avg_u += u
                                avg_v += v
                                avg_z += z
                                valid_pts += 1
                                
                        if len(poly_pts) > 1:
                            if l_type == 'polygon':
                                p_item = QGraphicsPolygonItem(QPolygonF(poly_pts))
                                fill_col = QColor(col)
                                fill_col.setAlpha(60)
                                p_item.setBrush(QBrush(fill_col))
                                scale = self.get_dynamic_scale(poly_pts[0].y(), use_persp)
                                p_item.setPen(QPen(col, base_size * scale, SolidLine, RoundCap))
                                p_item.setZValue(40)
                                target_scene.addItem(p_item)
                                graphics_to_add.append(p_item)
                            else:
                                for i in range(len(poly_pts)-1):
                                    scale = self.get_dynamic_scale(poly_pts[i].y(), use_persp)
                                    l_item = QGraphicsLineItem(poly_pts[i].x(), poly_pts[i].y(), poly_pts[i+1].x(), poly_pts[i+1].y())
                                    l_item.setPen(QPen(col, base_size * scale, SolidLine, RoundCap))
                                    l_item.setZValue(40)
                                    target_scene.addItem(l_item)
                                    graphics_to_add.append(l_item)

                if valid_pts > 0:
                    avg_u /= valid_pts
                    avg_v /= valid_pts
                    scale = self.get_dynamic_scale(avg_v, use_persp)
                    
                    field_name = self.sym_ui[l_type]['combo_label'].currentText()
                    lbl_val = feat.attribute(field_name)
                    lbl_item = QGraphicsTextItem(str(lbl_val) if lbl_val else "")
                    fnt = QFont()
                    fnt.setPointSize(int(36 * scale))
                    fnt.setBold(True)
                    lbl_item.setFont(fnt)
                    lbl_item.setDefaultTextColor(QColor("white"))
                    
                    shadow = QGraphicsTextItem(str(lbl_val) if lbl_val else "")
                    shadow.setFont(fnt)
                    shadow.setDefaultTextColor(QColor(0,0,0,150))
                    
                    br = lbl_item.boundingRect()
                    y_offset = avg_v - br.height() - (15 * scale)
                    shadow.setPos(avg_u - (br.width() / 2) + 3, y_offset + 3)
                    lbl_item.setPos(avg_u - (br.width() / 2), y_offset)
                    
                    shadow.setZValue(49)
                    lbl_item.setZValue(50)
                    
                    target_scene.addItem(shadow)
                    target_scene.addItem(lbl_item)
                    graphics_to_add.extend([shadow, lbl_item])
                
                for g_item in graphics_to_add:
                    g_item.setData(0, feat.id())
                    g_item.setData(1, layer.id())
                    
                if tracking_list is not None:
                    tracking_list.extend(graphics_to_add)

    def change_map_label(self, t_key, field_name):
        self.ensure_layers_valid()
        layer_map = {'pin': self.pin_layer, 'line': self.line_layer, 'polygon': self.poly_layer}
        layer = layer_map.get(t_key)
        if not self.is_layer_valid(layer): return
        
        labeling = layer.labeling()
        if labeling:
            settings = labeling.settings()
            settings.fieldName = field_name
            layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            layer.triggerRepaint()
            self.load_existing_features()

    def on_note_typing(self, text):
        if not getattr(self, 'active_qgis_fid', None) or not getattr(self, 'active_qgis_layer', None): return
        for action in self.undo_stack:
            if hasattr(action.get('feature_obj'), 'id') and action['feature_obj'].id() == self.active_qgis_fid:
                action['feature_obj'].setAttribute("note", text)
                break

    def save_note_to_qgis(self):
        if not getattr(self, 'active_qgis_fid', None) or not self.is_layer_valid(getattr(self, 'active_qgis_layer', None)): return
        text = self.txt_feature_note.text()
        note_idx = self.active_qgis_layer.fields().indexOf("note")
        if note_idx != -1:
            self._is_plugin_editing = True
            was_editable = self.active_qgis_layer.isEditable()
            if not was_editable: self.active_qgis_layer.startEditing()
            self.active_qgis_layer.changeAttributeValue(self.active_qgis_fid, note_idx, text)
            if not was_editable: self.active_qgis_layer.commitChanges()
            self._is_plugin_editing = False
            
            self.active_qgis_layer.triggerRepaint()
            self.load_existing_features()

    def update_buttons(self):
        self.btn_undo.setEnabled(len(self.undo_stack) > 0)
        self.btn_redo.setEnabled(len(self.redo_stack) > 0)

    def undo_action(self):
        self.txt_feature_note.clearFocus()
        layer = None
        while self.undo_stack:
            action = self.undo_stack.pop()
            layer = action.get('layer')
            if self.is_layer_valid(layer):
                break
            else:
                layer = None
                
        if not layer:
            self.update_buttons()
            return
            
        custom_id = action['feature_obj'].attribute("id")
        
        real_fid = None
        for feat in layer.getFeatures():
            if feat["id"] == custom_id:
                real_fid = feat.id()
                break
                
        if real_fid is not None:
            self._is_plugin_editing = True
            was_editable = layer.isEditable()
            if not was_editable: layer.startEditing()
            layer.deleteFeature(real_fid)
            if not was_editable: layer.commitChanges()
            layer.triggerRepaint()
            self._is_plugin_editing = False
            
        if self.active_qgis_fid == real_fid:
            self.active_qgis_fid = None
            self.active_qgis_layer = None
            self.lbl_detail_title.setText("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
            self.txt_feature_note.setText("")
            self.txt_feature_note.setEnabled(False)

        self.redo_stack.append(action)
        self.load_existing_features()
        self.update_buttons()

    def redo_action(self):
        layer = None
        while self.redo_stack:
            action = self.redo_stack.pop()
            layer = action.get('layer')
            if self.is_layer_valid(layer):
                break
            else:
                layer = None
                
        if not layer:
            self.update_buttons()
            return
        
        self._is_plugin_editing = True
        was_editable = layer.isEditable()
        if not was_editable: layer.startEditing()
        
        new_feat = QgsFeature(action['feature_obj'])
        layer.addFeature(new_feat)
        
        if not was_editable: layer.commitChanges()
        layer.triggerRepaint()
        self._is_plugin_editing = False
        
        action['feature_obj'] = QgsFeature(new_feat)
        
        self.undo_stack.append(action)
        self.load_existing_features()
        self.update_buttons()

    def remove_clicked_feature(self, item):
        layer_id = item.data(1)
        feat_id = item.data(0)
        
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer and layer.isValid():
            self._is_plugin_editing = True
            was_editable = layer.isEditable()
            if not was_editable: layer.startEditing()
            layer.deleteFeature(feat_id)
            if not was_editable: layer.commitChanges()
            self._is_plugin_editing = False
            layer.triggerRepaint()
            self.load_existing_features()

    def clear_all_features(self):
        reply = QMessageBox.question(self, 'Clear Photo', f'Are you sure you want to delete all drawn objects on {self.photo_name}?',
                                     MsgYes | MsgNo, MsgNo)
        if reply == MsgYes:
            self.txt_feature_note.blockSignals(True)
            
            self._is_plugin_editing = True
            self.ensure_layers_valid()
            for layer in [self.pin_layer, self.line_layer, self.poly_layer]:
                if not self.is_layer_valid(layer): continue
                fids = [f.id() for f in layer.getFeatures() if f["photo"] == self.photo_name]
                if fids:
                    was_editable = layer.isEditable()
                    if not was_editable: layer.startEditing()
                    layer.deleteFeatures(fids)
                    if not was_editable: layer.commitChanges()
                    layer.triggerRepaint()
            self._is_plugin_editing = False
                
            for item in self._persistent_graphics:
                try: 
                    self.proj_scene.removeItem(item)
                except RuntimeError: 
                    pass
            self._persistent_graphics.clear()
                
            self.active_qgis_fid = None
            self.active_qgis_layer = None
            self.lbl_detail_title.setText("<b>Feature Details</b><br><span style='color:#aaa; font-size:10px;'>Select a tool and draw.</span>")
            self.txt_feature_note.setText("")
            self.txt_feature_note.setEnabled(False)
            self.txt_feature_note.blockSignals(False)

            self.undo_stack.clear()
            self.redo_stack.clear()
            self.update_buttons()