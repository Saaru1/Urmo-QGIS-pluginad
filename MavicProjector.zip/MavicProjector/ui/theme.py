"""
Cohesive Dark & Light QSS themes for MavicProjector (PyQt5 / QGIS 3 and PyQt6 / QGIS 4).
"""
from ..core.i18n import ui_prefs


PALETTES = {
    "dark": {
        "bg": "#1a1e26",
        "surface": "#232834",
        "surface_alt": "#2b3140",
        "input_bg": "#151921",
        "border": "#394152",
        "border_focus": "#3b82f6",
        "text": "#eef2f7",
        "text_muted": "#9aa5b5",
        "hint_text": "#7dd3fc",
        "primary": "#2563eb",
        "primary_hover": "#3b82f6",
        "success": "#059669",
        "success_hover": "#10b981",
        "danger": "#dc2626",
        "danger_hover": "#ef4444",
        "accent": "#d97706",
        "accent_hover": "#f59e0b",
        "cyan": "#0891b2",
        "cyan_hover": "#06b6d4",
        "tab_bg": "#202530",
        "tab_selected": "#2e3647",
        "log_bg": "#11141a",
        "log_fg": "#4ade80",
        "header_bg": "#151922",
        "table_grid": "#394152",
        "selection_bg": "#2563eb",
        "selection_fg": "#ffffff",
    },
    "light": {
        "bg": "#f1f5f9",
        "surface": "#ffffff",
        "surface_alt": "#f8fafc",
        "input_bg": "#ffffff",
        "border": "#cbd5e1",
        "border_focus": "#2563eb",
        "text": "#0f172a",
        "text_muted": "#475569",
        "hint_text": "#0369a1",
        "primary": "#2563eb",
        "primary_hover": "#1d4ed8",
        "success": "#059669",
        "success_hover": "#047857",
        "danger": "#dc2626",
        "danger_hover": "#b91c1c",
        "accent": "#d97706",
        "accent_hover": "#b45309",
        "cyan": "#0e7490",
        "cyan_hover": "#0891b2",
        "tab_bg": "#e2e8f0",
        "tab_selected": "#ffffff",
        "log_bg": "#f8fafc",
        "log_fg": "#0f172a",
        "header_bg": "#e2e8f0",
        "table_grid": "#cbd5e1",
        "selection_bg": "#2563eb",
        "selection_fg": "#ffffff",
    },
}


def get_palette(theme_name=None):
    name = (theme_name or ui_prefs.theme).lower()
    return PALETTES["light"] if name == "light" else PALETTES["dark"]


def build_stylesheet(theme_name=None):
    p = get_palette(theme_name)
    return f"""
    QDialog, QDockWidget, QWidget#MavicRoot {{
        background-color: {p['bg']};
        color: {p['text']};
        font-family: "Segoe UI", "Inter", sans-serif;
        font-size: 12px;
    }}
    QLabel {{
        color: {p['text']};
        background: transparent;
    }}
    QLabel[role="title"] {{
        font-size: 13px;
        font-weight: 700;
        color: {p['text']};
    }}
    QLabel[role="section"] {{
        font-size: 12px;
        font-weight: 700;
        color: {p['text']};
        padding-bottom: 2px;
    }}
    QLabel[role="muted"] {{
        color: {p['text_muted']};
        font-size: 11px;
    }}
    QLabel[role="hint"] {{
        color: {p['hint_text']};
        font-weight: 600;
        font-size: 12px;
    }}
    QFrame[role="card"] {{
        background-color: {p['surface']};
        border: 1px solid {p['border']};
        border-radius: 6px;
    }}
    QFrame[role="header"] {{
        background-color: {p['header_bg']};
        border-bottom: 1px solid {p['border']};
        border-radius: 4px;
    }}
    QFrame[role="infoBanner"] {{
        background-color: {p['surface_alt']};
        border: 1px solid {p['border']};
        border-left: 3px solid {p['primary']};
        border-radius: 4px;
    }}
    QScrollArea {{
        background: transparent;
        border: none;
    }}
    QScrollArea > QWidget > QWidget {{
        background: transparent;
    }}
    QTabWidget::pane {{
        border: 1px solid {p['border']};
        background-color: {p['surface']};
        border-radius: 4px;
    }}
    QTabBar::tab {{
        background-color: {p['tab_bg']};
        color: {p['text_muted']};
        border: 1px solid {p['border']};
        border-bottom: none;
        padding: 4px 8px;
        margin-right: 2px;
        font-size: 11px;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
    }}
    QTabBar::tab:selected {{
        background-color: {p['tab_selected']};
        color: {p['text']};
        font-weight: 700;
    }}
    QLineEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
        background-color: {p['input_bg']};
        color: {p['text']};
        border: 1px solid {p['border']};
        border-radius: 4px;
        padding: 3px 6px;
        selection-background-color: {p['selection_bg']};
        selection-color: {p['selection_fg']};
    }}
    QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
        border: 1px solid {p['border_focus']};
    }}
    QComboBox QAbstractItemView {{
        background-color: {p['surface']};
        color: {p['text']};
        border: 1px solid {p['border']};
        selection-background-color: {p['selection_bg']};
        selection-color: {p['selection_fg']};
    }}
    QListWidget {{
        background-color: {p['input_bg']};
        color: {p['text']};
        border: 1px solid {p['border']};
        border-radius: 5px;
        alternate-background-color: {p['surface_alt']};
        outline: none;
    }}
    QListWidget[role="dropzone"] {{
        border: 2px dashed {p['border']};
    }}
    QListWidget::item:selected {{
        background-color: {p['selection_bg']};
        color: {p['selection_fg']};
    }}
    QTableWidget {{
        background-color: {p['input_bg']};
        color: {p['text']};
        gridline-color: {p['table_grid']};
        border: 1px solid {p['border']};
        border-radius: 4px;
    }}
    QHeaderView::section {{
        background-color: {p['surface_alt']};
        color: {p['text']};
        padding: 4px;
        border: 1px solid {p['border']};
        font-weight: 700;
    }}
    QCheckBox {{
        color: {p['text']};
        spacing: 6px;
        background: transparent;
    }}
    QCheckBox::indicator {{
        width: 15px;
        height: 15px;
        border-radius: 3px;
        border: 1px solid {p['border']};
        background-color: {p['input_bg']};
    }}
    QCheckBox::indicator:hover {{
        border: 1px solid {p['primary']};
    }}
    QCheckBox::indicator:checked {{
        background-color: {p['primary']};
        border: 1px solid {p['primary']};
    }}
    QPushButton, QToolButton {{
        background-color: {p['surface_alt']};
        color: {p['text']};
        border: 1px solid {p['border']};
        border-radius: 4px;
        padding: 4px 8px;
        font-weight: 500;
    }}
    QToolButton::menu-indicator {{
        image: none;
        width: 0px;
    }}
    QMenu {{
        background-color: {p['surface']};
        color: {p['text']};
        border: 1px solid {p['border']};
        padding: 4px;
    }}
    QMenu::item {{
        padding: 6px 14px;
        border-radius: 3px;
    }}
    QMenu::item:selected {{
        background-color: {p['selection_bg']};
        color: {p['selection_fg']};
    }}
    QPushButton:hover, QToolButton:hover {{
        border-color: {p['primary']};
    }}
    QPushButton:disabled, QToolButton:disabled {{
        opacity: 0.5;
        color: {p['text_muted']};
    }}
    QPushButton:checked, QToolButton:checked {{
        background-color: {p['primary']};
        color: #ffffff;
        border: 1px solid {p['primary_hover']};
        font-weight: 700;
    }}
    QPushButton[role="primary"] {{
        background-color: {p['primary']};
        color: #ffffff;
        border: 1px solid {p['primary']};
        font-weight: 700;
    }}
    QPushButton[role="primary"]:hover {{
        background-color: {p['primary_hover']};
    }}
    QPushButton[role="success"] {{
        background-color: {p['success']};
        color: #ffffff;
        border: 1px solid {p['success']};
        font-weight: 700;
    }}
    QPushButton[role="success"]:hover {{
        background-color: {p['success_hover']};
    }}
    QPushButton[role="danger"] {{
        background-color: {p['danger']};
        color: #ffffff;
        border: 1px solid {p['danger']};
        font-weight: 700;
    }}
    QPushButton[role="danger"]:hover {{
        background-color: {p['danger_hover']};
    }}
    QPushButton[role="accent"] {{
        background-color: {p['accent']};
        color: #ffffff;
        border: 1px solid {p['accent']};
        font-weight: 700;
    }}
    QPushButton[role="accent"]:hover {{
        background-color: {p['accent_hover']};
    }}
    QPushButton[role="modeBtn"] {{
        text-align: left;
        padding: 5px 7px;
        font-size: 11px;
        font-weight: 600;
    }}
    QPushButton[role="pill"] {{
        padding: 3px 8px;
        border-radius: 11px;
        font-size: 11px;
        font-weight: 600;
    }}
    QPushButton[role="toolBtn"], QToolButton[role="toolBtn"] {{
        padding: 4px 6px;
        font-size: 11px;
    }}
    QGraphicsView {{
        background-color: {p['log_bg']};
        border: 1px solid {p['border']};
        border-radius: 4px;
    }}
    QPushButton[role="toggleChip"] {{
        padding: 5px 8px;
        font-size: 11px;
    }}
    QPushButton[role="toggleChip"]:checked {{
        background-color: {p['success']};
        border: 1px solid {p['success_hover']};
        color: #ffffff;
    }}
    QTextEdit[role="log"] {{
        background-color: {p['log_bg']};
        color: {p['log_fg']};
        font-family: "Consolas", "Cascadia Mono", monospace;
        font-size: 10px;
        border: none;
    }}
    QProgressBar {{
        background-color: {p['input_bg']};
        color: {p['text']};
        border: 1px solid {p['border']};
        border-radius: 4px;
        text-align: center;
        height: 18px;
    }}
    QProgressBar::chunk {{
        background-color: {p['primary']};
        border-radius: 3px;
    }}
    QSlider::groove:horizontal {{
        height: 5px;
        background: {p['border']};
        border-radius: 2px;
    }}
    QSlider::handle:horizontal {{
        background: {p['primary']};
        width: 14px;
        margin: -5px 0;
        border-radius: 7px;
    }}
    QSplitter::handle {{
        background-color: {p['border']};
    }}
    """


def apply_theme(widget, theme_name=None):
    widget.setStyleSheet(build_stylesheet(theme_name))
