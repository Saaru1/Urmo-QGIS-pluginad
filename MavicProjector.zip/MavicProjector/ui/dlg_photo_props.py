import os
from ..compat_drone import (
    AlignCenter,
    KeepAspectRatio,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPixmap,
    QPushButton,
    QVBoxLayout,
    SmoothTransformation,
)
from ..core.i18n import tr, ui_prefs
from ..core.metadata_parser import MetadataParser
from .theme import apply_theme


class PhotoPropertiesDialog(QDialog):
    def __init__(self, photo_path, current_overrides, parent=None):
        super().__init__(parent)
        self.photo_path = photo_path
        self.current_overrides = dict(current_overrides or {})
        self._auto_geoid_val = -19.0
        self.resize(400, 580)

        self.initUI()
        self.retranslate_ui()
        self.apply_current_theme()
        self.extract_and_display_info()

        ui_prefs.languageChanged.connect(self.retranslate_ui)
        ui_prefs.themeChanged.connect(self.apply_current_theme)

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        self.thumb_label = QLabel()
        self.thumb_label.setAlignment(AlignCenter)
        pixmap = QPixmap(self.photo_path)
        if not pixmap.isNull():
            self.thumb_label.setPixmap(pixmap.scaled(360, 195, KeepAspectRatio, SmoothTransformation))
        else:
            self.thumb_label.setText("Preview Not Available")
        layout.addWidget(self.thumb_label)

        info_box = QFrame()
        info_box.setProperty("role", "infoBanner")
        ib_lay = QVBoxLayout(info_box)
        ib_lay.setContentsMargins(8, 6, 8, 6)
        self.info_label = QLabel()
        self.info_label.setWordWrap(True)
        ib_lay.addWidget(self.info_label)
        layout.addWidget(info_box)

        card = QFrame()
        card.setProperty("role", "card")
        c_lay = QVBoxLayout(card)
        c_lay.setContentsMargins(10, 8, 10, 8)
        c_lay.setSpacing(6)

        h_lens = QHBoxLayout()
        self.lbl_lens = QLabel()
        h_lens.addWidget(self.lbl_lens)
        self.combo_lens = QComboBox()
        self.combo_lens.addItem("", "Auto (From File)")
        self.combo_lens.addItem("", "Wide")
        self.combo_lens.addItem("", "Zoom")
        current_lens = self.current_overrides.get('lens_override', 'Auto (From File)')
        if current_lens in ('Wide', 'Force Wide'):
            self.combo_lens.setCurrentIndex(1)
        elif current_lens in ('Zoom', 'Force Zoom'):
            self.combo_lens.setCurrentIndex(2)
        else:
            self.combo_lens.setCurrentIndex(0)
        h_lens.addWidget(self.combo_lens)
        c_lay.addLayout(h_lens)

        h_focal = QHBoxLayout()
        self.lbl_focal = QLabel()
        h_focal.addWidget(self.lbl_focal)
        self.spin_focal = QDoubleSpinBox()
        self.spin_focal.setRange(50.0, 250.0)
        self.spin_focal.setDecimals(2)
        self.spin_focal.setSingleStep(0.5)
        self.spin_focal.setValue(float(self.current_overrides.get('focal_scale', 1.0)) * 100.0)
        h_focal.addWidget(self.spin_focal)
        c_lay.addLayout(h_focal)

        h1 = QHBoxLayout()
        self.lbl_pitch = QLabel()
        h1.addWidget(self.lbl_pitch)
        self.spin_pitch = QDoubleSpinBox()
        self.spin_pitch.setRange(-45.0, 45.0)
        self.spin_pitch.setDecimals(2)
        self.spin_pitch.setSingleStep(0.1)
        self.spin_pitch.setValue(float(self.current_overrides.get('pitch_offset', 0.0)))
        h1.addWidget(self.spin_pitch)
        c_lay.addLayout(h1)

        h2 = QHBoxLayout()
        self.lbl_yaw = QLabel()
        h2.addWidget(self.lbl_yaw)
        self.spin_yaw = QDoubleSpinBox()
        self.spin_yaw.setRange(-180.0, 180.0)
        self.spin_yaw.setDecimals(2)
        self.spin_yaw.setSingleStep(0.1)
        self.spin_yaw.setValue(float(self.current_overrides.get('yaw_offset', 0.0)))
        h2.addWidget(self.spin_yaw)
        c_lay.addLayout(h2)

        h_roll = QHBoxLayout()
        self.lbl_roll = QLabel()
        h_roll.addWidget(self.lbl_roll)
        self.spin_roll = QDoubleSpinBox()
        self.spin_roll.setRange(-45.0, 45.0)
        self.spin_roll.setDecimals(2)
        self.spin_roll.setSingleStep(0.1)
        self.spin_roll.setValue(float(self.current_overrides.get('roll_offset', 0.0)))
        h_roll.addWidget(self.spin_roll)
        c_lay.addLayout(h_roll)

        h3 = QHBoxLayout()
        self.chk_auto_geoid = QCheckBox()
        has_manual_geoid = (
            'use_auto_geoid' in self.current_overrides and not self.current_overrides['use_auto_geoid']
        ) or (
            'use_auto_geoid' not in self.current_overrides and 'geoid_offset' in self.current_overrides
        )
        self.chk_auto_geoid.setChecked(not has_manual_geoid)
        self.spin_geoid = QDoubleSpinBox()
        self.spin_geoid.setRange(-100.0, 100.0)
        self.spin_geoid.setDecimals(2)
        self.spin_geoid.setSingleStep(0.1)
        self.spin_geoid.setEnabled(has_manual_geoid)
        self.chk_auto_geoid.toggled.connect(self._on_auto_geoid_toggled)
        h3.addWidget(self.chk_auto_geoid)
        h3.addWidget(self.spin_geoid)
        c_lay.addLayout(h3)

        h4 = QHBoxLayout()
        self.lbl_k1 = QLabel()
        h4.addWidget(self.lbl_k1)
        self.spin_dist = QDoubleSpinBox()
        self.spin_dist.setRange(-0.5, 0.5)
        self.spin_dist.setDecimals(4)
        self.spin_dist.setSingleStep(0.005)
        dist_dict = self.current_overrides.get('dist_offsets', {})
        init_k1 = dist_dict.get('k1', self.current_overrides.get('dist_offset', 0.0))
        self.spin_dist.setValue(float(init_k1))
        h4.addWidget(self.spin_dist)
        c_lay.addLayout(h4)

        layout.addWidget(card)

        btn_layout = QHBoxLayout()
        self.clear_btn = QPushButton()
        self.clear_btn.clicked.connect(self.clear_overrides)
        self.save_btn = QPushButton()
        self.save_btn.setProperty("role", "primary")
        self.save_btn.clicked.connect(self.accept)

        btn_layout.addWidget(self.clear_btn)
        btn_layout.addWidget(self.save_btn, stretch=2)
        layout.addLayout(btn_layout)

    def apply_current_theme(self, *_args):
        apply_theme(self)

    def retranslate_ui(self, *_args):
        self.setWindowTitle(tr("dlg_photo_title", name=os.path.basename(self.photo_path)))
        self.lbl_lens.setText(tr("lbl_force_lens"))
        self.combo_lens.setItemText(0, tr("lens_auto"))
        self.combo_lens.setItemText(1, tr("lens_wide"))
        self.combo_lens.setItemText(2, tr("lens_zoom"))
        self.lbl_focal.setText(tr("lbl_focal_zoom_scale"))
        self.lbl_pitch.setText(tr("lbl_custom_pitch"))
        self.lbl_yaw.setText(tr("lbl_custom_yaw"))
        self.lbl_roll.setText(tr("lbl_custom_roll"))
        self.chk_auto_geoid.setText(tr("chk_auto_geoid"))
        self.lbl_k1.setText(tr("lbl_custom_k1"))
        self.clear_btn.setText(tr("btn_clear_overrides"))
        self.save_btn.setText(tr("btn_save_overrides"))
        self.extract_and_display_info()

    def _on_auto_geoid_toggled(self, checked):
        self.spin_geoid.setEnabled(not checked)
        if checked:
            self.spin_geoid.setValue(self._auto_geoid_val)

    def extract_and_display_info(self):
        try:
            tel = MetadataParser.extract_xmp(self.photo_path)
            is_rtk = tel.get('is_rtk', True)
            self._auto_geoid_val = tel.get('auto_geoid', -19.0) if is_rtk else 0.0

            if not self.chk_auto_geoid.isChecked() and 'geoid_offset' in self.current_overrides:
                self.spin_geoid.setValue(float(self.current_overrides['geoid_offset']))
            else:
                self.spin_geoid.setValue(self._auto_geoid_val)

            drone = tel.get('model', 'Unknown')
            camera = tel.get('source', 'Unknown')
            dewarp = tr("yes") if tel.get('has_dewarp') else tr("no")
            rtk_str = "RTK" if is_rtk else "Non-RTK"
            zoom = tel.get('zoom_ratio', 1.0)
            fx = tel.get('fx_px', 0.0)
            warn = f"<br><b style='color:#ef4444;'>{tr('meta_warn_projected')}</b>" if tel.get('already_projected') else ""

            info_text = (
                f"<b>Model:</b> {drone} | <b>Source:</b> {camera} | <b>Zoom:</b> {zoom:.2f}x<br>"
                f"<b>Focal fx:</b> {fx:.1f} px | <b>Dewarped:</b> {dewarp}<br>"
                f"<b>GNSS:</b> {rtk_str} | <b>EH2000 Geoid:</b> {self._auto_geoid_val:+.2f}m{warn}"
            )
            self.info_label.setText(info_text)
        except Exception:
            self.info_label.setText(tr("meta_error"))

    def clear_overrides(self):
        self.spin_pitch.setValue(0.0)
        self.spin_yaw.setValue(0.0)
        self.spin_roll.setValue(0.0)
        self.spin_focal.setValue(100.0)
        self.spin_dist.setValue(0.0)
        self.chk_auto_geoid.setChecked(True)
        self.combo_lens.setCurrentIndex(0)
        self.current_overrides = {}
        self.accept()

    def get_overrides(self):
        overrides = {}
        for keep_key in ('label_offsets', 'x_offset', 'y_offset', 'alt_mode'):
            if keep_key in self.current_overrides and self.current_overrides[keep_key]:
                overrides[keep_key] = self.current_overrides[keep_key]

        if abs(self.spin_pitch.value()) > 1e-6:
            overrides['pitch_offset'] = self.spin_pitch.value()
        if abs(self.spin_yaw.value()) > 1e-6:
            overrides['yaw_offset'] = self.spin_yaw.value()
        if abs(self.spin_roll.value()) > 1e-6:
            overrides['roll_offset'] = self.spin_roll.value()

        fscale = self.spin_focal.value() / 100.0
        if abs(fscale - 1.0) > 1e-4:
            overrides['focal_scale'] = round(fscale, 5)

        prev_dists = dict(self.current_overrides.get('dist_offsets', {}))
        prev_dists['k1'] = self.spin_dist.value()
        if any(abs(v) > 1e-6 for v in prev_dists.values()):
            overrides['dist_offsets'] = prev_dists

        if not self.chk_auto_geoid.isChecked():
            overrides['use_auto_geoid'] = False
            overrides['geoid_offset'] = self.spin_geoid.value()

        lens_data = self.combo_lens.currentData()
        if lens_data in ('Wide', 'Zoom'):
            overrides['lens_override'] = lens_data

        return overrides
