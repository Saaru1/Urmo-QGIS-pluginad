import os
from ..compat_drone import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDoubleSpinBox, QComboBox, QPixmap, KeepAspectRatio, SmoothTransformation, AlignCenter
from ..core.metadata_parser import MetadataParser

class PhotoPropertiesDialog(QDialog):
    def __init__(self, photo_path, current_overrides, parent=None):
        super().__init__(parent)
        self.photo_path = photo_path
        self.current_overrides = current_overrides
        self.setWindowTitle(f"Photo Overrides: {os.path.basename(photo_path)}")
        self.resize(350, 480)
        
        self.initUI()
        self.extract_and_display_info()

    def initUI(self):
        layout = QVBoxLayout()
        
        self.thumb_label = QLabel()
        self.thumb_label.setAlignment(AlignCenter)
        self.thumb_label.setStyleSheet("background-color: #111; border: 1px solid #444;")
        pixmap = QPixmap(self.photo_path)
        if not pixmap.isNull():
            self.thumb_label.setPixmap(pixmap.scaled(330, 200, KeepAspectRatio, SmoothTransformation))
        else:
            self.thumb_label.setText("Preview Not Available")
        layout.addWidget(self.thumb_label)
        
        self.info_label = QLabel("Extracting metadata...")
        self.info_label.setStyleSheet("color: #aaa; font-style: italic; background: #222; padding: 5px;")
        layout.addWidget(self.info_label)

        h_lens = QHBoxLayout()
        h_lens.addWidget(QLabel("Force Lens Type:"))
        self.combo_lens = QComboBox()
        self.combo_lens.addItems(["Auto (From File)", "Force Wide", "Force Zoom"])
        current_lens = self.current_overrides.get('lens_override', 'Auto (From File)')
        
        # Mapping to match ComboBox text perfectly
        idx = self.combo_lens.findText(current_lens)
        if idx >= 0:
            self.combo_lens.setCurrentIndex(idx)
        elif current_lens == 'Wide':
            self.combo_lens.setCurrentIndex(1)
        elif current_lens == 'Zoom':
            self.combo_lens.setCurrentIndex(2)
            
        h_lens.addWidget(self.combo_lens)
        layout.addLayout(h_lens)

        h1 = QHBoxLayout()
        h1.addWidget(QLabel("Custom Pitch Offset (°):"))
        self.spin_pitch = QDoubleSpinBox()
        self.spin_pitch.setRange(-45.0, 45.0)
        self.spin_pitch.setSingleStep(0.1)
        self.spin_pitch.setValue(self.current_overrides.get('pitch_offset', 0.0))
        h1.addWidget(self.spin_pitch)
        layout.addLayout(h1)

        h2 = QHBoxLayout()
        h2.addWidget(QLabel("Yaw (Crab Angle) Offset (°):"))
        self.spin_yaw = QDoubleSpinBox()
        self.spin_yaw.setRange(-180.0, 180.0)
        self.spin_yaw.setSingleStep(0.1)
        self.spin_yaw.setValue(self.current_overrides.get('yaw_offset', 0.0))
        h2.addWidget(self.spin_yaw)
        layout.addLayout(h2)

        h3 = QHBoxLayout()
        h3.addWidget(QLabel("Specific Geoid (EH2000):"))
        self.spin_geoid = QDoubleSpinBox()
        self.spin_geoid.setRange(-100.0, 100.0)
        h3.addWidget(self.spin_geoid)
        layout.addLayout(h3)

        h4 = QHBoxLayout()
        h4.addWidget(QLabel("Specific Distortion (k1):"))
        self.spin_dist = QDoubleSpinBox()
        self.spin_dist.setRange(-0.5, 0.5)
        self.spin_dist.setDecimals(3)
        self.spin_dist.setSingleStep(0.01)
        self.spin_dist.setValue(self.current_overrides.get('dist_offset', 0.0))
        h4.addWidget(self.spin_dist)
        layout.addLayout(h4)

        btn_layout = QHBoxLayout()
        clear_btn = QPushButton("Clear Overrides")
        clear_btn.clicked.connect(self.clear_overrides)
        save_btn = QPushButton("Save Overrides")
        save_btn.setStyleSheet("background-color: #0078D7; color: white; font-weight: bold;")
        save_btn.clicked.connect(self.accept)
        
        btn_layout.addWidget(clear_btn)
        btn_layout.addWidget(save_btn)
        layout.addLayout(btn_layout)

        self.setLayout(layout)

    def extract_and_display_info(self):
        try:
            tel = MetadataParser.extract_xmp(self.photo_path)
            auto_geoid = MetadataParser.calculate_est_geoid(tel['lat'], tel['lon'])
            
            if 'geoid_offset' in self.current_overrides:
                self.spin_geoid.setValue(self.current_overrides['geoid_offset'])
            else:
                self.spin_geoid.setValue(auto_geoid)
            
            drone = tel.get('model', 'Unknown')
            camera = tel.get('source', 'Unknown')
            dewarp = "Yes" if tel.get('has_dewarp') else "No (Needs k1 Offset)"
            
            info_text = (
                f"<b>Drone:</b> {drone} | <b>Camera:</b> {camera}<br>"
                f"<b>Factory Flattened:</b> {dewarp}<br>"
                f"<b>Auto-Geoid Est:</b> {auto_geoid}m"
            )
            self.info_label.setText(info_text)
        except Exception as e:
            self.info_label.setText("Could not read DJI XMP metadata.")

    def clear_overrides(self):
        self.spin_pitch.setValue(0.0)
        self.spin_yaw.setValue(0.0)
        self.spin_dist.setValue(0.0)
        self.combo_lens.setCurrentIndex(0)
        self.accept()

    def get_overrides(self):
        overrides = {}
        if self.spin_pitch.value() != 0.0: overrides['pitch_offset'] = self.spin_pitch.value()
        if self.spin_yaw.value() != 0.0: overrides['yaw_offset'] = self.spin_yaw.value()
        if self.spin_dist.value() != 0.0: overrides['dist_offset'] = self.spin_dist.value()
        overrides['geoid_offset'] = self.spin_geoid.value()
        
        lens_val = self.combo_lens.currentText()
        if lens_val == "Force Wide":
            overrides['lens_override'] = 'Wide'
        elif lens_val == "Force Zoom":
            overrides['lens_override'] = 'Zoom'
            
        return overrides