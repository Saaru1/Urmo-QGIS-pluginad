import math
from qgis.PyQt.QtWidgets import QDial
from qgis.PyQt.QtCore import QRect, QRectF

from ..compat_drone import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSpinBox, QDoubleSpinBox,
    QCheckBox, QColor, QColorDialog, ShowAlphaChannel, QTabWidget, QWidget, QLineEdit, QComboBox,
    QSlider, Horizontal, QgsRenderContext, NoBrush, QListWidget, QTextEdit, Qt, AlignCenter,
    QPixmap, QPainter, QPen, QFont, QTransform, SolidLine, RoundCap, RenderHintAntialiasing,
    QPainterPath, QPolygonF, QPointF, NoPen, QBrush
)

from functools import partial
from ..core.i18n import tr, ui_prefs
from .theme import apply_theme

COMBO_CSS = ""
INPUT_CSS = ""

def get_rect_intersection(rect_x, rect_y, rect_w, rect_h, line_x1, line_y1):
    cx = rect_x + rect_w / 2.0
    cy = rect_y + rect_h / 2.0
    dx = line_x1 - cx
    dy = line_y1 - cy
    if dx == 0 and dy == 0: return cx, cy
    x_scale = (rect_w / 2.0) / abs(dx) if dx != 0 else float('inf')
    y_scale = (rect_h / 2.0) / abs(dy) if dy != 0 else float('inf')
    scale = min(x_scale, y_scale)
    if scale >= 1.0: return line_x1, line_y1
    return cx + dx * scale, cy + dy * scale

class DropTextEdit(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setStyleSheet(INPUT_CSS)
        
    def dragEnterEvent(self, e): e.accept()
    def dragMoveEvent(self, e): e.accept()
    def dropEvent(self, e):
        source = e.source()
        if source and hasattr(source, 'currentItem') and source.currentItem():
            self.insertPlainText(f"[{source.currentItem().text()}]")
            e.accept()
        elif e.mimeData().hasText():
            self.insertPlainText(f"[{e.mimeData().text()}]")
            e.accept()
        else: super().dropEvent(e)

class LayerStyleDialog(QDialog):
    def __init__(self, layer, current_style, parent=None):
        super().__init__(parent)
        self.layer = layer
        self.current_style = current_style
        
        if not self.current_style:
            self.current_style = {
                "color": (255, 255, 0, 200), "fill_color": (255, 255, 0, 0), "width": 6, "point_size": 10, "opacity": 100, "fade": True,
                "label_field": "", "label_expr": "", "max_labels": 15, "font_size": 48,
                "label_color": (255, 255, 0, 255), "halo_color": (0, 0, 0, 255), "shadow": False,
                "preset": "Standard (Flat)", "billboard_shape": "Rounded", "light_angle": 45, "shadow_dist": 15,
                "callout_color": (255, 255, 255, 255), "callout_width": 5, "live_sync": False, "shadow_blur": 0
            }
            
        self.setWindowTitle(f"Style & Labels: {layer.name()}")
        self.resize(500, 800)
        
        self.line_color = QColor(*self.current_style.get("color", (255,255,0,200)))
        self.fill_color = QColor(*self.current_style.get("fill_color", (255,255,0,0)))
        self.label_color = QColor(*self.current_style.get("label_color", (255,255,0,255)))
        self.halo_color = QColor(*self.current_style.get("halo_color", (0,0,0,255)))
        self.callout_color = QColor(*self.current_style.get("callout_color", (150,150,150,200)))
        
        self.initUI()
        self.retranslate_ui()
        apply_theme(self)
        ui_prefs.languageChanged.connect(self.retranslate_ui)
        ui_prefs.themeChanged.connect(self._on_theme_changed)

    def _on_theme_changed(self, *_args):
        apply_theme(self)

    def retranslate_ui(self, *_args):
        self.setWindowTitle(tr("dlg_layer_title", name=self.layer.name()))
        self.check_live_sync.setText(tr("chk_live_sync"))
        self.sync_btn.setText(tr("btn_sync_now"))
        self.tabs_widget.setTabText(0, tr("tab_symbology"))
        self.tabs_widget.setTabText(1, tr("tab_labels"))
        self.lbl_line_col.setText(tr("lbl_line_color"))
        self.lbl_fill_col.setText(tr("lbl_fill_color"))
        self.lbl_op.setText(tr("lbl_opacity"))
        self.lbl_w.setText(tr("lbl_line_width"))
        self.lbl_pt.setText(tr("lbl_point_size"))
        self.check_fade.setText(tr("chk_fade"))
        self.lbl_zoff.setText(tr("lbl_z_offset"))
        self.check_use_3dz.setText(tr("chk_use_3dz"))
        self.lbl_designer.setText(tr("lbl_label_designer"))
        self.lbl_max_l.setText(tr("lbl_max_labels"))
        self.lbl_font.setText(tr("lbl_font_size"))
        self.lbl_tc.setText(tr("lbl_text_color"))
        self.lbl_hc.setText(tr("lbl_halo_color"))
        self.lbl_cw.setText(tr("lbl_callout_w"))
        self.check_shadow.setText(tr("chk_shadow"))
        self.lbl_pres.setText(tr("lbl_preset"))
        self.lbl_ang.setText(tr("lbl_angle"))
        self.lbl_dist.setText(tr("lbl_dist"))
        self.lbl_blur.setText(tr("lbl_blur"))
        self.save_btn.setText(tr("btn_save_layer"))

    def initUI(self):
        layout = QVBoxLayout()
        
        sync_layout = QHBoxLayout()
        self.check_live_sync = QCheckBox()
        self.check_live_sync.setChecked(self.current_style.get("live_sync", False))
        self.check_live_sync.toggled.connect(self.on_live_sync_toggled)
        sync_layout.addWidget(self.check_live_sync)
        
        self.sync_btn = QPushButton()
        self.sync_btn.setProperty("role", "primary")
        self.sync_btn.clicked.connect(self.sync_from_qgis)
        sync_layout.addWidget(self.sync_btn)
        layout.addLayout(sync_layout)

        self.tabs_widget = QTabWidget()
        tabs = self.tabs_widget
        
        # --- TAB 1: SYMBOLOGY ---
        tab1 = QWidget()
        l1 = QVBoxLayout()
        
        h1 = QHBoxLayout()
        self.lbl_line_col = QLabel()
        h1.addWidget(self.lbl_line_col)
        self.btn_line_color = QPushButton()
        self.update_color_btn(self.btn_line_color, self.line_color)
        self.btn_line_color.clicked.connect(partial(self.pick_color, "line"))
        h1.addWidget(self.btn_line_color)
        l1.addLayout(h1)

        h_fill = QHBoxLayout()
        self.lbl_fill_col = QLabel()
        h_fill.addWidget(self.lbl_fill_col)
        self.btn_fill_color = QPushButton()
        self.update_color_btn(self.btn_fill_color, self.fill_color)
        self.btn_fill_color.clicked.connect(partial(self.pick_color, "fill"))
        h_fill.addWidget(self.btn_fill_color)
        l1.addLayout(h_fill)
        
        h_op = QHBoxLayout()
        self.lbl_op = QLabel()
        h_op.addWidget(self.lbl_op)
        self.slider_op = QSlider(Horizontal)
        self.slider_op.setRange(0, 100)
        self.slider_op.setValue(self.current_style.get("opacity", 100))
        h_op.addWidget(self.slider_op)
        l1.addLayout(h_op)

        h2 = QHBoxLayout()
        self.lbl_w = QLabel()
        h2.addWidget(self.lbl_w)
        self.spin_width = QSpinBox()
        self.spin_width.setRange(1, 20)
        self.spin_width.setValue(self.current_style.get("width", 6))
        h2.addWidget(self.spin_width)
        l1.addLayout(h2)
        
        h3 = QHBoxLayout()
        self.lbl_pt = QLabel()
        h3.addWidget(self.lbl_pt)
        self.spin_pt_size = QSpinBox()
        self.spin_pt_size.setRange(1, 100)
        self.spin_pt_size.setValue(self.current_style.get("point_size", 10))
        h3.addWidget(self.spin_pt_size)
        l1.addLayout(h3)

        self.check_fade = QCheckBox()
        self.check_fade.setChecked(self.current_style.get("fade", True))
        l1.addWidget(self.check_fade)

        h_zoff = QHBoxLayout()
        self.lbl_zoff = QLabel()
        h_zoff.addWidget(self.lbl_zoff)
        self.spin_z_offset = QDoubleSpinBox()
        self.spin_z_offset.setRange(-200.0, 1000.0)
        self.spin_z_offset.setDecimals(2)
        self.spin_z_offset.setSingleStep(0.5)
        self.spin_z_offset.setValue(float(self.current_style.get("z_offset", 0.0)))
        h_zoff.addWidget(self.spin_z_offset)
        l1.addLayout(h_zoff)

        self.check_use_3dz = QCheckBox()
        self.check_use_3dz.setChecked(bool(self.current_style.get("use_feature_z", True)))
        l1.addWidget(self.check_use_3dz)

        l1.addStretch()
        tab1.setLayout(l1)
        
        # --- TAB 2: LABELS ---
        tab2 = QWidget()
        l2 = QVBoxLayout()
        
        self.lbl_designer = QLabel()
        l2.addWidget(self.lbl_designer)
        
        designer_layout = QHBoxLayout()
        self.list_fields = QListWidget()
        self.list_fields.setDragEnabled(True)
        for f in self.layer.fields():
            self.list_fields.addItem(f.name())
        self.list_fields.itemDoubleClicked.connect(self._insert_field_item)
        designer_layout.addWidget(self.list_fields, 1)

        self.edit_canvas = DropTextEdit()
        self.edit_canvas.setPlaceholderText("Drop fields here and format...\nExample:\n[id]\n[area_m2] m²")
        self.edit_canvas.setText(self.current_style.get("label_expr", ""))
        self.edit_canvas.textChanged.connect(self._update_live_preview)
        designer_layout.addWidget(self.edit_canvas, 2)
        
        l2.addLayout(designer_layout)

        self.lbl_preview = QLabel()
        self.lbl_preview.setAlignment(AlignCenter)
        self.lbl_preview.setStyleSheet("background: white; border: 1px solid #888; color: black;")
        self.lbl_preview.setMinimumHeight(150)
        l2.addWidget(self.lbl_preview)
        
        h_max = QHBoxLayout()
        self.lbl_max_l = QLabel()
        h_max.addWidget(self.lbl_max_l)
        self.spin_max_lbl = QSpinBox()
        self.spin_max_lbl.setRange(0, 1000)
        self.spin_max_lbl.setValue(self.current_style.get("max_labels", 15))
        h_max.addWidget(self.spin_max_lbl)
        l2.addLayout(h_max)
        
        h_size = QHBoxLayout()
        self.lbl_font = QLabel()
        h_size.addWidget(self.lbl_font)
        self.spin_font = QSpinBox()
        self.spin_font.setRange(8, 200)
        self.spin_font.setValue(self.current_style.get("font_size", 48))
        self.spin_font.valueChanged.connect(self._update_live_preview)
        h_size.addWidget(self.spin_font)
        l2.addLayout(h_size)

        h_tc = QHBoxLayout()
        self.lbl_tc = QLabel()
        h_tc.addWidget(self.lbl_tc)
        self.btn_txt_color = QPushButton()
        self.update_color_btn(self.btn_txt_color, self.label_color)
        self.btn_txt_color.clicked.connect(partial(self.pick_color, "text"))
        h_tc.addWidget(self.btn_txt_color)
        l2.addLayout(h_tc)
        
        h_hc = QHBoxLayout()
        self.lbl_hc = QLabel()
        h_hc.addWidget(self.lbl_hc)
        self.btn_halo_color = QPushButton()
        self.update_color_btn(self.btn_halo_color, self.halo_color)
        self.btn_halo_color.clicked.connect(partial(self.pick_color, "halo"))
        h_hc.addWidget(self.btn_halo_color)
        l2.addLayout(h_hc)
        
        h_callout = QHBoxLayout()
        self.lbl_cw = QLabel()
        h_callout.addWidget(self.lbl_cw)
        self.spin_callout_w = QSpinBox()
        self.spin_callout_w.setRange(0, 50)
        self.spin_callout_w.setValue(self.current_style.get("callout_width", 2))
        self.spin_callout_w.valueChanged.connect(self._update_live_preview)
        h_callout.addWidget(self.spin_callout_w)
        
        self.btn_callout_color = QPushButton("Color")
        self.update_color_btn(self.btn_callout_color, self.callout_color)
        self.btn_callout_color.clicked.connect(partial(self.pick_color, "callout"))
        h_callout.addWidget(self.btn_callout_color)
        l2.addLayout(h_callout)

        self.check_shadow = QCheckBox()
        self.check_shadow.setChecked(self.current_style.get("shadow", False))
        self.check_shadow.stateChanged.connect(self._update_live_preview)
        l2.addWidget(self.check_shadow)
        
        h_preset = QHBoxLayout()
        self.lbl_pres = QLabel()
        h_preset.addWidget(self.lbl_pres)
        self.combo_preset = QComboBox()
        self.combo_preset.addItems(["Standard (Flat)", "Billboard (Stand-up)"])
        idx = self.combo_preset.findText(self.current_style.get("preset", "Standard (Flat)"))
        if idx >= 0: self.combo_preset.setCurrentIndex(idx)
        self.combo_preset.currentTextChanged.connect(self._update_live_preview)
        h_preset.addWidget(self.combo_preset)
        
        self.combo_bb_shape = QComboBox()
        self.combo_bb_shape.addItems(["Rounded", "Rectangle"])
        idx_shp = self.combo_bb_shape.findText(self.current_style.get("billboard_shape", "Rounded"))
        if idx_shp >= 0: self.combo_bb_shape.setCurrentIndex(idx_shp)
        self.combo_bb_shape.currentTextChanged.connect(self._update_live_preview)
        h_preset.addWidget(self.combo_bb_shape)
        
        l2.addLayout(h_preset)
        
        h_ang = QHBoxLayout()
        self.lbl_ang = QLabel()
        h_ang.addWidget(self.lbl_ang)
        self.dial_angle = QDial()
        self.dial_angle.setRange(-180, 180)
        self.dial_angle.setValue(self.current_style.get("light_angle", 45))
        self.dial_angle.setNotchesVisible(True)
        self.dial_angle.setFixedSize(46, 46)
        self.lbl_angle_val = QLabel(f"{self.dial_angle.value()}°")
        self.dial_angle.valueChanged.connect(self._on_angle_val_changed)
        self.dial_angle.valueChanged.connect(self._update_live_preview)
        h_ang.addWidget(self.dial_angle)
        h_ang.addWidget(self.lbl_angle_val)
        
        self.lbl_dist = QLabel()
        h_ang.addWidget(self.lbl_dist)
        self.slider_shadow_dist = QSlider(Horizontal)
        self.slider_shadow_dist.setRange(-100, 100)
        self.slider_shadow_dist.setValue(self.current_style.get("shadow_dist", 15))
        self.slider_shadow_dist.setFixedWidth(75)
        
        self.spin_shadow_dist = QSpinBox()
        self.spin_shadow_dist.setRange(-100, 100)
        self.spin_shadow_dist.setValue(self.slider_shadow_dist.value())
        self.spin_shadow_dist.setFixedWidth(54)
        
        self.slider_shadow_dist.valueChanged.connect(self.spin_shadow_dist.setValue)
        self.spin_shadow_dist.valueChanged.connect(self.slider_shadow_dist.setValue)
        self.slider_shadow_dist.valueChanged.connect(self._update_live_preview)
        
        h_ang.addWidget(self.slider_shadow_dist)
        h_ang.addWidget(self.spin_shadow_dist)
        
        self.lbl_blur = QLabel()
        h_ang.addWidget(self.lbl_blur)
        self.slider_shadow_blur = QSlider(Horizontal)
        self.slider_shadow_blur.setRange(0, 30)
        self.slider_shadow_blur.setValue(self.current_style.get("shadow_blur", 0))
        self.slider_shadow_blur.setFixedWidth(75)
        
        self.spin_shadow_blur = QSpinBox()
        self.spin_shadow_blur.setRange(0, 30)
        self.spin_shadow_blur.setValue(self.slider_shadow_blur.value())
        self.spin_shadow_blur.setFixedWidth(50)
        
        self.slider_shadow_blur.valueChanged.connect(self.spin_shadow_blur.setValue)
        self.spin_shadow_blur.valueChanged.connect(self.slider_shadow_blur.setValue)
        self.slider_shadow_blur.valueChanged.connect(self._update_live_preview)
        
        h_ang.addWidget(self.slider_shadow_blur)
        h_ang.addWidget(self.spin_shadow_blur)
        
        l2.addLayout(h_ang)
        l2.addStretch()
        tab2.setLayout(l2)
        
        tabs.addTab(tab1, "Symbology")
        tabs.addTab(tab2, "Labels")
        layout.addWidget(tabs)

        self.save_btn = QPushButton()
        self.save_btn.setProperty("role", "primary")
        self.save_btn.clicked.connect(self.accept)
        layout.addWidget(self.save_btn)
        self.setLayout(layout)

        self.toggle_manual_controls(not self.check_live_sync.isChecked())
        self._update_live_preview()

    def _insert_field_item(self, item):
        self.edit_canvas.insertPlainText(f"[{item.text()}]")

    def _on_angle_val_changed(self, v):
        self.lbl_angle_val.setText(f"{v}°")

    def _update_live_preview(self):
        text = self.edit_canvas.toPlainText()
        if not text.strip():
            self.lbl_preview.setText("<i>(No labels enabled)</i>")
            return
            
        try:
            feat = next(self.layer.getFeatures())
            for fld in self.layer.fields():
                fname = fld.name()
                placeholder = f"[{fname}]"
                if placeholder in text:
                    val = feat.attribute(fname)
                    text = text.replace(placeholder, str(val) if val is not None else "")
        except StopIteration:
            pass 
            
        # Change pixmap fill
        pixmap = QPixmap(460, 180)
        pixmap.fill(QColor("white"))
        
        painter = QPainter(pixmap)
        painter.setRenderHint(RenderHintAntialiasing)
        
        fnt = QFont()
        fnt.setPointSize(self.spin_font.value())
        fnt.setBold(True)
        painter.setFont(fnt)
        fm = painter.fontMetrics()
        
        preset = self.combo_preset.currentText()
        shape = self.combo_bb_shape.currentText()
        shadow_angle = self.dial_angle.value()
        shadow_dist = self.slider_shadow_dist.value()
        shadow_blur = self.slider_shadow_blur.value()
        use_shadow = self.check_shadow.isChecked()
        c_w = self.spin_callout_w.value()
        
        lines = text.split('\n')
        th = len(lines) * fm.height() + 20
        try:
            tw = max(fm.horizontalAdvance(line) for line in lines) + 40
        except AttributeError:
            tw = max(fm.boundingRect(line).width() for line in lines) + 40
            
        anchor_x = 230
        anchor_y = 160
        
        if preset == "Billboard (Stand-up)":
            cx = anchor_x
            cy = anchor_y - max(15, abs(shadow_dist)) - th/2
            rect_x = cx - tw/2
            rect_y = cy - th/2
            
            board_rect = QRectF(rect_x, rect_y, tw, th)
            board_path = QPainterPath()
            if shape == "Rounded": 
                board_path.addRoundedRect(board_rect, 15.0, 15.0)
            else: 
                board_path.addRect(board_rect)
            
            dx = cx - anchor_x
            dy = cy - anchor_y
            dist = math.hypot(dx, dy)
            pole_path = QPainterPath()
            if dist > 0:
                nx, ny = -dy/dist, dx/dist
                pole_w = 10
                w = pole_w / 2.0
                # Fix: Connect pole to the intersection edge of the rect
                edge_x, edge_y = get_rect_intersection(rect_x, rect_y, tw, th, anchor_x, anchor_y)
                pole_path.addPolygon(QPolygonF([
                    QPointF(anchor_x + nx*w, anchor_y + ny*w),
                    QPointF(anchor_x - nx*w, anchor_y - ny*w),
                    QPointF(edge_x - nx*w, edge_y - ny*w),
                    QPointF(edge_x + nx*w, edge_y + ny*w)
                ]))
            
            # Use WindingFill to blend shadows perfectly
            shadow_path = QPainterPath()
            try:
                from ..compat_drone import Qt
                shadow_path.setFillRule(Qt.WindingFill)
            except Exception:
                pass
            shadow_path.addPath(pole_path)
            shadow_path.addPath(board_path)

            final_rect = QRect(int(rect_x), int(rect_y), int(tw), int(th))
            
            if use_shadow:
                painter.save()
                transform = QTransform()
                transform.translate(anchor_x, anchor_y)
                safe_shear = math.cos(math.radians(shadow_angle)) * (abs(shadow_dist) / 30.0)
                transform.shear(safe_shear, 0.0)
                scale_y = -0.4 * (shadow_dist / 15.0)
                if abs(scale_y) < 0.01: scale_y = -0.01 if shadow_dist >= 0 else 0.01
                transform.scale(1.0, scale_y)
                transform.translate(-anchor_x, -anchor_y)
                painter.setTransform(transform, True)
                
                painter.setPen(QPen(QColor(0, 0, 0, 0)))
                painter.setBrush(QBrush(QColor(0, 0, 0, 120)))
                painter.drawPath(shadow_path)
                painter.restore()
                
            painter.setPen(QPen(QColor(0, 0, 0), 4))
            painter.setBrush(QBrush(QColor(255, 255, 255)))
            
            # The order here is critical. Draw pole first so the board overlays it.
            painter.drawPath(pole_path)
            painter.drawPath(board_path)
            
            painter.setPen(QPen(QColor(0, 0, 0)))
            painter.drawText(final_rect, AlignCenter, text)
        else:
            cx = anchor_x
            cy = anchor_y - th/2 - 20
            rect_x = cx - tw/2
            rect_y = cy - th/2
            
            final_rect = QRect(int(rect_x), int(rect_y), int(tw), int(th))
            
            if c_w > 0:
                edge_x, edge_y = get_rect_intersection(rect_x, rect_y, tw, th, anchor_x, anchor_y)
                pole_pen = QPen(self.callout_color, c_w, SolidLine, RoundCap)
                painter.setPen(pole_pen)
                painter.drawLine(int(anchor_x), int(anchor_y), int(edge_x), int(edge_y))
            
            if use_shadow:
                painter.setPen(QPen(QColor(0, 0, 0, 150)))
                rad = math.radians(shadow_angle)
                sx = math.cos(rad) * shadow_dist
                sy = -math.sin(rad) * shadow_dist
                painter.drawText(final_rect.translated(int(sx), int(sy)), AlignCenter, text)
                    
            halo_pen = QPen(self.halo_color)
            painter.setPen(halo_pen)
            for o_dx, o_dy in [(-3,-3), (3,-3), (-3,3), (3,3), (0,-3), (0,3), (-3,0), (3,0)]:
                painter.drawText(final_rect.translated(o_dx, o_dy), AlignCenter, text)
                
            painter.setPen(QPen(self.label_color))
            painter.drawText(final_rect, AlignCenter, text)
        
        painter.end()
        self.lbl_preview.setPixmap(pixmap)

    def on_live_sync_toggled(self, checked):
        self.toggle_manual_controls(not checked)
        if checked:
            self.sync_from_qgis()

    def toggle_manual_controls(self, enabled):
        self.btn_line_color.setEnabled(enabled)
        self.btn_fill_color.setEnabled(enabled)
        self.spin_width.setEnabled(enabled)
        self.spin_pt_size.setEnabled(enabled)

    def sync_from_qgis(self):
        try:
            if hasattr(self.layer, 'opacity'):
                self.slider_op.setValue(max(0, min(100, int(round(self.layer.opacity() * 100)))))
            renderer = self.layer.renderer()
            if renderer:
                symbol = None
                if renderer.type() == 'singleSymbol':
                    symbol = renderer.symbol()
                elif renderer.type() in ['categorizedSymbol', 'ruleRenderer']:
                    symbols = renderer.symbols(QgsRenderContext())
                    if symbols: symbol = symbols[0]

                if symbol:
                    if symbol.symbolLayerCount() > 0:
                        layer0 = symbol.symbolLayer(0)
                        if hasattr(layer0, 'brushStyle'):
                            if layer0.brushStyle() == NoBrush or layer0.brushStyle() == 0:
                                self.fill_color = QColor(0, 0, 0, 0)
                                self.update_color_btn(self.btn_fill_color, self.fill_color)
                            elif hasattr(layer0, 'fillColor'):
                                self.fill_color = layer0.fillColor()
                                self.update_color_btn(self.btn_fill_color, self.fill_color)
                        elif hasattr(layer0, 'fillColor'):
                            self.fill_color = layer0.fillColor()
                            self.update_color_btn(self.btn_fill_color, self.fill_color)
                            
                        if hasattr(layer0, 'strokeColor'):
                            self.line_color = layer0.strokeColor()
                            self.update_color_btn(self.btn_line_color, self.line_color)
                            
                        if hasattr(layer0, 'strokeWidth'):
                            self.spin_width.setValue(int(layer0.strokeWidth() * 10)) 
                            
                        if hasattr(layer0, 'size'):
                            self.spin_pt_size.setValue(int(layer0.size() * 3))
                    else:
                        self.line_color = symbol.color()
                        self.update_color_btn(self.btn_line_color, self.line_color)

            if self.layer.labelsEnabled():
                labeling = self.layer.labeling()
                if labeling:
                    settings = labeling.settings()
                    if settings and not settings.isExpression:
                        self.edit_canvas.setText(f"[{settings.fieldName}]")
                        format = settings.format()
                        self.label_color = format.color()
                        self.update_color_btn(self.btn_txt_color, self.label_color)
                        buffer = format.buffer()
                        if buffer.enabled():
                            self.halo_color = buffer.color()
                            self.update_color_btn(self.btn_halo_color, self.halo_color)
        except Exception:
            pass

    def update_color_btn(self, btn, color):
        rgba = color.getRgb()
        btn.setStyleSheet(f"background-color: rgba({rgba[0]}, {rgba[1]}, {rgba[2]}, {rgba[3]}); border: 1px solid #ccc;")
        btn.setText(f"RGB ({rgba[0]},{rgba[1]},{rgba[2]})")

    def pick_color(self, target, *_args):
        if target == "line": c_in = self.line_color
        elif target == "fill": c_in = self.fill_color
        elif target == "text": c_in = self.label_color
        elif target == "callout": c_in = self.callout_color
        else: c_in = self.halo_color
        
        color = QColorDialog.getColor(c_in, self, "Pick Color", ShowAlphaChannel)
        if color.isValid():
            if target == "line": 
                self.line_color = color
                self.update_color_btn(self.btn_line_color, color)
            elif target == "fill":
                self.fill_color = color
                self.update_color_btn(self.btn_fill_color, color)
            elif target == "text": 
                self.label_color = color
                self.update_color_btn(self.btn_txt_color, color)
            elif target == "callout":
                self.callout_color = color
                self.update_color_btn(self.btn_callout_color, color)
            else: 
                self.halo_color = color
                self.update_color_btn(self.btn_halo_color, color)
            
            self._update_live_preview()

    def get_style(self):
        c_l = self.line_color.getRgb()
        c_f = self.fill_color.getRgb()
        c_t = self.label_color.getRgb()
        c_h = self.halo_color.getRgb()
        c_c = self.callout_color.getRgb()
        return {
            "color": (c_l[0], c_l[1], c_l[2], c_l[3]),
            "fill_color": (c_f[0], c_f[1], c_f[2], c_f[3]),
            "width": self.spin_width.value(),
            "point_size": self.spin_pt_size.value(),
            "opacity": self.slider_op.value(),
            "fade": self.check_fade.isChecked(),
            "label_field": "", 
            "label_expr": self.edit_canvas.toPlainText(),
            "max_labels": self.spin_max_lbl.value(),
            "font_size": self.spin_font.value(),
            "label_color": (c_t[0], c_t[1], c_t[2], c_t[3]),
            "halo_color": (c_h[0], c_h[1], c_h[2], c_h[3]),
            "shadow": self.check_shadow.isChecked(),
            "preset": self.combo_preset.currentText(),
            "billboard_shape": self.combo_bb_shape.currentText(),
            "light_angle": self.dial_angle.value(),
            "shadow_dist": self.slider_shadow_dist.value(),
            "shadow_blur": self.slider_shadow_blur.value(),
            "callout_color": (c_c[0], c_c[1], c_c[2], c_c[3]),
            "callout_width": self.spin_callout_w.value(),
            "live_sync": self.check_live_sync.isChecked(),
            "z_offset": self.spin_z_offset.value(),
            "use_feature_z": self.check_use_3dz.isChecked(),
        }