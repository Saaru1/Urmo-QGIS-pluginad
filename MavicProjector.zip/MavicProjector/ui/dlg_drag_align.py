"""
Dedicated floating non-modal Drag Align dialog allowing users to explicitly select
which geometric alignment plane to drag directly on the photo (including center-anchored
Forward Pitch / Ground Tilt), plus live fine-tuning sliders and wireframe appearance controls.
"""
from qgis.PyQt.QtWidgets import QButtonGroup, QScrollArea
from ..compat_drone import (
    Horizontal,
    NonModal,
    QCheckBox,
    QColor,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSlider,
    QSpinBox,
    QVBoxLayout,
    QWidget,
    Window,
    pyqtSignal,
)
from ..core.i18n import tr, ui_prefs
from .theme import apply_theme


WIREFRAME_COLORS = [
    ("Neon Green", QColor(0, 255, 140, 235)),
    ("Cyan", QColor(0, 229, 255, 235)),
    ("Magenta", QColor(255, 64, 220, 235)),
    ("Yellow", QColor(255, 235, 59, 235)),
    ("Red", QColor(255, 70, 70, 235)),
    ("White", QColor(255, 255, 255, 235)),
]


class DragAlignDialog(QDialog):
    modeChanged = pyqtSignal(str)
    poseSlidersChanged = pyqtSignal(dict)
    forwardPitchChanged = pyqtSignal(float)
    wireframeStyleChanged = pyqtSignal(object, int, bool)
    applyRequested = pyqtSignal()
    resetRequested = pyqtSignal()
    dialogClosed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Window)
        self.setWindowModality(NonModal)
        self.resize(470, 640)
        self._active_mode = "pan_rot"
        self._syncing = False

        self.initUI()
        self.retranslate_ui()
        self.apply_current_theme()

        ui_prefs.languageChanged.connect(self.retranslate_ui)
        ui_prefs.themeChanged.connect(self.apply_current_theme)

    def initUI(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # Header
        self.lbl_subtitle = QLabel()
        self.lbl_subtitle.setProperty("role", "muted")
        self.lbl_subtitle.setWordWrap(True)
        root.addWidget(self.lbl_subtitle)

        # --- Section 1: Alignment Plane Selector ---
        mode_card = QFrame()
        mode_card.setProperty("role", "card")
        mode_lay = QVBoxLayout(mode_card)
        mode_lay.setContentsMargins(10, 8, 10, 8)
        mode_lay.setSpacing(6)

        self.lbl_sec_mode = QLabel()
        self.lbl_sec_mode.setProperty("role", "section")
        mode_lay.addWidget(self.lbl_sec_mode)

        grid_modes = QGridLayout()
        grid_modes.setSpacing(6)

        self.mode_group = QButtonGroup(self)
        self.mode_buttons = {}
        mode_defs = [
            ("pan_rot", 0, 0),
            ("forward_pitch", 0, 1),
            ("roll", 1, 0),
            ("focal", 1, 1),
            ("xy_shift", 2, 0),
            ("horizon", 2, 1),
        ]
        for idx, (m_key, r, c) in enumerate(mode_defs):
            btn = QPushButton()
            btn.setCheckable(True)
            btn.setProperty("role", "modeBtn")
            self.mode_group.addButton(btn, idx)
            self.mode_buttons[m_key] = btn
            grid_modes.addWidget(btn, r, c)

        self.mode_buttons["pan_rot"].setChecked(True)
        self.mode_group.buttonClicked.connect(self._on_mode_btn_clicked)
        mode_lay.addLayout(grid_modes)

        # Active mode description banner
        desc_box = QFrame()
        desc_box.setProperty("role", "infoBanner")
        desc_lay = QVBoxLayout(desc_box)
        desc_lay.setContentsMargins(8, 6, 8, 6)
        self.lbl_mode_desc = QLabel()
        self.lbl_mode_desc.setWordWrap(True)
        desc_lay.addWidget(self.lbl_mode_desc)
        mode_lay.addWidget(desc_box)

        root.addWidget(mode_card)

        # --- Section 2: Live Fine-Tuning Sliders ---
        slider_card = QFrame()
        slider_card.setProperty("role", "card")
        sl_lay = QVBoxLayout(slider_card)
        sl_lay.setContentsMargins(10, 8, 10, 8)
        sl_lay.setSpacing(6)

        self.lbl_sec_sliders = QLabel()
        self.lbl_sec_sliders.setProperty("role", "section")
        sl_lay.addWidget(self.lbl_sec_sliders)

        grid = QGridLayout()
        grid.setSpacing(6)

        # Helper to create labeled slider + spinbox row (scale factor for integer slider)
        def _add_slider_row(row_idx, s_min, s_max, spin_min, spin_max, scale, step, decimals, suffix=""):
            lbl = QLabel()
            sld = QSlider(Horizontal)
            sld.setRange(int(round(s_min * scale)), int(round(s_max * scale)))
            spn = QDoubleSpinBox()
            spn.setRange(spin_min, spin_max)
            spn.setDecimals(decimals)
            spn.setSingleStep(step)
            if suffix:
                spn.setSuffix(suffix)
            spn.setFixedWidth(92)
            grid.addWidget(lbl, row_idx, 0)
            grid.addWidget(sld, row_idx, 1)
            grid.addWidget(spn, row_idx, 2)
            return lbl, sld, spn

        self.lbl_yaw, self.sld_yaw, self.spn_yaw = _add_slider_row(0, -30, 30, -180.0, 180.0, 100, 0.05, 2, "°")
        self.lbl_pitch, self.sld_pitch, self.spn_pitch = _add_slider_row(1, -20, 20, -45.0, 45.0, 100, 0.05, 2, "°")
        self.lbl_fpitch, self.sld_fpitch, self.spn_fpitch = _add_slider_row(2, -20, 20, -30.0, 30.0, 100, 0.1, 2, "°")
        self.lbl_roll, self.sld_roll, self.spn_roll = _add_slider_row(3, -20, 20, -45.0, 45.0, 100, 0.05, 2, "°")
        self.lbl_focal, self.sld_focal, self.spn_focal = _add_slider_row(4, 75, 135, 50.0, 250.0, 10, 0.2, 1, "%")
        self.spn_focal.setValue(100.0)
        self.sld_focal.setValue(1000)

        self.lbl_height, self.sld_height, self.spn_height = _add_slider_row(5, -45, 10, -100.0, 100.0, 10, 0.2, 2, "m")

        # X / Y Ground shift row
        self.lbl_xy = QLabel()
        xy_box = QHBoxLayout()
        xy_box.setContentsMargins(0, 0, 0, 0)
        self.spn_x = QDoubleSpinBox()
        self.spn_x.setRange(-500.0, 500.0)
        self.spn_x.setDecimals(2)
        self.spn_x.setSingleStep(0.5)
        self.spn_x.setPrefix("E: ")
        self.spn_y = QDoubleSpinBox()
        self.spn_y.setRange(-500.0, 500.0)
        self.spn_y.setDecimals(2)
        self.spn_y.setSingleStep(0.5)
        self.spn_y.setPrefix("N: ")
        xy_box.addWidget(self.spn_x)
        xy_box.addWidget(self.spn_y)
        grid.addWidget(self.lbl_xy, 6, 0)
        grid.addLayout(xy_box, 6, 1, 1, 2)

        sl_lay.addLayout(grid)
        root.addWidget(slider_card)

        # Wire slider <-> spinbox connections cleanly (no default-arg lambdas for PyQt6 safety)
        self.sld_yaw.valueChanged.connect(self._on_sld_yaw)
        self.spn_yaw.valueChanged.connect(self._on_spn_pose)
        self.sld_pitch.valueChanged.connect(self._on_sld_pitch)
        self.spn_pitch.valueChanged.connect(self._on_spn_pose)
        self.sld_fpitch.valueChanged.connect(self._on_sld_fpitch)
        self.spn_fpitch.valueChanged.connect(self._on_spn_fpitch)
        self.sld_roll.valueChanged.connect(self._on_sld_roll)
        self.spn_roll.valueChanged.connect(self._on_spn_pose)
        self.sld_focal.valueChanged.connect(self._on_sld_focal)
        self.spn_focal.valueChanged.connect(self._on_spn_pose)
        self.sld_height.valueChanged.connect(self._on_sld_height)
        self.spn_height.valueChanged.connect(self._on_spn_pose)
        self.spn_x.valueChanged.connect(self._on_spn_pose)
        self.spn_y.valueChanged.connect(self._on_spn_pose)

        # --- Section 3: Wireframe Appearance ---
        wf_card = QFrame()
        wf_card.setProperty("role", "card")
        wf_lay = QHBoxLayout(wf_card)
        wf_lay.setContentsMargins(10, 6, 10, 6)

        self.chk_show_wf = QCheckBox()
        self.chk_show_wf.setChecked(True)
        self.chk_show_wf.toggled.connect(self._emit_wf_style)
        wf_lay.addWidget(self.chk_show_wf)

        self.lbl_wf_color = QLabel()
        wf_lay.addWidget(self.lbl_wf_color)
        self.combo_wf_color = QComboBox()
        for cname, col in WIREFRAME_COLORS:
            self.combo_wf_color.addItem(cname, col)
        self.combo_wf_color.currentIndexChanged.connect(self._emit_wf_style)
        wf_lay.addWidget(self.combo_wf_color)

        self.lbl_wf_width = QLabel()
        wf_lay.addWidget(self.lbl_wf_width)
        self.spn_wf_width = QSpinBox()
        self.spn_wf_width.setRange(1, 10)
        self.spn_wf_width.setValue(4)
        self.spn_wf_width.valueChanged.connect(self._emit_wf_style)
        wf_lay.addWidget(self.spn_wf_width)
        root.addWidget(wf_card)

        self.lbl_shortcut = QLabel()
        self.lbl_shortcut.setProperty("role", "muted")
        self.lbl_shortcut.setWordWrap(True)
        root.addWidget(self.lbl_shortcut)

        # Footer action buttons
        btn_row = QHBoxLayout()
        self.btn_reset = QPushButton()
        self.btn_reset.clicked.connect(self.resetRequested.emit)

        self.btn_apply = QPushButton()
        self.btn_apply.setProperty("role", "primary")
        self.btn_apply.clicked.connect(self.applyRequested.emit)

        self.btn_close = QPushButton()
        self.btn_close.clicked.connect(self.close)

        btn_row.addWidget(self.btn_reset)
        btn_row.addWidget(self.btn_apply, stretch=2)
        btn_row.addWidget(self.btn_close)
        root.addLayout(btn_row)

    @property
    def active_mode(self):
        return self._active_mode

    def set_active_mode(self, mode_key, emit_signal=True):
        if mode_key not in self.mode_buttons:
            return
        self._active_mode = mode_key
        self.mode_buttons[mode_key].setChecked(True)
        self._update_mode_desc()
        if emit_signal:
            self.modeChanged.emit(mode_key)

    def _on_mode_btn_clicked(self, btn):
        for m_key, b in self.mode_buttons.items():
            if b is btn:
                self._active_mode = m_key
                self._update_mode_desc()
                self.modeChanged.emit(m_key)
                break

    def _update_mode_desc(self):
        desc_keys = {
            "pan_rot": "da_desc_pan",
            "forward_pitch": "da_desc_fpitch",
            "roll": "da_desc_roll",
            "focal": "da_desc_focal",
            "xy_shift": "da_desc_xy",
            "horizon": "da_desc_horizon",
        }
        self.lbl_mode_desc.setText(tr(desc_keys.get(self._active_mode, "da_desc_pan")))

    def sync_from_viewer(self, yaw, pitch, roll, focal_pct, geoid_z, x_off, y_off, forward_pitch_deg=None):
        self._syncing = True
        try:
            self.spn_yaw.setValue(float(yaw))
            self.sld_yaw.setValue(max(self.sld_yaw.minimum(), min(self.sld_yaw.maximum(), int(round(yaw * 100)))))

            self.spn_pitch.setValue(float(pitch))
            self.sld_pitch.setValue(max(self.sld_pitch.minimum(), min(self.sld_pitch.maximum(), int(round(pitch * 100)))))

            if forward_pitch_deg is not None:
                self.spn_fpitch.setValue(float(forward_pitch_deg))
                self.sld_fpitch.setValue(
                    max(self.sld_fpitch.minimum(), min(self.sld_fpitch.maximum(), int(round(forward_pitch_deg * 100))))
                )

            self.spn_roll.setValue(float(roll))
            self.sld_roll.setValue(max(self.sld_roll.minimum(), min(self.sld_roll.maximum(), int(round(roll * 100)))))

            self.spn_focal.setValue(float(focal_pct))
            self.sld_focal.setValue(max(self.sld_focal.minimum(), min(self.sld_focal.maximum(), int(round(focal_pct * 10)))))

            self.spn_height.setValue(float(geoid_z))
            self.sld_height.setValue(max(self.sld_height.minimum(), min(self.sld_height.maximum(), int(round(geoid_z * 10)))))

            self.spn_x.setValue(float(x_off))
            self.spn_y.setValue(float(y_off))
        finally:
            self._syncing = False

    def _emit_pose(self, manual_geoid=False):
        if self._syncing:
            return
        self.poseSlidersChanged.emit(
            {
                "yaw": self.spn_yaw.value(),
                "pitch": self.spn_pitch.value(),
                "roll": self.spn_roll.value(),
                "focal_pct": self.spn_focal.value(),
                "geoid_z": self.spn_height.value(),
                "manual_geoid": manual_geoid,
                "x_off": self.spn_x.value(),
                "y_off": self.spn_y.value(),
            }
        )

    def _on_sld_yaw(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.spn_yaw.setValue(v / 100.0)
        self._syncing = False
        self._emit_pose(False)

    def _on_sld_pitch(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.spn_pitch.setValue(v / 100.0)
        self._syncing = False
        self._emit_pose(False)

    def _on_sld_roll(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.spn_roll.setValue(v / 100.0)
        self._syncing = False
        self._emit_pose(False)

    def _on_sld_focal(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.spn_focal.setValue(v / 10.0)
        self._syncing = False
        self._emit_pose(False)

    def _on_sld_height(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.spn_height.setValue(v / 10.0)
        self._syncing = False
        self._emit_pose(True)

    def _on_spn_pose(self, _val):
        if self._syncing:
            return
        sender = self.sender()
        self._syncing = True
        try:
            self.sld_yaw.setValue(max(self.sld_yaw.minimum(), min(self.sld_yaw.maximum(), int(round(self.spn_yaw.value() * 100)))))
            self.sld_pitch.setValue(max(self.sld_pitch.minimum(), min(self.sld_pitch.maximum(), int(round(self.spn_pitch.value() * 100)))))
            self.sld_roll.setValue(max(self.sld_roll.minimum(), min(self.sld_roll.maximum(), int(round(self.spn_roll.value() * 100)))))
            self.sld_focal.setValue(max(self.sld_focal.minimum(), min(self.sld_focal.maximum(), int(round(self.spn_focal.value() * 10)))))
            self.sld_height.setValue(max(self.sld_height.minimum(), min(self.sld_height.maximum(), int(round(self.spn_height.value() * 10)))))
        finally:
            self._syncing = False
        self._emit_pose(manual_geoid=(sender is self.spn_height))

    def _on_sld_fpitch(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.spn_fpitch.setValue(v / 100.0)
        self._syncing = False
        self.forwardPitchChanged.emit(v / 100.0)

    def _on_spn_fpitch(self, v):
        if self._syncing:
            return
        self._syncing = True
        self.sld_fpitch.setValue(max(self.sld_fpitch.minimum(), min(self.sld_fpitch.maximum(), int(round(v * 100)))))
        self._syncing = False
        self.forwardPitchChanged.emit(float(v))

    def _emit_wf_style(self, *_args):
        col = self.combo_wf_color.currentData()
        if not isinstance(col, QColor):
            col = QColor(0, 255, 140, 235)
        self.wireframeStyleChanged.emit(col, self.spn_wf_width.value(), self.chk_show_wf.isChecked())

    def current_wireframe_style(self):
        col = self.combo_wf_color.currentData()
        if not isinstance(col, QColor):
            col = QColor(0, 255, 140, 235)
        return col, self.spn_wf_width.value(), self.chk_show_wf.isChecked()

    def apply_current_theme(self, *_args):
        apply_theme(self)

    def retranslate_ui(self, *_args):
        self.setWindowTitle(tr("da_title"))
        self.lbl_subtitle.setText(tr("da_subtitle"))
        self.lbl_sec_mode.setText(tr("da_sec_mode"))
        self.mode_buttons["pan_rot"].setText(tr("da_mode_pan"))
        self.mode_buttons["forward_pitch"].setText(tr("da_mode_fpitch"))
        self.mode_buttons["roll"].setText(tr("da_mode_roll"))
        self.mode_buttons["focal"].setText(tr("da_mode_focal"))
        self.mode_buttons["xy_shift"].setText(tr("da_mode_xy"))
        self.mode_buttons["horizon"].setText(tr("da_mode_horizon"))
        self._update_mode_desc()

        self.lbl_sec_sliders.setText(tr("da_sec_sliders"))
        self.lbl_yaw.setText(tr("da_lbl_yaw"))
        self.lbl_pitch.setText(tr("da_lbl_pitch"))
        self.lbl_fpitch.setText(tr("da_lbl_fpitch"))
        self.lbl_roll.setText(tr("da_lbl_roll"))
        self.lbl_focal.setText(tr("da_lbl_focal"))
        self.lbl_height.setText(tr("da_lbl_height"))
        self.lbl_xy.setText(tr("da_lbl_xy"))

        self.chk_show_wf.setText(tr("da_chk_show_wf"))
        self.lbl_wf_color.setText(tr("da_lbl_wf_color"))
        self.lbl_wf_width.setText(tr("da_lbl_wf_width"))
        self.lbl_shortcut.setText(tr("da_shortcut_note"))
        self.btn_reset.setText(tr("btn_reset_all"))
        self.btn_apply.setText(tr("btn_apply_render"))
        self.btn_close.setText(tr("btn_close"))

    def closeEvent(self, event):
        self.dialogClosed.emit()
        super().closeEvent(event)
