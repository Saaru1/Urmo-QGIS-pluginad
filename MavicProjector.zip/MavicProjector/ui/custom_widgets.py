import re
from ..compat_drone import (
    CopyAction,
    DropOnly,
    ExtendedSelection,
    QListWidget,
    ScrollBarAlwaysOff,
    pyqtSignal,
)
from qgis.core import QgsProject


class PhotoListWidget(QListWidget):
    filesDropped = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setDragDropMode(DropOnly)
        self.setSelectionMode(ExtendedSelection)
        self.setAlternatingRowColors(True)
        self.setProperty("role", "dropzone")
        self.setMinimumWidth(180)
        self.setHorizontalScrollBarPolicy(ScrollBarAlwaysOff)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
            links = []
            for url in event.mimeData().urls():
                if url.isLocalFile():
                    path = url.toLocalFile()
                    if path.lower().endswith(('.jpg', '.jpeg')):
                        links.append(path)
            if links:
                self.filesDropped.emit(links)
        else:
            event.ignore()


class LayerListWidget(QListWidget):
    layersDropped = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setDragDropMode(DropOnly)
        self.setSelectionMode(ExtendedSelection)
        self.setAlternatingRowColors(True)
        self.setProperty("role", "dropzone")
        self.setMinimumWidth(180)
        self.setHorizontalScrollBarPolicy(ScrollBarAlwaysOff)

    def dragEnterEvent(self, event):
        if (
            event.mimeData().hasFormat("application/x-vnd.qgis.qgis.uri")
            or event.mimeData().hasFormat("application/qgis.maplayerlist")
            or event.mimeData().hasFormat("application/qgis.layertreemodeldata")
        ):
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if (
            event.mimeData().hasFormat("application/x-vnd.qgis.qgis.uri")
            or event.mimeData().hasFormat("application/qgis.maplayerlist")
            or event.mimeData().hasFormat("application/qgis.layertreemodeldata")
        ):
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        mime_data = event.mimeData()

        if mime_data.hasFormat("application/qgis.layertreemodeldata"):
            event.setDropAction(CopyAction)
            event.accept()
            try:
                xml_data = bytes(mime_data.data("application/qgis.layertreemodeldata")).decode('utf-8', errors='ignore')
                layer_ids = re.findall(r'id="([^"]+)"', xml_data)
                layers = [QgsProject.instance().mapLayer(lid) for lid in layer_ids if QgsProject.instance().mapLayer(lid)]
                if layers:
                    self.layersDropped.emit(layers)
            except Exception:
                pass

        elif mime_data.hasFormat("application/x-vnd.qgis.qgis.uri"):
            event.setDropAction(CopyAction)
            event.accept()
            try:
                data = bytes(mime_data.data("application/x-vnd.qgis.qgis.uri")).decode('utf-8', errors='ignore')
                parts = data.split(':')
                if len(parts) >= 2:
                    layers = QgsProject.instance().mapLayersByName(parts[1])
                    if layers:
                        self.layersDropped.emit([layers[0]])
            except Exception:
                pass

        elif mime_data.hasFormat("application/qgis.maplayerlist"):
            event.setDropAction(CopyAction)
            event.accept()
            try:
                data = bytes(mime_data.data("application/qgis.maplayerlist")).decode('utf-8', errors='ignore')
                layer_ids = data.strip().split('\n')
                layers = [QgsProject.instance().mapLayer(lid) for lid in layer_ids if lid and QgsProject.instance().mapLayer(lid)]
                if layers:
                    self.layersDropped.emit(layers)
            except Exception:
                pass
        else:
            event.ignore()
