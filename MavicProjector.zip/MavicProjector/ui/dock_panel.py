import os
import json
import glob
from datetime import datetime
import numpy as np
from qgis.PyQt.QtWidgets import QTabWidget, QListWidget, QAbstractItemView
from qgis.PyQt.QtGui import QIcon, QPixmap, QPainter, QColor, QPen, QBrush, QMovie
from qgis.PyQt.QtCore import QSize

from ..compat_drone import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QTextEdit, QDoubleSpinBox, QSpinBox, QgsMapLayerComboBox, QComboBox,
    QListWidgetItem, QSettings, QgsApplication, UserRole, BottomDockWidgetArea,
    exec_dialog, QFileDialog, QLineEdit, QProgressBar, QGridLayout,
    ItemIsUserCheckable, Checked, Unchecked, QgsProject, QgsVectorLayer,
    QgsFeature, QgsGeometry, QgsPointXY, QgsFillSymbol, QgsMarkerSymbol,
    QgsTextFormat, QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QVariant, QgsField,
    QgsTextBufferSettings, LabelPlacementOverPoint, AlignCenter,
    FilterPolygon, FilterLine, FilterRaster, FilterPoint, KeepAspectRatio
)
from .custom_widgets import PhotoListWidget, LayerListWidget

class MavicDockPanel(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Dashboard", parent)
        self.iface = iface
        self.settings = QSettings("MavicProjectorPlugin", "UI_Settings")
        self.setAllowedAreas(BottomDockWidgetArea)
        self.task = None
        self.viewer_instance = None 
        self.connected_layers = {} 
        self.initUI()
        
    def initUI(self):
        self.tabs = QTabWidget()
        
        self.active_tab = QWidget()
        self.archive_tab = QWidget()
        
        self.setup_active_tab()
        self.setup_archive_tab()
        
        self.tabs.addTab(self.active_tab, "Active Job")
        self.tabs.addTab(self.archive_tab, "Archive")
        
        self.setWidget(self.tabs)
        self.refresh_archive_list()

    def setup_active_tab(self):
        main_layout = QHBoxLayout() 
        
        col1 = QVBoxLayout()
        col1.addWidget(QLabel("1. Layers (Vectors & WMS)"))
        
        add_layer_h = QHBoxLayout()
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(FilterPoint | FilterPolygon | FilterLine | FilterRaster)
        
        add_btn = QPushButton("+ Add")
        add_btn.clicked.connect(self.add_combo_layer_to_list)
        add_layer_h.addWidget(self.layer_combo)
        add_layer_h.addWidget(add_btn)
        col1.addLayout(add_layer_h)
        
        lbl_hint1 = QLabel("<i>💡 Checkbox = ONLY Selected Features<br>💡 Double-Click = Change Colors/Live Sync</i>")
        lbl_hint1.setStyleSheet("color: #aaa; font-size: 10px;")
        col1.addWidget(lbl_hint1)

        self.layer_list = LayerListWidget()
        self.layer_list.layersDropped.connect(self.add_dropped_layers_to_list)
        self.layer_list.itemDoubleClicked.connect(self.open_layer_properties)
        col1.addWidget(self.layer_list)

        rem_layer_btn = QPushButton("- Remove Selected Layer")
        rem_layer_btn.clicked.connect(lambda: self.remove_selected(self.layer_list))
        col1.addWidget(rem_layer_btn)
        main_layout.addLayout(col1, 2) 
        
        col2 = QVBoxLayout()
        col2.addWidget(QLabel("2. Photos (Drop .JPGs here)"))
        
        add_photo_h = QHBoxLayout()
        browse_btn = QPushButton("+ Browse Photos...")
        browse_btn.clicked.connect(self.browse_photos)
        rem_photo_btn = QPushButton("- Remove Selected")
        rem_photo_btn.clicked.connect(lambda: self.remove_selected(self.photo_list))
        add_photo_h.addWidget(browse_btn)
        add_photo_h.addWidget(rem_photo_btn)
        col2.addLayout(add_photo_h)
        
        lbl_hint2 = QLabel("<i>💡 Double-click = Tweaks | Right-click = Open Viewer</i>")
        lbl_hint2.setStyleSheet("color: #aaa; font-size: 10px;")
        col2.addWidget(lbl_hint2)

        self.photo_list = PhotoListWidget()
        self.photo_list.filesDropped.connect(self.add_photos_to_list)
        self.photo_list.itemDoubleClicked.connect(self.open_photo_properties)
        col2.addWidget(self.photo_list)
        
        view_photo_btn = QPushButton("👁️ OPEN INTERACTIVE VIEWER")
        view_photo_btn.setStyleSheet("background-color: #2b579a; color: white; font-size: 14px; font-weight: bold; padding: 12px; border-radius: 4px;")
        view_photo_btn.clicked.connect(self.open_interactive_viewer)
        col2.addWidget(view_photo_btn)

        self.btn_dump_xmp = QPushButton("📝 Dump XMP to Log")
        self.btn_dump_xmp.setStyleSheet("background-color: #444; color: white;")
        self.btn_dump_xmp.clicked.connect(self.dump_xmp_for_selected)
        col2.addWidget(self.btn_dump_xmp)

        self.map_btn = QPushButton("🗺️ Show Cameras on Map")
        self.map_btn.setStyleSheet("background-color: #555; color: white; font-weight: bold; padding: 4px;")
        self.map_btn.clicked.connect(self.toggle_cameras_on_map)
        col2.addWidget(self.map_btn)
        main_layout.addLayout(col2, 2)
        
        col3 = QVBoxLayout()
        col3.addWidget(QLabel("3. Global Fallbacks"))

        h_fall = QHBoxLayout()
        h_fall.addWidget(QLabel("Fallback Z (m):"))
        self.elevation_box = QDoubleSpinBox()
        self.elevation_box.setRange(-50.0, 4000.0)
        self.elevation_box.setValue(float(self.settings.value("fallback_z", 0.0)))
        h_fall.addWidget(self.elevation_box)
        col3.addLayout(h_fall)

        h_src = QHBoxLayout()
        h_src.addWidget(QLabel("Elevation Source:"))
        self.dem_combo = QComboBox()
        self.dem_combo.addItem("Maa-amet DTM (Ground)", "dtm-1")
        self.dem_combo.addItem("Maa-amet DSM (Trees/Roofs)", "dsm-1")
        h_src.addWidget(self.dem_combo)
        col3.addLayout(h_src)

        h_geo = QHBoxLayout()
        h_geo.addWidget(QLabel("Geoid (EH2000) [0=Auto]:"))
        self.geoid_box = QDoubleSpinBox()
        self.geoid_box.setRange(-100.0, 100.0)
        self.geoid_box.setValue(float(self.settings.value("geoid_offset", 0.0)))
        h_geo.addWidget(self.geoid_box)
        col3.addLayout(h_geo)
        
        h_pitch = QHBoxLayout()
        h_pitch.addWidget(QLabel("Pitch Offset (°):"))
        self.pitch_offset_box = QDoubleSpinBox()
        self.pitch_offset_box.setRange(-45.0, 45.0)
        self.pitch_offset_box.setValue(float(self.settings.value("pitch_offset", 0.0)))
        self.pitch_offset_box.setSingleStep(0.1)
        h_pitch.addWidget(self.pitch_offset_box)
        col3.addLayout(h_pitch)

        h_yaw = QHBoxLayout()
        h_yaw.addWidget(QLabel("Yaw (Crab) Offset (°):"))
        self.yaw_offset_box = QDoubleSpinBox()
        self.yaw_offset_box.setRange(-180.0, 180.0)
        self.yaw_offset_box.setValue(float(self.settings.value("yaw_offset", 0.0)))
        self.yaw_offset_box.setSingleStep(0.1)
        h_yaw.addWidget(self.yaw_offset_box)
        col3.addLayout(h_yaw)

        h_x = QHBoxLayout()
        h_x.addWidget(QLabel("X Nudge (East m):"))
        self.x_offset_box = QDoubleSpinBox()
        self.x_offset_box.setRange(-50.0, 50.0)
        self.x_offset_box.setValue(float(self.settings.value("x_offset", 0.0)))
        self.x_offset_box.setSingleStep(0.5)
        h_x.addWidget(self.x_offset_box)
        col3.addLayout(h_x)

        h_y = QHBoxLayout()
        h_y.addWidget(QLabel("Y Nudge (North m):"))
        self.y_offset_box = QDoubleSpinBox()
        self.y_offset_box.setRange(-50.0, 50.0)
        self.y_offset_box.setValue(float(self.settings.value("y_offset", 0.0)))
        self.y_offset_box.setSingleStep(0.5)
        h_y.addWidget(self.y_offset_box)
        col3.addLayout(h_y)

        col3.addWidget(QLabel("Lens Distortion Offsets:"))
        dist_grid = QGridLayout()
        dist_grid.setContentsMargins(0, 0, 0, 0)
        
        dist_grid.addWidget(QLabel("k1:"), 0, 0)
        self.k1_box = QDoubleSpinBox(); self.k1_box.setRange(-0.5, 0.5); self.k1_box.setDecimals(3); self.k1_box.setSingleStep(0.01)
        self.k1_box.setValue(float(self.settings.value("k1_offset", 0.0)))
        dist_grid.addWidget(self.k1_box, 0, 1)
        
        dist_grid.addWidget(QLabel("k2:"), 0, 2)
        self.k2_box = QDoubleSpinBox(); self.k2_box.setRange(-0.5, 0.5); self.k2_box.setDecimals(3); self.k2_box.setSingleStep(0.01)
        self.k2_box.setValue(float(self.settings.value("k2_offset", 0.0)))
        dist_grid.addWidget(self.k2_box, 0, 3)
        
        dist_grid.addWidget(QLabel("p1:"), 1, 0)
        self.p1_box = QDoubleSpinBox(); self.p1_box.setRange(-0.5, 0.5); self.p1_box.setDecimals(3); self.p1_box.setSingleStep(0.01)
        self.p1_box.setValue(float(self.settings.value("p1_offset", 0.0)))
        dist_grid.addWidget(self.p1_box, 1, 1)
        
        dist_grid.addWidget(QLabel("p2:"), 1, 2)
        self.p2_box = QDoubleSpinBox(); self.p2_box.setRange(-0.5, 0.5); self.p2_box.setDecimals(3); self.p2_box.setSingleStep(0.01)
        self.p2_box.setValue(float(self.settings.value("p2_offset", 0.0)))
        dist_grid.addWidget(self.p2_box, 1, 3)
        
        dist_grid.addWidget(QLabel("k3:"), 2, 0)
        self.k3_box = QDoubleSpinBox(); self.k3_box.setRange(-0.5, 0.5); self.k3_box.setDecimals(3); self.k3_box.setSingleStep(0.01)
        self.k3_box.setValue(float(self.settings.value("k3_offset", 0.0)))
        dist_grid.addWidget(self.k3_box, 2, 1)
        
        col3.addLayout(dist_grid)
        col3.addStretch() 
        main_layout.addLayout(col3, 1)
        
        col4 = QVBoxLayout()
        col4.addWidget(QLabel("Processing Logs:"))
        
        from qgis.PyQt.QtWidgets import QFrame
        self.log_container = QFrame()
        self.log_container.setStyleSheet("background-color: #1e1e1e; border: 1px solid #444; border-radius: 2px;") 
        
        log_and_gif_layout = QHBoxLayout(self.log_container)
        log_and_gif_layout.setContentsMargins(0, 0, 0, 0)
        log_and_gif_layout.setSpacing(0)
        
        self.log_panel = QTextEdit()
        self.log_panel.setReadOnly(True)
        self.log_panel.setStyleSheet("color: #00ff00; font-family: monospace; font-size: 10px; border: none; background: transparent;")
        log_and_gif_layout.addWidget(self.log_panel, stretch=1)
        
        self.gif_label = QLabel()
        self.gif_label.setAlignment(AlignCenter)
        self.gif_label.setStyleSheet("border: none; background: transparent; margin: 0px; padding: 0px;")
        
        gif_path = os.path.join(os.path.dirname(__file__), 'Tulemu2s.gif')
        self.gif_movie = QMovie(gif_path)
        
        self.gif_movie.jumpToFrame(0)
        native_size = self.gif_movie.currentImage().size()
        if not native_size.isEmpty() and native_size.height() > 0:
            native_size.scale(200, 200, KeepAspectRatio)
            self.gif_movie.setScaledSize(native_size)
            self.gif_label.setFixedSize(native_size)
        else:
            self.gif_label.setFixedSize(112, 200)
            
        self.gif_label.setMovie(self.gif_movie)
        self.gif_label.hide()
        
        sp = self.gif_label.sizePolicy()
        sp.setRetainSizeWhenHidden(True)
        self.gif_label.setSizePolicy(sp)
        
        log_and_gif_layout.addWidget(self.gif_label)
        col4.addWidget(self.log_container)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p% - Ready")
        col4.addWidget(self.progress_bar)

        run_layout = QHBoxLayout()
        self.run_btn = QPushButton("START BATCH PROCESSING")
        self.run_btn.setStyleSheet("background-color: #0078D7; color: white; font-weight: bold; padding: 15px;")
        self.run_btn.clicked.connect(self.process_image)
        
        self.cancel_btn = QPushButton("CANCEL")
        self.cancel_btn.setStyleSheet("background-color: #A00000; color: white; font-weight: bold; padding: 15px;")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self.cancel_processing)
        
        run_layout.addWidget(self.run_btn, 3)
        run_layout.addWidget(self.cancel_btn, 1)
        col4.addLayout(run_layout)
        
        main_layout.addLayout(col4, 3)
        self.active_tab.setLayout(main_layout)

    def dump_xmp_for_selected(self):
        selected_items = self.photo_list.selectedItems()
        if not selected_items:
            self.log("⚠️ Please select a photo from the list first.")
            return
            
        path = selected_items[0].data(UserRole)
        base_name = os.path.basename(path)
        suggested_filename = f"XMP_DUMP_{os.path.splitext(base_name)[0]}.txt"
        
        save_path, _ = QFileDialog.getSaveFileName(
            self, "Save XMP Dump File", suggested_filename, "Text Files (*.txt)"
        )
        
        if not save_path:
            return 
            
        try:
            with open(path, 'rb') as f:
                img_data = f.read()
            
            xmp_start = img_data.find(b'<x:xmpmeta')
            xmp_end = img_data.find(b'</x:xmpmeta>')
            
            raw_header_data = "No XMP tags found in file."
            if xmp_start != -1 and xmp_end != -1:
                raw_header_data = img_data[xmp_start:xmp_end+12].decode('utf-8', errors='ignore')
            
            from ..core.metadata_parser import MetadataParser
            parsed_dict = MetadataParser.extract_xmp(path)
            
            report = []
            report.append("=" * 60)
            report.append(f"MAVIC PROJECTOR - DETAILED XMP DUMP")
            report.append(f"Target File: {path}")
            report.append(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            report.append("=" * 60)
            report.append("\n💡 HOW THE PLUGIN INTERPRETS THIS PHOTO:")
            for k, v in parsed_dict.items():
                if isinstance(v, np.ndarray):
                    report.append(f"  -> {k}:\n{v}")
                else:
                    report.append(f"  -> {k}: {v}")
            report.append("\n" + "=" * 60)
            report.append("🔍 RAW UNPROCESSED XMP HEADER DATA:")
            report.append("=" * 60)
            report.append(raw_header_data)
            
            with open(save_path, 'w', encoding='utf-8') as out_f:
                out_f.write("\n".join(report))
                
            self.log(f"💾 Successfully saved XMP metadata dump to:\n   {save_path}")
            
        except Exception as e:
            self.log(f"❌ Failed to save dump file: {e}")

    def setup_archive_tab(self):
        layout = QVBoxLayout()
        
        header = QLabel("Saved Processing Jobs")
        header.setStyleSheet("font-size: 14px; font-weight: bold;")
        layout.addWidget(header)
        
        hint = QLabel("<i>Every successful batch process automatically saves its setup here.</i>")
        hint.setStyleSheet("color: #aaa;")
        layout.addWidget(hint)
        
        self.archive_list = QListWidget()
        self.archive_list.setIconSize(QSize(120, 80))
        self.archive_list.setSpacing(5)
        self.archive_list.itemDoubleClicked.connect(self.restore_job)
        layout.addWidget(self.archive_list)
        
        btn_layout = QHBoxLayout()
        restore_btn = QPushButton("📂 Restore")
        restore_btn.setStyleSheet("background-color: #2b579a; color: white; font-weight: bold; padding: 10px;")
        restore_btn.clicked.connect(self.restore_job)
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_archive_list)

        self.btn_del_job = QPushButton("🗑️ Delete Selected")
        self.btn_del_job.clicked.connect(self.delete_selected_job)
        
        self.btn_del_all = QPushButton("🗑️ Delete All")
        self.btn_del_all.setStyleSheet("background-color: #A00000; color: white;")
        self.btn_del_all.clicked.connect(self.delete_all_jobs)
        
        btn_layout.addWidget(restore_btn)
        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(self.btn_del_job)
        btn_layout.addWidget(self.btn_del_all)
        
        layout.addLayout(btn_layout)
        self.archive_tab.setLayout(layout)

    def log(self, text):
        self.log_panel.append(text)
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(text, "MavicProjector", Qgis.Info)
        
    def save_settings(self):
        self.settings.setValue("fallback_z", self.elevation_box.value())
        self.settings.setValue("geoid_offset", self.geoid_box.value())
        self.settings.setValue("yaw_offset", self.yaw_offset_box.value())
        self.settings.setValue("pitch_offset", self.pitch_offset_box.value())
        self.settings.setValue("x_offset", self.x_offset_box.value())
        self.settings.setValue("y_offset", self.y_offset_box.value())
        self.settings.setValue("k1_offset", self.k1_box.value())
        self.settings.setValue("k2_offset", self.k2_box.value())
        self.settings.setValue("p1_offset", self.p1_box.value())
        self.settings.setValue("p2_offset", self.p2_box.value())
        self.settings.setValue("k3_offset", self.k3_box.value())

    def _add_layer(self, layer):
        items = [self.layer_list.item(i).text() for i in range(self.layer_list.count())]
        if layer.name() not in items:
            item = QListWidgetItem(layer.name())
            item.setData(UserRole, layer) 
            item.setFlags(item.flags() | ItemIsUserCheckable)
            item.setCheckState(Unchecked)
            
            pixmap = QPixmap(20, 20)
            pixmap.fill(QColor(43, 43, 43))
            painter = QPainter(pixmap)
            
            geom_type = layer.geometryType() if layer.type() == 0 else -1
            
            default_style = {
                "color": (255, 255, 0, 200), "fill_color": (255, 255, 0, 50), 
                "width": 6, "point_size": 10, "opacity": 100, "fade": True, 
                "label_field": "", "label_expr": "", "max_labels": 15, "font_size": 48, 
                "halo_color": (0, 0, 0, 255), "shadow": False, "live_sync": False,
                "callout_color": (255, 255, 255, 255), "callout_width": 5 # Updated Defaults
            }
            
            if layer.type() == 1:
                default_style["opacity"] = 60 

            painter.setPen(QPen(QColor(*default_style["color"]), 2))
            if geom_type == 0: 
                painter.setBrush(QBrush(QColor(*default_style["color"])))
                painter.drawEllipse(5, 5, 10, 10)
            elif geom_type == 1: 
                painter.drawLine(2, 18, 18, 2)
            elif geom_type == 2: 
                painter.setBrush(QBrush(QColor(*default_style["fill_color"])))
                painter.drawRect(3, 3, 14, 14)
            elif layer.type() == 1:
                painter.setBrush(QBrush(QColor(100, 100, 255, 150)))
                painter.drawRect(2, 2, 16, 16)
                painter.drawLine(2, 10, 18, 10)
                painter.drawLine(10, 2, 10, 18)
                
            painter.end()
            item.setIcon(QIcon(pixmap))

            item.setData(UserRole + 1, default_style)
            self.layer_list.addItem(item)
            
            if layer.id() not in self.connected_layers:
                layer.styleChanged.connect(lambda l_id=layer.id(): self.handle_live_style_sync(l_id))
                self.connected_layers[layer.id()] = layer
                
            self.log(f"Added layer: {layer.name()}")

    def add_combo_layer_to_list(self):
        layer = self.layer_combo.currentLayer()
        if layer: self._add_layer(layer)

    def add_dropped_layers_to_list(self, layers):
        for layer in layers: self._add_layer(layer)

    def browse_photos(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select DJI Photos", "", "JPEG Images (*.jpg *.jpeg *.JPG *.JPEG)")
        if files: self.add_photos_to_list(files)

    def add_photos_to_list(self, file_paths):
        for path in file_paths:
            items = [self.photo_list.item(i).data(UserRole) for i in range(self.photo_list.count())]
            if path not in items:
                name = os.path.basename(path)
                item = QListWidgetItem(name)
                item.setData(UserRole, path) 
                item.setData(UserRole + 1, {})
                self.photo_list.addItem(item)
                self.log(f"Added photo: {name}")

    def remove_selected(self, list_widget):
        for item in list_widget.selectedItems():
            list_widget.takeItem(list_widget.row(item))

    def open_photo_properties(self, item):
        from .dlg_photo_props import PhotoPropertiesDialog
        photo_path = item.data(UserRole)
        current_overrides = item.data(UserRole + 1) or {}
        dialog = PhotoPropertiesDialog(photo_path, current_overrides, self)
        if exec_dialog(dialog):
            overrides = dialog.get_overrides()
            item.setData(UserRole + 1, overrides)
            base_name = os.path.basename(photo_path)
            if any(v != 0.0 and v is not None for v in overrides.values()):
                item.setText(f"{base_name} [Custom Offsets]")
            else:
                item.setText(base_name)

    def open_layer_properties(self, item):
        from .dlg_layer_style import LayerStyleDialog
        layer = item.data(UserRole)
        current_style = item.data(UserRole + 1)
        dialog = LayerStyleDialog(layer, current_style, self)
        if exec_dialog(dialog):
            new_style = dialog.get_style()
            item.setData(UserRole + 1, new_style)
            self.update_layer_list_icon(item, layer, new_style)

            base_name = layer.name()
            flags = []
            if new_style.get('live_sync'): flags.append("🔗 SYNC")
            if new_style.get('label_expr') or new_style.get('label_field'): flags.append("Labels")
            
            if flags:
                item.setText(f"{base_name} [{', '.join(flags)}]")
            else:
                item.setText(base_name)
            self.log(f"Updated style for layer: {base_name}")

    def handle_live_style_sync(self, layer_id):
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer = item.data(UserRole)
            
            if layer and layer.id() == layer_id:
                current_style = item.data(UserRole + 1)
                
                if current_style.get('live_sync', False):
                    updated_style = self.extract_qgis_style(layer, current_style)
                    item.setData(UserRole + 1, updated_style)
                    self.update_layer_list_icon(item, layer, updated_style)
                    self.refresh_viewer_if_open()
                break

    def extract_qgis_style(self, layer, current_style):
        new_style = current_style.copy()
        
        if layer.type() == 0: 
            renderer = layer.renderer()
            if renderer:
                symbol = None
                if renderer.type() == "singleSymbol":
                    symbol = renderer.symbol()
                elif renderer.type() in ["categorizedSymbol", "graduatedSymbol"]:
                    if renderer.categories(): 
                        symbol = renderer.categories()[0].symbol()
                elif renderer.type() == "ruleRenderer":
                    if renderer.rootRule().children():
                        symbol = renderer.rootRule().children()[0].symbol()
                        
                if symbol:
                    c = symbol.color()
                    alpha = max(100, c.alpha())
                    new_style["color"] = (c.red(), c.green(), c.blue(), alpha)
                    
                    if layer.geometryType() == 2: 
                        if symbol.symbolLayerCount() > 0:
                            sl = symbol.symbolLayer(0)
                            
                            from ..compat_drone import NoBrush
                            has_brush = True
                            if hasattr(sl, 'brushStyle'):
                                if sl.brushStyle() == NoBrush or sl.brushStyle() == 0:
                                    has_brush = False
                                    
                            if has_brush and hasattr(sl, 'fillColor'):
                                fc = sl.fillColor()
                                new_style["fill_color"] = (fc.red(), fc.green(), fc.blue(), min(100, fc.alpha()))
                            else:
                                new_style["fill_color"] = (0, 0, 0, 0)
                                
                            if hasattr(sl, 'strokeColor'):
                                oc = sl.strokeColor()
                                new_style["color"] = (oc.red(), oc.green(), oc.blue(), max(100, oc.alpha()))
                                
                            if hasattr(sl, 'strokeWidth'):
                                new_style["width"] = max(2, int(sl.strokeWidth() * 10))
                                
                    elif layer.geometryType() == 1:
                        new_style["width"] = max(2, int(symbol.width() * 8))
                    elif layer.geometryType() == 0:
                        new_style["point_size"] = max(20, int(symbol.size() * 12))
                        
        return new_style

    def update_layer_list_icon(self, item, layer, style):
        pixmap = QPixmap(20, 20)
        pixmap.fill(QColor(43, 43, 43))
        painter = QPainter(pixmap)
        geom_type = layer.geometryType() if layer.type() == 0 else -1
        
        c_r, c_g, c_b, c_a = style["color"]
        f_r, f_g, f_b, f_a = style["fill_color"]
        opacity = style.get("opacity", 100) / 100.0
        
        p_color = QColor(c_r, c_g, c_b, int(c_a * opacity))
        f_color = QColor(f_r, f_g, f_b, int(f_a * opacity))
        
        painter.setPen(QPen(p_color, 2))
        if geom_type == 0:
            painter.setBrush(QBrush(p_color))
            painter.drawEllipse(5, 5, 10, 10)
        elif geom_type == 1:
            painter.drawLine(2, 18, 18, 2)
        elif geom_type == 2:
            painter.setBrush(QBrush(f_color))
            painter.drawRect(3, 3, 14, 14)
        elif layer.type() == 1:
            painter.setBrush(QBrush(QColor(100, 100, 255, 150)))
            painter.drawRect(2, 2, 16, 16)
            painter.drawLine(2, 10, 18, 10)
            painter.drawLine(10, 2, 10, 18)
            
        painter.end()
        item.setIcon(QIcon(pixmap))

    def refresh_viewer_if_open(self):
        if self.viewer_instance is not None and self.viewer_instance.isVisible():
            gallery_data = []
            for i in range(self.photo_list.count()):
                p_item = self.photo_list.item(i)
                gallery_data.append({
                    'name': os.path.basename(p_item.data(UserRole)),
                    'raw_path': p_item.data(UserRole),
                    'proj_path': p_item.data(UserRole).replace(".jpg", "_PROJECTED.jpg").replace(".JPG", "_PROJECTED.jpg"),
                    'overrides': p_item.data(UserRole + 1) or {}
                })
            
            self.viewer_instance.gallery_data = gallery_data
            
            try:
                if hasattr(self.viewer_instance, 'refresh_live_sync'):
                    self.viewer_instance.refresh_live_sync()
            except Exception:
                pass

    def get_or_create_dem_layer(self):
        ident = self.dem_combo.currentData()
        uri = f"dpiMode=7&identifier={ident}&tilePixelRatio=0&url=https://teenus.maaamet.ee/ows/wcs-dtm"
        if "dsm" in ident:
            uri = uri.replace("wcs-dtm", "wcs-dsm") 

        from ..compat_drone import QgsRasterLayer
        raster_layer = QgsRasterLayer(uri, f"Kogu Eesti {ident.upper()}", "wcs")
        if raster_layer.isValid(): return raster_layer
        else: raise Exception("Failed to connect to Maa-amet WCS service.")

    def open_interactive_viewer(self):
        if self.photo_list.count() == 0:
            self.log("❌ Add at least one photo to the list first.")
            return

        gallery_data = []
        temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
        os.makedirs(temp_dir, exist_ok=True)
        
        for i in range(self.photo_list.count()):
            item = self.photo_list.item(i)
            raw_path = item.data(UserRole)
            overrides = item.data(UserRole + 1) or {}
                
            out_name = os.path.basename(raw_path).replace(".jpg", "_PROJECTED.jpg").replace(".JPG", "_PROJECTED.jpg")
            proj_path = os.path.join(temp_dir, out_name)
            
            gallery_data.append({
                'name': os.path.basename(raw_path),
                'raw_path': raw_path,
                'proj_path': proj_path,
                'overrides': overrides
            })

        start_index = self.photo_list.currentRow()
        if start_index < 0: start_index = 0

        try:
            from .viewer_dialog import InteractiveViewer
            from ..compat_drone import NonModal, Window
            
            dem_layer = None
            try: dem_layer = self.get_or_create_dem_layer()
            except: pass
            
            global_settings = {
                'fallback_z': self.elevation_box.value(),
                'geoid_offset': self.geoid_box.value(),
                'pitch_offset': self.pitch_offset_box.value(),
                'yaw_offset': self.yaw_offset_box.value(),
                'x_offset': self.x_offset_box.value(),
                'y_offset': self.y_offset_box.value(),
                'dist_offsets': {
                    'k1': self.k1_box.value(),
                    'k2': self.k2_box.value(),
                    'p1': self.p1_box.value(),
                    'p2': self.p2_box.value(),
                    'k3': self.k3_box.value()
                }
            }
            
            if self.viewer_instance is not None:
                self.viewer_instance.update_gallery(gallery_data, start_index)
                self.viewer_instance.showNormal() 
                self.viewer_instance.raise_()
                self.viewer_instance.activateWindow()
                return

            self.viewer_instance = InteractiveViewer(gallery_data, start_index, global_settings, dem_layer, self)
            self.viewer_instance.setWindowModality(NonModal)
            self.viewer_instance.setWindowFlags(Window)
            self.viewer_instance.show()
        except Exception as e:
            self.log(f"Viewer Error: {e}")

    def toggle_cameras_on_map(self):
        existing_cam = QgsProject.instance().mapLayersByName("Drone Cameras")
        if existing_cam:
            QgsProject.instance().removeMapLayer(existing_cam[0].id())
            self.map_btn.setText("🗺️ Show Cameras on Map")
            self.map_btn.setStyleSheet("background-color: #555; color: white; font-weight: bold; padding: 4px;")
            self.log("🗺️ Removed cameras from map.")
            self.iface.mapCanvas().refresh()
            return

        from ..core.metadata_parser import MetadataParser
        from ..core.math_engine import MathEngine
        from qgis.core import QgsFillSymbol 

        photo_paths = [self.photo_list.item(i).data(UserRole) for i in range(self.photo_list.count())]
        if not photo_paths:
            self.log("❌ No photos added.")
            return

        self.log("🗺️ Calculating 2D camera FOV footprints...")
        
        vl = QgsVectorLayer("MultiPolygon?crs=EPSG:3301", "Drone Cameras", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("photo", QVariant.String)])
        vl.updateFields()
        
        sym = QgsFillSymbol.createSimple({
            'color': '160,32,240,60', 
            'outline_color': '160,32,240,200', 
            'outline_width': '0.4',
            'outline_style': 'dash'
        })
        vl.renderer().setSymbol(sym)
        
        settings = QgsPalLayerSettings()
        settings.fieldName = 'photo'
        settings.placement = LabelPlacementOverPoint
        text_format = QgsTextFormat()
        text_format.setSize(10)
        halo = QgsTextBufferSettings()
        halo.setEnabled(True)
        halo.setSize(1)
        halo.setColor(QColor("white"))
        text_format.setBuffer(halo)
        settings.setFormat(text_format)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        vl.setLabelsEnabled(True)

        for path in photo_paths:
            try:
                overrides = {}
                for i in range(self.photo_list.count()):
                    item = self.photo_list.item(i)
                    if item.data(UserRole) == path:
                        overrides = item.data(UserRole + 1) or {}
                        break

                active_pitch = overrides.get('pitch_offset', self.pitch_offset_box.value())
                active_yaw = overrides.get('yaw_offset', self.yaw_offset_box.value())
                
                dist_dict = {
                    'k1': overrides.get('k1', self.k1_box.value()),
                    'k2': overrides.get('k2', self.k2_box.value()),
                    'p1': overrides.get('p1', self.p1_box.value()),
                    'p2': overrides.get('p2', self.p2_box.value()),
                    'k3': overrides.get('k3', self.k3_box.value())
                }
                
                tel = MetadataParser.extract_xmp(path, dist_dict)
                
                active_geoid = overrides.get('geoid_offset', self.geoid_box.value())
                if active_geoid == 0.0:
                    active_geoid = tel.get('auto_geoid', -18.0)

                safe_context = QgsProject.instance().transformContext()
                engine = MathEngine(tel, active_geoid, active_yaw, active_pitch, transform_context=safe_context)
                
                drone_poly, fov_poly = engine.get_simple_map_polygons()
                
                f = QgsFeature(vl.fields())
                geom = QgsGeometry.fromMultiPolygonXY([[drone_poly], [fov_poly]])
                f.setGeometry(geom)
                f.setAttribute("photo", f"{os.path.basename(path)} (P:{engine.grid_pitch:.1f}°)")
                pr.addFeature(f)
                    
            except Exception as e:
                self.log(f"Map Error for {os.path.basename(path)}: {e}")

        vl.updateExtents()
        QgsProject.instance().addMapLayer(vl)
        self.map_btn.setText("🗺️ Hide Cameras from Map")
        self.map_btn.setStyleSheet("background-color: #2b579a; color: white; font-weight: bold; padding: 4px;")
        self.log("🗺️ Added cameras to map!")
        self.iface.mapCanvas().refresh()

    def set_eta_info(self, text, eta_seconds):
        self.progress_bar.setFormat(text)
        if eta_seconds >= 30:
            if self.gif_label.isHidden():
                self.gif_label.show()
                self.gif_movie.start()
        else:
            if not self.gif_label.isHidden():
                self.gif_label.hide()
                self.gif_movie.stop()
        
    def cancel_processing(self):
        if self.task:
            self.task.cancel()
            self.cancel_btn.setEnabled(False)
            self.log("🛑 Canceling task... safely stopping and clearing memory.")
        self.gif_label.hide()
        self.gif_movie.stop()

    def process_image(self, checked=False, override_out_dir=None):
        self.save_settings() 

        layer_items = []
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            is_checked = item.checkState() == Checked
            layer_items.append({
                'layer': item.data(UserRole),
                'style': item.data(UserRole + 1),
                'selected_only': is_checked
            })
            
        photo_items = []
        for i in range(self.photo_list.count()):
            item = self.photo_list.item(i)
            photo_items.append({
                'path': item.data(UserRole),
                'overrides': item.data(UserRole + 1)
            })

        if not layer_items or not photo_items:
            self.log("❌ Missing Data: Add at least 1 Layer and 1 Photo.")
            return

        if isinstance(override_out_dir, str):
            out_folder = override_out_dir
        else:
            temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
            os.makedirs(temp_dir, exist_ok=True)
            out_folder = temp_dir

        self.log_panel.clear()
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p% - Initializing...")
        self.run_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.log("--- Initializing Batch Projection ---")

        try:
            dem_layer = self.get_or_create_dem_layer()
        except Exception as e:
            self.log(f"❌ Error loading DTM/DSM: {e}")
            self.run_btn.setEnabled(True)
            self.cancel_btn.setEnabled(False)
            return

        settings_dict = {
            'fallback_z': self.elevation_box.value(),
            'geoid_offset': self.geoid_box.value(),
            'yaw_offset': self.yaw_offset_box.value(),
            'pitch_offset': self.pitch_offset_box.value(),
            'x_offset': self.x_offset_box.value(),
            'y_offset': self.y_offset_box.value(),
            'dist_offsets': {
                'k1': self.k1_box.value(),
                'k2': self.k2_box.value(),
                'p1': self.p1_box.value(),
                'p2': self.p2_box.value(),
                'k3': self.k3_box.value()
            },
            'out_folder': out_folder
        }

        from ..core.task_worker import ProjectionTask
        
        safe_context = QgsProject.instance().transformContext()
        
        self.task = ProjectionTask(photo_items, layer_items, dem_layer, settings_dict, transform_context=safe_context)
        self.task.signals.log_signal.connect(self.log)
        self.task.signals.eta_signal.connect(self.set_eta_info)
        self.task.progressChanged.connect(lambda v: self.progress_bar.setValue(int(v)))
        self.task.signals.max_progress_signal.connect(self.progress_bar.setMaximum)
        self.task.signals.finished_signal.connect(self.on_task_finished)
        
        QgsApplication.taskManager().addTask(self.task)

    def on_task_finished(self, success, err_msg):
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.gif_label.hide()
        self.gif_movie.stop()
        
        if success:
            self.progress_bar.setValue(self.progress_bar.maximum())
            self.progress_bar.setFormat("100% - Finished!")
            self.save_job_to_archive()

    def save_job_to_archive(self):
        try:
            job_data = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "global_settings": {
                    "fallback_z": self.elevation_box.value(),
                    "geoid_offset": self.geoid_box.value(),
                    "yaw_offset": self.yaw_offset_box.value(),
                    "pitch_offset": self.pitch_offset_box.value(),
                    "x_offset": self.x_offset_box.value(),
                    "y_offset": self.y_offset_box.value(),
                    "dist_offsets": {
                        "k1": self.k1_box.value(),
                        "k2": self.k2_box.value(),
                        "p1": self.p1_box.value(),
                        "p2": self.p2_box.value(),
                        "k3": self.k3_box.value()
                    }
                },
                "layers": [],
                "photos": []
            }

            for i in range(self.layer_list.count()):
                item = self.layer_list.item(i)
                layer = item.data(UserRole)
                job_data["layers"].append({
                    "name": layer.name(),
                    "id": layer.id(),
                    "style": item.data(UserRole + 1),
                    "selected_only": item.checkState() == Checked
                })

            for i in range(self.photo_list.count()):
                item = self.photo_list.item(i)
                job_data["photos"].append({
                    "path": item.data(UserRole),
                    "overrides": item.data(UserRole + 1)
                })

            jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
            os.makedirs(jobs_dir, exist_ok=True)
            filename = f"Job_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            with open(os.path.join(jobs_dir, filename), 'w') as f:
                json.dump(job_data, f, indent=4)
                
            self.refresh_archive_list()
        except Exception as e:
            self.log(f"⚠️ Failed to save job archive: {e}")

    def refresh_archive_list(self):
        self.archive_list.clear()
        jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
        if not os.path.exists(jobs_dir): return
        
        for job_file in sorted(glob.glob(os.path.join(jobs_dir, "*.json")), reverse=True):
            try:
                with open(job_file, 'r') as f:
                    job_data = json.load(f)
                    
                ts = job_data.get("timestamp", "Unknown Date")
                photo_count = len(job_data.get("photos", []))
                layer_count = len(job_data.get("layers", []))
                
                item = QListWidgetItem(f"Job: {ts}\n{photo_count} Photos, {layer_count} Vectors")
                item.setData(UserRole, job_file)
                
                if photo_count > 0:
                    first_photo = job_data["photos"][0]["path"]
                    out_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
                    out_name = os.path.basename(first_photo).replace(".jpg", "_PROJECTED.jpg").replace(".JPG", "_PROJECTED.jpg")
                    proj_path = os.path.join(out_dir, out_name)
                    if os.path.exists(proj_path):
                        pixmap = QPixmap(proj_path)
                        if not pixmap.isNull():
                            icon = QIcon(pixmap)
                            item.setIcon(icon)
                            
                self.archive_list.addItem(item)
            except Exception:
                pass

    def restore_job(self):
        item = self.archive_list.currentItem()
        if not item: return
        job_path = item.data(UserRole)
        
        try:
            with open(job_path, 'r') as f:
                job_data = json.load(f)
                
            settings = job_data.get("global_settings", {})
            self.elevation_box.setValue(settings.get("fallback_z", 0.0))
            self.geoid_box.setValue(settings.get("geoid_offset", 0.0))
            self.yaw_offset_box.setValue(settings.get("yaw_offset", 0.0))
            self.pitch_offset_box.setValue(settings.get("pitch_offset", 0.0))
            self.x_offset_box.setValue(settings.get("x_offset", 0.0))
            self.y_offset_box.setValue(settings.get("y_offset", 0.0))
            
            dists = settings.get("dist_offsets", {})
            self.k1_box.setValue(dists.get("k1", 0.0))
            self.k2_box.setValue(dists.get("k2", 0.0))
            self.p1_box.setValue(dists.get("p1", 0.0))
            self.p2_box.setValue(dists.get("p2", 0.0))
            self.k3_box.setValue(dists.get("k3", 0.0))
            
            self.photo_list.clear()
            for p in job_data.get("photos", []):
                path = p.get("path")
                if os.path.exists(path):
                    name = os.path.basename(path)
                    l_item = QListWidgetItem(name)
                    l_item.setData(UserRole, path)
                    overrides = p.get("overrides", {})
                    l_item.setData(UserRole + 1, overrides)
                    if any(v != 0.0 and v is not None for v in overrides.values()):
                        l_item.setText(f"{name} [Custom Offsets]")
                    self.photo_list.addItem(l_item)
                    
            self.layer_list.clear()
            proj = QgsProject.instance()
            for l in job_data.get("layers", []):
                layer = proj.mapLayer(l.get("id"))
                if not layer:
                    layers = proj.mapLayersByName(l.get("name"))
                    if layers: layer = layers[0]
                    
                if layer:
                    l_item = QListWidgetItem(layer.name())
                    l_item.setData(UserRole, layer)
                    l_item.setFlags(l_item.flags() | ItemIsUserCheckable)
                    l_item.setCheckState(Checked if l.get("selected_only") else Unchecked)
                    l_item.setData(UserRole + 1, l.get("style", {}))
                    
                    flags = []
                    style = l.get("style", {})
                    if style.get('live_sync'): flags.append("🔗 SYNC")
                    if style.get('label_expr') or style.get('label_field'): flags.append("Labels")
                    if flags: l_item.setText(f"{layer.name()} [{', '.join(flags)}]")
                    self.layer_list.addItem(l_item)
                    
                    if layer.id() not in self.connected_layers:
                        layer.styleChanged.connect(lambda l_id=layer.id(): self.handle_live_style_sync(l_id))
                        self.connected_layers[layer.id()] = layer
                    
            self.tabs.setCurrentIndex(0) 
            self.log("\n✅ Job restored from archive. Photos, Layers, and Offsets loaded.")
        except Exception as e:
            self.log(f"⚠️ Failed to restore job: {e}")
    
    def delete_selected_job(self):
        from ..compat_drone import QMessageBox, MsgYes, MsgNo
        item = self.archive_list.currentItem()
        if not item: return
        job_path = item.data(UserRole)
        
        reply = QMessageBox.question(self, 'Delete Job', 'Are you sure you want to delete this saved setup?', MsgYes | MsgNo, MsgNo)
        if reply == MsgYes:
            try:
                os.remove(job_path)
                self.refresh_archive_list()
                self.log("🗑️ Selected job deleted successfully.")
            except Exception as e:
                self.log(f"⚠️ Failed to delete job: {e}")

    def delete_all_jobs(self):
        from ..compat_drone import QMessageBox, MsgYes, MsgNo
        reply = QMessageBox.question(self, 'Delete All Jobs', 'Are you sure you want to delete ALL saved setups? This cannot be undone.', MsgYes | MsgNo, MsgNo)
        if reply == MsgYes:
            jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
            if os.path.exists(jobs_dir):
                count = 0
                for job_file in glob.glob(os.path.join(jobs_dir, "*.json")):
                    try:
                        os.remove(job_file)
                        count += 1
                    except Exception: 
                        pass
                self.refresh_archive_list()
                self.log(f"🗑️ Cleared {count} saved jobs from archive.")