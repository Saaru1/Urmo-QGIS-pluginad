import glob
import json
import os
from datetime import datetime
from functools import partial
import numpy as np
from qgis.PyQt.QtCore import QSize
from qgis.PyQt.QtGui import QBrush, QColor, QIcon, QMovie, QPainter, QPen, QPixmap
from qgis.PyQt.QtWidgets import QCheckBox, QFrame, QListWidget, QTabWidget

from ..compat_drone import (
    AlignCenter,
    BottomDockWidgetArea,
    Checked,
    FilterLine,
    FilterPoint,
    FilterPolygon,
    FilterRaster,
    ItemIsUserCheckable,
    KeepAspectRatio,
    LabelPlacementOverPoint,
    QComboBox,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidgetItem,
    QProgressBar,
    QPushButton,
    QSettings,
    QTextEdit,
    QVBoxLayout,
    QVariant,
    QWidget,
    QgsApplication,
    QgsFeature,
    QgsField,
    QgsFillSymbol,
    QgsGeometry,
    QgsMapLayerComboBox,
    QgsPalLayerSettings,
    QgsProject,
    QgsRasterLayer,
    QgsTextBufferSettings,
    QgsTextFormat,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
    Unchecked,
    UserRole,
    exec_dialog,
)
from ..core.i18n import tr, ui_prefs
from .custom_widgets import LayerListWidget, PhotoListWidget
from .theme import apply_theme


def _has_meaningful_overrides(overrides):
    if not overrides:
        return False
    for k, v in overrides.items():
        if k == 'label_offsets' and v:
            return True
        if k == 'use_auto_geoid' and v is False:
            return True
        if k == 'focal_scale' and abs(float(v) - 1.0) > 1e-4:
            return True
        if k == 'dist_offsets' and isinstance(v, dict) and any(abs(float(x)) > 1e-6 for x in v.values()):
            return True
        if k in ('pitch_offset', 'yaw_offset', 'roll_offset', 'x_offset', 'y_offset') and abs(float(v)) > 1e-6:
            return True
        if k == 'lens_override' and v and v != 'Auto (From File)':
            return True
    return False


class MavicDockPanel(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Mavic Projector", parent)
        self.iface = iface
        self.settings = QSettings("MavicProjectorPlugin", "UI_Settings")
        self.setAllowedAreas(BottomDockWidgetArea)
        self.task = None
        self.viewer_instance = None
        self.connected_layers = {}
        self.initUI()

        self.retranslate_ui()
        self.apply_current_theme()

        ui_prefs.languageChanged.connect(self.retranslate_ui)
        ui_prefs.themeChanged.connect(self.apply_current_theme)
        QgsProject.instance().layersAdded.connect(self.refresh_dem_sources)
        QgsProject.instance().layersRemoved.connect(self.refresh_dem_sources)

    def initUI(self):
        root_widget = QWidget()
        root_widget.setObjectName("MavicRoot")
        root_layout = QVBoxLayout(root_widget)
        root_layout.setContentsMargins(6, 4, 6, 6)
        root_layout.setSpacing(6)

        # --- Clean Header Bar (Title + EN/ET + Dark/Light) ---
        header_bar = QFrame()
        header_bar.setProperty("role", "header")
        hb_lay = QHBoxLayout(header_bar)
        hb_lay.setContentsMargins(10, 4, 10, 4)
        hb_lay.setSpacing(8)

        self.lbl_app_title = QLabel()
        self.lbl_app_title.setProperty("role", "title")
        hb_lay.addWidget(self.lbl_app_title)

        self.lbl_ver_badge = QLabel("v1.2")
        self.lbl_ver_badge.setProperty("role", "muted")
        hb_lay.addWidget(self.lbl_ver_badge)

        hb_lay.addStretch()

        self.btn_lang = QPushButton()
        self.btn_lang.setProperty("role", "pill")
        self.btn_lang.clicked.connect(ui_prefs.toggle_language)
        hb_lay.addWidget(self.btn_lang)

        self.btn_theme = QPushButton()
        self.btn_theme.setProperty("role", "pill")
        self.btn_theme.clicked.connect(ui_prefs.toggle_theme)
        hb_lay.addWidget(self.btn_theme)

        root_layout.addWidget(header_bar)

        self.tabs = QTabWidget()
        self.active_tab = QWidget()
        self.archive_tab = QWidget()

        self.setup_active_tab()
        self.setup_archive_tab()

        self.tabs.addTab(self.active_tab, "")
        self.tabs.addTab(self.archive_tab, "")

        root_layout.addWidget(self.tabs, stretch=1)
        self.setWidget(root_widget)
        self.refresh_archive_list()

    def setup_active_tab(self):
        main_layout = QHBoxLayout(self.active_tab)
        main_layout.setContentsMargins(6, 6, 6, 6)
        main_layout.setSpacing(8)

        # --- Card 1: Layers ---
        card1 = QFrame()
        card1.setProperty("role", "card")
        col1 = QVBoxLayout(card1)
        col1.setContentsMargins(8, 8, 8, 8)
        col1.setSpacing(5)

        self.lbl_sec_layers = QLabel()
        self.lbl_sec_layers.setProperty("role", "section")
        col1.addWidget(self.lbl_sec_layers)

        add_layer_h = QHBoxLayout()
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(FilterPoint | FilterPolygon | FilterLine | FilterRaster)
        self.btn_add_layer = QPushButton()
        self.btn_add_layer.setProperty("role", "primary")
        self.btn_add_layer.clicked.connect(self.add_combo_layer_to_list)
        add_layer_h.addWidget(self.layer_combo, stretch=1)
        add_layer_h.addWidget(self.btn_add_layer)
        col1.addLayout(add_layer_h)

        self.lbl_hint1 = QLabel()
        self.lbl_hint1.setProperty("role", "muted")
        self.lbl_hint1.setWordWrap(True)
        col1.addWidget(self.lbl_hint1)

        self.layer_list = LayerListWidget()
        self.layer_list.layersDropped.connect(self.add_dropped_layers_to_list)
        self.layer_list.itemDoubleClicked.connect(self.open_layer_properties)
        col1.addWidget(self.layer_list, stretch=1)

        self.btn_rem_layer = QPushButton()
        self.btn_rem_layer.clicked.connect(partial(self.remove_selected, self.layer_list))
        col1.addWidget(self.btn_rem_layer)
        main_layout.addWidget(card1, 2)

        # --- Card 2: Photos ---
        card2 = QFrame()
        card2.setProperty("role", "card")
        col2 = QVBoxLayout(card2)
        col2.setContentsMargins(8, 8, 8, 8)
        col2.setSpacing(5)

        self.lbl_sec_photos = QLabel()
        self.lbl_sec_photos.setProperty("role", "section")
        col2.addWidget(self.lbl_sec_photos)

        add_photo_h = QHBoxLayout()
        self.btn_browse_photos = QPushButton()
        self.btn_browse_photos.setProperty("role", "primary")
        self.btn_browse_photos.clicked.connect(self.browse_photos)
        self.btn_rem_photo = QPushButton()
        add_photo_h.addWidget(self.btn_browse_photos, stretch=2)
        add_photo_h.addWidget(self.btn_rem_photo, stretch=1)
        col2.addLayout(add_photo_h)

        self.lbl_hint2 = QLabel()
        self.lbl_hint2.setProperty("role", "muted")
        self.lbl_hint2.setWordWrap(True)
        col2.addWidget(self.lbl_hint2)

        self.photo_list = PhotoListWidget()
        self.photo_list.filesDropped.connect(self.add_photos_to_list)
        self.photo_list.itemDoubleClicked.connect(self.open_photo_properties)
        self.btn_rem_photo.clicked.connect(partial(self.remove_selected, self.photo_list))
        col2.addWidget(self.photo_list, stretch=1)

        self.btn_open_viewer = QPushButton()
        self.btn_open_viewer.setProperty("role", "primary")
        self.btn_open_viewer.setMinimumHeight(34)
        self.btn_open_viewer.clicked.connect(self.open_interactive_viewer)
        col2.addWidget(self.btn_open_viewer)

        photo_tools_h = QHBoxLayout()
        self.btn_dump_xmp = QPushButton()
        self.btn_dump_xmp.clicked.connect(self.dump_xmp_for_selected)
        self.map_btn = QPushButton()
        self.map_btn.clicked.connect(self.toggle_cameras_on_map)
        photo_tools_h.addWidget(self.btn_dump_xmp)
        photo_tools_h.addWidget(self.map_btn)
        col2.addLayout(photo_tools_h)
        main_layout.addWidget(card2, 2)

        # --- Card 3: Global Settings (Compact 2-Tab Card to fit Bottom Dock comfortably) ---
        card3 = QFrame()
        card3.setProperty("role", "card")
        col3 = QVBoxLayout(card3)
        col3.setContentsMargins(8, 8, 8, 8)
        col3.setSpacing(5)

        self.lbl_sec_global = QLabel()
        self.lbl_sec_global.setProperty("role", "section")
        col3.addWidget(self.lbl_sec_global)

        self.settings_subtabs = QTabWidget()

        # Sub-tab A: Elevation & Pose
        sub_pose = QWidget()
        pose_lay = QVBoxLayout(sub_pose)
        pose_lay.setContentsMargins(6, 6, 6, 6)
        pose_lay.setSpacing(4)

        elev_grid = QGridLayout()
        elev_grid.setSpacing(4)

        self.lbl_elev_src = QLabel()
        self.dem_combo = QComboBox()
        self.refresh_dem_sources()
        elev_grid.addWidget(self.lbl_elev_src, 0, 0)
        elev_grid.addWidget(self.dem_combo, 0, 1, 1, 3)

        self.lbl_alt_mode = QLabel()
        self.alt_mode_combo = QComboBox()
        self.alt_mode_combo.addItem("", "auto")
        self.alt_mode_combo.addItem("", "rtk")
        self.alt_mode_combo.addItem("", "rel_dem")
        self.alt_mode_combo.addItem("", "msl")
        saved_alt_mode = str(self.settings.value("alt_mode", "auto"))
        idx_am = self.alt_mode_combo.findData(saved_alt_mode)
        if idx_am >= 0:
            self.alt_mode_combo.setCurrentIndex(idx_am)
        elev_grid.addWidget(self.lbl_alt_mode, 1, 0)
        elev_grid.addWidget(self.alt_mode_combo, 1, 1, 1, 3)

        self.lbl_fallback_z = QLabel()
        self.elevation_box = QDoubleSpinBox()
        self.elevation_box.setRange(-50.0, 4000.0)
        self.elevation_box.setValue(float(self.settings.value("fallback_z", 0.0)))
        elev_grid.addWidget(self.lbl_fallback_z, 2, 0)
        elev_grid.addWidget(self.elevation_box, 2, 1)

        self.chk_auto_geoid = QCheckBox()
        use_auto_g = str(self.settings.value("use_auto_geoid", "true")).lower() != "false"
        self.chk_auto_geoid.setChecked(use_auto_g)
        self.geoid_box = QDoubleSpinBox()
        self.geoid_box.setRange(-100.0, 100.0)
        self.geoid_box.setDecimals(2)
        self.geoid_box.setValue(float(self.settings.value("geoid_offset", 0.0)))
        self.geoid_box.setEnabled(not use_auto_g)
        self.chk_auto_geoid.toggled.connect(self._on_auto_geoid_toggled)
        elev_grid.addWidget(self.chk_auto_geoid, 2, 2)
        elev_grid.addWidget(self.geoid_box, 2, 3)

        self.lbl_pitch = QLabel()
        self.pitch_offset_box = QDoubleSpinBox()
        self.pitch_offset_box.setRange(-45.0, 45.0)
        self.pitch_offset_box.setDecimals(2)
        self.pitch_offset_box.setSingleStep(0.1)
        self.pitch_offset_box.setValue(float(self.settings.value("pitch_offset", 0.0)))
        elev_grid.addWidget(self.lbl_pitch, 3, 0)
        elev_grid.addWidget(self.pitch_offset_box, 3, 1)

        self.lbl_yaw = QLabel()
        self.yaw_offset_box = QDoubleSpinBox()
        self.yaw_offset_box.setRange(-180.0, 180.0)
        self.yaw_offset_box.setDecimals(2)
        self.yaw_offset_box.setSingleStep(0.1)
        self.yaw_offset_box.setValue(float(self.settings.value("yaw_offset", 0.0)))
        elev_grid.addWidget(self.lbl_yaw, 3, 2)
        elev_grid.addWidget(self.yaw_offset_box, 3, 3)

        self.lbl_roll = QLabel()
        self.roll_offset_box = QDoubleSpinBox()
        self.roll_offset_box.setRange(-45.0, 45.0)
        self.roll_offset_box.setDecimals(2)
        self.roll_offset_box.setSingleStep(0.1)
        self.roll_offset_box.setValue(float(self.settings.value("roll_offset", 0.0)))
        elev_grid.addWidget(self.lbl_roll, 4, 0)
        elev_grid.addWidget(self.roll_offset_box, 4, 1)

        self.lbl_focal_pct = QLabel()
        self.focal_scale_box = QDoubleSpinBox()
        self.focal_scale_box.setRange(50.0, 250.0)
        self.focal_scale_box.setDecimals(1)
        self.focal_scale_box.setSingleStep(0.5)
        self.focal_scale_box.setValue(float(self.settings.value("focal_scale_pct", 100.0)))
        elev_grid.addWidget(self.lbl_focal_pct, 4, 2)
        elev_grid.addWidget(self.focal_scale_box, 4, 3)

        self.lbl_x_east = QLabel()
        self.x_offset_box = QDoubleSpinBox()
        self.x_offset_box.setRange(-500.0, 500.0)
        self.x_offset_box.setSingleStep(0.5)
        self.x_offset_box.setValue(float(self.settings.value("x_offset", 0.0)))
        elev_grid.addWidget(self.lbl_x_east, 5, 0)
        elev_grid.addWidget(self.x_offset_box, 5, 1)

        self.lbl_y_north = QLabel()
        self.y_offset_box = QDoubleSpinBox()
        self.y_offset_box.setRange(-500.0, 500.0)
        self.y_offset_box.setSingleStep(0.5)
        self.y_offset_box.setValue(float(self.settings.value("y_offset", 0.0)))
        elev_grid.addWidget(self.lbl_y_north, 5, 2)
        elev_grid.addWidget(self.y_offset_box, 5, 3)

        pose_lay.addLayout(elev_grid)
        pose_lay.addStretch()

        # Sub-tab B: Lens Distortion
        sub_dist = QWidget()
        dist_lay = QVBoxLayout(sub_dist)
        dist_lay.setContentsMargins(8, 8, 8, 8)
        dist_grid = QGridLayout()
        dist_grid.setSpacing(6)

        dist_grid.addWidget(QLabel("k1:"), 0, 0)
        self.k1_box = QDoubleSpinBox()
        self.k1_box.setRange(-0.5, 0.5); self.k1_box.setDecimals(4); self.k1_box.setSingleStep(0.005)
        self.k1_box.setValue(float(self.settings.value("k1_offset", 0.0)))
        dist_grid.addWidget(self.k1_box, 0, 1)

        dist_grid.addWidget(QLabel("k2:"), 0, 2)
        self.k2_box = QDoubleSpinBox()
        self.k2_box.setRange(-0.5, 0.5); self.k2_box.setDecimals(4); self.k2_box.setSingleStep(0.005)
        self.k2_box.setValue(float(self.settings.value("k2_offset", 0.0)))
        dist_grid.addWidget(self.k2_box, 0, 3)

        dist_grid.addWidget(QLabel("p1:"), 1, 0)
        self.p1_box = QDoubleSpinBox()
        self.p1_box.setRange(-0.5, 0.5); self.p1_box.setDecimals(4); self.p1_box.setSingleStep(0.005)
        self.p1_box.setValue(float(self.settings.value("p1_offset", 0.0)))
        dist_grid.addWidget(self.p1_box, 1, 1)

        dist_grid.addWidget(QLabel("p2:"), 1, 2)
        self.p2_box = QDoubleSpinBox()
        self.p2_box.setRange(-0.5, 0.5); self.p2_box.setDecimals(4); self.p2_box.setSingleStep(0.005)
        self.p2_box.setValue(float(self.settings.value("p2_offset", 0.0)))
        dist_grid.addWidget(self.p2_box, 1, 3)

        dist_grid.addWidget(QLabel("k3:"), 2, 0)
        self.k3_box = QDoubleSpinBox()
        self.k3_box.setRange(-0.5, 0.5); self.k3_box.setDecimals(4); self.k3_box.setSingleStep(0.005)
        self.k3_box.setValue(float(self.settings.value("k3_offset", 0.0)))
        dist_grid.addWidget(self.k3_box, 2, 1)

        dist_lay.addLayout(dist_grid)
        dist_lay.addStretch()

        self.settings_subtabs.addTab(sub_pose, "")
        self.settings_subtabs.addTab(sub_dist, "")
        col3.addWidget(self.settings_subtabs, stretch=1)
        main_layout.addWidget(card3, 2)

        # --- Card 4: Logs & Execution ---
        card4 = QFrame()
        card4.setProperty("role", "card")
        col4 = QVBoxLayout(card4)
        col4.setContentsMargins(8, 8, 8, 8)
        col4.setSpacing(6)

        self.lbl_sec_logs = QLabel()
        self.lbl_sec_logs.setProperty("role", "section")
        col4.addWidget(self.lbl_sec_logs)

        self.log_container = QFrame()
        self.log_container.setProperty("role", "card")
        log_and_gif_layout = QHBoxLayout(self.log_container)
        log_and_gif_layout.setContentsMargins(2, 2, 2, 2)
        log_and_gif_layout.setSpacing(0)

        self.log_panel = QTextEdit()
        self.log_panel.setReadOnly(True)
        self.log_panel.setProperty("role", "log")
        log_and_gif_layout.addWidget(self.log_panel, stretch=1)

        self.gif_label = QLabel()
        self.gif_label.setAlignment(AlignCenter)
        gif_path = os.path.join(os.path.dirname(__file__), 'Tulemu2s.gif')
        self.gif_movie = QMovie(gif_path)
        self.gif_movie.jumpToFrame(0)
        native_size = self.gif_movie.currentImage().size()
        if not native_size.isEmpty() and native_size.height() > 0:
            native_size.scale(180, 180, KeepAspectRatio)
            self.gif_movie.setScaledSize(native_size)
            self.gif_label.setFixedSize(native_size)
        else:
            self.gif_label.setFixedSize(100, 180)
        self.gif_label.setMovie(self.gif_movie)
        self.gif_label.hide()

        sp = self.gif_label.sizePolicy()
        sp.setRetainSizeWhenHidden(True)
        self.gif_label.setSizePolicy(sp)
        log_and_gif_layout.addWidget(self.gif_label)
        col4.addWidget(self.log_container, stretch=1)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        col4.addWidget(self.progress_bar)

        run_layout = QHBoxLayout()
        run_layout.setSpacing(6)
        self.run_btn = QPushButton()
        self.run_btn.setProperty("role", "primary")
        self.run_btn.setMinimumHeight(38)
        self.run_btn.clicked.connect(self.process_image)

        self.export_dir_btn = QPushButton()
        self.export_dir_btn.setProperty("role", "success")
        self.export_dir_btn.setMinimumHeight(38)
        self.export_dir_btn.clicked.connect(self.export_batch_to_folder)

        self.cancel_btn = QPushButton()
        self.cancel_btn.setProperty("role", "danger")
        self.cancel_btn.setMinimumHeight(38)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self.cancel_processing)

        run_layout.addWidget(self.run_btn, 3)
        run_layout.addWidget(self.export_dir_btn, 2)
        run_layout.addWidget(self.cancel_btn, 1)
        col4.addLayout(run_layout)
        main_layout.addWidget(card4, 3)

    def _on_auto_geoid_toggled(self, checked):
        self.geoid_box.setEnabled(not checked)

    def setup_archive_tab(self):
        layout = QVBoxLayout(self.archive_tab)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        self.lbl_arch_header = QLabel()
        self.lbl_arch_header.setProperty("role", "title")
        layout.addWidget(self.lbl_arch_header)

        self.lbl_arch_hint = QLabel()
        self.lbl_arch_hint.setProperty("role", "muted")
        layout.addWidget(self.lbl_arch_hint)

        self.archive_list = QListWidget()
        self.archive_list.setIconSize(QSize(120, 80))
        self.archive_list.setSpacing(5)
        self.archive_list.itemDoubleClicked.connect(self.restore_job)
        layout.addWidget(self.archive_list, stretch=1)

        btn_layout = QHBoxLayout()
        self.btn_restore = QPushButton()
        self.btn_restore.setProperty("role", "primary")
        self.btn_restore.clicked.connect(self.restore_job)

        self.btn_refresh_arch = QPushButton()
        self.btn_refresh_arch.clicked.connect(self.refresh_archive_list)

        self.btn_del_job = QPushButton()
        self.btn_del_job.clicked.connect(self.delete_selected_job)

        self.btn_del_all = QPushButton()
        self.btn_del_all.setProperty("role", "danger")
        self.btn_del_all.clicked.connect(self.delete_all_jobs)

        btn_layout.addWidget(self.btn_restore)
        btn_layout.addWidget(self.btn_refresh_arch)
        btn_layout.addWidget(self.btn_del_job)
        btn_layout.addWidget(self.btn_del_all)
        layout.addLayout(btn_layout)

    def apply_current_theme(self, *_args):
        apply_theme(self)
        self.btn_theme.setText(tr("theme_light") if ui_prefs.theme == "dark" else tr("theme_dark"))

    def retranslate_ui(self, *_args):
        self.setWindowTitle(tr("dock_title"))
        self.lbl_app_title.setText(tr("app_title"))
        self.btn_lang.setText(tr("lang_toggle"))
        self.btn_lang.setToolTip(tr("lang_tooltip"))
        self.btn_theme.setText(tr("theme_light") if ui_prefs.theme == "dark" else tr("theme_dark"))
        self.btn_theme.setToolTip(tr("theme_tooltip"))

        self.tabs.setTabText(0, tr("tab_active_job"))
        self.tabs.setTabText(1, tr("tab_archive"))

        self.lbl_sec_layers.setText(tr("sec_layers"))
        self.btn_add_layer.setText(tr("btn_add"))
        self.lbl_hint1.setText(tr("hint_layers"))
        self.btn_rem_layer.setText(tr("btn_rem_layer"))

        self.lbl_sec_photos.setText(tr("sec_photos"))
        self.btn_browse_photos.setText(tr("btn_browse_photos"))
        self.btn_rem_photo.setText(tr("btn_rem_photo"))
        self.lbl_hint2.setText(tr("hint_photos"))
        self.btn_open_viewer.setText(tr("btn_open_viewer"))
        self.btn_dump_xmp.setText(tr("btn_dump_xmp"))
        has_cam = bool(QgsProject.instance().mapLayersByName("Drone Cameras"))
        self.map_btn.setText(tr("btn_hide_cams") if has_cam else tr("btn_show_cams"))

        self.lbl_sec_global.setText(tr("sec_global"))
        self.settings_subtabs.setTabText(0, tr("subtab_elev_pose"))
        self.settings_subtabs.setTabText(1, tr("subtab_distortion"))

        self.lbl_elev_src.setText(tr("lbl_elev_src"))
        self.refresh_dem_sources()
        self.lbl_alt_mode.setText(tr("lbl_alt_mode"))
        self.alt_mode_combo.setItemText(0, tr("alt_auto"))
        self.alt_mode_combo.setItemText(1, tr("alt_rtk"))
        self.alt_mode_combo.setItemText(2, tr("alt_rel"))
        self.alt_mode_combo.setItemText(3, tr("alt_msl"))
        self.lbl_fallback_z.setText(tr("lbl_fallback_z"))
        self.chk_auto_geoid.setText(tr("chk_auto_geoid"))
        self.lbl_pitch.setText(tr("lbl_pitch"))
        self.lbl_yaw.setText(tr("lbl_yaw"))
        self.lbl_roll.setText(tr("lbl_roll"))
        self.lbl_focal_pct.setText(tr("lbl_focal_pct"))
        self.lbl_x_east.setText(tr("lbl_x_east"))
        self.lbl_y_north.setText(tr("lbl_y_north"))

        self.lbl_sec_logs.setText(tr("sec_logs"))
        if self.progress_bar.value() == 0:
            self.progress_bar.setFormat(tr("progress_ready"))
        self.run_btn.setText(tr("btn_start_batch"))
        self.export_dir_btn.setText(tr("btn_export_folder"))
        self.cancel_btn.setText(tr("btn_cancel"))

        self.lbl_arch_header.setText(tr("arch_header"))
        self.lbl_arch_hint.setText(tr("arch_hint"))
        self.btn_restore.setText(tr("btn_restore"))
        self.btn_refresh_arch.setText(tr("btn_refresh"))
        self.btn_del_job.setText(tr("btn_del_job"))
        self.btn_del_all.setText(tr("btn_del_all"))

    def refresh_dem_sources(self, *args):
        prev_data = self.dem_combo.currentData() if self.dem_combo.count() > 0 else ("wcs", "dtm-1")
        self.dem_combo.blockSignals(True)
        self.dem_combo.clear()
        self.dem_combo.addItem(tr("dem_dtm"), ("wcs", "dtm-1"))
        self.dem_combo.addItem(tr("dem_dsm"), ("wcs", "dsm-1"))
        self.dem_combo.addItem(tr("dem_none"), ("none", None))

        prefix = tr("dem_project_prefix")
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr and lyr.isValid() and lyr.type() == 1:
                prov = lyr.providerType().lower()
                if prov in ('gdal', 'wcs'):
                    self.dem_combo.addItem(f"{prefix}: {lyr.name()}", ("layer", lyr.id()))

        for i in range(self.dem_combo.count()):
            if self.dem_combo.itemData(i) == prev_data:
                self.dem_combo.setCurrentIndex(i)
                break
        self.dem_combo.blockSignals(False)

    def _build_global_settings(self, out_folder=""):
        return {
            'fallback_z': self.elevation_box.value(),
            'geoid_offset': self.geoid_box.value(),
            'use_auto_geoid': self.chk_auto_geoid.isChecked(),
            'alt_mode': self.alt_mode_combo.currentData() or 'auto',
            'yaw_offset': self.yaw_offset_box.value(),
            'pitch_offset': self.pitch_offset_box.value(),
            'roll_offset': self.roll_offset_box.value(),
            'focal_scale': self.focal_scale_box.value() / 100.0,
            'x_offset': self.x_offset_box.value(),
            'y_offset': self.y_offset_box.value(),
            'dist_offsets': {
                'k1': self.k1_box.value(),
                'k2': self.k2_box.value(),
                'p1': self.p1_box.value(),
                'p2': self.p2_box.value(),
                'k3': self.k3_box.value(),
            },
            'out_folder': out_folder,
        }

    def dump_xmp_for_selected(self):
        selected_items = self.photo_list.selectedItems()
        if not selected_items:
            self.log("⚠️ Please select a photo from the list first.")
            return

        path = selected_items[0].data(UserRole)
        base_name = os.path.basename(path)
        suggested_filename = f"XMP_DUMP_{os.path.splitext(base_name)[0]}.txt"

        save_path, _ = QFileDialog.getSaveFileName(
            self, "Save XMP Dump File", suggested_filename, "Text Files (*.txt)"
        )
        if not save_path:
            return

        try:
            with open(path, 'rb') as f:
                img_data = f.read(524288)

            xmp_start = img_data.find(b'<x:xmpmeta')
            xmp_end = img_data.find(b'</x:xmpmeta>')
            raw_header_data = "No XMP tags found in file."
            if xmp_start != -1 and xmp_end != -1:
                raw_header_data = img_data[xmp_start:xmp_end + 12].decode('utf-8', errors='ignore')

            from ..core.metadata_parser import MetadataParser
            parsed_dict = MetadataParser.extract_xmp(path)

            report = [
                "=" * 60,
                "MAVIC PROJECTOR - DETAILED XMP & EXIF DUMP",
                f"Target File: {path}",
                f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "=" * 60,
                "\n💡 HOW THE PLUGIN INTERPRETS THIS PHOTO:",
            ]
            for k, v in parsed_dict.items():
                if isinstance(v, np.ndarray):
                    report.append(f"  -> {k}:\n{v}")
                else:
                    report.append(f"  -> {k}: {v}")
            report.append("\n" + "=" * 60)
            report.append("🔍 RAW UNPROCESSED XMP HEADER DATA:")
            report.append("=" * 60)
            report.append(raw_header_data)

            with open(save_path, 'w', encoding='utf-8') as out_f:
                out_f.write("\n".join(report))

            self.log(f"💾 Successfully saved XMP/EXIF metadata dump to:\n   {save_path}")
        except Exception as e:
            self.log(f"❌ Failed to save dump file: {e}")

    def log(self, text):
        self.log_panel.append(text)
        from qgis.core import Qgis, QgsMessageLog
        QgsMessageLog.logMessage(text, "MavicProjector", Qgis.Info)

    def save_settings(self):
        self.settings.setValue("fallback_z", self.elevation_box.value())
        self.settings.setValue("geoid_offset", self.geoid_box.value())
        self.settings.setValue("use_auto_geoid", self.chk_auto_geoid.isChecked())
        self.settings.setValue("alt_mode", self.alt_mode_combo.currentData() or "auto")
        self.settings.setValue("yaw_offset", self.yaw_offset_box.value())
        self.settings.setValue("pitch_offset", self.pitch_offset_box.value())
        self.settings.setValue("roll_offset", self.roll_offset_box.value())
        self.settings.setValue("focal_scale_pct", self.focal_scale_box.value())
        self.settings.setValue("x_offset", self.x_offset_box.value())
        self.settings.setValue("y_offset", self.y_offset_box.value())
        self.settings.setValue("k1_offset", self.k1_box.value())
        self.settings.setValue("k2_offset", self.k2_box.value())
        self.settings.setValue("p1_offset", self.p1_box.value())
        self.settings.setValue("p2_offset", self.p2_box.value())
        self.settings.setValue("k3_offset", self.k3_box.value())

    def _connect_layer_live_sync(self, layer):
        """Connects QgsMapLayer.styleChanged safely using functools.partial (PyQt6-safe)."""
        if layer is None or not layer.isValid():
            return
        lid = layer.id()
        if lid not in self.connected_layers:
            slot = partial(self.handle_live_style_sync, lid)
            layer.styleChanged.connect(slot)
            self.connected_layers[lid] = (layer, slot)

    def _add_layer(self, layer):
        items = [self.layer_list.item(i).text() for i in range(self.layer_list.count())]
        if layer.name() not in items:
            item = QListWidgetItem(layer.name())
            item.setData(UserRole, layer)
            item.setFlags(item.flags() | ItemIsUserCheckable)
            item.setCheckState(Unchecked)

            default_style = {
                "color": (255, 255, 0, 200),
                "fill_color": (255, 255, 0, 50),
                "width": 6,
                "point_size": 10,
                "opacity": 60 if layer.type() == 1 else 100,
                "fade": True,
                "label_field": "",
                "label_expr": "",
                "max_labels": 15,
                "font_size": 48,
                "halo_color": (0, 0, 0, 255),
                "shadow": False,
                "live_sync": False,
                "callout_color": (255, 255, 255, 255),
                "callout_width": 5,
                "z_offset": 0.0,
                "use_feature_z": True,
            }
            self.update_layer_list_icon(item, layer, default_style)
            item.setData(UserRole + 1, default_style)
            self.layer_list.addItem(item)
            self._connect_layer_live_sync(layer)
            self.log(f"Added layer: {layer.name()}")

    def add_combo_layer_to_list(self):
        layer = self.layer_combo.currentLayer()
        if layer:
            self._add_layer(layer)

    def add_dropped_layers_to_list(self, layers):
        for layer in layers:
            self._add_layer(layer)

    def browse_photos(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Select DJI Photos", "", "JPEG Images (*.jpg *.jpeg *.JPG *.JPEG)"
        )
        if files:
            self.add_photos_to_list(files)

    def add_photos_to_list(self, file_paths):
        from ..core.metadata_parser import MetadataParser

        for path in file_paths:
            items = [self.photo_list.item(i).data(UserRole) for i in range(self.photo_list.count())]
            if path not in items:
                name = os.path.basename(path)
                item = QListWidgetItem(name)
                item.setData(UserRole, path)
                item.setData(UserRole + 1, {})
                self.photo_list.addItem(item)
                try:
                    tel = MetadataParser.extract_xmp(path)
                    if tel.get('already_projected'):
                        self.log(
                            f"⚠️ Added '{name}', which looks like an already-projected photo! Use the raw camera JPEG for accurate projection."
                        )
                    else:
                        z_str = f", Zoom {tel['zoom_ratio']:.2f}x" if tel.get('zoom_ratio', 1.0) > 1.01 else ""
                        self.log(f"Added photo: {name} ({tel.get('model', 'Drone')}{z_str})")
                except Exception:
                    self.log(f"Added photo: {name}")

    def remove_selected(self, list_widget, *_args):
        for item in list_widget.selectedItems():
            list_widget.takeItem(list_widget.row(item))

    def open_photo_properties(self, item):
        from .dlg_photo_props import PhotoPropertiesDialog
        photo_path = item.data(UserRole)
        current_overrides = item.data(UserRole + 1) or {}
        dialog = PhotoPropertiesDialog(photo_path, current_overrides, self)
        if exec_dialog(dialog):
            overrides = dialog.get_overrides()
            item.setData(UserRole + 1, overrides)
            base_name = os.path.basename(photo_path)
            item.setText(f"{base_name} [Custom Offsets]" if _has_meaningful_overrides(overrides) else base_name)

    def open_layer_properties(self, item):
        from .dlg_layer_style import LayerStyleDialog
        layer = item.data(UserRole)
        current_style = item.data(UserRole + 1)
        dialog = LayerStyleDialog(layer, current_style, self)
        if exec_dialog(dialog):
            new_style = dialog.get_style()
            item.setData(UserRole + 1, new_style)
            self.update_layer_list_icon(item, layer, new_style)

            base_name = layer.name()
            flags = []
            if new_style.get('live_sync'):
                flags.append("🔗 SYNC")
            if new_style.get('label_expr') or new_style.get('label_field'):
                flags.append("Labels")
            if abs(float(new_style.get('z_offset', 0.0))) > 1e-6:
                flags.append(f"Z{new_style['z_offset']:+.1f}m")

            item.setText(f"{base_name} [{', '.join(flags)}]" if flags else base_name)
            self.log(f"Updated style for layer: {base_name}")

    def handle_live_style_sync(self, layer_id, *_args):
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer = item.data(UserRole)
            try:
                if layer and layer.isValid() and layer.id() == layer_id:
                    current_style = item.data(UserRole + 1) or {}
                    if current_style.get('live_sync', False):
                        updated_style = self.extract_qgis_style(layer, current_style)
                        item.setData(UserRole + 1, updated_style)
                        self.update_layer_list_icon(item, layer, updated_style)
                        self.refresh_viewer_if_open()
                    break
            except RuntimeError:
                continue

    def extract_qgis_style(self, layer, current_style):
        new_style = current_style.copy()
        try:
            if hasattr(layer, 'opacity'):
                new_style["opacity"] = max(0, min(100, int(round(float(layer.opacity()) * 100.0))))
        except Exception:
            pass

        if layer.type() == 0:
            renderer = layer.renderer()
            if renderer:
                symbol = None
                if renderer.type() == "singleSymbol":
                    symbol = renderer.symbol()
                elif renderer.type() in ["categorizedSymbol", "graduatedSymbol"]:
                    if renderer.categories():
                        symbol = renderer.categories()[0].symbol()
                elif renderer.type() == "ruleRenderer":
                    if renderer.rootRule().children():
                        symbol = renderer.rootRule().children()[0].symbol()

                if symbol:
                    c = symbol.color()
                    alpha = max(100, c.alpha())
                    new_style["color"] = (c.red(), c.green(), c.blue(), alpha)

                    if layer.geometryType() == 2:
                        if symbol.symbolLayerCount() > 0:
                            sl = symbol.symbolLayer(0)
                            from ..compat_drone import NoBrush
                            has_brush = True
                            if hasattr(sl, 'brushStyle') and (sl.brushStyle() == NoBrush or sl.brushStyle() == 0):
                                has_brush = False
                            if has_brush and hasattr(sl, 'fillColor'):
                                fc = sl.fillColor()
                                new_style["fill_color"] = (fc.red(), fc.green(), fc.blue(), min(100, fc.alpha()))
                            else:
                                new_style["fill_color"] = (0, 0, 0, 0)
                            if hasattr(sl, 'strokeColor'):
                                oc = sl.strokeColor()
                                new_style["color"] = (oc.red(), oc.green(), oc.blue(), max(100, oc.alpha()))
                            if hasattr(sl, 'strokeWidth'):
                                new_style["width"] = max(2, int(sl.strokeWidth() * 10))
                    elif layer.geometryType() == 1:
                        new_style["width"] = max(2, int(symbol.width() * 8))
                    elif layer.geometryType() == 0:
                        new_style["point_size"] = max(20, int(symbol.size() * 12))
        return new_style

    def update_layer_list_icon(self, item, layer, style):
        pixmap = QPixmap(20, 20)
        pixmap.fill(QColor(43, 43, 43))
        painter = QPainter(pixmap)
        geom_type = layer.geometryType() if layer.type() == 0 else -1

        c_r, c_g, c_b, c_a = style.get("color", (255, 255, 0, 200))
        f_r, f_g, f_b, f_a = style.get("fill_color", (255, 255, 0, 50))
        opacity = style.get("opacity", 100) / 100.0

        p_color = QColor(c_r, c_g, c_b, int(c_a * opacity))
        f_color = QColor(f_r, f_g, f_b, int(f_a * opacity))

        painter.setPen(QPen(p_color, 2))
        if geom_type == 0:
            painter.setBrush(QBrush(p_color))
            painter.drawEllipse(5, 5, 10, 10)
        elif geom_type == 1:
            painter.drawLine(2, 18, 18, 2)
        elif geom_type == 2:
            painter.setBrush(QBrush(f_color))
            painter.drawRect(3, 3, 14, 14)
        elif layer.type() == 1:
            painter.setBrush(QBrush(QColor(100, 100, 255, 150)))
            painter.drawRect(2, 2, 16, 16)
            painter.drawLine(2, 10, 18, 10)
            painter.drawLine(10, 2, 10, 18)

        painter.end()
        item.setIcon(QIcon(pixmap))

    def refresh_viewer_if_open(self):
        if self.viewer_instance is not None and self.viewer_instance.isVisible():
            gallery_data = []
            temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
            for i in range(self.photo_list.count()):
                p_item = self.photo_list.item(i)
                raw_p = p_item.data(UserRole)
                stem, _ = os.path.splitext(os.path.basename(raw_p))
                gallery_data.append(
                    {
                        'name': os.path.basename(raw_p),
                        'raw_path': raw_p,
                        'proj_path': os.path.join(temp_dir, f"{stem}_PROJECTED.jpg"),
                        'overrides': p_item.data(UserRole + 1) or {},
                    }
                )
            self.viewer_instance.gallery_data = gallery_data
            try:
                if hasattr(self.viewer_instance, 'refresh_live_sync'):
                    self.viewer_instance.refresh_live_sync()
            except Exception:
                pass

    def get_or_create_dem_layer(self):
        sel = self.dem_combo.currentData()
        if not sel:
            sel = ("wcs", "dtm-1")
        kind, ident = sel

        if kind == "none":
            return None
        if kind == "layer":
            lyr = QgsProject.instance().mapLayer(ident)
            if lyr and lyr.isValid():
                return lyr
            self.log("⚠️ Selected project DEM layer is no longer valid; falling back to Fallback Z.")
            return None

        uri = f"dpiMode=7&identifier={ident}&tilePixelRatio=0&url=https://teenus.maaamet.ee/ows/wcs-dtm"
        if "dsm" in str(ident):
            uri = uri.replace("wcs-dtm", "wcs-dsm")

        raster_layer = QgsRasterLayer(uri, f"Kogu Eesti {str(ident).upper()}", "wcs")
        if raster_layer.isValid():
            return raster_layer
        self.log("⚠️ Could not reach Maa-amet WCS service; proceeding with flat Fallback Z.")
        return None

    def open_interactive_viewer(self):
        if self.photo_list.count() == 0:
            self.log("❌ Add at least one photo to the list first.")
            return

        gallery_data = []
        temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
        os.makedirs(temp_dir, exist_ok=True)

        for i in range(self.photo_list.count()):
            item = self.photo_list.item(i)
            raw_path = item.data(UserRole)
            overrides = item.data(UserRole + 1) or {}
            stem, _ = os.path.splitext(os.path.basename(raw_path))
            proj_path = os.path.join(temp_dir, f"{stem}_PROJECTED.jpg")
            gallery_data.append(
                {
                    'name': os.path.basename(raw_path),
                    'raw_path': raw_path,
                    'proj_path': proj_path,
                    'overrides': overrides,
                }
            )

        start_index = self.photo_list.currentRow()
        if start_index < 0:
            start_index = 0

        try:
            from .viewer_dialog import InteractiveViewer
            from ..compat_drone import NonModal, Window

            dem_layer = self.get_or_create_dem_layer()
            global_settings = self._build_global_settings(temp_dir)

            if self.viewer_instance is not None:
                self.viewer_instance.global_settings = global_settings
                self.viewer_instance.dem_layer = dem_layer
                self.viewer_instance.update_gallery(gallery_data, start_index)
                self.viewer_instance.showNormal()
                self.viewer_instance.raise_()
                self.viewer_instance.activateWindow()
                return

            self.viewer_instance = InteractiveViewer(
                gallery_data, start_index, global_settings, dem_layer, self
            )
            self.viewer_instance.setWindowModality(NonModal)
            self.viewer_instance.setWindowFlags(Window)
            self.viewer_instance.show()
        except Exception as e:
            self.log(f"Viewer Error: {e}")

    def toggle_cameras_on_map(self):
        existing_cam = QgsProject.instance().mapLayersByName("Drone Cameras")
        if existing_cam:
            QgsProject.instance().removeMapLayer(existing_cam[0].id())
            self.map_btn.setText(tr("btn_show_cams"))
            self.log("🗺️ Removed cameras from map.")
            self.iface.mapCanvas().refresh()
            return

        from ..core.math_engine import MathEngine
        from ..core.metadata_parser import MetadataParser

        if self.photo_list.count() == 0:
            self.log("❌ No photos added.")
            return

        self.log("🗺️ Calculating 2D camera FOV footprints...")

        vl = QgsVectorLayer("MultiPolygon?crs=EPSG:3301", "Drone Cameras", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("photo", QVariant.String)])
        vl.updateFields()

        sym = QgsFillSymbol.createSimple(
            {
                'color': '160,32,240,60',
                'outline_color': '160,32,240,200',
                'outline_width': '0.4',
                'outline_style': 'dash',
            }
        )
        vl.renderer().setSymbol(sym)

        settings = QgsPalLayerSettings()
        settings.fieldName = 'photo'
        settings.placement = LabelPlacementOverPoint
        text_format = QgsTextFormat()
        text_format.setSize(10)
        halo = QgsTextBufferSettings()
        halo.setEnabled(True)
        halo.setSize(1)
        halo.setColor(QColor("white"))
        text_format.setBuffer(halo)
        settings.setFormat(text_format)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        vl.setLabelsEnabled(True)

        global_dists = {
            'k1': self.k1_box.value(),
            'k2': self.k2_box.value(),
            'p1': self.p1_box.value(),
            'p2': self.p2_box.value(),
            'k3': self.k3_box.value(),
        }

        for i in range(self.photo_list.count()):
            item = self.photo_list.item(i)
            path = item.data(UserRole)
            overrides = item.data(UserRole + 1) or {}
            try:
                active_pitch = overrides.get('pitch_offset', self.pitch_offset_box.value())
                active_yaw = overrides.get('yaw_offset', self.yaw_offset_box.value())
                active_roll = overrides.get('roll_offset', self.roll_offset_box.value())
                active_fscale = overrides.get('focal_scale', self.focal_scale_box.value() / 100.0)
                active_x = overrides.get('x_offset', self.x_offset_box.value())
                active_y = overrides.get('y_offset', self.y_offset_box.value())
                lens_override = overrides.get('lens_override', 'Auto (From File)')

                dist_dict = dict(global_dists)
                if isinstance(overrides.get('dist_offsets'), dict):
                    dist_dict.update(overrides['dist_offsets'])

                tel = MetadataParser.extract_xmp(path, dist_dict, lens_override)

                if 'use_auto_geoid' in overrides:
                    use_auto_g = bool(overrides['use_auto_geoid'])
                elif 'geoid_offset' in overrides:
                    use_auto_g = False
                else:
                    use_auto_g = self.chk_auto_geoid.isChecked()

                if use_auto_g:
                    active_geoid = tel.get('auto_geoid', -19.0) if tel.get('is_rtk', True) else 0.0
                else:
                    active_geoid = overrides.get('geoid_offset', self.geoid_box.value())

                safe_context = QgsProject.instance().transformContext()
                engine = MathEngine(
                    tel,
                    active_geoid,
                    active_yaw,
                    active_pitch,
                    transform_context=safe_context,
                    roll_offset=active_roll,
                    focal_scale=active_fscale,
                    alt_mode=self.alt_mode_combo.currentData() or 'auto',
                )
                engine.drone_pos[0] -= active_x
                engine.drone_pos[1] -= active_y

                drone_poly, fov_poly = engine.get_simple_map_polygons()

                f = QgsFeature(vl.fields())
                geom = QgsGeometry.fromMultiPolygonXY([[drone_poly], [fov_poly]])
                f.setGeometry(geom)
                f.setAttribute("photo", f"{os.path.basename(path)} (P:{engine.grid_pitch:.1f}°)")
                pr.addFeature(f)
            except Exception as e:
                self.log(f"Map Error for {os.path.basename(path)}: {e}")

        vl.updateExtents()
        QgsProject.instance().addMapLayer(vl)
        self.map_btn.setText(tr("btn_hide_cams"))
        self.log("🗺️ Added cameras to map!")
        self.iface.mapCanvas().refresh()

    def set_eta_info(self, text, eta_seconds):
        self.progress_bar.setFormat(text)
        if eta_seconds >= 30:
            if self.gif_label.isHidden():
                self.gif_label.show()
                self.gif_movie.start()
        else:
            if not self.gif_label.isHidden():
                self.gif_label.hide()
                self.gif_movie.stop()

    def cancel_processing(self):
        if self.task:
            self.task.cancel()
            self.cancel_btn.setEnabled(False)
            self.log("🛑 Canceling task... safely stopping and clearing memory.")
        self.gif_label.hide()
        self.gif_movie.stop()

    def export_batch_to_folder(self):
        if self.photo_list.count() == 0 or self.layer_list.count() == 0:
            self.log("❌ Missing Data: Add at least 1 Layer and 1 Photo.")
            return
        start_dir = os.path.dirname(self.photo_list.item(0).data(UserRole))
        chosen = QFileDialog.getExistingDirectory(self, "Select Output Folder for Projected Photos", start_dir)
        if chosen:
            self.process_image(override_out_dir=chosen)

    def _on_progress_changed(self, v):
        self.progress_bar.setValue(int(v))

    def process_image(self, checked=False, override_out_dir=None):
        self.save_settings()

        layer_items = []
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            is_checked = (item.checkState() == Checked)
            layer_items.append(
                {
                    'layer': item.data(UserRole),
                    'style': item.data(UserRole + 1),
                    'selected_only': is_checked,
                }
            )

        photo_items = []
        for i in range(self.photo_list.count()):
            item = self.photo_list.item(i)
            photo_items.append({'path': item.data(UserRole), 'overrides': item.data(UserRole + 1)})

        if not layer_items or not photo_items:
            self.log("❌ Missing Data: Add at least 1 Layer and 1 Photo.")
            return

        if isinstance(override_out_dir, str) and override_out_dir:
            out_folder = override_out_dir
        else:
            temp_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
            os.makedirs(temp_dir, exist_ok=True)
            out_folder = temp_dir

        self.log_panel.clear()
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat(tr("progress_init"))
        self.run_btn.setEnabled(False)
        self.export_dir_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.log("--- Initializing Batch Projection ---")

        dem_layer = self.get_or_create_dem_layer()
        settings_dict = self._build_global_settings(out_folder)

        from ..core.task_worker import ProjectionTask
        safe_context = QgsProject.instance().transformContext()

        self.task = ProjectionTask(
            photo_items, layer_items, dem_layer, settings_dict, transform_context=safe_context
        )
        self.task.signals.log_signal.connect(self.log)
        self.task.signals.eta_signal.connect(self.set_eta_info)
        self.task.progressChanged.connect(self._on_progress_changed)
        self.task.signals.max_progress_signal.connect(self.progress_bar.setMaximum)
        self.task.signals.finished_signal.connect(self.on_task_finished)

        QgsApplication.taskManager().addTask(self.task)

    def on_task_finished(self, success, err_msg):
        self.run_btn.setEnabled(True)
        self.export_dir_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.gif_label.hide()
        self.gif_movie.stop()

        if success:
            self.progress_bar.setValue(self.progress_bar.maximum())
            self.progress_bar.setFormat(tr("progress_done"))
            self.save_job_to_archive()

    def save_job_to_archive(self):
        try:
            job_data = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "global_settings": self._build_global_settings(""),
                "layers": [],
                "photos": [],
            }

            for i in range(self.layer_list.count()):
                item = self.layer_list.item(i)
                layer = item.data(UserRole)
                job_data["layers"].append(
                    {
                        "name": layer.name(),
                        "id": layer.id(),
                        "style": item.data(UserRole + 1),
                        "selected_only": item.checkState() == Checked,
                    }
                )

            for i in range(self.photo_list.count()):
                item = self.photo_list.item(i)
                job_data["photos"].append(
                    {"path": item.data(UserRole), "overrides": item.data(UserRole + 1)}
                )

            jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
            os.makedirs(jobs_dir, exist_ok=True)
            filename = f"Job_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

            with open(os.path.join(jobs_dir, filename), 'w', encoding='utf-8') as f:
                json.dump(job_data, f, indent=4)

            self.refresh_archive_list()
        except Exception as e:
            self.log(f"⚠️ Failed to save job archive: {e}")

    def refresh_archive_list(self):
        self.archive_list.clear()
        jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
        if not os.path.exists(jobs_dir):
            return

        for job_file in sorted(glob.glob(os.path.join(jobs_dir, "*.json")), reverse=True):
            try:
                with open(job_file, 'r', encoding='utf-8') as f:
                    job_data = json.load(f)

                ts = job_data.get("timestamp", "Unknown Date")
                photo_count = len(job_data.get("photos", []))
                layer_count = len(job_data.get("layers", []))

                item = QListWidgetItem(f"Job: {ts}\n{photo_count} Photos, {layer_count} Layers")
                item.setData(UserRole, job_file)

                if photo_count > 0:
                    first_photo = job_data["photos"][0]["path"]
                    out_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicProjectorTemp")
                    stem, _ = os.path.splitext(os.path.basename(first_photo))
                    proj_path = os.path.join(out_dir, f"{stem}_PROJECTED.jpg")
                    cand = proj_path if os.path.exists(proj_path) else first_photo
                    if os.path.exists(cand):
                        pixmap = QPixmap(cand)
                        if not pixmap.isNull():
                            item.setIcon(QIcon(pixmap))

                self.archive_list.addItem(item)
            except Exception:
                pass

    def restore_job(self):
        item = self.archive_list.currentItem()
        if not item:
            return
        job_path = item.data(UserRole)

        try:
            with open(job_path, 'r', encoding='utf-8') as f:
                job_data = json.load(f)

            settings = job_data.get("global_settings", {})
            self.elevation_box.setValue(float(settings.get("fallback_z", 0.0)))
            self.geoid_box.setValue(float(settings.get("geoid_offset", 0.0)))
            self.chk_auto_geoid.setChecked(bool(settings.get("use_auto_geoid", settings.get("geoid_offset", 0.0) == 0.0)))
            idx_am = self.alt_mode_combo.findData(settings.get("alt_mode", "auto"))
            if idx_am >= 0:
                self.alt_mode_combo.setCurrentIndex(idx_am)

            self.yaw_offset_box.setValue(float(settings.get("yaw_offset", 0.0)))
            self.pitch_offset_box.setValue(float(settings.get("pitch_offset", 0.0)))
            self.roll_offset_box.setValue(float(settings.get("roll_offset", 0.0)))
            self.focal_scale_box.setValue(float(settings.get("focal_scale", 1.0)) * 100.0)
            self.x_offset_box.setValue(float(settings.get("x_offset", 0.0)))
            self.y_offset_box.setValue(float(settings.get("y_offset", 0.0)))

            dists = settings.get("dist_offsets", {})
            self.k1_box.setValue(float(dists.get("k1", 0.0)))
            self.k2_box.setValue(float(dists.get("k2", 0.0)))
            self.p1_box.setValue(float(dists.get("p1", 0.0)))
            self.p2_box.setValue(float(dists.get("p2", 0.0)))
            self.k3_box.setValue(float(dists.get("k3", 0.0)))

            self.photo_list.clear()
            for p in job_data.get("photos", []):
                path = p.get("path")
                if path and os.path.exists(path):
                    name = os.path.basename(path)
                    l_item = QListWidgetItem(name)
                    l_item.setData(UserRole, path)
                    overrides = p.get("overrides", {})
                    l_item.setData(UserRole + 1, overrides)
                    if _has_meaningful_overrides(overrides):
                        l_item.setText(f"{name} [Custom Offsets]")
                    self.photo_list.addItem(l_item)

            self.layer_list.clear()
            proj = QgsProject.instance()
            for l in job_data.get("layers", []):
                layer = proj.mapLayer(l.get("id"))
                if not layer:
                    layers = proj.mapLayersByName(l.get("name"))
                    if layers:
                        layer = layers[0]

                if layer:
                    l_item = QListWidgetItem(layer.name())
                    l_item.setData(UserRole, layer)
                    l_item.setFlags(l_item.flags() | ItemIsUserCheckable)
                    l_item.setCheckState(Checked if l.get("selected_only") else Unchecked)
                    style = l.get("style", {})
                    l_item.setData(UserRole + 1, style)
                    self.update_layer_list_icon(l_item, layer, style)

                    flags = []
                    if style.get('live_sync'):
                        flags.append("🔗 SYNC")
                    if style.get('label_expr') or style.get('label_field'):
                        flags.append("Labels")
                    if flags:
                        l_item.setText(f"{layer.name()} [{', '.join(flags)}]")
                    self.layer_list.addItem(l_item)
                    self._connect_layer_live_sync(layer)

            self.tabs.setCurrentIndex(0)
            self.log("\n✅ Job restored from archive. Photos, Layers, and Offsets loaded.")
        except Exception as e:
            self.log(f"⚠️ Failed to restore job: {e}")

    def delete_selected_job(self):
        from ..compat_drone import MsgNo, MsgYes, QMessageBox
        item = self.archive_list.currentItem()
        if not item:
            return
        job_path = item.data(UserRole)

        reply = QMessageBox.question(
            self, 'Delete Job', 'Are you sure you want to delete this saved setup?', MsgYes | MsgNo, MsgNo
        )
        if reply == MsgYes:
            try:
                os.remove(job_path)
                self.refresh_archive_list()
                self.log("🗑️ Selected job deleted successfully.")
            except Exception as e:
                self.log(f"⚠️ Failed to delete job: {e}")

    def delete_all_jobs(self):
        from ..compat_drone import MsgNo, MsgYes, QMessageBox
        reply = QMessageBox.question(
            self,
            'Delete All Jobs',
            'Are you sure you want to delete ALL saved setups? This cannot be undone.',
            MsgYes | MsgNo,
            MsgNo,
        )
        if reply == MsgYes:
            jobs_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "MavicJobs")
            if os.path.exists(jobs_dir):
                count = 0
                for job_file in glob.glob(os.path.join(jobs_dir, "*.json")):
                    try:
                        os.remove(job_file)
                        count += 1
                    except Exception:
                        pass
                self.refresh_archive_list()
                self.log(f"🗑️ Cleared {count} saved jobs from archive.")
