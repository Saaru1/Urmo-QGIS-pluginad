"""
Compatibility layer for QGIS 3 (PyQt5) and QGIS 4 (PyQt6).
"""
from qgis.PyQt.QtCore import Qt, pyqtSignal, QObject, QSettings, QRect, QVariant, QTimer, QPointF

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QDoubleSpinBox, QSpinBox, QGraphicsView, QGraphicsScene, 
    QMessageBox, QProgressDialog, QComboBox, QInputDialog, 
    QLineEdit, QCheckBox, QTextEdit, QDockWidget, QListWidget, 
    QListWidgetItem, QAbstractItemView, QWidget, QFrame, QColorDialog, 
    QFileDialog, QProgressBar, QTabWidget, QSlider,
    QGraphicsEllipseItem, QGraphicsTextItem, QGraphicsLineItem, 
    QGraphicsPolygonItem, QGraphicsPathItem, QSplitter, QGridLayout,
    QGraphicsItem, QGraphicsRectItem, QGraphicsBlurEffect
)
from qgis.PyQt.QtGui import QIcon, QImage, QPixmap, QPainter, QPen, QColor, QFont, QTransform, QBrush, QPolygonF, QPainterPath
from qgis.core import (
    QgsMessageLog, Qgis, QgsMapLayerProxyModel, QgsRaster, 
    QgsWkbTypes, QgsTask, QgsApplication, QgsProject,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, 
    QgsPointXY, QgsGeometry, QgsRectangle, QgsFeatureRequest, QgsRasterLayer,
    QgsExpression, QgsExpressionContext, QgsExpressionContextUtils,
    QgsFillSymbol, QgsMarkerSymbol, QgsTextFormat, QgsPalLayerSettings, 
    QgsVectorLayerSimpleLabeling, QgsField, QgsVectorLayer, QgsFeature,
    QgsTextBufferSettings, QgsRenderContext,
    QgsSimpleMarkerSymbolLayer, QgsProperty, QgsSymbolLayer, QgsLineSymbol
)
from qgis.gui import QgsFileWidget, QgsMapLayerComboBox, QgsRubberBand, QgsMapToolEmitPoint, QgsVertexMarker

try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction

try:
    KeepAspectRatio = Qt.AspectRatioMode.KeepAspectRatio
    AppModal = Qt.WindowModality.ApplicationModal
    WindowModal = Qt.WindowModality.WindowModal
    LeftDockWidgetArea = Qt.DockWidgetArea.LeftDockWidgetArea
    RightDockWidgetArea = Qt.DockWidgetArea.RightDockWidgetArea
    BottomDockWidgetArea = Qt.DockWidgetArea.BottomDockWidgetArea
    UserRole = Qt.ItemDataRole.UserRole
    AlignCenter = Qt.AlignmentFlag.AlignCenter
    ItemIsUserCheckable = Qt.ItemFlag.ItemIsUserCheckable
    Checked = Qt.CheckState.Checked
    Unchecked = Qt.CheckState.Unchecked
    SmoothTransformation = Qt.TransformationMode.SmoothTransformation
except AttributeError:
    KeepAspectRatio = Qt.KeepAspectRatio
    AppModal = Qt.ApplicationModal
    WindowModal = Qt.WindowModal
    LeftDockWidgetArea = Qt.LeftDockWidgetArea
    RightDockWidgetArea = Qt.RightDockWidgetArea
    BottomDockWidgetArea = Qt.BottomDockWidgetArea
    UserRole = Qt.UserRole
    AlignCenter = Qt.AlignCenter
    ItemIsUserCheckable = Qt.ItemIsUserCheckable
    Checked = Qt.Checked
    Unchecked = Qt.Unchecked
    SmoothTransformation = Qt.SmoothTransformation

try:
    GraphicsItemIsSelectable = QGraphicsItem.GraphicsItemFlag.ItemIsSelectable
    GraphicsItemIsMovable = QGraphicsItem.GraphicsItemFlag.ItemIsMovable
    GraphicsItemSendsGeometryChanges = QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges
except AttributeError:
    GraphicsItemIsSelectable = QGraphicsItem.ItemIsSelectable
    GraphicsItemIsMovable = QGraphicsItem.ItemIsMovable
    GraphicsItemSendsGeometryChanges = QGraphicsItem.ItemSendsGeometryChanges

try:
    CopyAction = Qt.DropAction.CopyAction
    WindowMinimized = Qt.WindowState.WindowMinimized
except AttributeError:
    CopyAction = Qt.CopyAction
    WindowMinimized = Qt.WindowMinimized

try:
    LeftButton = Qt.MouseButton.LeftButton
    RightButton = Qt.MouseButton.RightButton
    NoBrush = Qt.BrushStyle.NoBrush
    DashLine = Qt.PenStyle.DashLine
    SolidLine = Qt.PenStyle.SolidLine
    NoPen = Qt.PenStyle.NoPen
except AttributeError:
    LeftButton = Qt.LeftButton
    RightButton = Qt.RightButton
    NoBrush = Qt.NoBrush
    DashLine = Qt.DashLine
    SolidLine = Qt.SolidLine
    NoPen = Qt.NoPen

try:
    Key_Return = Qt.Key.Key_Return
    Key_Enter = Qt.Key.Key_Enter
    Key_Escape = Qt.Key.Key_Escape
    Key_Up = Qt.Key.Key_Up
    Key_Down = Qt.Key.Key_Down
except AttributeError:
    Key_Return = Qt.Key_Return
    Key_Enter = Qt.Key_Enter
    Key_Escape = Qt.Key_Escape
    Key_Up = Qt.Key_Up
    Key_Down = Qt.Key_Down

try:
    QuadrantAbove = QgsPalLayerSettings.QuadrantPosition.QuadrantAbove
except AttributeError:
    QuadrantAbove = QgsPalLayerSettings.QuadrantAbove

try:
    PropertyAngle = QgsSymbolLayer.Property.PropertyAngle
    PropertySize = QgsSymbolLayer.Property.PropertySize
except AttributeError:
    PropertyAngle = QgsSymbolLayer.PropertyAngle
    PropertySize = QgsSymbolLayer.PropertySize

try:
    MsgYes = QMessageBox.StandardButton.Yes
    MsgNo = QMessageBox.StandardButton.No
except AttributeError:
    MsgYes = QMessageBox.Yes
    MsgNo = QMessageBox.No

try:
    StyledPanel = QFrame.Shape.StyledPanel
except AttributeError:
    StyledPanel = QFrame.StyledPanel

try:
    LabelPlacementOverPoint = QgsPalLayerSettings.Placement.OverPoint
except AttributeError:
    LabelPlacementOverPoint = QgsPalLayerSettings.OverPoint

try:
    DropOnly = QAbstractItemView.DragDropMode.DropOnly
    ExtendedSelection = QAbstractItemView.SelectionMode.ExtendedSelection
except AttributeError:
    DropOnly = QAbstractItemView.DropOnly
    ExtendedSelection = QAbstractItemView.ExtendedSelection

try:
    ShowAlphaChannel = QColorDialog.ColorDialogOption.ShowAlphaChannel
except AttributeError:
    ShowAlphaChannel = QColorDialog.ShowAlphaChannel

try:
    TaskCanCancel = QgsTask.Flag.CanCancel
except AttributeError:
    TaskCanCancel = QgsTask.CanCancel

try:
    IconInfo = QMessageBox.Icon.Information
    IconCrit = QMessageBox.Icon.Critical
    IconWarn = QMessageBox.Icon.Warning
except AttributeError:
    IconInfo = QMessageBox.Information
    IconCrit = QMessageBox.Critical
    IconWarn = QMessageBox.Warning

try:
    MsgInfo = Qgis.MessageLevel.Info
    MsgSuccess = Qgis.MessageLevel.Success
    MsgCritical = Qgis.MessageLevel.Critical
    MsgWarning = Qgis.MessageLevel.Warning
except AttributeError:
    MsgInfo = Qgis.Info
    MsgSuccess = Qgis.Success
    MsgCritical = Qgis.Critical
    MsgWarning = Qgis.Warning

try:
    FilterPoint = QgsMapLayerProxyModel.Filter.PointLayer
    FilterPolygon = QgsMapLayerProxyModel.Filter.PolygonLayer
    FilterLine = QgsMapLayerProxyModel.Filter.LineLayer
    FilterRaster = QgsMapLayerProxyModel.Filter.RasterLayer
except AttributeError:
    FilterPoint = QgsMapLayerProxyModel.PointLayer
    FilterPolygon = QgsMapLayerProxyModel.PolygonLayer
    FilterLine = QgsMapLayerProxyModel.LineLayer
    FilterRaster = QgsMapLayerProxyModel.RasterLayer

try:
    RoundCap = Qt.PenCapStyle.RoundCap
    EchoModeNormal = QLineEdit.EchoMode.Normal
    RenderHintAntialiasing = QPainter.RenderHint.Antialiasing
except AttributeError:
    RoundCap = Qt.RoundCap
    EchoModeNormal = QLineEdit.Normal
    RenderHintAntialiasing = QPainter.Antialiasing

try:
    IdentifyFormatValue = QgsRaster.IdentifyFormat.Value
except AttributeError:
    IdentifyFormatValue = QgsRaster.IdentifyFormatValue

try:
    GeomPolygon = Qgis.GeometryType.Polygon
    WkbPolygon = Qgis.WkbType.Polygon
    WkbMultiPolygon = Qgis.WkbType.MultiPolygon
    WkbLineString = Qgis.WkbType.LineString
    WkbMultiLineString = Qgis.WkbType.MultiLineString
    WkbPoint = Qgis.WkbType.Point
    WkbMultiPoint = Qgis.WkbType.MultiPoint
except AttributeError:
    try:
        GeomPolygon = QgsWkbTypes.PolygonGeometry
        WkbPolygon = QgsWkbTypes.Polygon
        WkbMultiPolygon = QgsWkbTypes.MultiPolygon
        WkbLineString = QgsWkbTypes.LineString
        WkbMultiLineString = QgsWkbTypes.MultiLineString
        WkbPoint = QgsWkbTypes.Point
        WkbMultiPoint = QgsWkbTypes.MultiPoint
    except AttributeError:
        GeomPolygon = QgsWkbTypes.GeometryType.PolygonGeometry
        WkbPolygon = QgsWkbTypes.Type.Polygon
        WkbMultiPolygon = QgsWkbTypes.Type.MultiPolygon
        WkbLineString = QgsWkbTypes.Type.LineString
        WkbMultiLineString = QgsWkbTypes.Type.MultiLineString
        WkbPoint = QgsWkbTypes.Type.Point
        WkbMultiPoint = QgsWkbTypes.Type.MultiPoint

try:
    HLine = QFrame.Shape.HLine
except AttributeError:
    HLine = QFrame.HLine

try:
    NonModal = Qt.WindowModality.NonModal
    Window = Qt.WindowType.Window
    Transparent = Qt.GlobalColor.transparent
except AttributeError:
    NonModal = Qt.NonModal
    Window = Qt.Window
    Transparent = Qt.transparent

try:
    ScrollHandDrag = QGraphicsView.DragMode.ScrollHandDrag
    NoDrag = QGraphicsView.DragMode.NoDrag
except AttributeError:
    ScrollHandDrag = QGraphicsView.ScrollHandDrag
    NoDrag = QGraphicsView.NoDrag
    
try:
    AnchorUnderMouse = QGraphicsView.ViewportAnchor.AnchorUnderMouse
except AttributeError:
    AnchorUnderMouse = QGraphicsView.AnchorUnderMouse

try:
    Horizontal = Qt.Orientation.Horizontal
    Vertical = Qt.Orientation.Vertical
except AttributeError:
    Horizontal = Qt.Horizontal
    Vertical = Qt.Vertical

try:
    Format_ARGB32 = QImage.Format.Format_ARGB32
    Format_ARGB32_Premultiplied = QImage.Format.Format_ARGB32_Premultiplied
    SmoothPixmapTransform = QPainter.RenderHint.SmoothPixmapTransform
except AttributeError:
    Format_ARGB32 = QImage.Format_ARGB32
    Format_ARGB32_Premultiplied = QImage.Format_ARGB32_Premultiplied
    SmoothPixmapTransform = QPainter.SmoothPixmapTransform

def exec_dialog(dialog):
    if hasattr(dialog, 'exec'): return dialog.exec()
    return dialog.exec_()

try:
    BlurPerformanceHint = QGraphicsBlurEffect.BlurHint.PerformanceHint
except AttributeError:
    BlurPerformanceHint = QGraphicsBlurEffect.PerformanceHint

try:
    DeviceCoordinateCache = QGraphicsItem.CacheMode.DeviceCoordinateCache
except AttributeError:
    DeviceCoordinateCache = QGraphicsItem.DeviceCoordinateCache