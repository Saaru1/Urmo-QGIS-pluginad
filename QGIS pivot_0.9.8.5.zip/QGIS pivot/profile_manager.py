import json
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QSplitter, 
                                 QListWidget, QTableWidget, QTableWidgetItem, 
                                 QLabel, QLineEdit, QPushButton, QDialogButtonBox, 
                                 QMessageBox, QDoubleSpinBox, QWidget)
from qgis.core import QgsSettings

from .compat import *

class ProfileEditorDialog(QDialog):
    def __init__(self, profile_name, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Edit Profile: {profile_name}")
        self.resize(700, 500)
        self.profile_name = profile_name
        
        settings = QgsSettings()
        profiles = json.loads(settings.value("spatial_pivot/geosearch_profiles", "{}"))
        
        p_data = profiles.get(profile_name, []) 
        self.targets = p_data if isinstance(p_data, list) else p_data.get("targets", [])
        
        self.current_target_idx = -1

        main_layout = QVBoxLayout(self)
        splitter = QSplitter(QT_HORIZONTAL)

        # LEFT: Target Layers List
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0,0,0,0)
        left_layout.addWidget(QLabel("<b>Target Layers</b>"))
        
        self.layer_list = QListWidget()
        self.layer_list.setSelectionMode(QT_SINGLE_SELECTION)
        for t in self.targets:
            self.layer_list.addItem(t.get('layer', 'Unknown Layer'))
        self.layer_list.currentRowChanged.connect(self.load_target_details)
        left_layout.addWidget(self.layer_list)
        splitter.addWidget(left_panel)

        # RIGHT: Layer Settings & Sensitive Features
        right_panel = QWidget()
        self.right_layout = QVBoxLayout(right_panel)
        self.right_layout.setContentsMargins(0,0,0,0)
        
        self.lbl_layer = QLabel("Select a layer to edit settings")
        self.lbl_layer.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.right_layout.addWidget(self.lbl_layer)
        
        # Group Field & Filter
        form_layout = QHBoxLayout()
        form_layout.addWidget(QLabel("Group Field:"))
        self.in_group = QLineEdit()
        self.in_group.textChanged.connect(self.save_current_details)
        form_layout.addWidget(self.in_group)
        
        form_layout.addWidget(QLabel("Filter:"))
        self.in_filter = QLineEdit()
        self.in_filter.textChanged.connect(self.save_current_details)
        form_layout.addWidget(self.in_filter)
        self.right_layout.addLayout(form_layout)
        
        # Secondary Expression
        sec_layout = QHBoxLayout()
        sec_layout.addWidget(QLabel("Secondary Expr:"))
        self.in_sec_expr = QLineEdit()
        self.in_sec_expr.setPlaceholderText('e.g., "Category" or substr(@layer_name, 1, 5)')
        self.in_sec_expr.textChanged.connect(self.save_current_details)
        sec_layout.addWidget(self.in_sec_expr)
        self.right_layout.addLayout(sec_layout)
        
        # Sensitive Features Section
        self.right_layout.addWidget(QLabel("<br><b>Sensitive Features (Only used for Custom Buffers)</b>"))
        
        add_layout = QHBoxLayout()
        self.in_feature_name = QLineEdit()
        self.in_feature_name.setPlaceholderText("Feature Name (e.g. Lanius collurio (punaselg-õgija))")
        self.in_feature_dist = QDoubleSpinBox()
        self.in_feature_dist.setRange(0.1, 100000.0)
        self.in_feature_dist.setSuffix(" m")
        self.in_feature_dist.setValue(500.0)
        
        self.btn_add_sensitive = QPushButton("➕ Add")
        self.btn_add_sensitive.clicked.connect(self.add_sensitive_feature)
        
        add_layout.addWidget(self.in_feature_name, stretch=1)
        add_layout.addWidget(self.in_feature_dist)
        add_layout.addWidget(self.btn_add_sensitive)
        self.right_layout.addLayout(add_layout)
        
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Feature Group Name", "Sensitivity Buffer (m)"])
        self.table.horizontalHeader().setSectionResizeMode(0, QT_HEADER_STRETCH)
        
        # Connect to catch manual edits inside the table
        self.table.itemChanged.connect(self.save_current_details)
        self.right_layout.addWidget(self.table)
        
        self.btn_del_sensitive = QPushButton("❌ Remove Selected")
        self.btn_del_sensitive.clicked.connect(self.remove_sensitive_feature)
        self.right_layout.addWidget(self.btn_del_sensitive)
        
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        main_layout.addWidget(splitter)

        # Dialog Buttons
        self.button_box = QDialogButtonBox(QDIALOG_BTN_SAVE | QDIALOG_BTN_CANCEL)
        self.button_box.accepted.connect(self.save_and_close)
        self.button_box.rejected.connect(self.reject)
        main_layout.addWidget(self.button_box)
        
        self.enable_right_panel(False)
        if self.layer_list.count() > 0:
            self.layer_list.setCurrentRow(0)

    def enable_right_panel(self, enabled):
        self.in_group.setEnabled(enabled)
        self.in_filter.setEnabled(enabled)
        self.in_sec_expr.setEnabled(enabled)
        self.in_feature_name.setEnabled(enabled)
        self.in_feature_dist.setEnabled(enabled)
        self.btn_add_sensitive.setEnabled(enabled)
        self.table.setEnabled(enabled)
        self.btn_del_sensitive.setEnabled(enabled)

    def load_target_details(self, idx):
        # Prevent wiping changes when switching targets
        if self.current_target_idx >= 0 and self.current_target_idx != idx:
            self.save_current_details()
            
        if idx < 0 or idx >= len(self.targets): 
            self.enable_right_panel(False)
            return
            
        self.enable_right_panel(True)
        self.current_target_idx = idx
        target = self.targets[idx]
        
        self.lbl_layer.setText(f"Editing: {target.get('layer', 'Unknown')}")
        
        self.in_group.blockSignals(True)
        self.in_filter.blockSignals(True)
        self.in_sec_expr.blockSignals(True)
        
        self.in_group.setText(target.get('custom_field', ''))
        self.in_filter.setText(target.get('custom_filter', ''))
        self.in_sec_expr.setText(target.get('secondary_expr', ''))
        
        self.in_group.blockSignals(False)
        self.in_filter.blockSignals(False)
        self.in_sec_expr.blockSignals(False)
        
        # Block signals so populating the table doesn't trigger save_current_details 
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        sensitive = target.get('sensitive_features', {})
        for name, dist in sensitive.items():
            self.insert_table_row(name, dist)
        self.table.blockSignals(False)

    def insert_table_row(self, name, dist):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(name))
        self.table.setItem(row, 1, QTableWidgetItem(f"{dist:g}"))

    def add_sensitive_feature(self):
        name = self.in_feature_name.text().strip()
        dist = self.in_feature_dist.value()
        if not name: return
        
        self.table.blockSignals(True)
        found = False
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).text() == name:
                self.table.item(row, 1).setText(f"{dist:g}")
                found = True
                break
                
        if not found: self.insert_table_row(name, dist)
        self.table.blockSignals(False)
        
        self.in_feature_name.clear()
        self.save_current_details()

    def remove_sensitive_feature(self):
        rows = set(item.row() for item in self.table.selectedItems())
        self.table.blockSignals(True)
        for row in sorted(rows, reverse=True):
            self.table.removeRow(row)
        self.table.blockSignals(False)
        self.save_current_details()

    def save_current_details(self):
        if self.current_target_idx < 0: return
        
        target = self.targets[self.current_target_idx]
        
        grp = self.in_group.text().strip()
        flt = self.in_filter.text().strip()
        sec = self.in_sec_expr.text().strip()
        
        target['custom_field'] = grp if grp else None
        target['custom_filter'] = flt if flt else None
        target['secondary_expr'] = sec if sec else None
        
        sensitive = {}
        for row in range(self.table.rowCount()):
            name_item = self.table.item(row, 0)
            dist_item = self.table.item(row, 1)
            if not name_item or not dist_item: continue
            
            name = name_item.text().strip()
            if not name: continue
            
            try: 
                # Bulletproof against European locale commas
                dist_str = dist_item.text().replace(',', '.').strip()
                dist = float(dist_str)
            except ValueError: 
                continue # If they typed pure letters, we skip it to prevent a hard crash
                
            sensitive[name] = dist
            
        if sensitive: target['sensitive_features'] = sensitive
        elif 'sensitive_features' in target: del target['sensitive_features']

    def save_and_close(self):
        self.save_current_details() 
        settings = QgsSettings()
        profiles = json.loads(settings.value("spatial_pivot/geosearch_profiles", "{}"))
        
        profile_data = profiles.get(self.profile_name, {})
        if isinstance(profile_data, list):
            profiles[self.profile_name] = {"targets": self.targets, "main_buffers": [], "custom_buffers": []}
        else:
            profile_data["targets"] = self.targets
            profiles[self.profile_name] = profile_data
            
        settings.setValue("spatial_pivot/geosearch_profiles", json.dumps(profiles))
        self.accept()