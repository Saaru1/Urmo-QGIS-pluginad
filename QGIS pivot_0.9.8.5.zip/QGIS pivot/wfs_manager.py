import json
from qgis.PyQt.QtWidgets import QMessageBox, QInputDialog, QLineEdit, QTreeWidgetItem
from qgis.core import QgsSettings, QgsApplication
from .compat import *
from .geosearch_logic import WfsCatalogFetchTask

class WfsManager:
    def __init__(self, dock):
        self.dock = dock
        self.active_tasks = []

    def prompt_add_wfs(self):
        url, ok = QInputDialog.getText(self.dock, "Add Custom WFS Server", "Enter WFS Server URL:", QLINEEDIT_NORMAL, "")
        if ok and url:
            url = url.strip()
            name, ok2 = QInputDialog.getText(self.dock, "WFS Server Name", "Enter a display name for this server:", QLINEEDIT_NORMAL, "Custom WFS")
            if ok2 and name:
                self.save_wfs_server(name.strip(), url)
                self.fetch_wfs_server(name.strip(), url)

    def save_wfs_server(self, name, url):
        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        servers[name] = url
        settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))

    def remove_wfs_server(self, name):
        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        clean_name = name.replace(" [Failed]", "").replace(" [Loading...]", "")
        if clean_name in servers:
            del servers[clean_name]
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))
            return True
        return False

    def rename_wfs_server(self, old_name, new_name):
        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        clean_old = old_name.replace(" [Failed]", "").replace(" [Loading...]", "")
        new_name_clean = new_name.strip()
        
        if clean_old in servers and new_name_clean and new_name_clean not in servers:
            url = servers.pop(clean_old)
            servers[new_name_clean] = url
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))
            return True
        return False

    def load_all_wfs_catalogs(self):
        # --- THE FIX: Single brain controlling the global catalog ---
        self.dock.global_root_wfs.takeChildren()
        
        item_add1 = QTreeWidgetItem(self.dock.global_root_wfs, ["➕ Add Custom WFS Server..."])
        item_add1.setData(0, QT_USER_ROLE, {"type": "add_custom_wfs"})

        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        
        needs_save = False
        if "Estonian Topo (ETA)" in servers:
            del servers["Estonian Topo (ETA)"]
            needs_save = True
            
        for k, v in list(servers.items()):
            if "geoserver/eta/wfs" in v:
                del servers[k]
                needs_save = True
                
        if needs_save:
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))

        if not servers:
            servers = {
                "EELIS (Public)": "https://gsavalik.envir.ee/geoserver/eelis/ows",
                "EELIS (Internal)": "https://gsa.envir.ee/geoserver/eelis/wfs", 
                "Maa-amet Kataster": "https://gsavalik.envir.ee/geoserver/kataster/wfs",
                "PRIA (Public)": "https://kls.pria.ee/geoserver/pria_avalik/wfs",
                "Estonian Topo (ETAK)": "https://gsavalik.envir.ee/geoserver/etak/wfs"
            }
            for name, url in servers.items():
                self.save_wfs_server(name, url)

        for name, url in servers.items():
            self.fetch_wfs_server(name, url)

    def force_refresh_wfs(self):
        self.load_all_wfs_catalogs()
        self.dock.log_message("Forced WFS catalog refresh.")

    def fetch_wfs_server(self, server_name, url):
        node1 = None
        for i in range(self.dock.global_root_wfs.childCount()):
            if self.dock.global_root_wfs.child(i).text(0) == server_name or self.dock.global_root_wfs.child(i).text(0).startswith(server_name + " ["):
                node1 = self.dock.global_root_wfs.child(i)
                break
                
        if not node1:
            node1 = QTreeWidgetItem(self.dock.global_root_wfs, [f"{server_name} [Loading...]"])
            node1.setData(0, QT_USER_ROLE, {"type": "wfs_server", "uri": url, "name": server_name})
        else:
            node1.setText(0, f"{server_name} [Loading...]")
            node1.takeChildren()

        task = WfsCatalogFetchTask(f"Fetching WFS: {server_name}", url, node1, None, self.on_wfs_fetched)
        self.active_tasks.append(task)
        QgsApplication.taskManager().addTask(task)

    def on_wfs_fetched(self, layers, error_msg, n1, n2=None):
        data = n1.data(0, QT_USER_ROLE)
        s_name = data.get("name")
        
        if error_msg:
            n1.setText(0, f"{s_name} [Failed]")
            self.dock.log_message(f"WFS fetch failed for '{s_name}': {error_msg}", True)
            return
            
        n1.setText(0, s_name)
        
        for lyr_name in layers:
            c1 = QTreeWidgetItem(n1, [lyr_name])
            c1.setData(0, QT_USER_ROLE, {"type": "wfs", "uri": data.get("uri"), "name": lyr_name})