import traceback
import xml.etree.ElementTree as ET
import pandas as pd
from qgis.core import (QgsTask, QgsVectorLayer, QgsFeatureRequest, QgsWkbTypes, 
                       QgsGeometry, QgsBlockingNetworkRequest, QgsProject,
                       QgsExpression, QgsExpressionContext, QgsExpressionContextUtils)
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.PyQt.QtCore import QUrl

from .compat import *

class WfsCatalogParser:
    @staticmethod
    def fetch_layers(url):
        try:
            base_url = url.split('?')[0]
            req_url = f"{base_url}?SERVICE=WFS&REQUEST=GetCapabilities&VERSION=1.0.0"
            
            req = QgsBlockingNetworkRequest()
            result_code = req.get(QNetworkRequest(QUrl(req_url)), forceRefresh=True)
            
            if result_code != 0:
                domain = base_url.split('/')[2] if '//' in base_url else base_url
                return False, [], f"Network Error ({domain}): {req.errorMessage()}"
                
            content = req.reply().content().data()
            root = ET.fromstring(content)
            layers = []
            
            for elem in root.iter():
                if elem.tag.endswith('FeatureType'):
                    name_val = None
                    title_val = None
                    for child in elem:
                        if child.tag.endswith('Name'): name_val = child.text
                        elif child.tag.endswith('Title'): title_val = child.text
                    if name_val:
                        layers.append({'name': name_val, 'title': title_val if title_val else name_val})
                        
            return True, layers, None
            
        except Exception as e:
            return False, [], f"Failed to parse WFS:\n{traceback.format_exc()}"

class WfsCatalogFetchTask(QgsTask):
    def __init__(self, description, url, n1, n2, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.url = url
        self.n1 = n1 
        self.n2 = n2
        self.callback = callback
        self.success = False
        self.layers = []
        self.error_msg = None

    def run(self):
        self.success, parsed_layers, self.error_msg = WfsCatalogParser.fetch_layers(self.url)
        if self.success:
            # Extract just the layer names for the UI tree
            self.layers = [layer['name'] for layer in parsed_layers]
        return True

    def finished(self, result):
        # Pass the extracted layers, error message, and both UI nodes back to wfs_manager
        self.callback(self.layers if self.success else [], self.error_msg, self.n1, self.n2)

class WfsSchemaFetchTask(QgsTask):
    def __init__(self, description, layer_name, layer_def, list_item, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.layer_name = layer_name
        self.layer_def = layer_def
        self.list_item = list_item
        self.callback = callback
        self.fields = []
        self.success = False

    def run(self):
        l_type = self.layer_def.get("type", "wfs")
        if l_type == "wfs":
            url = self.layer_def.get("uri").split('?')[0]
            crs_authid = QgsProject.instance().crs().authid() or 'EPSG:3301'
            uri = f"restrictToRequestBBOX='1' srsname='{crs_authid}' typename='{self.layer_name}' url='{url}'"
            vlayer = QgsVectorLayer(uri, self.layer_name, "WFS")
        elif l_type == "canvas":
            vlayer = QgsProject.instance().mapLayer(self.layer_def.get("uri"))
        else:
            vlayer = QgsVectorLayer(self.layer_def.get("uri"), self.layer_name, "ogr")
            
        if vlayer and vlayer.isValid():
            self.fields = vlayer.fields().names()
            self.success = True
        return True

    def finished(self, result):
        self.callback(self.success, self.fields, self.list_item)

class GeosearchTask(QgsTask):
    def __init__(self, description, targets, aoi_geom, predicate, main_buffer_dists, custom_buffer_dists, strict_mode, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.targets = targets
        self.aoi_geom = aoi_geom
        self.predicate = predicate
        self.main_buffer_dists = main_buffer_dists
        self.custom_buffer_dists = custom_buffer_dists
        self.strict_mode = strict_mode
        self.callback = callback
        self.df_result = None
        self.raw_geodata = [] 
        self.buffered_geoms = [] 
        self.log_messages = []
        self.exception = None

    def _generate_rings(self, dists, prefix):
        rings = []
        prev_dist = 0.0
        for dist in dists:
            ring_geom = self.aoi_geom.buffer(dist, 36).difference(self.aoi_geom.buffer(prev_dist, 36))
            name = f"{prefix} B: {dist:g}m"
            rings.append((name, ring_geom, dist, prefix))
            self.buffered_geoms.append((name, ring_geom, dist, prefix))
            prev_dist = dist
        return rings

    def run(self):
        try:
            data = []
            self.main_rings = self._generate_rings(self.main_buffer_dists, "Main")
            self.custom_rings = self._generate_rings(self.custom_buffer_dists, "Custom")
                
            max_dist = 0.0
            if self.main_buffer_dists: max_dist = max(max_dist, self.main_buffer_dists[-1])
            if self.custom_buffer_dists: max_dist = max(max_dist, self.custom_buffer_dists[-1])
            
            for t in self.targets:
                for _, s_dist in t.get('sensitive_features', {}).items():
                    if s_dist > max_dist: max_dist = s_dist
                    
            max_search_geom = self.aoi_geom.buffer(max_dist, 36) if max_dist > 0 else self.aoi_geom
            bbox = max_search_geom.boundingBox()
            
            total_layers = len(self.targets)
            crs_authid = QgsProject.instance().crs().authid() or 'EPSG:3301'
            
            dynamic_cols = []
            for b_name, _, _, _ in self.main_rings + self.custom_rings:
                dynamic_cols.extend([f"{b_name} Count", f"{b_name} Area (ha)", f"{b_name} Length (m)"])
            
            for idx, target in enumerate(self.targets):
                if self.isCanceled(): return False
                self.setProgress((idx / total_layers) * 100)
                
                layer_name = target['layer']
                custom_field = target.get('custom_field') 
                custom_filter = target.get('custom_filter')
                sec_expr_str = target.get('secondary_expr')
                sensitive_features = target.get('sensitive_features', {})
                buffer_role = target.get('buffer_role', 'Main Only')
                l_type = target.get('type', 'wfs')
                
                if l_type == 'wfs':
                    wfs_url = target['url'].split('?')[0]
                    uri = f"restrictToRequestBBOX='1' srsname='{crs_authid}' typename='{layer_name}' url='{wfs_url}'"
                    vlayer = QgsVectorLayer(uri, layer_name, "WFS")
                elif l_type == 'canvas':
                    vlayer = QgsProject.instance().mapLayer(target['url'])
                else:
                    vlayer = QgsVectorLayer(target['url'], layer_name, "ogr")
                
                if not vlayer or not vlayer.isValid():
                    self.log_messages.append(f"[WARN] Failed to load {layer_name}. Skipping.")
                    continue
                    
                # Setup Dynamic Expression Context Engine
                exp = None
                context = None
                if sec_expr_str:
                    exp = QgsExpression(sec_expr_str)
                    context = QgsExpressionContext()
                    context.appendScope(QgsExpressionContextUtils.globalScope())
                    context.appendScope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
                    context.appendScope(QgsExpressionContextUtils.layerScope(vlayer))
                    exp.prepare(context)
                    
                request = QgsFeatureRequest().setFilterRect(bbox)
                if custom_filter: request.setFilterExpression(custom_filter)
                
                for feature in vlayer.getFeatures(request):
                    if self.isCanceled(): return False
                    geom = feature.geometry()
                    if not geom or geom.isEmpty(): continue
                        
                    if self.predicate == 'Intersects' and not geom.intersects(max_search_geom): continue
                    elif self.predicate == 'Contains' and not max_search_geom.contains(geom): continue
                    elif self.predicate == 'Within' and not max_search_geom.within(geom): continue
                    elif self.predicate == 'Touches' and not geom.touches(max_search_geom): continue
                        
                    fields = feature.fields().names()
                    name_val = "N/A"
                    field_used = "Name"
                    
                    # Logic differentiation for Secondary Expression
                    secondary_val = "N/A" 
                    
                    if custom_field and custom_field in fields:
                        val = feature[custom_field]
                        if val: name_val = str(val)
                        field_used = custom_field
                    else:
                        for n_field in ['nimi', 'name', 'nimetus', 'kood', 'objekti_id']:
                            if n_field in fields:
                                val = feature[n_field]
                                if val:
                                    name_val = str(val)
                                    field_used = n_field
                                    break
                                    
                    # Evaluate Secondary Expression (Overrides "N/A" with actual result, blank, or error)
                    if sec_expr_str:
                        if exp:
                            context.setFeature(feature)
                            res = exp.evaluate(context)
                            if not exp.hasEvalError():
                                secondary_val = str(res) if res is not None else ""
                            else:
                                secondary_val = "Eval Error"
                        else:
                            secondary_val = ""
                                    
                    geom_type_enum = geom.type()
                    geom_string = "Polygon" if geom_type_enum == QGS_WKB_POLYGON else "Line" if geom_type_enum == QGS_WKB_LINE else "Point"
                    
                    row_data = {"Layer": layer_name, "Type": geom_string, "Group": name_val, "Secondary": secondary_val,
                                "Sensitive Alert": "", "Threshold (m)": 0.0, 
                                "AOI Count": 0, "AOI (ha)": 0.0, "AOI Length (m)": 0.0}
                    
                    for d_col in dynamic_cols:
                        row_data[d_col] = 0.0 if "Area" in d_col or "Length" in d_col else 0

                    matched_any = False
                    is_sensitive_hit = False
                    hit_threshold = 0.0
                    sensitive_dist = sensitive_features.get(name_val)

                    match_aoi = False
                    if self.predicate == 'Intersects': match_aoi = geom.intersects(self.aoi_geom)
                    elif self.predicate == 'Contains': match_aoi = self.aoi_geom.contains(geom)
                    elif self.predicate == 'Within': match_aoi = self.aoi_geom.within(geom)
                    elif self.predicate == 'Touches': match_aoi = geom.touches(self.aoi_geom)

                    if match_aoi:
                        ix_aoi = geom.intersection(self.aoi_geom) if self.predicate == 'Intersects' else geom
                        if not ix_aoi.isEmpty():
                            matched_any = True
                            row_data["AOI Count"] = 1
                            if geom_type_enum == QGS_WKB_POLYGON: row_data["AOI (ha)"] = ix_aoi.area() / 10000.0
                            elif geom_type_enum == QGS_WKB_LINE: row_data["AOI Length (m)"] = ix_aoi.length()
                            
                            zone_alert = "YES" if sensitive_dist is not None else ""
                            if zone_alert: 
                                is_sensitive_hit = True
                                hit_threshold = float(sensitive_dist)
                            
                            f_attrs = {field_used: name_val, "Sensitive Alert": zone_alert, "Threshold (m)": sensitive_dist if zone_alert else 0.0}
                            self.raw_geodata.append({
                                "Layer": layer_name, "Group": name_val, "Secondary": secondary_val, "Geometry": QgsGeometry(ix_aoi), 
                                "Type": geom_type_enum, "Zone": "AOI", "feature_attrs": f_attrs
                            })

                    rings_to_test = []
                    
                    if self.strict_mode:
                        if buffer_role in ['Main Only', 'Main + Custom']: rings_to_test.extend(self.main_rings)
                        if buffer_role in ['Custom Only', 'Main + Custom']: rings_to_test.extend(self.custom_rings)
                    else:
                        rings_to_test.extend(self.main_rings)
                        rings_to_test.extend(self.custom_rings)

                    for b_name, b_geom, b_dist, prefix in rings_to_test:
                        
                        if self.strict_mode and prefix == "Custom":
                            if sensitive_dist is None or b_dist > sensitive_dist:
                                continue
                                
                        match_ring = False
                        if self.predicate == 'Intersects': match_ring = geom.intersects(b_geom)
                        elif self.predicate == 'Contains': match_ring = b_geom.contains(geom)
                        elif self.predicate == 'Within': match_ring = b_geom.within(geom)
                        elif self.predicate == 'Touches': match_ring = geom.touches(b_geom)
                        
                        if match_ring:
                            ix_ring = geom.intersection(b_geom) if self.predicate == 'Intersects' else geom
                            if not ix_ring.isEmpty():
                                matched_any = True
                                row_data[f"{b_name} Count"] = 1 
                                if geom_type_enum == QGS_WKB_POLYGON: row_data[f"{b_name} Area (ha)"] = ix_ring.area() / 10000.0
                                elif geom_type_enum == QGS_WKB_LINE: row_data[f"{b_name} Length (m)"] = ix_ring.length()
                                
                                zone_alert = "YES" if prefix == "Custom" and (sensitive_dist is not None and b_dist <= sensitive_dist) else ""
                                if zone_alert: 
                                    is_sensitive_hit = True
                                    hit_threshold = float(sensitive_dist)
                                
                                f_attrs = {field_used: name_val, "Sensitive Alert": zone_alert, "Threshold (m)": sensitive_dist if zone_alert else 0.0}
                                self.raw_geodata.append({
                                    "Layer": layer_name, "Group": name_val, "Secondary": secondary_val, "Geometry": QgsGeometry(ix_ring), 
                                    "Type": geom_type_enum, "Zone": b_name, "feature_attrs": f_attrs
                                })
                                
                    if matched_any:
                        row_data["Sensitive Alert"] = "YES" if is_sensitive_hit else ""
                        row_data["Threshold (m)"] = hit_threshold if is_sensitive_hit else 0.0
                        data.append(row_data)

            self.setProgress(100)
            df = pd.DataFrame(data)
            
            cols_order = ['Layer', 'Type', 'Group', 'Secondary', 'Sensitive Alert', 'Threshold (m)', 'AOI Count', 'AOI (ha)', 'AOI Length (m)']
            for b_name, _, _, _ in self.main_rings: cols_order.extend([f"{b_name} Count", f"{b_name} Area (ha)", f"{b_name} Length (m)"])
            for b_name, _, _, _ in self.custom_rings: cols_order.extend([f"{b_name} Count", f"{b_name} Area (ha)", f"{b_name} Length (m)"])
            
            if not df.empty:
                for c in df.columns:
                    if c not in cols_order: cols_order.append(c)
                    
                agg_funcs = {'Sensitive Alert': 'max', 'Threshold (m)': 'max'}
                numeric_keys = [c for c in cols_order if 'Count' in c or 'Area' in c or 'Length' in c or 'AOI (ha)' in c]
                for nk in numeric_keys: agg_funcs[nk] = 'sum'
                
                for c in list(agg_funcs.keys()):
                    if c not in df.columns: df[c] = 0.0 if c not in ['Sensitive Alert', 'Threshold (m)'] else ""
                        
                self.df_result = df.groupby(['Layer', 'Type', 'Group', 'Secondary'], as_index=False).agg(agg_funcs)
                self.df_result = self.df_result[[c for c in cols_order if c in self.df_result.columns]]

                numeric_cols = [c for c in self.df_result.columns if 'Area' in c or 'Length' in c or 'AOI (ha)' in c]
                for c in numeric_cols:
                    self.df_result[c] = pd.to_numeric(self.df_result[c], errors='coerce')
                    if not self.df_result[c].isna().all():
                        decimals = 2 if 'Area' in c or 'AOI (ha)' in c else 0
                        self.df_result[c] = self.df_result[c].round(decimals)
                    self.df_result[c] = self.df_result[c].replace(0, pd.NA)
                    
                count_cols = [c for c in self.df_result.columns if 'Count' in c]
                for c in count_cols:
                    self.df_result[c] = self.df_result[c].replace(0, pd.NA)
                        
                if 'Threshold (m)' in self.df_result.columns:
                    self.df_result['Threshold (m)'] = self.df_result['Threshold (m)'].replace(0.0, "")
            else:
                self.df_result = pd.DataFrame(columns=cols_order)
                
            if self.strict_mode and not self.df_result.empty:
                self.log_messages.append("[INFO] Strict Mode: Pruning visually empty metrics.")
                cols_to_drop = []
                protected_cols = ['Layer', 'Type', 'Group', 'Secondary', 'Sensitive Alert', 'Threshold (m)', 'AOI Count', 'AOI (ha)', 'AOI Length (m)']
                
                for c in self.df_result.columns:
                    if c not in protected_cols:
                        if self.df_result[c].isna().all() or (self.df_result[c] == '').all():
                            cols_to_drop.append(c)
                            
                if cols_to_drop:
                    self.df_result.drop(columns=cols_to_drop, inplace=True, errors='ignore')
            elif self.strict_mode:
                self.log_messages.append("[INFO] Strict Mode: Report is empty, maintaining template structure.")
            else:
                self.log_messages.append("[INFO] Debug Mode: Calculating all intersections; Preserving full metric template.")

            return True
        except Exception as e:
            self.exception = traceback.format_exc()
            return False

    def finished(self, result):
        self.callback(self.df_result, self.raw_geodata, self.buffered_geoms, self.log_messages, self.exception)