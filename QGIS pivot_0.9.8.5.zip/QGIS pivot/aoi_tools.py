import math
from qgis.PyQt.QtWidgets import QWidget, QHBoxLayout, QToolButton, QMenu, QAction, QMessageBox, QToolTip
from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.core import (QgsGeometry, QgsPointXY, QgsApplication, 
                       QgsWkbTypes, QgsRectangle, QgsFeatureRequest, QgsVectorLayer)
from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand
from qgis.utils import iface

from .compat import *

class AOIWidget(QWidget):
    aoi_changed = pyqtSignal(object) 
    buffer_captured_main = pyqtSignal(list) 
    buffer_captured_custom = pyqtSignal(list) 

    def __init__(self, canvas, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        self.current_aoi_geom = None
        self.current_aoi_title = "" # Stores the extracted Nimi/Nimetus
        self.map_tool = None
        
        self.aoi_rubberband = QgsRubberBand(self.canvas, QGS_WKB_POLYGON) 
        self.aoi_rubberband.setZValue(9999) 
        self.aoi_rubberband.setColor(QColor(255, 100, 100, 80))
        self.aoi_rubberband.setStrokeColor(QColor(255, 0, 0))
        self.aoi_rubberband.setWidth(2)

        self.main_buffer_rubberbands = []
        self.custom_buffer_rubberbands = []

        self.initUI()

    def initUI(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.tool_btn = QToolButton()
        self.tool_btn.setCheckable(True) 
        
        try:
            self.tool_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            self.tool_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        except AttributeError:
            self.tool_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            self.tool_btn.setPopupMode(QToolButton.MenuButtonPopup)
        
        icon_path = QgsApplication.iconPath("mActionSelectPolygon.svg")
        if icon_path:
            self.tool_btn.setIcon(QIcon(icon_path))

        self.menu = QMenu(self)

        self.action_click = QAction("Select Feature by Click", self)
        self.action_click.triggered.connect(self.activate_click_tool)
        self.menu.addAction(self.action_click)

        self.action_polygon = QAction("Draw Polygon", self)
        self.action_polygon.triggered.connect(self.activate_polygon_tool)
        self.menu.addAction(self.action_polygon)
        
        self.action_freehand = QAction("Draw Freehand", self)
        self.action_freehand.triggered.connect(self.activate_freehand_tool)
        self.menu.addAction(self.action_freehand)

        self.action_radius = QAction("Draw Radius", self)
        self.action_radius.triggered.connect(self.activate_radius_tool)
        self.menu.addAction(self.action_radius)
        
        self.action_buffer_main = QAction("Interactive Main Multi-Ring...", self)
        self.action_buffer_main.setEnabled(False) 
        self.action_buffer_main.triggered.connect(self.activate_buffer_tool_main)
        self.menu.addAction(self.action_buffer_main)
        
        self.action_buffer_custom = QAction("Interactive Custom Multi-Ring...", self)
        self.action_buffer_custom.setEnabled(False) 
        self.action_buffer_custom.triggered.connect(self.activate_buffer_tool_custom)
        self.menu.addAction(self.action_buffer_custom)
        
        self.tool_btn.setMenu(self.menu)
        
        self.activate_click_tool()
        self.tool_btn.clicked.connect(self.reapply_current_tool)

        layout.addWidget(self.tool_btn)

        self.clear_btn = QToolButton()
        self.clear_btn.setText("❌ Clear AOI")
        try:
            self.clear_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        except AttributeError:
            self.clear_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            
        self.clear_btn.clicked.connect(self.clear_aoi)
        self.clear_btn.setEnabled(False) 
        layout.addWidget(self.clear_btn)

    def set_map_tool(self, tool, label):
        self.tool_btn.setText(f" AOI: {label}")
        if self.map_tool:
            self.canvas.unsetMapTool(self.map_tool)
            
        self.map_tool = tool
        self.map_tool.geometry_captured.connect(self.on_geometry_captured)
        
        if isinstance(tool, InteractiveBufferTool):
            if tool.zone_type == "Main":
                tool.buffer_captured.connect(self.buffer_captured_main.emit)
            else:
                tool.buffer_captured.connect(self.buffer_captured_custom.emit)
            
        self.canvas.setMapTool(self.map_tool)

    def reapply_current_tool(self):
        if self.map_tool:
            self.canvas.setMapTool(self.map_tool)
        self.tool_btn.setChecked(self.current_aoi_geom is not None)

    def activate_click_tool(self):
        self.set_map_tool(ClickSelectAOITool(self.canvas), "Select")

    def activate_polygon_tool(self):
        self.set_map_tool(PolygonAOITool(self.canvas), "Polygon")

    def activate_freehand_tool(self):
        self.set_map_tool(FreehandAOITool(self.canvas), "Freehand")

    def activate_radius_tool(self):
        self.set_map_tool(RadiusAOITool(self.canvas), "Radius")
        
    def activate_buffer_tool_main(self):
        if not self.current_aoi_geom: return
        self.set_map_tool(InteractiveBufferTool(self.canvas, self.current_aoi_geom, "Main"), "Main Rings")
        
    def activate_buffer_tool_custom(self):
        if not self.current_aoi_geom: return
        self.set_map_tool(InteractiveBufferTool(self.canvas, self.current_aoi_geom, "Custom"), "Custom Rings")

    def _clear_main_bands(self):
        for rb in self.main_buffer_rubberbands: rb.reset()
        self.main_buffer_rubberbands.clear()
        
    def _clear_custom_bands(self):
        for rb in self.custom_buffer_rubberbands: rb.reset()
        self.custom_buffer_rubberbands.clear()

    def clear_aoi(self):
        self.current_aoi_geom = None
        self.current_aoi_title = ""
        self.aoi_rubberband.reset()
        self.aoi_rubberband.hide()
        self._clear_main_bands()
        self._clear_custom_bands()
        self.clear_btn.setEnabled(False)
        self.action_buffer_main.setEnabled(False) 
        self.action_buffer_custom.setEnabled(False) 
        self.tool_btn.setChecked(False) 
        if self.map_tool:
            self.canvas.unsetMapTool(self.map_tool)
        self.aoi_changed.emit(None)

    def on_geometry_captured(self, geom, title=""):
        if geom is None or geom.isEmpty() or (self.current_aoi_geom and geom.equals(self.current_aoi_geom)):
            return

        self.current_aoi_geom = QgsGeometry(geom) 
        self.current_aoi_title = title # Save the extracted title
        
        self.aoi_rubberband.setToGeometry(self.current_aoi_geom, None)
        
        self.aoi_rubberband.setColor(QColor(255, 100, 100, 80))
        self.aoi_rubberband.setStrokeColor(QColor(255, 0, 0))
        self.aoi_rubberband.setWidth(2)
        self.aoi_rubberband.setZValue(9999)
        self.aoi_rubberband.show() 
        
        if hasattr(self.aoi_rubberband, 'updatePosition'):
            self.aoi_rubberband.updatePosition()
            self.aoi_rubberband.update()
        
        self._clear_main_bands()
        self._clear_custom_bands()
        self.clear_btn.setEnabled(True)
        self.action_buffer_main.setEnabled(True) 
        self.action_buffer_custom.setEnabled(True) 
        self.tool_btn.setChecked(True)
        self.aoi_changed.emit(self.current_aoi_geom)

    def on_buffer_captured_main(self, dists):
        self._clear_main_bands()
        if not self.current_aoi_geom or not dists: return
            
        prev_dist = 0.0
        for i, dist in enumerate(dists):
            rb = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
            rb.setZValue(9998)
            total = len(dists)
            opacity = int(70 - (55 * (i / (total - 1)))) if total > 1 else 50
            rb.setColor(QColor(50, 150, 255, opacity))
            rb.setStrokeColor(QColor(50, 150, 255, 255))
            rb.setWidth(2)
            
            geom = self.current_aoi_geom.buffer(dist, 36).difference(self.current_aoi_geom.buffer(prev_dist, 36))
            rb.setToGeometry(geom, None)
            rb.show()
            self.main_buffer_rubberbands.append(rb)
            prev_dist = dist

    def on_buffer_captured_custom(self, dists):
        self._clear_custom_bands()
        if not self.current_aoi_geom or not dists: return
            
        prev_dist = 0.0
        for i, dist in enumerate(dists):
            rb = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
            rb.setZValue(9998)
            total = len(dists)
            opacity = int(70 - (55 * (i / (total - 1)))) if total > 1 else 50
            rb.setColor(QColor(150, 50, 255, opacity))
            rb.setStrokeColor(QColor(150, 50, 255, 255))
            rb.setWidth(2)
            
            geom = self.current_aoi_geom.buffer(dist, 36).difference(self.current_aoi_geom.buffer(prev_dist, 36))
            rb.setToGeometry(geom, None)
            rb.show()
            self.custom_buffer_rubberbands.append(rb)
            prev_dist = dist


# ==========================================
# CUSTOM MAP TOOLS
# ==========================================

def get_mouse_btn(e, target_btn):
    try:
        return e.button() == getattr(Qt.MouseButton, target_btn)
    except AttributeError:
        return e.button() == getattr(Qt, target_btn)

class InteractiveBufferTool(QgsMapToolEmitPoint):
    geometry_captured = pyqtSignal(QgsGeometry, str) 
    buffer_captured = pyqtSignal(list)

    def __init__(self, canvas, base_geom, zone_type="Main"):
        super().__init__(canvas)
        self.canvas = canvas
        self.base_geom = base_geom
        self.zone_type = zone_type
        
        self.locked_dists = []
        self.fixed_bands = []
        
        self.preview_band = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
        self.preview_band.setZValue(9999)
        
        if self.zone_type == "Main":
            self.fill_color = QColor(50, 150, 255, 60)
            self.stroke_color = QColor(50, 150, 255, 255)
        else:
            self.fill_color = QColor(150, 50, 255, 60)
            self.stroke_color = QColor(150, 50, 255, 255)
            
        self.preview_band.setColor(QColor(50, 150, 255, 40) if self.zone_type == "Main" else QColor(150, 50, 255, 40))
        self.preview_band.setStrokeColor(QColor(255, 255, 0, 255)) 
        self.preview_band.setWidth(2)
        
        self.current_dist = 0.0

    def canvasMoveEvent(self, e):
        point = self.toMapCoordinates(e.pos())
        pt_geom = QgsGeometry.fromPointXY(point)
        dist = self.base_geom.distance(pt_geom)
        
        min_dist = self.locked_dists[-1] + 1.0 if self.locked_dists else 1.0
        if dist < min_dist:
            dist = min_dist
            
        self.current_dist = dist
        
        inner_geom = self.base_geom.buffer(self.locked_dists[-1], 36) if self.locked_dists else self.base_geom
        outer_geom = self.base_geom.buffer(self.current_dist, 36)
        doughnut = outer_geom.difference(inner_geom)
        
        self.preview_band.setToGeometry(doughnut, None)
        self.preview_band.show()
        
        global_pos = self.canvas.mapToGlobal(e.pos())
        msg = f"[{self.zone_type}] B{len(self.locked_dists)+1}: {self.current_dist:.1f} m\n(Left-Click: Add Ring | Right-Click: Finish)"
        QToolTip.showText(global_pos, msg, self.canvas)

    def canvasReleaseEvent(self, e):
        if get_mouse_btn(e, 'LeftButton'):
            if self.current_dist > 0:
                self.locked_dists.append(self.current_dist)
                
                rb = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
                rb.setZValue(9999)
                rb.setColor(self.fill_color)
                rb.setStrokeColor(self.stroke_color)
                rb.setWidth(2)
                rb.setToGeometry(self.preview_band.asGeometry(), None)
                rb.show()
                self.fixed_bands.append(rb)
                
                if len(self.locked_dists) >= 10:
                    self.buffer_captured.emit(self.locked_dists)
                    self.clean_up()
                    
        elif get_mouse_btn(e, 'RightButton'):
            if self.locked_dists:
                self.buffer_captured.emit(self.locked_dists)
            self.clean_up()

    def clean_up(self):
        self.preview_band.reset()
        self.preview_band.hide()
        for rb in self.fixed_bands: 
            rb.reset()
            rb.hide()
        self.fixed_bands.clear()
        QToolTip.hideText()
        
    def deactivate(self):
        self.clean_up()
        super().deactivate()

class ClickSelectAOITool(QgsMapToolEmitPoint):
    geometry_captured = pyqtSignal(QgsGeometry, str)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas

    def canvasReleaseEvent(self, e):
        if get_mouse_btn(e, 'LeftButton'):
            point = self.toMapCoordinates(e.pos())
            layer = iface.activeLayer()

            if isinstance(layer, QgsVectorLayer):
                tol = self.canvas.mapUnitsPerPixel() * 5
                rect = QgsRectangle(point.x() - tol, point.y() - tol, point.x() + tol, point.y() + tol)
                
                request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
                for feature in layer.getFeatures(request):
                    
                    # --- Extract the naming attribute upon click ---
                    title = ""
                    for field in feature.fields():
                        fname = field.name().lower()
                        if fname in ['nimi', 'nimetus', 'name', 'title']:
                            val = feature[field.name()]
                            if val and str(val).strip():
                                title = str(val).strip()
                                break
                                
                    self.geometry_captured.emit(QgsGeometry(feature.geometry()), title)
                    break

class PolygonAOITool(QgsMapToolEmitPoint):
    geometry_captured = pyqtSignal(QgsGeometry, str)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.rubberband = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
        self.rubberband.setZValue(9999)
        self.rubberband.setColor(QColor(255, 165, 0, 100)) 
        self.points = []

    def canvasReleaseEvent(self, e):
        point = self.toMapCoordinates(e.pos())
        
        if get_mouse_btn(e, 'LeftButton'):
            self.points.append(point)
            self.rubberband.addPoint(point, True)
            self.rubberband.show()
            
        elif get_mouse_btn(e, 'RightButton'):
            if len(self.points) > 2:
                self.points.append(self.points[0]) 
                geom = QgsGeometry.fromPolygonXY([self.points])
                
                self.rubberband.reset()
                self.rubberband.hide()
                self.points = []
                
                self.geometry_captured.emit(QgsGeometry(geom), "")
            else:
                self.rubberband.reset()
                self.rubberband.hide()
                self.points = []

    def canvasMoveEvent(self, e):
        if not self.points:
            return
        point = self.toMapCoordinates(e.pos())
        self.rubberband.movePoint(point)

    def deactivate(self):
        self.rubberband.reset()
        self.rubberband.hide()
        super().deactivate()

class FreehandAOITool(QgsMapToolEmitPoint):
    geometry_captured = pyqtSignal(QgsGeometry, str)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.rubberband = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
        self.rubberband.setZValue(9999)
        self.rubberband.setColor(QColor(255, 165, 0, 100))
        self.points = []
        self.is_drawing = False

    def canvasPressEvent(self, e):
        if get_mouse_btn(e, 'LeftButton'):
            self.points = [self.toMapCoordinates(e.pos())]
            self.is_drawing = True

    def canvasMoveEvent(self, e):
        if self.is_drawing:
            point = self.toMapCoordinates(e.pos())
            self.points.append(point)
            geom = QgsGeometry.fromPolylineXY(self.points)
            self.rubberband.setToGeometry(geom, None)
            self.rubberband.show()

    def canvasReleaseEvent(self, e):
        if self.is_drawing and get_mouse_btn(e, 'LeftButton'):
            self.is_drawing = False
            if len(self.points) > 2:
                self.points.append(self.points[0]) 
                geom = QgsGeometry.fromPolygonXY([self.points])
                
                self.rubberband.reset()
                self.rubberband.hide()
                self.points = []
                
                self.geometry_captured.emit(QgsGeometry(geom), "")
            else:
                self.rubberband.reset()
                self.rubberband.hide()
                self.points = []

    def deactivate(self):
        self.rubberband.reset()
        self.rubberband.hide()
        super().deactivate()

class RadiusAOITool(QgsMapToolEmitPoint):
    geometry_captured = pyqtSignal(QgsGeometry, str)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.rubberband = QgsRubberBand(self.canvas, QGS_WKB_POLYGON)
        self.rubberband.setZValue(9999)
        self.rubberband.setColor(QColor(255, 165, 0, 100))
        self.center = None

    def canvasReleaseEvent(self, e):
        point = self.toMapCoordinates(e.pos())
        
        if get_mouse_btn(e, 'LeftButton'):
            if self.center is None:
                self.center = point
            else:
                distance = math.sqrt(self.center.sqrDist(point))
                geom = QgsGeometry.fromPointXY(self.center).buffer(distance, 36)
                
                self.rubberband.reset()
                self.rubberband.hide()
                self.center = None
                
                self.geometry_captured.emit(QgsGeometry(geom), "")
                
        elif get_mouse_btn(e, 'RightButton'):
            self.rubberband.reset()
            self.rubberband.hide()
            self.center = None

    def canvasMoveEvent(self, e):
        if self.center is None:
            return
        point = self.toMapCoordinates(e.pos())
        distance = math.sqrt(self.center.sqrDist(point))
        geom = QgsGeometry.fromPointXY(self.center).buffer(distance, 36)
        self.rubberband.setToGeometry(geom, None)
        self.rubberband.show()

    def deactivate(self):
        self.rubberband.reset()
        self.rubberband.hide()
        super().deactivate()