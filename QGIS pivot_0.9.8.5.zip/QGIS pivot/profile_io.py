import json
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox, QInputDialog, QListWidgetItem
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsSettings

from .compat import *

class ProfileIO:
    def __init__(self, dock):
        self.dock = dock

    # ---------------------------------------------------------
    # WORKSPACE I/O
    # ---------------------------------------------------------
    def save_workspace(self):
        # --- THE FIX: Helper to safely extract both Text and Hidden Data Arrays ---
        def _extract_items(list_widget):
            items = []
            for i in range(list_widget.count()):
                item = list_widget.item(i)
                items.append({
                    'text': item.text(),
                    'data_1': item.data(QT_USER_ROLE + 1) # Captures Multi-Select filter arrays!
                })
            return items

        workspace = {
            'base_layers': [{'text': self.dock.base_layer_list.item(i).text(), 'data': self.dock.base_layer_list.item(i).data(QT_USER_ROLE)} for i in range(self.dock.base_layer_list.count())],
            'join_layers': [{'text': self.dock.join_layer_list.item(i).text(), 'data': self.dock.join_layer_list.item(i).data(QT_USER_ROLE)} for i in range(self.dock.join_layer_list.count())],
            'filters': _extract_items(self.dock.filters_list),
            'rows': _extract_items(self.dock.rows_list),
            'cols': _extract_items(self.dock.cols_list),
            'vals': _extract_items(self.dock.vals_list),
            'show_totals': self.dock.totals_check.isChecked()
        }
        
        path, _ = QFileDialog.getSaveFileName(self.dock, "Save Workspace", "", "JSON Files (*.json)")
        if path:
            if not path.endswith('.json'): path += '.json'
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump(workspace, f, indent=4)
                self.dock.log_message(f"Workspace saved successfully to: {path}")
            except Exception as e:
                self.dock.log_message(f"Failed to save workspace: {str(e)}", True)

    def load_workspace(self):
        path, _ = QFileDialog.getOpenFileName(self.dock, "Load Workspace", "", "JSON Files (*.json)")
        if not path: return
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                ws = json.load(f)
            
            # --- VALIDATION CHECK: Is this actually a Workspace? ---
            if not isinstance(ws, dict) or 'base_layers' not in ws:
                QMessageBox.warning(self.dock, "Invalid File", "This file does not appear to be a valid Pivot Workspace JSON.\n\nDid you accidentally select a Geosearch Profile?")
                return
            
            self.dock.clear_setup()
            
            for item_dict in ws.get('base_layers', []):
                item = QListWidgetItem(item_dict['text'])
                item.setData(QT_USER_ROLE, item_dict['data'])
                self.dock.base_layer_list.addItem(item)
                
            for item_dict in ws.get('join_layers', []):
                item = QListWidgetItem(item_dict['text'])
                item.setData(QT_USER_ROLE, item_dict['data'])
                self.dock.join_layer_list.addItem(item)
                
            # --- THE FIX: Helper to safely inject text and hidden data back into UI ---
            def _populate_items(list_widget, items_data):
                for i_data in items_data:
                    # Legacy support: if it's an old workspace, it's just a string
                    if isinstance(i_data, str): 
                        item = QListWidgetItem(i_data)
                    else:
                        # Modern workspace: it's a dict containing text and hidden arrays
                        item = QListWidgetItem(i_data.get('text', ''))
                        if i_data.get('data_1') is not None:
                            item.setData(QT_USER_ROLE + 1, i_data['data_1'])
                    list_widget.addItem(item)

            _populate_items(self.dock.filters_list, ws.get('filters', []))
            _populate_items(self.dock.rows_list, ws.get('rows', []))
            _populate_items(self.dock.cols_list, ws.get('cols', []))
            _populate_items(self.dock.vals_list, ws.get('vals', []))
            
            self.dock.totals_check.setChecked(ws.get('show_totals', False))
            
            self.dock.on_sources_changed()
            self.dock.log_message(f"Workspace loaded successfully from: {path}")
            
        except Exception as e:
            self.dock.log_message(f"Failed to load workspace: {str(e)}", True)

    # ---------------------------------------------------------
    # WFS PROFILE I/O
    # ---------------------------------------------------------
    def save_wfs_profile(self):
        if self.dock.geo_target_list.count() == 0: 
            return QMessageBox.warning(self.dock, "Empty", "Add targets first.")
        
        default_name = ""
        selected = self.dock.geo_profile_list.selectedItems()
        if selected: default_name = selected[0].text()
        
        name, ok = QInputDialog.getText(self.dock, "Save Profile", "Enter profile name:", QLINEEDIT_NORMAL, default_name)
        if ok and name:
            settings = QgsSettings()
            profiles = json.loads(settings.value("spatial_pivot/geosearch_profiles", "{}"))
            
            existing_profile = profiles.get(name, {})
            existing_targets = existing_profile.get("targets", []) if isinstance(existing_profile, dict) else existing_profile
            
            if name in profiles:
                reply = QMessageBox.question(self.dock, "Overwrite Profile", f"The profile '{name}' already exists.\n\nAre you sure you want to overwrite it?", QMESSAGEBOX_YES | QMESSAGEBOX_NO)
                if reply != QMESSAGEBOX_YES: return
                
            targets = []
            for i in range(self.dock.geo_target_list.count()):
                item = self.dock.geo_target_list.item(i)
                data = item.data(QT_USER_ROLE)
                layer_name = item.text().split(" [")[0].split(" (")[0].split(" {")[0].split(" 🎯")[0]
                
                s_feat = item.data(QT_USER_ROLE + 5)
                
                target_data = {
                    "layer": layer_name, 
                    "url": data.get("uri"), 
                    "type": data.get("type"), 
                    "custom_field": item.data(QT_USER_ROLE + 1),
                    "custom_filter": item.data(QT_USER_ROLE + 2),
                    "buffer_role": item.data(QT_USER_ROLE + 3) or "Main Only",
                    "secondary_expr": item.data(QT_USER_ROLE + 4)
                }
                
                if s_feat:
                    target_data["sensitive_features"] = s_feat
                    
                targets.append(target_data)
                
            profiles[name] = {
                "targets": targets,
                "main_buffers": self.dock.last_run_buffer_dists_main,
                "custom_buffers": self.dock.last_run_buffer_dists_custom
            }
            settings.setValue("spatial_pivot/geosearch_profiles", json.dumps(profiles))
            self.load_wfs_profiles()
            
            try: match_flag = Qt.MatchFlag.MatchExactly
            except AttributeError: match_flag = Qt.MatchExactly
                
            items = self.dock.geo_profile_list.findItems(name, match_flag)
            if items: self.dock.geo_profile_list.setCurrentItem(items[0])
            
            self.dock.log_message(f"Saved WFS Profile: {name}")

    def load_wfs_profiles(self):
        self.dock.geo_profile_list.clear()
        profiles = json.loads(QgsSettings().value("spatial_pivot/geosearch_profiles", "{}"))
        for name in sorted(profiles.keys()): self.dock.geo_profile_list.addItem(name)

    def load_wfs_profile_click_trigger(self, item):
        self.load_wfs_profile(item.text())

    def load_wfs_profile(self, profile_name):
        profiles = json.loads(QgsSettings().value("spatial_pivot/geosearch_profiles", "{}"))
        if profile_name in profiles:
            p_data = profiles[profile_name]
            
            if isinstance(p_data, list):
                targets = p_data
                self.dock.last_run_buffer_dists_main = []
                self.dock.last_run_buffer_dists_custom = []
            else:
                targets = p_data.get("targets", [])
                self.dock.last_run_buffer_dists_main = p_data.get("main_buffers", [])
                self.dock.last_run_buffer_dists_custom = p_data.get("custom_buffers", [])
                
            self.dock.update_buffer_ui_labels()
            
            if self.dock.aoi_widget.current_aoi_geom:
                self.dock.aoi_widget.on_buffer_captured_main(self.dock.last_run_buffer_dists_main)
                self.dock.aoi_widget.on_buffer_captured_custom(self.dock.last_run_buffer_dists_custom)
            
            for t in targets:
                self.dock.add_target_layer(t['layer'], {"type": t.get('type', 'wfs'), "uri": t['url'], "name": t['layer']})
                
                last_item = self.dock.geo_target_list.item(self.dock.geo_target_list.count() - 1)
                
                if t.get('custom_field'): last_item.setData(QT_USER_ROLE + 1, t.get('custom_field'))
                if t.get('custom_filter'): last_item.setData(QT_USER_ROLE + 2, t.get('custom_filter'))
                if t.get('buffer_role'): last_item.setData(QT_USER_ROLE + 3, t.get('buffer_role'))
                if t.get('secondary_expr'): last_item.setData(QT_USER_ROLE + 4, t.get('secondary_expr'))
                if t.get('sensitive_features'): last_item.setData(QT_USER_ROLE + 5, t.get('sensitive_features'))
                
                self.dock._refresh_target_label(last_item)

    def delete_wfs_profile(self, profile_name):
        settings = QgsSettings(); profiles = json.loads(settings.value("spatial_pivot/geosearch_profiles", "{}"))
        
        active_names = [self.dock.geo_profile_list.item(i).text() for i in range(self.dock.geo_profile_list.count())]
        deleted_count = 0
        for name in list(profiles.keys()):
            if name not in active_names:
                del profiles[name]
                deleted_count += 1
                self.dock.log_message(f"Deleted profile: {name}")
                
        if deleted_count > 0:
            settings.setValue("spatial_pivot/geosearch_profiles", json.dumps(profiles))

    def import_profile(self):
        path, _ = QFileDialog.getOpenFileName(self.dock, "Import Buffer Profile", "", "JSON Files (*.json)")
        if not path: return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                new_profiles = json.load(f)
                
            # --- STRICT VALIDATION CHECK: Is this actually a Profile? ---
            is_valid = False
            if isinstance(new_profiles, dict):
                # Hard block: If it has Workspace keys, reject immediately
                if 'base_layers' in new_profiles or 'join_layers' in new_profiles:
                    is_valid = False
                else:
                    for k, v in new_profiles.items():
                        # Modern profile structure check
                        if isinstance(v, dict) and 'targets' in v:
                            is_valid = True
                            break
                        # Legacy array structure check (must be a list of target dicts, not strings)
                        elif isinstance(v, list) and len(v) > 0 and isinstance(v[0], dict) and 'layer' in v[0]:
                            is_valid = True
                            break
                        
            if not is_valid:
                QMessageBox.warning(self.dock, "Invalid File", "This file does not appear to be a valid Geosearch Profile JSON.\n\nDid you accidentally select a Pivot Workspace?")
                return

            settings = QgsSettings()
            profiles = json.loads(settings.value("spatial_pivot/geosearch_profiles", "{}"))
            profiles.update(new_profiles)
            settings.setValue("spatial_pivot/geosearch_profiles", json.dumps(profiles))
            self.load_wfs_profiles()
            self.dock.log_message(f"Successfully imported profiles from {path}.")
        except Exception as e:
            self.dock.log_message(f"Failed to import profiles: {str(e)}", True)
            
    def export_profile(self):
        if not self.dock.geo_profile_list.selectedItems():
            return self.dock.log_message("Please select a profile to export.", True)
        profile_name = self.dock.geo_profile_list.selectedItems()[0].text()
        
        settings = QgsSettings()
        profiles = json.loads(settings.value("spatial_pivot/geosearch_profiles", "{}"))
        if profile_name not in profiles: return
        
        path, _ = QFileDialog.getSaveFileName(self.dock, "Export Buffer Profile", f"{profile_name}_Profile.json", "JSON Files (*.json)")
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump({profile_name: profiles[profile_name]}, f, indent=4)
                self.dock.log_message(f"Successfully exported profile '{profile_name}' to {path}.")
            except Exception as e:
                self.dock.log_message(f"Failed to export profile: {str(e)}", True)