import datetime
import pandas as pd
from qgis.PyQt.QtWidgets import QApplication, QProgressDialog
from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsProject, QgsVectorLayer, QgsFeature, QgsField, QgsVectorFileWriter, QgsGeometry

from .compat import *
from .symbology import apply_aoi_style, apply_categorized_style, apply_uniform_style, apply_unified_buffer_style, apply_alert_style

class GeodataExporter:
    def __init__(self, dock):
        self.dock = dock

    def build_layer_tree_from_blueprint(self):
        root = QgsProject.instance().layerTreeRoot()
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.dock.last_geo_group = root.insertGroup(0, f"Spatial Results {ts}")
        
        raw_group = None
        rep_group = None
        alert_group = None

        main_rings = [bp for bp in self.dock.precalculated_layers if bp.get("zone_type") == "Main"]
        custom_rings = [bp for bp in self.dock.precalculated_layers if bp.get("zone_type") == "Custom"]

        for bp in self.dock.precalculated_layers:
            lyr = QgsVectorLayer(bp["uri"], bp["name"], "memory")
            pr = lyr.dataProvider()
            pr.addAttributes(bp["fields"])
            lyr.updateFields()
            
            feats = []
            for geom, attrs in bp["features"]:
                f = QgsFeature()
                f.setGeometry(QgsGeometry(geom)) 
                f.setAttributes(attrs)
                feats.append(f)
                
            pr.addFeatures(feats)
            lyr.updateExtents()
            
            if bp["category"] == "AOI":
                apply_aoi_style(lyr)
                self.dock.last_geo_group.addLayer(lyr)
            elif bp["category"] == "Buffered_Main":
                apply_unified_buffer_style(lyr, "50,150,255", "")
                self.dock.last_geo_group.addLayer(lyr)
            elif bp["category"] == "Buffered_Custom":
                apply_unified_buffer_style(lyr, "150,50,255", "C")
                self.dock.last_geo_group.addLayer(lyr)
            elif bp["category"] == "Sensitive":
                apply_alert_style(lyr)
                if not alert_group: alert_group = self.dock.last_geo_group.addGroup("⚠️ Sensitive Alerts")
                alert_group.addLayer(lyr)
            else:
                if bp.get("symbology") == "Categorized":
                    apply_categorized_style(lyr, bp.get("sym_field", "Group"))
                else:
                    apply_uniform_style(lyr)

                if bp["category"] == "Raw":
                    if not raw_group: raw_group = self.dock.last_geo_group.addGroup("Raw Geometries")
                    raw_group.addLayer(lyr)
                elif bp["category"] == "Report":
                    if not rep_group: rep_group = self.dock.last_geo_group.addGroup("Query Report (Dissolved)")
                    rep_group.addLayer(lyr)

            QgsProject.instance().addMapLayer(lyr, False) 
        
        self.dock.log_message(f"Instantly restored spatial results from memory cache.")

    def generate_spatial_outputs(self, path, load_temp, inc_aoi, inc_buffered_aoi, inc_raw, inc_rep, inc_sensitive, aoi_name, sym_style="Categorized", sym_field="Group", is_pivot=False, pivot_df=None):
        QApplication.setOverrideCursor(QT_WAIT_CURSOR)
        
        self.dock.precalculated_layers = [] 
        
        total_items = len(self.dock.current_geo_raw_data) if self.dock.current_geo_raw_data else 1
        progress = QProgressDialog("Generating Spatial Data...", "Cancel", 0, total_items, self.dock)
        progress.setWindowTitle("Please Wait")
        progress.setWindowModality(QT_WINDOW_MODAL)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        
        dynamic_fields = self.dock._get_dynamic_fields()
        
        try:
            current_crs = QgsProject.instance().crs().authid()
            layers_to_export = []
            
            def get_geom_uri(ltype):
                if ltype == QGS_WKB_POLYGON: return "MultiPolygon"
                elif ltype == QGS_WKB_LINE: return "MultiLineString"
                elif ltype == QGS_WKB_POINT: return "MultiPoint"
                return "Geometry"
            
            step = 0
            
            if inc_raw:
                layer_groups = {}
                for item in self.dock.current_geo_raw_data:
                    key = (item['Layer'], item['Type'])
                    layer_groups.setdefault(key, []).append(item)
                    
                for (lname, ltype), items in layer_groups.items():
                    if not items: continue
                    geom_str = get_geom_uri(ltype)
                    
                    lyr = QgsVectorLayer(f"{geom_str}?crs={current_crs}", f"[Raw] {lname}", "memory")
                    pr = lyr.dataProvider()
                    
                    if is_pivot:
                        fields = [QgsField("Layer", QVariant.String), QgsField("Group", QVariant.String)]
                    else:
                        fields = [QgsField("Layer", QVariant.String), QgsField("Group", QVariant.String), QgsField("Secondary", QVariant.String), QgsField("Zone", QVariant.String), QgsField("Threshold_m", QVariant.Double)]
                    
                    for df in dynamic_fields:
                        fields.append(QgsField(df, QVariant.String))
                    pr.addAttributes(fields)
                    lyr.updateFields()
                    
                    feats = []
                    cache_feats = []
                    for it in items:
                        step += 1
                        if step % 10 == 0: 
                            progress.setValue(step)
                            QApplication.processEvents()
                        if progress.wasCanceled(): break
                        
                        f = QgsFeature()
                        f.setGeometry(it['Geometry'])
                        
                        if is_pivot:
                            attrs = [it['Layer'], it['Group']]
                        else:
                            attrs = [it['Layer'], it['Group'], it.get('Secondary', ''), it.get('Zone', 'AOI'), it.get('feature_attrs', {}).get('Threshold (m)', 0.0)]
                            
                        for d_field in dynamic_fields:
                            attrs.append(str(it.get('feature_attrs', {}).get(d_field, '')))
                            
                        f.setAttributes(attrs)
                        feats.append(f)
                        cache_feats.append((QgsGeometry(it['Geometry']), attrs))
                    
                    if progress.wasCanceled(): break
                    if feats:
                        pr.addFeatures(feats); lyr.updateExtents()
                        
                        if sym_style == "Categorized": apply_categorized_style(lyr, sym_field)
                        else: apply_uniform_style(lyr)
                        
                        # --- THE FIX: Prefix Raw Layers for GPKG grouping ---
                        layers_to_export.append(("Raw", lyr, f"99_Raw_{lname}"))
                        self.dock.precalculated_layers.append({
                            "category": "Raw", "name": f"99_Raw_{lname}", "uri": f"{geom_str}?crs={current_crs}",
                            "fields": fields, "features": cache_feats, "symbology": sym_style, "sym_field": sym_field
                        })
                        
            step = 0
            
            if inc_rep and not progress.wasCanceled():
                
                if is_pivot and pivot_df is not None:
                    report_groups = {}
                    for item in self.dock.current_geo_raw_data:
                        report_groups.setdefault(item['Type'], []).append(item)
                        
                    for ltype, items in report_groups.items():
                        if not items: continue
                        
                        geom_str = get_geom_uri(ltype)
                        lyr = QgsVectorLayer(f"{geom_str}?crs={current_crs}", f"[Report] Pivot Dashboard Results", "memory")
                        pr = lyr.dataProvider()
                        
                        fields = [QgsField("Layer", QVariant.String), QgsField("Group", QVariant.String)]
                        for col in pivot_df.columns:
                            if pd.api.types.is_numeric_dtype(pivot_df[col]):
                                fields.append(QgsField(str(col), QVariant.Double))
                            else:
                                fields.append(QgsField(str(col), QVariant.String))
                        pr.addAttributes(fields)
                        lyr.updateFields()
                        
                        row_cols = [self.dock.rows_list.item(i).text() for i in range(self.dock.rows_list.count())]
                        if not row_cols: row_cols = [' ']
                        
                        pivot_records = pivot_df.to_dict('records')
                        group_to_record = {}
                        for rec in pivot_records:
                            g_str = " | ".join(str(rec.get(r, '')) for r in row_cols)
                            group_to_record[g_str] = rec

                        dissolved = {}
                        for it in items:
                            key = (it['Layer'], it['Group'])
                            if key not in dissolved:
                                dissolved[key] = {'geoms': []}
                            dissolved[key]['geoms'].append(it['Geometry'])

                        feats = []
                        cache_feats = []
                        for (layer_name, group_name), grp_data in dissolved.items():
                            geom_list = grp_data['geoms']
                            
                            step += len(geom_list)
                            if step % 10 == 0: 
                                progress.setValue(min(step, total_items))
                                QApplication.processEvents()
                            if progress.wasCanceled(): break
                            
                            union_geom = geom_list[0] if len(geom_list) == 1 else QgsGeometry.unaryUnion(geom_list)
                            f = QgsFeature()
                            f.setGeometry(union_geom)
                            
                            rec = group_to_record.get(group_name, {})
                            attrs = [layer_name, group_name]
                            for col in pivot_df.columns:
                                val = rec.get(col, None)
                                if pd.isna(val): val = None
                                elif isinstance(val, float): val = round(val, 4)
                                attrs.append(val)
                                
                            f.setAttributes(attrs)
                            feats.append(f)
                            cache_feats.append((QgsGeometry(union_geom), attrs))
                            
                        if progress.wasCanceled(): break
                        if feats:
                            pr.addFeatures(feats); lyr.updateExtents()
                            if sym_style == "Categorized": apply_categorized_style(lyr, sym_field)
                            else: apply_uniform_style(lyr)
                            
                            layers_to_export.append(("Report", lyr, "01_Pivot_Dashboard_Results"))
                            self.dock.precalculated_layers.append({
                                "category": "Report", "name": "01_Pivot_Dashboard_Results", "uri": f"{geom_str}?crs={current_crs}",
                                "fields": fields, "features": cache_feats, "symbology": sym_style, "sym_field": sym_field
                            })

                else:
                    report_groups = {}
                    for item in self.dock.current_geo_raw_data:
                        report_groups.setdefault(item['Type'], []).append(item)
                        
                    for ltype, items in report_groups.items():
                        if not items: continue
                        
                        geom_str = get_geom_uri(ltype)
                        
                        lyr = QgsVectorLayer(f"{geom_str}?crs={current_crs}", f"[Report] All {geom_str}s", "memory")
                        pr = lyr.dataProvider()
                        
                        fields = [QgsField("Layer", QVariant.String), QgsField("Group", QVariant.String), QgsField("Secondary", QVariant.String), QgsField("Zone", QVariant.String), QgsField("Threshold_m", QVariant.Double)]
                        for df in dynamic_fields:
                            fields.append(QgsField(df, QVariant.String))
                            
                        if ltype == QGS_WKB_POLYGON: fields.append(QgsField("Area (ha)", QVariant.Double))
                        elif ltype == QGS_WKB_LINE: fields.append(QgsField("Length (m)", QVariant.Double))
                        else: fields.append(QgsField("Count", QVariant.Int))
                        pr.addAttributes(fields)
                        lyr.updateFields()

                        dissolved = {}
                        for it in items:
                            key = (it['Layer'], it['Group'], it.get('Secondary', ''), it.get('Zone', 'AOI'), it.get('feature_attrs', {}).get('Threshold (m)', 0.0))
                            if key not in dissolved:
                                dissolved[key] = {'geoms': [], 'attrs': it.get('feature_attrs', {})}
                            dissolved[key]['geoms'].append(it['Geometry'])

                        feats = []
                        cache_feats = []
                        for (layer_name, group_name, secondary_val, zone_val, thresh_val), grp_data in dissolved.items():
                            geom_list = grp_data['geoms']
                            f_attrs = grp_data['attrs']
                            
                            step += len(geom_list)
                            if step % 10 == 0: 
                                progress.setValue(min(step, total_items))
                                QApplication.processEvents()
                            if progress.wasCanceled(): break
                            
                            union_geom = geom_list[0] if len(geom_list) == 1 else QgsGeometry.unaryUnion(geom_list)
                            f = QgsFeature()
                            f.setGeometry(union_geom)
                            
                            attrs = [layer_name, group_name, secondary_val, zone_val, thresh_val]
                            for d_field in dynamic_fields:
                                attrs.append(str(f_attrs.get(d_field, '')))
                                
                            if ltype == QGS_WKB_POLYGON: attrs.append(round(union_geom.area()/10000.0, 2))
                            elif ltype == QGS_WKB_LINE: attrs.append(round(union_geom.length(), 2))
                            else: attrs.append(len(geom_list)) 
                            
                            f.setAttributes(attrs)
                            feats.append(f)
                            cache_feats.append((QgsGeometry(union_geom), attrs))
                            
                        if progress.wasCanceled(): break
                        if feats:
                            pr.addFeatures(feats); lyr.updateExtents()
                            
                            if sym_style == "Categorized": apply_categorized_style(lyr, sym_field)
                            else: apply_uniform_style(lyr)
                            
                            layers_to_export.append(("Report", lyr, f"01_Report_All_{geom_str}s"))
                            self.dock.precalculated_layers.append({
                                "category": "Report", "name": f"01_Report_All_{geom_str}s", "uri": f"{geom_str}?crs={current_crs}",
                                "fields": fields, "features": cache_feats, "symbology": sym_style, "sym_field": sym_field
                            })

            if inc_sensitive and not progress.wasCanceled():
                # --- THE FIX: Aggressive truth-check for Sensitive Alerts ---
                alert_items = []
                for it in self.dock.current_geo_raw_data:
                    alert_val = str(it.get('feature_attrs', {}).get('Sensitive Alert', '')).upper()
                    if alert_val == 'YES' or alert_val == 'TRUE':
                        alert_items.append(it)
                        
                if alert_items:
                    alert_groups = {}
                    for item in alert_items:
                        alert_groups.setdefault(item['Type'], []).append(item)
                        
                    for ltype, items in alert_groups.items():
                        if not items: continue
                        geom_str = get_geom_uri(ltype)
                        
                        lyr = QgsVectorLayer(f"{geom_str}?crs={current_crs}", f"[Alerts] Sensitive {geom_str}s", "memory")
                        pr = lyr.dataProvider()
                        
                        fields = [QgsField("Layer", QVariant.String), QgsField("Group", QVariant.String), QgsField("Secondary", QVariant.String), QgsField("Threshold_m", QVariant.Double)]
                        for df in dynamic_fields: fields.append(QgsField(df, QVariant.String))
                        pr.addAttributes(fields)
                        lyr.updateFields()
                        
                        dissolved = {}
                        for it in items:
                            key = (it['Layer'], it['Group'], it.get('Secondary', ''), it.get('feature_attrs', {}).get('Threshold (m)', 0.0))
                            if key not in dissolved:
                                dissolved[key] = {'geoms': [], 'attrs': it.get('feature_attrs', {})}
                            dissolved[key]['geoms'].append(it['Geometry'])
                            
                        feats = []
                        cache_feats = []
                        for (layer_name, group_name, secondary_val, thresh_val), grp_data in dissolved.items():
                            geom_list = grp_data['geoms']
                            f_attrs = grp_data['attrs']
                            
                            union_geom = geom_list[0] if len(geom_list) == 1 else QgsGeometry.unaryUnion(geom_list)
                            f = QgsFeature()
                            f.setGeometry(union_geom)
                            
                            attrs = [layer_name, group_name, secondary_val, thresh_val]
                            for d_field in dynamic_fields: attrs.append(str(f_attrs.get(d_field, '')))
                            f.setAttributes(attrs)
                            feats.append(f)
                            cache_feats.append((QgsGeometry(union_geom), attrs))
                            
                        if feats:
                            pr.addFeatures(feats); lyr.updateExtents()
                            apply_alert_style(lyr)
                            layers_to_export.append(("Sensitive", lyr, f"02_Alerts_{geom_str}s"))
                            self.dock.precalculated_layers.append({
                                "category": "Sensitive", "name": f"02_Alerts_{geom_str}s", "uri": f"{geom_str}?crs={current_crs}",
                                "fields": fields, "features": cache_feats, "symbology": "Alert", "sym_field": ""
                            })

            progress.setValue(total_items)

            if inc_aoi and self.dock.current_geo_aoi and not progress.wasCanceled():
                aoi_lyr = QgsVectorLayer(f"MultiPolygon?crs={current_crs}", aoi_name, "memory")
                pr = aoi_lyr.dataProvider()
                fields = [QgsField("Name", QVariant.String)]
                pr.addAttributes(fields)
                aoi_lyr.updateFields()
                f = QgsFeature()
                f.setGeometry(QgsGeometry(self.dock.current_geo_aoi))
                f.setAttributes([aoi_name])
                pr.addFeature(f); aoi_lyr.updateExtents()
                
                apply_aoi_style(aoi_lyr)
                layers_to_export.append(("AOI", aoi_lyr, "00_AOI_Polygon"))
                self.dock.precalculated_layers.append({
                    "category": "AOI", "name": "00_AOI_Polygon", "uri": f"MultiPolygon?crs={current_crs}",
                    "fields": fields, "features": [(QgsGeometry(self.dock.current_geo_aoi), [aoi_name])]
                })
                
            if inc_buffered_aoi and self.dock.current_geo_aoi_buffered and not progress.wasCanceled():
                main_rings = [b for b in self.dock.current_geo_aoi_buffered if b[3] == "Main"]
                custom_rings = [b for b in self.dock.current_geo_aoi_buffered if b[3] == "Custom"]

                if main_rings:
                    buf_lyr = QgsVectorLayer(f"MultiPolygon?crs={current_crs}", f"{aoi_name} (Main Buffers)", "memory")
                    pr = buf_lyr.dataProvider()
                    fields = [QgsField("Name", QVariant.String), QgsField("Buffer_m", QVariant.Double)]
                    pr.addAttributes(fields)
                    buf_lyr.updateFields()
                    
                    feats = []
                    cache_feats = []
                    for b_name, b_geom, b_dist, z_type in main_rings:
                        f = QgsFeature()
                        f.setGeometry(QgsGeometry(b_geom))
                        attrs = [f"{aoi_name} ({b_name})", b_dist]
                        f.setAttributes(attrs)
                        feats.append(f)
                        cache_feats.append((QgsGeometry(b_geom), attrs))
                        
                    pr.addFeatures(feats); buf_lyr.updateExtents()
                    apply_unified_buffer_style(buf_lyr, "50,150,255", "") 
                    
                    layers_to_export.append(("Buffered_AOI", buf_lyr, "00_Buffered_Main_All"))
                    self.dock.precalculated_layers.append({
                        "category": "Buffered_Main", "name": "00_Buffered_Main_All", "uri": f"MultiPolygon?crs={current_crs}",
                        "fields": fields, "features": cache_feats
                    })

                if custom_rings:
                    buf_lyr = QgsVectorLayer(f"MultiPolygon?crs={current_crs}", f"{aoi_name} (Custom Buffers)", "memory")
                    pr = buf_lyr.dataProvider()
                    fields = [QgsField("Name", QVariant.String), QgsField("Buffer_m", QVariant.Double)]
                    pr.addAttributes(fields)
                    buf_lyr.updateFields()
                    
                    feats = []
                    cache_feats = []
                    for b_name, b_geom, b_dist, z_type in custom_rings:
                        f = QgsFeature()
                        f.setGeometry(QgsGeometry(b_geom))
                        attrs = [f"{aoi_name} ({b_name})", b_dist]
                        f.setAttributes(attrs)
                        feats.append(f)
                        cache_feats.append((QgsGeometry(b_geom), attrs))
                        
                    pr.addFeatures(feats); buf_lyr.updateExtents()
                    apply_unified_buffer_style(buf_lyr, "150,50,255", "C") 
                    
                    layers_to_export.append(("Buffered_AOI", buf_lyr, "00_Buffered_Custom_All"))
                    self.dock.precalculated_layers.append({
                        "category": "Buffered_Custom", "name": "00_Buffered_Custom_All", "uri": f"MultiPolygon?crs={current_crs}",
                        "fields": fields, "features": cache_feats
                    })

            if progress.wasCanceled():
                self.dock.log_message("Spatial Generation Canceled by User.", True)
                self.dock.precalculated_layers = []
                return

            if path and layers_to_export:
                options = QgsVectorFileWriter.SaveVectorOptions()
                options.driverName = "GPKG"
                for i, (grp, lyr, name) in enumerate(layers_to_export):
                    options.layerName = name
                    options.actionOnExistingFile = QGS_ACTION_OVERWRITE_FILE if i == 0 else QGS_ACTION_OVERWRITE_LAYER
                    err = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, path, QgsProject.instance().transformContext(), options)
                self.dock.log_message(f"Successfully saved Geodata to: {path}")

            if load_temp and layers_to_export:
                root = QgsProject.instance().layerTreeRoot()
                ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                main_group = root.insertGroup(0, f"Spatial Results {ts}")
                self.dock.last_geo_group = main_group 

                raw_group = None
                rep_group = None
                alert_group = None

                for grp, lyr, name in layers_to_export:
                    QgsProject.instance().addMapLayer(lyr, False) 
                    if grp == "AOI" or grp == "Buffered_AOI": main_group.addLayer(lyr)
                    elif grp == "Sensitive":
                        if not alert_group: alert_group = main_group.addGroup("⚠️ Sensitive Alerts")
                        alert_group.addLayer(lyr)
                    elif grp == "Raw":
                        if not raw_group: raw_group = main_group.addGroup("Raw Geometries")
                        raw_group.addLayer(lyr)
                    elif grp == "Report":
                        if not rep_group: rep_group = main_group.addGroup("Query Report (Dissolved)")
                        rep_group.addLayer(lyr)
                
                self.dock.toggle_canvas_btn.setEnabled(True)
                self.dock.toggle_canvas_btn.setText("👁️ Toggle Canvas Layers")
                self.dock.toggle_canvas_btn.setChecked(True)
                self.dock.iface.mapCanvas().refresh() 
                self.dock.log_message(f"Successfully loaded temporary layers to Map Canvas.")
                
        except Exception as e:
            self.dock.log_message(f"Geodata Generation Error: {str(e)}", True)
        finally:
            progress.close()
            QApplication.restoreOverrideCursor()