def classFactory(iface):
    """Load the plugin class."""
    from .main import SpatialPivotPlugin
    return SpatialPivotPlugin(iface)