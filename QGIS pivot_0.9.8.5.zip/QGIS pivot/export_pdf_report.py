import datetime
import math
import os
import re
import pandas as pd
from qgis.PyQt.QtWidgets import QFileDialog, QApplication, QInputDialog
from qgis.PyQt.QtCore import Qt, QVariant, QEventLoop, QTimer
from qgis.PyQt.QtGui import QFont, QColor
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsLayoutItemPage, QgsLayoutSize, QgsLayoutPoint,
    QgsLayoutItemMap, QgsLayoutItemLegend, QgsLayoutItemScaleBar,
    QgsLayoutItemLabel, QgsLayoutFrame, QgsLayoutMultiFrame,
    QgsLayoutItemManualTable, QgsLayoutTableColumn, QgsTableCell,
    QgsLayoutExporter, QgsRasterLayer, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsUnitTypes, QgsRectangle, QgsField, QgsCoordinateReferenceSystem, QgsTextFormat,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFillSymbol,
    QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QgsSimpleLineCallout,
    QgsTextBufferSettings, QgsLineSymbol, QgsLayoutTableStyle, QgsLayoutTable
)

# Using our robust compatibility enums
from .compat import (
    QLINEEDIT_NORMAL, QGS_WKB_POLYGON, QGS_WKB_LINE, QGS_WKB_POINT, QT_WAIT_CURSOR,
    QGSLAYOUTTABLE_ALLFRAMES, QGSLAYOUTMULTIFRAME_USEEXISTINGFRAMES,
    QGSRENDERCONTEXT_TEXTFORMATALWAYSTEXT
)
from .symbology import apply_aoi_style, apply_unified_buffer_style, apply_alert_style, apply_uniform_style


class ReportGenerator:
    @staticmethod
    def clean_and_truncate(df, dock=None):
        """Constructs new header names from scratch based on data values."""
        clean_df = df.copy()
        
        # Flatten MultiIndex if it exists
        if isinstance(clean_df.columns, pd.MultiIndex):
            clean_df.columns = ['_'.join(map(str, col)).strip() for col in clean_df.columns.values]
            
        new_cols = []
        for original_c in clean_df.columns:
            c = str(original_c).strip()
            
            # 1. Standard Mapping for static columns
            mapping = {
                "Layer": "Layer",
                "Type": "Typ",
                "Group": "Feature",
                "Secondary": "SubF",
                "Sensitive Alert": "Alrt",
                "Threshold (m)": "Thr",
                "AOI Count": "AOIc",
                "AOI (ha)": "AOIa",
                "AOI Area (ha)": "AOIa",
                "AOI Length (m)": "AOIl"
            }
            
            if c in mapping:
                new_c = mapping[c]
            else:
                # 2. Build buffer names from scratch
                num_match = re.search(r'\d+', c)
                if num_match:
                    val = num_match.group()
                    
                    c_lower = c.lower()
                    
                    # Determine metric suffix
                    if 'count' in c_lower or c_lower.endswith('c') or c_lower.endswith('mc'):
                        suffix = 'c'
                    elif 'area' in c_lower or 'ha' in c_lower or c_lower.endswith('a') or c_lower.endswith('ma'):
                        suffix = 'a'
                    elif 'length' in c_lower or '(m)' in c_lower or c_lower.endswith('l') or c_lower.endswith('ml'):
                        suffix = 'l'
                    else:
                        suffix = ''
                    
                    # Prefix 'M' if it's a main buffer, otherwise just number + suffix
                    if 'main' in c_lower:
                        new_c = f"M{val}{suffix}"
                    else:
                        new_c = f"{val}{suffix}"
                else:
                    new_c = c # Fallback if absolutely no numbers exist
                
            new_cols.append(new_c)
            
        clean_df.columns = new_cols
        
        if dock:
            dock.log_message(f"Successfully mapped columns to: {new_cols}")
        
        if "Alrt" in clean_df.columns:
            clean_df["Alrt"] = clean_df["Alrt"].replace("YES", "⚠️YES")
            
        for col in clean_df.columns:
            clean_df[col] = clean_df[col].apply(lambda x: "" if pd.isna(x) else str(x))
            if col in ['Layer']: clean_df[col] = clean_df[col].apply(lambda x: x[:14] + '..' if len(x) > 16 else x)
            elif col in ['Feature']: clean_df[col] = clean_df[col].apply(lambda x: x[:35] + '..' if len(x) > 37 else x)
            elif col in ['SubF']: clean_df[col] = clean_df[col].apply(lambda x: x[:10] + '..' if len(x) > 12 else x)
            else: clean_df[col] = clean_df[col].apply(lambda x: x.rstrip('0').rstrip('.') if '.' in x and x.endswith('0') else x)
                
        return clean_df

    @staticmethod
    def export_pdf_report(dock, df):
        if df is None or df.empty:
            return dock.log_message("No data available to generate a PDF report.", True)

        # --- THE FIX: GRAB SAVED TITLE DIRECTLY FROM WIDGET ---
        default_title = "Spatial Pivot Query Report"
        if dock and hasattr(dock, 'aoi_widget') and getattr(dock.aoi_widget, 'current_aoi_title', None):
            default_title = str(dock.aoi_widget.current_aoi_title)
        
        header_text, ok = QInputDialog.getText(dock, "PDF Report Header", "Enter a title for the report:", QLINEEDIT_NORMAL, default_title)
        if not ok: return
        if not header_text.strip(): header_text = default_title

        pdf_path, _ = QFileDialog.getSaveFileName(dock, "Save PDF Report", f"{header_text.replace(' ', '_')}.pdf", "PDF Files (*.pdf)")
        if not pdf_path: return
        if not pdf_path.endswith('.pdf'): pdf_path += '.pdf'

        dock.log_message("Generating native GeoPDF report... (Building Layout Mathematically)")
        
        QApplication.setOverrideCursor(QT_WAIT_CURSOR)
        
        project = QgsProject.instance()
        temp_layers = []
        layout = None 

        try:
            layout = QgsPrintLayout(project)
            layout.setName("Temp_Spatial_Report_Layout")
            layout.initializeDefaults()
            project.layoutManager().addLayout(layout)
            
            page1 = layout.pageCollection().page(0)
            page1.setPageSize(QgsLayoutSize(420, 297, QgsUnitTypes.LayoutMillimeters))

            # 1. WMS LAYER
            wms_url = "crs=EPSG%3A3301&dpiMode=7&featureCount=10&format=image%2Fpng&layers=kaart_ht&styles&tilePixelRatio=0&url=https%3A%2F%2Fkaart.maaamet.ee%2Fwms%2Fhallkaart"
            wms_lyr = QgsRasterLayer(wms_url, "Maa-amet Hallkaart", "wms")
            if wms_lyr.isValid():
                project.addMapLayer(wms_lyr, False)
                temp_layers.append(wms_lyr)

            # 2. CUSTOM BUFFERS WITH DYNAMIC DARK-TO-LIGHT SYMBOLOGY
            custom_rings = [b for b in dock.current_geo_aoi_buffered if b[3] == "Custom"]
            if custom_rings:
                c_buf_lyr = QgsVectorLayer("MultiPolygon?crs=epsg:3301", "Custom Buffers", "memory")
                pr = c_buf_lyr.dataProvider()
                pr.addAttributes([QgsField("Buffer_m", QVariant.Double)])
                c_buf_lyr.updateFields()
                feats = []
                for b_name, b_geom, b_dist, z_type in custom_rings:
                    f = QgsFeature(); f.setGeometry(QgsGeometry(b_geom)); f.setAttributes([b_dist])
                    feats.append(f)
                pr.addFeatures(feats); c_buf_lyr.updateExtents()
                
                distances = sorted(list(set([f['Buffer_m'] for f in c_buf_lyr.getFeatures()])))
                categories = []
                for i, dist in enumerate(distances):
                    ratio = i / max(1, len(distances) - 1) if len(distances) > 1 else 0
                    r = int(90 + ratio * (235 - 90))
                    g = int(30 + ratio * (210 - 30))
                    b = int(140 + ratio * (255 - 140))
                    a = int(180 - ratio * (100))
                    
                    symbol = QgsFillSymbol.createSimple({
                        'color': f"{r},{g},{b},{a}", 
                        'outline_color': '90,90,90,255', 
                        'outline_width': '0.15'
                    })
                    category = QgsRendererCategory(dist, symbol, f"{dist} m")
                    categories.append(category)
                
                renderer = QgsCategorizedSymbolRenderer("Buffer_m", categories)
                c_buf_lyr.setRenderer(renderer)
                
                project.addMapLayer(c_buf_lyr, False); temp_layers.append(c_buf_lyr)

            # 3. MAIN BUFFERS
            main_rings = [b for b in dock.current_geo_aoi_buffered if b[3] == "Main"]
            if main_rings:
                m_buf_lyr = QgsVectorLayer("MultiPolygon?crs=epsg:3301", "Main Buffers", "memory")
                pr = m_buf_lyr.dataProvider()
                pr.addAttributes([QgsField("Buffer_m", QVariant.Double)])
                m_buf_lyr.updateFields()
                feats = []
                for b_name, b_geom, b_dist, z_type in main_rings:
                    f = QgsFeature(); f.setGeometry(QgsGeometry(b_geom)); f.setAttributes([b_dist])
                    feats.append(f)
                pr.addFeatures(feats); m_buf_lyr.updateExtents()
                apply_unified_buffer_style(m_buf_lyr, "50,150,255", "")
                project.addMapLayer(m_buf_lyr, False); temp_layers.append(m_buf_lyr)

            # 4. TARGET AOI
            aoi_lyr = None
            if dock.current_geo_aoi:
                aoi_lyr = QgsVectorLayer("MultiPolygon?crs=epsg:3301", "Target AOI", "memory")
                pr = aoi_lyr.dataProvider()
                f = QgsFeature(); f.setGeometry(QgsGeometry(dock.current_geo_aoi))
                pr.addFeature(f); aoi_lyr.updateExtents()
                apply_aoi_style(aoi_lyr)
                project.addMapLayer(aoi_lyr, False); temp_layers.append(aoi_lyr)

            # 5. RAW DATA INTERSECTS
            if dock.current_geo_raw_data:
                poly_feats, line_feats, pt_feats = [], [], []
                for item in dock.current_geo_raw_data:
                    f = QgsFeature()
                    f.setGeometry(QgsGeometry(item['Geometry']))
                    f.setAttributes([str(item['Group'])])
                    if item['Type'] == QGS_WKB_POLYGON: poly_feats.append(f)
                    elif item['Type'] == QGS_WKB_LINE: line_feats.append(f)
                    else: pt_feats.append(f)

                def build_rep_lyr(feats, geom_str, name):
                    if not feats: return None
                    lyr = QgsVectorLayer(f"{geom_str}?crs=epsg:3301", name, "memory")
                    pr = lyr.dataProvider()
                    pr.addAttributes([QgsField("Group", QVariant.String)])
                    lyr.updateFields()
                    pr.addFeatures(feats); lyr.updateExtents()
                    apply_uniform_style(lyr) 
                    project.addMapLayer(lyr, False)
                    return lyr

                rep_poly = build_rep_lyr(poly_feats, "MultiPolygon", "Intersect Results (Polygon)")
                rep_line = build_rep_lyr(line_feats, "MultiLineString", "Intersect Results (Line)")
                rep_pt = build_rep_lyr(pt_feats, "MultiPoint", "Intersect Results (Point)")
                if rep_poly: temp_layers.append(rep_poly)
                if rep_line: temp_layers.append(rep_line)
                if rep_pt: temp_layers.append(rep_pt)

            # 6. SENSITIVE ALERTS (True Geometries)
            if dock.current_geo_raw_data:
                poly_alerts, line_alerts, pt_alerts = [], [], []
                for item in dock.current_geo_raw_data:
                    if item.get('feature_attrs', {}).get('Sensitive Alert') == 'YES':
                        f = QgsFeature()
                        f.setGeometry(QgsGeometry(item['Geometry']))
                        f.setAttributes([str(item['Group'])])
                        if item['Type'] == QGS_WKB_POLYGON: poly_alerts.append(f)
                        elif item['Type'] == QGS_WKB_LINE: line_alerts.append(f)
                        else: pt_alerts.append(f)

                def build_alert_lyr(feats, geom_str, name):
                    if not feats: return None
                    lyr = QgsVectorLayer(f"{geom_str}?crs=epsg:3301", name, "memory")
                    pr = lyr.dataProvider()
                    pr.addAttributes([QgsField("Group", QVariant.String)])
                    lyr.updateFields()
                    pr.addFeatures(feats); lyr.updateExtents()
                    apply_alert_style(lyr)

                    pal_settings = QgsPalLayerSettings()
                    pal_settings.fieldName = "'⚠️ ' || \"Group\""
                    pal_settings.isExpression = True
                    
                    text_format = QgsTextFormat()
                    alert_font = QFont("Arial", 8, 75)
                    alert_font.setBold(True) 
                    text_format.setFont(alert_font)
                    text_format.setColor(QColor(220, 20, 60))
                    
                    bg_buffer = QgsTextBufferSettings()
                    bg_buffer.setEnabled(True)
                    bg_buffer.setSize(0.8)
                    bg_buffer.setColor(QColor(255, 255, 255, 220))
                    text_format.setBuffer(bg_buffer)
                    pal_settings.setFormat(text_format)
                    
                    callout = QgsSimpleLineCallout()
                    callout.setEnabled(True)
                    try:
                        line_sym = QgsLineSymbol.createSimple({'line_color': '220,20,60', 'line_width': '0.3'})
                        if hasattr(callout, 'setLineSymbol') and line_sym:
                            callout.setLineSymbol(line_sym)
                    except Exception:
                        pass
                        
                    pal_settings.setCallout(callout)
                    pal_settings.dist = 3.0
                    
                    labels = QgsVectorLayerSimpleLabeling(pal_settings)
                    lyr.setLabelsEnabled(True)
                    lyr.setLabeling(labels)

                    project.addMapLayer(lyr, False)
                    return lyr

                a_poly = build_alert_lyr(poly_alerts, "MultiPolygon", "Sensitive Alerts (Poly)")
                a_line = build_alert_lyr(line_alerts, "MultiLineString", "Sensitive Alerts (Line)")
                a_pt = build_alert_lyr(pt_alerts, "MultiPoint", "Sensitive Alerts (Point)")

                if a_poly: temp_layers.append(a_poly)
                if a_line: temp_layers.append(a_line)
                if a_pt: temp_layers.append(a_pt)

            draw_layers = list(reversed([l for l in temp_layers if l is not None]))

            # 7. PURE PYTHON MAP CREATION
            map_item = QgsLayoutItemMap(layout)
            layout.addLayoutItem(map_item)

            m_x, m_y = 15.0, 25.0
            m_w, m_h = 290.0, 250.0

            map_item.attemptMove(QgsLayoutPoint(m_x, m_y, QgsUnitTypes.LayoutMillimeters))
            map_item.attemptResize(QgsLayoutSize(m_w, m_h, QgsUnitTypes.LayoutMillimeters))

            map_item.setCrs(QgsCoordinateReferenceSystem("EPSG:3301"))
            map_item.setLayers(draw_layers)
            map_item.setKeepLayerSet(True)
            map_item.setFrameEnabled(True)
            
            bbox = QgsRectangle()
            for lyr in draw_layers:
                if "Hallkaart" not in lyr.name():
                    bbox.combineExtentWith(lyr.extent())
            
            center = bbox.center()
            target_scale = 150000
            extent_width_m = (m_w / 1000.0) * target_scale
            extent_height_m = (m_h / 1000.0) * target_scale
            half_w = extent_width_m / 2.0
            half_h = extent_height_m / 2.0

            exact_extent = QgsRectangle(
                center.x() - half_w, 
                center.y() - half_h, 
                center.x() + half_w, 
                center.y() + half_h
            )

            map_item.setExtent(exact_extent)
            map_item.attemptResize(QgsLayoutSize(m_w, m_h, QgsUnitTypes.LayoutMillimeters))

            # 8. ADD TITLE, LEGEND, SCALEBAR DYNAMICALLY
            title = QgsLayoutItemLabel(layout)
            layout.addLayoutItem(title)
            title.setText(f"{header_text}\nGenerated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
            title.setFont(title.font()) 
            title.attemptResize(QgsLayoutSize(200, 15, QgsUnitTypes.LayoutMillimeters))
            title.attemptMove(QgsLayoutPoint(m_x, max(5.0, m_y - 12.0), QgsUnitTypes.LayoutMillimeters))

            legend = QgsLayoutItemLegend(layout)
            layout.addLayoutItem(legend)
            legend.setLinkedMap(map_item)
            legend.setAutoUpdateModel(False) 
            model = legend.model()
            rootGroup = model.rootGroup()
            rootGroup.clear()
            for lyr in draw_layers: 
                if "Hallkaart" not in lyr.name(): rootGroup.addLayer(lyr)
            legend.attemptResize(QgsLayoutSize(90, m_h, QgsUnitTypes.LayoutMillimeters))
            legend.attemptMove(QgsLayoutPoint(m_x + m_w + 10.0, m_y, QgsUnitTypes.LayoutMillimeters))

            scalebar = QgsLayoutItemScaleBar(layout)
            layout.addLayoutItem(scalebar)
            scalebar.setLinkedMap(map_item)
            scalebar.setStyle('Line Ticks Middle')
            try:
                scalebar.setUnits(QgsUnitTypes.DistanceKilometers)
                scalebar.setUnitLabel("km")
            except AttributeError: pass
            scalebar.setNumberOfSegments(2)
            scalebar.setNumberOfSegmentsLeft(0)
            try: scalebar.applyDefaultSize()
            except AttributeError: pass
            scalebar.attemptMove(QgsLayoutPoint(m_x + 5.0, m_y + m_h - 15.0, QgsUnitTypes.LayoutMillimeters))

            # 9. PREPARE THE DATA TABLE
            df_print = ReportGenerator.clean_and_truncate(df, dock)
            
            table = QgsLayoutItemManualTable.create(layout)
            table.setCellMargin(1.0)
            
            content_font = QFont("Arial", 5) 
            header_font = QFont("Arial", 5, 75)
            header_font.setBold(True) 
            
            content_fmt = QgsTextFormat()
            content_fmt.setFont(content_font)
            content_fmt.setSize(5.5)
            content_fmt.setSizeUnit(QgsUnitTypes.RenderPoints)
            
            header_fmt = QgsTextFormat()
            header_fmt.setFont(header_font)
            header_fmt.setSize(5.5)
            header_fmt.setSizeUnit(QgsUnitTypes.RenderPoints)

            try: table.setHeaderFont(header_font)
            except AttributeError: pass
            
            try: table.setHeaderTextFormat(header_fmt)
            except AttributeError: pass

            try:
                header_style = QgsLayoutTableStyle()
                header_style.setFont(header_font)
                header_style.setTextFormat(header_fmt)
                table.setCellStyle(0, header_style)
            except Exception:
                pass

            try: table.setContentTextFormat(content_fmt)
            except AttributeError:
                try: table.setContentFont(content_font)
                except Exception: pass

            table.setHeaderMode(QGSLAYOUTTABLE_ALLFRAMES)

            columns = []
            for col_name in df_print.columns:
                col = QgsLayoutTableColumn()
                col.setHeading(str(col_name))
                columns.append(col)
            table.setHeaders(columns)
            
            try: table.setIncludeTableHeader(True)
            except AttributeError: pass
            
            columns_list = list(df_print.columns)
            alrt_idx = columns_list.index("Alrt") if "Alrt" in columns_list else -1

            contents = []
            for _, row in df_print.iterrows():
                table_row = []
                
                is_sensitive = False
                if alrt_idx >= 0:
                    val = str(row.iloc[alrt_idx])
                    if "YES" in val or "⚠️" in val:
                        is_sensitive = True

                for x in row:
                    cell = QgsTableCell(str(x))
                    if is_sensitive:
                        cell.setBackgroundColor(QColor(255, 230, 230))
                    table_row.append(cell)
                contents.append(table_row)
            
            table.setTableContents(contents)
            table.setGridStrokeWidth(0.3)
            
            table.setResizeMode(QGSLAYOUTMULTIFRAME_USEEXISTINGFRAMES)
            layout.addMultiFrame(table)

            page_width = page1.pageSize().width()
            page_height = page1.pageSize().height()
            
            rows_count = len(contents)
            rows_per_page = 45 
            needed_pages = max(1, math.ceil(rows_count / rows_per_page))

            side_margin = 15.0
            top_margin = 15.0
            bottom_margin = 15.0
            table_width = page_width - (2.0 * side_margin)
            table_height = page_height - top_margin - bottom_margin
            inter_table_spacing_mm = 10.0

            while layout.pageCollection().pageCount() < (needed_pages + 1):
                new_page = QgsLayoutItemPage(layout)
                new_page.setPageSize(page1.pageSize())
                layout.pageCollection().addPage(new_page)

            for i in range(needed_pages):
                target_page = layout.pageCollection().page(i + 1)
                page_y = target_page.pos().y()

                frame = QgsLayoutFrame(layout, table)
                layout.addLayoutItem(frame)
                frame.attemptResize(QgsLayoutSize(table_width, table_height, QgsUnitTypes.LayoutMillimeters))
                frame.attemptMove(QgsLayoutPoint(side_margin, page_y + top_margin, QgsUnitTypes.LayoutMillimeters))
                
                table.addFrame(frame)

            table.recalculateTableSize()

            # 10. WMS REFRESH & NETWORK WAIT
            map_item.refresh()
            loop = QEventLoop()
            QTimer.singleShot(4000, loop.quit)
            
            if hasattr(loop, 'exec'): loop.exec()
            else: loop.exec_()

            # 11. EXPORT
            exporter = QgsLayoutExporter(layout)
            settings = QgsLayoutExporter.PdfExportSettings()
            
            settings.dpi = 300
            settings.exportGeoPdf = True
            settings.appendGeoreference = True
            settings.exportMetadata = True
            settings.rasterizeWholeImage = False
            settings.forceVectorOutput = False
            settings.simplifyGeometries = False
            
            try: settings.textRenderFormat = QGSRENDERCONTEXT_TEXTFORMATALWAYSTEXT
            except AttributeError: pass

            result = exporter.exportToPdf(pdf_path, settings)
            
            if result == QgsLayoutExporter.Success:
                dock.log_message(f"Successfully generated Layout PDF report at: {pdf_path}")
            else:
                dock.log_message(f"Layout PDF export encountered an error (Code: {result})", True)

        except Exception as e:
            import traceback
            dock.log_message(f"Failed to generate Layout PDF: {str(e)}\n{traceback.format_exc()}", True)
        
        finally:
            if temp_layers:
                project.removeMapLayers([l.id() for l in temp_layers])
            
            if layout and layout in project.layoutManager().layouts():
                project.layoutManager().removeLayout(layout)
            
            QApplication.restoreOverrideCursor()