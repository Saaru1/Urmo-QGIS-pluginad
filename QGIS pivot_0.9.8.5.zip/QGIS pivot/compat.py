from qgis.PyQt.QtWidgets import QAbstractItemView, QTreeWidgetItem, QStyle, QDialogButtonBox, QMessageBox, QLineEdit, QHeaderView, QSizePolicy
from qgis.PyQt.QtCore import Qt, QEvent
from qgis.PyQt.QtGui import QKeySequence
from qgis.PyQt.QtPrintSupport import QPrinter
from qgis.core import QgsWkbTypes, QgsVectorFileWriter, QgsTask, QgsLayoutTable, QgsLayoutMultiFrame, QgsRenderContext

# --- QGIS 3 (PyQt5) / QGIS 4 (PyQt6) Universal Enum Translator ---
try:
    # PyQt6 / QGIS 4
    from qgis.PyQt.QtGui import QPageSize
    
    QT_HORIZONTAL = Qt.Orientation.Horizontal
    QT_VERTICAL = Qt.Orientation.Vertical
    QT_USER_ROLE = int(Qt.ItemDataRole.UserRole)
    QT_DISPLAY_ROLE = Qt.ItemDataRole.DisplayRole
    QT_WINDOW_MODAL = Qt.WindowModality.WindowModal
    QT_WAIT_CURSOR = Qt.CursorShape.WaitCursor
    
    QT_EXTENDED_SELECTION = QAbstractItemView.SelectionMode.ExtendedSelection
    QT_SINGLE_SELECTION = QAbstractItemView.SelectionMode.SingleSelection
    QT_SHOW_INDICATOR = QTreeWidgetItem.ChildIndicatorPolicy.ShowIndicator
    
    QT_LEFT_BUTTON = Qt.MouseButton.LeftButton
    QT_ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    QT_KEY_DELETE = Qt.Key.Key_Delete
    QT_KEY_BACKSPACE = Qt.Key.Key_Backspace
    QT_CUSTOM_CONTEXT_MENU = Qt.ContextMenuPolicy.CustomContextMenu
    QT_MATCH_EXACTLY = Qt.MatchFlag.MatchExactly
    
    QT_COPY_ACTION = Qt.DropAction.CopyAction
    QT_CHECKED = Qt.CheckState.Checked
    QT_UNCHECKED = Qt.CheckState.Unchecked
    
    QSTYLE_STATE_MOUSEOVER = QStyle.StateFlag.State_MouseOver
    QSTYLE_CE_ITEMVIEWITEM = QStyle.ControlElement.CE_ItemViewItem
    QEVENT_MOUSEBUTTONRELEASE = QEvent.Type.MouseButtonRelease
    QEVENT_KEYPRESS = QEvent.Type.KeyPress
    QKEYSEQUENCE_COPY = QKeySequence.StandardKey.Copy
    
    QGS_WKB_POLYGON = QgsWkbTypes.GeometryType.PolygonGeometry
    QGS_WKB_LINE = QgsWkbTypes.GeometryType.LineGeometry
    QGS_WKB_POINT = QgsWkbTypes.GeometryType.PointGeometry
    
    QGS_ACTION_OVERWRITE_FILE = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile
    QGS_ACTION_OVERWRITE_LAYER = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
    
    QDIALOG_BTN_OK = QDialogButtonBox.StandardButton.Ok
    QDIALOG_BTN_CANCEL = QDialogButtonBox.StandardButton.Cancel
    QDIALOG_BTN_SAVE = QDialogButtonBox.StandardButton.Save
    
    QGS_TASK_CANCEL = QgsTask.Flag.CanCancel
    
    QMESSAGEBOX_YES = QMessageBox.StandardButton.Yes
    QMESSAGEBOX_NO = QMessageBox.StandardButton.No
    
    QLINEEDIT_NORMAL = QLineEdit.EchoMode.Normal
    QT_ITEM_IS_EDITABLE = Qt.ItemFlag.ItemIsEditable
    
    QT_HEADER_STRETCH = QHeaderView.ResizeMode.Stretch

    QSIZEPOLICY_EXPANDING = QSizePolicy.Policy.Expanding
    QSIZEPOLICY_IGNORED = QSizePolicy.Policy.Ignored

    QT_BOTTOM_DOCK_WIDGET_AREA = Qt.DockWidgetArea.BottomDockWidgetArea
    QT_TOP_DOCK_WIDGET_AREA = Qt.DockWidgetArea.TopDockWidgetArea
    
    # Print & Layout Enums
    QPRINTER_HIGH_RES = QPrinter.PrinterMode.HighResolution
    QPRINTER_PDF_FORMAT = QPrinter.OutputFormat.PdfFormat
    QPRINTER_A4 = QPageSize(QPageSize.PageSizeId.A4)
    QGSLAYOUTTABLE_ALLFRAMES = QgsLayoutTable.HeaderMode.AllFrames
    QGSLAYOUTMULTIFRAME_USEEXISTINGFRAMES = QgsLayoutMultiFrame.ResizeMode.UseExistingFrames
    QGSRENDERCONTEXT_TEXTFORMATALWAYSTEXT = QgsRenderContext.TextRenderFormat.TextFormatAlwaysText

except AttributeError:
    # PyQt5 / QGIS 3
    QT_HORIZONTAL = Qt.Horizontal
    QT_VERTICAL = Qt.Vertical
    QT_USER_ROLE = int(Qt.UserRole)
    QT_DISPLAY_ROLE = Qt.DisplayRole
    QT_WINDOW_MODAL = Qt.WindowModal
    QT_WAIT_CURSOR = Qt.WaitCursor
    
    QT_EXTENDED_SELECTION = QAbstractItemView.ExtendedSelection
    QT_SINGLE_SELECTION = QAbstractItemView.SingleSelection
    QT_SHOW_INDICATOR = QTreeWidgetItem.ShowIndicator
    
    QT_LEFT_BUTTON = Qt.LeftButton
    QT_ALIGN_CENTER = Qt.AlignCenter
    QT_KEY_DELETE = Qt.Key_Delete
    QT_KEY_BACKSPACE = Qt.Key_Backspace
    QT_CUSTOM_CONTEXT_MENU = Qt.CustomContextMenu
    QT_MATCH_EXACTLY = Qt.MatchExactly
    
    QT_COPY_ACTION = Qt.CopyAction
    QT_CHECKED = Qt.Checked
    QT_UNCHECKED = Qt.Unchecked
    
    QSTYLE_STATE_MOUSEOVER = QStyle.State_MouseOver
    QSTYLE_CE_ITEMVIEWITEM = QStyle.CE_ItemViewItem
    QEVENT_MOUSEBUTTONRELEASE = QEvent.MouseButtonRelease
    QEVENT_KEYPRESS = QEvent.KeyPress
    QKEYSEQUENCE_COPY = QKeySequence.Copy
    
    QGS_WKB_POLYGON = QgsWkbTypes.PolygonGeometry
    QGS_WKB_LINE = QgsWkbTypes.LineGeometry
    QGS_WKB_POINT = QgsWkbTypes.PointGeometry
    
    QGS_ACTION_OVERWRITE_FILE = QgsVectorFileWriter.CreateOrOverwriteFile
    QGS_ACTION_OVERWRITE_LAYER = QgsVectorFileWriter.CreateOrOverwriteLayer
    
    QDIALOG_BTN_OK = QDialogButtonBox.Ok
    QDIALOG_BTN_CANCEL = QDialogButtonBox.Cancel
    QDIALOG_BTN_SAVE = QDialogButtonBox.Save
    
    QGS_TASK_CANCEL = QgsTask.CanCancel
    
    QMESSAGEBOX_YES = QMessageBox.Yes
    QMESSAGEBOX_NO = QMessageBox.No
    
    QLINEEDIT_NORMAL = QLineEdit.Normal
    QT_ITEM_IS_EDITABLE = Qt.ItemIsEditable
    
    QT_HEADER_STRETCH = QHeaderView.Stretch

    QSIZEPOLICY_EXPANDING = QSizePolicy.Expanding
    QSIZEPOLICY_IGNORED = QSizePolicy.Ignored

    QT_BOTTOM_DOCK_WIDGET_AREA = Qt.BottomDockWidgetArea
    QT_TOP_DOCK_WIDGET_AREA = Qt.TopDockWidgetArea
    
    # Print & Layout Enums
    QPRINTER_HIGH_RES = QPrinter.HighResolution
    QPRINTER_PDF_FORMAT = QPrinter.PdfFormat
    QPRINTER_A4 = QPrinter.A4
    QGSLAYOUTTABLE_ALLFRAMES = getattr(QgsLayoutTable, "AllFrames", 1)
    QGSLAYOUTMULTIFRAME_USEEXISTINGFRAMES = getattr(QgsLayoutMultiFrame, "UseExistingFrames", 0)
    QGSRENDERCONTEXT_TEXTFORMATALWAYSTEXT = getattr(QgsRenderContext, "TextFormatAlwaysText", 1)