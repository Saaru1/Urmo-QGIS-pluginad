import traceback
import re
import pandas as pd
from qgis.core import (QgsFeatureRequest, QgsWkbTypes, QgsSpatialIndex, QgsTask, 
                       QgsVectorLayer, QgsProject, QgsGeometry, QgsRectangle, 
                       QgsDistanceArea, QgsCoordinateTransform, QgsCoordinateReferenceSystem)

# --- QGIS 3 / QGIS 4 (PyQt6) Compatibility Block ---
try:
    QGS_TASK_CANCEL = QgsTask.Flag.CanCancel
    QGS_WKB_POLYGON = QgsWkbTypes.GeometryType.PolygonGeometry
    QGS_WKB_POINT = QgsWkbTypes.GeometryType.PointGeometry
    QGS_WKB_LINE = QgsWkbTypes.GeometryType.LineGeometry
except AttributeError:
    QGS_TASK_CANCEL = QgsTask.CanCancel
    QGS_WKB_POLYGON = QgsWkbTypes.PolygonGeometry
    QGS_WKB_POINT = QgsWkbTypes.PointGeometry
    QGS_WKB_LINE = QgsWkbTypes.LineGeometry
# ---------------------------------------------------

def _buffer_geom_to_meters(geom, layer_crs, distance, context):
    """Safely applies point/line buffering by temporarily projecting if needed."""
    if distance <= 0: return geom
    if layer_crs.isGeographic():
        proj_crs = QgsCoordinateReferenceSystem("EPSG:3857")
        xform_fwd = QgsCoordinateTransform(layer_crs, proj_crs, context)
        xform_rev = QgsCoordinateTransform(proj_crs, layer_crs, context)
        try:
            geom.transform(xform_fwd)
            geom = geom.buffer(distance, 5)
            geom.transform(xform_rev)
        except Exception:
            pass
    else:
        geom = geom.buffer(distance, 5)
    return geom

class PivotEngine:
    def __init__(self):
        self.ui_logger = None

    def set_logger(self, logger_func):
        self.ui_logger = logger_func

    def log(self, message, is_error=False):
        if self.ui_logger: self.ui_logger(message, is_error)
        else: print(message)

    def _load_layer_headless(self, layer_def):
        l_type = layer_def.get('type')
        uri = layer_def.get('uri')
        name = layer_def.get('name')
        
        if l_type == 'canvas': 
            lyr = QgsProject.instance().mapLayer(uri)
            if not lyr:
                layers = QgsProject.instance().mapLayersByName(name)
                if layers: return layers[0]
            return lyr
            
        elif l_type == 'local': 
            lyr = QgsVectorLayer(uri, name, "ogr")
            if not lyr.isValid():
                lyr = QgsVectorLayer(uri, name, "")
            return lyr
        elif l_type == 'wfs':
            crs_authid = QgsProject.instance().crs().authid() or 'EPSG:3301'
            wfs_uri = f"restrictToRequestBBOX='1' srsname='{crs_authid}' typename='{name}' url='{uri.split('?')[0]}'"
            return QgsVectorLayer(wfs_uri, name, "WFS")
        return None

    def run_pivot(self, base_layer_def, join_layer_defs, rows, cols, vals_dict, filters=None, show_totals=False, force_zeros=False, extent=None, aoi_geom=None, raw_data_cache=None, progress_cb=None, cancel_cb=None):
        try:
            if filters is None: filters = {}
                
            val_fields = list(vals_dict.keys())
            filter_fields = list(filters.keys())
            all_requested_fields = list(set(rows + cols + val_fields + filter_fields))
            
            cache_package = raw_data_cache if raw_data_cache is not None else {}
            
            base_fields = [f for f in all_requested_fields if not f.startswith("[")]
            actual_base_req = [f for f in base_fields if f != "Calculate area (ha)"]
            
            join_fields_map = {}
            for j_def in join_layer_defs:
                j_name = j_def['name']
                prefix = f"[{j_name}] "
                fields_for_this_join = [f.replace(prefix, "") for f in all_requested_fields if f.startswith(prefix)]
                if fields_for_this_join: join_fields_map[j_name] = fields_for_this_join

            base_filters = {k: v for k, v in filters.items() if not k.startswith("[")}
            join_filters = {k: v for k, v in filters.items() if k.startswith("[")}

            current_signature = {
                'base_filters': {k: tuple(v) if isinstance(v, list) else v for k, v in base_filters.items()},
                'join_filters': {k: tuple(v) if isinstance(v, list) else v for k, v in join_filters.items()},
                'base_fields': sorted(actual_base_req),
                'join_layers': {j['name']: sorted(join_fields_map.get(j['name'], [])) for j in join_layer_defs}
            }
            
            if cache_package.get('signature') != current_signature:
                if 'signature' in cache_package:
                    self.log("Configuration change detected. Invalidating stale cache safely...")
                cache_package.clear()
                cache_package['signature'] = current_signature
                
            base_features = cache_package.get('base_features', None)
            join_indexes = cache_package.get('join_indexes', {})
            
            transform_context = QgsProject.instance().transformContext()

            categorical_domains = {}
            if force_zeros:
                self.log("Extracting full categorical domains from source layers to force 0-value matrix logic...")
                def get_unique_vals(layer_def, field_name_raw):
                    lyr = self._load_layer_headless(layer_def)
                    if not lyr or not lyr.isValid(): return []
                    idx = lyr.fields().indexOf(field_name_raw)
                    if idx == -1: return []
                    try:
                        raw_vals = lyr.uniqueValues(idx)
                        return [str(v).strip() for v in raw_vals if v is not None and str(v).strip() not in ("NULL", "")]
                    except Exception as ex:
                        self.log(f"Warning: Could not fetch unique values for {field_name_raw}: {ex}", True)
                        return []

                for rc in set(rows + cols):
                    if rc == ' ': continue
                    if rc.startswith("["):
                        # Robust Regex to extract layer name and field name safely
                        m = re.match(r"^\[(.*?)\]\s+(.*)$", rc)
                        if m:
                            j_name = m.group(1)
                            f_name = m.group(2)
                            for jd in join_layer_defs:
                                if jd['name'] == j_name:
                                    categorical_domains[rc] = get_unique_vals(jd, f_name)
                                    break
                    else:
                        categorical_domains[rc] = get_unique_vals(base_layer_def, rc)

            if base_features is None:
                for j_def in join_layer_defs:
                    j_name = j_def['name']
                    prefix = f"[{j_name}] "
                    j_specific_filters = {k.replace(prefix, ""): v for k, v in join_filters.items() if k.startswith(prefix)}
                    
                    if j_specific_filters:
                        self.log(f"Pre-calculating BBOX constraints for Join Layer: <b>{j_name}</b>")
                        j_lyr = self._load_layer_headless(j_def)
                        if j_lyr and j_lyr.isValid():
                            j_req = QgsFeatureRequest().setSubsetOfAttributes([], j_lyr.fields())
                            expr_parts = []
                            for k, v_list in j_specific_filters.items():
                                if isinstance(v_list, list) and v_list:
                                    safe_vals = [str(val).replace("'", "''") for val in v_list]
                                    in_clause = ", ".join([f"'{sv}'" for sv in safe_vals])
                                    expr_parts.append(f"\"{k}\" IN ({in_clause})")
                                elif not isinstance(v_list, list):
                                    safe_v = str(v_list).replace("'", "''")
                                    expr_parts.append(f"\"{k}\" = '{safe_v}'")
                            if expr_parts:
                                j_req.setFilterExpression(" AND ".join(expr_parts))
                                
                            j_bbox = QgsRectangle()
                            for jf in j_lyr.getFeatures(j_req):
                                g = jf.geometry()
                                if g and not g.isEmpty():
                                    if j_bbox.isEmpty(): j_bbox = g.boundingBox()
                                    else: j_bbox.combineExtentWith(g.boundingBox())
                                    
                            if not j_bbox.isEmpty():
                                j_def['_precalc_bbox'] = j_bbox
                                j_def['_precalc_crs'] = j_lyr.crs()

            if base_features is not None and len(base_features) > 0:
                first_f = base_features[0]
                try:
                    if not first_f.isValid():
                        self.log("Stale C++ pointers detected in memory. Re-fetching Base Layer securely...")
                        base_features = None
                except Exception:
                    base_features = None

                if base_features is not None:
                    for req_f in actual_base_req:
                        try:
                            _ = first_f.attribute(req_f)
                        except KeyError:
                            self.log("New filter field detected. Re-fetching Base Layer securely...")
                            base_features = None
                            break

            if base_features is None:
                self.log(f"Downloading/Extracting Base Layer: <b>{base_layer_def['name']}</b>")
                base_layer = self._load_layer_headless(base_layer_def)
                if not base_layer or not base_layer.isValid(): raise Exception(f"Failed to load Base Layer: {base_layer_def['name']}")
                
                request = QgsFeatureRequest().setSubsetOfAttributes(actual_base_req, base_layer.fields())
                base_crs = base_layer.crs()
                
                master_base_bbox = QgsRectangle()
                restrict_bbox = False
                
                for j_def in join_layer_defs:
                    if '_precalc_bbox' in j_def:
                        j_bbox = j_def['_precalc_bbox']
                        j_crs = j_def['_precalc_crs']
                        if j_crs != base_crs:
                            xform = QgsCoordinateTransform(j_crs, base_crs, transform_context)
                            j_bbox = xform.transformBoundingBox(j_bbox)
                        if master_base_bbox.isEmpty():
                            master_base_bbox = QgsRectangle(j_bbox)
                        else:
                            master_base_bbox.combineExtentWith(j_bbox)
                        restrict_bbox = True
                
                if restrict_bbox and not master_base_bbox.isEmpty():
                    self.log("Applying strict pre-calculated BBOX limits to Base Layer for maximum processing performance.")
                    if aoi_geom:
                        master_base_bbox = master_base_bbox.intersect(aoi_geom.boundingBox())
                    elif extent:
                        master_base_bbox = master_base_bbox.intersect(extent)
                    request.setFilterRect(master_base_bbox)
                elif aoi_geom: 
                    request.setFilterRect(aoi_geom.boundingBox())
                elif extent is not None: 
                    request.setFilterRect(extent)
                
                if base_filters:
                    expr_parts = []
                    for k, v_list in base_filters.items():
                        if isinstance(v_list, list) and v_list:
                            safe_vals = [str(val).replace("'", "''") for val in v_list]
                            in_clause = ", ".join([f"'{sv}'" for sv in safe_vals])
                            expr_parts.append(f"\"{k}\" IN ({in_clause})")
                        elif not isinstance(v_list, list):
                            safe_v = str(v_list).replace("'", "''")
                            expr_parts.append(f"\"{k}\" = '{safe_v}'")
                    if expr_parts:
                        request.setFilterExpression(" AND ".join(expr_parts))
                
                base_features = list(base_layer.getFeatures(request))
                cache_package['base_crs'] = base_crs
                cache_package['base_features'] = base_features
            else:
                base_crs = cache_package.get('base_crs', QgsProject.instance().crs())

            if not base_features:
                if not force_zeros:
                    return pd.DataFrame(), cache_package, []

            base_bbox = QgsRectangle()
            if base_features:
                for f in base_features:
                    geom = f.geometry()
                    if geom and not geom.isEmpty():
                        if base_bbox.isEmpty():
                            base_bbox = geom.boundingBox()
                        else:
                            base_bbox.combineExtentWith(geom.boundingBox())

            for j_def in join_layer_defs:
                j_name = j_def['name']
                if j_name in join_fields_map and j_name not in join_indexes:
                    self.log(f"Downloading/Indexing Join Layer: <b>{j_name}</b>")
                    j_lyr = self._load_layer_headless(j_def)
                    if not j_lyr or not j_lyr.isValid():
                        self.log(f"Warning: Could not load join layer {j_name}", True); continue
                        
                    j_crs = j_lyr.crs()
                    j_to_base_transform = None
                    
                    if j_crs.isValid() and base_crs.isValid() and j_crs != base_crs:
                        j_to_base_transform = QgsCoordinateTransform(j_crs, base_crs, transform_context)
                        base_to_j_transform = QgsCoordinateTransform(base_crs, j_crs, transform_context)
                        j_bbox = base_to_j_transform.transformBoundingBox(base_bbox) if not base_bbox.isEmpty() else QgsRectangle()
                    else:
                        j_bbox = base_bbox
                        
                    idx = QgsSpatialIndex()
                    f_dict = {}
                    j_req = QgsFeatureRequest().setSubsetOfAttributes(join_fields_map[j_name], j_lyr.fields())
                    
                    if not j_bbox.isEmpty():
                        j_req.setFilterRect(j_bbox)
                    elif aoi_geom: 
                        j_req.setFilterRect(aoi_geom.boundingBox())
                    elif extent is not None: 
                        j_req.setFilterRect(extent)

                    j_specific_filters = {k.replace(f"[{j_name}] ", ""): v for k, v in join_filters.items() if k.startswith(f"[{j_name}] ")}
                    if j_specific_filters:
                        expr_parts = []
                        for k, v_list in j_specific_filters.items():
                            if isinstance(v_list, list) and v_list:
                                safe_vals = [str(val).replace("'", "''") for val in v_list]
                                in_clause = ", ".join([f"'{sv}'" for sv in safe_vals])
                                expr_parts.append(f"\"{k}\" IN ({in_clause})")
                            elif not isinstance(v_list, list):
                                safe_v = str(v_list).replace("'", "''")
                                expr_parts.append(f"\"{k}\" = '{safe_v}'")
                        if expr_parts:
                            j_req.setFilterExpression(" AND ".join(expr_parts))

                    j_pt_buf = j_def.get('pt_buffer', 10.0)
                    j_ln_buf = j_def.get('ln_buffer', 5.0)

                    for jf in j_lyr.getFeatures(j_req):
                        geom = jf.geometry()
                        if not geom or geom.isEmpty(): continue
                            
                        geom_type = geom.type()
                        if geom_type == QGS_WKB_POINT and not j_def.get('include_points', True): continue
                        if geom_type == QGS_WKB_LINE and not j_def.get('include_lines', True): continue
                        if geom_type == QGS_WKB_POLYGON and not j_def.get('include_polygons', True): continue

                        if geom_type == QGS_WKB_POINT:
                            geom = _buffer_geom_to_meters(geom, j_crs, j_pt_buf, transform_context)
                        elif geom_type == QGS_WKB_LINE:
                            geom = _buffer_geom_to_meters(geom, j_crs, j_ln_buf, transform_context)
                            
                        if j_to_base_transform:
                            try:
                                geom.transform(j_to_base_transform)
                            except: pass 
                        
                        jf.setGeometry(geom)
                        idx.addFeature(jf); f_dict[jf.id()] = jf
                        
                    join_indexes[j_name] = (idx, f_dict)
                    
            cache_package['join_indexes'] = join_indexes

            da = QgsDistanceArea()
            da.setSourceCrs(base_crs, transform_context)
            if base_crs.isGeographic():
                da.setEllipsoid(QgsProject.instance().ellipsoid() or 'WGS84')
            else:
                da.setEllipsoid('NONE')

            data = []
            raw_geodata_temp = [] 
            
            base_total = len(base_features) if base_features else 1
            b_interval = max(1, base_total // 100)
            
            b_pt_buf = base_layer_def.get('pt_buffer', 10.0)
            b_ln_buf = base_layer_def.get('ln_buffer', 5.0)

            if base_features:
                for i, feature in enumerate(base_features):
                    if cancel_cb and cancel_cb():
                        raise Exception("Task canceled by user.")

                    if progress_cb and i % b_interval == 0: progress_cb((i / base_total) * 100.0)
                        
                    geom = feature.geometry()
                    if not geom or geom.isEmpty(): continue
                    
                    geom_type = geom.type()
                    if geom_type == QGS_WKB_POINT and not base_layer_def.get('include_points', True): continue
                    if geom_type == QGS_WKB_LINE and not base_layer_def.get('include_lines', True): continue
                    if geom_type == QGS_WKB_POLYGON and not base_layer_def.get('include_polygons', True): continue

                    if geom_type == QGS_WKB_POINT:
                        geom = _buffer_geom_to_meters(geom, base_crs, b_pt_buf, transform_context)
                    elif geom_type == QGS_WKB_LINE:
                        geom = _buffer_geom_to_meters(geom, base_crs, b_ln_buf, transform_context)
                    
                    if not geom.isGeosValid(): 
                        geom = geom.buffer(0, 5) 
                        if geom.isNull() or geom.isEmpty(): continue
                    
                    if aoi_geom:
                        if not geom.intersects(aoi_geom): continue
                        geom = geom.intersection(aoi_geom)

                    base_attrs = {}
                    for f in base_fields:
                        base_attrs[f] = feature.attribute(f) if f != "Calculate area (ha)" else None
                    
                    pipeline_geoms = [(base_attrs, geom)]

                    for j_name in join_fields_map.keys():
                        if j_name not in join_indexes: continue
                        
                        j_idx, j_dict = join_indexes[j_name]
                        j_fields = join_fields_map[j_name]
                        next_pipeline = []

                        for current_attrs, current_geom in pipeline_geoms:
                            bbox = current_geom.boundingBox()
                            candidate_ids = j_idx.intersects(bbox)
                            
                            hits = []
                            unmatched_geom = QgsGeometry(current_geom) 
                            
                            for cid in candidate_ids:
                                if unmatched_geom.isNull() or unmatched_geom.isEmpty():
                                    break 
                                    
                                jf = j_dict[cid]
                                j_geom = jf.geometry()
                                
                                if not j_geom.isGeosValid(): 
                                    j_geom = j_geom.buffer(0, 5)
                                    if j_geom.isNull() or j_geom.isEmpty(): continue
                                
                                if unmatched_geom.intersects(j_geom):
                                    try:
                                        ix_geom = unmatched_geom.intersection(j_geom)
                                        if ix_geom and not ix_geom.isEmpty(): 
                                            
                                            ix_geom = ix_geom.buffer(0, 5)
                                            
                                            if ix_geom and not ix_geom.isEmpty() and ix_geom.type() == QGS_WKB_POLYGON: 
                                                hits.append((jf, ix_geom))
                                                
                                                unmatched_geom = unmatched_geom.difference(j_geom)
                                                if unmatched_geom and not unmatched_geom.isEmpty():
                                                    unmatched_geom = unmatched_geom.buffer(0, 5)

                                    except Exception:
                                        pass

                            if not hits:
                                new_attrs = current_attrs.copy()
                                for f in j_fields: new_attrs[f"[{j_name}] {f}"] = "Unmatched"
                                next_pipeline.append((new_attrs, current_geom))
                            else:
                                for jf, ix_geom in hits:
                                    new_attrs = current_attrs.copy()
                                    for f in j_fields: 
                                        val = jf.attribute(f)
                                        new_attrs[f"[{j_name}] {f}"] = str(val) if val is not None else "Unmatched"
                                    next_pipeline.append((new_attrs, ix_geom))
                                    
                                if unmatched_geom and not unmatched_geom.isNull() and not unmatched_geom.isEmpty():
                                    if unmatched_geom.type() == QGS_WKB_POLYGON:
                                        try:
                                            if base_crs.isGeographic():
                                                u_area = da.measureArea(unmatched_geom) / 10000.0
                                            else:
                                                u_area = unmatched_geom.area() / 10000.0
                                                
                                            if u_area > 0.0001: 
                                                unmatched_attrs = current_attrs.copy()
                                                for f in j_fields: unmatched_attrs[f"[{j_name}] {f}"] = "Unmatched"
                                                next_pipeline.append((unmatched_attrs, unmatched_geom))
                                        except Exception:
                                            pass

                        pipeline_geoms = next_pipeline

                    for final_attrs, final_geom in pipeline_geoms:
                        if "Calculate area (ha)" in final_attrs:
                            try:
                                if base_crs.isGeographic():
                                    area_sq_m = da.measureArea(final_geom)
                                else:
                                    area_sq_m = final_geom.area()
                                    
                                final_attrs["Calculate area (ha)"] = area_sq_m / 10000.0
                            except Exception:
                                final_attrs["Calculate area (ha)"] = 0.0
                                
                        data.append(final_attrs)
                        
                        raw_geodata_temp.append({
                            "Layer": base_layer_def['name'],
                            "Group": None, 
                            "Geometry": QgsGeometry(final_geom),
                            "Type": final_geom.type(),
                            "attrs": final_attrs 
                        })
                        
            if progress_cb: progress_cb(100.0) 

            df = pd.DataFrame(data)

            if not rows: df[' '] = 'All Data'; rows = [' ']
            
            for f_col, f_val in filters.items():
                if f_col in df.columns: 
                    if isinstance(f_val, list):
                        clean_vals = [str(v).strip() for v in f_val]
                        mask = df[f_col].astype(str).str.strip().isin(clean_vals)
                    else:
                        mask = df[f_col].astype(str).str.strip() == str(f_val).strip()
                    df = df[mask]

            if df.empty:
                if not force_zeros:
                    return pd.DataFrame(), cache_package, []
                else:
                    dummy = {c: 0.0 for c in df.columns if c in df.columns}
                    for r in rows: dummy[r] = 'Empty'
                    for c in cols: dummy[c] = 'Empty'
                    for v in val_fields: dummy[v] = 0.0
                    for f_col, f_val in filters.items():
                        if isinstance(f_val, list) and f_val:
                            dummy[f_col] = str(f_val[0]).strip()
                    df = pd.DataFrame([dummy])

            for r in rows:
                if r in df.columns and r != ' ':
                    df[r] = df[r].fillna("NULL").astype(str)
                    df[r] = df[r].replace({'nan': 'NULL', 'None': 'NULL', '': 'Empty'})
            for c in cols:
                if c in df.columns:
                    df[c] = df[c].fillna("NULL").astype(str)
                    df[c] = df[c].replace({'nan': 'NULL', 'None': 'NULL', '': 'Empty'})
            
            if force_zeros:
                for f_col, domains in categorical_domains.items():
                    if f_col in df.columns:
                        cats = list(set(domains + ["Empty", "NULL", "Unmatched"]))
                        df[f_col] = pd.Categorical(df[f_col].astype(str).str.strip(), categories=sorted(cats))

            valid_indices = set(df.index.tolist())
            raw_geodata = []
            for idx in valid_indices:
                try:
                    geo_obj = raw_geodata_temp[idx]
                    attrs = geo_obj['attrs']
                    
                    group_vals = []
                    if rows == [' ']:
                        group_vals = ['All Data']
                    else:
                        for r in rows:
                            val = attrs.get(r, 'NULL')
                            if pd.isna(val) or val is None or val == '': val = "NULL"
                            group_vals.append(str(val))
                            
                    geo_obj['Group'] = " | ".join(group_vals)
                    geo_obj['feature_attrs'] = {r: str(attrs.get(r, '')) for r in rows} if rows and rows != [' '] else {}
                    
                    del geo_obj['attrs'] 
                    raw_geodata.append(geo_obj)
                except IndexError:
                    pass

            agg_map = {"Count": "count", "Sum": "sum", "Mean": "mean", "Min": "min", "Max": "max"}
            pandas_aggfunc = {}
            
            for v_field, v_agg_list in vals_dict.items():
                funcs = []
                for v_agg in v_agg_list:
                    func = agg_map.get(v_agg, "sum")
                    if func in ["sum", "mean", "min", "max"]: 
                        df[v_field] = pd.to_numeric(df[v_field], errors='coerce').fillna(0).round(2)
                    if func not in funcs:
                        funcs.append(func)
                pandas_aggfunc[v_field] = funcs if len(funcs) > 1 else funcs[0]
            
            # --- THE FIX: Absolute guarantee against KeyError by filling unpopulated framework columns ---
            for rc in set(rows + cols):
                if rc != ' ' and rc not in df.columns:
                    df[rc] = 'Empty'

            pivot_df = pd.pivot_table(data=df, index=rows, columns=cols, values=val_fields, aggfunc=pandas_aggfunc, dropna=not force_zeros)

            if force_zeros:
                pivot_df = pivot_df.fillna(0)

            if show_totals and len(rows) > 1 and not pivot_df.empty:
                try:
                    grouped = df.groupby(rows[0])[val_fields].agg(pandas_aggfunc)
                    new_tuples = [(lbl,) + ("SUBTOTAL",) * (len(rows) - 1) for lbl in grouped.index]
                    grouped.index = pd.MultiIndex.from_tuples(new_tuples, names=rows)
                    pivot_df = pd.concat([pivot_df, grouped]).sort_index()
                except Exception as e:
                    self.log("Subtotals logically bypassed (Matrix is too flat)")

            if isinstance(pivot_df.columns, pd.MultiIndex):
                clean_cols = []
                for col in pivot_df.columns.values:
                    val_name = str(col[0])
                    categories = " | ".join(map(str, col[1:])) if len(col) > 1 else ""
                    clean_cols.append(f"{categories} ({val_name})" if categories else val_name)
                pivot_df.columns = clean_cols

            if show_totals and not pivot_df.empty:
                try:
                    numeric_cols = pivot_df.select_dtypes(include='number').columns
                    if not numeric_cols.empty:
                        if isinstance(pivot_df.index, pd.MultiIndex):
                            mask = ['SUBTOTAL' not in str(idx) for idx in pivot_df.index.get_level_values(-1)]
                            orig_rows = pivot_df[mask]
                            gt_idx = tuple(['GRAND TOTAL'] + [''] * (pivot_df.index.nlevels - 1))
                        else:
                            orig_rows = pivot_df
                            gt_idx = 'GRAND TOTAL'
                        pivot_df.loc[gt_idx, :] = orig_rows[numeric_cols].sum().values
                except Exception as e:
                    self.log("Grand totals logically bypassed")

            pivot_df.reset_index(inplace=True); pivot_df = pivot_df.round(2)
            
            for v_field, v_agg_list in vals_dict.items():
                if "Count" in v_agg_list:
                    for col in pivot_df.columns:
                        if v_field in str(col):
                            if len(v_agg_list) > 1 and "count" not in str(col).lower():
                                continue 
                            try:
                                pivot_df[col] = pivot_df[col].fillna(0).astype(int)
                            except:
                                pass
                        
            return pivot_df, cache_package, raw_geodata
            
        except Exception as e:
            self.log(f"Pivot Error: {str(e)}\n{traceback.format_exc()}", is_error=True)
            raise e

class PivotCalculationTask(QgsTask):
    def __init__(self, description, engine, kwargs, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.engine = engine
        self.kwargs = kwargs 
        self.callback = callback
        self.df_result = None
        self.raw_data = None
        self.raw_geodata = []
        self.exception = None

    def run(self):
        try:
            self.kwargs['progress_cb'] = self.setProgress 
            self.kwargs['cancel_cb'] = self.isCanceled 
            self.df_result, self.raw_data, self.raw_geodata = self.engine.run_pivot(**self.kwargs)
            return True
        except Exception as e:
            self.exception = traceback.format_exc()
            return False

    def finished(self, result):
        rg = getattr(self, 'raw_geodata', [])
        self.callback(self.df_result, self.raw_data, rg, self.exception)