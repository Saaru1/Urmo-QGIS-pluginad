import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from .dialog import PivotDockWidget

class SpatialPivotPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dockwidget = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'popup_button.png')
        self.action = QAction(QIcon(icon_path), "Spatial Pivot Dashboard", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        self.iface.addPluginToMenu("&Spatial Pivot", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&Spatial Pivot", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)

    def run(self):
        """Docks the dashboard to the bottom and handles splitting."""
        main_window = self.iface.mainWindow()
        
        if self.dockwidget is None:
            self.dockwidget = PivotDockWidget(self.iface)
            
            # Use BottomDockWidgetArea to share space with Attribute Table
            try:
                dock_area = Qt.DockWidgetArea.BottomDockWidgetArea
            except AttributeError:
                dock_area = Qt.BottomDockWidgetArea
                
            self.iface.addDockWidget(dock_area, self.dockwidget)
        
        self.dockwidget.show()
        self.dockwidget.raise_()
        
        # Request a decent height for the bottom panel
        try:
            main_window.resizeDocks([self.dockwidget], [350], Qt.Orientation.Vertical)
        except AttributeError:
            main_window.resizeDocks([self.dockwidget], [350], Qt.Vertical)