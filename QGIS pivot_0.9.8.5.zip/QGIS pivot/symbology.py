import random
from qgis.core import (QgsFillSymbol, QgsSingleSymbolRenderer, 
                       QgsCategorizedSymbolRenderer, QgsRendererCategory,
                       QgsMarkerSymbol, QgsLineSymbol,
                       QgsPalLayerSettings, QgsTextFormat, 
                       QgsTextBufferSettings, QgsVectorLayerSimpleLabeling)
from qgis.PyQt.QtGui import QColor

from .compat import QGS_WKB_POLYGON, QGS_WKB_LINE, QGS_WKB_POINT

def apply_alert_style(layer):
    geom_type = layer.geometryType()
    
    if geom_type == QGS_WKB_POLYGON:
        symbol = QgsFillSymbol.createSimple({
            'color': '255,0,0,100',
            'outline_color': '255,0,0,255',
            'outline_style': 'solid',
            'outline_width': '0.8'
        })
    elif geom_type == QGS_WKB_LINE:
        symbol = QgsLineSymbol.createSimple({
            'line_color': '255,0,0,255',
            'line_width': '1.2'
        })
    elif geom_type == QGS_WKB_POINT:
        symbol = QgsMarkerSymbol.createSimple({
            'color': '255,0,0,255',
            'outline_color': '150,0,0,255',
            'size': '4'
        })
    else: return
    
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    
    settings = QgsPalLayerSettings()
    settings.isExpression = True
    settings.fieldName = "'⚠️ ' || tostring(\"Group\")"
    
    text_format = QgsTextFormat()
    text_format.setSize(10)
    text_format.setColor(QColor(255, 0, 0, 255))
    font = text_format.font()
    font.setBold(True)
    text_format.setFont(font)
    
    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(1)
    buffer_settings.setColor(QColor("white"))
    text_format.setBuffer(buffer_settings)
    
    settings.setFormat(text_format)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()

def apply_aoi_style(layer):
    symbol = QgsFillSymbol.createSimple({
        'color': '0,0,0,0',
        'outline_color': '255,0,0,255',
        'outline_style': 'dash',
        'outline_width': '0.66'
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()

def apply_unified_buffer_style(layer, color_rgb, prefix):
    """Categorizes a merged multi-ring layer by its Buffer_m distance field."""
    field_name = "Buffer_m"
    idx = layer.fields().indexOf(field_name)
    if idx == -1: return

    # Sort distances descending so the largest buffer renders at the bottom
    unique_values = sorted([float(v) for v in layer.uniqueValues(idx) if v is not None], reverse=True)
    total_rings = len(unique_values)

    categories = []
    for ring_idx, val in enumerate(unique_values):
        if total_rings > 1: opacity = int(70 - (55 * (ring_idx / (total_rings - 1))))
        else: opacity = 50

        color_fill = f'{color_rgb},{opacity}'

        symbol = QgsFillSymbol.createSimple({
            'color': color_fill,
            'outline_color': f'{color_rgb},255',
            'outline_style': 'solid',
            'outline_width': '0.4'
        })
        category = QgsRendererCategory(val, symbol, f"{val} m")
        categories.append(category)

    if categories:
        renderer = QgsCategorizedSymbolRenderer(field_name, categories)
        layer.setRenderer(renderer)

    settings = QgsPalLayerSettings()
    settings.isExpression = True
    if prefix:
        settings.fieldName = f"'{prefix}: ' || tostring(\"Buffer_m\") || ' m'"
    else:
        settings.fieldName = "tostring(\"Buffer_m\") || ' m'"

    try: settings.placement = QgsPalLayerSettings.Horizontal
    except AttributeError: settings.placement = 0

    text_format = QgsTextFormat()
    text_format.setSize(9)
    text_format.setColor(QColor(*[int(x) for x in color_rgb.split(',')[:3]], 255))

    font = text_format.font()
    font.setBold(True)
    text_format.setFont(font)

    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(1)
    buffer_settings.setColor(QColor("white"))
    text_format.setBuffer(buffer_settings)

    settings.setFormat(text_format)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()

def get_random_color():
    return QColor.fromHsv(random.randint(0, 359), random.randint(130, 240), random.randint(150, 250))

def apply_labels(layer, field_name="Group"):
    settings = QgsPalLayerSettings()
    settings.fieldName = field_name
    settings.isExpression = False
    
    text_format = QgsTextFormat()
    text_format.setSize(9)
    
    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(1)
    buffer_settings.setColor(QColor("white"))
    text_format.setBuffer(buffer_settings)
    
    settings.setFormat(text_format)
    settings.scaleVisibility = True
    settings.minimumScale = 50000
    settings.maximumScale = 0
    
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)

def apply_uniform_style(layer):
    geom_type = layer.geometryType()
    color = QColor(41, 128, 185) 
    
    if geom_type == QGS_WKB_POLYGON:
        color.setAlpha(191) 
        color_str = f"{color.red()},{color.green()},{color.blue()},{color.alpha()}"
        symbol = QgsFillSymbol.createSimple({
            'color': color_str, 
            'outline_color': '30,30,30,255', 
            'outline_width': '0.2'
        })
    elif geom_type == QGS_WKB_LINE:
        color_str = f"{color.red()},{color.green()},{color.blue()},255"
        symbol = QgsLineSymbol.createSimple({
            'line_color': color_str, 
            'line_width': '0.6'
        })
    elif geom_type == QGS_WKB_POINT:
        color_str = f"{color.red()},{color.green()},{color.blue()},255"
        symbol = QgsMarkerSymbol.createSimple({
            'color': color_str, 
            'outline_color': '30,30,30,255', 
            'size': '3'
        })
    else: return

    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    apply_labels(layer) 
    layer.triggerRepaint()

def apply_categorized_style(layer, field_name="Group"):
    idx = layer.fields().indexOf(field_name)
    if idx == -1: return

    unique_values = layer.uniqueValues(idx)
    geom_type = layer.geometryType()
    
    categories = []
    for val in sorted(unique_values, key=lambda x: str(x)): 
        val_str = str(val) if val is not None else "NULL"
        color = get_random_color()
        
        if geom_type == QGS_WKB_POLYGON:
            color.setAlpha(191) 
            color_str = f"{color.red()},{color.green()},{color.blue()},{color.alpha()}"
            symbol = QgsFillSymbol.createSimple({
                'color': color_str, 
                'outline_color': '30,30,30,255', 
                'outline_width': '0.2'
            })
        elif geom_type == QGS_WKB_LINE:
            color_str = f"{color.red()},{color.green()},{color.blue()},255"
            symbol = QgsLineSymbol.createSimple({
                'line_color': color_str, 
                'line_width': '0.6'
            })
        elif geom_type == QGS_WKB_POINT:
            color_str = f"{color.red()},{color.green()},{color.blue()},255"
            symbol = QgsMarkerSymbol.createSimple({
                'color': color_str, 
                'outline_color': '30,30,30,255', 
                'size': '3'
            })
        else: continue 
            
        category = QgsRendererCategory(val, symbol, val_str)
        categories.append(category)

    if categories:
        renderer = QgsCategorizedSymbolRenderer(field_name, categories)
        layer.setRenderer(renderer)
        apply_labels(layer) 
        layer.triggerRepaint()