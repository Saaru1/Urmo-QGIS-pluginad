import os
import tempfile
import webbrowser
import json
import textwrap
from difflib import SequenceMatcher
from collections import defaultdict

from qgis.PyQt.QtWidgets import (QComboBox, QMessageBox, QInputDialog, QTableWidgetItem, 
                                 QApplication, QDialog, QVBoxLayout, QHBoxLayout, 
                                 QLabel, QSplitter, QListWidget, QListWidgetItem, 
                                 QDialogButtonBox, QAbstractItemView, QWidget, QPushButton, QProgressBar)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QCursor

# --- THE FIX: Added QgsDistanceArea to imports ---
from qgis.core import (QgsProject, QgsExpression, QgsExpressionContext, 
                       QgsExpressionContextUtils, QgsDistanceArea)
from qgis.gui import QgsExpressionBuilderDialog 

from .compat import (QT_HORIZONTAL, QLINEEDIT_NORMAL, QT_USER_ROLE, QT_WAIT_CURSOR, 
                     QT_ITEM_IS_EDITABLE, QDIALOG_BTN_OK, QDIALOG_BTN_CANCEL)

class TemporalSchemaMatcher:
    @staticmethod
    def get_similarity(a, b):
        if not a or not b: return 0.0
        c_a = str(a).lower().replace("_", "").replace(" ", "")
        c_b = str(b).lower().replace("_", "").replace(" ", "")
        return SequenceMatcher(None, c_a, c_b).ratio()

class TemporalProgressDialog(QDialog):
    def __init__(self, total_steps, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Crunching Temporal Data")
        self.setWindowFlags(Qt.Dialog | Qt.CustomizeWindowHint | Qt.WindowTitleHint)
        try:
            self.setWindowModality(Qt.WindowModality.ApplicationModal)
        except AttributeError:
            self.setWindowModality(Qt.ApplicationModal)
            
        self.resize(350, 100)
        self.is_canceled = False
        
        layout = QVBoxLayout(self)
        self.lbl = QLabel("Initializing data processors...")
        layout.addWidget(self.lbl)
        
        self.bar = QProgressBar()
        self.bar.setMaximum(total_steps)
        self.bar.setValue(0)
        layout.addWidget(self.bar)
        
        self.btn = QPushButton("Cancel")
        self.btn.clicked.connect(self.cancel)
        layout.addWidget(self.btn)
        
    def cancel(self):
        self.is_canceled = True
        self.lbl.setText("Aborting process safely... please wait.")
        self.btn.setEnabled(False)
        
    def update_progress(self, step, text):
        self.bar.setValue(step)
        self.lbl.setText(text)

class ChartConfigDialog(QDialog):
    def __init__(self, fields, parent_dock, parent=None):
        super().__init__(parent)
        self.dock = parent_dock
        self.setWindowTitle("Configure Temporal Dashboard")
        self.resize(650, 500)
        layout = QVBoxLayout(self)

        val_layout = QHBoxLayout()
        val_layout.addWidget(QLabel("<b>Numeric Value to Graph (Y-Axis):</b>"))
        self.val_combo = QComboBox()
        
        extended_fields = fields + ["[Auto-Calculate Area (ha)]"]
        self.val_combo.addItems(extended_fields)
        
        last_idx = self.val_combo.count() - 1
        font = self.val_combo.font()
        font.setItalic(True)
        try:
            self.val_combo.setItemData(last_idx, QColor("#7f8c8d"), Qt.ItemDataRole.ForegroundRole)
            self.val_combo.setItemData(last_idx, font, Qt.ItemDataRole.FontRole)
        except AttributeError:
            self.val_combo.setItemData(last_idx, QColor("#7f8c8d"), Qt.ForegroundRole)
            self.val_combo.setItemData(last_idx, font, Qt.FontRole)
        
        known_area_terms = ['pindala', 'ha', 'pindala_ha', 'area', 'area_ha', 'shape_area', '[auto-calculate area (ha)]']
        for i, f in enumerate(extended_fields):
            clean_f = f.lower().strip()
            if clean_f in known_area_terms or any(term in clean_f for term in known_area_terms):
                self.val_combo.setCurrentIndex(i)
                break

        val_layout.addWidget(self.val_combo, stretch=1)
        layout.addLayout(val_layout)
        
        layout.addSpacing(10)
        
        lbl_layout = QHBoxLayout()
        lbl_layout.addWidget(QLabel("<b>Categories to Graph:</b> Drag fields or build an Expression"))
        self.btn_expr = QPushButton("∑ Add QGIS Expression")
        self.btn_expr.setStyleSheet("background-color: #27ae60; color: white; font-weight: bold; border-radius: 3px; padding: 4px 8px;")
        self.btn_expr.clicked.connect(self.open_expression_builder)
        lbl_layout.addWidget(self.btn_expr)
        lbl_layout.addStretch()
        layout.addLayout(lbl_layout)

        split = QSplitter(QT_HORIZONTAL)

        left_widget = QWidget(); l_layout = QVBoxLayout(left_widget); l_layout.setContentsMargins(0,0,0,0)
        l_layout.addWidget(QLabel("Available Fields:"))
        self.avail_list = QListWidget()
        
        try:
            self.avail_list.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
            self.avail_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        except AttributeError:
            self.avail_list.setDragDropMode(QAbstractItemView.DragDrop)
            self.avail_list.setDefaultDropAction(Qt.MoveAction)
            
        self.avail_list.addItems(fields)
        l_layout.addWidget(self.avail_list)

        right_widget = QWidget(); r_layout = QVBoxLayout(right_widget); r_layout.setContentsMargins(0,0,0,0)
        r_layout.addWidget(QLabel("Fields/Expressions to Graph (Drop Here):"))
        self.selected_list = QListWidget()
        
        try:
            self.selected_list.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
            self.selected_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        except AttributeError:
            self.selected_list.setDragDropMode(QAbstractItemView.DragDrop)
            self.selected_list.setDefaultDropAction(Qt.MoveAction)
            
        self.selected_list.setStyleSheet("background-color: #f8f9fa; border: 2px dashed #bdc3c7;")
        r_layout.addWidget(self.selected_list)

        split.addWidget(left_widget)
        split.addWidget(right_widget)
        layout.addWidget(split, stretch=1)

        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def open_expression_builder(self):
        base_layer = self.dock.temporal_manager.active_layers[0] if self.dock.temporal_manager.active_layers else None
        dialog = QgsExpressionBuilderDialog(base_layer)
        dialog.setWindowTitle("Build Temporal Category Expression")
        if dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_():
            expr_text = dialog.expressionText().strip()
            if expr_text:
                item = QListWidgetItem(f"ƒ: {expr_text}")
                item.setBackground(QColor("#e8f8f5")) 
                self.selected_list.addItem(item)

    def get_selections(self):
        cats = [self.selected_list.item(i).text() for i in range(self.selected_list.count())]
        return self.val_combo.currentText(), cats

class TemporalChartGenerator:
    @staticmethod
    def build_plotly_dashboard(charts_data, title, y_axis_label, kpi_stats):
        kpi_html = ""
        for kpi in kpi_stats:
            kpi_html += f"""
            <div class="kpi-card">
                <div class="kpi-label">{kpi['label']}</div>
                <div class="kpi-value">{kpi['value']}</div>
            </div>"""

        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        local_plotly_path = os.path.join(plugin_dir, 'js', 'plotly.min.js').replace("\\", "/")
        
        html_template = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Temporal Dashboard</title>
            <script src="file:///{local_plotly_path}"></script>
            <script>if (typeof Plotly === 'undefined') document.write('<script src="https://cdn.plot.ly/plotly-2.27.0.min.js"><\\/script>');</script>
            <style>
                body {{ margin: 0; padding: 0; background-color: #f4f6f7; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }}
                #header {{ background-color: #2c3e50; color: white; padding: 15px 25px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); display: flex; justify-content: space-between; align-items: center; }}
                #header h2 {{ margin: 0; font-weight: 400; }}
                .btn-group {{ display: flex; gap: 10px; }}
                .btn-action {{ background-color: #27ae60; color: white; border: none; padding: 8px 15px; font-size: 14px; border-radius: 4px; cursor: pointer; font-weight: bold; transition: background 0.2s; }}
                .btn-action:hover {{ background-color: #2ecc71; }}
                .btn-print {{ background-color: #e67e22; }}
                .btn-print:hover {{ background-color: #d35400; }}
                
                #content-wrapper {{ padding: 25px; max-width: 1400px; margin: 0 auto; }}
                
                #kpi-row {{ display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap; }}
                .kpi-card {{ background: white; padding: 20px; border-radius: 8px; border-left: 5px solid #3498db; box-shadow: 0 2px 5px rgba(0,0,0,0.05); flex: 1; min-width: 200px; overflow: hidden; }}
                .kpi-value {{ font-size: 28px; font-weight: bold; color: #2c3e50; margin-top: 5px; word-wrap: break-word; }}
                .kpi-label {{ font-size: 13px; color: #7f8c8d; text-transform: uppercase; letter-spacing: 1px; font-weight: bold; }}
                
                #chart-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: 25px; margin-bottom: 40px; }}
                .chart-box {{ background: white; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); padding: 15px; height: 450px; }}
                
                .table-wrapper {{ background: white; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); padding: 20px; overflow-x: auto; }}
                .data-table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }}
                .data-table th {{ background-color: #ecf0f1; color: #2c3e50; padding: 12px; border-bottom: 2px solid #bdc3c7; }}
                .data-table td {{ padding: 10px 12px; border-bottom: 1px solid #ecf0f1; color: #34495e; }}
                .data-table tr:hover {{ background-color: #f9fbfc; }}
                
                @media print {{
                    @page {{ size: A3 landscape; margin: 15mm; }}
                    body {{ background-color: white; }}
                    #header .btn-group {{ display: none; }} 
                    #content-wrapper {{ max-width: 100%; padding: 0; }}
                    
                    .chart-box {{ box-shadow: none; border: 1px solid #ccc; page-break-inside: avoid; }}
                    .kpi-card {{ box-shadow: none; border: 1px solid #ccc; }}
                    
                    .table-wrapper {{ 
                        box-shadow: none; border: 1px solid #ccc; 
                        overflow: visible !important; overflow-x: visible !important; 
                        page-break-inside: auto; 
                    }}
                    .data-table {{ table-layout: fixed; width: 100%; }}
                    .data-table th, .data-table td {{
                        word-wrap: break-word; overflow-wrap: break-word;
                        white-space: normal !important; font-size: 11px; padding: 6px;
                    }}
                    tr {{ page-break-inside: avoid; page-break-after: auto; }}
                }}
            </style>
        </head>
        <body>
            <div id="header">
                <h2>📈 Spatial Pivot - Temporal Dashboard</h2>
                <div class="btn-group">
                    <button class="btn-action" onclick="downloadCSV()">💾 Export CSV</button>
                    <button class="btn-action btn-print" onclick="window.print()">🖨️ Save as PDF</button>
                </div>
            </div>
            
            <div id="content-wrapper">
                <div id="kpi-row">
                    {kpi_html}
                </div>
                <div id="chart-grid"></div>
                
                <h3 style="color: #2c3e50; margin-top: 20px;">Detailed Data View</h3>
                <div class="table-wrapper" id="table-container"></div>
            </div>

            <script>
                var charts = {json.dumps(charts_data)};
                var grid = document.getElementById('chart-grid');
                var tableContainer = document.getElementById('table-container');
                
                function downloadCSV() {{
                    let csv = "";
                    let timeSteps = charts[0].traces[0].x;
                    
                    charts.forEach(chart => {{
                        let cleanTitle = chart.title.replace(/<[^>]*>?/gm, ' ').trim(); 
                        csv += `"${{cleanTitle}}"\\n`;
                        csv += `Category,${{timeSteps.join(",")}}\\n`;
                        chart.traces.forEach(trace => {{
                            let safeName = '"' + String(trace.name).replace(/"/g, '""') + '"';
                            csv += `${{safeName}},${{trace.y.join(",")}}\\n`;
                        }});
                        csv += "\\n";
                    }});
                    
                    let blob = new Blob([csv], {{ type: 'text/csv;charset=utf-8;' }});
                    let link = document.createElement("a");
                    let url = URL.createObjectURL(blob);
                    link.setAttribute("href", url);
                    link.setAttribute("download", "Temporal_Data_Export.csv");
                    link.style.visibility = 'hidden';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }}

                function buildTable() {{
                    if (charts.length === 0) return;
                    let timeSteps = charts[0].traces[0].x;
                    
                    let tableHTML = '<table class="data-table"><thead><tr>';
                    tableHTML += '<th>Dataset / Category</th>';
                    timeSteps.forEach(ts => tableHTML += `<th>${{ts}}</th>`);
                    tableHTML += '</tr></thead><tbody>';
                    
                    charts.forEach(chart => {{
                        let cleanTitle = chart.title.replace(/<[^>]*>?/gm, ' ');
                        tableHTML += `<tr style="background-color: #fdfefe; font-weight: bold;"><td colspan="${{timeSteps.length + 1}}" style="color: #2980b9;">${{cleanTitle}}</td></tr>`;
                        
                        chart.traces.forEach(trace => {{
                            tableHTML += `<tr><td>${{trace.name}}</td>`;
                            trace.y.forEach(val => {{
                                tableHTML += `<td>${{val.toLocaleString(undefined, {{minimumFractionDigits: 1, maximumFractionDigits: 2}})}}</td>`;
                            }});
                            tableHTML += '</tr>';
                        }});
                    }});
                    
                    tableHTML += '</tbody></table>';
                    tableContainer.innerHTML = tableHTML;
                }}

                buildTable(); 

                charts.forEach(function(c, i) {{
                    var wrapper = document.createElement('div');
                    wrapper.className = 'chart-box';
                    wrapper.id = 'plot-' + i;
                    wrapper.title = c.full_title || c.title; 
                    grid.appendChild(wrapper);
                }});
                
                charts.forEach(function(c, i) {{
                    var layout = {{
                        title: {{ text: c.title, font: {{ size: 16 }} }},
                        margin: {{ t: 80, b: 40, l: 60, r: 20 }},
                        xaxis: {{ showgrid: false, fixedrange: true }},
                        yaxis: {{ title: '{y_axis_label}', zerolinecolor: '#eee', fixedrange: true }},
                        hovermode: 'x unified',
                        showlegend: true,
                        legend: {{ orientation: 'h', y: -0.2 }}
                    }};
                    var config = {{ 
                        responsive: true, 
                        displayModeBar: true, 
                        displaylogo: false,
                        toImageButtonOptions: {{ format: 'png', filename: 'temporal_chart', scale: 2 }}
                    }};
                    Plotly.newPlot('plot-' + i, c.traces, layout, config);
                }});
            </script>
        </body>
        </html>
        """
        
        temp_file = os.path.join(tempfile.gettempdir(), 'spatial_pivot_dashboard.html')
        with open(temp_file, 'w', encoding='utf-8') as f:
            f.write(html_template)
            
        webbrowser.open(f'file://{temp_file}')

class TemporalManager:
    def __init__(self, dock):
        self.dock = dock
        self.bind_ui()
        self.active_layers = []

    def bind_ui(self):
        if not hasattr(self.dock, 'timeline_list'): return 
        self.dock.timeline_list.layers_updated.connect(self.on_timeline_changed)
        self.dock.clear_temporal_btn.clicked.connect(self.clear_timeline)
        self.dock.auto_match_btn.clicked.connect(self.execute_auto_match)
        self.dock.generate_chart_btn.clicked.connect(self.prompt_and_generate_chart)

    def _get_clean_layer_name(self, text):
        return text.replace("🟢 [BASE] ", "").replace("🔵 ", "").strip()

    def _fetch_layers_from_timeline(self):
        layers = []
        for i in range(self.dock.timeline_list.count()):
            item = self.dock.timeline_list.item(i)
            layer_def = item.data(QT_USER_ROLE)
            
            if isinstance(layer_def, dict):
                lyr = self.dock.engine._load_layer_headless(layer_def)
                if lyr and lyr.isValid():
                    layers.append(lyr)
                else:
                    self.dock.log_message(f"Temporal Analysis failed to connect to layer: {layer_def.get('name')}", True)
            else:
                clean_name = self._get_clean_layer_name(item.text())
                matched_layers = QgsProject.instance().mapLayersByName(clean_name)
                if matched_layers: layers.append(matched_layers[0])
        return layers

    def clear_timeline(self):
        self.dock.timeline_list.clear()
        self.on_timeline_changed()

    def on_timeline_changed(self):
        QApplication.setOverrideCursor(QCursor(QT_WAIT_CURSOR))
        try:
            self.active_layers = self._fetch_layers_from_timeline()
            
            if len(self.active_layers) < 2:
                self.dock.schema_table.setRowCount(0)
                self.dock.schema_table.setColumnCount(0)
                self.dock.auto_match_btn.setEnabled(False)
                self.dock.generate_chart_btn.setEnabled(False)
                return

            self.dock.auto_match_btn.setEnabled(True)
            self.dock.generate_chart_btn.setEnabled(True)
            self.populate_schema_table()
        finally:
            QApplication.restoreOverrideCursor()

    def populate_schema_table(self):
        table = self.dock.schema_table
        table.clear()
        
        base_layer = self.active_layers[0]
        subsequent_layers = self.active_layers[1:]
        
        table.setColumnCount(len(self.active_layers))
        headers = [f"🟢 BASE: {base_layer.name()}"] + [f"🔵 {l.name()}" for l in subsequent_layers]
        table.setHorizontalHeaderLabels(headers)
        
        base_fields = [f.name() for f in base_layer.fields()]
        table.setRowCount(len(base_fields))
        
        for row_idx, field_name in enumerate(base_fields):
            item = QTableWidgetItem(field_name)
            item.setFlags(item.flags() & ~QT_ITEM_IS_EDITABLE) 
            item.setBackground(QColor(235, 245, 251)) 
            table.setItem(row_idx, 0, item)
            
            for col_offset, target_layer in enumerate(subsequent_layers):
                col_idx = col_offset + 1
                combo = QComboBox()
                combo.addItem("-- Ignore --")
                combo.addItems([f.name() for f in target_layer.fields()])
                table.setCellWidget(row_idx, col_idx, combo)

    def execute_auto_match(self):
        table = self.dock.schema_table
        if table.rowCount() == 0 or table.columnCount() < 2: return
        
        for row_idx in range(table.rowCount()):
            base_field = table.item(row_idx, 0).text()
            
            for col_idx in range(1, table.columnCount()):
                combo = table.cellWidget(row_idx, col_idx)
                if not combo: continue
                
                best_match_idx = 0
                highest_score = 0.0
                
                for item_idx in range(1, combo.count()):
                    target_field = combo.itemText(item_idx)
                    score = TemporalSchemaMatcher.get_similarity(base_field, target_field)
                    if score > highest_score:
                        highest_score = score
                        best_match_idx = item_idx
                
                if highest_score > 0.85:
                    combo.setCurrentIndex(best_match_idx)
                    combo.setStyleSheet("background-color: #d5f5e3;") 
                elif highest_score > 0.60:
                    combo.setCurrentIndex(best_match_idx)
                    combo.setStyleSheet("background-color: #fcf3cf;") 
                else:
                    combo.setCurrentIndex(0)
                    combo.setStyleSheet("background-color: #fadbd8;") 
                    
        self.dock.log_message("Schema auto-matching complete. Please review yellow and red fields.")

    def prompt_and_generate_chart(self):
        table = self.dock.schema_table
        if table.rowCount() == 0: return
        
        base_fields = [table.item(i, 0).text() for i in range(table.rowCount())]
        
        dialog = ChartConfigDialog(base_fields, self.dock)
        if not dialog.exec_() if hasattr(dialog, 'exec_') else not dialog.exec():
            return
            
        val_field, selected_cats = dialog.get_selections()
        
        if not val_field or not selected_cats:
            return self.dock.log_message("You must select a value and at least one category.", True)

        self.dock.log_message("Crunching temporal data for Dashboard...")
        
        layer_names = []
        for i in range(self.dock.timeline_list.count()):
            layer_names.append(self._get_clean_layer_name(self.dock.timeline_list.item(i).text()))
            
        charts_data = []
        is_virtual_area = val_field == "[Auto-Calculate Area (ha)]"
        val_row = -1 if is_virtual_area else base_fields.index(val_field)
        
        latest_year_total = 0.0
        
        total_steps = len(selected_cats) * len(self.active_layers)
        progress = TemporalProgressDialog(total_steps, self.dock)
        progress.show()
        
        step = 0
        QApplication.setOverrideCursor(QCursor(QT_WAIT_CURSOR))
        try:
            for cat_field in selected_cats:
                if progress.is_canceled: break
                
                is_expression = cat_field.startswith("ƒ: ")
                cat_expr = cat_field.replace("ƒ: ", "") if is_expression else None
                cat_row = base_fields.index(cat_field) if not is_expression else -1
                
                master_data = defaultdict(list) 
                
                for col_idx, layer in enumerate(self.active_layers):
                    if progress.is_canceled: break
                    
                    safe_lname = self._get_clean_layer_name(layer.name())
                    progress.update_progress(step, f"Processing Layer: {safe_lname}")
                    QApplication.processEvents()
                    
                    # --- THE FIX: CRS Aware Area Calculator ---
                    da = QgsDistanceArea()
                    da.setSourceCrs(layer.crs(), QgsProject.instance().transformContext())
                    da.setEllipsoid(QgsProject.instance().ellipsoid())
                    
                    if is_expression:
                        qgs_exp = QgsExpression(cat_expr)
                        context = QgsExpressionContext()
                        context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                    
                    if col_idx == 0:
                        local_cat_field = cat_field if not is_expression else None
                        local_val_field = val_field if not is_virtual_area else None
                    else:
                        if not is_expression:
                            cat_combo = table.cellWidget(cat_row, col_idx)
                            local_cat_field = cat_combo.currentText() if cat_combo.currentIndex() > 0 else None
                        else:
                            local_cat_field = None
                            
                        if not is_virtual_area:
                            val_combo = table.cellWidget(val_row, col_idx)
                            local_val_field = val_combo.currentText() if val_combo.currentIndex() > 0 else None
                        else:
                            local_val_field = None
                    
                    layer_aggregates = defaultdict(float)
                    
                    if (local_cat_field or is_expression) and (local_val_field or is_virtual_area):
                        feat_count = 0
                        for feat in layer.getFeatures():
                            
                            feat_count += 1
                            if feat_count % 1000 == 0:
                                QApplication.processEvents()
                                if progress.is_canceled: break
                            
                            if is_expression:
                                context.setFeature(feat)
                                res = qgs_exp.evaluate(context)
                                c_val = str(res) if res is not None else "Unknown"
                            else:
                                c_val = str(feat[local_cat_field]) if feat[local_cat_field] else "Unknown"
                            
                            if is_virtual_area:
                                geom = feat.geometry()
                                if geom and not geom.isEmpty():
                                    # --- THE FIX: Auto-heal geometries ---
                                    if not geom.isGeosValid(): 
                                        geom = geom.makeValid()
                                    v_val = da.measureArea(geom) / 10000.0
                                else:
                                    v_val = 0.0
                            else:
                                try:
                                    v_val = float(feat[local_val_field])
                                except (ValueError, TypeError, KeyError):
                                    v_val = 0.0
                                
                            layer_aggregates[c_val] += v_val
                            
                            if col_idx == len(self.active_layers) - 1 and cat_field == selected_cats[0]:
                                latest_year_total += v_val

                    all_known_cats = set(master_data.keys()).union(set(layer_aggregates.keys()))
                    for c in all_known_cats:
                        while len(master_data[c]) < col_idx:
                            master_data[c].append(0.0)
                        master_data[c].append(layer_aggregates.get(c, 0.0))
                
                    step += 1
                    progress.update_progress(step, f"Finished Layer: {safe_lname}")
                    QApplication.processEvents()
                    
                if progress.is_canceled: break
                
                traces = []
                for category, values in master_data.items():
                    traces.append({
                        'x': layer_names,
                        'y': values,
                        'name': category,
                        'type': 'scatter',
                        'mode': 'lines+markers',
                        'line': {'width': 3},
                        'marker': {'size': 6}
                    })
                
                if is_expression:
                    wrapped_expr = "<br>".join(textwrap.wrap(cat_expr, width=65))
                    chart_title = f"Condition:<br><span style='font-size: 14px; color: #7f8c8d;'>{wrapped_expr}</span>"
                else:
                    chart_title = f"Trend by {cat_field}"
                    
                full_title = cat_field if not is_expression else f"Condition: {cat_expr}"
                
                charts_data.append({
                    'title': chart_title,
                    'full_title': full_title,
                    'traces': traces
                })
                
        finally:
            progress.close()
            QApplication.restoreOverrideCursor()

        if progress.is_canceled:
            return self.dock.log_message("Temporal Dashboard generation canceled by user.", True)

        time_span = f"{layer_names[0]} ➔ {layer_names[-1]}" if len(layer_names) > 1 else layer_names[0]
        kpi_stats = [
            {'label': 'Time Steps Evaluated', 'value': str(len(self.active_layers))},
            {'label': 'Chronological Span', 'value': time_span},
            {'label': f'Total {val_field.replace("[Auto-Calculate ", "").replace("]", "")} (Latest Year)', 'value': f"{latest_year_total:,.1f}"}
        ]

        TemporalChartGenerator.build_plotly_dashboard(charts_data, title="Temporal Dashboard", y_axis_label=val_field, kpi_stats=kpi_stats)
        self.dock.log_message("Temporal Dashboard generated and opened in browser.")