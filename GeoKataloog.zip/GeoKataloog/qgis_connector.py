# -*- coding: utf-8 -*-
"""
GeoProfile Hub - QGIS Connection & Map Bridge
Injects profile configurations into QGIS settings (QgsSettings) and loads layers onto the Map Canvas.
Includes intelligent mixed-geometry resolvers: single-type filter, group splitting, and rule-based symbology.
Compatible with QGIS 3.44+ and QGIS 4.2+.
"""

import os
import urllib.parse
from qgis.core import (
    QgsSettings,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsDataSourceUri,
    QgsRuleBasedRenderer,
    QgsFillSymbol,
    QgsLineSymbol,
    QgsMarkerSymbol
)
from .i18n import tr
from .utils.url import normalize_service_url


def get_qgis_ini_settings():
    """Returns list of QSettings objects targeting QgsSettings and discovered QGIS INI files."""
    settings = QgsSettings()
    objs = [settings]  # Live QgsSettings first
    seen_paths = set()
    if settings.fileName():
        seen_paths.add(os.path.normpath(settings.fileName()))

    candidate_dirs = []
    try:
        from qgis.core import QgsApplication
        p = QgsApplication.qgisSettingsDirPath()
        if p:
            candidate_dirs.append(p)
    except Exception:
        pass

    appdata = os.environ.get("APPDATA", "")
    if appdata:
        for qver in ("QGIS4", "QGIS3"):
            candidate_dirs.append(os.path.join(appdata, "QGIS", qver, "profiles", "default"))

    for d in candidate_dirs:
        for fname in ("QGIS4.ini", "QGIS3.ini"):
            ini_p = os.path.normpath(os.path.join(d, "QGIS", fname))
            if os.path.exists(ini_p) and ini_p not in seen_paths:
                seen_paths.add(ini_p)
                from qgis.PyQt.QtCore import QSettings
                objs.append(QSettings(ini_p, QSettings.Format.IniFormat))

    return objs


class QgisConnector:
    """Manages writing connections to QGIS and loading layers to canvas."""

    def __init__(self, iface=None):
        self.iface = iface

    def remove_qgis_connection(self, service_type, name):
        """Removes a connection completely from QGIS settings across all modern and legacy keys."""
        if not name:
            return
        stype = (service_type or "").upper()
        name_clean = name.strip()
        name_quoted = urllib.parse.quote(name_clean)

        # 1. Official QGIS native C++ API deletion
        try:
            from qgis.core import QgsOwsConnection
            if stype in ("WFS", "WMS", "WCS"):
                QgsOwsConnection.deleteConnection(stype, name_clean)
                if name_quoted != name_clean:
                    QgsOwsConnection.deleteConnection(stype, name_quoted)
                QgsOwsConnection.deleteConnection(stype, name_clean.lower())
                QgsOwsConnection.deleteConnection(stype, name_clean.upper())
        except Exception:
            pass

        # 2. Comprehensive key removals across QgsSettings and discovered QGIS INI files
        settings_objs = get_qgis_ini_settings()

        name_variants = {
            name_clean,
            name_clean.lower(),
            name_clean.upper(),
            name_clean.capitalize(),
            name_quoted,
            urllib.parse.quote(name_clean.lower()),
            urllib.parse.quote(name_clean.upper())
        }

        keys_to_remove = []
        for v in name_variants:
            keys_to_remove.extend([
                f"connections/ows/items/{stype.lower()}/connections/items/{v}",
                f"connections/ows/items/{stype.upper()}/connections/items/{v}",
                f"ows/items/{stype.lower()}/connections/items/{v}",
                f"ows/items/{stype.upper()}/connections/items/{v}",
                f"connections-{stype.lower()}/{v}",
                f"{stype.upper()}/{v}",
                f"{stype.lower()}/{v}",
                f"qgis/connections-{stype.lower()}/{v}",
                f"qgis/connections/{stype.upper()}/{v}",
                f"qgis/connections/{stype.lower()}/{v}",
                f"connections-wms/{v}",
                f"connections-wfs/{v}",
                f"connections-wcs/{v}",
                f"WMS/{v}",
                f"WFS/{v}",
                f"WCS/{v}",
                f"connections/xyz/items/{v}",
                f"xyz/items/{v}",
                f"qgis/connections-xyz/{v}",
                f"connections-xyz/{v}"
            ])

        for s_obj in settings_objs:
            for k in keys_to_remove:
                try:
                    s_obj.remove(k)
                except Exception:
                    pass

            # Also scan child groups case-insensitively to catch any stubborn INI node
            for parent_grp in (
                f"connections/ows/items/{stype.lower()}/connections/items",
                f"ows/items/{stype.lower()}/connections/items",
                f"connections-{stype.lower()}",
                f"qgis/connections-{stype.lower()}",
                f"qgis/connections/{stype.upper()}",
                stype.upper()
            ):
                try:
                    s_obj.beginGroup(parent_grp)
                    child_groups = list(s_obj.childGroups())
                    s_obj.endGroup()
                    for cg in child_groups:
                        if cg.lower() == name_clean.lower():
                            s_obj.remove(f"{parent_grp}/{cg}")
                except Exception:
                    pass

            try:
                s_obj.sync()
            except Exception:
                pass

    def get_all_qgis_connections(self):
        """Returns list of all connections currently registered in QGIS settings."""
        settings_objs = get_qgis_ini_settings()
        connections = []
        found_keys = {}

        for s in settings_objs:
            try:
                s.sync()
            except Exception:
                pass

            # 1. Modern connections/ows/items/{stype}/connections/items/{name}
            has_modern_ows = False
            for grp_prefix in ("connections/ows/items", "ows/items"):
                s.beginGroup(grp_prefix)
                for stype in s.childGroups():
                    stype_upper = stype.upper()
                    s.beginGroup(f"{stype}/connections/items")
                    for conn_name in s.childGroups():
                        url = s.value(f"{conn_name}/url")
                        if url and isinstance(url, str):
                            has_modern_ows = True
                            name_clean = urllib.parse.unquote(conn_name)
                            dedup_key = (stype_upper, name_clean.lower())
                            if dedup_key not in found_keys:
                                found_keys[dedup_key] = len(connections)
                                connections.append({
                                    "service_type": stype_upper,
                                    "name": name_clean,
                                    "raw_name": conn_name,
                                    "url": str(url).strip().strip('"')
                                })
                            else:
                                existing_name = connections[found_keys[dedup_key]]["name"]
                                if name_clean != existing_name and (name_clean[0].isupper() or len(name_clean) > len(existing_name)):
                                    connections[found_keys[dedup_key]]["name"] = name_clean
                    s.endGroup()
                s.endGroup()

            # 2. Modern connections/xyz/items/{name}
            has_modern_xyz = False
            for grp_prefix in ("connections/xyz/items", "xyz/items"):
                s.beginGroup(grp_prefix)
                for conn_name in s.childGroups():
                    url = s.value(f"{conn_name}/url")
                    if url and isinstance(url, str):
                        has_modern_xyz = True
                        name_clean = urllib.parse.unquote(conn_name)
                        dedup_key = ("XYZ", name_clean.lower())
                        if dedup_key not in found_keys:
                            found_keys[dedup_key] = len(connections)
                            connections.append({
                                "service_type": "XYZ",
                                "name": name_clean,
                                "raw_name": conn_name,
                                "url": str(url).strip().strip('"')
                            })
                        else:
                            existing_name = connections[found_keys[dedup_key]]["name"]
                            if name_clean != existing_name and (name_clean[0].isupper() or len(name_clean) > len(existing_name)):
                                connections[found_keys[dedup_key]]["name"] = name_clean
                s.endGroup()

            # 3. Legacy fallbacks ONLY if modern connections are empty (preserves deletions in QGIS 3/4)
            if not has_modern_ows:
                for stype, grp in [("WMS", "connections-wms"), ("WFS", "connections-wfs"), ("WCS", "connections-wcs")]:
                    s.beginGroup(grp)
                    for conn_name in s.childGroups():
                        url = s.value(f"{conn_name}/url")
                        if url and isinstance(url, str):
                            name_clean = urllib.parse.unquote(conn_name)
                            dedup_key = (stype, name_clean.lower())
                            if dedup_key not in found_keys:
                                found_keys[dedup_key] = len(connections)
                                connections.append({
                                    "service_type": stype,
                                    "name": name_clean,
                                    "raw_name": conn_name,
                                    "url": str(url).strip().strip('"')
                                })
                            else:
                                existing_name = connections[found_keys[dedup_key]]["name"]
                                if name_clean != existing_name and (name_clean[0].isupper() or len(name_clean) > len(existing_name)):
                                    connections[found_keys[dedup_key]]["name"] = name_clean
                    s.endGroup()

            if not has_modern_xyz:
                for grp in ("qgis/connections-xyz", "connections-xyz"):
                    s.beginGroup(grp)
                    for conn_name in s.childGroups():
                        url = s.value(f"{conn_name}/url")
                        if url and isinstance(url, str):
                            name_clean = urllib.parse.unquote(conn_name)
                            dedup_key = ("XYZ", name_clean.lower())
                            if dedup_key not in found_keys:
                                found_keys[dedup_key] = len(connections)
                                connections.append({
                                    "service_type": "XYZ",
                                    "name": name_clean,
                                    "raw_name": conn_name,
                                    "url": str(url).strip().strip('"')
                                })
                            else:
                                existing_name = connections[found_keys[dedup_key]]["name"]
                                if name_clean != existing_name and (name_clean[0].isupper() or len(name_clean) > len(existing_name)):
                                    connections[found_keys[dedup_key]]["name"] = name_clean
                    s.endGroup()

            # If live authoritative QgsSettings yielded connections, don't resurrect deleted ones from stale fallback INIs
            if connections:
                break

        return connections

    def apply_single_service(self, service_dict):
        """
        Applies a single service to QGIS connections immediately.
        Cleans up any previous names or older connections pointing to the same URL,
        writes modern and legacy connection keys across all active QGIS settings,
        synchronizes and refreshes the browser.
        """
        if not service_dict:
            return False

        stype = service_dict.get("service_type", "WMS").upper()
        name = service_dict.get("name", "Service").strip()
        url = service_dict.get("url", "").strip()
        if not url:
            return False

        norm_u = normalize_service_url(url)

        # 1. Clean up any previous names explicitly stored
        for old_n in service_dict.get("previous_names", []):
            if old_n and old_n != name:
                self.remove_qgis_connection(stype, old_n)
        service_dict["previous_names"] = []

        # 2. Check for any existing connection in QGIS with the same URL but different name
        for c in self.get_all_qgis_connections():
            if c.get("service_type", "").upper() == stype:
                c_norm = normalize_service_url(c.get("url", ""))
                if c_norm == norm_u and c.get("name", "").strip() != name:
                    self.remove_qgis_connection(stype, c.get("name"))

        # 3. Ensure stale casing variant is removed first so Windows INI preserves exact casing
        if name.lower() != name:
            self.remove_qgis_connection(stype, name.lower())
        if name.upper() != name:
            self.remove_qgis_connection(stype, name.upper())

        # 4. Save connection across all targets
        auth_type = service_dict.get("auth_type", "none")
        auth_params = service_dict.get("auth_params", {})
        pref = service_dict.get("preferred_settings", {})

        settings_objs = get_qgis_ini_settings()
        for target_set in settings_objs:
            if stype in ("WMS", "WMTS"):
                self._save_wms_connection(target_set, name, url, auth_type, auth_params, pref)
            elif stype == "WFS":
                self._save_wfs_connection(target_set, name, url, auth_type, auth_params, pref)
            elif stype == "WCS":
                self._save_wcs_connection(target_set, name, url, auth_type, auth_params, pref)
            elif stype == "XYZ":
                self._save_xyz_connection(target_set, name, url, pref)
            try:
                target_set.sync()
            except Exception:
                pass

        self.refresh_browser()
        return True

    def apply_profile(self, profile, clean_unlisted=True):
        """
        Applies all services in profile to QGIS connection settings.
        Writes to modern and legacy paths across all QGIS targets.
        Cleans up renamed connections and unlisted lingering connections so QGIS browser matches the profile 100%.
        """
        services = profile.get("services", [])
        applied_count = 0

        # Build incoming profile lookup structures
        incoming_by_url = {}   # (stype, norm_url) -> service dict
        incoming_names = set() # (stype, name_lower)

        for s in services:
            stype = s.get("service_type", "WMS").upper()
            if stype == "MIXED":
                # MIXED groups contain layers referencing external parent services
                for layer in s.get("layers", []):
                    p_svc = layer.get("parent_service")
                    if p_svc and isinstance(p_svc, dict):
                        p_stype = p_svc.get("service_type", "").upper()
                        p_name = p_svc.get("name", "").strip()
                        p_url = p_svc.get("url", "").strip()
                        norm_pu = normalize_service_url(p_url)
                        if p_stype and norm_pu:
                            incoming_by_url[(p_stype, norm_pu)] = p_svc
                            incoming_names.add((p_stype, p_name.lower()))
                continue

            name = s.get("name", "Service").strip()
            url = s.get("url", "").strip()
            norm_u = normalize_service_url(url)
            if norm_u:
                incoming_by_url[(stype, norm_u)] = s
            incoming_names.add((stype, name.lower()))

        # 1. Inspect existing QGIS connections
        existing_conns = self.get_all_qgis_connections()

        # Step 1A: Remove old names for same URLs
        for c in existing_conns:
            c_stype = c.get("service_type", "").upper()
            c_name = c.get("name", "").strip()
            c_norm_u = normalize_service_url(c.get("url", ""))
            url_key = (c_stype, c_norm_u)

            if url_key in incoming_by_url:
                target_s = incoming_by_url[url_key]
                target_name = target_s.get("name", "").strip()
                if c_name != target_name:
                    # Same service under old name in QGIS -> remove old name
                    self.remove_qgis_connection(c_stype, c_name)

        # Step 1B: Clean unlisted connections (mirroring profile into QGIS browser)
        if clean_unlisted:
            for c in existing_conns:
                c_stype = c.get("service_type", "").upper()
                c_name = c.get("name", "").strip()
                c_norm_u = normalize_service_url(c.get("url", ""))

                if (c_stype, c_name.lower()) not in incoming_names and (c_stype, c_norm_u) not in incoming_by_url:
                    self.remove_qgis_connection(c_stype, c_name)

        # Step 1C: Clean up explicit previous_names
        for s in services:
            stype = s.get("service_type", "WMS").upper()
            name = s.get("name", "Service").strip()
            for old_n in s.get("previous_names", []):
                if old_n and old_n != name:
                    self.remove_qgis_connection(stype, old_n)
            s["previous_names"] = []

        # Step 2: Save all incoming services across all targets
        settings_objs = get_qgis_ini_settings()

        # Collect standard services plus any parent services needed by MIXED groups
        services_to_save = [s for s in services if s.get("service_type", "").upper() != "MIXED"]
        saved_urls = {normalize_service_url(s.get("url", "")) for s in services_to_save}

        for s in services:
            if s.get("service_type", "").upper() == "MIXED":
                for layer in s.get("layers", []):
                    p_svc = layer.get("parent_service")
                    if p_svc and isinstance(p_svc, dict):
                        p_url = p_svc.get("url", "").strip()
                        norm_pu = normalize_service_url(p_url)
                        if norm_pu and norm_pu not in saved_urls:
                            services_to_save.append(p_svc)
                            saved_urls.add(norm_pu)

        for s in services_to_save:
            stype = s.get("service_type", "WMS").upper()
            name = s.get("name", "Service").strip()
            url = s.get("url", "").strip()
            if not url or stype == "MIXED":
                continue

            auth_type = s.get("auth_type", "none")
            auth_params = s.get("auth_params", {})
            pref = s.get("preferred_settings", {})

            # Ensure stale casing variant is removed first so Windows INI preserves exact casing
            if name.lower() != name:
                self.remove_qgis_connection(stype, name.lower())
            if name.upper() != name:
                self.remove_qgis_connection(stype, name.upper())

            for target_set in settings_objs:
                if stype in ("WMS", "WMTS"):
                    self._save_wms_connection(target_set, name, url, auth_type, auth_params, pref)
                elif stype == "WFS":
                    self._save_wfs_connection(target_set, name, url, auth_type, auth_params, pref)
                elif stype == "WCS":
                    self._save_wcs_connection(target_set, name, url, auth_type, auth_params, pref)
                elif stype == "XYZ":
                    self._save_xyz_connection(target_set, name, url, pref)

            applied_count += 1

        for target_set in settings_objs:
            try:
                target_set.sync()
            except Exception:
                pass

        self.refresh_browser()
        return applied_count

    def _save_wms_connection(self, settings, name, url, auth_type, auth_params, pref):
        """Saves WMS/WMTS connection to QgsSettings."""
        clean_name = name.strip()
        m_base = f"connections/ows/items/wms/connections/items/{clean_name}"
        settings.setValue(f"{m_base}/url", url)
        settings.setValue(f"{m_base}/dpi-mode", pref.get("dpi-mode", 7))
        settings.setValue(f"{m_base}/smooth-pixmap-transform", pref.get("smooth-pixmap-transform", False))
        settings.setValue(f"{m_base}/reported-layer-extents", pref.get("reported-layer-extents", False))
        settings.setValue(f"{m_base}/invert-axis-orientation", pref.get("invert-axis-orientation", False))
        settings.setValue(f"{m_base}/ignore-axis-orientation", pref.get("ignore-axis-orientation", False))

        l_base = f"connections-wms/{clean_name}"
        settings.setValue(f"{l_base}/url", url)
        settings.setValue(f"{l_base}/ignoreReportedLayerExtents", pref.get("reported-layer-extents", False))

        authcfg = auth_params.get("authcfg", "")
        username = auth_params.get("username", "") if auth_type == "basic" else ""
        password = auth_params.get("password", "") if auth_type == "basic" else ""

        settings.setValue(f"{m_base}/authcfg", authcfg)
        settings.setValue(f"{m_base}/username", username)
        settings.setValue(f"{m_base}/password", password)

        settings.setValue(f"WMS/{clean_name}/authcfg", authcfg)
        settings.setValue(f"WMS/{clean_name}/username", username)
        settings.setValue(f"WMS/{clean_name}/password", password)

    def _save_wfs_connection(self, settings, name, url, auth_type, auth_params, pref):
        """Saves WFS connection to QgsSettings."""
        clean_name = name.strip()
        m_base = f"connections/ows/items/wfs/connections/items/{clean_name}"
        settings.setValue(f"{m_base}/url", url)
        settings.setValue(f"{m_base}/paging-enabled", pref.get("paging-enabled", True))
        settings.setValue(f"{m_base}/page-size", pref.get("page-size", 1000))
        settings.setValue(f"{m_base}/version", pref.get("version", "auto"))
        settings.setValue(f"{m_base}/max-num-features", pref.get("max-num-features", ""))
        settings.setValue(f"{m_base}/prefer-coordinates-for-wfs-T11", pref.get("prefer-coordinates-for-wfs-T11", False))

        l_base = f"connections-wfs/{clean_name}"
        settings.setValue(f"{l_base}/url", url)
        settings.setValue(f"{l_base}/paging-enabled", pref.get("paging-enabled", True))
        settings.setValue(f"{l_base}/page-size", pref.get("page-size", 1000))

        authcfg = auth_params.get("authcfg", "")
        username = auth_params.get("username", "") if auth_type == "basic" else ""
        password = auth_params.get("password", "") if auth_type == "basic" else ""

        settings.setValue(f"{m_base}/authcfg", authcfg)
        settings.setValue(f"{m_base}/username", username)
        settings.setValue(f"{m_base}/password", password)

        settings.setValue(f"WFS/{clean_name}/authcfg", authcfg)
        settings.setValue(f"WFS/{clean_name}/username", username)
        settings.setValue(f"WFS/{clean_name}/password", password)

    def _save_wcs_connection(self, settings, name, url, auth_type, auth_params, pref):
        """Saves WCS (Web Coverage Service) connection to QgsSettings."""
        clean_name = name.strip()
        clean_url = url.split("?")[0] if "?" in url else url
        m_base = f"connections/ows/items/wcs/connections/items/{clean_name}"
        settings.setValue(f"{m_base}/url", clean_url)
        settings.setValue(f"{m_base}/dpi-mode", pref.get("dpi-mode", 7))
        settings.setValue(f"{m_base}/smooth-pixmap-transform", pref.get("smooth-pixmap-transform", False))
        settings.setValue(f"{m_base}/reported-layer-extents", pref.get("reported-layer-extents", False))
        settings.setValue(f"{m_base}/ignore-axis-orientation", pref.get("ignore-axis-orientation", False))
        settings.setValue(f"{m_base}/invert-axis-orientation", pref.get("invert-axis-orientation", False))

        authcfg = auth_params.get("authcfg", "")
        username = auth_params.get("username", "") if auth_type == "basic" else ""
        password = auth_params.get("password", "") if auth_type == "basic" else ""

        settings.setValue(f"{m_base}/authcfg", authcfg)
        settings.setValue(f"{m_base}/username", username)
        settings.setValue(f"{m_base}/password", password)

        l_base = f"connections-wcs/{clean_name}"
        settings.setValue(f"{l_base}/url", clean_url)
        settings.setValue(f"WCS/{clean_name}/url", clean_url)
        settings.setValue(f"WCS/{clean_name}/authcfg", authcfg)

    def _save_xyz_connection(self, settings, name, url, pref):
        """Saves XYZ tile connection to QgsSettings across modern and legacy paths."""
        clean_name = name.strip()
        zmin = int(pref.get("zmin", 0))
        zmax = int(pref.get("zmax", 19))
        authcfg = pref.get("authcfg", "")

        # Remove any legacy or duplicate URL-encoded variant key so it never appears twice in QGIS Browser
        quoted_name = urllib.parse.quote(clean_name)
        for old_base in (
            f"connections/xyz/items/{quoted_name}",
            f"xyz/items/{quoted_name}",
            f"xyz/items/{clean_name}",
            f"qgis/connections-xyz/{quoted_name}",
            f"qgis/connections-xyz/{clean_name}",
            f"connections-xyz/{quoted_name}",
            f"connections-xyz/{clean_name}",
        ):
            if old_base != f"connections/xyz/items/{clean_name}":
                settings.remove(old_base)

        # 1. Modern QGIS 3/4 location in [connections] (official browser node)
        base_modern = f"connections/xyz/items/{clean_name}"
        settings.setValue(f"{base_modern}/url", str(url))
        settings.setValue(f"{base_modern}/zmin", zmin)
        settings.setValue(f"{base_modern}/zmax", zmax)
        settings.setValue(f"{base_modern}/tile-pixel-ratio", 0)
        settings.setValue(f"{base_modern}/hidden", False)
        if authcfg:
            settings.setValue(f"{base_modern}/authcfg", str(authcfg))

    def refresh_browser(self):
        """
        Safely refreshes QGIS Browser dock connections asynchronously outside the Qt event stack.
        Prevents dangerous C++ model reset re-entrancy segfaults (0xc0000409).
        """
        try:
            from qgis.PyQt import QtCore
            QtCore.QTimer.singleShot(150, self._do_deferred_refresh)
        except Exception:
            self._do_deferred_refresh()

    def _do_deferred_refresh(self):
        """Executes browser refresh cleanly via native toolbar actions."""
        if not self.iface:
            return
        try:
            from qgis.PyQt import QtWidgets
            main_window = self.iface.mainWindow() if hasattr(self.iface, "mainWindow") else None
            if not main_window:
                return

            for dock in main_window.findChildren(QtWidgets.QDockWidget):
                d_name = (dock.objectName() or "").lower()
                d_cls = dock.metaObject().className().lower()
                if "browser" in d_name or "browser" in d_cls:
                    refreshed = False
                    for act in dock.findChildren(QtWidgets.QAction):
                        act_name = (act.objectName() or "").lower()
                        if act_name == "mactionrefresh" or "refresh" in act_name:
                            act.trigger()
                            refreshed = True
                            break
                    if not refreshed and hasattr(dock, "refresh"):
                        try:
                            dock.refresh()
                        except Exception:
                            pass
        except Exception:
            pass

    def add_layer_to_canvas(self, layer_item, service_item, geometry_filter=None, mode="single"):
        """
        Instantiates and adds layer to active QGIS project map canvas.
        Supports single-type geometry filtering, split group creation, and rule-based symbology.
        Returns (success_bool, message_str).
        """
        # Resolve parent service if layer originates from a MIXED group
        parent_svc = layer_item.get("parent_service") or {}
        stype = (layer_item.get("service_type") or parent_svc.get("service_type") or service_item.get("service_type") or "WMS").upper()
        if stype == "MIXED":
            stype = (layer_item.get("service_type") or parent_svc.get("service_type") or "WMS").upper()

        url = layer_item.get("service_url") or parent_svc.get("url") or service_item.get("url", "")
        layer_name = layer_item.get("name", "")
        layer_title = layer_item.get("title", layer_name)
        crs = layer_item.get("default_crs", "EPSG:3301")
        geom_col = layer_item.get("geom_col", "shape") or "shape"

        # Fail-safe: if stype is mistakenly WMS/WMTS but layer has vector characteristics or URL is clearly WFS
        if stype in ("WMS", "WMTS"):
            if (layer_item.get("geom_type") in ("Point", "Polygon", "LineString", "Geometry", "Vektor (WFS)")
                or layer_item.get("fields")
                or ("/wfs" in url.lower() or "service=wfs" in url.lower())):
                stype = "WFS"

        auth_type = parent_svc.get("auth_type") or service_item.get("auth_type", "none")
        auth_params = parent_svc.get("auth_params") or service_item.get("auth_params", {})
        pref = parent_svc.get("preferred_settings") or service_item.get("preferred_settings", {})

        try:
            if stype in ("WMS", "WMTS"):
                uri_parts = [
                    f"url={url}",
                    f"layers={layer_name}",
                    f"styles=",
                    f"format=image/png",
                    f"crs={crs}"
                ]
                if auth_params.get("authcfg"):
                    uri_parts.append(f"authcfg={auth_params['authcfg']}")
                if auth_type == "basic" and auth_params.get("username"):
                    uri_parts.append(f"username={auth_params['username']}")
                    uri_parts.append(f"password={auth_params.get('password', '')}")

                uri = "&".join(uri_parts)
                rlayer = QgsRasterLayer(uri, layer_title, "wms")
                if rlayer.isValid():
                    QgsProject.instance().addMapLayer(rlayer)
                    return True, tr("msg_layer_added", name=layer_title)
                else:
                    return False, f"WMS viga: {rlayer.error().message()}"

            elif stype == "WFS":
                # Mode 1: Split all mixed geometries into a dedicated group
                if mode == "split_all":
                    return self._add_wfs_split_group(layer_item, service_item, layer_title, url, crs, geom_col, auth_type, auth_params, pref)

                # Mode 2: Rule-based symbology on single layer
                elif mode == "rule_based":
                    return self._add_wfs_rule_based(layer_item, service_item, layer_title, url, crs, auth_type, auth_params, pref)

                # Mode 3: Single layer (with optional geometryType filter)
                return self._add_wfs_single(layer_item, service_item, layer_title, url, crs, geom_col, geometry_filter, auth_type, auth_params, pref)

            elif stype == "XYZ":
                xyz_uri = f"type=xyz&url={url}&zmax={pref.get('zmax', 19)}&zmin={pref.get('zmin', 0)}"
                tlayer = QgsRasterLayer(xyz_uri, layer_title, "wms")
                if tlayer.isValid():
                    QgsProject.instance().addMapLayer(tlayer)
                    return True, tr("msg_layer_added", name=layer_title)
                else:
                    return False, "XYZ tiilide laadimine ebaõnnestus."

            elif stype == "WCS":
                clean_url = url.split("?")[0] if "?" in url else url
                uri_parts = [
                    f"url={clean_url}",
                    f"identifier={layer_name}"
                ]
                if auth_params.get("authcfg"):
                    uri_parts.append(f"authcfg={auth_params['authcfg']}")
                if auth_type == "basic" and auth_params.get("username"):
                    uri_parts.append(f"username={auth_params['username']}")
                    uri_parts.append(f"password={auth_params.get('password', '')}")

                uri = "&".join(uri_parts)
                rlayer = QgsRasterLayer(uri, layer_title, "wcs")
                if rlayer.isValid():
                    QgsProject.instance().addMapLayer(rlayer)
                    return True, tr("msg_layer_added", name=layer_title)
                else:
                    return False, f"WCS viga: {rlayer.error().message()}"

            return False, f"Tundmatu protokoll: {stype}"

        except Exception as e:
            return False, f"Viga kaardile lisamisel: {e}"

    def add_mixed_group_to_canvas(self, mixed_group_item):
        """
        Loads all layers from a user-defined custom MIXED group into a dedicated
        QgsLayerTreeGroup in the active QGIS project map canvas.
        Returns (success_bool, message_str).
        """
        group_name = mixed_group_item.get("name", "Kohandatud grupp").strip() or "Kohandatud grupp"
        layers = mixed_group_item.get("layers", [])
        if not layers:
            return False, tr("mixed_empty_hint")

        try:
            root = QgsProject.instance().layerTreeRoot()
            group_node = None
            for child in root.children():
                if hasattr(child, "name") and child.name() == group_name:
                    group_node = child
                    break
            if not group_node:
                group_node = root.addGroup(group_name)

            added_count = 0
            for layer_item in layers:
                parent_svc = layer_item.get("parent_service") or {}
                stype = (layer_item.get("service_type") or parent_svc.get("service_type") or "WMS").upper()
                url = layer_item.get("service_url") or parent_svc.get("url", "")
                layer_name = layer_item.get("name", "")
                title = layer_item.get("title", layer_name)
                crs = layer_item.get("default_crs", "EPSG:3301")
                auth_type = parent_svc.get("auth_type", "none")
                auth_params = parent_svc.get("auth_params", {})
                pref = parent_svc.get("preferred_settings", {})

                created_layer = None
                if stype in ("WMS", "WMTS"):
                    uri_parts = [
                        f"url={url}",
                        f"layers={layer_name}",
                        f"styles=",
                        f"format=image/png",
                        f"crs={crs}"
                    ]
                    if auth_params.get("authcfg"):
                        uri_parts.append(f"authcfg={auth_params['authcfg']}")
                    uri = "&".join(uri_parts)
                    rlayer = QgsRasterLayer(uri, title, "wms")
                    if rlayer.isValid():
                        created_layer = rlayer
                elif stype == "XYZ":
                    zmin = int(pref.get("zmin", 0))
                    zmax = int(pref.get("zmax", 19))
                    clean_u = url.replace("&", "%26")
                    uri = f"type=xyz&url={clean_u}&zmin={zmin}&zmax={zmax}"
                    rlayer = QgsRasterLayer(uri, title, "wms")
                    if rlayer.isValid():
                        created_layer = rlayer
                elif stype == "WCS":
                    clean_url = url.split("?")[0] if "?" in url else url
                    uri = f"url={clean_url}&identifier={layer_name}&crs={crs}&format=GeoTIFF"
                    rlayer = QgsRasterLayer(uri, title, "wcs")
                    if rlayer.isValid():
                        created_layer = rlayer
                elif stype == "WFS":
                    wfs_uri = self._build_wfs_uri(url, layer_name, crs, auth_type, auth_params, pref)
                    vlayer = QgsVectorLayer(wfs_uri.uri(), title, "WFS")
                    if vlayer.isValid():
                        created_layer = vlayer

                if created_layer:
                    QgsProject.instance().addMapLayer(created_layer, False)
                    group_node.addLayer(created_layer)
                    added_count += 1

            if added_count > 0:
                return True, tr("canvas_group_added", name=group_name, count=added_count)
            else:
                return False, f"Ühtegi kihti grupist '{group_name}' ei õnnestunud avada."
        except Exception as e:
            return False, f"Viga grupi kaardile lisamisel: {e}"

    def _build_wfs_uri(self, url, layer_name, crs, auth_type, auth_params, pref, cql_filter=None):
        """Builds a configured QgsDataSourceUri for WFS."""
        wfs_uri = QgsDataSourceUri()

        clean_url = url.split("?")[0] if "?" in url else url
        final_url = clean_url
        if cql_filter:
            encoded_cql = urllib.parse.quote(cql_filter)
            final_url = f"{clean_url}?cql_filter={encoded_cql}"

        wfs_uri.setParam("url", final_url)
        wfs_uri.setParam("typename", layer_name)
        wfs_uri.setParam("srsname", crs)
        if pref.get("paging-enabled", True):
            wfs_uri.setParam("pagingEnabled", "true")
            p_size = int(pref.get("page-size", 1000))
            if cql_filter and p_size > 500:
                p_size = 500  # Cap page size for spatial CQL filters to prevent GeoServer 502 Bad Gateway timeouts
            wfs_uri.setParam("pageSize", str(p_size))
        ver = pref.get("version", "auto")
        if not ver or ver == "auto":
            if "version=1.1" in url.lower(): ver = "1.1.0"
            elif "version=1.0" in url.lower(): ver = "1.0.0"
            elif "version=2.0" in url.lower(): ver = "2.0.0"
        if ver and ver != "auto":
            wfs_uri.setParam("version", ver)
        if auth_params.get("authcfg"):
            wfs_uri.setAuthConfigId(auth_params["authcfg"])
        if auth_type == "basic" and auth_params.get("username"):
            wfs_uri.setUsername(auth_params["username"])
            wfs_uri.setPassword(auth_params.get("password", ""))

        return wfs_uri

    def _add_wfs_single(self, layer_item, service_item, title, url, crs, geom_col, geom_filter, auth_type, auth_params, pref):
        """Loads a single WFS layer, applying geometryType filter if requested."""
        layer_name = layer_item.get("name", "")
        counts = layer_item.get("geom_counts", {})
        cql = None
        custom_title = title

        if geom_filter:
            if geom_filter.lower() in ("polygon", "multipolygon"):
                cql = f"geometryType({geom_col}) IN ('Polygon', 'MultiPolygon')"
                cnt = counts.get("Polygon")
                c_str = f" [{cnt/1000:.1f}k]" if cnt and cnt >= 10000 else (f" [{cnt}]" if cnt is not None else "")
                custom_title = f"{title} (Polügoonid){c_str}"
            elif geom_filter.lower() in ("linestring", "multilinestring", "line"):
                cql = f"geometryType({geom_col}) IN ('LineString', 'MultiLineString')"
                cnt = counts.get("LineString")
                c_str = f" [{cnt/1000:.1f}k]" if cnt and cnt >= 10000 else (f" [{cnt}]" if cnt is not None else "")
                custom_title = f"{title} (Jooned){c_str}"
            elif geom_filter.lower() in ("point", "multipoint"):
                cql = f"geometryType({geom_col}) IN ('Point', 'MultiPoint')"
                cnt = counts.get("Point")
                c_str = f" [{cnt/1000:.1f}k]" if cnt and cnt >= 10000 else (f" [{cnt}]" if cnt is not None else "")
                custom_title = f"{title} (Punktid){c_str}"

        wfs_uri = self._build_wfs_uri(url, layer_name, crs, auth_type, auth_params, pref, cql_filter=cql)
        vlayer = QgsVectorLayer(wfs_uri.uri(), custom_title, "WFS")

        if vlayer.isValid():
            if geom_filter and vlayer.featureCount() == 0:
                return False, f"Kihil '{title}' puuduvad valitud geomeetriaga ({geom_filter}) objektid."
            QgsProject.instance().addMapLayer(vlayer)
            return True, tr("msg_layer_added", name=custom_title)
        else:
            return False, f"WFS viga: {vlayer.error().message()}"

    def _add_wfs_split_group(self, layer_item, service_item, title, url, crs, geom_col, auth_type, auth_params, pref):
        """Creates dedicated sub-layers for only the geometry types that actually exist in the layer."""
        layer_name = layer_item.get("name", "")
        group_name = f"{title} [Eraldatud/Split]"
        root = QgsProject.instance().layerTreeRoot()

        mixed_types = layer_item.get("mixed_types", [])
        if not mixed_types:
            mixed_types = ["Polygon", "LineString", "Point"]

        counts = layer_item.get("geom_counts", {})

        all_targets = [
            ("Polygon", "Polügoonid", f"geometryType({geom_col}) IN ('Polygon', 'MultiPolygon')"),
            ("LineString", "Jooned", f"geometryType({geom_col}) IN ('LineString', 'MultiLineString')"),
            ("Point", "Punktid", f"geometryType({geom_col}) IN ('Point', 'MultiPoint')")
        ]

        targets = []
        for g_key, label_est, cql in all_targets:
            if any(m.lower() in g_key.lower() for m in mixed_types):
                if counts and g_key in counts and counts[g_key] == 0:
                    continue
                targets.append((g_key, label_est, cql))

        if not targets:
            targets = all_targets

        added_layers = []
        for geom_key, label_est, cql in targets:
            c = counts.get(geom_key)
            if c is not None and c > 0:
                c_str = f"{c/1000:.1f}k" if c >= 10000 else str(c)
                sub_title = f"{title} ({label_est}) [{c_str}]"
            else:
                sub_title = f"{title} ({label_est})"

            wfs_uri = self._build_wfs_uri(url, layer_name, crs, auth_type, auth_params, pref, cql_filter=cql)
            vlayer = QgsVectorLayer(wfs_uri.uri(), sub_title, "WFS")
            if vlayer.isValid():
                if vlayer.featureCount() != 0:
                    added_layers.append(vlayer)

        if added_layers:
            group = root.addGroup(group_name)
            for idx, vlayer in enumerate(added_layers):
                QgsProject.instance().addMapLayer(vlayer, False)
                node = group.addLayer(vlayer)
                # Keep first/primary layer visible, set secondary sub-layers unchecked so remote server isn't hit by parallel bursts
                if idx > 0 and hasattr(node, "setItemVisibilityChecked"):
                    try:
                        node.setItemVisibilityChecked(False)
                    except Exception:
                        pass
            return True, tr("msg_split_group_added", name=title, group=group_name, count=len(added_layers))
        else:
            return False, f"Kihil '{title}' ei leitud eraldatavaid geomeetriatüüpe."

    def _add_wfs_rule_based(self, layer_item, service_item, title, url, crs, auth_type, auth_params, pref):
        """Loads layer and applies rule-based symbology covering points, lines and polygons."""
        layer_name = layer_item.get("name", "")
        wfs_uri = self._build_wfs_uri(url, layer_name, crs, auth_type, auth_params, pref)
        vlayer = QgsVectorLayer(wfs_uri.uri(), f"{title} (Reeglipõhine)", "WFS")

        if not vlayer.isValid():
            return False, f"WFS viga: {vlayer.error().message()}"

        try:
            # Root rule
            root_rule = QgsRuleBasedRenderer.Rule(None)

            # Rule 1: Polygons (matches Polygon & MultiPolygon without syntax error)
            poly_sym = QgsFillSymbol.createSimple({'color': '100,160,240,140', 'outline_color': '30,80,180', 'outline_width': '0.5'})
            r_poly = QgsRuleBasedRenderer.Rule(poly_sym, 0, 0, "geometry_type($geometry) = 'Polygon'", "Polügoonid (Polygons)")
            root_rule.appendChild(r_poly)

            # Rule 2: Lines (matches LineString & MultiLineString without syntax error)
            line_sym = QgsLineSymbol.createSimple({'color': '230,80,40', 'width': '0.9'})
            r_line = QgsRuleBasedRenderer.Rule(line_sym, 0, 0, "geometry_type($geometry) = 'Line'", "Jooned (Lines)")
            root_rule.appendChild(r_line)

            # Rule 3: Points (matches Point & MultiPoint without syntax error)
            pt_sym = QgsMarkerSymbol.createSimple({'color': '40,190,90', 'size': '3.2', 'outline_color': '0,100,40'})
            r_pt = QgsRuleBasedRenderer.Rule(pt_sym, 0, 0, "geometry_type($geometry) = 'Point'", "Punktid (Points)")
            root_rule.appendChild(r_pt)

            renderer = QgsRuleBasedRenderer(root_rule)
            vlayer.setRenderer(renderer)
            vlayer.triggerRepaint()
        except Exception:
            pass

        QgsProject.instance().addMapLayer(vlayer)
        return True, tr("msg_layer_added", name=f"{title} (Reeglipõhine)")
