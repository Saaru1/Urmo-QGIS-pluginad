# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Profile Manager
Manages user profiles, groupings, JSON persistence, and QGIS XML import/export.
Detects active QGIS connections at startup and creates/syncs 'Current profile'.
"""

import os
import json
import time
import uuid
import urllib.parse
import xml.etree.ElementTree as ET
from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QSettings
from .presets import ESTONIA_SERVICES
from .utils.url import normalize_service_url


def get_profile_name(profile, lang="EST"):
    """Returns localized name for profile (e.g. 'Hetke profiil' in EST, 'Current profile' in ENG)."""
    if not profile:
        return "Hetke profiil" if lang == "EST" else "Current profile"
    p_id = profile.get("id")
    p_name = profile.get("name", "")
    if p_id == "prof_current" or p_name in ("Current profile", "Hetke profiil", "Praegune profiil"):
        return "Current profile" if lang == "ENG" else "Hetke profiil"
    if lang == "ENG" and profile.get("name_en"):
        return profile.get("name_en")
    return p_name or ("Hetke profiil" if lang == "EST" else "Current profile")


class ProfileManager:
    """Manages geospatial service profiles and serialization."""

    def __init__(self, storage_dir=None):
        if storage_dir:
            self.storage_dir = storage_dir
        else:
            cand = None
            try:
                p = QgsApplication.qgisSettingsDirPath()
                if p and "QGIS" in p and os.path.exists(p):
                    cand = p
            except Exception:
                pass
            if not cand:
                appdata = os.environ.get("APPDATA", "")
                if appdata:
                    for qver in ("QGIS4", "QGIS3"):
                        qp = os.path.join(appdata, "QGIS", qver, "profiles", "default")
                        if os.path.exists(qp):
                            cand = qp
                            break
            try:
                self.storage_dir = cand or QgsApplication.qgisSettingsDirPath() or os.path.expanduser("~")
            except Exception:
                self.storage_dir = cand or os.path.expanduser("~")

        self.storage_file = os.path.join(self.storage_dir, "geoprofile_hub_profiles.json")
        self.data = {"version": "1.0", "active_profile_id": None, "profiles": []}
        self.load()

        # Detect active QGIS connections and initialize/sync 'Current profile'
        self.sync_current_qgis_profile()

    def load(self):
        """Loads profiles from JSON storage file or initializes defaults."""
        loaded = False
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
                    if self.data.get("profiles"):
                        loaded = True
            except Exception:
                pass

        if not loaded:
            self._init_default_profiles()
            self.save()

        # Ingest and auto-populate known layers from LayerCatalogCache
        try:
            from .cache.layer_cache import get_layer_catalog_cache
            from .layer_index import get_layer_index
            l_cache = get_layer_catalog_cache()
            l_idx = get_layer_index()
            for prof in self.data.get("profiles", []):
                for s in prof.get("services", []):
                    stype = s.get("service_type")
                    s_url = s.get("url")
                    if stype and s_url and stype not in ("MIXED", "XYZ"):
                        if not s.get("layers"):
                            c_layers = l_cache.get_layers(stype, s_url)
                            if c_layers:
                                s["layers"] = c_layers
                        if s.get("layers"):
                            l_idx.register_service_layers(s, s["layers"])
        except Exception:
            pass

    def save(self):
        """Saves current state to JSON file."""
        try:
            os.makedirs(os.path.dirname(self.storage_file), exist_ok=True)
            with open(self.storage_file, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            return False

    def sync_current_qgis_profile(self):
        """
        Detects currently configured WMS, WFS and XYZ connections in QGIS
        and creates/updates a profile named 'Current profile', making it active on startup.
        """
        detected_services = self._detect_qgis_connections()
        if not detected_services:
            return

        current_prof = None
        for p in self.data["profiles"]:
            if p.get("id") == "prof_current" or p.get("name") in ("Current profile", "Hetke profiil", "Praegune profiil"):
                current_prof = p
                break

        if not current_prof:
            current_prof = {
                "id": "prof_current",
                "name": "Hetke profiil",
                "name_en": "Current profile",
                "description": "QGIS-i hetkel salvestatud ruumiandmeteenuste ühendused.",
                "description_en": "Currently connected geospatial services in QGIS.",
                "created_at": int(time.time()),
                "services": detected_services
            }
            # Put Current profile right at the beginning
            self.data["profiles"].insert(0, current_prof)
        else:
            # Smart sync: preserve custom user renames and settings by connection identity (type, name)
            existing_services = current_prof.get("services", [])
            existing_by_key = {
                (s.get("service_type", "").upper(), s.get("name", "").strip().lower()): s
                for s in existing_services
            }

            merged = []
            seen_keys = set()
            for d in detected_services:
                key = (d.get("service_type", "").upper(), d.get("name", "").strip().lower())
                if key in seen_keys:
                    continue
                seen_keys.add(key)

                if key in existing_by_key:
                    # Keep existing user custom name and settings
                    ex = existing_by_key[key]
                    merged.append(ex)
                else:
                    # New connection added directly in QGIS Browser!
                    merged.append(d)

            # Preserve existing user custom MIXED groups
            for ex in existing_services:
                if ex.get("service_type") == "MIXED":
                    merged.append(ex)

            # Automatically populate layers from LayerCatalogCache if available
            try:
                from .cache.layer_cache import get_layer_catalog_cache
                from .layer_index import get_layer_index
                l_cache = get_layer_catalog_cache()
                l_idx = get_layer_index()
                for s in merged:
                    if not s.get("layers"):
                        c_layers = l_cache.get_layers(s.get("service_type"), s.get("url"))
                        if c_layers:
                            s["layers"] = c_layers
                            l_idx.register_service_layers(s, c_layers)
            except Exception:
                pass

            current_prof["services"] = merged

        # Set as active profile on plugin start
        self.data["active_profile_id"] = current_prof["id"]
        self.save()
        return current_prof

    def _detect_qgis_connections(self):
        """Reads existing connections from active QGIS profile settings."""
        services = []
        found_keys = {}  # (stype, name_clean.lower()) -> item dict

        def add_or_update_conn(stype, name_clean, url_val, pref=None):
            if not url_val or not isinstance(url_val, str) or not name_clean:
                return
            clean_u = url_val.strip()
            stype_clean = stype.upper()
            name_str = name_clean.strip()

            # Connection identity in QGIS is (service_type, name)
            dedup_key = (stype_clean, name_str.lower())
            if dedup_key in found_keys:
                existing = found_keys[dedup_key]
                # If exact casing variant (e.g. Test vs test), prefer capitalized version
                if name_str[0].isupper() and not existing["name"][0].isupper():
                    existing["name"] = name_str
                if clean_u and not existing.get("url"):
                    existing["url"] = clean_u
                return

            item = {
                "id": f"current_{len(services)+1}",
                "name": name_str,
                "service_type": stype_clean,
                "url": clean_u,
                "category": "current",
                "auth_params": {},
                "preferred_settings": pref or ({"paging-enabled": True, "page-size": 1000} if stype_clean == "WFS" else {})
            }
            services.append(item)
            found_keys[dedup_key] = item

        # 1. Prioritize active QgsSettings inside running QGIS (live in-memory authoritative state)
        settings_sources = []
        is_qgis_active = False
        try:
            from qgis.core import QgsSettings
            qgs_s = QgsSettings()
            qgs_s.sync()
            settings_sources.append(qgs_s)
            is_qgis_active = True
        except Exception:
            pass

        # 2. Check direct INI files across QGIS 4 and QGIS 3 ONLY when standalone outside QGIS
        if not is_qgis_active:
            appdata = os.environ.get("APPDATA", "")
            ini_candidates = [
                os.path.join(appdata, "QGIS", "QGIS4", "profiles", "default", "QGIS", "QGIS4.ini"),
                os.path.join(appdata, "QGIS", "QGIS3", "profiles", "default", "QGIS", "QGIS3.ini")
            ]
            fmt = getattr(QSettings, 'Format', QSettings).IniFormat if hasattr(QSettings, 'Format') else getattr(QSettings, 'IniFormat', 0)

            for ini_path in ini_candidates:
                if os.path.exists(ini_path):
                    try:
                        s_ini = QSettings(ini_path, fmt)
                        s_ini.sync()
                        settings_sources.append(s_ini)
                    except Exception:
                        pass

        for s in settings_sources:
            try:
                s.sync()
            except Exception:
                pass

            has_modern_ows = False
            has_modern_xyz = False

            try:
                # 1. Modern connections in [connections]
                s.beginGroup("connections")

                # Modern OWS connections
                for stype in ("wms", "wfs", "wcs"):
                    s.beginGroup(f"ows/items/{stype}/connections/items")
                    for conn_name in s.childGroups():
                        url = s.value(f"{conn_name}/url")
                        if url and isinstance(url, str):
                            has_modern_ows = True
                            name_clean = urllib.parse.unquote(conn_name)
                            add_or_update_conn(stype.upper(), name_clean, url)
                    s.endGroup()

                # Modern XYZ tiles
                s.beginGroup("xyz/items")
                for conn_name in s.childGroups():
                    url = s.value(f"{conn_name}/url")
                    if url and isinstance(url, str):
                        has_modern_xyz = True
                        name_clean = urllib.parse.unquote(conn_name)
                        zmin = s.value(f"{conn_name}/zmin")
                        zmax = s.value(f"{conn_name}/zmax")
                        pref = {
                            "zmin": int(zmin) if zmin is not None else 0,
                            "zmax": int(zmax) if zmax is not None else 19
                        }
                        add_or_update_conn("XYZ", name_clean, url, pref)
                s.endGroup()

                s.endGroup()

                # 2. Legacy fallbacks ONLY if modern connections are empty
                if not has_modern_ows:
                    for stype, grp in [("WMS", "connections-wms"), ("WFS", "connections-wfs"), ("WCS", "connections-wcs")]:
                        s.beginGroup(grp)
                        for conn_name in s.childGroups():
                            url = s.value(f"{conn_name}/url")
                            if url and isinstance(url, str):
                                name_clean = urllib.parse.unquote(conn_name)
                                add_or_update_conn(stype, name_clean, url)
                        s.endGroup()

                if not has_modern_xyz:
                    for grp in ("qgis/connections-xyz", "connections-xyz"):
                        s.beginGroup(grp)
                        for conn_name in s.childGroups():
                            url = s.value(f"{conn_name}/url")
                            if url and isinstance(url, str):
                                name_clean = urllib.parse.unquote(conn_name)
                                add_or_update_conn("XYZ", name_clean, url, {"zmin": 0, "zmax": 19})
                        s.endGroup()

            except Exception:
                pass

            if services:
                break  # Successfully found connections

        return services

    def _init_default_profiles(self):
        """Generates starter profiles based on Estonian spatial data."""
        p_base = {
            "id": "prof_estonia_core",
            "name": "Eesti Põhikaardid & Kataster",
            "name_en": "Estonian Core Basemaps & Cadastre",
            "description": "Maa- ja Ruumiameti aluskaardid, ortofotod, kataster ja ETAK topograafia.",
            "description_en": "Estonian Land Board basemaps, orthophotos, cadastre and ETAK topography.",
            "created_at": int(time.time()),
            "services": [
                s for s in ESTONIA_SERVICES if s["id"] in (
                    "maru_alus_wms", "maru_fotokaart_wms", "maru_kataster_wms",
                    "maru_kataster_wfs", "etak_vector_wfs"
                )
            ]
        }

        p_env = {
            "id": "prof_estonia_env",
            "name": "Eesti Keskkond & Looduskaitse",
            "name_en": "Estonian Nature & Conservation",
            "description": "EELIS kaitsealad, püsielupaigad, Natura 2000, mullakaart ja veekogud.",
            "description_en": "EELIS protected areas, habitats, Natura 2000, soil map and water bodies.",
            "created_at": int(time.time()),
            "services": [
                s for s in ESTONIA_SERVICES if s["id"] in (
                    "eelis_env_wfs", "eelis_env_wms", "maru_geoloogia_wms",
                    "inspire_veekogud_wfs", "maru_alus_wms"
                )
            ]
        }

        self.data["profiles"] = [p_base, p_env]
        self.data["active_profile_id"] = p_base["id"]

    def get_profiles(self):
        """Returns list of all profiles."""
        return self.data.get("profiles", [])

    def get_profile_by_id(self, profile_id):
        """Returns profile dict by id or None."""
        for p in self.get_profiles():
            if p.get("id") == profile_id:
                return p
        return None

    def get_active_profile(self):
        """Returns currently active profile or first profile."""
        active_id = self.data.get("active_profile_id")
        if active_id:
            p = self.get_profile_by_id(active_id)
            if p:
                return p
        profiles = self.get_profiles()
        return profiles[0] if profiles else None

    def set_active_profile(self, profile_id):
        """Sets active profile id."""
        if self.get_profile_by_id(profile_id):
            self.data["active_profile_id"] = profile_id
            self.save()
            return True
        return False

    def create_profile(self, name, description=""):
        """Creates a new empty profile."""
        new_id = f"prof_{uuid.uuid4().hex[:8]}"
        new_prof = {
            "id": new_id,
            "name": name.strip(),
            "name_en": name.strip(),
            "description": description.strip(),
            "description_en": description.strip(),
            "created_at": int(time.time()),
            "services": []
        }
        self.data["profiles"].append(new_prof)
        self.data["active_profile_id"] = new_id
        self.save()
        return new_prof

    def delete_profile(self, profile_id):
        """Deletes a profile by id."""
        profiles = self.get_profiles()
        if len(profiles) <= 1:
            return False
        self.data["profiles"] = [p for p in profiles if p.get("id") != profile_id]
        if self.data.get("active_profile_id") == profile_id:
            self.data["active_profile_id"] = self.data["profiles"][0]["id"]
        self.save()
        return True

    def find_service_in_profile(self, profile_id, service_dict):
        """
        Finds existing service in profile by ID, normalized URL, or name & type.
        Returns the existing service dictionary if found, or None.
        """
        p = self.get_profile_by_id(profile_id)
        if not p or not service_dict:
            return None

        services = p.get("services", [])
        s_id = service_dict.get("id")
        raw_url = (service_dict.get("url") or "").strip()
        s_norm_url = raw_url.rstrip("/?&").lower()
        s_name = (service_dict.get("name") or "").strip().lower()
        s_type = (service_dict.get("service_type") or "").strip().upper()

        for svc in services:
            # 1. Exact ID match
            if s_id and svc.get("id") == s_id:
                return svc
            # 2. Normalized URL match
            curr_url = (svc.get("url") or "").strip().rstrip("/?&").lower()
            if s_norm_url and curr_url:
                if s_norm_url == curr_url or s_norm_url.split("?")[0] == curr_url.split("?")[0]:
                    curr_type = (svc.get("service_type") or "").strip().upper()
                    if not s_type or not curr_type or s_type == curr_type:
                        return svc
            # 3. Exact Name + Type match
            curr_name = (svc.get("name") or "").strip().lower()
            curr_type = (svc.get("service_type") or "").strip().upper()
            if s_name and curr_name and s_name == curr_name:
                if not s_type or not curr_type or s_type == curr_type:
                    return svc

        return None

    def add_layer_or_service_to_profile(self, profile_id, layer_dict=None, service_dict=None):
        """
        Adds layer and/or service to profile smartly:
        - If service already exists and layer already in service: returns (True, "layer_exists", svc, layer_dict)
        - If service exists and layer is new: appends layer to service, returns (True, "layer_added_to_existing", svc, layer_dict)
        - If service does not exist: adds service with layer (if provided), returns (True, "service_added", svc, layer_dict)
        - If only service passed and already exists: returns (True, "service_exists", svc, None)
        """
        p = self.get_profile_by_id(profile_id)
        if not p or not service_dict:
            return False, "invalid_profile", None, None

        existing_svc = self.find_service_in_profile(profile_id, service_dict)

        if existing_svc:
            if layer_dict:
                l_name = layer_dict.get("name", "")
                existing_layers = existing_svc.setdefault("layers", [])
                for el in existing_layers:
                    if el.get("name") == l_name or (l_name and el.get("name", "").lower() == l_name.lower()):
                        return True, "layer_exists", existing_svc, layer_dict
                # New layer for this existing service
                existing_layers.append(dict(layer_dict))
                self.save()
                return True, "layer_added_to_existing", existing_svc, layer_dict
            else:
                return True, "service_exists", existing_svc, None
        else:
            # Service not in profile yet
            svc_copy = dict(service_dict)
            if not svc_copy.get("id"):
                svc_copy["id"] = f"svc_{uuid.uuid4().hex[:8]}"
            if layer_dict:
                svc_copy["layers"] = [dict(layer_dict)]
            else:
                svc_copy.setdefault("layers", [])
            p.setdefault("services", []).append(svc_copy)
            self.save()
            return True, "service_added", svc_copy, layer_dict

    def add_service_to_profile(self, profile_id, service_dict):
        """Adds or updates service in specified profile."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False

        services = p.setdefault("services", [])
        s_id = service_dict.get("id") or f"svc_{uuid.uuid4().hex[:8]}"
        s_url = service_dict.get("url", "").strip()

        for idx, existing in enumerate(services):
            if existing.get("id") == s_id or (s_url and existing.get("url") == s_url):
                services[idx] = dict(service_dict)
                services[idx]["id"] = s_id
                self.save()
                return True

        item_to_add = dict(service_dict)
        item_to_add["id"] = s_id
        services.append(item_to_add)
        self.save()
        return True

    def remove_service_from_profile(self, profile_id, service_id):
        """Removes service from specified profile."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False
        services = p.get("services", [])
        p["services"] = [s for s in services if s.get("id") != service_id and s.get("name") != service_id]
        self.save()
        return True

    def create_mixed_group(self, profile_id, name):
        """Creates a new user-defined custom mixed group in the specified profile."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return None
        clean_name = (name or "").strip()
        if not clean_name:
            clean_name = "Kohandatud grupp"

        # Ensure uniqueness of name within profile
        existing_names = {s.get("name") for s in p.get("services", [])}
        unique_name = clean_name
        counter = 2
        while unique_name in existing_names:
            unique_name = f"{clean_name} ({counter})"
            counter += 1

        group_id = f"mixed_{uuid.uuid4().hex[:8]}"
        group_item = {
            "id": group_id,
            "name": unique_name,
            "name_en": unique_name,
            "service_type": "MIXED",
            "agency": "Kasutaja kohandatud",
            "description": "Kasutaja koostatud kihtide kogumik erinevatest ruumiandmeteenustest.",
            "url": "",
            "layers": []
        }
        p.setdefault("services", []).append(group_item)
        self.save()
        return group_item

    def get_mixed_groups(self, profile_id):
        """Returns list of MIXED group dicts in specified profile."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return []
        return [s for s in p.get("services", []) if s.get("service_type") == "MIXED"]

    def add_layer_to_mixed_group(self, profile_id, group_id_or_name, layer_dict, parent_service_dict=None):
        """
        Adds a layer to a user-defined custom mixed group.
        Preserves complete parent service metadata for each layer so it can be rendered and mapped on demand.
        Returns (success_bool, status_str, group_item).
        """
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False, "profile_not_found", None

        group = None
        for s in p.get("services", []):
            if s.get("service_type") == "MIXED" and (s.get("id") == group_id_or_name or s.get("name") == group_id_or_name):
                group = s
                break

        if not group:
            return False, "group_not_found", None

        # Build clean layer entry
        layer_copy = dict(layer_dict)
        l_name = layer_copy.get("name", "")

        # Determine parent service metadata
        parent_svc = parent_service_dict or layer_copy.get("parent_service")
        if parent_svc:
            layer_copy["parent_service"] = dict(parent_svc)
            layer_copy["service_type"] = parent_svc.get("service_type", layer_copy.get("service_type", "WMS"))
            layer_copy["service_url"] = parent_svc.get("url", layer_copy.get("service_url", ""))
            layer_copy["service_name"] = parent_svc.get("name", layer_copy.get("service_name", ""))
            layer_copy["agency"] = parent_svc.get("agency", layer_copy.get("agency", ""))

        target_url = layer_copy.get("service_url", "")

        # Check for duplicate layer in group
        layers = group.setdefault("layers", [])
        for existing in layers:
            if existing.get("name") == l_name and existing.get("service_url", "") == target_url:
                return False, "duplicate", group

        layers.append(layer_copy)
        self.save()
        return True, "added", group

    def remove_layer_from_mixed_group(self, profile_id, group_id_or_name, layer_name):
        """Removes a layer from a MIXED group."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False
        for s in p.get("services", []):
            if s.get("service_type") == "MIXED" and (s.get("id") == group_id_or_name or s.get("name") == group_id_or_name):
                s["layers"] = [l for l in s.get("layers", []) if l.get("name") != layer_name]
                self.save()
                return True
        return False

    def rename_service_in_profile(self, profile_id, service_id_or_name, new_name):
        """Renames a service in specified profile and tracks previous names for QGIS sync."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False
        clean_name = new_name.strip()
        if not clean_name:
            return False
        for s in p.get("services", []):
            if s.get("id") == service_id_or_name or s.get("name") == service_id_or_name:
                old_name = s.get("name")
                if old_name != clean_name:
                    s.setdefault("previous_names", []).append(old_name)
                    s["name"] = clean_name
                    s["name_en"] = clean_name
                    self.save()
                    return True
        return False

    def get_hidden_catalog_urls(self):
        """Returns set of URLs hidden from service catalog by user."""
        return set(self.data.get("hidden_catalog_urls", []))

    def hide_catalog_url(self, url):
        """Adds URL to hidden catalog list."""
        if not url:
            return
        hidden = set(self.data.get("hidden_catalog_urls", []))
        hidden.add(url.strip())
        self.data["hidden_catalog_urls"] = list(hidden)
        self.save()

    def unhide_all_catalog_urls(self):
        """Restores all hidden services in catalog."""
        self.data["hidden_catalog_urls"] = []
        self.save()

    def update_service_layers(self, profile_id, service_id_or_url, layers):
        """Caches or updates layer list for a service in specified profile."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False
        for s in p.get("services", []):
            if s.get("id") == service_id_or_url or s.get("url") == service_id_or_url:
                s["layers"] = layers
                self.save()
                return True
        return False

    # -------------------------------------------------------------------------
    # Import / Export / Share
    # -------------------------------------------------------------------------
    def export_profile_json(self, profile_id, file_path):
        """Exports profile to JSON file."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False
        export_payload = {
            "format": "GeoProfileHub",
            "version": "1.0",
            "profile": p
        }
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(export_payload, f, ensure_ascii=False, indent=2)
        return True

    def import_profile_json(self, file_path):
        """Imports profile from JSON file."""
        with open(file_path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        profile_data = payload.get("profile") if "profile" in payload else payload
        if not isinstance(profile_data, dict) or "name" not in profile_data:
            raise ValueError("Invalid GeoProfile JSON format")

        profile_data["id"] = f"prof_{uuid.uuid4().hex[:8]}"
        profile_data["name"] = f"{profile_data.get('name', 'Imported')} (Imported)"
        self.data["profiles"].append(profile_data)
        self.data["active_profile_id"] = profile_data["id"]
        self.save()
        return profile_data

    def export_profile_qgis_xml(self, profile_id, file_path):
        """Exports profile to standard QGIS XML connections file."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return False

        root = ET.Element("qgsConnections", attrib={"version": "1.0"})
        wms_group = ET.SubElement(root, "wms")
        wfs_group = ET.SubElement(root, "wfs")
        wcs_group = ET.SubElement(root, "wcs")
        xyz_group = ET.SubElement(root, "xyz")

        for s in p.get("services", []):
            st = s.get("service_type", "WMS").upper()
            name = s.get("name", "Service")
            url = s.get("url", "")
            auth_params = s.get("auth_params", {})
            pref = s.get("preferred_settings", {})

            if st in ("WMS", "WMTS"):
                ET.SubElement(wms_group, "wms", attrib={
                    "name": name,
                    "url": url,
                    "authcfg": auth_params.get("authcfg", ""),
                    "ignoreReportedLayerExtents": str(pref.get("reported-layer-extents", False)).lower()
                })
            elif st == "WFS":
                ET.SubElement(wfs_group, "wfs", attrib={
                    "name": name,
                    "url": url,
                    "paging-enabled": str(pref.get("paging-enabled", True)).lower(),
                    "pageSize": str(pref.get("page-size", 1000)),
                    "version": pref.get("version", "auto"),
                    "authcfg": auth_params.get("authcfg", "")
                })
            elif st == "WCS":
                ET.SubElement(wcs_group, "wcs", attrib={
                    "name": name,
                    "url": url,
                    "authcfg": auth_params.get("authcfg", "")
                })
            elif st == "XYZ":
                ET.SubElement(xyz_group, "xyz", attrib={
                    "name": name,
                    "url": url,
                    "zmin": str(pref.get("zmin", 0)),
                    "zmax": str(pref.get("zmax", 19))
                })

        tree = ET.ElementTree(root)
        tree.write(file_path, encoding="utf-8", xml_declaration=True)
        return True

    def import_profile_qgis_xml(self, file_path, profile_name="QGIS Imported Connections"):
        """Imports standard QGIS connections XML file into a new profile."""
        tree = ET.parse(file_path)
        root = tree.getroot()
        services = []

        for wms in root.findall(".//wms") + root.findall(".//WMS"):
            name = wms.attrib.get("name")
            url = wms.attrib.get("url")
            if name and url:
                services.append({
                    "id": f"xml_wms_{uuid.uuid4().hex[:6]}",
                    "name": name,
                    "service_type": "WMS",
                    "url": url,
                    "category": "custom",
                    "auth_params": {"authcfg": wms.attrib.get("authcfg", "")},
                    "preferred_settings": {"dpi-mode": 7}
                })

        for wfs in root.findall(".//wfs") + root.findall(".//WFS"):
            name = wfs.attrib.get("name")
            url = wfs.attrib.get("url")
            if name and url:
                paging = wfs.attrib.get("paging-enabled", "true").lower() == "true"
                services.append({
                    "id": f"xml_wfs_{uuid.uuid4().hex[:6]}",
                    "name": name,
                    "service_type": "WFS",
                    "url": url,
                    "category": "custom",
                    "auth_params": {"authcfg": wfs.attrib.get("authcfg", "")},
                    "preferred_settings": {
                        "paging-enabled": paging,
                        "page-size": int(wfs.attrib.get("pageSize", 1000)),
                        "version": wfs.attrib.get("version", "auto")
                    }
                })

        for wcs in root.findall(".//wcs") + root.findall(".//WCS"):
            name = wcs.attrib.get("name")
            url = wcs.attrib.get("url")
            if name and url:
                services.append({
                    "id": f"xml_wcs_{uuid.uuid4().hex[:6]}",
                    "name": name,
                    "service_type": "WCS",
                    "url": url,
                    "category": "custom",
                    "auth_params": {"authcfg": wcs.attrib.get("authcfg", "")},
                    "preferred_settings": {}
                })

        new_prof = self.create_profile(profile_name, "Imporditud QGIS XML ühenduste failist.")
        new_prof["services"] = services
        self.save()
        return new_prof

    def share_profile_string(self, profile_id):
        """Generates compact JSON string representation for clipboard sharing."""
        p = self.get_profile_by_id(profile_id)
        if not p:
            return ""
        return json.dumps({"format": "GeoProfileHub", "profile": p}, ensure_ascii=False)
