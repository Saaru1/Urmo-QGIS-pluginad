# -*- coding: utf-8 -*-
"""
URL utilities for GeoProfile Hub.
Provides canonical normalization, validation, and OGC endpoint sanitization.
"""

import urllib.parse
import re


def normalize_service_url(url, service_type=None):
    """
    Normalizes a geospatial service URL for consistent matching and deduplication.
    
    Rules:
    - Strips whitespace and markdown link artifacts.
    - Handles protocol-relative URLs (e.g. //example.com -> https://example.com).
    - Lowercases scheme and hostname.
    - Drops default ports (:80 on http, :443 on https).
    - Removes trailing slashes from path.
    - For OGC services (WMS, WFS, WCS, WMTS), strips transient GetCapabilities query params.
    - For XYZ tile services, preserves tile placeholders ({x}, {y}, {z}) and essential template query parameters.
    """
    if not url:
        return ""

    u = str(url).strip()
    if not u:
        return ""

    # Clean markdown link formatting (e.g. [http://...](http://...))
    if "[" in u and "](" in u:
        m = re.search(r"\]\((https?://[^\)]+)\)", u)
        if m:
            u = m.group(1)
        else:
            u = u.replace("[", "").replace("]", "")
    elif u.startswith("[") and u.endswith("]"):
        u = u[1:-1]

    # Protocol-relative fix
    if u.startswith("//"):
        u = "https:" + u
    elif not (u.startswith("http://") or u.startswith("https://") or u.startswith("ftp://")):
        u = "https://" + u

    try:
        parsed = urllib.parse.urlsplit(u)
        scheme = parsed.scheme.lower()
        netloc = parsed.netloc.lower()

        # Drop default ports
        if scheme == "http" and netloc.endswith(":80"):
            netloc = netloc[:-3]
        elif scheme == "https" and netloc.endswith(":443"):
            netloc = netloc[:-4]

        path = parsed.path.rstrip("/").lower()
        if not path:
            path = ""

        stype = (service_type or "").upper()
        is_xyz = stype == "XYZ" or ("{x}" in u and "{y}" in u) or ("{z}" in u)

        if is_xyz:
            # Preserve query string for XYZ tiles (e.g. lyrs=s&x={x}&y={y}&z={z})
            query = parsed.query
            normalized = urllib.parse.urlunsplit((scheme, netloc, path, query, ""))
            return normalized

        # For OGC services, strip out GetCapabilities / transient query params
        if parsed.query:
            query_params = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
            filtered = []
            for k, v in query_params:
                k_lower = k.lower()
                if k_lower in ("service", "request", "version", "acceptversions", "exceptions"):
                    continue
                filtered.append((k, v))

            if filtered:
                filtered.sort(key=lambda item: item[0].lower())
                query = urllib.parse.urlencode(filtered)
            else:
                query = ""
        else:
            query = ""

        normalized = urllib.parse.urlunsplit((scheme, netloc, path, query, ""))
        return normalized.rstrip("?")

    except Exception:
        # Fallback to robust basic split on malformed URLs
        return u.split("?")[0].strip().rstrip("/").lower()


def is_valid_url(url):
    """Validates that URL has a valid web scheme and network location."""
    if not url or not isinstance(url, str):
        return False
    u = url.strip()
    try:
        p = urllib.parse.urlparse(u)
        return p.scheme in ("http", "https") and bool(p.netloc)
    except Exception:
        return False


def get_ogc_capabilities_url(base_url, service_type, version=None):
    """
    Constructs a standards-compliant GetCapabilities URL for the specified OGC service.
    """
    if not base_url:
        return ""
    stype = (service_type or "WMS").upper()
    clean_base = base_url.split("?")[0].strip().rstrip("/")
    sep = "?"

    if stype == "WMS":
        ver = version or "1.3.0"
        return f"{clean_base}?SERVICE=WMS&REQUEST=GetCapabilities&VERSION={ver}"
    elif stype == "WFS":
        ver = version or "2.0.0"
        return f"{clean_base}?SERVICE=WFS&REQUEST=GetCapabilities&VERSION={ver}"
    elif stype == "WCS":
        ver = version or "1.0.0"
        return f"{clean_base}?SERVICE=WCS&REQUEST=GetCapabilities&VERSION={ver}"
    elif stype == "WMTS":
        return f"{clean_base}?SERVICE=WMTS&REQUEST=GetCapabilities"
    elif stype == "CSW":
        return f"{clean_base}?SERVICE=CSW&REQUEST=GetCapabilities"

    return f"{clean_base}?REQUEST=GetCapabilities"
