# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Estonian Geoportal CSW Client
Queries the official metadata catalogue at metadata.geoportaal.ee via OGC CSW 2.0.2.
"""

import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import re

GEOPORTAAL_CSW_URL = "https://metadata.geoportaal.ee/geonetwork/srv/est/csw"

NAMESPACES = {
    "csw": "http://www.opengis.net/cat/csw/2.0.2",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dct": "http://purl.org/dc/terms/",
    "ows": "http://www.opengis.net/ows",
    "gmd": "http://www.isotc211.org/2005/gmd",
    "ogc": "http://www.opengis.net/ogc"
}


class CswClient:
    """Client for querying Estonian Geoportal GeoNetwork CSW endpoint."""

    def __init__(self, endpoint_url=GEOPORTAAL_CSW_URL, timeout=8):
        self.endpoint_url = endpoint_url
        self.timeout = timeout

    def search_records(self, search_text="", max_records=20, start_position=1):
        """
        Query CSW GetRecords for spatial data services via standard OGC XML POST.
        Returns a list of standardized service dicts.
        """
        clean_text = (search_text or "").strip()
        filter_xml = ""
        if clean_text:
            term = clean_text
            # Preserve full noun for specific words like "loomad" to avoid verbal false positives ("loomiseks")
            if len(clean_text) > 5 and clean_text.endswith("ad") and clean_text.lower() != "loomad":
                term = clean_text[:-2]
            elif len(clean_text) > 5 and clean_text.endswith("id"):
                term = clean_text[:-2]

            filter_xml = f"""<csw:Constraint version="1.1.0">
      <ogc:Filter>
        <ogc:PropertyIsLike wildCard="*" singleChar="?" escapeChar="!">
          <ogc:PropertyName>AnyText</ogc:PropertyName>
          <ogc:Literal>*{term}*</ogc:Literal>
        </ogc:PropertyIsLike>
      </ogc:Filter>
    </csw:Constraint>"""

        post_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<csw:GetRecords xmlns:csw="http://www.opengis.net/cat/csw/2.0.2" xmlns:ogc="http://www.opengis.net/ogc" service="CSW" version="2.0.2" resultType="results" maxRecords="{max_records}" startPosition="{start_position}">
  <csw:Query typeNames="csw:Record">
    <csw:ElementSetName>full</csw:ElementSetName>
    {filter_xml}
  </csw:Query>
</csw:GetRecords>"""

        req = urllib.request.Request(
            self.endpoint_url,
            data=post_xml.encode("utf-8"),
            headers={
                "Content-Type": "application/xml",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) QGIS-GeoKataloog/1.8",
                "Accept": "application/xml, text/xml"
            }
        )

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                xml_data = resp.read()
                return self._parse_csw_response(xml_data)
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "records": []
            }

    def _parse_csw_response(self, xml_bytes):
        """Parse CSW XML response into uniform record structures."""
        try:
            root = ET.fromstring(xml_bytes)
        except Exception as e:
            return {"success": False, "error": f"XML parse error: {e}", "records": []}

        records_found = []
        csw_records = (
            root.findall(".//{http://www.opengis.net/cat/csw/2.0.2}Record")
            or root.findall(".//{http://www.opengis.net/cat/csw/2.0.2}SummaryRecord")
            or root.findall(".//Record")
        )

        for rec in csw_records:
            title = rec.findtext(".//{http://purl.org/dc/elements/1.1/}title") or "Unnamed Service"
            abstract = rec.findtext(".//{http://purl.org/dc/elements/1.1/}description") or ""
            identifier = rec.findtext(".//{http://purl.org/dc/elements/1.1/}identifier") or ""

            # Extract URIs
            uri_elems = rec.findall(".//{http://purl.org/dc/elements/1.1/}URI")
            service_urls = []
            for u in uri_elems:
                if u.text:
                    url_clean = u.text.strip()
                    desc = u.attrib.get("description", "")
                    name = u.attrib.get("name", "")
                    protocol = u.attrib.get("protocol", "")
                    service_urls.append({
                        "url": url_clean,
                        "description": desc,
                        "name": name,
                        "protocol": protocol
                    })

            # Determine service type (WMS, WFS, WMTS, etc.)
            service_type = "UNKNOWN"
            primary_url = ""

            for su in service_urls:
                u_str = su["url"].lower()
                proto = su["protocol"].lower()
                if "wfs" in u_str or "wfs" in proto:
                    service_type = "WFS"
                    primary_url = su["url"]
                    break
                elif "wms" in u_str or "wms" in proto:
                    service_type = "WMS"
                    primary_url = su["url"]
                    break
                elif "wmts" in u_str or "wmts" in proto:
                    service_type = "WMTS"
                    primary_url = su["url"]
                    break

            if not primary_url and service_urls:
                primary_url = service_urls[0]["url"]

            # Infer type from title if unknown
            if service_type == "UNKNOWN":
                if "(wfs)" in title.lower():
                    service_type = "WFS"
                elif "(wms)" in title.lower():
                    service_type = "WMS"
                elif "(wmts)" in title.lower():
                    service_type = "WMTS"

            # Clean URL: strip request=GetCapabilities if present
            clean_endpoint = primary_url
            if "?" in clean_endpoint:
                base, query = clean_endpoint.split("?", 1)
                clean_endpoint = base.rstrip("?")

            record_item = {
                "id": f"csw_{identifier[:16]}",
                "name": title,
                "title_en": title,
                "agency": "Geoportaal / CSW",
                "category": "csw_live",
                "service_type": service_type if service_type != "UNKNOWN" else "WMS",
                "url": clean_endpoint or primary_url,
                "raw_url": primary_url,
                "description": abstract[:300] if abstract else "Geoportaali metaandmetest leitud teenus.",
                "description_en": abstract[:300] if abstract else "Service discovered from Estonian Geoportal.",
                "all_uris": service_urls
            }
            if primary_url:
                records_found.append(record_item)

        return {
            "success": True,
            "total_records": len(records_found),
            "records": records_found
        }
