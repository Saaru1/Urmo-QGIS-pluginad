# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Curated Geospatial Services Presets (Estonia & Global)
Pre-configured verified public services with metadata, categories, and preferred settings.
"""

import os
import json

ESTONIA_SERVICES = [
    # -------------------------------------------------------------------------
    # 1. Maa- ja Ruumiamet - Aluskaardid
    # -------------------------------------------------------------------------
    {
        "id": "maru_alus_wms",
        "name": "Maa- ja Ruumiamet: Aluskaardid",
        "title_en": "Estonian Land Board: Basemaps",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WMS",
        "url": "https://kaart.maaamet.ee/wms/alus",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857", "EPSG:4326"],
        "description": "Eesti põhikaart (värviline, halltoonides, reljeefivarjutusega), hübriidkaart, halduspiirid, teedevõrk ja hüdrograafia.",
        "description_en": "Estonian basic map (colored, grayscale, shaded relief), hybrid map, administrative boundaries, roads and hydrography.",
        "layers_preview": ["pohikaart", "vreljeef", "mustvalge", "halduspiirid", "teed", "vesi"],
        "preferred_settings": {
            "dpi-mode": 7,
            "smooth-pixmap-transform": False,
            "reported-layer-extents": False,
            "invert-axis-orientation": False
        }
    },
    {
        "id": "maru_fotokaart_wms",
        "name": "Maa- ja Ruumiamet: Fotokaart (Ortofotod)",
        "title_en": "Estonian Land Board: Orthophotos",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WMS",
        "url": "https://kaart.maaamet.ee/wms/fotokaart",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857", "EPSG:4326"],
        "description": "Kõrge resolutsiooniga värvilised ja CIR (värvi-infrapuna) ortofotod kogu Eesti kohta, samuti metsanduslikud ortofotod.",
        "description_en": "High resolution true-color and color-infrared (CIR) aerial orthophotos of Estonia.",
        "layers_preview": ["EESTIFOTO", "cir", "metsafoto"],
        "preferred_settings": {
            "dpi-mode": 7,
            "smooth-pixmap-transform": False,
            "reported-layer-extents": False
        }
    },
    {
        "id": "maru_ajaloolised_wms",
        "name": "Maa- ja Ruumiamet: Ajaloolised kaardid",
        "title_en": "Estonian Land Board: Historical Maps",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WMS",
        "url": "https://kaart.maaamet.ee/wms/ajalooline",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857", "EPSG:4326"],
        "description": "Eesti ajaloolised topograafilised kaardid, verstakaardid ja endiste aastate ortofotod.",
        "description_en": "Historical topographic maps, verst maps and past aerial orthophotos of Estonia.",
        "layers_preview": ["nsvl_topokaart", "verstakaart", "ew_topokaart"],
        "preferred_settings": {
            "dpi-mode": 7,
            "smooth-pixmap-transform": False
        }
    },
    {
        "id": "maru_aadressid_wms",
        "name": "Maa- ja Ruumiamet: Aadressiandmed",
        "title_en": "Estonian Land Board: Address Data",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WMS",
        "url": "https://kaart.maaamet.ee/wms/aadressid",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "Eesti aadressiandmete süsteemi (ADS) aadressipunktid, hoone- ja koha-aadressid.",
        "description_en": "Estonian address database (ADS) address points, building addresses and place names.",
        "layers_preview": ["aadressid", "hooned"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },
    {
        "id": "maru_korgus_wcs",
        "name": "Maa- ja Ruumiamet: Kõrgusmudel (WCS DTM)",
        "title_en": "Estonian Land Board: Elevation DTM (WCS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WCS",
        "url": "https://teenus.maaamet.ee/ows/wcs-dtm",
        "version": "1.0.0",
        "crs": ["EPSG:3301", "EPSG:4326"],
        "description": "Kogu Eesti kõrgusandmed (DTM): 1m, 10m ja 25m sammuga raster-kõrgusmudelid.",
        "description_en": "Estonian National Digital Terrain Models (DTM) with 1m, 10m and 25m grid resolutions.",
        "layers_preview": ["dtm-1", "dtm-10", "dtm-25"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },

    # -------------------------------------------------------------------------
    # 2. Kataster ja Kitsendused
    # -------------------------------------------------------------------------
    {
        "id": "maru_kataster_wms",
        "name": "Maa- ja Ruumiamet: Katastriüksused (WMS)",
        "title_en": "Estonian Land Board: Cadastral Parcels (WMS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "cadastre",
        "service_type": "WMS",
        "url": "https://kaart.maaamet.ee/wms/kataster",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "Ametlik maakatastri kaart: katastriüksuste piirid, katastritunnused, piiripunktid.",
        "description_en": "Official land cadastre map: parcel boundaries, cadastre codes, boundary marks.",
        "layers_preview": ["ky", "piirid", "punktid"],
        "preferred_settings": {
            "dpi-mode": 7,
            "smooth-pixmap-transform": False
        }
    },
    {
        "id": "maru_kataster_wfs",
        "name": "Maa- ja Ruumiamet: Kataster Vektor (WFS)",
        "title_en": "Estonian Land Board: Cadastre Vector (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "cadastre",
        "service_type": "WFS",
        "url": "https://gsavalik.envir.ee/geoserver/kataster/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Katastriandmete vektorandmed (GeoServer WFS): katastriüksused, piirid, kitsenduste mõjualad.",
        "description_en": "Cadastral vector data (GeoServer WFS): parcel polygons, attributes, restrictions.",
        "layers_preview": ["kataster:katastriuksus", "kataster:piiripunktid", "kataster:geom_vead"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },
    {
        "id": "maru_kitsendused_wfs",
        "name": "Maa- ja Ruumiamet: Kitsenduste kaart (WFS)",
        "title_en": "Estonian Land Board: Restrictions & Protections (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "cadastre",
        "service_type": "WFS",
        "url": "https://gsavalik.envir.ee/geoserver/kitsendused/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Kitsendusi põhjustavad objektid (KPO) ja kaitsevööndid (looduskaitse, veekaitse, tehnovõrgud, tehnorajatised).",
        "description_en": "Public spatial restrictions and protection zones (nature conservation, water protection, utilities).",
        "layers_preview": ["kitsendused:KMA_AVALIK_WMS_VEKTOR", "kitsendused:metsakas_kpois_RANNA_VOI_KALDA_PIIRANGUVOOND"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },

    # -------------------------------------------------------------------------
    # 3. Eesti Haldus- ja Asustusjaotus (EHAK)
    # -------------------------------------------------------------------------
    {
        "id": "maru_haldusjaotus_wfs",
        "name": "Maa- ja Ruumiamet: Eesti haldus- ja asustusjaotus (WFS)",
        "title_en": "Estonian Land Board: Administrative & Settlement Units EHAK (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WFS",
        "url": "https://teenus-ogc-ms.geoportaal.ee/ows/ajakohane-haldusjaotus",
        "version": "2.0.0",
        "crs": ["EPSG:3301", "EPSG:3857", "EPSG:4326"],
        "description": "Eesti ametlik haldus- ja asustusjaotus (maakonnad, omavalitsused, asustusüksused, EHAK). Andmed uuenevad kord kuus.",
        "description_en": "Official Estonian administrative and settlement units (EHAK: counties, municipalities, villages/towns). Updated monthly.",
        "layers_preview": ["ms:omavalitsus_merel", "ms:maakond_merel", "ms:asustus_pind", "ms:omavalitsus_valispiirita"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },
    {
        "id": "maru_haldusjaotus_wms",
        "name": "Maa- ja Ruumiamet: Eesti haldus- ja asustusjaotus (WMS)",
        "title_en": "Estonian Land Board: Administrative & Settlement Units EHAK (WMS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "base",
        "service_type": "WMS",
        "url": "https://teenus-ogc-ms.geoportaal.ee/ows/ajakohane-haldusjaotus",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "Eesti haldus- ja asustusüksuste piirid kaardipildina (WMS aluskaart, EHAK).",
        "description_en": "Estonian administrative and settlement unit boundaries as WMS map.",
        "layers_preview": ["omavalitsus_merel", "maakond_merel", "asustus_pind"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },

    # -------------------------------------------------------------------------
    # 4. Eesti Topograafia Andmekogu (ETAK)
    # -------------------------------------------------------------------------
    {
        "id": "etak_vector_wfs",
        "name": "ETAK: Eesti Topograafia Andmekogu (WFS)",
        "title_en": "ETAK: Estonian Topographic Database (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "topo",
        "service_type": "WFS",
        "url": "https://gsavalik.envir.ee/geoserver/etak/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Riiklik topograafia andmekogu: hooned, rajatised, teed, veekogud, vooluveekogud, elektriliinid.",
        "description_en": "National topographic database: buildings, facilities, roads, hydrography, power lines.",
        "layers_preview": ["etak:e_401_hoone_ka", "etak:e_501_tee_j", "etak:e_202_vooluveekogu_j", "etak:e_601_elektriliin_j"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },
    {
        "id": "etak_vector_wms",
        "name": "ETAK: Eesti Topograafia Andmekogu (WMS)",
        "title_en": "ETAK: Estonian Topographic Database (WMS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "topo",
        "service_type": "WMS",
        "url": "https://gsavalik.envir.ee/geoserver/etak/wms",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "ETAK kaardikihtide pilditeenus.",
        "description_en": "ETAK topographic map viewing service.",
        "layers_preview": ["etak:etak"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },

    # -------------------------------------------------------------------------
    # 5. Keskkond, Mets & Loodus (EELIS & KEMIT)
    # -------------------------------------------------------------------------
    {
        "id": "eelis_env_wfs",
        "name": "EELIS: Looduskaitse ja Keskkond (WFS)",
        "title_en": "EELIS: Nature Conservation & Environment (WFS)",
        "agency": "Keskkonnaagentuur",
        "category": "env",
        "service_type": "WFS",
        "url": "https://gsavalik.envir.ee/geoserver/eelis/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Eesti looduse infosüsteem (EELIS): kaitsealad, hoiualad, püsielupaigad, kaitsealused liigid (loomad III, taimed III, seened III), Natura 2000 alad, veekogud ja elupaigad.",
        "description_en": "Estonian nature information system: protected areas, conservation zones, Natura 2000, protected species (animals, plants, fungi) and habitats.",
        "layers_preview": ["eelis:kr_ala", "eelis:kr_vyond", "eelis:kr_loomad_iii", "eelis:kr_taimed_iii", "eelis:kr_seened_samblikud_iii", "eelis:kr_kudemisala", "eelis:kr_vep", "eelis:natura_linnualad", "eelis:natura_loodusalad"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },
    {
        "id": "envir_general_wfs",
        "name": "Keskkonnaportaal & KEMIT: Avalik WFS (Envir)",
        "title_en": "Ministry of Climate / KEMIT: Public WFS (Envir)",
        "agency": "Keskkonnaagentuur",
        "category": "env",
        "service_type": "WFS",
        "url": "https://gsavalik.envir.ee/geoserver/wfs",
        "version": "1.1.0",
        "crs": ["EPSG:3301"],
        "description": "Kliimaministeeriumi ja Keskkonnaagentuuri koond-WFS: looduskaitse, loomad (loomad III), taimed, seened, metsandus, maapõu, vesi ja kitsendused.",
        "description_en": "Comprehensive environmental WFS: nature conservation, protected species (animals III, plants, fungi), forestry, geology and restrictions.",
        "layers_preview": ["eelis:kr_loomad_iii", "eelis:kr_taimed_iii", "eelis:kr_ala", "kponahtused:kpo_avalik_looduskaitse_10007"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "1.1.0"
        }
    },
    {
        "id": "eelis_env_wms",
        "name": "EELIS: Looduskaitse ja Keskkond (WMS)",
        "title_en": "EELIS: Nature Conservation & Environment (WMS)",
        "agency": "Keskkonnaagentuur",
        "category": "env",
        "service_type": "WMS",
        "url": "https://gsavalik.envir.ee/geoserver/eelis/wms",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "Eesti looduse infosüsteemi kaardikihid pildina.",
        "description_en": "Estonian nature information system map layers as WMS images.",
        "layers_preview": ["eelis:kr_ala", "eelis:kr_vyond"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },
    {
        "id": "kemit_metsaregister_wfs",
        "name": "Keskkonnaagentuur: Metsaregister (WFS)",
        "title_en": "Environment Agency: Forest Register (WFS)",
        "agency": "Keskkonnaagentuur",
        "category": "env",
        "service_type": "WFS",
        "url": "https://gsavalik.envir.ee/geoserver/metsaregister/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Riikliku metsaregistri avalikud vektorandmed: kehtivad metsateatised, kahjustused, metsakaitseekspertiisid.",
        "description_en": "State forest register public vector data: valid notifications, damages, assessments.",
        "layers_preview": ["metsaregister:teatis", "metsaregister:kahjustused"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },
    {
        "id": "maru_geoloogia_wms",
        "name": "Maa- ja Ruumiamet: Geoloogia & Mullakaart",
        "title_en": "Estonian Land Board: Geology & Soil Map",
        "agency": "Maa- ja Ruumiamet",
        "category": "env",
        "service_type": "WMS",
        "url": "https://kaart.maaamet.ee/wms/muld",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "Eesti suuremõõtkavaline mullakaart (1:10 000), mullalõimis ja boniteet.",
        "description_en": "Large-scale soil map of Estonia (1:10,000), soil texture and quality.",
        "layers_preview": ["muld", "boniteet"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },

    # -------------------------------------------------------------------------
    # 6. Põllumajandus & PRIA
    # -------------------------------------------------------------------------
    {
        "id": "pria_massiivid_wfs",
        "name": "PRIA: Põllumassiivid ja toetused (WFS)",
        "title_en": "PRIA: Agricultural Field Parcels & Aid (WFS)",
        "agency": "PRIA",
        "category": "agri",
        "service_type": "WFS",
        "url": "https://kls.pria.ee/geoserver/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "PRIA ametlikud põllumassiivid, maastikuelemendid ja toetusõiguslikud maad vektorkujul.",
        "description_en": "PRIA official agricultural field parcel boundaries, landscape elements, and eligible areas.",
        "layers_preview": ["pria:pollumassiivid", "pria:maastikuelemendid"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },
    {
        "id": "pria_massiivid_wms",
        "name": "PRIA: Põllumassiivide register (WMS)",
        "title_en": "PRIA: Agricultural Field Parcels (WMS)",
        "agency": "PRIA",
        "category": "agri",
        "service_type": "WMS",
        "url": "https://kls.pria.ee/geoserver/ows",
        "version": "1.3.0",
        "crs": ["EPSG:3301", "EPSG:3857"],
        "description": "Põllumajanduse Registrite ja Informatsiooni Ameti põllumassiivid, maastikuelemendid ja toetusõiguslikud maad.",
        "description_en": "PRIA agricultural field boundaries, landscape elements and eligible areas.",
        "layers_preview": ["pria:pollumassiivid", "pria:maastikuelemendid"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },
    {
        "id": "pria_ajalooline_wfs",
        "name": "PRIA: Ajaloolised põllumassiivid (GSAA WFS)",
        "title_en": "PRIA: Historical Agricultural Parcels (WFS)",
        "agency": "PRIA",
        "category": "agri",
        "service_type": "WFS",
        "url": "https://kls.pria.ee/geoserver/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Ajaloolised põllumassiivid ja taotluste piirid aastate lõikes (2008–2024).",
        "description_en": "Historical agricultural field parcel boundaries by application year (2008–2024).",
        "layers_preview": ["inspire_gsaa:LU.GSAA.AGRICULTURAL_PARCELS"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },

    # -------------------------------------------------------------------------
    # 7. Kultuurimälestised & Muinsuskaitse
    # -------------------------------------------------------------------------
    {
        "id": "muinsus_wms",
        "name": "Muinsuskaitseamet: Kultuurimälestiste register",
        "title_en": "National Heritage Board: Monuments Register",
        "agency": "Muinsuskaitseamet",
        "category": "heritage",
        "service_type": "WMS",
        "url": "https://register.muinas.ee/wms",
        "version": "1.3.0",
        "crs": ["EPSG:3301"],
        "description": "Eesti arhitektuuri-, ajaloo-, kunsti- ja arheoloogiamälestised ning nende kaitsevööndid.",
        "description_en": "Protected architectural, historical, art and archaeological monuments and zones.",
        "layers_preview": ["malestised", "kaitsevoondid"],
        "preferred_settings": {
            "dpi-mode": 7
        }
    },

    # -------------------------------------------------------------------------
    # 8. Planeeringud & INSPIRE
    # -------------------------------------------------------------------------
    {
        "id": "inspire_planeeringud_wfs",
        "name": "INSPIRE: Üldplaneeringu maakasutus (WFS)",
        "title_en": "INSPIRE: Spatial Planning Land Use (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "planning",
        "service_type": "WFS",
        "url": "https://inspire.geoportaal.ee/geoserver/LU_planeeringud/ows",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "Maa- ja Ruumiameti planeeringute infosüsteemi üldplaneeringute järgsed juhtotstarbed ja tiheasustusalad.",
        "description_en": "Comprehensive planning zones and designated urban areas from spatial planning system.",
        "layers_preview": ["LU_planeeringud:LU.ExistingLandUse"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 500,
            "version": "2.0.0"
        }
    },
    {
        "id": "inspire_veekogud_wfs",
        "name": "INSPIRE: Hüdrograafia ja Paisud (WFS)",
        "title_en": "INSPIRE: Hydrography & Dams (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "env",
        "service_type": "WFS",
        "url": "https://inspire.geoportaal.ee/geoserver/HY_pais/wfs",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "INSPIRE spetsifikatsioonile vastavad Eesti paisud ja hüdrograafia objektid.",
        "description_en": "Estonian dams and hydrographic features conforming to INSPIRE specification.",
        "layers_preview": ["HY_pais:HY.PhysicalWaters.ManMadeObject"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 500,
            "version": "2.0.0"
        }
    },
    {
        "id": "inspire_haldus_wfs",
        "name": "INSPIRE: Haldusüksused AdministrativeUnits (WFS)",
        "title_en": "INSPIRE: Administrative Units (WFS)",
        "agency": "Maa- ja Ruumiamet",
        "category": "planning",
        "service_type": "WFS",
        "url": "https://inspire.geoportaal.ee/geoserver/AU_haldusyksused/wfs",
        "version": "2.0.0",
        "crs": ["EPSG:3301"],
        "description": "INSPIRE spetsifikatsioonile vastavad Eesti haldusüksused (AU.AdministrativeUnit).",
        "description_en": "Estonian administrative units conforming to European INSPIRE specifications.",
        "layers_preview": ["AU_haldusyksused:AU.AdministrativeUnit"],
        "preferred_settings": {
            "paging-enabled": True,
            "page-size": 1000,
            "version": "2.0.0"
        }
    },

    # -------------------------------------------------------------------------
    # 9. Globaalsed Aluskaardid (XYZ Tiles)
    # -------------------------------------------------------------------------
    {
        "id": "osm_standard_xyz",
        "name": "OpenStreetMap Standard",
        "title_en": "OpenStreetMap Standard",
        "agency": "OpenStreetMap Foundation",
        "category": "global",
        "service_type": "XYZ",
        "url": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "version": "XYZ",
        "crs": ["EPSG:3857"],
        "description": "Ülemaailmne avatud vektoripõhine kaardikiht.",
        "description_en": "Crowdsourced global standard basemap.",
        "layers_preview": ["osm"],
        "preferred_settings": {
            "zmin": 0,
            "zmax": 19
        }
    },
    {
        "id": "esri_satellite_xyz",
        "name": "ESRI World Imagery (Satelliit)",
        "title_en": "ESRI World Imagery (Satellite)",
        "agency": "Esri",
        "category": "global",
        "service_type": "XYZ",
        "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        "version": "XYZ",
        "crs": ["EPSG:3857"],
        "description": "Kõrge resolutsiooniga globaalne satelliit- ja ortofoto aluskaart.",
        "description_en": "High-resolution worldwide satellite and aerial imagery.",
        "layers_preview": ["esri_imagery"],
        "preferred_settings": {
            "zmin": 0,
            "zmax": 19
        }
    },
    {
        "id": "carto_light_xyz",
        "name": "CartoDB Positron (Hele minimaalne)",
        "title_en": "CartoDB Positron (Light Minimal)",
        "agency": "Carto",
        "category": "global",
        "service_type": "XYZ",
        "url": "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
        "version": "XYZ",
        "crs": ["EPSG:3857"],
        "description": "Maitsekas ja puhas hele taustakaart andmete esitlemiseks.",
        "description_en": "Clean, light basemap ideal for thematic overlay data.",
        "layers_preview": ["carto_light"],
        "preferred_settings": {
            "zmin": 0,
            "zmax": 20
        }
    },
    {
        "id": "carto_dark_xyz",
        "name": "CartoDB Dark Matter (Tume minimalistlik)",
        "title_en": "CartoDB Dark Matter (Dark Minimal)",
        "agency": "Carto",
        "category": "global",
        "service_type": "XYZ",
        "url": "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
        "version": "XYZ",
        "crs": ["EPSG:3857"],
        "description": "Kaasaegne tume taustakaart helendavate ja kontrastsete kihtide visualiseerimiseks.",
        "description_en": "Sleek dark basemap designed for vibrant thematic data.",
        "layers_preview": ["carto_dark"],
        "preferred_settings": {
            "zmin": 0,
            "zmax": 20
        }
    }
]


def get_catalog_json_path():
    """Returns path to bundled or user-overridden estonia_catalog.json."""
    base_dir = os.path.dirname(__file__)
    res_path = os.path.join(base_dir, "resources", "estonia_catalog.json")
    return res_path


def export_catalog_json(path=None):
    """Exports default Estonian presets to JSON file."""
    target_path = path or get_catalog_json_path()
    try:
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(ESTONIA_SERVICES, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def get_all_presets():
    """Returns copy of all preset services, from estonia_catalog.json if available or fallback to code."""
    res_path = get_catalog_json_path()
    if os.path.exists(res_path):
        try:
            with open(res_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list) and len(data) > 0:
                    return data
        except Exception:
            pass
    else:
        export_catalog_json(res_path)

    return list(ESTONIA_SERVICES)


def get_presets_by_category(category_key):
    """Filters presets by category."""
    if not category_key or category_key == "all":
        return list(ESTONIA_SERVICES)
    return [s for s in ESTONIA_SERVICES if s.get("category") == category_key]


def search_presets(query, service_type=None, category=None):
    """Performs search on presets with multi-field matching and Estonian stemming."""
    results = []
    q = (query or "").strip().lower()
    st = (service_type or "").strip().upper()
    cat = (category or "").strip()

    def get_stems(w):
        stems = [w]
        if len(w) > 4:
            for suffix in ("ad", "id", "de", "sid", "des", "delt", "dele", "dest", "sse", "ga", "le", "lt", "st", "te", "stik"):
                if w.endswith(suffix) and len(w) - len(suffix) >= 3:
                    stems.append(w[:-len(suffix)])
        return stems

    words = q.split() if q else []
    word_stems = [get_stems(w) for w in words]

    for item in ESTONIA_SERVICES:
        if st and st != "ALL" and item.get("service_type") != st:
            continue
        if cat and cat != "all" and item.get("category") != cat:
            continue
        if not q:
            results.append(item)
            continue

        haystack = " ".join([
            item.get("name", ""),
            item.get("title_en", ""),
            item.get("agency", ""),
            item.get("url", ""),
            item.get("description", ""),
            item.get("description_en", ""),
            " ".join(item.get("layers_preview", []))
        ]).lower()

        if all(any(stem in haystack for stem in stems) for stems in word_stems):
            results.append(item)

    return results
