# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Background Catalog Preloader.
Inspired by QGIS Pivot catalog preloading. Asynchronously queries un-cached
services in the active profile and presets using QgsTask, eliminating UI blocking
and making all layers immediately searchable.
"""

from qgis.core import QgsTask, QgsApplication
from .service_tester import ServiceTester
from .cache.layer_cache import get_layer_catalog_cache
from .layer_index import get_layer_index
from .utils.url import normalize_service_url


class ServiceCapabilitiesFetchTask(QgsTask):
    """QgsTask executing non-blocking capabilities fetching in background."""

    def __init__(self, service_dict, callback=None):
        name = service_dict.get("name", "Service")
        super().__init__(f"GeoKataloog: Laen teenuse '{name}' kihte", QgsTask.CanCancel)
        self.service_dict = dict(service_dict)
        self.callback = callback
        self.layers = []
        self.success = False
        self.error_msg = None

    def run(self):
        url = self.service_dict.get("url")
        stype = self.service_dict.get("service_type", "WMS")
        if not url or stype == "MIXED":
            return True

        # Check if cancelled
        if self.isCanceled():
            return False

        try:
            tester = ServiceTester(timeout=10)
            res = tester.inspect_service(
                url,
                service_type=stype,
                auth_type=self.service_dict.get("auth_type", "none"),
                auth_params=self.service_dict.get("auth_params")
            )
            if res.get("online") and res.get("layers"):
                self.layers = res.get("layers")
                self.success = True
            else:
                self.error_msg = res.get("error")
        except Exception as e:
            self.error_msg = str(e)

        return True

    def finished(self, result):
        if self.isCanceled():
            return

        if self.success and self.layers:
            stype = self.service_dict.get("service_type", "WMS")
            url = self.service_dict.get("url")

            # 1. Update persistent layer cache
            get_layer_catalog_cache().set_layers(stype, url, self.layers)

            # 2. Update search index
            get_layer_index().register_service_layers(self.service_dict, self.layers)

            # 3. Call UI callback
            if self.callback:
                try:
                    self.callback(self.service_dict, self.layers)
                except Exception:
                    pass


class CatalogPreloader:
    """Coordinates background preloading of profile services and preset catalogs."""

    _active_tasks = []
    _queued_urls = set()

    @classmethod
    def preload_service(cls, service_dict, callback=None, force=False):
        """Preloads a single service if not already cached or queued."""
        stype = service_dict.get("service_type", "WMS").upper()
        url = service_dict.get("url", "").strip()
        if not url or stype in ("MIXED", "XYZ"):
            return

        layer_cache = get_layer_catalog_cache()
        cached = layer_cache.get_layers(stype, url)
        if cached and not force:
            # Already cached! Ensure registered in index
            get_layer_index().register_service_layers(service_dict, cached)
            if callback:
                try:
                    callback(service_dict, cached)
                except Exception:
                    pass
            return

        norm_u = normalize_service_url(url, service_type=stype)
        task_key = (stype, norm_u)
        if task_key in cls._queued_urls:
            return  # Already in progress

        cls._queued_urls.add(task_key)

        def on_finished(svc, layers):
            cls._queued_urls.discard(task_key)
            if callback:
                callback(svc, layers)

        task = ServiceCapabilitiesFetchTask(service_dict, on_finished)
        cls._active_tasks.append(task)
        QgsApplication.taskManager().addTask(task)

    @classmethod
    def preload_all(cls, profile_manager, callback=None):
        """
        Scans active profile services and core presets. Immediately resolves
        cached services into memory and launches background tasks for remaining ones.
        """
        layer_cache = get_layer_catalog_cache()
        layer_index = get_layer_index()

        # 1. Inspect active profile
        active_prof = profile_manager.get_active_profile()
        if active_prof:
            for s in active_prof.get("services", []):
                stype = s.get("service_type", "WMS").upper()
                url = s.get("url", "").strip()
                if not url or stype in ("MIXED", "XYZ"):
                    continue

                cached_layers = layer_cache.get_layers(stype, url)
                if cached_layers:
                    if not s.get("layers"):
                        s["layers"] = cached_layers
                    layer_index.register_service_layers(s, cached_layers)
                else:
                    cls.preload_service(s, callback=callback)
