# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Global Dataset and Layer Index.
Enables 'Search datasets, not servers' inside the Services/Layers panel,
with offline indexed Estonian layers and online open data / CSW discovery.
"""

import urllib.request
import urllib.parse
import json
import xml.etree.ElementTree as ET
from .presets import ESTONIA_SERVICES
from .csw_client import CswClient


class LayerIndex:
    """In-memory searchable index of all known spatial layers and datasets."""

    def __init__(self):
        self._layers = []
        self._initialized = False
        self._init_preset_index()

    def _init_preset_index(self):
        """Builds index from curated Estonian presets and rich default layer catalogs."""
        if self._initialized:
            return

        for s in ESTONIA_SERVICES:
            s_id = s.get("id", "")
            s_name = s.get("name", "")
            s_agency = s.get("agency", "Eesti riik")
            stype = s.get("service_type", "WMS").upper()
            url = s.get("url", "")
            crs = "EPSG:3301"

            # 1. Preview layers declared in preset
            for l_name in s.get("layers_preview", []):
                self._add_indexed_layer(
                    name=l_name,
                    title=f"{s_name} - {l_name}",
                    abstract=s.get("description", ""),
                    agency=s_agency,
                    service_type=stype,
                    service_name=s_name,
                    service_url=url,
                    geometry_type=self._guess_geometry_type(l_name, stype),
                    crs=crs,
                    service_dict=s
                )

        # Pre-seed verified high-value Estonian layers with precise names & titles
        self._seed_core_estonian_layers()

        # Ingest all bundled and cached layer catalogs from LayerCatalogCache
        try:
            from .cache.layer_cache import get_layer_catalog_cache
            from .utils.url import normalize_service_url
            layer_cache = get_layer_catalog_cache()
            for stype, url, layers in layer_cache.all_services_and_layers():
                matched_preset = None
                norm_u = normalize_service_url(url, service_type=stype)
                for ps in ESTONIA_SERVICES:
                    if ps.get("service_type") == stype and normalize_service_url(ps.get("url"), service_type=stype) == norm_u:
                        matched_preset = ps
                        break

                s_agency = matched_preset.get("agency") if matched_preset else "Eesti riik"
                s_name = matched_preset.get("name") if matched_preset else f"{stype} Teenus"

                for l in layers:
                    self._add_indexed_layer(
                        name=l.get("name", ""),
                        title=l.get("title", l.get("name", "")),
                        abstract=l.get("abstract", ""),
                        agency=s_agency,
                        service_type=stype,
                        service_name=s_name,
                        service_url=url,
                        geometry_type=l.get("geom_type") or l.get("geometry_type") or self._guess_geometry_type(l.get("name", ""), stype),
                        crs=l.get("default_crs", "EPSG:3301"),
                        service_dict=matched_preset or {
                            "name": s_name,
                            "agency": s_agency,
                            "service_type": stype,
                            "url": url
                        }
                    )
        except Exception:
            pass

        self._initialized = True

    def _seed_core_estonian_layers(self):
        """Seeds canonical Estonian government layers with exact identifiers."""
        core_seeds = [
            # Maa- ja Ruumiamet
            {"name": "pohikaart", "title": "Eesti põhikaart (Värviline)", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/alus", "geom": "Raster"},
            {"name": "vreljeef", "title": "Reljeefivarjutus (Värviline)", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/alus", "geom": "Raster"},
            {"name": "EESTIFOTO", "title": "Eesti ortofoto (Kõrglahutusega)", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/fotokaart", "geom": "Raster"},
            {"name": "cir", "title": "CIR Värvi-infrapuna ortofoto", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/fotokaart", "geom": "Raster"},
            {"name": "metsafoto", "title": "Metsanduslik ortofoto", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/fotokaart", "geom": "Raster"},
            {"name": "kataster:katastriyksus", "title": "Katastriüksused (Kehtivad piirid)", "agency": "Maa- ja Ruumiamet", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/kataster/wfs", "geom": "Polügoon"},
            {"name": "kataster:piiripunkt", "title": "Katastri piiripunktid", "agency": "Maa- ja Ruumiamet", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/kataster/wfs", "geom": "Punkt"},
            {"name": "kataster:kinnistu", "title": "Kinnistud ja katastrikaart", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/kataster", "geom": "Raster"},
            {"name": "aadress:aadressipunkt", "title": "ADS Aadressipunktid", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/aadressid", "geom": "Punkt"},
            {"name": "korgus_dtm_1m", "title": "Eesti kõrgusmudel DTM 1m", "agency": "Maa- ja Ruumiamet", "stype": "WCS", "url": "https://teenus.maaamet.ee/ows/wcs-dtm", "geom": "Raster (Kõrgusmudel)"},
            {"name": "korgus_dsm_1m", "title": "Eesti pinnamudel DSM 1m", "agency": "Maa- ja Ruumiamet", "stype": "WCS", "url": "https://teenus.maaamet.ee/ows/wcs-dtm", "geom": "Raster (Kõrgusmudel)"},
            {"name": "etak_joonelement", "title": "ETAK Topograafilised jooned", "agency": "Maa- ja Ruumiamet", "stype": "WFS", "url": "https://teenus.maaamet.ee/ows/wfs-etak", "geom": "Joon"},
            {"name": "etak_pindelement", "title": "ETAK Topograafilised pinnad", "agency": "Maa- ja Ruumiamet", "stype": "WFS", "url": "https://teenus.maaamet.ee/ows/wfs-etak", "geom": "Polügoon"},

            # Keskkonnaportaal / EELIS
            {"name": "eelis:kr_loomad_iii", "title": "KKR loomad III (Kaitsealused loomad III)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:kr_taimed_iii", "title": "KKR taimed III (Kaitsealused taimed III)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:kr_seened_samblikud_iii", "title": "KKR seened ja samblikud III", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:kr_kudemisala", "title": "Lõheliste kudemisalad ja elupaigad", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Joon / Polügoon"},
            {"name": "eelis:kr_vep", "title": "Vääriselupaigad (VEP)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:natura_linnualad", "title": "Natura 2000 linnualad (SPA)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:natura_loodusalad", "title": "Natura 2000 loodusalad (SCI)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:kr_ala", "title": "Kaitsealade ja hoiualade piirid", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "eelis:kr_vyond", "title": "Kaitsealade sihtkaitsevööndid", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/ows", "geom": "Polügoon"},
            {"name": "kponahtused:kpo_avalik_looduskaitse_10007", "title": "Looduskaitse objektid ja piirangud (Envir)", "agency": "Keskkonnaportaal (KEMIT)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/wfs", "geom": "Polügoon"},
            {"name": "kr_kaitseala", "title": "Kaitsealad (Looduspargid, rahvuspargid)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Polügoon"},
            {"name": "kr_hoiuala", "title": "Hoiualad", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Polügoon"},
            {"name": "kr_pyt", "title": "Püsielupaigad ja kaitsealused liigid", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Polügoon"},
            {"name": "kr_natura_linnuala", "title": "Natura 2000 linnualad (SPA)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Polügoon"},
            {"name": "kr_natura_loodusala", "title": "Natura 2000 loodusalad (SCI)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Polügoon"},
            {"name": "kr_veekogu", "title": "Eesti veekogud (Järved, veehoidlad)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Polügoon"},
            {"name": "kr_vooluvesi", "title": "Eesti vooluveekogud (Jõed, ojad, kraavid)", "agency": "Keskkonnaagentuur (EELIS)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/eelis/wfs", "geom": "Joon"},
            {"name": "metsaregister:eraldised", "title": "Metsaregistri metsaeraldised", "agency": "Keskkonnaagentuur (Mets)", "stype": "WFS", "url": "https://gsavalik.envir.ee/geoserver/mets/wfs", "geom": "Polügoon"},

            # PRIA
            {"name": "pria:pollud", "title": "PRIA Põllumassiivid (Kehtivad toetusalad)", "agency": "PRIA", "stype": "WFS", "url": "https://kls.pria.ee/geoserver/pria_avalik/wfs", "geom": "Polügoon"},
            {"name": "pria:maastikuelemendid", "title": "PRIA Maastikuelemendid (Kraavid, hekid)", "agency": "PRIA", "stype": "WFS", "url": "https://kls.pria.ee/geoserver/pria_avalik/wfs", "geom": "Joon / Polügoon"},
            {"name": "pria:ajalooline_massiiv", "title": "PRIA Ajaloolised põllumassiivid", "agency": "PRIA", "stype": "WFS", "url": "https://kls.pria.ee/geoserver/pria_avalik/wfs", "geom": "Polügoon"},

            # Muinsuskaitseamet
            {"name": "mka:malestis", "title": "Kultuurimälestised (Ehitised, arheoloogia, ajalugu)", "agency": "Muinsuskaitseamet", "stype": "WFS", "url": "https://service.muinsuskaitseamet.ee/geoserver/wfs", "geom": "Punkt"},
            {"name": "mka:kaitsevoond", "title": "Mälestiste kaitsevööndid", "agency": "Muinsuskaitseamet", "stype": "WFS", "url": "https://service.muinsuskaitseamet.ee/geoserver/wfs", "geom": "Polügoon"},

            # Maardlad & Geoloogia
            {"name": "geoloogia:maardlad", "title": "Eesti maardlad ja mäeeraldised", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/geoloogia", "geom": "Polügoon"},
            {"name": "geoloogia:turbamaardlad", "title": "Eesti turbamaardlad", "agency": "Maa- ja Ruumiamet", "stype": "WMS", "url": "https://kaart.maaamet.ee/wms/geoloogia", "geom": "Polügoon"},

            # Globaalsed satelliidipildid & kaardid
            {"name": "OpenStreetMap", "title": "OpenStreetMap Standard", "agency": "OSM Foundation", "stype": "XYZ", "url": "https://tile.openstreetmap.org/{z}/{x}/{y}.png", "geom": "Raster"},
            {"name": "ESRI_Satellite", "title": "ESRI World Imagery (Kõrglahutusega Satelliit)", "agency": "ESRI / Maxar", "stype": "XYZ", "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", "geom": "Raster"},
            {"name": "CartoDB_Positron", "title": "CartoDB Positron (Puhas hele aluskaart)", "agency": "Carto", "stype": "XYZ", "url": "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png", "geom": "Raster"}
        ]

        for seed in core_seeds:
            svc_dict = {
                "name": seed["agency"],
                "agency": seed["agency"],
                "service_type": seed["stype"],
                "url": seed["url"],
                "preferred_settings": {"dpi-mode": 7} if seed["stype"] in ("WMS", "WMTS") else {}
            }
            self._add_indexed_layer(
                name=seed["name"],
                title=seed["title"],
                abstract=f"{seed['agency']} ametlik ruumiandmestik: {seed['title']}",
                agency=seed["agency"],
                service_type=seed["stype"],
                service_name=seed["agency"],
                service_url=seed["url"],
                geometry_type=seed["geom"],
                crs="EPSG:3301",
                service_dict=svc_dict
            )

    def _add_indexed_layer(self, name, title, abstract, agency, service_type, service_name, service_url, geometry_type, crs, service_dict):
        """Adds or updates layer item in index."""
        key = (service_type.upper(), service_url.lower(), name.lower())
        for existing in self._layers:
            if (existing["service_type"], existing["service_url"].lower(), existing["name"].lower()) == key:
                existing["title"] = title
                existing["geometry_type"] = geometry_type
                return

        self._layers.append({
            "name": name,
            "title": title or name,
            "abstract": abstract or "",
            "agency": agency or "Eesti riik",
            "service_type": service_type.upper(),
            "service_name": service_name or agency,
            "service_url": service_url,
            "geometry_type": geometry_type or "Tundmatu",
            "crs": crs or "EPSG:3301",
            "service_dict": service_dict,
            "source": "CATALOG"
        })

    def _guess_geometry_type(self, name, stype):
        """Infers geometry badge from layer name and protocol."""
        if stype in ("WMS", "WMTS", "XYZ", "WCS"):
            return "Raster" if stype != "WCS" else "Raster (Kõrgusmudel)"
        n_lower = name.lower()
        if any(x in n_lower for x in ("polygon", "ala", "pind", "piir", "massiiv", "erald", "zone", "kuurort", "loom", "taim", "seen", "vep", "vyond")):
            return "Polügoon"
        if any(x in n_lower for x in ("line", "joon", "tee", "rada", "vooluvesi", "kraav", "raudtee", "jogi")):
            return "Joon"
        if any(x in n_lower for x in ("point", "punkt", "koht", "mälestis", "puu", "objekt", "aadress", "voorliik")):
            return "Punkt"
        return "Vektor (WFS)"

    def register_service_layers(self, service_dict, layers_list):
        """Dynamically registers live probed or inspected layers into the index."""
        stype = service_dict.get("service_type", "WMS").upper()
        s_url = service_dict.get("url", "")
        s_name = service_dict.get("name", "Service")
        s_agency = service_dict.get("agency", s_name)

        for l in layers_list:
            self._add_indexed_layer(
                name=l.get("name", ""),
                title=l.get("title", l.get("name", "")),
                abstract=l.get("abstract", ""),
                agency=s_agency,
                service_type=stype,
                service_name=s_name,
                service_url=s_url,
                geometry_type=l.get("geometry_type") or self._guess_geometry_type(l.get("name", ""), stype),
                crs=l.get("default_crs", "EPSG:3301"),
                service_dict=service_dict
            )

        # Also persist to LayerCatalogCache
        try:
            from .cache.layer_cache import get_layer_catalog_cache
            get_layer_catalog_cache().set_layers(stype, s_url, layers_list)
        except Exception:
            pass

    def search_local(self, query):
        """
        Instant offline search across indexed Estonian layers.
        Matches keywords specifically against layer name and title.
        """
        if not query or not query.strip():
            return list(self._layers)

        q = query.strip().lower()
        words = q.split()

        def get_stems(w):
            stems = [w]
            if len(w) > 4:
                for suffix in ("ad", "id"):
                    if w.endswith(suffix) and len(w) - len(suffix) >= 3:
                        stems.append(w[:-len(suffix)])
            return stems

        word_stems = [get_stems(w) for w in words]

        def matches_name_title(name_title, stems):
            clean_str = name_title
            if "loom" in stems:
                clean_str = clean_str.replace("loomiseks", "").replace("loomine", "").replace("loomise", "").replace("loomisel", "")
            return any(s in clean_str for s in stems)

        results = []
        for l in self._layers:
            name_title = f"{l['name']} {l['title']}".lower()
            if all(matches_name_title(name_title, stems) for stems in word_stems):
                results.append(l)

        # Sort exact title prefix matches higher
        results.sort(key=lambda item: (
            not item["title"].lower().startswith(q),
            not item["name"].lower().startswith(q),
            item["agency"],
            item["title"]
        ))
        return results

    def search_web(self, query, max_results=15):
        """
        Queries Estonian Open Data portal (avaandmed.eesti.ee) and Geoportal CSW.
        Returns newly discovered remote layers/services as structured items.
        """
        if not query or not query.strip():
            return []

        q = query.strip()
        web_results = []
        seen_urls = set()

        # 1. Query avaandmed.eesti.ee API
        try:
            enc_q = urllib.parse.quote(q)
            api_url = f"https://avaandmed.eesti.ee/api/datasets?search={enc_q}&limit={max_results}"
            req = urllib.request.Request(api_url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) QGIS GeoKataloog/1.8",
                "Accept": "application/json"
            })
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                datasets = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
                for ds in datasets:
                    d_title = ds.get("title", "")
                    d_org = ds.get("organization", {}).get("name") or "Eesti Avaandmed"
                    files = ds.get("files", []) or []
                    for f in files:
                        f_url = f.get("url") or ""
                        f_name = f.get("name") or d_title
                        f_type = (f.get("format") or f.get("mimetype") or "").upper()

                        stype = "WFS" if "WFS" in f_type or "wfs" in f_url.lower() else ("WMS" if "WMS" in f_type or "wms" in f_url.lower() else "")
                        if stype and f_url and f_url.lower() not in seen_urls:
                            seen_urls.add(f_url.lower())
                            svc_dict = {
                                "name": f"{d_title} ({stype})",
                                "agency": d_org,
                                "service_type": stype,
                                "url": f_url,
                                "preferred_settings": {}
                            }
                            web_results.append({
                                "name": f_name,
                                "title": f"{d_title} - {f_name}",
                                "abstract": ds.get("description", ""),
                                "agency": d_org,
                                "service_type": stype,
                                "service_name": d_title,
                                "service_url": f_url,
                                "geometry_type": "Vektor (Avaandmed)" if stype == "WFS" else "Raster (Avaandmed)",
                                "crs": "EPSG:3301",
                                "service_dict": svc_dict,
                                "source": "WEB"
                            })
        except Exception:
            pass

        # 2. Query Geoportal CSW
        try:
            csw = CswClient(timeout=6)
            csw_res = csw.search_records(search_text=q, max_records=max_results)
            records = csw_res.get("records", []) if isinstance(csw_res, dict) else []
            for r in records:
                r_url = r.get("url", "")
                r_title = r.get("name") or r.get("title", "CSW Kiht")
                r_type = r.get("service_type", "WMS").upper()
                if r_url and r_url.lower() not in seen_urls:
                    seen_urls.add(r_url.lower())
                    svc_dict = {
                        "name": r_title,
                        "agency": r.get("agency", "Maa- ja Ruumiamet (CSW)"),
                        "service_type": r_type,
                        "url": r_url,
                        "preferred_settings": {}
                    }
                    web_results.append({
                        "name": r_title,
                        "title": r_title,
                        "abstract": r.get("description", "Leitud Maa-ameti Geoportaali CSW metaandmetest."),
                        "agency": r.get("agency", "Maa- ja Ruumiamet (CSW)"),
                        "service_type": r_type,
                        "service_name": r_title,
                        "service_url": r_url,
                        "geometry_type": "Vektor (CSW)" if r_type == "WFS" else "Raster (CSW)",
                        "crs": "EPSG:3301",
                        "service_dict": svc_dict,
                        "source": "WEB"
                    })
        except Exception:
            pass

        # Post-filter remote results: only include layers whose title or name matches the search terms
        words = q.lower().split()
        def get_stems(w):
            stems = [w]
            if len(w) > 4:
                for suffix in ("ad", "id"):
                    if w.endswith(suffix) and len(w) - len(suffix) >= 3:
                        stems.append(w[:-len(suffix)])
            return stems

        word_stems = [get_stems(w) for w in words]

        def matches_name_title(name_title, stems):
            clean_str = name_title
            if "loom" in stems:
                clean_str = clean_str.replace("loomiseks", "").replace("loomine", "").replace("loomise", "").replace("loomisel", "")
            return any(s in clean_str for s in stems)

        filtered_web = []
        for w in web_results:
            name_title = f"{w['name']} {w['title']}".lower()
            if all(matches_name_title(name_title, stems) for stems in word_stems):
                filtered_web.append(w)

        return filtered_web


# Singleton instance for quick access across widgets
_LAYER_INDEX_INSTANCE = None

def get_layer_index():
    """Returns singleton LayerIndex instance."""
    global _LAYER_INDEX_INSTANCE
    if _LAYER_INDEX_INSTANCE is None:
        _LAYER_INDEX_INSTANCE = LayerIndex()
    return _LAYER_INDEX_INSTANCE
