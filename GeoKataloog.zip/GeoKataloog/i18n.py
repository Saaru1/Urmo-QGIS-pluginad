# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Comprehensive Internationalization (i18n)
Provides full Estonian (EST) and English (ENG) translation support.
"""

CURRENT_LANG = "EST"

TRANSLATIONS = {
    # Plugin Identity & Dock
    "plugin_name": {
        "EST": "GeoKataloog (Eesti & OGC)",
        "ENG": "GeoKataloog (Estonia & OGC)"
    },
    "dock_title": {
        "EST": "GeoKataloog — Kihid & Profiilid",
        "ENG": "GeoKataloog — Layers & Profiles"
    },
    "tab_layers": {
        "EST": "Kihid",
        "ENG": "Layers"
    },
    "tab_catalog": {
        "EST": "Teenuste Kataloog",
        "ENG": "Service Catalog"
    },
    "tab_settings": {
        "EST": "Seaded",
        "ENG": "Settings"
    },

    # Main Dock Header & Bar
    "app_subtitle": {
        "EST": "Eesti ja OGC ruumiandmeteenuste otsing, geomeetria testija ja profiilihaldur",
        "ENG": "Estonian & OGC spatial services discovery, geometry inspector & profile manager"
    },
    "active_profile": {
        "EST": "Aktiivne profiil:",
        "ENG": "Active Profile:"
    },
    "theme_btn_dark": {
        "EST": "🌙 Tume",
        "ENG": "🌙 Dark"
    },
    "theme_btn_light": {
        "EST": "☀ Hele",
        "ENG": "☀ Light"
    },
    "lang_btn_text": {
        "EST": "Keel: EST",
        "ENG": "Lang: ENG"
    },
    "btn_dock_qgis": {
        "EST": "Doki",
        "ENG": "Dock"
    },
    "btn_dock_qgis_tooltip": {
        "EST": "Doki paneel QGIS-i peaaknasse (paremasse serva)",
        "ENG": "Dock panel into QGIS main window (right edge)"
    },
    "btn_float_window": {
        "EST": "Hõlju",
        "ENG": "Float"
    },
    "btn_float_window_tooltip": {
        "EST": "Ava paneel eraldi hõljuva aknana",
        "ENG": "Float panel as a standalone window"
    },
    "btn_minimize_tooltip": {
        "EST": "Minimeeri aken",
        "ENG": "Minimize window"
    },
    "btn_collapse_tooltip": {
        "EST": "Ahenda paneel ajutiselt kokku",
        "ENG": "Collapse panel temporarily"
    },
    "btn_expand_tooltip": {
        "EST": "Taasta paneeli vaade",
        "ENG": "Restore panel view"
    },
    "btn_close_tooltip": {
        "EST": "Sulge GeoKataloog",
        "ENG": "Close GeoKataloog"
    },

    # Catalog View
    "search_placeholder": {
        "EST": "Otsi teenust, asutust või märksõna...",
        "ENG": "Search service, agency or keyword..."
    },
    "filter_all": {
        "EST": "Kõik tüübid",
        "ENG": "All Types"
    },
    "filter_category": {
        "EST": "Kategooria:",
        "ENG": "Category:"
    },
    "cat_all": {
        "EST": "Kõik kategooriad",
        "ENG": "All Categories"
    },
    "cat_base": {
        "EST": "Aluskaardid & Ortofotod",
        "ENG": "Basemaps & Orthophotos"
    },
    "cat_cadastre": {
        "EST": "Kataster & Maakorraldus",
        "ENG": "Cadastre & Land Registry"
    },
    "cat_topo": {
        "EST": "Topograafia (ETAK)",
        "ENG": "Topography (ETAK)"
    },
    "cat_env": {
        "EST": "Keskkond & Loodus (EELIS)",
        "ENG": "Environment & Nature (EELIS)"
    },
    "cat_agri": {
        "EST": "Põllumajandus & PRIA",
        "ENG": "Agriculture & PRIA"
    },
    "cat_transport": {
        "EST": "Transport & Teed",
        "ENG": "Transport & Roads"
    },
    "cat_heritage": {
        "EST": "Kultuurimälestised",
        "ENG": "Cultural Heritage"
    },
    "cat_planning": {
        "EST": "Planeeringud & Ruum",
        "ENG": "Spatial Planning"
    },
    "cat_global": {
        "EST": "Globaalsed Aluskaardid",
        "ENG": "Global Basemaps"
    },
    "cat_current": {
        "EST": "QGIS Praegused Ühendused",
        "ENG": "Current QGIS Connections"
    },
    "cat_custom": {
        "EST": "Kasutaja Lisatud",
        "ENG": "User Custom"
    },
    "csw_toggle": {
        "EST": "Kaasa reaalajas Geoportaali otsing (CSW)",
        "ENG": "Include live Geoportal search (CSW)"
    },
    "btn_search": {
        "EST": "Otsi",
        "ENG": "Search"
    },
    "btn_reset": {
        "EST": "Lähtesta",
        "ENG": "Reset"
    },
    "btn_inspect_layers": {
        "EST": "Ava Kihtide paneelis →",
        "ENG": "Open in Layers Panel →"
    },
    "btn_add_to_profile": {
        "EST": "+ Lisa profiili",
        "ENG": "+ Add to Profile"
    },
    "btn_add_custom_url": {
        "EST": "+ Lisa oma URL...",
        "ENG": "+ Add Custom URL..."
    },
    "services_found": {
        "EST": "Leitud teenuseid: {count}",
        "ENG": "Services found: {count}"
    },

    # Layers Panel View
    "layers_panel_title": {
        "EST": "Kihtide Paneel",
        "ENG": "Layers Panel"
    },
    "mode_single_service": {
        "EST": "Valitud teenus",
        "ENG": "Selected Service"
    },
    "mode_global_search": {
        "EST": "Otsi kihte",
        "ENG": "Search Layers"
    },
    "global_search_placeholder": {
        "EST": "Otsi andmestikku või kihti (nt kataster, kaitsealad, orto)...",
        "ENG": "Search dataset or layer (e.g. cadastre, protected areas, ortho)..."
    },
    "btn_web_search": {
        "EST": "Otsi veebist",
        "ENG": "Search Web"
    },
    "local_results_count": {
        "EST": "Leitud: {count} kihti",
        "ENG": "Found: {count} layers"
    },
    "web_results_count": {
        "EST": "Veebist leitud: {count} kihti",
        "ENG": "Web results: {count} layers"
    },
    "searching_web": {
        "EST": "Otsin riiklikest portaalidest...",
        "ENG": "Searching open data portals..."
    },
    "col_service_name": {
        "EST": "Teenuse pealkiri / nimi",
        "ENG": "Service Title / Name"
    },
    "service_selector_label": {
        "EST": "📋 Vali teenus:",
        "ENG": "📋 Select Service:"
    },
    "choose_service_prompt": {
        "EST": "-- Vali teenus nimekirjast... --",
        "ENG": "-- Select service from list... --"
    },
    "layers_filter_placeholder": {
        "EST": "Filtreeri kihte nime või geomeetria järgi...",
        "ENG": "Filter layers by name or geometry..."
    },
    "btn_refresh_layers": {
        "EST": "Uuenda",
        "ENG": "Refresh"
    },
    "status_ready": {
        "EST": "Valmis",
        "ENG": "Ready"
    },
    "status_loading": {
        "EST": "Laadimine...",
        "ENG": "Loading..."
    },
    "loading_layers_text": {
        "EST": "Teenuse andmete ja kihtide laadimine... Palun oodake.",
        "ENG": "Loading service layers and metadata... Please wait."
    },

    # Layer Table Columns
    "col_layer_title": {
        "EST": "Kihi pealkiri / nimi",
        "ENG": "Layer Title / Name"
    },
    "col_geom_type": {
        "EST": "Geomeetria",
        "ENG": "Geometry"
    },
    "col_owner": {
        "EST": "Omanik / Asutus",
        "ENG": "Owner / Agency"
    },
    "col_renewed": {
        "EST": "Uuendussagedus",
        "ENG": "Update Frequency"
    },
    "col_updated": {
        "EST": "Viimati uuendatud",
        "ENG": "Last Updated"
    },
    "col_paging": {
        "EST": "Paging",
        "ENG": "Paging"
    },
    "col_crs": {
        "EST": "Koordinaatsüsteem",
        "ENG": "CRS"
    },
    "col_actions": {
        "EST": "Toiming",
        "ENG": "Action"
    },
    "yes_text": {
        "EST": "Jah",
        "ENG": "Yes"
    },
    "no_text": {
        "EST": "Ei",
        "ENG": "No"
    },

    # Metadata Card (Overview)
    "card_overview_badge": {
        "EST": "KIHI ÜLEVAADE & METAANDMED",
        "ENG": "LAYER OVERVIEW & METADATA"
    },
    "layer_metadata_header": {
        "EST": "Valitud kihi metaandmed & geomeetria",
        "ENG": "Selected Layer Metadata & Geometry"
    },
    "no_layer_selected": {
        "EST": "Vali ülalolevast tabelist kiht, et näha üksikasjalikke metaandmeid.",
        "ENG": "Select a layer from the table above to inspect metadata and geometry."
    },
    "meta_abstract": {
        "EST": "Kirjeldus / Abstrakt:",
        "ENG": "Abstract / Description:"
    },
    "meta_bbox": {
        "EST": "Ruumiline ulatus (BBOX):",
        "ENG": "Spatial Extent (BBOX):"
    },
    "meta_paging": {
        "EST": "Lehekülgede jaotus:",
        "ENG": "Paging Support:"
    },
    "meta_geom_col": {
        "EST": "Geomeetria veerg:",
        "ENG": "Geometry Column:"
    },
    "meta_owner": {
        "EST": "Andmete omanik:",
        "ENG": "Data Owner:"
    },
    "meta_frequency": {
        "EST": "Uuendussagedus:",
        "ENG": "Update Frequency:"
    },
    "meta_updated": {
        "EST": "Viimati uuendatud:",
        "ENG": "Last Updated:"
    },
    "meta_crs": {
        "EST": "Koordinaatsüsteem:",
        "ENG": "Coordinate System:"
    },
    "tab_overview": {
        "EST": "Ülevaade",
        "ENG": "Overview"
    },
    "tab_fields": {
        "EST": "Atribuutide tabeliväljad (Fields)",
        "ENG": "Attribute Fields Schema"
    },
    "col_field_name": {
        "EST": "Välja nimi (Field)",
        "ENG": "Field Name"
    },
    "col_field_type": {
        "EST": "Andmetüüp (Type)",
        "ENG": "Data Type"
    },

    # Mixed Geometry
    "mixed_geom_detected_title": {
        "EST": "⚠️ Tuvastati segageomeetria (Mitmik-tüüp)",
        "ENG": "⚠️ Mixed Geometry Type Detected"
    },
    "mixed_geom_desc": {
        "EST": "See kiht sisaldab erinevaid geomeetriaid (polügoonid, jooned ja punktid). QGIS avab vaikimisi vaid polügoonid. Vali kuidas soovid avada:",
        "ENG": "This layer holds mixed geometries (polygons, lines and points). QGIS defaults to polygons only. Choose how to open:"
    },
    "btn_open_poly": {
        "EST": "Ainult Polügoonid",
        "ENG": "Polygons Only"
    },
    "btn_open_lines": {
        "EST": "Ainult Jooned",
        "ENG": "Lines Only"
    },
    "btn_open_points": {
        "EST": "Ainult Punktid",
        "ENG": "Points Only"
    },
    "btn_split_all": {
        "EST": "★ Eralda kihtideks grupis",
        "ENG": "★ Split Types into Group"
    },
    "mixed_dialog_title": {
        "EST": "⚠️ Tuvastati segageomeetria (Andmekao oht)",
        "ENG": "⚠️ Mixed Geometry Detected (Data Loss Warning)"
    },
    "mixed_dialog_warn": {
        "EST": "See kiht sisaldab mitut erinevat geomeetriatüüpi. QGIS suudab ühel kihil korraga kuvada vaid ühte tüüpi – avades tavapäraselt lähevad teised geomeetriad kaduma!\n\nVali, kuidas soovid kihi lisada:",
        "ENG": "This layer contains multiple geometry types. QGIS can only display one geometry type per layer – opening normally will discard other geometries!\n\nChoose how to load this layer:"
    },
    "btn_open_rule_based": {
        "EST": "Reeglipõhise stiiliga",
        "ENG": "Rule-based Symbology"
    },

    # Actions
    "btn_add_to_canvas": {
        "EST": "+ Ava kaardil",
        "ENG": "+ Add to Map"
    },
    "btn_download_gpkg": {
        "EST": "📥 Laadi alla (GPKG)",
        "ENG": "📥 Download (GPKG)"
    },
    "tip_download_gpkg": {
        "EST": "Laadi andmestik tervikuna alla ja salvesta kohalikuks GeoPackage failiks (nagu MapInfo - tagab 100% andmete kättesaamise ilma serveri piiranguteta)",
        "ENG": "Download complete dataset to a local GeoPackage file (like MapInfo - ensures 100% feature retrieval without server limits)"
    },
    "dlg_downloading_gpkg": {
        "EST": "Kihi allalaadimine GeoPackage'i...",
        "ENG": "Downloading layer to GeoPackage..."
    },
    "dlg_downloading_features": {
        "EST": "Laadin alla kihi '{name}' andmeid ja salvestan kohalikku GeoPackage faili...",
        "ENG": "Downloading features for layer '{name}' to local GeoPackage..."
    },
    "msg_gpkg_download_success": {
        "EST": "Kiht '{name}' ({count:,} objekti) salvestati edukalt GeoPackage'i ja lisati kaardile!",
        "ENG": "Layer '{name}' ({count:,} features) saved to GeoPackage and added to the map!"
    },
    "btn_drag_hint": {
        "EST": "💡 Vihje: lohista kiht paremale profiili puusse (Drag & Drop)!",
        "ENG": "💡 Tip: Drag layer to profile tree on the right (Drag & Drop)!"
    },

    # Profile Builder Panel
    "profile_builder_title": {
        "EST": "Aktiivne Profiil & Koostaja",
        "ENG": "Active Profile & Builder"
    },
    "select_profile": {
        "EST": "📁 Profiil:",
        "ENG": "📁 Profile:"
    },
    "btn_new_profile": {
        "EST": "+ Uus",
        "ENG": "+ New"
    },
    "btn_delete_profile": {
        "EST": "🗑️ Kustuta",
        "ENG": "🗑️ Delete"
    },
    "btn_apply_to_qgis": {
        "EST": "★ Rakenda QGIS ühendustesse",
        "ENG": "★ Apply to QGIS Connections"
    },
    "btn_sync_from_qgis": {
        "EST": "🔄 Sünkrooni QGIS-ist",
        "ENG": "🔄 Sync from QGIS"
    },
    "confirm_sync_from_qgis": {
        "EST": "Kas soovid värskendada aktiivse profiili andmeid otse QGIS-i salvestatud ühendustest?",
        "ENG": "Do you want to refresh active profile data directly from QGIS saved connections?"
    },
    "msg_sync_from_qgis_done": {
        "EST": "Aktiivne profiil edukalt sünkroonitud QGIS-i ühendustega (leiti {count} ühendust)!",
        "ENG": "Active profile successfully synchronized with QGIS connections ({count} connections found)!"
    },
    "btn_export_xml": {
        "EST": "📤 Ekspordi XML",
        "ENG": "📤 Export XML"
    },
    "btn_import_profile": {
        "EST": "📥 Impordi",
        "ENG": "📥 Import"
    },
    "btn_share_profile": {
        "EST": "📋 Jaga",
        "ENG": "📋 Share"
    },
    "profile_drop_zone_hint": {
        "EST": "Lohista kihid või teenused siia profiili lisamiseks",
        "ENG": "Drag & drop layers or services here to add to profile"
    },
    "col_prof_service": {
        "EST": "Teenus / Kiht",
        "ENG": "Service / Layer"
    },
    "col_prof_type": {
        "EST": "Tüüp",
        "ENG": "Type"
    },
    "col_prof_settings": {
        "EST": "Seaded & URL",
        "ENG": "Settings & URL"
    },
    "btn_remove_item": {
        "EST": "Eemalda valitud",
        "ENG": "Remove Selected"
    },
    "btn_remove_catalog": {
        "EST": "Eemalda nimekirjast",
        "ENG": "Remove from Catalog"
    },
    "menu_remove_catalog": {
        "EST": "🗑️ Eemalda kataloogist",
        "ENG": "🗑️ Remove from Catalog"
    },
    "confirm_remove_catalog": {
        "EST": "Kas soovid teenuse '{name}' kataloogist eemaldada/peita?",
        "ENG": "Do you want to remove/hide service '{name}' from the catalog?"
    },
    "confirm_title": {
        "EST": "Kinnitus",
        "ENG": "Confirmation"
    },
    "my_qgis_tag": {
        "EST": "✓ Minu ühendus",
        "ENG": "✓ My Connection"
    },
    "qgis_applied_success": {
        "EST": "Profiili '{profile}' ühendused ({count} tk) on edukalt QGIS seadetesse rakendatud ja brauser uuendatud!",
        "ENG": "Profile '{profile}' connections ({count}) successfully applied to QGIS settings and browser refreshed!"
    },

    # Context Menu & Service Info
    "menu_apply_single_to_qgis": {
        "EST": "Rakenda see teenus QGIS ühendustesse",
        "ENG": "Apply this service to QGIS connections"
    },
    "msg_single_applied": {
        "EST": "Teenus '{name}' edukalt rakendatud QGIS ühendustesse!",
        "ENG": "Service '{name}' successfully applied to QGIS connections!"
    },
    "confirm_apply_renamed_to_qgis": {
        "EST": "Teenus nimetati ümber: '{old_name}' ➔ '{new_name}'.\n\nKas soovid muudatuse kohe QGIS ühendustesse rakendada?",
        "ENG": "Service renamed: '{old_name}' ➔ '{new_name}'.\n\nDo you want to apply this change to QGIS connections now?"
    },
    "menu_inspect_layers": {
        "EST": "Ava Kihtide paneelis (Uuri & Testi)",
        "ENG": "Open in Layers Panel (Inspect & Test)"
    },
    "menu_advanced_info": {
        "EST": "Täpsem info & metaandmed...",
        "ENG": "Advanced Info & Metadata..."
    },
    "menu_rename": {
        "EST": "✏️ Nimeta",
        "ENG": "✏️ Rename"
    },
    "menu_suggest_name": {
        "EST": "Paku ametlikku nime (Metaandmed)...",
        "ENG": "Suggest official name (Metadata)..."
    },
    "dialog_suggest_name_title": {
        "EST": "Soovita ametlikku nime metaandmetest",
        "ENG": "Suggest Official Name from Metadata"
    },
    "suggest_dialog_prompt": {
        "EST": "Vali sobiv nimi metaandmete soovituste hulgast või muuda seda:",
        "ENG": "Choose a suitable name from metadata suggestions or edit it:"
    },
    "suggest_source_preset": {
        "EST": "Kataloogi ametlik nimetus",
        "ENG": "Catalog official name"
    },
    "suggest_source_server": {
        "EST": "Serveri OGC päise tiitel",
        "ENG": "Server OGC header title"
    },
    "btn_apply_name": {
        "EST": "Võta nimi kasutusele",
        "ENG": "Apply Name"
    },
    "msg_name_updated": {
        "EST": "Teenuse nimi uuendatud: '{name}'",
        "ENG": "Service name updated to: '{name}'"
    },
    "in_my_profile_pill": {
        "EST": "✓ Minu profiilis: \"{name}\"",
        "ENG": "✓ In my profile: \"{name}\""
    },
    "view_mode_both": {
        "EST": "Kõrvuti",
        "ENG": "Both"
    },
    "view_mode_layers": {
        "EST": "Ainult kihid",
        "ENG": "Layers only"
    },
    "view_mode_profile": {
        "EST": "Ainult profiil",
        "ENG": "Profile only"
    },
    "view_orientation_toggle": {
        "EST": "Vaheta paigutust (Kõrvuti / Ülestikku)",
        "ENG": "Toggle Layout (Horizontal / Vertical)"
    },
    "menu_remove": {
        "EST": "Eemalda profiilist",
        "ENG": "Remove from Profile"
    },
    "menu_copy_layer_name": {
        "EST": "Kopeeri kihi nimi",
        "ENG": "Copy Layer Name"
    },
    "menu_remove_layer": {
        "EST": "Eemalda kiht profiilist",
        "ENG": "Remove Layer"
    },
    "rename_dialog_title": {
        "EST": "Teenuse ümbernimetamine",
        "ENG": "Rename Service"
    },
    "rename_dialog_label": {
        "EST": "Uus nimi teenusele:",
        "ENG": "New name for service:"
    },
    "info_dialog_title": {
        "EST": "Teenuse metaandmed ja tehniline info",
        "ENG": "Service Metadata & Technical Info"
    },
    "btn_copy_url": {
        "EST": "Kopeeri URL",
        "ENG": "Copy URL"
    },
    "btn_inspect_in_layers": {
        "EST": "Ava Kihtide paneelis →",
        "ENG": "Open in Layers Panel →"
    },
    "meta_version_server": {
        "EST": "Protokoll & Server:",
        "ENG": "Protocol & Server:"
    },
    "meta_geometry_breakdown": {
        "EST": "Geomeetriate jaotus:",
        "ENG": "Geometry Breakdown:"
    },
    "expand_loading": {
        "EST": "Laaditakse kihte...",
        "ENG": "Loading layers..."
    },
    "double_click_layer_hint": {
        "EST": "💡 Vihje: topeltklõps kihil lisab selle otse kaardile (Add to Map)",
        "ENG": "💡 Tip: double-click a layer to add it directly to the map canvas"
    },
    "btn_close": {
        "EST": "Sulge",
        "ENG": "Close"
    },

    # Custom Service Dialog
    "btn_add_custom_url": {
        "EST": "+ Lisa oma URL...",
        "ENG": "+ Add Custom URL..."
    },
    "custom_svc_title": {
        "EST": "Lisa oma ruumiandmeteenuse URL",
        "ENG": "Add Custom Geospatial Service URL"
    },
    "svc_name_label": {
        "EST": "Teenuse nimi:",
        "ENG": "Service Name:"
    },
    "svc_url_label": {
        "EST": "Teenuse URL:",
        "ENG": "Service URL:"
    },
    "service_type_label": {
        "EST": "Protokoll:",
        "ENG": "Protocol:"
    },
    "auth_options_header": {
        "EST": "Autentimine & kohandatud päised (mitteavalikud teenused)",
        "ENG": "Authentication & Custom Headers (Non-public services)"
    },
    "auth_none": {
        "EST": "Avalik (autentimiseta)",
        "ENG": "Public (No auth)"
    },
    "auth_basic": {
        "EST": "Basic Auth (kasutajanimi / parool)",
        "ENG": "Basic Auth (Username / Password)"
    },
    "auth_token": {
        "EST": "API Võti / Päis (Token / Bearer)",
        "ENG": "API Key / Header (Token / Bearer)"
    },
    "auth_qgis_cfg": {
        "EST": "QGIS Auth Manageri profiil (authcfg)",
        "ENG": "QGIS Auth Manager Profile (authcfg)"
    },
    "username": {
        "EST": "Kasutajanimi:",
        "ENG": "Username:"
    },
    "password": {
        "EST": "Parool:",
        "ENG": "Password:"
    },
    "token_header": {
        "EST": "Päise nimi:",
        "ENG": "Header Name:"
    },
    "token_value": {
        "EST": "Võtme / Päise väärtus:",
        "ENG": "Key / Header Value:"
    },
    "authcfg_code": {
        "EST": "Authcfg ID (nt 7 tähemärki):",
        "ENG": "Authcfg ID (e.g. 7 characters):"
    },

    # Settings View
    "language_choice": {
        "EST": "Keelevalik (Language):",
        "ENG": "Language Selection:"
    },
    "theme_choice": {
        "EST": "Välimuse teema (Theme):",
        "ENG": "Color Theme:"
    },
    "theme_dark": {
        "EST": "Tume (Dark Modern)",
        "ENG": "Dark (Modern)"
    },
    "theme_light": {
        "EST": "Hele (Light Modern)",
        "ENG": "Light (Modern)"
    },
    "timeout_setting": {
        "EST": "Võrgupäringu ajalõpp (sekundites):",
        "ENG": "Network Request Timeout (seconds):"
    },
    "default_crs_label": {
        "EST": "Eelistatud koordinaatsüsteem:",
        "ENG": "Preferred CRS:"
    },

    # Messages & Notifications
    "msg_profile_applied": {
        "EST": "Profiil '{name}' rakendatud edukalt! {count} ühendust registreeritud QGIS-is.",
        "ENG": "Profile '{name}' applied successfully! {count} connections registered in QGIS."
    },
    "msg_layer_added": {
        "EST": "Kiht '{name}' lisatud edukalt töölauale.",
        "ENG": "Layer '{name}' successfully added to map canvas."
    },
    "msg_split_group_added": {
        "EST": "Segageomeetriaga kiht '{name}' eraldatud {count} eraldi kihiks grupis '{group}'!",
        "ENG": "Mixed-geometry layer '{name}' split into {count} separate layers in group '{group}'!"
    },
    "dialog_new_profile_title": {
        "EST": "Uue profiili loomine",
        "ENG": "Create New Profile"
    },
    "dialog_new_profile_prompt": {
        "EST": "Sisesta uue profiili nimi:",
        "ENG": "Enter new profile name:"
    },
    "confirm_delete_profile": {
        "EST": "Kas oled kindel, et soovid kustutada profiili '{name}'?",
        "ENG": "Are you sure you want to delete profile '{name}'?"
    },

    # Common
    "btn_close": {
        "EST": "Sulge",
        "ENG": "Close"
    },
    "btn_cancel": {
        "EST": "Tühista",
        "ENG": "Cancel"
    },
    "btn_ok": {
        "EST": "Olgu",
        "ENG": "OK"
    },
    "notice": {
        "EST": "Teade",
        "ENG": "Notice"
    },
    "warning": {
        "EST": "Hoiatus",
        "ENG": "Warning"
    },
    "error": {
        "EST": "Viga",
        "ENG": "Error"
    },
    "success": {
        "EST": "Õnnestus",
        "ENG": "Success"
    },
    "btn_new_group": {
        "EST": "+ Grupp",
        "ENG": "+ Group"
    },
    "btn_new_group_tooltip": {
        "EST": "Loo profiili uus kohandatud segagrupp (MIXED), kuhu saab kombineerida kihte erinevatest teenustest",
        "ENG": "Create a new custom mixed group (MIXED) to combine layers from different services"
    },
    "dialog_new_group_title": {
        "EST": "Uus kohandatud grupp (MIXED)",
        "ENG": "New Custom Group (MIXED)"
    },
    "dialog_new_group_prompt": {
        "EST": "Sisesta kohandatud grupi nimi:",
        "ENG": "Enter custom group name:"
    },
    "group_mixed_title": {
        "EST": "KOHANDATUD GRUPID (MIXED)",
        "ENG": "CUSTOM GROUPS (MIXED)"
    },
    "menu_new_mixed_group": {
        "EST": "Uus kohandatud grupp (MIXED)...",
        "ENG": "New Custom Group (MIXED)..."
    },
    "menu_add_to_mixed_group": {
        "EST": "Lisa kohandatud gruppi (MIXED)...",
        "ENG": "Add to Custom Group (MIXED)..."
    },
    "menu_remove_from_group": {
        "EST": "Eemalda sellest grupist",
        "ENG": "Remove from this group"
    },
    "mixed_empty_hint": {
        "EST": "(Tühi grupp - lohista kihte siia)",
        "ENG": "(Empty group - drag layers here)"
    },
    "msg_mixed_group_created": {
        "EST": "Kohandatud grupp loodud: {name}",
        "ENG": "Custom group created: {name}"
    },
    "msg_layer_added_to_group": {
        "EST": "Kiht '{layer}' lisatud gruppi '{group}'!",
        "ENG": "Layer '{layer}' added to group '{group}'!"
    },
    "msg_layer_already_in_group": {
        "EST": "Kiht '{layer}' on juba grupis '{group}'!",
        "ENG": "Layer '{layer}' is already in group '{group}'!"
    },
    "canvas_group_added": {
        "EST": "Grupp '{name}' ({count} kihti) avatud kaardil!",
        "ENG": "Group '{name}' ({count} layers) loaded to canvas!"
    },
    "btn_open_group_canvas": {
        "EST": "Ava kogu grupp kaardil",
        "ENG": "Load entire group to canvas"
    }
}


def tr(key, **kwargs):
    """Retrieve translated string with optional formatting."""
    lang = CURRENT_LANG
    entry = TRANSLATIONS.get(key)
    if not entry:
        return key
    text = entry.get(lang, entry.get("ENG", key))
    if kwargs:
        try:
            return text.format(**kwargs)
        except Exception:
            return text
    return text


def set_language(lang_code):
    """Set the active language ('EST' or 'ENG')."""
    global CURRENT_LANG
    if lang_code in ("EST", "ENG"):
        CURRENT_LANG = lang_code


def get_language():
    """Get active language code."""
    return CURRENT_LANG
