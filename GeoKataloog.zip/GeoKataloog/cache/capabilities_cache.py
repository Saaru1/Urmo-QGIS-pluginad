# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Capabilities XML Disk & Memory Cache.
Eliminates repetitive network queries and accelerates service inspection to 0ms latency.
"""

import os
import time
import json
import hashlib
from ..utils.url import normalize_service_url


class CapabilitiesCache:
    """Manages persistent caching of OGC GetCapabilities responses."""

    def __init__(self, cache_dir=None, default_ttl=86400):
        self.default_ttl = default_ttl  # Default 24 hours
        self._mem_cache = {}  # In-memory session cache

        if cache_dir:
            self.cache_dir = cache_dir
        else:
            base_dir = ""
            try:
                from qgis.core import QgsApplication
                base_dir = QgsApplication.qgisSettingsDirPath()
            except Exception:
                pass
            if not base_dir:
                base_dir = os.path.expanduser("~/.geoprofile_hub")
            self.cache_dir = os.path.join(base_dir, "capabilities_cache")

        try:
            os.makedirs(self.cache_dir, exist_ok=True)
        except Exception:
            pass

    def _get_key(self, service_type, url):
        stype = (service_type or "WMS").upper()
        norm_u = normalize_service_url(url, service_type=stype)
        h = hashlib.sha256(f"{stype}:{norm_u}".encode("utf-8")).hexdigest()[:20]
        return f"{stype}_{h}"

    def get(self, service_type, url, max_age_seconds=None):
        """
        Retrieves cached XML string if available and not expired.
        Returns None if missing or expired.
        """
        ttl = max_age_seconds if max_age_seconds is not None else self.default_ttl
        if ttl <= 0:
            return None
        key = self._get_key(service_type, url)

        # 1. Fast memory check
        if key in self._mem_cache:
            entry = self._mem_cache[key]
            if time.time() - entry["time"] <= ttl:
                return entry["data"]

        # 2. Disk check
        fpath = os.path.join(self.cache_dir, f"{key}.json")
        if not os.path.exists(fpath):
            return None

        try:
            with open(fpath, "r", encoding="utf-8") as f:
                payload = json.load(f)
            ts = payload.get("time", 0)
            if time.time() - ts <= ttl:
                data = payload.get("data", "")
                self._mem_cache[key] = {"time": ts, "data": data}
                return data
        except Exception:
            pass

        return None

    def set(self, service_type, url, xml_data):
        """Saves XML response to memory and persistent disk cache."""
        if not xml_data:
            return
        key = self._get_key(service_type, url)
        now = time.time()

        if isinstance(xml_data, bytes):
            text_data = xml_data.decode("utf-8", errors="replace")
        else:
            text_data = str(xml_data)

        self._mem_cache[key] = {"time": now, "data": text_data}

        fpath = os.path.join(self.cache_dir, f"{key}.json")
        try:
            with open(fpath, "w", encoding="utf-8") as f:
                json.dump({"time": now, "url": url, "stype": service_type, "data": text_data}, f, ensure_ascii=False)
        except Exception:
            pass

    def clear(self, service_type=None, url=None):
        """Clears cache for specific service or all cached items."""
        if service_type and url:
            key = self._get_key(service_type, url)
            self._mem_cache.pop(key, None)
            fpath = os.path.join(self.cache_dir, f"{key}.json")
            if os.path.exists(fpath):
                try:
                    os.remove(fpath)
                except Exception:
                    pass
        else:
            self._mem_cache.clear()
            if os.path.exists(self.cache_dir):
                for fname in os.listdir(self.cache_dir):
                    if fname.endswith(".json"):
                        try:
                            os.remove(os.path.join(self.cache_dir, fname))
                        except Exception:
                            pass


# Singleton cache instance
_CAP_CACHE_INSTANCE = None

def get_capabilities_cache():
    """Returns singleton CapabilitiesCache instance."""
    global _CAP_CACHE_INSTANCE
    if _CAP_CACHE_INSTANCE is None:
        _CAP_CACHE_INSTANCE = CapabilitiesCache()
    return _CAP_CACHE_INSTANCE
