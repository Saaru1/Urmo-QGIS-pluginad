# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Persistent Layer Catalog Cache.
Provides instantaneous (0ms) access to layer catalogs across sessions and eliminates
silent loading delays. Bundles pre-indexed Estonian government layer catalogs.
"""

import os
import json
import time
from ..utils.url import normalize_service_url


class LayerCatalogCache:
    """Manages persistent layer catalogs on disk and in memory."""

    def __init__(self, cache_dir=None):
        self._mem_cache = {}
        self._bundled_seeds = {}

        if cache_dir:
            self.cache_dir = cache_dir
        else:
            base_dir = ""
            try:
                from qgis.core import QgsApplication
                base_dir = QgsApplication.qgisSettingsDirPath()
            except Exception:
                pass
            if not base_dir:
                base_dir = os.path.expanduser("~/.geoprofile_hub")
            self.cache_dir = os.path.join(base_dir, "layer_catalogs")

        try:
            os.makedirs(self.cache_dir, exist_ok=True)
        except Exception:
            pass

        self.disk_file = os.path.join(self.cache_dir, "layer_catalog_cache.json")
        self._load_bundled_seeds()
        self._load_disk_cache()

    def _normalize_key(self, service_type, url):
        stype = (service_type or "WMS").upper()
        norm_u = normalize_service_url(url, service_type=stype)
        return f"{stype}:{norm_u}"

    def _load_bundled_seeds(self):
        """Loads bundled canonical layer catalogs shipped with GeoKataloog."""
        bundled_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "resources", "bundled_seeds.json"
        )
        if os.path.exists(bundled_path):
            try:
                with open(bundled_path, "r", encoding="utf-8") as f:
                    raw_data = json.load(f)
                for key_str, layers in raw_data.items():
                    if ":" in key_str and layers:
                        parts = key_str.split(":", 1)
                        stype = parts[0]
                        u = parts[1]
                        norm_key = self._normalize_key(stype, u)
                        self._bundled_seeds[norm_key] = layers
            except Exception:
                pass

    def _load_disk_cache(self):
        """Loads user's cached layer lists from persistent disk JSON."""
        if not os.path.exists(self.disk_file):
            return
        try:
            with open(self.disk_file, "r", encoding="utf-8") as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                for k, v in saved.items():
                    if isinstance(v, list):
                        self._mem_cache[k] = v
        except Exception:
            pass

    def _save_disk_cache(self):
        """Persists in-memory cache to disk JSON."""
        try:
            with open(self.disk_file, "w", encoding="utf-8") as f:
                json.dump(self._mem_cache, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def get_layers(self, service_type, url):
        """
        Retrieves cached layers for given service type and URL.
        Checks user disk cache first, then falls back to bundled seeds.
        """
        if not url:
            return None
        key = self._normalize_key(service_type, url)

        # 1. User session / disk cache
        if key in self._mem_cache:
            return list(self._mem_cache[key])

        # 2. Bundled verified seed catalogs
        if key in self._bundled_seeds:
            return list(self._bundled_seeds[key])

        # 3. Fuzzy match by URL path (ignoring trailing query params or wfs vs ows difference)
        clean_url = url.split("?")[0].rstrip("/")
        stype = (service_type or "WMS").upper()
        for k, v in self._mem_cache.items():
            if k.startswith(f"{stype}:") and clean_url in k:
                return list(v)
        for k, v in self._bundled_seeds.items():
            if k.startswith(f"{stype}:") and clean_url in k:
                return list(v)

        return None

    def has_layers(self, service_type, url):
        """Checks if service layers are available in cache or bundled seeds."""
        return self.get_layers(service_type, url) is not None

    def set_layers(self, service_type, url, layers):
        """Saves inspected layer list to persistent cache."""
        if not url or not layers:
            return
        key = self._normalize_key(service_type, url)
        self._mem_cache[key] = layers
        self._save_disk_cache()

    def all_services_and_layers(self):
        """
        Yields tuple (service_type, url, layers_list) for all known catalogs
        (combining bundled seeds and user-discovered services).
        """
        combined = dict(self._bundled_seeds)
        combined.update(self._mem_cache)
        for key_str, layers in combined.items():
            if ":" in key_str and layers:
                parts = key_str.split(":", 1)
                yield parts[0], parts[1], layers


# Singleton
_LAYER_CACHE_INSTANCE = None

def get_layer_catalog_cache():
    """Returns singleton LayerCatalogCache instance."""
    global _LAYER_CACHE_INSTANCE
    if _LAYER_CACHE_INSTANCE is None:
        _LAYER_CACHE_INSTANCE = LayerCatalogCache()
    return _LAYER_CACHE_INSTANCE
