# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Modern Stylesheet & Themes
Provides meticulously crafted Light and Dark themes with flawless text contrast.
Eliminates any white-on-light or dark-on-dark contrast bugs.
"""

import os

CURRENT_THEME = "LIGHT"
RESOURCES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources").replace("\\", "/")


def get_stylesheet(theme="LIGHT"):
    """Returns CSS stylesheet for specified theme ('LIGHT' or 'DARK') with resolved resource paths."""
    raw = LIGHT_STYLESHEET if theme == "LIGHT" else DARK_STYLESHEET
    return raw.replace("__RES_DIR__", RESOURCES_DIR)


def set_theme(theme_name):
    """Update active theme and configure global QToolTip palette for clean readability."""
    global CURRENT_THEME
    if theme_name in ("LIGHT", "DARK"):
        CURRENT_THEME = theme_name
        try:
            from qgis.PyQt import QtWidgets, QtGui
            app = QtWidgets.QApplication.instance()
            if app:
                pal = QtWidgets.QToolTip.palette()
                role_base = QtGui.QPalette.ColorRole.ToolTipBase if hasattr(QtGui.QPalette, 'ColorRole') else QtGui.QPalette.ToolTipBase
                role_text = QtGui.QPalette.ColorRole.ToolTipText if hasattr(QtGui.QPalette, 'ColorRole') else QtGui.QPalette.ToolTipText
                if theme_name == "LIGHT":
                    pal.setColor(role_base, QtGui.QColor("#ffffff"))
                    pal.setColor(role_text, QtGui.QColor("#0f172a"))
                else:
                    pal.setColor(role_base, QtGui.QColor("#1e293b"))
                    pal.setColor(role_text, QtGui.QColor("#f8fafc"))
                QtWidgets.QToolTip.setPalette(pal)
        except Exception:
            pass


def get_current_theme():
    return CURRENT_THEME


# -------------------------------------------------------------
# DARK THEME (Robust high-contrast slate & azure)
# -------------------------------------------------------------
DARK_STYLESHEET = """
/* Tooltip styling - crystal clear high-contrast hover boxes */
QToolTip {
    background-color: #1e293b;
    color: #f8fafc;
    border: 1px solid #38bdf8;
    border-radius: 4px;
    padding: 5px 8px;
    font-size: 8.5pt;
    font-weight: 500;
}

/* Base DockWidget & Root Container */
QDockWidget, QWidget#MainDockContent, QWidget#MainContent, QDialog {
    background-color: #0b1120;
    color: #f1f5f9;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 10pt;
}

QDockWidget::title {
    background-color: #1e293b;
    color: #f8fafc;
    padding: 8px 12px;
    font-weight: 700;
    border-bottom: 1px solid #334155;
}

/* Header Banner */
QFrame#HeaderBanner {
    background-color: #1e293b;
    border-bottom: 1px solid #334155;
    padding: 3px 10px;
    max-height: 40px;
}
QLabel#AppTitle {
    font-size: 12pt;
    font-weight: 700;
    color: #f8fafc;
}
QLabel#AppSubtitle {
    font-size: 8.5pt;
    color: #94a3b8;
}
QPushButton#BtnHeaderMinimize, QPushButton#BtnHeaderDock {
    background-color: #334155;
    border: 1px solid #475569;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 8.5pt;
    font-weight: 600;
    color: #f1f5f9;
}
QPushButton#BtnHeaderMinimize:hover, QPushButton#BtnHeaderDock:hover {
    background-color: #475569;
    border-color: #38bdf8;
    color: #ffffff;
}
QPushButton#BtnHeaderClose {
    background-color: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    padding: 2px 5px;
    font-size: 9pt;
    font-weight: 700;
    color: #94a3b8;
}
QPushButton#BtnHeaderClose:hover {
    background-color: #ef4444;
    border-color: #dc2626;
    color: #ffffff;
}

/* Splitter */
QSplitter::handle {
    background-color: #334155;
    width: 3px;
    height: 3px;
}
QSplitter::handle:hover {
    background-color: #38bdf8;
}

/* Tab Bar */
QTabWidget::pane {
    border: 1px solid #334155;
    background-color: #111827;
    border-radius: 6px;
    top: -1px;
}
QTabBar::tab {
    background-color: #0f172a;
    color: #94a3b8;
    padding: 7px 14px;
    margin-right: 3px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    border: 1px solid #334155;
    border-bottom: none;
    font-weight: 500;
}
QTabBar::tab:selected {
    background-color: #1e293b;
    color: #38bdf8;
    font-weight: 600;
    border-bottom: 2px solid #38bdf8;
}
QTabBar::tab:hover:!selected {
    background-color: #1e293b;
    color: #f8fafc;
}

/* Card Frames */
QFrame.CardFrame, QFrame#CardFrame {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 10px;
    color: #f1f5f9;
}

/* Highlighted Overview & Diagnostics Card */
QFrame#MetaOverviewCard {
    background-color: #111c30;
    border: 1px solid #334155;
    border-left: 5px solid #38bdf8;
    border-radius: 8px;
    padding: 8px;
}
QFrame#MetaOverviewHeader {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 6px 10px;
}
QFrame.MetaBadgeCard {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 5px;
    padding: 4px 8px;
}
QFrame#MixedGeometryBox {
    background-color: #2e1065;
    border: 1px solid #c026d3;
    border-radius: 6px;
    padding: 6px;
}

/* Progress Bar */
QProgressBar {
    background-color: #0f172a;
    border: 1px solid #334155;
    border-radius: 4px;
    text-align: center;
    color: #f8fafc;
    font-size: 8pt;
    font-weight: 700;
    min-height: 15px;
    max-height: 15px;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284c7, stop:1 #38bdf8);
    border-radius: 3px;
}

/* Labels */
QLabel {
    color: #f1f5f9;
    background-color: transparent;
}
QLabel.SectionTitle {
    font-size: 10.5pt;
    font-weight: 600;
    color: #f8fafc;
    margin-bottom: 2px;
}

/* Group Boxes */
QGroupBox {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 6px;
    margin-top: 14px;
    padding-top: 14px;
    font-weight: 600;
    color: #38bdf8;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 4px;
    color: #38bdf8;
    background-color: #1e293b;
}

/* Inputs & ComboBoxes */
QLineEdit, QSpinBox {
    background-color: #0f172a;
    border: 1px solid #475569;
    border-radius: 5px;
    padding: 6px 9px;
    color: #f8fafc;
    selection-background-color: #0284c7;
    selection-color: #ffffff;
}
QLineEdit:focus, QSpinBox:focus {
    border: 1px solid #38bdf8;
}

/* Distinct Dropdown List Appearance */
QComboBox {
    background-color: #0f172a;
    border: 1px solid #64748b;
    border-radius: 5px;
    padding: 5px 32px 5px 10px;
    color: #f8fafc;
    font-weight: 600;
    selection-background-color: #0284c7;
    selection-color: #ffffff;
}
QComboBox:hover {
    border-color: #38bdf8;
    background-color: #1e293b;
}
QComboBox:focus {
    border: 1.5px solid #38bdf8;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 28px;
    border-left: 1px solid #475569;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
    background-color: #1e293b;
}
QComboBox::drop-down:hover {
    background-color: #334155;
    border-left-color: #38bdf8;
}
QComboBox::down-arrow {
    image: url("__RES_DIR__/chevron_down_light.svg");
    width: 12px;
    height: 12px;
}
QComboBox::down-arrow:hover {
    image: url("__RES_DIR__/chevron_down_light_hover.svg");
}
QComboBox QAbstractItemView {
    background-color: #1e293b;
    border: 1.5px solid #38bdf8;
    border-radius: 4px;
    color: #f8fafc;
    padding: 4px;
    selection-background-color: #0369a1;
    selection-color: #ffffff;
}
QComboBox QAbstractItemView::item {
    min-height: 26px;
    padding: 4px 8px;
    border-radius: 3px;
}
QComboBox QAbstractItemView::item:hover {
    background-color: #0f172a;
    color: #38bdf8;
}

/* CheckBoxes - Dark Mode */
QCheckBox {
    color: #f1f5f9;
    font-size: 9pt;
    font-weight: 500;
    spacing: 7px;
}
QCheckBox:hover {
    color: #38bdf8;
}
QCheckBox::indicator {
    width: 17px;
    height: 17px;
    border-radius: 4px;
    border: 1.5px solid #64748b;
    background-color: #0f172a;
}
QCheckBox::indicator:hover {
    border-color: #38bdf8;
    background-color: #1e293b;
}
QCheckBox::indicator:checked {
    background-color: #0284c7;
    border-color: #38bdf8;
}

/* PushButtons */
QPushButton {
    background-color: #1e293b;
    border: 1px solid #475569;
    border-radius: 5px;
    padding: 6px 12px;
    color: #f1f5f9;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #334155;
    border-color: #64748b;
    color: #ffffff;
}
QPushButton:pressed {
    background-color: #475569;
}
QPushButton:disabled {
    background-color: #111827;
    border-color: #1f2937;
    color: #64748b;
}

/* Primary Button */
QPushButton.PrimaryButton, QPushButton#PrimaryButton {
    background-color: #0284c7;
    border: 1px solid #38bdf8;
    color: #ffffff;
    font-weight: 600;
}
QPushButton.PrimaryButton:hover, QPushButton#PrimaryButton:hover {
    background-color: #0369a1;
}

/* Success Button */
QPushButton.SuccessButton, QPushButton#SuccessButton {
    background-color: #059669;
    border: 1px solid #10b981;
    color: #ffffff;
    font-weight: 600;
}
QPushButton.SuccessButton:hover, QPushButton#SuccessButton:hover {
    background-color: #047857;
}

/* Danger Button */
QPushButton.DangerButton, QPushButton#DangerButton {
    background-color: #1e293b;
    border: 1px solid #991b1b;
    color: #f87171;
}
QPushButton.DangerButton:hover, QPushButton#DangerButton:hover {
    background-color: #450a0a;
}

/* Tables and Trees */
QTableWidget, QTreeWidget, QListWidget {
    background-color: #0f172a;
    alternate-background-color: #162032;
    border: 1px solid #334155;
    border-radius: 5px;
    gridline-color: #1e293b;
    selection-background-color: #0369a1;
    selection-color: #ffffff;
    color: #f8fafc;
    outline: none;
}
QTableWidget::item, QTreeWidget::item, QListWidget::item {
    padding: 5px 6px;
    color: #f1f5f9;
}
QTableWidget::item:selected, QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #0369a1;
    color: #ffffff;
}
QHeaderView::section {
    background-color: #1e293b;
    color: #94a3b8;
    font-weight: 600;
    border: none;
    border-bottom: 1px solid #334155;
    border-right: 1px solid #334155;
    padding: 6px 8px;
}

/* ScrollBars */
QScrollBar:vertical, QScrollBar:horizontal {
    border: none;
    background: #0f172a;
    width: 8px;
    height: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical, QScrollBar::handle:horizontal {
    background: #334155;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar::handle:hover {
    background: #475569;
}

/* Badges & Pills */
QLabel.BadgeWFS {
    background-color: #1e3a8a;
    color: #bfdbfe;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeWMS {
    background-color: #78350f;
    color: #fde68a;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeWCS {
    background-color: #0e7490;
    color: #cffafe;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeWMTS {
    background-color: #312e81;
    color: #c7d2fe;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeXYZ {
    background-color: #4c1d95;
    color: #ddd6fe;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeGeom {
    background-color: #064e3b;
    color: #86efac;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeMixed {
    background-color: #701a75;
    color: #f5d0fe;
    border: 1px solid #c026d3;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 700;
    font-size: 8pt;
}
QLabel.BadgeInProfile {
    background-color: #064e3b;
    color: #6ee7b7;
    border: 1px solid #059669;
    border-radius: 3px;
    padding: 1px 6px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeCRS {
    background-color: #1e293b;
    color: #cbd5e1;
    border: 1px solid #475569;
    border-radius: 3px;
    padding: 2px 5px;
    font-size: 8pt;
}
"""

# -------------------------------------------------------------
# LIGHT THEME (Minimalist clean and balanced)
# -------------------------------------------------------------
LIGHT_STYLESHEET = """
/* Tooltip styling - crystal clear high-contrast white hover boxes */
QToolTip {
    background-color: #ffffff;
    color: #0f172a;
    border: 1px solid #94a3b8;
    border-radius: 4px;
    padding: 5px 8px;
    font-size: 8.5pt;
    font-weight: 500;
}

/* Base DockWidget & Root Container */
QDockWidget, QWidget#MainDockContent, QWidget#MainContent, QDialog {
    background-color: #f8fafc;
    color: #0f172a;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 10pt;
}

QDockWidget::title {
    background-color: #ffffff;
    color: #0f172a;
    padding: 8px 12px;
    font-weight: 700;
    border-bottom: 1px solid #e2e8f0;
}

/* Header Banner */
QFrame#HeaderBanner {
    background-color: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    padding: 3px 10px;
    max-height: 40px;
}
QLabel#AppTitle {
    font-size: 12pt;
    font-weight: 700;
    color: #0f172a;
}
QLabel#AppSubtitle {
    font-size: 8.5pt;
    color: #64748b;
}
QPushButton#BtnHeaderMinimize, QPushButton#BtnHeaderDock {
    background-color: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 2px 7px;
    font-size: 8.5pt;
    font-weight: 600;
    color: #1e293b;
}
QPushButton#BtnHeaderMinimize:hover, QPushButton#BtnHeaderDock:hover {
    background-color: #e2e8f0;
    border-color: #0284c7;
    color: #0f172a;
}
QPushButton#BtnHeaderClose {
    background-color: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    padding: 2px 5px;
    font-size: 9pt;
    font-weight: 700;
    color: #64748b;
}
QPushButton#BtnHeaderClose:hover {
    background-color: #ef4444;
    border-color: #dc2626;
    color: #ffffff;
}

/* Splitter */
QSplitter::handle {
    background-color: #cbd5e1;
    width: 3px;
    height: 3px;
}
QSplitter::handle:hover {
    background-color: #0284c7;
}

/* Tab Bar */
QTabWidget::pane {
    border: 1px solid #e2e8f0;
    background-color: #ffffff;
    border-radius: 6px;
    top: -1px;
}
QTabBar::tab {
    background-color: #f1f5f9;
    color: #475569;
    padding: 7px 14px;
    margin-right: 3px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    border: 1px solid #e2e8f0;
    border-bottom: none;
    font-weight: 500;
}
QTabBar::tab:selected {
    background-color: #ffffff;
    color: #0284c7;
    font-weight: 600;
    border-bottom: 2px solid #0284c7;
}
QTabBar::tab:hover:!selected {
    background-color: #e2e8f0;
    color: #0f172a;
}

/* Card Frames */
QFrame.CardFrame, QFrame#CardFrame {
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 10px;
    color: #0f172a;
}

/* Highlighted Overview & Diagnostics Card */
QFrame#MetaOverviewCard {
    background-color: #f8fafc;
    border: 1px solid #bae6fd;
    border-left: 5px solid #0284c7;
    border-radius: 8px;
    padding: 8px;
}
QFrame#MetaOverviewHeader {
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 6px 10px;
}
QFrame.MetaBadgeCard {
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 5px;
    padding: 4px 8px;
}
QFrame#MixedGeometryBox {
    background-color: #fdf4ff;
    border: 1px solid #d946ef;
    border-radius: 6px;
    padding: 6px;
}

/* Progress Bar */
QProgressBar {
    background-color: #f1f5f9;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    text-align: center;
    color: #0f172a;
    font-size: 8pt;
    font-weight: 700;
    min-height: 15px;
    max-height: 15px;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284c7, stop:1 #38bdf8);
    border-radius: 3px;
}

/* Labels */
QLabel {
    color: #0f172a;
    background-color: transparent;
}
QLabel.SectionTitle {
    font-size: 10.5pt;
    font-weight: 600;
    color: #0f172a;
    margin-bottom: 2px;
}

/* Group Boxes */
QGroupBox {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    margin-top: 14px;
    padding-top: 14px;
    font-weight: 600;
    color: #0284c7;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 4px;
    color: #0284c7;
    background-color: #ffffff;
}

/* Inputs & ComboBoxes */
QLineEdit, QSpinBox {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 5px;
    padding: 6px 9px;
    color: #0f172a;
    selection-background-color: #38bdf8;
    selection-color: #ffffff;
}
QLineEdit:focus, QSpinBox:focus {
    border: 1px solid #0284c7;
}

/* Distinct Dropdown List Appearance */
QComboBox {
    background-color: #ffffff;
    border: 1.5px solid #94a3b8;
    border-radius: 5px;
    padding: 5px 32px 5px 10px;
    color: #0f172a;
    font-weight: 600;
    selection-background-color: #38bdf8;
    selection-color: #ffffff;
}
QComboBox:hover {
    border-color: #0284c7;
    background-color: #f8fafc;
}
QComboBox:focus {
    border: 1.5px solid #0284c7;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 28px;
    border-left: 1px solid #cbd5e1;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
    background-color: #f1f5f9;
}
QComboBox::drop-down:hover {
    background-color: #e0f2fe;
    border-left-color: #0284c7;
}
QComboBox::down-arrow {
    image: url("__RES_DIR__/chevron_down_slate.svg");
    width: 12px;
    height: 12px;
}
QComboBox::down-arrow:hover {
    image: url("__RES_DIR__/chevron_down_sky.svg");
}
QComboBox QAbstractItemView {
    background-color: #ffffff;
    border: 1.5px solid #0284c7;
    border-radius: 4px;
    color: #0f172a;
    padding: 4px;
    selection-background-color: #e0f2fe;
    selection-color: #0369a1;
}
QComboBox QAbstractItemView::item {
    min-height: 26px;
    padding: 4px 8px;
    border-radius: 3px;
}
QComboBox QAbstractItemView::item:hover {
    background-color: #f0f9ff;
    color: #0284c7;
}

/* CheckBoxes - Light Mode */
QCheckBox {
    color: #0f172a;
    font-size: 9pt;
    font-weight: 500;
    spacing: 7px;
}
QCheckBox:hover {
    color: #0284c7;
}
QCheckBox::indicator {
    width: 17px;
    height: 17px;
    border-radius: 4px;
    border: 1.5px solid #94a3b8;
    background-color: #ffffff;
}
QCheckBox::indicator:hover {
    border-color: #0284c7;
    background-color: #f0f9ff;
}
QCheckBox::indicator:checked {
    background-color: #0284c7;
    border-color: #0284c7;
}

/* PushButtons */
QPushButton {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 5px;
    padding: 6px 12px;
    color: #334155;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #f1f5f9;
    border-color: #94a3b8;
    color: #0f172a;
}
QPushButton:pressed {
    background-color: #e2e8f0;
}
QPushButton:disabled {
    background-color: #f8fafc;
    border-color: #e2e8f0;
    color: #94a3b8;
}

/* Primary Button */
QPushButton.PrimaryButton, QPushButton#PrimaryButton {
    background-color: #0284c7;
    border: 1px solid #0284c7;
    color: #ffffff;
    font-weight: 600;
}
QPushButton.PrimaryButton:hover, QPushButton#PrimaryButton:hover {
    background-color: #0369a1;
}

/* Success Button */
QPushButton.SuccessButton, QPushButton#SuccessButton {
    background-color: #059669;
    border: 1px solid #059669;
    color: #ffffff;
    font-weight: 600;
}
QPushButton.SuccessButton:hover, QPushButton#SuccessButton:hover {
    background-color: #047857;
}

/* Danger Button */
QPushButton.DangerButton, QPushButton#DangerButton {
    background-color: #ffffff;
    border: 1px solid #fecaca;
    color: #dc2626;
}
QPushButton.DangerButton:hover, QPushButton#DangerButton:hover {
    background-color: #fee2e2;
}

/* Tables and Trees */
QTableWidget, QTreeWidget, QListWidget {
    background-color: #ffffff;
    alternate-background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 5px;
    gridline-color: #f1f5f9;
    selection-background-color: #e0f2fe;
    selection-color: #0369a1;
    color: #0f172a;
    outline: none;
}
QTableWidget::item, QTreeWidget::item, QListWidget::item {
    padding: 5px 6px;
    color: #0f172a;
}
QTableWidget::item:selected, QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #e0f2fe;
    color: #0369a1;
}
QHeaderView::section {
    background-color: #f8fafc;
    color: #475569;
    font-weight: 600;
    border: none;
    border-bottom: 1px solid #e2e8f0;
    border-right: 1px solid #f1f5f9;
    padding: 6px 8px;
}

/* ScrollBars */
QScrollBar:vertical, QScrollBar:horizontal {
    border: none;
    background: #f1f5f9;
    width: 8px;
    height: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical, QScrollBar::handle:horizontal {
    background: #cbd5e1;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar::handle:hover {
    background: #94a3b8;
}

/* Badges & Pills */
QLabel.BadgeWFS {
    background-color: #dbeafe;
    color: #1d4ed8;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeWMS {
    background-color: #fef3c7;
    color: #b45309;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeWCS {
    background-color: #cffafe;
    color: #0e7490;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeWMTS {
    background-color: #e0e7ff;
    color: #4338ca;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeXYZ {
    background-color: #ede9fe;
    color: #6d28d9;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeGeom {
    background-color: #dcfce7;
    color: #15803d;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeMixed {
    background-color: #fae8ff;
    color: #86198f;
    border: 1px solid #d946ef;
    border-radius: 3px;
    padding: 2px 5px;
    font-weight: 700;
    font-size: 8pt;
}
QLabel.BadgeInProfile {
    background-color: #d1fae5;
    color: #047857;
    border: 1px solid #10b981;
    border-radius: 3px;
    padding: 1px 6px;
    font-weight: 600;
    font-size: 8pt;
}
QLabel.BadgeCRS {
    background-color: #f1f5f9;
    color: #334155;
    border: 1px solid #cbd5e1;
    border-radius: 3px;
    padding: 2px 5px;
    font-size: 8pt;
}
"""
