# -*- coding: utf-8 -*-
"""
GeoKataloog (Eesti & OGC)
Eesti ja rahvusvaheliste ruumiandmeteenuste kataloog, kihtide ja geomeetriate eelvaade ning profiilihaldur.
Supports QGIS 3.28+ and QGIS 4.x.
"""


def classFactory(iface):
    """QGIS plugin factory entrypoint."""
    from .plugin import GeoProfileHubPlugin
    return GeoProfileHubPlugin(iface)
