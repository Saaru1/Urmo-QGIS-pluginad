# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Qt5 (PyQt5) and Qt6 (PyQt6) Compatibility Layer
Provides seamless cross-version compatibility between QGIS 3.44+ and QGIS 4.2+
"""

import sys
from qgis.PyQt import QtCore, QtGui, QtWidgets

try:
    from qgis.PyQt import QtNetwork
except ImportError:
    QtNetwork = None

try:
    from qgis.PyQt import QtXml
except ImportError:
    QtXml = None

# Detect Qt major version
QT_VERSION = QtCore.qVersion()
QT_MAJOR = int(QT_VERSION.split('.')[0]) if QT_VERSION else 5
IS_QT6 = QT_MAJOR >= 6


def get_enum(scope, name, fallback_scope=None):
    """Safely retrieves an enum value from scope or fallback."""
    if hasattr(scope, name):
        return getattr(scope, name)
    if fallback_scope and hasattr(fallback_scope, name):
        return getattr(fallback_scope, name)
    return getattr(QtCore.Qt, name, None)


# Alignment Flags
Alignment = getattr(QtCore.Qt, 'AlignmentFlag', QtCore.Qt)
AlignLeft = get_enum(Alignment, 'AlignLeft', QtCore.Qt)
AlignRight = get_enum(Alignment, 'AlignRight', QtCore.Qt)
AlignCenter = get_enum(Alignment, 'AlignCenter', QtCore.Qt)
AlignVCenter = get_enum(Alignment, 'AlignVCenter', QtCore.Qt)
AlignTop = get_enum(Alignment, 'AlignTop', QtCore.Qt)
AlignBottom = get_enum(Alignment, 'AlignBottom', QtCore.Qt)

# Orientation
Orientation = getattr(QtCore.Qt, 'Orientation', QtCore.Qt)
Horizontal = get_enum(Orientation, 'Horizontal', QtCore.Qt)
Vertical = get_enum(Orientation, 'Vertical', QtCore.Qt)

# Item Flags
ItemFlag = getattr(QtCore.Qt, 'ItemFlag', QtCore.Qt)
ItemIsEnabled = get_enum(ItemFlag, 'ItemIsEnabled', QtCore.Qt)
ItemIsSelectable = get_enum(ItemFlag, 'ItemIsSelectable', QtCore.Qt)
ItemIsUserCheckable = get_enum(ItemFlag, 'ItemIsUserCheckable', QtCore.Qt)
ItemIsEditable = get_enum(ItemFlag, 'ItemIsEditable', QtCore.Qt)
ItemIsDragEnabled = get_enum(ItemFlag, 'ItemIsDragEnabled', QtCore.Qt)
ItemIsDropEnabled = get_enum(ItemFlag, 'ItemIsDropEnabled', QtCore.Qt)

# CheckState
CheckState = getattr(QtCore.Qt, 'CheckState', QtCore.Qt)
Checked = get_enum(CheckState, 'Checked', QtCore.Qt)
Unchecked = get_enum(CheckState, 'Unchecked', QtCore.Qt)
PartiallyChecked = get_enum(CheckState, 'PartiallyChecked', QtCore.Qt)

# Dialog Codes
DialogCode = getattr(QtWidgets.QDialog, 'DialogCode', QtWidgets.QDialog)
DialogAccepted = get_enum(DialogCode, 'Accepted', QtWidgets.QDialog)
DialogRejected = get_enum(DialogCode, 'Rejected', QtWidgets.QDialog)

# QHeaderView ResizeMode
ResizeMode = getattr(QtWidgets.QHeaderView, 'ResizeMode', QtWidgets.QHeaderView)
ResizeStretch = get_enum(ResizeMode, 'Stretch', QtWidgets.QHeaderView)
ResizeToContents = get_enum(ResizeMode, 'ResizeToContents', QtWidgets.QHeaderView)
ResizeInteractive = get_enum(ResizeMode, 'Interactive', QtWidgets.QHeaderView)
ResizeFixed = get_enum(ResizeMode, 'Fixed', QtWidgets.QHeaderView)

# Text Interaction Flags
TextInteractionFlags = getattr(QtCore.Qt, 'TextInteractionFlag', QtCore.Qt)
TextSelectableByMouse = get_enum(TextInteractionFlags, 'TextSelectableByMouse', QtCore.Qt)

# Dock Widget Area & Features
DockWidgetArea = getattr(QtCore.Qt, 'DockWidgetArea', QtCore.Qt)
RightDockWidgetArea = get_enum(DockWidgetArea, 'RightDockWidgetArea', QtCore.Qt)
LeftDockWidgetArea = get_enum(DockWidgetArea, 'LeftDockWidgetArea', QtCore.Qt)
BottomDockWidgetArea = get_enum(DockWidgetArea, 'BottomDockWidgetArea', QtCore.Qt)
AllDockWidgetAreas = get_enum(DockWidgetArea, 'AllDockWidgetAreas', QtCore.Qt)

DockWidgetFeature = getattr(QtWidgets.QDockWidget, 'DockWidgetFeature', QtWidgets.QDockWidget)
DockWidgetMovable = get_enum(DockWidgetFeature, 'DockWidgetMovable', QtWidgets.QDockWidget)
DockWidgetFloatable = get_enum(DockWidgetFeature, 'DockWidgetFloatable', QtWidgets.QDockWidget)
DockWidgetClosable = get_enum(DockWidgetFeature, 'DockWidgetClosable', QtWidgets.QDockWidget)

# DragDropMode
DragDropMode = getattr(QtWidgets.QAbstractItemView, 'DragDropMode', QtWidgets.QAbstractItemView)
DragOnly = get_enum(DragDropMode, 'DragOnly', QtWidgets.QAbstractItemView)
DropOnly = get_enum(DragDropMode, 'DropOnly', QtWidgets.QAbstractItemView)
DragDrop = get_enum(DragDropMode, 'DragDrop', QtWidgets.QAbstractItemView)
InternalMove = get_enum(DragDropMode, 'InternalMove', QtWidgets.QAbstractItemView)

# DropAction
DropAction = getattr(QtCore.Qt, 'DropAction', QtCore.Qt)
CopyAction = get_enum(DropAction, 'CopyAction', QtCore.Qt)
MoveAction = get_enum(DropAction, 'MoveAction', QtCore.Qt)


def exec_dialog(dialog):
    """Execute a dialog safely in both Qt5 (exec_ / exec) and Qt6 (exec)."""
    if hasattr(dialog, 'exec'):
        return dialog.exec()
    elif hasattr(dialog, 'exec_'):
        return dialog.exec_()
    return 0


def set_header_resize_mode(header, column, mode):
    """Safely set header section resize mode across Qt5 and Qt6."""
    header.setSectionResizeMode(column, mode)


def qgis_version_info():
    """Returns (major, minor, patch) of current QGIS."""
    try:
        from qgis.core import Qgis
        ver_str = Qgis.version().split('-')[0]
        parts = [int(p) for p in ver_str.split('.') if p.isdigit()]
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])
    except Exception:
        return (3, 44, 0)
