# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Standalone Dialog Window
Alternative modal container with synchronized tab translations and rich metadata.
"""

import os
from qgis.PyQt import QtWidgets, QtCore, QtGui
from ..compat import (
    AlignLeft, AlignVCenter, AlignRight, AlignCenter, Horizontal,
    qgis_version_info, IS_QT6, QT_VERSION
)
from ..i18n import tr, set_language, get_language
from ..styles import get_stylesheet, set_theme, get_current_theme
from ..profile_manager import ProfileManager
from ..qgis_connector import QgisConnector
from .widgets.layers_widget import LayersWidget
from .widgets.profile_widget import ProfileWidget
from .widgets.catalog_widget import CatalogWidget


class MainDialog(QtWidgets.QDialog):
    """Standalone dialog window for GeoProfile Hub."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.profile_manager = ProfileManager()
        self.qgis_connector = QgisConnector(iface)

        self.setWindowTitle(tr("plugin_name"))
        self.resize(1040, 680)
        self.setMinimumSize(520, 380)

        self.setWindowFlags(
            self.windowFlags()
            | QtCore.Qt.WindowType.WindowMaximizeButtonHint
            | QtCore.Qt.WindowType.WindowMinimizeButtonHint
            if hasattr(QtCore.Qt, "WindowType")
            else self.windowFlags()
            | QtCore.Qt.WindowMaximizeButtonHint
            | QtCore.Qt.WindowMinimizeButtonHint
        )

        self._init_ui()
        self._apply_current_style()

    def _init_ui(self):
        root_layout = QtWidgets.QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        header = QtWidgets.QFrame()
        header.setObjectName("HeaderBanner")
        h_layout = QtWidgets.QHBoxLayout(header)
        h_layout.setContentsMargins(14, 8, 14, 8)
        h_layout.setSpacing(10)

        # Plugin Icon
        self.lbl_icon = QtWidgets.QLabel()
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "resources", "icon.svg")
        if not os.path.exists(icon_path):
            icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        if os.path.exists(icon_path):
            pix = QtGui.QIcon(icon_path).pixmap(26, 26)
            self.lbl_icon.setPixmap(pix)
            self.lbl_icon.setFixedSize(26, 26)
            h_layout.addWidget(self.lbl_icon)

        v_title = QtWidgets.QVBoxLayout()
        v_title.setSpacing(1)
        self.app_title = QtWidgets.QLabel(tr("plugin_name"))
        self.app_title.setObjectName("AppTitle")
        self.app_sub = QtWidgets.QLabel(tr("app_subtitle"))
        self.app_sub.setObjectName("AppSubtitle")
        v_title.addWidget(self.app_title)
        v_title.addWidget(self.app_sub)
        h_layout.addLayout(v_title, stretch=1)

        self.active_pill = QtWidgets.QLabel()
        self.active_pill.setProperty("class", "BadgeCRS")
        self._update_active_pill()
        h_layout.addWidget(self.active_pill)

        self.btn_lang = QtWidgets.QPushButton(tr("lang_btn_text"))
        self.btn_lang.clicked.connect(self._toggle_language)
        h_layout.addWidget(self.btn_lang)

        self.btn_theme = QtWidgets.QPushButton(
            tr("theme_btn_dark") if get_current_theme() == "DARK" else tr("theme_btn_light")
        )
        self.btn_theme.clicked.connect(self._toggle_theme)
        h_layout.addWidget(self.btn_theme)

        root_layout.addWidget(header)

        # Tabs
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setDocumentMode(True)

        # Splitter (Layers + Profile Builder)
        splitter = QtWidgets.QSplitter(Horizontal)
        self.layers_widget = LayersWidget(self.profile_manager, self.qgis_connector, self)
        self.profile_widget = ProfileWidget(self.profile_manager, self.qgis_connector, self)
        splitter.addWidget(self.layers_widget)
        splitter.addWidget(self.profile_widget)
        splitter.setSizes([620, 460])
        self.tabs.addTab(splitter, tr("tab_layers"))

        # Catalog
        self.catalog_widget = CatalogWidget(self.profile_manager, self)
        self.tabs.addTab(self.catalog_widget, tr("tab_catalog"))

        root_layout.addWidget(self.tabs, stretch=1)

        # Footer
        footer = QtWidgets.QFrame()
        footer.setStyleSheet("background-color: transparent; padding: 6px 12px; border-top: 1px solid #334155;")
        f_layout = QtWidgets.QHBoxLayout(footer)
        f_layout.setContentsMargins(0, 0, 0, 0)

        q_ver = ".".join(str(x) for x in qgis_version_info())
        self.lbl_info = QtWidgets.QLabel(f"QGIS v{q_ver} | Qt {QT_VERSION} | L-EST97 (EPSG:3301)")
        self.lbl_info.setStyleSheet("color: #64748b; font-size: 8.5pt;")
        f_layout.addWidget(self.lbl_info)

        f_layout.addStretch()

        self.btn_close = QtWidgets.QPushButton(tr("btn_close"))
        self.btn_close.clicked.connect(self.close)
        f_layout.addWidget(self.btn_close)

        root_layout.addWidget(footer)

        self.catalog_widget.testServiceRequested.connect(self._on_catalog_inspect)
        self.catalog_widget.addToProfileRequested.connect(self._on_service_added)
        self.layers_widget.addToProfileRequested.connect(self._on_service_added)
        self.profile_widget.profileApplied.connect(self._on_profile_applied)

    def _update_active_pill(self):
        active = self.profile_manager.get_active_profile()
        name = active.get("name") if active else "Current profile"
        self.active_pill.setText(f"{tr('active_profile')} {name}")

    def _on_catalog_inspect(self, service_dict):
        self.tabs.setCurrentIndex(0)
        self.layers_widget.set_service(service_dict)

    def _on_service_added(self, service_dict):
        self.profile_widget.refresh_profiles()
        self._update_active_pill()

    def _on_profile_applied(self, profile_name, count):
        self._update_active_pill()

    def _toggle_language(self):
        new_lang = "ENG" if get_language() == "EST" else "EST"
        set_language(new_lang)
        self.btn_lang.setText(tr("lang_btn_text"))
        self.setWindowTitle(tr("plugin_name"))
        self.app_title.setText(tr("plugin_name"))
        self.app_sub.setText(tr("app_subtitle"))
        self.tabs.setTabText(0, tr("tab_layers"))
        self.tabs.setTabText(1, tr("tab_catalog"))
        self.btn_close.setText(tr("btn_close"))
        self._update_active_pill()

        self.layers_widget.retranslate_ui()
        self.profile_widget.retranslate_ui()
        self.catalog_widget.retranslate_ui()

    def _toggle_theme(self):
        new_theme = "LIGHT" if get_current_theme() == "DARK" else "DARK"
        set_theme(new_theme)
        self.btn_theme.setText(
            tr("theme_btn_dark") if new_theme == "DARK" else tr("theme_btn_light")
        )
        self._apply_current_style()

    def _apply_current_style(self):
        css = get_stylesheet(get_current_theme())
        self.setStyleSheet(css)
