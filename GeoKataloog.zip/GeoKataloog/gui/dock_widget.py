# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Dockable QGIS Panel (QgsDockWidget)
Provides native QGIS docking alongside the map canvas,
with an integrated side-by-side view (Layers Panel + Profile Builder)
and 100% dynamic EST/ENG translation across all panels.
"""

import os
from qgis.gui import QgsDockWidget
from qgis.PyQt import QtWidgets, QtCore, QtGui
from ..compat import (
    AlignLeft, AlignVCenter, AlignRight, AlignCenter, Horizontal, Vertical,
    DockWidgetMovable, DockWidgetFloatable, DockWidgetClosable, AllDockWidgetAreas, RightDockWidgetArea,
    qgis_version_info, IS_QT6, QT_VERSION
)
from ..i18n import tr, set_language, get_language
from ..styles import get_stylesheet, set_theme, get_current_theme
from ..profile_manager import ProfileManager
from ..qgis_connector import QgisConnector
from .widgets.layers_widget import LayersWidget
from .widgets.profile_widget import ProfileWidget
from .widgets.catalog_widget import CatalogWidget


class GeoProfileDockWidget(QgsDockWidget):
    """Main dockable panel for GeoProfile Hub."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.profile_manager = ProfileManager()
        self.qgis_connector = QgisConnector(iface)

        self.setObjectName("GeoProfileHubDockWidget")
        self.setWindowTitle(tr("dock_title"))

        # Enable flexible docking, floating and resizing on any screen
        features = DockWidgetMovable
        if DockWidgetFloatable:
            features = features | DockWidgetFloatable
        if DockWidgetClosable:
            features = features | DockWidgetClosable
        self.setFeatures(features)
        if AllDockWidgetAreas:
            self.setAllowedAreas(AllDockWidgetAreas)
        self.setMinimumWidth(280)

        self._collapsed = False
        self.topLevelChanged.connect(self._on_top_level_changed)

        self._init_ui()
        self._apply_current_style()

    def _init_ui(self):
        self.main_content = QtWidgets.QWidget()
        self.main_content.setObjectName("MainDockContent")
        root_layout = QtWidgets.QVBoxLayout(self.main_content)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # -------------------------------------------------------------
        # 1. Header Banner (Compact, single-line to maximize vertical workspace)
        # -------------------------------------------------------------
        self.header = QtWidgets.QFrame()
        self.header.setObjectName("HeaderBanner")
        self.header.setMaximumHeight(38)
        self.header.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding if hasattr(QtWidgets.QSizePolicy, 'Policy') else QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed if hasattr(QtWidgets.QSizePolicy, 'Policy') else QtWidgets.QSizePolicy.Fixed
        )
        h_layout = QtWidgets.QHBoxLayout(self.header)
        h_layout.setContentsMargins(8, 2, 8, 2)
        h_layout.setSpacing(6)
        h_layout.setAlignment(AlignVCenter)

        # Plugin Icon next to title
        self.lbl_icon = QtWidgets.QLabel()
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "resources", "icon.svg")
        if not os.path.exists(icon_path):
            icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        if os.path.exists(icon_path):
            pix = QtGui.QIcon(icon_path).pixmap(20, 20)
            self.lbl_icon.setPixmap(pix)
            self.lbl_icon.setFixedSize(20, 20)
            h_layout.addWidget(self.lbl_icon)

        self.app_title = QtWidgets.QLabel(tr('plugin_name'))
        self.app_title.setObjectName("AppTitle")
        self.app_title.setStyleSheet("font-size: 10pt; font-weight: 700;")
        h_layout.addWidget(self.app_title)

        h_layout.addStretch(1)

        # Active Profile Indicator Pill
        self.active_pill = QtWidgets.QLabel()
        self.active_pill.setProperty("class", "BadgeCRS")
        self.active_pill.setStyleSheet("font-size: 8pt; padding: 2px 6px; font-weight: 600;")
        self._update_active_pill()
        h_layout.addWidget(self.active_pill)

        # Language Toggle (EST / ENG)
        self.btn_lang = QtWidgets.QPushButton(tr("lang_btn_text"))
        self.btn_lang.setToolTip("Switch Language / Vaheta keelt (EST / ENG)")
        self.btn_lang.clicked.connect(self._toggle_language)
        h_layout.addWidget(self.btn_lang)

        # Theme Toggle (☀ / 🌙)
        self.btn_theme = QtWidgets.QPushButton(
            tr("theme_btn_dark") if get_current_theme() == "LIGHT" else tr("theme_btn_light")
        )
        self.btn_theme.setToolTip("Switch Theme / Vaheta teemat (Light / Dark)")
        self.btn_theme.clicked.connect(self._toggle_theme)
        h_layout.addWidget(self.btn_theme)

        # Separator
        sep = QtWidgets.QFrame()
        sep.setFrameShape(QtWidgets.QFrame.Shape.VLine if hasattr(QtWidgets.QFrame, 'Shape') else QtWidgets.QFrame.VLine)
        sep.setStyleSheet("color: rgba(148, 163, 184, 0.4); margin: 0 2px;")
        h_layout.addWidget(sep)

        # Window controls: Minimize, Dock/Undock (Native title bar has the single X close button)
        self.btn_minimize = QtWidgets.QPushButton("🗕")
        self.btn_minimize.setObjectName("BtnHeaderMinimize")
        self.btn_minimize.setFixedSize(28, 24)
        self.btn_minimize.setToolTip(tr("btn_minimize_tooltip"))
        self.btn_minimize.clicked.connect(self.minimize_window)
        h_layout.addWidget(self.btn_minimize)

        self.btn_dock = QtWidgets.QPushButton("📌 " + tr("btn_dock_qgis"))
        self.btn_dock.setObjectName("BtnHeaderDock")
        self.btn_dock.setFixedHeight(24)
        self.btn_dock.clicked.connect(self.toggle_dock)
        h_layout.addWidget(self.btn_dock)

        root_layout.addWidget(self.header)

        # -------------------------------------------------------------
        # 2. Main Tabs
        # -------------------------------------------------------------
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setDocumentMode(True)

        # Tab 0: Integrated Splitter View (Layers Panel on Left + Profile Builder on Right)
        self.split_widget = self._create_split_view()
        self.tabs.addTab(self.split_widget, tr("tab_layers"))

        # Tab 1: Catalog View
        self.catalog_widget = CatalogWidget(self.profile_manager, self)
        self.tabs.addTab(self.catalog_widget, tr("tab_catalog"))

        # Tab 2: Settings View
        self.settings_widget = self._create_settings_widget()
        self.tabs.addTab(self.settings_widget, tr("tab_settings"))

        root_layout.addWidget(self.tabs, stretch=1)

        # -------------------------------------------------------------
        # 3. Status Bar Footer
        # -------------------------------------------------------------
        self.footer = QtWidgets.QFrame()
        self.footer.setStyleSheet("background-color: transparent; padding: 4px 10px; border-top: 1px solid #334155;")
        f_layout = QtWidgets.QHBoxLayout(self.footer)
        f_layout.setContentsMargins(0, 0, 0, 0)

        q_ver = ".".join(str(x) for x in qgis_version_info())
        self.lbl_info = QtWidgets.QLabel(f"QGIS v{q_ver} | Qt {QT_VERSION} | L-EST97 (EPSG:3301)")
        self.lbl_info.setStyleSheet("color: #64748b; font-size: 8pt;")
        f_layout.addWidget(self.lbl_info)

        f_layout.addStretch()

        root_layout.addWidget(self.footer)
        self.setWidget(self.main_content)

        # Signal connections
        self.catalog_widget.testServiceRequested.connect(self._on_catalog_inspect_service)
        self.catalog_widget.addToProfileRequested.connect(self._on_service_added)
        self.layers_widget.addToProfileRequested.connect(self._on_service_added)
        self.profile_widget.profileApplied.connect(self._on_profile_applied)
        self.profile_widget.inspectServiceRequested.connect(self._on_catalog_inspect_service)
        self._update_dock_buttons()

    def _create_split_view(self):
        """Creates integrated splitter view with view-switching controls and collapsible panels."""
        container = QtWidgets.QWidget()
        c_layout = QtWidgets.QVBoxLayout(container)
        c_layout.setContentsMargins(0, 0, 0, 0)
        c_layout.setSpacing(2)

        # Quick View Switching Bar (Both / Layers only / Profile only / Toggle Layout)
        view_bar = QtWidgets.QFrame()
        view_bar.setObjectName("ViewSwitcherBar")
        view_bar.setStyleSheet("background-color: transparent; border-bottom: 1px solid rgba(148, 163, 184, 0.2); padding: 3px 6px;")
        vb_layout = QtWidgets.QHBoxLayout(view_bar)
        vb_layout.setContentsMargins(0, 0, 0, 0)
        vb_layout.setSpacing(4)

        self.btn_view_both = QtWidgets.QPushButton(f"⮀ {tr('view_mode_both')}")
        self.btn_view_both.setCheckable(True)
        self.btn_view_both.setChecked(True)
        self.btn_view_both.setToolTip("Näita mõlemat paneeli kõrvuti (Kihid + Profiil)")
        self.btn_view_both.setStyleSheet("font-size: 8pt; padding: 2px 7px;")
        self.btn_view_both.clicked.connect(self._set_view_both)
        vb_layout.addWidget(self.btn_view_both)

        self.btn_view_layers = QtWidgets.QPushButton(f"◀ {tr('view_mode_layers')}")
        self.btn_view_layers.setCheckable(True)
        self.btn_view_layers.setToolTip("Näita ainult kihtide paneeli täislaiuses")
        self.btn_view_layers.setStyleSheet("font-size: 8pt; padding: 2px 7px;")
        self.btn_view_layers.clicked.connect(self._set_view_layers_only)
        vb_layout.addWidget(self.btn_view_layers)

        self.btn_view_profile = QtWidgets.QPushButton(f"▶ {tr('view_mode_profile')}")
        self.btn_view_profile.setCheckable(True)
        self.btn_view_profile.setToolTip("Näita ainult profiili paneeli täislaiuses")
        self.btn_view_profile.setStyleSheet("font-size: 8pt; padding: 2px 7px;")
        self.btn_view_profile.clicked.connect(self._set_view_profile_only)
        vb_layout.addWidget(self.btn_view_profile)

        vb_layout.addStretch()

        self.btn_toggle_orient = QtWidgets.QPushButton(f"⇕ {tr('view_orientation_toggle')}")
        self.btn_toggle_orient.setToolTip("Vaheta paigutust: kõrvuti (horisontaalne) või ülestikku (vertikaalne)")
        self.btn_toggle_orient.setStyleSheet("font-size: 8pt; padding: 2px 7px;")
        self.btn_toggle_orient.clicked.connect(self._toggle_splitter_orientation)
        vb_layout.addWidget(self.btn_toggle_orient)

        c_layout.addWidget(view_bar)

        self.splitter = QtWidgets.QSplitter(Horizontal)
        self.splitter.setHandleWidth(5)
        self.splitter.setChildrenCollapsible(True)

        self.layers_widget = LayersWidget(self.profile_manager, self.qgis_connector, self)
        self.splitter.addWidget(self.layers_widget)

        self.profile_widget = ProfileWidget(self.profile_manager, self.qgis_connector, self)
        self.splitter.addWidget(self.profile_widget)

        self.splitter.setSizes([450, 350])
        c_layout.addWidget(self.splitter, stretch=1)
        return container

    def _set_view_both(self):
        self.btn_view_both.setChecked(True)
        self.btn_view_layers.setChecked(False)
        self.btn_view_profile.setChecked(False)
        self.layers_widget.setVisible(True)
        self.profile_widget.setVisible(True)
        self.splitter.setSizes([450, 350])

    def _set_view_layers_only(self):
        self.btn_view_both.setChecked(False)
        self.btn_view_layers.setChecked(True)
        self.btn_view_profile.setChecked(False)
        self.layers_widget.setVisible(True)
        self.profile_widget.setVisible(False)

    def _set_view_profile_only(self):
        self.btn_view_both.setChecked(False)
        self.btn_view_layers.setChecked(False)
        self.btn_view_profile.setChecked(True)
        self.layers_widget.setVisible(False)
        self.profile_widget.setVisible(True)

    def _toggle_splitter_orientation(self):
        if self.splitter.orientation() == Horizontal:
            self.splitter.setOrientation(Vertical)
            self.splitter.setSizes([320, 280])
        else:
            self.splitter.setOrientation(Horizontal)
            self.splitter.setSizes([450, 350])

    def _create_settings_widget(self):
        """Constructs Settings tab page."""
        w = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(w)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(14)

        card = QtWidgets.QFrame()
        card.setProperty("class", "CardFrame")
        form = QtWidgets.QFormLayout(card)
        form.setSpacing(12)

        self.set_lang_combo = QtWidgets.QComboBox()
        self.set_lang_combo.addItem("Eesti keel (EST)", "EST")
        self.set_lang_combo.addItem("English (ENG)", "ENG")
        self.set_lang_combo.setCurrentIndex(0 if get_language() == "EST" else 1)
        self.set_lang_combo.currentIndexChanged.connect(
            lambda: self._set_language_direct(self.set_lang_combo.currentData())
        )
        self.lbl_lang_setting = QtWidgets.QLabel(tr("language_choice"))
        form.addRow(self.lbl_lang_setting, self.set_lang_combo)

        self.set_theme_combo = QtWidgets.QComboBox()
        self.set_theme_combo.addItem(tr("theme_light"), "LIGHT")
        self.set_theme_combo.addItem(tr("theme_dark"), "DARK")
        idx_theme = self.set_theme_combo.findData(get_current_theme())
        if idx_theme >= 0:
            self.set_theme_combo.setCurrentIndex(idx_theme)
        self.set_theme_combo.currentIndexChanged.connect(
            lambda: self._set_theme_direct(self.set_theme_combo.currentData())
        )
        self.lbl_theme_setting = QtWidgets.QLabel(tr("theme_choice"))
        form.addRow(self.lbl_theme_setting, self.set_theme_combo)

        self.crs_input = QtWidgets.QLineEdit("EPSG:3301")
        self.crs_input.setReadOnly(True)
        self.lbl_crs_setting = QtWidgets.QLabel(tr("default_crs_label"))
        form.addRow(self.lbl_crs_setting, self.crs_input)

        self.timeout_spin = QtWidgets.QSpinBox()
        self.timeout_spin.setRange(2, 60)
        self.timeout_spin.setValue(10)
        self.timeout_spin.setSuffix(" sek")
        self.lbl_timeout_setting = QtWidgets.QLabel(tr("timeout_setting"))
        form.addRow(self.lbl_timeout_setting, self.timeout_spin)

        layout.addWidget(card)

        info_card = QtWidgets.QFrame()
        info_card.setProperty("class", "CardFrame")
        i_layout = QtWidgets.QVBoxLayout(info_card)
        i_title = QtWidgets.QLabel("<b>Eesti Avaandmete ja Geoportaali Tugi</b>")
        i_text = QtWidgets.QLabel(
            "Toetab ametlikke ruumiandmeteenuseid: Maa- ja Ruumiamet (põhikaardid, ortofotod, kataster, kõrgusmudelid), "
            "Keskkonnaportaal / EELIS (kaitsealad, Natura 2000), ETAK topograafia, PRIA põllumassiivid ja Muinsuskaitseamet.<br>"
            "Toetatud on ka kohandatud sisevõrgu teenused (Basic Auth, API Token, QGIS AuthCfg) ja automaatne segageomeetriate eraldamine."
        )
        i_text.setWordWrap(True)
        i_layout.addWidget(i_title)
        i_layout.addWidget(i_text)
        layout.addWidget(info_card)

        layout.addStretch()
        return w

    def _update_active_pill(self):
        from ..profile_manager import get_profile_name
        active = self.profile_manager.get_active_profile()
        p_name = get_profile_name(active, get_language())
        self.active_pill.setText(f"{tr('active_profile')} {p_name}")

    def _on_catalog_inspect_service(self, service_dict):
        self.tabs.setCurrentIndex(0)
        self.layers_widget.set_service(service_dict)

    def _on_service_added(self, service_dict):
        self.profile_widget.refresh_profiles()
        self._update_active_pill()

    def _on_profile_applied(self, profile_name, count):
        self._update_active_pill()

    def _toggle_language(self):
        new_lang = "ENG" if get_language() == "EST" else "EST"
        self._set_language_direct(new_lang)

    def _set_language_direct(self, lang_code):
        set_language(lang_code)
        self.retranslate_all()

    def retranslate_all(self):
        """Refreshes all texts across dock widget and sub-panels dynamically."""
        self.setWindowTitle(tr("dock_title"))
        self.app_title.setText(tr("plugin_name"))
        if hasattr(self, "app_sub") and self.app_sub:
            self.app_sub.setText(tr("app_subtitle"))
        self.btn_lang.setText(tr("lang_btn_text"))
        self.btn_theme.setText(
            tr("theme_btn_dark") if get_current_theme() == "LIGHT" else tr("theme_btn_light")
        )

        # Tab titles (Clean: 'Kihid' / 'Layers')
        self.tabs.setTabText(0, tr("tab_layers"))
        self.tabs.setTabText(1, tr("tab_catalog"))
        self.tabs.setTabText(2, tr("tab_settings"))

        self._update_active_pill()

        # Retranslate all sub-panels
        if hasattr(self, "layers_widget"):
            self.layers_widget.retranslate_ui()
        if hasattr(self, "profile_widget"):
            self.profile_widget.retranslate_ui()
        if hasattr(self, "catalog_widget"):
            self.catalog_widget.retranslate_ui()

        self._update_dock_buttons()

        # Settings labels
        if hasattr(self, "lbl_lang_setting"):
            self.lbl_lang_setting.setText(tr("language_choice"))
            self.lbl_theme_setting.setText(tr("theme_choice"))
            self.lbl_crs_setting.setText(tr("default_crs_label"))
            self.lbl_timeout_setting.setText(tr("timeout_setting"))

    def _toggle_theme(self):
        new_theme = "LIGHT" if get_current_theme() == "DARK" else "DARK"
        self._set_theme_direct(new_theme)

    def _set_theme_direct(self, theme_name):
        set_theme(theme_name)
        self.btn_theme.setText(
            tr("theme_btn_dark") if theme_name == "LIGHT" else tr("theme_btn_light")
        )
        self._apply_current_style()

    def _apply_current_style(self):
        css = get_stylesheet(get_current_theme())
        self.setStyleSheet(css)
        self.main_content.setStyleSheet(css)

    def dock_to_qgis(self):
        """
        Hard-resets and docks the panel into the right-side dock area of QGIS,
        no matter where the floating window was located.
        """
        if self.isMinimized():
            self.showNormal()

        self.setMinimumWidth(280)
        self.setMaximumWidth(16777215)
        self.setMinimumHeight(200)
        self.setMaximumHeight(16777215)

        self.setFloating(False)

        mw = self.iface.mainWindow() if (self.iface and hasattr(self.iface, "mainWindow")) else None
        if self.iface and hasattr(self.iface, "addDockWidget"):
            self.iface.addDockWidget(RightDockWidgetArea, self)
        elif mw:
            mw.addDockWidget(RightDockWidgetArea, self)
        elif self.parent() and hasattr(self.parent(), "addDockWidget"):
            self.parent().addDockWidget(RightDockWidgetArea, self)

        if mw:
            try:
                mw.resizeDocks([self], [480], Horizontal)
            except Exception:
                pass

        self.setVisible(True)
        self.show()
        self.raise_()
        self.activateWindow()
        self._update_dock_buttons()

    def float_window(self):
        """Floats panel as an independent resizable window natively."""
        if self.isMinimized():
            self.showNormal()

        self.setFloating(True)

        self.setMinimumWidth(320)
        self.setMaximumWidth(16777215)
        self.setMinimumHeight(240)
        self.setMaximumHeight(16777215)

        if self.width() < 700 or self.height() < 500:
            self.resize(1000, 680)

        self.setVisible(True)
        self.show()
        self.raise_()
        self.activateWindow()
        self._update_dock_buttons()

    def toggle_dock(self):
        """Toggles between docked and floating modes natively."""
        if self.isFloating():
            self.dock_to_qgis()
        else:
            self.float_window()

    def minimize_window(self):
        """
        Minimizes or collapses the panel.
        If floating: minimizes the independent window to the OS taskbar.
        If docked: hides the dock widget so QGIS map canvas takes full space.
        """
        if self.isFloating():
            self.showMinimized()
        else:
            self.hide()

    def toggle_minimize(self):
        """Alias for minimize_window."""
        self.minimize_window()

    def minimize_or_collapse(self):
        """Alias for minimize_window."""
        self.minimize_window()

    def _update_dock_buttons(self):
        """Refreshes dock and minimize button labels & tooltips based on current state."""
        if not hasattr(self, 'btn_dock') or not hasattr(self, 'btn_minimize'):
            return
        if self.isFloating():
            self.btn_dock.setText("📌 " + tr("btn_dock_qgis"))
            self.btn_dock.setToolTip(tr("btn_dock_qgis_tooltip"))
        else:
            self.btn_dock.setText("🗗 " + tr("btn_float_window"))
            self.btn_dock.setToolTip(tr("btn_float_window_tooltip"))

        self.btn_minimize.setText("🗕")
        self.btn_minimize.setToolTip(tr("btn_minimize_tooltip"))
        self.btn_minimize.setStyleSheet("")

    def _on_top_level_changed(self, is_floating):
        """Triggered natively when dock widget transitions between docked and floating."""
        self._update_dock_buttons()
