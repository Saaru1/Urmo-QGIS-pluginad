# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Service Inspector & Tester Widget
Executes deep inspection of geospatial endpoints, displays geometry types,
paging capabilities, latency, and provides one-click profile integration.
"""

from qgis.PyQt import QtWidgets, QtCore, QtGui
from ...compat import (
    AlignLeft, AlignVCenter, AlignCenter,
    ItemIsEnabled, ItemIsSelectable,
    ResizeStretch, ResizeToContents, ResizeInteractive,
    set_header_resize_mode
)
from ...i18n import tr
from ...service_tester import ServiceTester


class TesterWidget(QtWidgets.QWidget):
    """Deep inspection and diagnostic panel for WFS, WMS, WMTS and XYZ endpoints."""

    addToProfileWithSettings = QtCore.pyqtSignal(dict)
    addLayerToCanvasRequested = QtCore.pyqtSignal(dict, dict)  # (layer_dict, service_dict)

    def __init__(self, profile_manager, qgis_connector=None, parent=None):
        super().__init__(parent)
        self.profile_manager = profile_manager
        self.qgis_connector = qgis_connector
        self.tester = ServiceTester(timeout=10)
        self.last_result = None
        self.current_service_dict = None
        self._init_ui()

    def _init_ui(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # -------------------------------------------------------------
        # Input Section Card
        # -------------------------------------------------------------
        input_card = QtWidgets.QFrame()
        input_card.setProperty("class", "CardFrame")
        input_layout = QtWidgets.QVBoxLayout(input_card)
        input_layout.setContentsMargins(10, 10, 10, 10)
        input_layout.setSpacing(8)

        # Row 1: URL & Protocol & Test Button
        row1 = QtWidgets.QHBoxLayout()
        row1.setSpacing(8)

        self.url_edit = QtWidgets.QLineEdit()
        self.url_edit.setPlaceholderText(tr("url_placeholder"))
        self.url_edit.returnPressed.connect(self.run_test)
        row1.addWidget(self.url_edit, stretch=4)

        self.type_combo = QtWidgets.QComboBox()
        self.type_combo.addItems([tr("service_type_auto"), "WFS", "WMS", "WMTS", "XYZ"])
        row1.addWidget(self.type_combo)

        self.btn_run_test = QtWidgets.QPushButton(tr("btn_run_test"))
        self.btn_run_test.setProperty("class", "PrimaryButton")
        self.btn_run_test.clicked.connect(self.run_test)
        row1.addWidget(self.btn_run_test)

        input_layout.addLayout(row1)

        # Row 2: Collapsible Authentication Accordion
        self.auth_group = QtWidgets.QGroupBox(tr("auth_options_header"))
        self.auth_group.setCheckable(True)
        self.auth_group.setChecked(False)
        auth_box_layout = QtWidgets.QHBoxLayout(self.auth_group)
        auth_box_layout.setSpacing(12)

        self.auth_type_combo = QtWidgets.QComboBox()
        self.auth_type_combo.addItem(tr("auth_none"), "none")
        self.auth_type_combo.addItem(tr("auth_basic"), "basic")
        self.auth_type_combo.addItem(tr("auth_token"), "token")
        self.auth_type_combo.addItem(tr("auth_qgis_cfg"), "authcfg")
        self.auth_type_combo.currentIndexChanged.connect(self._on_auth_type_changed)
        auth_box_layout.addWidget(self.auth_type_combo)

        self.auth_stack = QtWidgets.QStackedWidget()

        # 0: None
        w_none = QtWidgets.QWidget()
        self.auth_stack.addWidget(w_none)

        # 1: Basic
        w_basic = QtWidgets.QWidget()
        l_basic = QtWidgets.QHBoxLayout(w_basic)
        l_basic.setContentsMargins(0, 0, 0, 0)
        self.user_input = QtWidgets.QLineEdit()
        self.user_input.setPlaceholderText(tr("username"))
        self.pass_input = QtWidgets.QLineEdit()
        self.pass_input.setPlaceholderText(tr("password"))
        self.pass_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password if hasattr(QtWidgets.QLineEdit, "EchoMode") else QtWidgets.QLineEdit.Password)
        l_basic.addWidget(self.user_input)
        l_basic.addWidget(self.pass_input)
        self.auth_stack.addWidget(w_basic)

        # 2: Token
        w_token = QtWidgets.QWidget()
        l_token = QtWidgets.QHBoxLayout(w_token)
        l_token.setContentsMargins(0, 0, 0, 0)
        self.token_hdr = QtWidgets.QLineEdit("Authorization")
        self.token_val = QtWidgets.QLineEdit()
        self.token_val.setPlaceholderText("Bearer token või API võti...")
        l_token.addWidget(self.token_hdr, stretch=1)
        l_token.addWidget(self.token_val, stretch=2)
        self.auth_stack.addWidget(w_token)

        # 3: AuthCfg
        w_cfg = QtWidgets.QWidget()
        l_cfg = QtWidgets.QHBoxLayout(w_cfg)
        l_cfg.setContentsMargins(0, 0, 0, 0)
        self.authcfg_input = QtWidgets.QLineEdit()
        self.authcfg_input.setPlaceholderText("QGIS authcfg ID (nt 7 märki)")
        l_cfg.addWidget(self.authcfg_input)
        self.auth_stack.addWidget(w_cfg)

        auth_box_layout.addWidget(self.auth_stack, stretch=1)
        input_layout.addWidget(self.auth_group)

        main_layout.addWidget(input_card)

        # -------------------------------------------------------------
        # Metrics & Diagnostic Summary Card
        # -------------------------------------------------------------
        self.metrics_card = QtWidgets.QFrame()
        self.metrics_card.setProperty("class", "CardFrame")
        metrics_layout = QtWidgets.QGridLayout(self.metrics_card)
        metrics_layout.setContentsMargins(12, 10, 12, 10)
        metrics_layout.setSpacing(10)

        # Row 0
        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_ping')}</b>"), 0, 0)
        self.lbl_status = QtWidgets.QLabel("Ootel / Ready")
        metrics_layout.addWidget(self.lbl_status, 0, 1)

        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_latency')}</b>"), 0, 2)
        self.lbl_latency = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_latency, 0, 3)

        # Row 1
        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_version')}</b>"), 1, 0)
        self.lbl_version = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_version, 1, 1)

        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_server')}</b>"), 1, 2)
        self.lbl_server = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_server, 1, 3)

        # Row 2
        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_paging')}</b>"), 2, 0)
        self.lbl_paging = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_paging, 2, 1)

        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_crs')}</b>"), 2, 2)
        self.lbl_crs = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_crs, 2, 3)

        # Row 3
        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('status_layers_count')}</b>"), 3, 0)
        self.lbl_layers_count = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_layers_count, 3, 1)

        metrics_layout.addWidget(QtWidgets.QLabel(f"<b>{tr('preferred_paging_size')}</b>"), 3, 2)
        self.lbl_pref_page = QtWidgets.QLabel("-")
        metrics_layout.addWidget(self.lbl_pref_page, 3, 3)

        main_layout.addWidget(self.metrics_card)

        # -------------------------------------------------------------
        # Discovered Layers Table
        # -------------------------------------------------------------
        self.layers_table = QtWidgets.QTableWidget()
        self.layers_table.setColumnCount(6)
        self.layers_table.setHorizontalHeaderLabels([
            tr("col_layer_name"),
            tr("col_layer_title"),
            tr("col_geom_type"),
            tr("col_geom_col"),
            tr("col_crs"),
            tr("col_actions")
        ])
        self.layers_table.verticalHeader().setVisible(False)
        self.layers_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows if hasattr(QtWidgets.QAbstractItemView, "SelectionBehavior") else QtWidgets.QAbstractItemView.SelectRows)
        self.layers_table.setShowGrid(True)
        self.layers_table.setAlternatingRowColors(True)

        l_hdr = self.layers_table.horizontalHeader()
        set_header_resize_mode(l_hdr, 0, ResizeInteractive)
        set_header_resize_mode(l_hdr, 1, ResizeStretch)
        set_header_resize_mode(l_hdr, 2, ResizeToContents)
        set_header_resize_mode(l_hdr, 3, ResizeToContents)
        set_header_resize_mode(l_hdr, 4, ResizeToContents)
        set_header_resize_mode(l_hdr, 5, ResizeToContents)

        self.layers_table.setColumnWidth(0, 180)
        main_layout.addWidget(self.layers_table)

        # -------------------------------------------------------------
        # Bottom Action Bar
        # -------------------------------------------------------------
        bottom_bar = QtWidgets.QHBoxLayout()
        bottom_bar.setSpacing(10)

        self.pref_summary_lbl = QtWidgets.QLabel("")
        self.pref_summary_lbl.setStyleSheet("color: #475569; font-size: 9pt;")
        bottom_bar.addWidget(self.pref_summary_lbl, stretch=1)

        self.btn_add_to_profile = QtWidgets.QPushButton("★ Lisa testitud seadetega aktiivsesse profiili")
        self.btn_add_to_profile.setProperty("class", "SuccessButton")
        self.btn_add_to_profile.setEnabled(False)
        self.btn_add_to_profile.clicked.connect(self._on_add_to_profile_clicked)
        bottom_bar.addWidget(self.btn_add_to_profile)

        main_layout.addLayout(bottom_bar)

    def _on_auth_type_changed(self, index):
        self.auth_stack.setCurrentIndex(index)

    def load_service(self, service_dict):
        """Populates UI with service details and triggers test."""
        self.current_service_dict = dict(service_dict)
        url = service_dict.get("url", "")
        stype = service_dict.get("service_type", "AUTO")

        self.url_edit.setText(url)
        idx = self.type_combo.findText(stype)
        if idx >= 0:
            self.type_combo.setCurrentIndex(idx)
        else:
            self.type_combo.setCurrentIndex(0)

        # Auth
        auth_type = service_dict.get("auth_type", "none")
        if auth_type != "none":
            self.auth_group.setChecked(True)
            auth_idx = self.auth_type_combo.findData(auth_type)
            if auth_idx >= 0:
                self.auth_type_combo.setCurrentIndex(auth_idx)
            ap = service_dict.get("auth_params", {})
            self.user_input.setText(ap.get("username", ""))
            self.pass_input.setText(ap.get("password", ""))
            self.token_hdr.setText(ap.get("header_name", "Authorization"))
            self.token_val.setText(ap.get("header_val", ""))
            self.authcfg_input.setText(ap.get("authcfg", ""))

        self.run_test()

    def run_test(self):
        """Runs the service inspection synchronously with responsive wait cursor."""
        url = self.url_edit.text().strip()
        if not url:
            QtWidgets.QMessageBox.warning(self, tr("warning"), "Sisesta esmalt teenuse URL.")
            return

        stype_text = self.type_combo.currentText()
        stype = "AUTO" if stype_text == tr("service_type_auto") else stype_text

        auth_type = "none"
        auth_params = {}

        if self.auth_group.isChecked():
            auth_type = self.auth_type_combo.currentData() or "none"
            if auth_type == "basic":
                auth_params = {
                    "username": self.user_input.text().strip(),
                    "password": self.pass_input.text()
                }
            elif auth_type == "token":
                auth_params = {
                    "header_name": self.token_hdr.text().strip(),
                    "header_val": self.token_val.text().strip()
                }
            elif auth_type == "authcfg":
                auth_params = {
                    "authcfg": self.authcfg_input.text().strip()
                }

        self.lbl_status.setText("● Testimine käib...")
        self.lbl_status.setStyleSheet("color: #0284c7; font-weight: 600;")
        QtWidgets.QApplication.setOverrideCursor(QtGui.QCursor(QtCore.Qt.CursorShape.WaitCursor if hasattr(QtCore.Qt, "CursorShape") else QtCore.Qt.WaitCursor))

        try:
            result = self.tester.inspect_service(
                url,
                service_type=stype,
                auth_type=auth_type,
                auth_params=auth_params
            )
            QtWidgets.QApplication.restoreOverrideCursor()
            self.last_result = result
            self._render_results(result)
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            self.lbl_status.setText(f"● Viga: {e}")
            self.lbl_status.setStyleSheet("color: #dc2626; font-weight: 600;")
            QtWidgets.QMessageBox.critical(self, tr("error"), f"Testimise viga: {e}")

    def _render_results(self, res):
        """Updates UI cards and layer table with inspection outcome."""
        online = res.get("online", False)

        if online:
            self.lbl_status.setText("● Online (Aktiivne)")
            self.lbl_status.setStyleSheet("color: #16a34a; font-weight: 700;")
            self.btn_add_to_profile.setEnabled(True)
        else:
            err = res.get("error", "Ühendus ebaõnnestus")
            self.lbl_status.setText(f"● Offline ({err[:40]})")
            self.lbl_status.setStyleSheet("color: #dc2626; font-weight: 700;")
            self.btn_add_to_profile.setEnabled(False)

        self.lbl_latency.setText(f"{res.get('latency_ms', 0)} ms")
        self.lbl_server.setText(res.get("server_software", "Unknown"))
        self.lbl_version.setText(f"{res.get('detected_type', '')} {res.get('version', '')}")

        # Paging
        if res.get("paging_supported"):
            self.lbl_paging.setText("Jah (Toetatud)")
            self.lbl_paging.setStyleSheet("color: #16a34a; font-weight: 600;")
            self.lbl_pref_page.setText(str(res.get("recommended_page_size", 1000)))
        else:
            self.lbl_paging.setText("Ei / Mittevajalik" if res.get("detected_type") != "WFS" else "Ei toetatud")
            self.lbl_paging.setStyleSheet("color: #64748b;")
            self.lbl_pref_page.setText("-")

        # EPSG:3301
        has_est = res.get("epsg_3301_supported", False)
        self.lbl_crs.setText("Jah (EPSG:3301)" if has_est else "Ei (Muu CRS)")
        self.lbl_crs.setStyleSheet("color: #16a34a; font-weight: 600;" if has_est else "color: #b45309;")

        # Layers count
        layers = res.get("layers", [])
        self.lbl_layers_count.setText(f"{len(layers)} kihti")

        # Preferred summary text
        pref = res.get("preferred_settings", {})
        pref_str = ", ".join(f"{k}: {v}" for k, v in pref.items())
        self.pref_summary_lbl.setText(f"Soovituslikud seaded: {pref_str}")

        # Populate Layers Table
        self.layers_table.setRowCount(len(layers))
        for row, l in enumerate(layers):
            # Col 0: Name
            self.layers_table.setItem(row, 0, QtWidgets.QTableWidgetItem(l.get("name", "")))

            # Col 1: Title
            self.layers_table.setItem(row, 1, QtWidgets.QTableWidgetItem(l.get("title", "")))

            # Col 2: Geometry Type badge
            geom_type = l.get("geom_type", "Unknown")
            g_widget = QtWidgets.QWidget()
            g_lay = QtWidgets.QHBoxLayout(g_widget)
            g_lay.setContentsMargins(4, 2, 4, 2)
            g_lbl = QtWidgets.QLabel(f" {geom_type} ")
            g_lbl.setProperty("class", "BadgeGeom")
            g_lbl.setAlignment(AlignCenter)
            g_lay.addWidget(g_lbl)
            self.layers_table.setCellWidget(row, 2, g_widget)

            # Col 3: Geometry column name
            g_col = l.get("geom_col", "-")
            self.layers_table.setItem(row, 3, QtWidgets.QTableWidgetItem(g_col))

            # Col 4: EPSG:3301
            has_3301 = l.get("has_3301", False)
            crs_widget = QtWidgets.QWidget()
            crs_lay = QtWidgets.QHBoxLayout(crs_widget)
            crs_lay.setContentsMargins(4, 2, 4, 2)
            crs_lbl = QtWidgets.QLabel(" Jah " if has_3301 else " Muu ")
            if has_3301:
                crs_lbl.setProperty("class", "BadgeGeom")
            crs_lbl.setAlignment(AlignCenter)
            crs_lay.addWidget(crs_lbl)
            self.layers_table.setCellWidget(row, 4, crs_widget)

            # Col 5: Action Button (Add to Canvas)
            btn_add_canvas = QtWidgets.QPushButton("+ Kaardile")
            btn_add_canvas.setStyleSheet("padding: 3px 8px; font-size: 8.5pt;")
            btn_add_canvas.clicked.connect(lambda ch, lyr=l: self._on_add_layer_to_canvas(lyr))
            self.layers_table.setCellWidget(row, 5, btn_add_canvas)

            self.layers_table.setRowHeight(row, 34)

    def _on_add_layer_to_canvas(self, layer_item):
        """Adds a single inspected layer directly onto QGIS map canvas."""
        if not self.last_result:
            return

        svc_dict = self.current_service_dict or {}
        svc_dict.update({
            "service_type": self.last_result.get("detected_type"),
            "url": self.last_result.get("url"),
            "preferred_settings": self.last_result.get("preferred_settings", {})
        })

        if self.qgis_connector:
            ok, msg = self.qgis_connector.add_layer_to_canvas(layer_item, svc_dict)
            if ok:
                QtWidgets.QMessageBox.information(self, tr("success"), msg)
            else:
                QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
        else:
            self.addLayerToCanvasRequested.emit(layer_item, svc_dict)

    def _on_add_to_profile_clicked(self):
        """Adds tested service to active profile with full preferred settings."""
        if not self.last_result:
            return

        active_prof = self.profile_manager.get_active_profile()
        if not active_prof:
            QtWidgets.QMessageBox.warning(self, tr("warning"), "Aktiivset profiili pole leitud.")
            return

        # Prepare service payload
        name = (self.current_service_dict or {}).get("name") or self.url_edit.text().strip().split("/")[-1]
        if not name or name == "ows" or name == "wms" or name == "wfs":
            name = f"{self.last_result.get('detected_type')} Teenus ({self.last_result.get('server_software', 'OGC')})"

        svc_payload = dict(self.current_service_dict or {})
        svc_payload.update({
            "name": name,
            "title_en": name,
            "service_type": self.last_result.get("detected_type"),
            "url": self.last_result.get("url"),
            "version": self.last_result.get("version"),
            "preferred_settings": self.last_result.get("preferred_settings", {}),
            "layers_count": self.last_result.get("layers_count", 0),
            "layers": self.last_result.get("layers", [])
        })

        self.profile_manager.add_service_to_profile(active_prof["id"], svc_payload)
        QtWidgets.QMessageBox.information(
            self, tr("success"),
            f"Teenus '{name}' lisati edukalt profiili '{active_prof.get('name')}' koos testitud seadetega!"
        )
        self.addToProfileWithSettings.emit(svc_payload)
