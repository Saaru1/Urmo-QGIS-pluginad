# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Service Advanced Information & Metadata Dialog
Displays in-depth metadata, protocol capabilities, geometry breakdowns,
and interactive layer list with instant map addition and clipboard copying.
"""

from qgis.PyQt import QtWidgets, QtCore, QtGui
from ...compat import (
    AlignLeft, AlignVCenter, AlignCenter,
    ResizeStretch, ResizeToContents, ResizeInteractive,
    set_header_resize_mode
)
from ...i18n import tr, get_language
from ...styles import get_stylesheet, get_current_theme
from ...service_tester import ServiceTester


class ServiceInspectWorker(QtCore.QThread):
    """Background inspector for services."""
    finished = QtCore.pyqtSignal(dict)
    error = QtCore.pyqtSignal(str)

    def __init__(self, tester, url, service_type, auth_type, auth_params, parent=None):
        super().__init__(parent)
        self.tester = tester
        self.url = url
        self.service_type = service_type
        self.auth_type = auth_type
        self.auth_params = auth_params

    def run(self):
        try:
            res = self.tester.inspect_service(
                self.url,
                service_type=self.service_type,
                auth_type=self.auth_type,
                auth_params=self.auth_params
            )
            self.finished.emit(res)
        except Exception as e:
            self.error.emit(str(e))


class ServiceInfoDialog(QtWidgets.QDialog):
    """Modern modal dialog showing comprehensive service metadata and layer breakdown."""

    openInLayersRequested = QtCore.pyqtSignal(dict)
    addLayerRequested = QtCore.pyqtSignal(dict, dict)
    renameRequested = QtCore.pyqtSignal(dict, str)

    def __init__(self, service_dict, qgis_connector=None, parent=None):
        super().__init__(parent)
        self.service_dict = dict(service_dict)
        self.qgis_connector = qgis_connector
        self.tester = ServiceTester(timeout=10)
        self.inspect_res = None
        self.worker = None

        self.setWindowTitle(f"{tr('info_dialog_title')} — {self.service_dict.get('name', 'Service')}")
        self.resize(760, 620)
        self.setStyleSheet(get_stylesheet(get_current_theme()))

        self._init_ui()
        self._load_service_data()

    def _init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # -------------------------------------------------------------
        # 1. Header Banner
        # -------------------------------------------------------------
        header = QtWidgets.QFrame()
        header.setObjectName("MetaOverviewHeader")
        h_layout = QtWidgets.QHBoxLayout(header)
        h_layout.setContentsMargins(10, 8, 10, 8)
        h_layout.setSpacing(8)

        v_title = QtWidgets.QVBoxLayout()
        v_title.setSpacing(2)
        self.lbl_title = QtWidgets.QLabel(f"<b>{self.service_dict.get('name', 'Service')}</b>")
        self.lbl_title.setStyleSheet("font-size: 13pt; font-weight: 700; color: #38bdf8;")
        self.lbl_sub = QtWidgets.QLabel(self.service_dict.get("url", ""))
        self.lbl_sub.setStyleSheet("font-size: 8.5pt; color: #94a3b8; font-family: monospace;")
        v_title.addWidget(self.lbl_title)
        v_title.addWidget(self.lbl_sub)
        h_layout.addLayout(v_title, stretch=1)

        self.badge_type = QtWidgets.QLabel(f" {self.service_dict.get('service_type', 'WFS')} ")
        self.badge_type.setProperty("class", f"Badge{self.service_dict.get('service_type', 'WFS')}")
        h_layout.addWidget(self.badge_type)

        self.btn_copy_url = QtWidgets.QPushButton(tr("btn_copy_url"))
        self.btn_copy_url.clicked.connect(self._copy_url)
        h_layout.addWidget(self.btn_copy_url)

        self.btn_open_layers = QtWidgets.QPushButton(tr("btn_inspect_in_layers"))
        self.btn_open_layers.setProperty("class", "PrimaryButton")
        self.btn_open_layers.clicked.connect(self._on_open_in_layers)
        h_layout.addWidget(self.btn_open_layers)

        layout.addWidget(header)

        # -------------------------------------------------------------
        # 2. Key Metadata Cards Grid
        # -------------------------------------------------------------
        meta_grid = QtWidgets.QGridLayout()
        meta_grid.setSpacing(8)

        self.card_provider = self._create_info_chip(tr("meta_owner"), self.service_dict.get("agency", "-"))
        meta_grid.addWidget(self.card_provider, 0, 0)

        self.card_version = self._create_info_chip(tr("meta_version_server"), "...")
        meta_grid.addWidget(self.card_version, 0, 1)

        self.card_paging = self._create_info_chip(tr("meta_paging"), "...")
        meta_grid.addWidget(self.card_paging, 0, 2)

        self.card_geom_summary = self._create_info_chip(tr("meta_geometry_breakdown"), "...")
        meta_grid.addWidget(self.card_geom_summary, 0, 3)

        layout.addLayout(meta_grid)

        # Loading Indicator
        self.loading_box = QtWidgets.QWidget()
        l_layout = QtWidgets.QHBoxLayout(self.loading_box)
        l_layout.setContentsMargins(0, 0, 0, 0)
        self.prog_bar = QtWidgets.QProgressBar()
        self.prog_bar.setRange(0, 0)
        self.prog_bar.setFixedHeight(8)
        self.lbl_load = QtWidgets.QLabel(tr("expand_loading"))
        self.lbl_load.setStyleSheet("color: #38bdf8; font-weight: 600; font-size: 8.5pt;")
        l_layout.addWidget(self.lbl_load)
        l_layout.addWidget(self.prog_bar)
        layout.addWidget(self.loading_box)

        # -------------------------------------------------------------
        # 3. Searchable Layers Table
        # -------------------------------------------------------------
        table_card = QtWidgets.QFrame()
        table_card.setObjectName("MetaOverviewCard")
        t_layout = QtWidgets.QVBoxLayout(table_card)
        t_layout.setContentsMargins(8, 8, 8, 8)
        t_layout.setSpacing(6)

        t_head = QtWidgets.QHBoxLayout()
        self.lbl_table_head = QtWidgets.QLabel(f"<b>{tr('tab_layers')} (0)</b>")
        self.lbl_table_head.setStyleSheet("font-size: 10pt; font-weight: 600;")
        t_head.addWidget(self.lbl_table_head)

        t_head.addStretch()

        self.filter_input = QtWidgets.QLineEdit()
        self.filter_input.setPlaceholderText(tr("layers_filter_placeholder"))
        self.filter_input.textChanged.connect(self._filter_table)
        self.filter_input.setMaximumWidth(280)
        t_head.addWidget(self.filter_input)

        t_layout.addLayout(t_head)

        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            tr("col_layer_title"),
            tr("col_geom_type"),
            tr("meta_geom_col"),
            tr("col_crs"),
            tr("col_actions")
        ])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows if hasattr(QtWidgets.QAbstractItemView, "SelectionBehavior") else QtWidgets.QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers if hasattr(QtWidgets.QAbstractItemView, "EditTrigger") else QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setShowGrid(True)
        self.table.setAlternatingRowColors(True)

        t_hdr = self.table.horizontalHeader()
        set_header_resize_mode(t_hdr, 0, ResizeStretch)
        set_header_resize_mode(t_hdr, 1, ResizeToContents)
        set_header_resize_mode(t_hdr, 2, ResizeToContents)
        set_header_resize_mode(t_hdr, 3, ResizeToContents)
        set_header_resize_mode(t_hdr, 4, ResizeToContents)

        t_layout.addWidget(self.table)
        layout.addWidget(table_card, stretch=1)

        # -------------------------------------------------------------
        # 4. Footer Close Bar
        # -------------------------------------------------------------
        foot = QtWidgets.QHBoxLayout()
        self.lbl_hint = QtWidgets.QLabel(tr("double_click_layer_hint"))
        self.lbl_hint.setStyleSheet("color: #64748b; font-size: 8.5pt;")
        foot.addWidget(self.lbl_hint)

        foot.addStretch()

        btn_close = QtWidgets.QPushButton(tr("btn_close"))
        btn_close.clicked.connect(self.accept)
        foot.addWidget(btn_close)

        layout.addLayout(foot)

    def _create_info_chip(self, label_text, val_text):
        f = QtWidgets.QFrame()
        f.setProperty("class", "MetaBadgeCard")
        vl = QtWidgets.QVBoxLayout(f)
        vl.setContentsMargins(6, 4, 6, 4)
        vl.setSpacing(2)
        lbl_k = QtWidgets.QLabel(f"<b>{label_text}</b>")
        lbl_k.setStyleSheet("color: #94a3b8; font-size: 8pt;")
        lbl_v = QtWidgets.QLabel(val_text)
        lbl_v.setStyleSheet("color: #f8fafc; font-weight: 600; font-size: 9pt;")
        vl.addWidget(lbl_k)
        vl.addWidget(lbl_v)
        f.lbl_val = lbl_v
        return f

    def _load_service_data(self):
        url = self.service_dict.get("url", "")
        stype = self.service_dict.get("service_type", "AUTO")
        auth_type = self.service_dict.get("auth_type", "none")
        auth_params = self.service_dict.get("auth_params", {})

        # If layers already cached in service dict
        cached_layers = self.service_dict.get("layers", [])
        if cached_layers:
            self._render_layers(cached_layers)
            self.loading_box.setVisible(False)
            return

        self.loading_box.setVisible(True)
        self.worker = ServiceInspectWorker(self.tester, url, stype, auth_type, auth_params, self)
        self.worker.finished.connect(self._on_worker_finished)
        self.worker.error.connect(self._on_worker_error)
        self.worker.start()

    def _on_worker_finished(self, res):
        self.loading_box.setVisible(False)
        self.inspect_res = res
        if res.get("online"):
            v_str = f"{res.get('detected_type')} {res.get('version')} ({res.get('server_software', 'OGC')})"
            self.card_version.lbl_val.setText(v_str)

            p_sup = res.get("paging_supported", False)
            p_str = f"{tr('yes_text')} (1000)" if p_sup else tr("no_text")
            self.card_paging.lbl_val.setText(p_str)

            layers = res.get("layers", [])
            self.service_dict["layers"] = layers
            self._render_layers(layers)
        else:
            self.card_version.lbl_val.setText("Offline / Error")
            self.table.setRowCount(0)

    def _on_worker_error(self, err_msg):
        self.loading_box.setVisible(False)
        self.card_version.lbl_val.setText(f"Error: {err_msg[:20]}")

    def _render_layers(self, layers):
        filter_text = self.filter_input.text().strip().lower()
        self.table.setRowCount(0)

        poly_cnt = 0
        line_cnt = 0
        point_cnt = 0
        mixed_cnt = 0

        filtered = []
        for l in layers:
            name = l.get("name", "")
            title = l.get("title", name)
            gt = l.get("geom_type", "Unknown")
            is_mix = l.get("is_mixed", False)

            if is_mix or "Mixed" in gt:
                mixed_cnt += 1
            elif "Poly" in gt:
                poly_cnt += 1
            elif "Line" in gt:
                line_cnt += 1
            elif "Point" in gt:
                point_cnt += 1

            if filter_text:
                if filter_text not in f"{name} {title} {gt}".lower():
                    continue
            filtered.append(l)

        # Update summary chip
        breakdown_str = f"Poly: {poly_cnt} | Line: {line_cnt} | Point: {point_cnt}"
        if mixed_cnt > 0:
            breakdown_str += f" | ⚠️ Mixed: {mixed_cnt}"
        self.card_geom_summary.lbl_val.setText(breakdown_str)
        if mixed_cnt > 0:
            self.card_geom_summary.lbl_val.setStyleSheet("color: #d946ef; font-weight: 700; font-size: 9pt;")

        self.lbl_table_head.setText(f"<b>{tr('tab_layers')} ({len(layers)})</b>")
        self.table.setRowCount(len(filtered))

        for row, l in enumerate(filtered):
            name = l.get("name", "")
            title = l.get("title", name)
            gt = l.get("geom_type", "Unknown")
            is_mix = l.get("is_mixed", False)
            geom_col = l.get("geom_col", "shape")
            crs_str = l.get("crs_summary", "EPSG:3301")

            it_title = QtWidgets.QTableWidgetItem(f"{title} ({name})")
            it_title.setData(QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, l)
            self.table.setItem(row, 0, it_title)

            # Geom badge
            badge_w = QtWidgets.QWidget()
            bl = QtWidgets.QHBoxLayout(badge_w)
            bl.setContentsMargins(4, 2, 4, 2)
            lbl_g = QtWidgets.QLabel(f" {gt} ")
            lbl_g.setProperty("class", "BadgeMixed" if is_mix else "BadgeGeom")
            lbl_g.setAlignment(AlignCenter)
            bl.addWidget(lbl_g)
            self.table.setCellWidget(row, 1, badge_w)

            self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(geom_col))
            self.table.setItem(row, 3, QtWidgets.QTableWidgetItem(crs_str))

            # Action button
            btn_add = QtWidgets.QPushButton(tr("btn_add_to_canvas"))
            btn_add.setProperty("class", "PrimaryButton")
            btn_add.setStyleSheet("padding: 2px 8px; font-size: 8pt;")
            btn_add.clicked.connect(lambda checked=False, lyr=l: self._on_add_layer(lyr))
            self.table.setCellWidget(row, 4, btn_add)

            self.table.setRowHeight(row, 32)

    def _filter_table(self, text):
        layers = self.service_dict.get("layers", [])
        self._render_layers(layers)

    def _copy_url(self):
        url = self.service_dict.get("url", "")
        clipboard = QtWidgets.QApplication.clipboard()
        clipboard.setText(url)
        QtWidgets.QMessageBox.information(self, tr("notice"), f"URL kopeeritud lõikelauale:\n{url}")

    def _on_open_in_layers(self):
        self.openInLayersRequested.emit(self.service_dict)
        self.accept()

    def _on_add_layer(self, layer_dict):
        if self.qgis_connector:
            ok, msg = self.qgis_connector.add_layer_to_canvas(layer_dict, self.service_dict)
            if ok:
                QtWidgets.QMessageBox.information(self, tr("success"), msg)
            else:
                QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
        else:
            self.addLayerRequested.emit(layer_dict, self.service_dict)
