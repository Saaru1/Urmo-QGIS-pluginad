# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Layers Panel Widget
Displays service layers with rich table metadata (Owner, Renewed, Last Updated, Paging, CRS),
non-blocking background worker with loading animation, prominent Overview card,
mixed geometry resolvers, and 100% dynamic EST/ENG translation.
"""

import json
import os
import re
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import QgsFeedback, QgsProject
from ...compat import (
    AlignLeft, AlignVCenter, AlignCenter,
    ItemIsEnabled, ItemIsSelectable, ItemIsDragEnabled,
    ResizeStretch, ResizeToContents, ResizeInteractive,
    set_header_resize_mode
)
from ...i18n import tr, get_language
from ...presets import get_all_presets
from ...service_tester import ServiceTester
from ...styles import get_current_theme
from ...layer_index import get_layer_index


class ServiceInspectWorker(QtCore.QThread):
    """Background worker executing service capability inspections without freezing the GUI."""

    progress = QtCore.pyqtSignal(int, str)
    finished = QtCore.pyqtSignal(dict)
    error = QtCore.pyqtSignal(str)

    def __init__(self, tester, url, service_type, auth_type, auth_params, force_refresh=False, parent=None):
        super().__init__(parent)
        self.tester = tester
        self.url = url
        self.service_type = service_type
        self.auth_type = auth_type
        self.auth_params = auth_params
        self.force_refresh = force_refresh

    def run(self):
        try:
            def on_progress(pct, msg):
                self.progress.emit(pct, msg)

            self.progress.emit(10, tr("loading_layers_text"))
            res = self.tester.inspect_service(
                self.url,
                service_type=self.service_type,
                auth_type=self.auth_type,
                auth_params=self.auth_params,
                progress_callback=on_progress,
                force_refresh=self.force_refresh
            )
            self.finished.emit(res)
        except Exception as e:
            self.error.emit(str(e))


class WebSearchWorker(QtCore.QThread):
    """Background worker querying open data portals and CSW asynchronously without freezing GUI."""

    finished = QtCore.pyqtSignal(list)
    error = QtCore.pyqtSignal(str)

    def __init__(self, layer_index, query, parent=None):
        super().__init__(parent)
        self.layer_index = layer_index
        self.query = query

    def run(self):
        try:
            results = self.layer_index.search_web(self.query, max_results=20)
            self.finished.emit(results)
        except Exception as e:
            self.error.emit(str(e))


class LayerProbeWorker(QtCore.QThread):
    """Background worker probing exact geometry counts and mixed types for a single layer."""

    finished = QtCore.pyqtSignal(dict, object)

    def __init__(self, tester, base_url, layer_dict, version, auth_type, auth_params, tree_item, parent=None):
        super().__init__(parent)
        self.tester = tester
        self.base_url = base_url
        self.layer_dict = layer_dict
        self.version = version
        self.auth_type = auth_type
        self.auth_params = auth_params
        self.tree_item = tree_item

    def run(self):
        try:
            res = self.tester.probe_layer_geometry(
                self.base_url,
                self.layer_dict,
                version=self.version,
                auth_type=self.auth_type,
                auth_params=self.auth_params
            )
            self.finished.emit(res, self.tree_item)
        except Exception:
            pass


class DraggableLayersTree(QtWidgets.QTreeWidget):
    """Tree widget enabling dragging layers out and receiving dropped services from Profile panel."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection if hasattr(QtWidgets.QAbstractItemView, "SelectionMode") else QtWidgets.QAbstractItemView.SingleSelection)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        if not item:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if not data:
            return

        drag = QtGui.QDrag(self)
        mime = QtCore.QMimeData()
        payload = json.dumps(data)
        mime.setData("application/x-geoprofile-item", QtCore.QByteArray(payload.encode("utf-8")))
        mime.setText(item.text(0))
        drag.setMimeData(mime)
        drag.exec(QtCore.Qt.DropAction.CopyAction if hasattr(QtCore.Qt, "DropAction") else QtCore.Qt.CopyAction)

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat("application/x-geoprofile-service") or event.mimeData().hasFormat("application/x-geoprofile-item"):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat("application/x-geoprofile-service") or event.mimeData().hasFormat("application/x-geoprofile-item"):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        mime = event.mimeData()
        payload = None
        for fmt in ("application/x-geoprofile-service", "application/x-geoprofile-item"):
            if mime.hasFormat(fmt):
                try:
                    payload = json.loads(bytes(mime.data(fmt)).decode("utf-8"))
                    break
                except Exception:
                    pass
        if payload and self.parent():
            p = self.parent()
            while p and not hasattr(p, "set_service"):
                p = p.parent()
            if p and hasattr(p, "set_service"):
                svc = payload.get("service") if "service" in payload else payload
                if svc:
                    QtCore.QTimer.singleShot(0, lambda target=svc: p.set_service(target))
                    event.acceptProposedAction()
                    return
        super().dropEvent(event)


class LayersWidget(QtWidgets.QWidget):
    """The central Layers Panel prioritizing individual layers and geometry diagnostics."""

    layerSelected = QtCore.pyqtSignal(dict, dict)
    addLayerRequested = QtCore.pyqtSignal(dict, dict, str, str)
    addToProfileRequested = QtCore.pyqtSignal(dict)

    def __init__(self, profile_manager, qgis_connector, parent=None):
        super().__init__(parent)
        self.profile_manager = profile_manager
        self.qgis_connector = qgis_connector
        self.tester = ServiceTester(timeout=10)
        self.layer_index = get_layer_index()
        self.mode = "single"  # "single" or "global"
        self.worker = None
        self.web_worker = None
        self.layer_probe_worker = None

        self.current_service_dict = None
        self.current_layers = []
        self.global_results = []
        self.current_selected_layer = None

        # Debounce timer for instantaneous, snappy search filtering without typing stutter
        self.search_debounce_timer = QtCore.QTimer(self)
        self.search_debounce_timer.setSingleShot(True)
        self.search_debounce_timer.setInterval(120)
        self.search_debounce_timer.timeout.connect(self._on_search_debounced)

        # Pre-cached graphic resources for tree rendering
        self._brush_cyan = QtGui.QBrush(QtGui.QColor("#38bdf8"))
        self._brush_orange = QtGui.QBrush(QtGui.QColor("#fb923c"))
        self._brush_green = QtGui.QBrush(QtGui.QColor("#4ade80"))
        self._brush_teal = QtGui.QBrush(QtGui.QColor("#06b6d4"))
        self._brush_magenta = QtGui.QBrush(QtGui.QColor("#d946ef"))
        self._font_bold = QtGui.QFont("", -1, QtGui.QFont.Weight.Bold if hasattr(QtGui.QFont, "Weight") else QtGui.QFont.Bold)

        self._init_ui()
        self.load_default_service()

        # Connect to preloader notifications to update global search live
        try:
            from ...preloader import CatalogPreloader
            CatalogPreloader.preload_all(self.profile_manager, callback=self._on_preloader_service_loaded)
        except Exception:
            pass

    def _init_ui(self):
        self.setAcceptDrops(True)
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(6)

        # -------------------------------------------------------------
        # 1. Mode Switcher & Quick Controls
        # -------------------------------------------------------------
        top_card = QtWidgets.QFrame()
        top_card.setProperty("class", "CardFrame")
        top_layout = QtWidgets.QVBoxLayout(top_card)
        top_layout.setContentsMargins(8, 6, 8, 6)
        top_layout.setSpacing(5)

        # Row 0: Mode Selection Segmented Buttons
        row0 = QtWidgets.QHBoxLayout()
        row0.setSpacing(6)

        self.btn_mode_single = QtWidgets.QPushButton(tr("mode_single_service"))
        self.btn_mode_single.setCheckable(True)
        self.btn_mode_single.setChecked(True)
        self.btn_mode_single.setToolTip("Kuva ja uuri valitud ruumiandmeteenuse kihte")
        self.btn_mode_single.setStyleSheet("font-size: 8.5pt; font-weight: 600; padding: 4px 8px;")
        self.btn_mode_single.clicked.connect(self._set_mode_single_service)
        row0.addWidget(self.btn_mode_single)

        self.btn_mode_global = QtWidgets.QPushButton(tr("mode_global_search"))
        self.btn_mode_global.setCheckable(True)
        self.btn_mode_global.setToolTip("Otsi andmestikke ja kihte üle kõigi Eesti riiklike teenuste ning veebist")
        self.btn_mode_global.setStyleSheet("font-size: 8.5pt; font-weight: 600; padding: 4px 8px;")
        self.btn_mode_global.clicked.connect(self._set_mode_global_search)
        row0.addWidget(self.btn_mode_global)

        row0.addStretch()
        top_layout.addLayout(row0)

        # Row 1: Single Service Selector (Visible in single mode, hidden in global mode)
        self.row1_widget = QtWidgets.QWidget()
        row1 = QtWidgets.QHBoxLayout(self.row1_widget)
        row1.setContentsMargins(0, 0, 0, 0)
        row1.setSpacing(6)

        self.lbl_svc = QtWidgets.QLabel(f"<b>{tr('service_selector_label')}</b>")
        row1.addWidget(self.lbl_svc)

        self.service_combo = QtWidgets.QComboBox()
        self.service_combo.setToolTip("Klõpsa siia, et avada rippmenüü (nimekiri) ja valida teine ruumiandmeteenus")
        self.service_combo.currentIndexChanged.connect(self._on_combo_service_selected)
        row1.addWidget(self.service_combo, stretch=2)

        self.btn_refresh = QtWidgets.QPushButton(tr("btn_refresh_layers"))
        self.btn_refresh.setProperty("class", "PrimaryButton")
        self.btn_refresh.setToolTip("Laadi teenuse andmed ja kihtide nimekiri uuesti serverist (tühjenda vahemälu)")
        self.btn_refresh.clicked.connect(lambda: self.reload_service_layers(force_refresh=True))
        row1.addWidget(self.btn_refresh)

        top_layout.addWidget(self.row1_widget)

        # Row 2: Search/Filter bar + Web search button + Status Pill
        row2 = QtWidgets.QHBoxLayout()
        row2.setSpacing(6)
        self.filter_input = QtWidgets.QLineEdit()
        self.filter_input.setPlaceholderText(tr("layers_filter_placeholder"))
        self.filter_input.setToolTip("Filtreeri kihte nime, pealkirja, geomeetria või omaniku järgi")
        self.filter_input.textChanged.connect(self._on_search_text_changed)
        self.filter_input.returnPressed.connect(self._on_search_return_pressed)
        row2.addWidget(self.filter_input, stretch=3)

        self.btn_web_search = QtWidgets.QPushButton(tr("btn_web_search"))
        self.btn_web_search.setProperty("class", "PrimaryButton")
        self.btn_web_search.setStyleSheet("font-size: 8.5pt; font-weight: 600; padding: 4px 8px;")
        self.btn_web_search.setToolTip("Otsi Eesti avaandmete portaalist (avaandmed.eesti.ee) ja Geoportaali CSW-st")
        self.btn_web_search.clicked.connect(self._start_web_search)
        self.btn_web_search.setVisible(False)
        row2.addWidget(self.btn_web_search)

        self.status_pill = QtWidgets.QLabel(tr("status_ready"))
        self.status_pill.setProperty("class", "BadgeCRS")
        row2.addWidget(self.status_pill)

        top_layout.addLayout(row2)

        # Non-blocking Loading Bar (Pulsing modern progress bar with percentage)
        self.loading_box = QtWidgets.QWidget()
        load_layout = QtWidgets.QVBoxLayout(self.loading_box)
        load_layout.setContentsMargins(0, 4, 0, 0)
        load_layout.setSpacing(2)

        self.lbl_loading = QtWidgets.QLabel(tr("loading_layers_text"))
        self.lbl_loading.setStyleSheet("color: #38bdf8; font-weight: 600; font-size: 8.5pt;")
        load_layout.addWidget(self.lbl_loading)

        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(14)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("%p%")
        load_layout.addWidget(self.progress_bar)

        self.loading_box.setVisible(False)
        top_layout.addWidget(self.loading_box)

        main_layout.addWidget(top_card)

        # -------------------------------------------------------------
        # 2. Rich Layers Table (with Owner, Renewed, Updated, Paging, CRS)
        # -------------------------------------------------------------
        self.tree = DraggableLayersTree(self)
        self.tree.setColumnCount(8)
        self.tree.setSortingEnabled(True)
        self.tree.setHeaderLabels([
            tr("col_layer_title"),
            tr("col_geom_type"),
            tr("col_owner"),
            tr("col_renewed"),
            tr("col_updated"),
            tr("col_paging"),
            tr("col_crs"),
            tr("col_actions")
        ])
        t_hdr = self.tree.header()
        for col in range(8):
            set_header_resize_mode(t_hdr, col, ResizeInteractive)

        self.tree.setColumnWidth(0, 160)
        self.tree.setColumnWidth(1, 95)
        self.tree.setColumnWidth(2, 110)
        self.tree.setColumnWidth(3, 85)
        self.tree.setColumnWidth(4, 85)
        self.tree.setColumnWidth(5, 65)
        self.tree.setColumnWidth(6, 75)
        self.tree.setColumnWidth(7, 75)
        self.tree.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded if hasattr(QtCore.Qt, "ScrollBarPolicy") else QtCore.Qt.ScrollBarAsNeeded)
        self.tree.setMinimumWidth(100)
        self.setMinimumWidth(220)

        self.tree.itemSelectionChanged.connect(self._on_tree_selection_changed)
        self.tree.itemDoubleClicked.connect(self._on_tree_double_clicked)
        main_layout.addWidget(self.tree, stretch=3)

        # -------------------------------------------------------------
        # 3. Highlighted Overview & Diagnostics Card (Bottom Panel)
        # -------------------------------------------------------------
        self.meta_card = QtWidgets.QFrame()
        self.meta_card.setObjectName("MetaOverviewCard")
        meta_layout = QtWidgets.QVBoxLayout(self.meta_card)
        meta_layout.setContentsMargins(8, 8, 8, 8)
        meta_layout.setSpacing(6)

        # Header Ribbon
        meta_header = QtWidgets.QFrame()
        meta_header.setObjectName("MetaOverviewHeader")
        h_strip = QtWidgets.QHBoxLayout(meta_header)
        h_strip.setContentsMargins(8, 5, 8, 5)
        h_strip.setSpacing(8)

        self.badge_card_title = QtWidgets.QLabel(f"📋 {tr('card_overview_badge')}")
        self.badge_card_title.setProperty("class", "BadgeWFS")
        self.badge_card_title.setStyleSheet("font-weight: 700; font-size: 8.5pt;")
        h_strip.addWidget(self.badge_card_title)

        self.lbl_layer_name = QtWidgets.QLabel(tr("no_layer_selected"))
        self.lbl_layer_name.setStyleSheet("font-size: 11pt; font-weight: 700; color: #38bdf8;")
        h_strip.addWidget(self.lbl_layer_name, stretch=1)

        self.lbl_geom_badge = QtWidgets.QLabel("")
        h_strip.addWidget(self.lbl_geom_badge)

        self.btn_add_canvas = QtWidgets.QPushButton(tr("btn_add_to_canvas"))
        self.btn_add_canvas.setProperty("class", "PrimaryButton")
        self.btn_add_canvas.setEnabled(False)
        self.btn_add_canvas.setToolTip("Ava valitud kiht otse QGIS-i kaardilõuendil")
        self.btn_add_canvas.clicked.connect(lambda: self._on_add_layer_clicked("single"))
        h_strip.addWidget(self.btn_add_canvas)

        self.btn_download_gpkg = QtWidgets.QPushButton(tr("btn_download_gpkg"))
        self.btn_download_gpkg.setEnabled(False)
        self.btn_download_gpkg.setToolTip(tr("tip_download_gpkg"))
        self.btn_download_gpkg.setStyleSheet("padding: 4px 8px; font-size: 8.5pt;")
        self.btn_download_gpkg.clicked.connect(self._on_download_gpkg_clicked)
        h_strip.addWidget(self.btn_download_gpkg)

        self.btn_add_prof = QtWidgets.QPushButton(tr("btn_add_to_profile"))
        self.btn_add_prof.setEnabled(False)
        self.btn_add_prof.setToolTip("Lisa valitud kiht aktiivsesse profiili")
        self.btn_add_prof.clicked.connect(self._on_add_to_profile_clicked)
        h_strip.addWidget(self.btn_add_prof)

        self.btn_toggle_meta = QtWidgets.QToolButton()
        self.btn_toggle_meta.setText("▾")
        self.btn_toggle_meta.setToolTip("Peida / Näita detailide sisu (Collapse/Expand details)")
        self.btn_toggle_meta.setStyleSheet("font-size: 9pt; font-weight: bold; padding: 2px 6px;")
        self.btn_toggle_meta.clicked.connect(self._toggle_meta_card)
        h_strip.addWidget(self.btn_toggle_meta)

        meta_layout.addWidget(meta_header)

        # Mixed Geometry Box
        self.mixed_box = QtWidgets.QFrame()
        self.mixed_box.setObjectName("MixedGeometryBox")
        mixed_layout = QtWidgets.QVBoxLayout(self.mixed_box)
        mixed_layout.setContentsMargins(8, 6, 8, 6)
        mixed_layout.setSpacing(4)

        is_light = get_current_theme() == "LIGHT"
        self.lbl_mixed_warn = QtWidgets.QLabel(tr("mixed_geom_detected_title"))
        self.lbl_mixed_warn.setStyleSheet(f"font-weight: 700; color: {'#86198f' if is_light else '#f5d0fe'}; font-size: 9.5pt;")
        mixed_layout.addWidget(self.lbl_mixed_warn)

        self.lbl_mixed_sub = QtWidgets.QLabel(tr("mixed_geom_desc"))
        self.lbl_mixed_sub.setStyleSheet(f"color: {'#701a75' if is_light else '#e9d5ff'}; font-size: 8.5pt;")
        self.lbl_mixed_sub.setWordWrap(True)
        mixed_layout.addWidget(self.lbl_mixed_sub)

        split_btns = QtWidgets.QHBoxLayout()
        split_btns.setSpacing(6)

        self.btn_poly = QtWidgets.QPushButton(tr("btn_open_poly"))
        self.btn_poly.setStyleSheet("padding: 4px 8px; font-size: 8.5pt;")
        self.btn_poly.setToolTip("Ava kaardil ainult polügoongeomeetriaga elemendid")
        self.btn_poly.clicked.connect(lambda: self._on_add_layer_clicked("single", geom_filter="Polygon"))
        split_btns.addWidget(self.btn_poly)

        self.btn_line = QtWidgets.QPushButton(tr("btn_open_lines"))
        self.btn_line.setStyleSheet("padding: 4px 8px; font-size: 8.5pt;")
        self.btn_line.setToolTip("Ava kaardil ainult joongeomeetriaga elemendid")
        self.btn_line.clicked.connect(lambda: self._on_add_layer_clicked("single", geom_filter="LineString"))
        split_btns.addWidget(self.btn_line)

        self.btn_point = QtWidgets.QPushButton(tr("btn_open_points"))
        self.btn_point.setStyleSheet("padding: 4px 8px; font-size: 8.5pt;")
        self.btn_point.setToolTip("Ava kaardil ainult punktgeomeetriaga elemendid")
        self.btn_point.clicked.connect(lambda: self._on_add_layer_clicked("single", geom_filter="Point"))
        split_btns.addWidget(self.btn_point)

        self.btn_split_all = QtWidgets.QPushButton(tr("btn_split_all"))
        self.btn_split_all.setProperty("class", "SuccessButton")
        self.btn_split_all.setStyleSheet("padding: 4px 10px; font-size: 8.5pt; font-weight: 700;")
        self.btn_split_all.setToolTip("Lahuta segakiht punktideks, joonteks ja polügoonideks ning ava kõik korraga kaardil")
        self.btn_split_all.clicked.connect(lambda: self._on_add_layer_clicked("split_all"))
        split_btns.addWidget(self.btn_split_all)

        self.btn_rule = QtWidgets.QPushButton(tr("btn_open_rule_based"))
        self.btn_rule.setStyleSheet("padding: 4px 8px; font-size: 8.5pt;")
        self.btn_rule.clicked.connect(lambda: self._on_add_layer_clicked("rule_based"))
        split_btns.addWidget(self.btn_rule)

        mixed_layout.addLayout(split_btns)
        meta_layout.addWidget(self.mixed_box)
        self.mixed_box.setVisible(False)

        # Metadata Tabs
        self.meta_tabs = QtWidgets.QTabWidget()
        self.meta_tabs.setStyleSheet("font-size: 9pt;")

        # Tab 1: Overview
        w_over = QtWidgets.QWidget()
        f_over = QtWidgets.QGridLayout(w_over)
        f_over.setContentsMargins(6, 6, 6, 6)
        f_over.setSpacing(6)

        # Abstract
        self.lbl_head_abstract = QtWidgets.QLabel(f"<b>{tr('meta_abstract')}</b>")
        f_over.addWidget(self.lbl_head_abstract, 0, 0)
        self.lbl_abstract = QtWidgets.QLabel("-")
        self.lbl_abstract.setWordWrap(True)
        f_over.addWidget(self.lbl_abstract, 0, 1, 1, 3)

        # Extent BBOX
        self.lbl_head_bbox = QtWidgets.QLabel(f"<b>{tr('meta_bbox')}</b>")
        f_over.addWidget(self.lbl_head_bbox, 1, 0)
        self.lbl_bbox = QtWidgets.QLabel("-")
        f_over.addWidget(self.lbl_bbox, 1, 1)

        # Paging
        self.lbl_head_paging = QtWidgets.QLabel(f"<b>{tr('meta_paging')}</b>")
        f_over.addWidget(self.lbl_head_paging, 1, 2)
        self.lbl_paging = QtWidgets.QLabel("-")
        f_over.addWidget(self.lbl_paging, 1, 3)

        # Owner
        self.lbl_head_owner = QtWidgets.QLabel(f"<b>{tr('meta_owner')}</b>")
        f_over.addWidget(self.lbl_head_owner, 2, 0)
        self.lbl_owner_val = QtWidgets.QLabel("-")
        f_over.addWidget(self.lbl_owner_val, 2, 1)

        # Frequency
        self.lbl_head_freq = QtWidgets.QLabel(f"<b>{tr('meta_frequency')}</b>")
        f_over.addWidget(self.lbl_head_freq, 2, 2)
        self.lbl_freq_val = QtWidgets.QLabel("-")
        f_over.addWidget(self.lbl_freq_val, 2, 3)

        # Last Updated
        self.lbl_head_updated = QtWidgets.QLabel(f"<b>{tr('meta_updated')}</b>")
        f_over.addWidget(self.lbl_head_updated, 3, 0)
        self.lbl_updated_val = QtWidgets.QLabel("-")
        f_over.addWidget(self.lbl_updated_val, 3, 1)

        # CRS
        self.lbl_head_crs = QtWidgets.QLabel(f"<b>{tr('meta_crs')}</b>")
        f_over.addWidget(self.lbl_head_crs, 3, 2)
        self.lbl_crs_val = QtWidgets.QLabel("-")
        f_over.addWidget(self.lbl_crs_val, 3, 3)

        self.meta_tabs.addTab(w_over, tr("tab_overview"))

        # Tab 2: Fields Schema Table
        self.fields_table = QtWidgets.QTableWidget()
        self.fields_table.setColumnCount(2)
        self.fields_table.setHorizontalHeaderLabels([tr("col_field_name"), tr("col_field_type")])
        self.fields_table.verticalHeader().setVisible(False)
        self.fields_table.setSortingEnabled(True)
        f_hdr = self.fields_table.horizontalHeader()
        set_header_resize_mode(f_hdr, 0, ResizeStretch)
        set_header_resize_mode(f_hdr, 1, ResizeToContents)
        self.meta_tabs.addTab(self.fields_table, tr("tab_fields"))

        meta_layout.addWidget(self.meta_tabs)

        self.hint_lbl = QtWidgets.QLabel(tr("btn_drag_hint"))
        self.hint_lbl.setStyleSheet("color: #64748b; font-size: 8.5pt;")
        meta_layout.addWidget(self.hint_lbl)

        main_layout.addWidget(self.meta_card, stretch=2)

    def load_default_service(self):
        """Populates service dropdown with presets and detected QGIS connections, leaving selection empty on startup."""
        self.service_combo.blockSignals(True)
        self.service_combo.clear()

        # Add empty prompt item as index 0 so no service is auto-selected on start
        self.service_combo.addItem(tr("choose_service_prompt"), None)

        # Check if Current Profile has services
        cur_prof = self.profile_manager.get_active_profile()
        if cur_prof and cur_prof.get("services"):
            for s in cur_prof["services"]:
                stype = s.get("service_type", "WMS")
                name = s.get("name", "Service")
                self.service_combo.addItem(f"[{stype}] {name}", s)

        # Add presets
        presets = get_all_presets()
        for p in presets:
            stype = p.get("service_type", "WMS")
            name = p.get("name", "Service")
            if not any(self.service_combo.itemText(i) == f"[{stype}] {name}" for i in range(self.service_combo.count())):
                self.service_combo.addItem(f"[{stype}] {name}", p)

        self.service_combo.setCurrentIndex(0)
        self.current_service_dict = None
        self.current_layers = []
        self.current_selected_layer = None
        self.tree.clear()
        self._on_tree_selection_changed()
        self.status_pill.setText("")
        self.btn_refresh.setEnabled(False)
        self.service_combo.blockSignals(False)

    def dragEnterEvent(self, event):
        """Accepts service items dragged from Profile panel."""
        mime = event.mimeData()
        if (mime.hasFormat("application/x-geoprofile-service") or
            mime.hasFormat("application/x-geoprofile-item") or
            mime.hasText()):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        mime = event.mimeData()
        if (mime.hasFormat("application/x-geoprofile-service") or
            mime.hasFormat("application/x-geoprofile-item") or
            mime.hasText()):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        """When a service is dropped, sets it as current and immediately inspects it."""
        mime = event.mimeData()
        payload = None
        for fmt in ("application/x-geoprofile-service", "application/x-geoprofile-item"):
            if mime.hasFormat(fmt):
                try:
                    payload = json.loads(bytes(mime.data(fmt)).decode("utf-8"))
                    break
                except Exception:
                    pass

        if payload:
            target_svc = None
            if "service" in payload:
                target_svc = payload["service"]
            elif "url" in payload:
                target_svc = payload
            elif "layer" in payload:
                target_svc = payload.get("service")

            if target_svc and isinstance(target_svc, dict):
                QtCore.QTimer.singleShot(0, lambda target=target_svc: self.set_service(target))
                event.acceptProposedAction()
                return

        event.ignore()

    def set_service(self, service_dict):
        """Sets active service in combo, then runs inspection."""
        self.current_service_dict = dict(service_dict)
        url = service_dict.get("url", "").strip()
        stype = (service_dict.get("service_type") or "").upper()

        self.service_combo.blockSignals(True)
        try:
            found = False
            for i in range(self.service_combo.count()):
                d = self.service_combo.itemData(i)
                if d and d.get("url") == url:
                    d_stype = (d.get("service_type") or "").upper()
                    if stype and d_stype and stype != d_stype:
                        continue
                    self.service_combo.setCurrentIndex(i)
                    self.current_service_dict = dict(d)
                    found = True
                    break

            if not found:
                name = service_dict.get("name", "Custom Service")
                st = service_dict.get("service_type", "WFS")
                insert_idx = 1 if (self.service_combo.count() > 0 and self.service_combo.itemData(0) is None) else 0
                self.service_combo.insertItem(insert_idx, f"[{st}] {name}", service_dict)
                self.service_combo.setCurrentIndex(insert_idx)
        finally:
            self.service_combo.blockSignals(False)

        self.btn_refresh.setEnabled(True)
        self.reload_service_layers()

    def _on_combo_service_selected(self, index):
        if index >= 0:
            data = self.service_combo.itemData(index)
            if data and isinstance(data, dict):
                self.current_service_dict = dict(data)
                self.btn_refresh.setEnabled(True)
                self.reload_service_layers()
            else:
                self.current_service_dict = None
                self.current_layers = []
                self.current_selected_layer = None
                self.tree.clear()
                self._on_tree_selection_changed()
                self.status_pill.setText("")
                self.btn_refresh.setEnabled(False)

    def reload_service_layers(self, force_refresh=False):
        """Runs inspector on current service using non-blocking background worker."""
        if not self.current_service_dict:
            return

        url = self.current_service_dict.get("url", "")
        stype = self.current_service_dict.get("service_type", "AUTO")
        auth_type = self.current_service_dict.get("auth_type", "none")
        auth_params = self.current_service_dict.get("auth_params", {})

        # Fast Instant Check: if layers already in persistent catalog cache and not forced refresh
        if not force_refresh and url and stype not in ("MIXED", "XYZ"):
            try:
                from ...cache.layer_cache import get_layer_catalog_cache
                cached = get_layer_catalog_cache().get_layers(stype, url)
                if cached:
                    self.current_layers = cached
                    self.status_pill.setText(f"● {stype} ({len(cached)} kihti)")
                    self.status_pill.setStyleSheet("color: #4ade80; font-weight: 700;")
                    self._populate_layers_tree(self.current_layers)
                    self.layer_index.register_service_layers(self.current_service_dict, self.current_layers)
                    self.btn_refresh.setEnabled(True)
                    return
            except Exception:
                pass

        # Show animated loading bar
        self.loading_box.setVisible(True)
        self.lbl_loading.setText(tr("loading_layers_text"))
        self.status_pill.setText(tr("status_loading"))
        self.status_pill.setStyleSheet("color: #38bdf8; font-weight: 600;")
        self.btn_refresh.setEnabled(False)

        # Safely disconnect any previously running worker (NEVER terminate in Python)
        if self.worker and self.worker.isRunning():
            try:
                self.worker.progress.disconnect()
                self.worker.finished.disconnect()
                self.worker.error.disconnect()
            except Exception:
                pass
            self.worker = None

        self.worker = ServiceInspectWorker(self.tester, url, stype, auth_type, auth_params, force_refresh=force_refresh, parent=self)
        self.worker.progress.connect(self._on_worker_progress)
        self.worker.finished.connect(self._on_inspect_finished)
        self.worker.error.connect(self._on_inspect_error)
        self.worker.start()

    def _on_worker_progress(self, percent, msg):
        """Updates progress bar and status indicator in real-time."""
        self.progress_bar.setValue(percent)
        self.lbl_loading.setText(f"{msg} ({percent}%)")
        self.status_pill.setText(f"● {percent}%")

    def _on_inspect_finished(self, res):
        """Called on worker completion."""
        self.loading_box.setVisible(False)
        self.btn_refresh.setEnabled(True)

        if res.get("online"):
            det_type = res.get("detected_type") or res.get("service_type")
            if det_type and self.current_service_dict:
                self.current_service_dict["service_type"] = det_type
            self.status_pill.setText(f"● {res.get('detected_type')} {res.get('version')} ({res.get('latency_ms')}ms)")
            self.status_pill.setStyleSheet("color: #4ade80; font-weight: 700;")
            self.current_layers = res.get("layers", [])
            if self.current_service_dict and self.current_layers:
                self.layer_index.register_service_layers(self.current_service_dict, self.current_layers)
            self._populate_layers_tree(self.current_layers)
        else:
            err = res.get("error", "Viga")
            self.status_pill.setText(f"● Viga: {err[:20]}")
            self.status_pill.setStyleSheet("color: #f87171; font-weight: 700;")
            self.tree.clear()

    def _on_inspect_error(self, err_msg):
        self.loading_box.setVisible(False)
        self.btn_refresh.setEnabled(True)
        self.status_pill.setText(f"● Viga: {err_msg[:20]}")
        self.status_pill.setStyleSheet("color: #f87171; font-weight: 700;")

    def _set_mode_single_service(self):
        self.mode = "single"
        self.btn_mode_single.setChecked(True)
        self.btn_mode_global.setChecked(False)
        self.row1_widget.setVisible(True)
        self.btn_web_search.setVisible(False)
        self.filter_input.setPlaceholderText(tr("layers_filter_placeholder"))
        self._populate_layers_tree(self.current_layers)
        self.status_pill.setText(f"{len(self.current_layers)} kihti")

    def _set_mode_global_search(self):
        self.mode = "global"
        self.btn_mode_single.setChecked(False)
        self.btn_mode_global.setChecked(True)
        self.row1_widget.setVisible(False)
        self.btn_web_search.setVisible(True)
        self.filter_input.setPlaceholderText(tr("global_search_placeholder"))
        self._execute_global_search()

    def _on_search_text_changed(self, text):
        self.search_debounce_timer.start()

    def _on_search_debounced(self):
        if self.mode == "single":
            self._populate_layers_tree(self.current_layers)
        else:
            self._execute_global_search()

    def _on_search_return_pressed(self):
        self.search_debounce_timer.stop()
        self._on_search_debounced()
        if self.mode == "global":
            q = self.filter_input.text().strip()
            if not self.global_results and q:
                self._start_web_search()

    def _on_preloader_service_loaded(self, service_dict, layers):
        """Refreshes global search results live if newly indexed layers arrive."""
        if self.mode == "global":
            self.search_debounce_timer.start()

    def _execute_global_search(self):
        q = self.filter_input.text().strip()
        local_results = self.layer_index.search_local(q)
        self.global_results = local_results
        self._populate_global_layers_tree(local_results)
        total_cnt = len(local_results)
        if total_cnt > 150:
            self.status_pill.setText(f"{tr('local_results_count', count=total_cnt)} (kuvatud 150)")
        else:
            self.status_pill.setText(tr("local_results_count", count=total_cnt))

    def _start_web_search(self):
        q = self.filter_input.text().strip()
        if not q:
            QtWidgets.QMessageBox.information(self, tr("warning"), "Palun sisesta otsisõna (nt kataster, mets, kaitseala).")
            return
        if self.web_worker and self.web_worker.isRunning():
            return

        self.status_pill.setText(tr("searching_web"))
        self.loading_box.setVisible(True)
        self.lbl_loading.setText(tr("searching_web"))
        self.progress_bar.setRange(0, 0)

        self.web_worker = WebSearchWorker(self.layer_index, q, self)
        self.web_worker.finished.connect(self._on_web_search_finished)
        self.web_worker.error.connect(self._on_web_search_error)
        self.web_worker.start()

    def _on_web_search_finished(self, web_results):
        self.loading_box.setVisible(False)
        self.progress_bar.setRange(0, 100)
        seen = {(x["name"].lower(), x.get("service_url", "").lower()) for x in self.global_results}
        merged = list(self.global_results)
        added_count = 0
        for w in web_results:
            key = (w["name"].lower(), w.get("service_url", "").lower())
            if key not in seen:
                seen.add(key)
                merged.append(w)
                added_count += 1
        self.global_results = merged
        self._populate_global_layers_tree(merged)
        self.status_pill.setText(tr("web_results_count", count=len(web_results)))

    def _on_web_search_error(self, err_msg):
        self.loading_box.setVisible(False)
        self.status_pill.setText("Veebiotsingu viga")

    def _populate_global_layers_tree(self, results):
        """Fills tree with global search results across all services and web."""
        self.tree.blockSignals(True)
        self.tree.setUpdatesEnabled(False)
        was_sorting = self.tree.isSortingEnabled()
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        items_to_add = []

        display_results = results[:150]

        btn_txt = tr("btn_add_to_canvas")
        brush_cyan = getattr(self, "_brush_cyan", None) or QtGui.QBrush(QtGui.QColor("#38bdf8"))
        brush_orange = getattr(self, "_brush_orange", None) or QtGui.QBrush(QtGui.QColor("#fb923c"))
        brush_green = getattr(self, "_brush_green", None) or QtGui.QBrush(QtGui.QColor("#4ade80"))
        brush_teal = getattr(self, "_brush_teal", None) or QtGui.QBrush(QtGui.QColor("#06b6d4"))
        font_bold = getattr(self, "_font_bold", None)
        user_role = QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole

        try:
            for item in display_results:
                title = item.get("title") or item.get("name", "Layer")
                name = item.get("name", "")
                geom_type = item.get("geometry_type", "Tundmatu")
                owner = item.get("agency", item.get("service_name", "Eesti riik"))
                stype = item.get("service_type", "WMS")
                source = item.get("source", "CATALOG")
                source_str = "🌐 VEEB" if source == "WEB" else "Kataloog"
                paging_str = "Jah" if stype == "WFS" else "-"
                crs_str = item.get("crs", "EPSG:3301")

                tree_item = QtWidgets.QTreeWidgetItem()
                tree_item.setText(0, title)
                tree_item.setText(1, f" {geom_type} ")
                tree_item.setText(2, owner)
                tree_item.setText(3, f"[{stype}]")
                tree_item.setText(4, source_str)
                tree_item.setText(5, paging_str)
                tree_item.setText(6, crs_str)
                tree_item.setText(7, btn_txt)

                l_dict = {
                    "name": name,
                    "title": title,
                    "geom_type": geom_type,
                    "abstract": item.get("abstract", ""),
                    "owner": owner,
                    "default_crs": crs_str,
                    "has_3301": ("3301" in crs_str),
                    "is_mixed": False,
                    "bbox": {}
                }
                payload = {
                    "type": "layer",
                    "layer": l_dict,
                    "service": item.get("service_dict") or {
                        "name": owner,
                        "agency": owner,
                        "service_type": stype,
                        "url": item.get("service_url", "")
                    }
                }
                tree_item.setData(0, user_role, payload)

                if source == "WEB":
                    tree_item.setForeground(4, brush_cyan)
                    if font_bold:
                        tree_item.setFont(4, font_bold)
                if "Poly" in geom_type or "Polü" in geom_type:
                    tree_item.setForeground(1, brush_cyan)
                elif "Line" in geom_type or "Joon" in geom_type:
                    tree_item.setForeground(1, brush_orange)
                elif "Point" in geom_type or "Punkt" in geom_type:
                    tree_item.setForeground(1, brush_green)
                elif "Raster" in geom_type:
                    tree_item.setForeground(1, brush_teal)

                items_to_add.append(tree_item)

            self.tree.addTopLevelItems(items_to_add)
        finally:
            self.tree.setSortingEnabled(was_sorting)
            self.tree.setUpdatesEnabled(True)
            self.tree.blockSignals(False)

        if self.tree.topLevelItemCount() > 0:
            self.tree.setCurrentItem(self.tree.topLevelItem(0))
        else:
            self.tree.setCurrentItem(None)
            self._on_tree_selection_changed()

    def _populate_layers_tree(self, layers):
        """Fills tree with rich layer rows quickly with batch insertion and updates disabled."""
        self.tree.blockSignals(True)
        self.tree.setUpdatesEnabled(False)
        was_sorting = self.tree.isSortingEnabled()
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        filter_text = self.filter_input.text().strip().lower()
        items_to_add = []

        btn_txt = tr("btn_add_to_canvas")
        brush_cyan = getattr(self, "_brush_cyan", None) or QtGui.QBrush(QtGui.QColor("#38bdf8"))
        brush_orange = getattr(self, "_brush_orange", None) or QtGui.QBrush(QtGui.QColor("#fb923c"))
        brush_green = getattr(self, "_brush_green", None) or QtGui.QBrush(QtGui.QColor("#4ade80"))
        brush_teal = getattr(self, "_brush_teal", None) or QtGui.QBrush(QtGui.QColor("#06b6d4"))
        brush_magenta = getattr(self, "_brush_magenta", None) or QtGui.QBrush(QtGui.QColor("#d946ef"))
        font_bold = getattr(self, "_font_bold", None)
        user_role = QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole

        try:
            for l in layers:
                name = l.get("name", "")
                title = l.get("title", name)
                stype = (l.get("service_type") or (self.current_service_dict or {}).get("service_type") or "WMS").upper()
                geom_type = l.get("geom_type") or l.get("geometry_type") or ("Vektor (WFS)" if stype == "WFS" else "Raster")
                geom_col = l.get("geom_col", "-")
                has_3301 = l.get("has_3301", False)
                is_mixed = l.get("is_mixed", False)

                owner = l.get("owner", (self.current_service_dict or {}).get("agency", "-"))
                renewed = l.get("renewed", "Perioodiline")
                updated = l.get("updated", "2026")
                raw_paging = str(l.get("paging_str", ""))
                if stype in ("WMS", "WMTS", "XYZ", "WCS"):
                    paging_str = "- (Raster)"
                elif "jah" in raw_paging.lower() or "yes" in raw_paging.lower() or "1000" in raw_paging:
                    paging_str = f"{tr('yes_text')} (1000)"
                elif "ei" in raw_paging.lower() or "no" in raw_paging.lower():
                    paging_str = tr("no_text")
                else:
                    paging_str = raw_paging or "-"
                crs_str = l.get("crs_summary", "EPSG:3301" if has_3301 else "Muu")

                if filter_text:
                    haystack = f"{name} {title} {geom_type} {owner} {renewed}".lower()
                    if filter_text not in haystack:
                        continue

                item = QtWidgets.QTreeWidgetItem()
                item.setText(0, title)
                item.setText(1, f" {geom_type} ")
                item.setText(2, owner)
                item.setText(3, renewed)
                item.setText(4, updated)
                item.setText(5, paging_str)
                item.setText(6, crs_str)
                item.setText(7, btn_txt)

                payload = {
                    "type": "layer",
                    "layer": l,
                    "service": self.current_service_dict
                }
                item.setData(0, user_role, payload)

                if is_mixed:
                    item.setForeground(1, brush_magenta)
                    if font_bold:
                        item.setFont(1, font_bold)
                elif "DTM" in geom_type or "Kõrgus" in geom_type:
                    item.setForeground(1, brush_teal)
                    if font_bold:
                        item.setFont(1, font_bold)
                elif "Poly" in geom_type:
                    item.setForeground(1, brush_cyan)
                elif "Line" in geom_type:
                    item.setForeground(1, brush_orange)
                elif "Point" in geom_type:
                    item.setForeground(1, brush_green)

                items_to_add.append(item)

            self.tree.addTopLevelItems(items_to_add)
        finally:
            self.tree.setSortingEnabled(was_sorting)
            self.tree.setUpdatesEnabled(True)
            self.tree.blockSignals(False)

        if self.tree.topLevelItemCount() > 0:
            self.tree.setCurrentItem(self.tree.topLevelItem(0))
        else:
            self.tree.setCurrentItem(None)
            self._on_tree_selection_changed()

    def _filter_layers_tree(self, text):
        self._populate_layers_tree(self.current_layers)

    def _on_tree_selection_changed(self):
        item = self.tree.currentItem()
        if not item:
            self.current_selected_layer = None
            self.lbl_layer_name.setText(tr("no_layer_selected"))
            self.lbl_geom_badge.setText("")
            self.lbl_abstract.setText("-")
            self.lbl_bbox.setText("-")
            self.lbl_paging.setText("-")
            self.lbl_owner_val.setText("-")
            self.lbl_freq_val.setText("-")
            self.lbl_updated_val.setText("-")
            self.lbl_crs_val.setText("-")
            self.btn_add_canvas.setEnabled(False)
            self.btn_download_gpkg.setEnabled(False)
            self.btn_add_prof.setEnabled(False)
            self.mixed_box.setVisible(False)
            self.fields_table.setRowCount(0)
            return

        payload = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if not payload or "layer" not in payload:
            return

        l = payload["layer"]
        self.current_selected_layer = l
        if "service" in payload and payload["service"]:
            self.current_service_dict = payload["service"]
        self.btn_add_canvas.setEnabled(True)
        self.btn_add_prof.setEnabled(True)

        title = l.get("title", l.get("name", "Layer"))
        stype = (l.get("service_type") or (self.current_service_dict or {}).get("service_type") or "WMS").upper()
        self.btn_download_gpkg.setEnabled(stype == "WFS")
        geom_type = l.get("geom_type") or l.get("geometry_type") or ("Vektor (WFS)" if stype == "WFS" else "Raster")
        is_mixed = l.get("is_mixed", False)

        self.lbl_layer_name.setText(f"{title} ({l.get('name')})")
        self.lbl_geom_badge.setText(f" {geom_type} ")
        target_badge_class = "BadgeMixed" if is_mixed else "BadgeGeom"
        if self.lbl_geom_badge.property("class") != target_badge_class:
            self.lbl_geom_badge.setProperty("class", target_badge_class)
            self.lbl_geom_badge.style().unpolish(self.lbl_geom_badge)
            self.lbl_geom_badge.style().polish(self.lbl_geom_badge)

        self.mixed_box.setVisible(is_mixed)
        if is_mixed:
            counts = l.get("geom_counts", {})
            poly_c = counts.get("Polygon", 0)
            line_c = counts.get("LineString", 0)
            pt_c = counts.get("Point", 0)

            self.btn_poly.setVisible(poly_c > 0)
            self.btn_poly.setText(f"{tr('btn_open_poly')} ({poly_c:,})")
            self.btn_line.setVisible(line_c > 0)
            self.btn_line.setText(f"{tr('btn_open_lines')} ({line_c:,})")
            self.btn_point.setVisible(pt_c > 0)
            self.btn_point.setText(f"{tr('btn_open_points')} ({pt_c:,})")

            active_cnt = len(l.get("mixed_types", []))
            self.btn_split_all.setText(f"★ {tr('btn_split_all')} ({active_cnt} kihti)")

        abstract = l.get("abstract", "")
        self.lbl_abstract.setText(abstract if abstract else "Puudub täpsem kirjeldus.")

        bbox = l.get("bbox")
        if bbox:
            b_str = f"MinX: {bbox['minx']:.2f}, MinY: {bbox['miny']:.2f} | MaxX: {bbox['maxx']:.2f}, MaxY: {bbox['maxy']:.2f} ({bbox.get('crs')})"
            self.lbl_bbox.setText(b_str)
        else:
            self.lbl_bbox.setText("Globaalne või määramata")

        stype = self.current_service_dict.get("service_type", "WMS").upper()
        if stype in ("WMS", "WMTS", "XYZ", "WCS"):
            self.lbl_paging.setText("Ei kohaldu (Raster / Pilditeenus)")
        else:
            paging = self.current_service_dict.get("preferred_settings", {}).get("paging-enabled", True)
            c_limit = l.get("server_count_limit") or self.current_service_dict.get("preferred_settings", {}).get("server_count_limit")
            limit_str = f" / serveri limiit: {c_limit}" if c_limit else ""
            self.lbl_paging.setText(f"{tr('yes_text')} (1000 lk{limit_str})" if paging else tr("no_text"))

        self.lbl_owner_val.setText(l.get("owner", "-"))
        self.lbl_freq_val.setText(l.get("renewed", "-"))
        self.lbl_updated_val.setText(l.get("updated", "-"))
        self.lbl_crs_val.setText(l.get("crs_summary", "EPSG:3301" if l.get("has_3301") else "Muu"))

        fields = l.get("fields", [])
        self.fields_table.setRowCount(len(fields))
        for row, f in enumerate(fields):
            self.fields_table.setItem(row, 0, QtWidgets.QTableWidgetItem(f.get("name", "")))
            self.fields_table.setItem(row, 1, QtWidgets.QTableWidgetItem(f.get("type", "")))
            self.fields_table.setRowHeight(row, 24)

        # On-demand deep geometry probing for WFS layers that haven't been verified
        stype = (l.get("service_type") or (self.current_service_dict or {}).get("service_type") or "WMS").upper()
        if stype == "WFS" and not l.get("probed"):
            self.lbl_geom_badge.setText(f" {geom_type} ⏳ ")
            if self.layer_probe_worker and self.layer_probe_worker.isRunning():
                try:
                    self.layer_probe_worker.finished.disconnect()
                except Exception:
                    pass
                self.layer_probe_worker = None

            base_url = self.current_service_dict.get("url", "").split("?")[0]
            ver = self._extract_service_version()
            auth_type = self.current_service_dict.get("auth_type", "none")
            auth_params = self.current_service_dict.get("auth_params", {})

            self.layer_probe_worker = LayerProbeWorker(
                self.tester, base_url, l, ver, auth_type, auth_params, item, self
            )
            self.layer_probe_worker.finished.connect(self._on_layer_probed)
            self.layer_probe_worker.start()

    def _extract_service_version(self):
        """Extracts clean WFS version avoiding duplicate URL parameters."""
        url = self.current_service_dict.get("url", "")
        if "version=1.1" in url.lower():
            return "1.1.0"
        if "version=1.0" in url.lower():
            return "1.0.0"
        if "version=2.0" in url.lower():
            return "2.0.0"
        ver = self.current_service_dict.get("version") or self.current_service_dict.get("preferred_settings", {}).get("version")
        if ver and "version=" in str(ver).lower():
            return str(ver).split("=")[-1].split("&")[0]
        return str(ver) if ver and ver != "auto" else "2.0.0"

    def _on_layer_probed(self, l, item):
        """Called when deep geometry inspection finishes."""
        geom_type = l.get("geom_type", "Geometry")
        is_mixed = l.get("is_mixed", False)

        try:
            item.setText(1, f" {geom_type} ")
            if is_mixed:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#d946ef")))
                item.setFont(1, QtGui.QFont("", -1, QtGui.QFont.Weight.Bold if hasattr(QtGui.QFont, "Weight") else QtGui.QFont.Bold))
            elif "Poly" in geom_type:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#38bdf8")))
            elif "Line" in geom_type:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#fb923c")))
            elif "Point" in geom_type:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#4ade80")))
        except Exception:
            pass

        # If this layer is currently selected, refresh bottom overview card
        if self.current_selected_layer and self.current_selected_layer.get("name") == l.get("name"):
            self.lbl_geom_badge.setText(f" {geom_type} ")
            self.lbl_geom_badge.setProperty("class", "BadgeMixed" if is_mixed else "BadgeGeom")
            self.lbl_geom_badge.style().unpolish(self.lbl_geom_badge)
            self.lbl_geom_badge.style().polish(self.lbl_geom_badge)

            self.mixed_box.setVisible(is_mixed)
            if is_mixed:
                counts = l.get("geom_counts", {})
                poly_c = counts.get("Polygon", 0)
                line_c = counts.get("LineString", 0)
                pt_c = counts.get("Point", 0)

                self.btn_poly.setVisible(poly_c > 0)
                self.btn_poly.setText(f"{tr('btn_open_poly')} ({poly_c:,})")
                self.btn_line.setVisible(line_c > 0)
                self.btn_line.setText(f"{tr('btn_open_lines')} ({line_c:,})")
                self.btn_point.setVisible(pt_c > 0)
                self.btn_point.setText(f"{tr('btn_open_points')} ({pt_c:,})")

                active_cnt = len(l.get("mixed_types", []))
                self.btn_split_all.setText(f"★ {tr('btn_split_all')} ({active_cnt} kihti)")

    def _on_tree_double_clicked(self, item, column):
        self._on_add_layer_clicked("single")

    def _on_add_layer_clicked(self, mode="single", geom_filter=None):
        if not self.current_selected_layer or not self.current_service_dict:
            return

        l = self.current_selected_layer
        stype = self.current_service_dict.get("service_type", "WMS").upper()

        if mode == "single" and geom_filter is None and stype == "WFS":
            # If not yet probed or unknown, probe synchronously before opening to prevent silent data loss!
            if not l.get("probed") or l.get("geom_type") in ("Geometry", "Unknown"):
                base_url = self.current_service_dict.get("url", "").split("?")[0]
                ver = self._extract_service_version()
                auth_type = self.current_service_dict.get("auth_type", "none")
                auth_params = self.current_service_dict.get("auth_params", {})
                QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.CursorShape.WaitCursor if hasattr(QtCore.Qt, "CursorShape") else QtCore.Qt.WaitCursor)
                try:
                    self.tester.probe_layer_geometry(base_url, l, version=ver, auth_type=auth_type, auth_params=auth_params)
                    self._on_layer_probed(l, self.tree.currentItem())
                finally:
                    QtWidgets.QApplication.restoreOverrideCursor()

            if l.get("is_mixed"):
                self._show_mixed_layer_dialog(l)
                return

        self._execute_add_layer(mode=mode, geom_filter=geom_filter)

    def _show_mixed_layer_dialog(self, layer):
        """Shows modal warning and resolver dialog to prevent silent data loss in QGIS."""
        title = layer.get("title", layer.get("name", "Layer"))
        counts = layer.get("geom_counts", {})
        poly_c = counts.get("Polygon", 0)
        line_c = counts.get("LineString", 0)
        pt_c = counts.get("Point", 0)
        mixed_types = layer.get("mixed_types", [])

        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle(tr("mixed_dialog_title"))
        dlg.setMinimumWidth(440)

        layout = QtWidgets.QVBoxLayout(dlg)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # Header Title
        lbl_t = QtWidgets.QLabel(f"<b>{title}</b>")
        lbl_t.setStyleSheet("font-size: 11pt; color: #38bdf8; font-weight: 700;")
        layout.addWidget(lbl_t)

        parts = []
        if poly_c > 0:
            parts.append(f"• <b>{poly_c:,}</b> polügooni / polygon")
        if pt_c > 0:
            parts.append(f"• <b>{pt_c:,}</b> punkti / point")
        if line_c > 0:
            parts.append(f"• <b>{line_c:,}</b> joont / line")

        breakdown_text = "\n".join(parts) if parts else f"• {', '.join(mixed_types)}"

        lbl_desc = QtWidgets.QLabel(
            f"{tr('mixed_dialog_warn')}\n\n"
            f"Tuvastatud andmed:\n{breakdown_text}"
        )
        lbl_desc.setWordWrap(True)
        lbl_desc.setStyleSheet("font-size: 9pt;")
        layout.addWidget(lbl_desc)

        # Option 1: Split all types into group (Recommended)
        btn_split = QtWidgets.QPushButton(f"★ {tr('btn_split_all')} ({len(mixed_types)} kihti grupis)")
        btn_split.setProperty("class", "SuccessButton")
        btn_split.setStyleSheet("font-weight: 700; padding: 8px; font-size: 9.5pt;")
        btn_split.clicked.connect(lambda: dlg.done(1))
        layout.addWidget(btn_split)

        # Option 2: Only Polygons
        if poly_c > 0 or "Polygon" in mixed_types:
            btn_p = QtWidgets.QPushButton(f"{tr('btn_open_poly')} ({poly_c:,})" if poly_c else tr('btn_open_poly'))
            btn_p.setStyleSheet("padding: 6px; font-size: 9pt;")
            btn_p.clicked.connect(lambda: dlg.done(2))
            layout.addWidget(btn_p)

        # Option 3: Only Points
        if pt_c > 0 or "Point" in mixed_types:
            btn_pt = QtWidgets.QPushButton(f"{tr('btn_open_points')} ({pt_c:,})" if pt_c else tr('btn_open_points'))
            btn_pt.setStyleSheet("padding: 6px; font-size: 9pt;")
            btn_pt.clicked.connect(lambda: dlg.done(3))
            layout.addWidget(btn_pt)

        # Option 4: Only Lines
        if line_c > 0 or "LineString" in mixed_types:
            btn_l = QtWidgets.QPushButton(f"{tr('btn_open_lines')} ({line_c:,})" if line_c else tr('btn_open_lines'))
            btn_l.setStyleSheet("padding: 6px; font-size: 9pt;")
            btn_l.clicked.connect(lambda: dlg.done(4))
            layout.addWidget(btn_l)

        # Option 5: Cancel
        btn_cancel = QtWidgets.QPushButton("Loobu / Cancel")
        btn_cancel.setStyleSheet("padding: 6px; font-size: 9pt;")
        btn_cancel.clicked.connect(lambda: dlg.done(0))
        layout.addWidget(btn_cancel)

        res = dlg.exec()
        if res == 1:
            self._execute_add_layer(mode="split_all")
        elif res == 2:
            self._execute_add_layer(mode="single", geom_filter="Polygon")
        elif res == 3:
            self._execute_add_layer(mode="single", geom_filter="Point")
        elif res == 4:
            self._execute_add_layer(mode="single", geom_filter="LineString")

    def _execute_add_layer(self, mode="single", geom_filter=None):
        ok, msg = self.qgis_connector.add_layer_to_canvas(
            self.current_selected_layer,
            self.current_service_dict,
            geometry_filter=geom_filter,
            mode=mode
        )
        if ok:
            QtWidgets.QMessageBox.information(self, tr("success"), msg)
        else:
            QtWidgets.QMessageBox.warning(self, tr("warning"), msg)

    def _on_download_gpkg_clicked(self):
        """Downloads all features of the selected WFS layer into a local GeoPackage file with live progress feedback."""
        if not self.current_selected_layer or not self.current_service_dict:
            return

        l = self.current_selected_layer
        title = l.get("title", l.get("name", "layer"))
        clean_name = re.sub(r'[^a-zA-Z0-9_-]', '_', l.get("name", "layer"))

        proj = QgsProject.instance()
        default_dir = os.path.dirname(proj.fileName()) if proj.fileName() else os.path.expanduser("~/Documents")
        default_file = os.path.join(default_dir, f"{clean_name}.gpkg")

        target_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            tr("dlg_downloading_gpkg"),
            default_file,
            "GeoPackage (*.gpkg)"
        )
        if not target_path:
            return

        if not target_path.lower().endswith(".gpkg"):
            target_path += ".gpkg"

        progress_dlg = QtWidgets.QProgressDialog(
            tr("dlg_downloading_features", name=title),
            tr("cancel"),
            0, 100,
            self
        )
        progress_dlg.setWindowTitle(tr("dlg_downloading_gpkg"))
        progress_dlg.setWindowModality(QtCore.Qt.WindowModality.WindowModal if hasattr(QtCore.Qt, "WindowModality") else QtCore.Qt.WindowModal)
        progress_dlg.setMinimumDuration(0)
        progress_dlg.setValue(5)

        feedback = QgsFeedback()
        def on_prog(p):
            progress_dlg.setValue(int(p))
            QtWidgets.QApplication.processEvents()

        feedback.progressChanged.connect(on_prog)
        progress_dlg.canceled.connect(feedback.cancel)

        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.CursorShape.WaitCursor if hasattr(QtCore.Qt, "CursorShape") else QtCore.Qt.WaitCursor)
        try:
            ok, msg, count = self.qgis_connector.download_wfs_to_gpkg(
                l, self.current_service_dict, target_path, feedback=feedback
            )
            progress_dlg.close()
            if ok:
                QtWidgets.QMessageBox.information(self, tr("success"), msg)
            else:
                QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
            progress_dlg.close()

    def _on_add_to_profile_clicked(self):
        if not self.current_service_dict or not self.current_selected_layer:
            return
        active_prof = self.profile_manager.get_active_profile()
        if not active_prof:
            QtWidgets.QMessageBox.warning(self, tr("warning"), "Aktiivset profiili pole leitud.")
            return

        l = self.current_selected_layer
        l_title = l.get("title") or l.get("name", "Kiht")
        mixed_groups = self.profile_manager.get_mixed_groups(active_prof["id"])

        if mixed_groups:
            # Show popup menu to let user choose target
            menu = QtWidgets.QMenu(self)
            act_svc = menu.addAction(f"➕ Lisa teenusena profiili: {self.current_service_dict.get('name', 'Teenus')}")
            menu.addSeparator()
            grp_actions = {}
            for g in mixed_groups:
                act = menu.addAction(f"📁 Lisa gruppi: {g.get('name')}")
                grp_actions[act] = g
            menu.addSeparator()
            act_new = menu.addAction(f"📁 + {tr('dialog_new_group_title')}...")

            # Show menu below button
            action = menu.exec(self.btn_add_prof.mapToGlobal(QtCore.QPoint(0, self.btn_add_prof.height())))
            if not action:
                return

            if action in grp_actions:
                target_g = grp_actions[action]
                ok, status, _ = self.profile_manager.add_layer_to_mixed_group(
                    active_prof["id"], target_g["id"], l, self.current_service_dict
                )
                if ok:
                    QtWidgets.QMessageBox.information(
                        self, tr("success"),
                        tr("msg_layer_added_to_group", layer=l_title, group=target_g.get("name"))
                    )
                else:
                    if status == "duplicate":
                        QtWidgets.QMessageBox.warning(
                            self, tr("warning"),
                            tr("msg_layer_already_in_group", layer=l_title, group=target_g.get("name"))
                        )
                return
            elif action == act_new:
                text, ok = QtWidgets.QInputDialog.getText(
                    self, tr("dialog_new_group_title"), tr("dialog_new_group_prompt")
                )
                if ok and text.strip():
                    new_g = self.profile_manager.create_mixed_group(active_prof["id"], text.strip())
                    if new_g:
                        self.profile_manager.add_layer_to_mixed_group(
                            active_prof["id"], new_g["id"], l, self.current_service_dict
                        )
                        QtWidgets.QMessageBox.information(
                            self, tr("success"),
                            tr("msg_layer_added_to_group", layer=l_title, group=new_g.get("name"))
                        )
                return

        # Default action: Add as service to profile
        ok, status, svc, layer = self.profile_manager.add_layer_or_service_to_profile(
            active_prof["id"], layer_dict=l, service_dict=self.current_service_dict
        )
        svc_title = (svc or self.current_service_dict).get("name", "Teenus")
        prof_name = active_prof.get("name", "")

        if status == "layer_exists":
            QtWidgets.QMessageBox.information(
                self, tr("notice"),
                f"Teenus '{svc_title}' on juba profiilis olemas ja kiht '{l_title}' sisaldub selles juba!"
            )
        elif status == "layer_added_to_existing":
            self.addToProfileRequested.emit(svc)
            QtWidgets.QMessageBox.information(
                self, tr("notice"),
                f"Teenus '{svc_title}' on juba profiilis olemas. Kiht '{l_title}' lisati selle teenuse alla."
            )
        elif status == "service_added":
            self.addToProfileRequested.emit(svc)
            QtWidgets.QMessageBox.information(
                self, tr("success"),
                f"Teenus '{svc_title}' ja kiht '{l_title}' lisati profiili '{prof_name}'!"
            )

    def _toggle_meta_card(self):
        """Collapses or expands bottom metadata tabs to maximize table vertical space."""
        visible = not self.meta_tabs.isVisible()
        self.meta_tabs.setVisible(visible)
        if hasattr(self, "mixed_box") and self.current_selected_layer and self.current_selected_layer.get("is_mixed"):
            self.mixed_box.setVisible(visible)
        self.btn_toggle_meta.setText("▾" if visible else "▸")

    def retranslate_ui(self):
        """Re-evaluates 100% of text strings dynamically in LayersWidget."""
        if hasattr(self, "btn_mode_single"):
            self.btn_mode_single.setText(tr("mode_single_service"))
        if hasattr(self, "btn_mode_global"):
            self.btn_mode_global.setText(tr("mode_global_search"))
        if hasattr(self, "btn_web_search"):
            self.btn_web_search.setText(tr("btn_web_search"))
        if self.mode == "global":
            self.filter_input.setPlaceholderText(tr("global_search_placeholder"))
        else:
            self.filter_input.setPlaceholderText(tr("layers_filter_placeholder"))

        self.lbl_svc.setText(f"<b>{tr('service_selector_label')}</b>")
        self.btn_refresh.setText(tr("btn_refresh_layers"))
        if self.service_combo.count() > 0 and self.service_combo.itemData(0) is None:
            self.service_combo.setItemText(0, tr("choose_service_prompt"))
        if not self.current_service_dict:
            self.status_pill.setText("")
            self.btn_refresh.setEnabled(False)
        else:
            self.status_pill.setText(tr("status_ready"))
            self.btn_refresh.setEnabled(True)
        self.lbl_loading.setText(tr("loading_layers_text"))

        # Table Headers
        self.tree.setHeaderLabels([
            tr("col_layer_title"),
            tr("col_geom_type"),
            tr("col_owner"),
            tr("col_renewed"),
            tr("col_updated"),
            tr("col_paging"),
            tr("col_crs"),
            tr("col_actions")
        ])

        # Bottom Card
        self.badge_card_title.setText(f"📋 {tr('card_overview_badge')}")
        if not self.current_selected_layer:
            self.lbl_layer_name.setText(tr("no_layer_selected"))
        self.btn_add_canvas.setText(tr("btn_add_to_canvas"))
        self.btn_add_prof.setText(tr("btn_add_to_profile"))

        self.lbl_mixed_warn.setText(tr("mixed_geom_detected_title"))
        self.lbl_mixed_sub.setText(tr("mixed_geom_desc"))
        self.btn_poly.setText(tr("btn_open_poly"))
        self.btn_line.setText(tr("btn_open_lines"))
        self.btn_point.setText(tr("btn_open_points"))
        self.btn_split_all.setText(tr("btn_split_all"))
        self.btn_rule.setText(tr("btn_open_rule_based"))

        self.lbl_head_abstract.setText(f"<b>{tr('meta_abstract')}</b>")
        self.lbl_head_bbox.setText(f"<b>{tr('meta_bbox')}</b>")
        self.lbl_head_paging.setText(f"<b>{tr('meta_paging')}</b>")
        self.lbl_head_owner.setText(f"<b>{tr('meta_owner')}</b>")
        self.lbl_head_freq.setText(f"<b>{tr('meta_frequency')}</b>")
        self.lbl_head_updated.setText(f"<b>{tr('meta_updated')}</b>")
        self.lbl_head_crs.setText(f"<b>{tr('meta_crs')}</b>")

        self.meta_tabs.setTabText(0, tr("tab_overview"))
        self.meta_tabs.setTabText(1, tr("tab_fields"))
        self.fields_table.setHorizontalHeaderLabels([tr("col_field_name"), tr("col_field_type")])

        self.hint_lbl.setText(tr("btn_drag_hint"))

        # Re-populate rows to refresh text (Jah/Yes, etc.)
        if self.current_layers:
            self._populate_layers_tree(self.current_layers)
