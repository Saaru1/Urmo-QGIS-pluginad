# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Custom Service Dialog
Allows users to add private or non-public services with custom authentication and headers.
"""

from qgis.PyQt import QtWidgets, QtCore
from ...compat import (
    AlignLeft, AlignVCenter, exec_dialog, DialogAccepted, DialogRejected
)
from ...i18n import tr


class CustomServiceDialog(QtWidgets.QDialog):
    """Dialog for configuring custom/private geospatial endpoints."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("btn_add_custom_url"))
        self.resize(550, 480)
        self._init_ui()

    def _init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        # Title
        title_lbl = QtWidgets.QLabel(tr("btn_add_custom_url"))
        title_lbl.setStyleSheet("font-size: 12pt; font-weight: 700;")
        layout.addWidget(title_lbl)

        # Form Layout
        form = QtWidgets.QFormLayout()
        form.setLabelAlignment(AlignLeft | AlignVCenter)
        form.setSpacing(10)

        # Service Name
        self.name_edit = QtWidgets.QLineEdit()
        self.name_edit.setPlaceholderText("nt Minu Sisevõrgu WFS või Ettevõtte Kaart...")
        form.addRow("Teenuse nimi:", self.name_edit)

        # Protocol
        self.type_combo = QtWidgets.QComboBox()
        self.type_combo.addItems(["WFS", "WMS", "WCS", "WMTS", "XYZ", "AUTO"])
        form.addRow(tr("service_type_label"), self.type_combo)

        # URL
        self.url_edit = QtWidgets.QLineEdit()
        self.url_edit.setPlaceholderText("https://server.domain.ee/geoserver/ows...")
        form.addRow(tr("url_label"), self.url_edit)

        # Category
        self.cat_combo = QtWidgets.QComboBox()
        self.cat_combo.addItem(tr("cat_custom"), "custom")
        self.cat_combo.addItem(tr("cat_base"), "base")
        self.cat_combo.addItem(tr("cat_cadastre"), "cadastre")
        self.cat_combo.addItem(tr("cat_env"), "env")
        self.cat_combo.addItem(tr("cat_planning"), "planning")
        form.addRow(tr("filter_category"), self.cat_combo)

        # Description
        self.desc_edit = QtWidgets.QLineEdit()
        self.desc_edit.setPlaceholderText("Märkmed või kirjeldus teenuse kohta...")
        form.addRow("Kirjeldus:", self.desc_edit)

        layout.addLayout(form)

        # Auth Box
        auth_group = QtWidgets.QGroupBox(tr("auth_options_header"))
        auth_layout = QtWidgets.QVBoxLayout(auth_group)
        auth_layout.setSpacing(8)

        self.auth_none_radio = QtWidgets.QRadioButton(tr("auth_none"))
        self.auth_basic_radio = QtWidgets.QRadioButton(tr("auth_basic"))
        self.auth_token_radio = QtWidgets.QRadioButton(tr("auth_token"))
        self.auth_qgis_radio = QtWidgets.QRadioButton(tr("auth_qgis_cfg"))

        self.auth_none_radio.setChecked(True)

        auth_layout.addWidget(self.auth_none_radio)
        auth_layout.addWidget(self.auth_basic_radio)
        auth_layout.addWidget(self.auth_token_radio)
        auth_layout.addWidget(self.auth_qgis_radio)

        # Auth sub-forms
        self.auth_stack = QtWidgets.QStackedWidget()

        # 0: None
        w_none = QtWidgets.QWidget()
        self.auth_stack.addWidget(w_none)

        # 1: Basic
        w_basic = QtWidgets.QWidget()
        f_basic = QtWidgets.QFormLayout(w_basic)
        self.user_edit = QtWidgets.QLineEdit()
        self.pass_edit = QtWidgets.QLineEdit()
        self.pass_edit.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password if hasattr(QtWidgets.QLineEdit, "EchoMode") else QtWidgets.QLineEdit.Password)
        f_basic.addRow(tr("username"), self.user_edit)
        f_basic.addRow(tr("password"), self.pass_edit)
        self.auth_stack.addWidget(w_basic)

        # 2: Token / API Key
        w_token = QtWidgets.QWidget()
        f_token = QtWidgets.QFormLayout(w_token)
        self.header_name_edit = QtWidgets.QLineEdit("Authorization")
        self.header_val_edit = QtWidgets.QLineEdit()
        self.header_val_edit.setPlaceholderText("Bearer xyz123... või api-key-väärtus")
        f_token.addRow(tr("token_header"), self.header_name_edit)
        f_token.addRow(tr("token_value"), self.header_val_edit)
        self.auth_stack.addWidget(w_token)

        # 3: QGIS AuthCfg
        w_qgis = QtWidgets.QWidget()
        f_qgis = QtWidgets.QFormLayout(w_qgis)

        self.authcfg_combo = QtWidgets.QComboBox()
        self.authcfg_combo.addItem("-- Vali olemasolev QGIS Auth konfiguratsioon --", "")
        try:
            from qgis.core import QgsApplication
            auth_mgr = QgsApplication.authManager()
            if auth_mgr:
                for cid in auth_mgr.configIds():
                    c_name = auth_mgr.configName(cid) or cid
                    self.authcfg_combo.addItem(f"{cid} - {c_name}", cid)
        except Exception:
            pass

        self.authcfg_combo.currentIndexChanged.connect(self._on_authcfg_combo_changed)
        f_qgis.addRow("Salvestatud AuthCfg:", self.authcfg_combo)

        self.authcfg_edit = QtWidgets.QLineEdit()
        self.authcfg_edit.setPlaceholderText("nt a1b2c3d")
        f_qgis.addRow(tr("authcfg_code"), self.authcfg_edit)
        self.auth_stack.addWidget(w_qgis)

        auth_layout.addWidget(self.auth_stack)
        layout.addWidget(auth_group)

        # Connect radios to stack
        self.auth_none_radio.toggled.connect(lambda: self.auth_stack.setCurrentIndex(0))
        self.auth_basic_radio.toggled.connect(lambda: self.auth_stack.setCurrentIndex(1))
        self.auth_token_radio.toggled.connect(lambda: self.auth_stack.setCurrentIndex(2))
        self.auth_qgis_radio.toggled.connect(lambda: self.auth_stack.setCurrentIndex(3))

        # Buttons
        btn_box = QtWidgets.QHBoxLayout()
        btn_box.addStretch()

        self.btn_cancel = QtWidgets.QPushButton(tr("btn_cancel"))
        self.btn_cancel.clicked.connect(self.reject)
        btn_box.addWidget(self.btn_cancel)

        self.btn_save = QtWidgets.QPushButton(tr("btn_ok"))
        self.btn_save.setProperty("class", "PrimaryButton")
        self.btn_save.clicked.connect(self._validate_and_accept)
        btn_box.addWidget(self.btn_save)

        layout.addLayout(btn_box)

    def _on_authcfg_combo_changed(self, idx):
        val = self.authcfg_combo.currentData()
        if val:
            self.authcfg_edit.setText(val)

    def _validate_and_accept(self):
        url = self.url_edit.text().strip()
        name = self.name_edit.text().strip()
        if not url:
            QtWidgets.QMessageBox.warning(self, tr("warning"), "Palun sisesta teenuse URL aadress.")
            return
        if not name:
            self.name_edit.setText("Minu Teenus")
        self.accept()

    def get_service_data(self):
        """Returns structured dictionary of entered service."""
        auth_type = "none"
        auth_params = {}

        if self.auth_basic_radio.isChecked():
            auth_type = "basic"
            auth_params = {
                "username": self.user_edit.text().strip(),
                "password": self.pass_edit.text()
            }
        elif self.auth_token_radio.isChecked():
            auth_type = "token"
            auth_params = {
                "header_name": self.header_name_edit.text().strip(),
                "header_val": self.header_val_edit.text().strip()
            }
        elif self.auth_qgis_radio.isChecked():
            auth_type = "authcfg"
            auth_params = {
                "authcfg": self.authcfg_edit.text().strip()
            }

        name = self.name_edit.text().strip() or "Custom Service"
        stype = self.type_combo.currentText()

        return {
            "name": name,
            "title_en": name,
            "service_type": stype,
            "url": self.url_edit.text().strip(),
            "category": self.cat_combo.currentData() or "custom",
            "description": self.desc_edit.text().strip() or "Kasutaja lisatud ruumiandmeteenus.",
            "description_en": self.desc_edit.text().strip() or "User configured geospatial service.",
            "auth_type": auth_type,
            "auth_params": auth_params,
            "preferred_settings": {
                "paging-enabled": True if stype == "WFS" else False,
                "page-size": 1000 if stype == "WFS" else 0,
                "dpi-mode": 7 if stype in ("WMS", "WMTS") else 0
            }
        }
