# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Profile Builder & Manager Widget
Accepts drag-and-drop layers/services from the Layers Panel, supports profile switching,
QGIS connection synchronization, and standard QGIS XML / JSON sharing.
Includes full dynamic EST/ENG translation.
"""

import os
import json
import xml.etree.ElementTree as ET
from qgis.PyQt import QtWidgets, QtCore, QtGui
from ...compat import (
    AlignLeft, AlignVCenter, AlignCenter,
    ItemIsEnabled, ItemIsSelectable, ItemIsDropEnabled,
    ResizeStretch, ResizeToContents, ResizeInteractive,
    set_header_resize_mode
)
from ...i18n import tr, get_language
from ...presets import get_all_presets
from ...profile_manager import get_profile_name
from ...service_tester import ServiceTester
from ...styles import get_current_theme
from .service_info_dialog import ServiceInfoDialog
from .catalog_widget import normalize_service_url


class ProfileExpandWorker(QtCore.QThread):
    """Background worker for dynamically fetching service layers on triangle expansion."""
    progress = QtCore.pyqtSignal(int, str)
    finished = QtCore.pyqtSignal(dict)
    error = QtCore.pyqtSignal(str)

    def __init__(self, tester, service_dict, parent=None):
        super().__init__(parent)
        self.tester = tester
        self.service_dict = service_dict

    def run(self):
        try:
            def on_progress(pct, msg):
                self.progress.emit(pct, msg)

            url = self.service_dict.get("url", "")
            stype = self.service_dict.get("service_type", "AUTO")
            auth_type = self.service_dict.get("auth_type", "none")
            auth_params = self.service_dict.get("auth_params", {})
            res = self.tester.inspect_service(
                url,
                service_type=stype,
                auth_type=auth_type,
                auth_params=auth_params,
                progress_callback=on_progress
            )
            self.finished.emit(res)
        except Exception as e:
            self.error.emit(str(e))


class SuggestNameDialog(QtWidgets.QDialog):
    """Dialog for suggesting official service names based on presets and server metadata."""

    def __init__(self, service_dict, profile_manager, tester, parent=None):
        super().__init__(parent)
        self.service_dict = service_dict
        self.profile_manager = profile_manager
        self.tester = tester
        self.selected_name = service_dict.get("name", "")

        self.setWindowTitle(tr("dialog_suggest_name_title"))
        self.resize(540, 390)
        self._init_ui()
        self._load_suggestions()

    def _init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Header info
        lbl_head = QtWidgets.QLabel(f"<b>{tr('dialog_suggest_name_title')}</b>")
        lbl_head.setStyleSheet("font-size: 11pt; color: #38bdf8;")
        layout.addWidget(lbl_head)

        lbl_prompt = QtWidgets.QLabel(tr("suggest_dialog_prompt"))
        lbl_prompt.setStyleSheet("color: #64748b; font-size: 8.5pt;")
        layout.addWidget(lbl_prompt)

        # Current name info
        cur_name = self.service_dict.get("name", "")
        lbl_cur = QtWidgets.QLabel(f"Praegune nimi: <b>{cur_name}</b>")
        layout.addWidget(lbl_cur)

        # Suggestions list
        self.list_widget = QtWidgets.QListWidget()
        self.list_widget.setStyleSheet("font-size: 9pt;")
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        self.list_widget.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self.list_widget, stretch=1)

        # Chosen name edit
        edit_layout = QtWidgets.QHBoxLayout()
        lbl_new = QtWidgets.QLabel(tr("rename_dialog_label"))
        lbl_new.setStyleSheet("font-weight: 600;")
        edit_layout.addWidget(lbl_new)
        self.name_edit = QtWidgets.QLineEdit()
        self.name_edit.setText(cur_name)
        edit_layout.addWidget(self.name_edit, stretch=1)
        layout.addLayout(edit_layout)

        # Buttons
        btn_box = QtWidgets.QHBoxLayout()
        btn_box.addStretch()

        self.btn_cancel = QtWidgets.QPushButton(tr("btn_cancel") if "btn_cancel" in tr("btn_cancel") else "Loobu")
        self.btn_cancel.clicked.connect(self.reject)
        btn_box.addWidget(self.btn_cancel)

        self.btn_apply = QtWidgets.QPushButton(tr("btn_apply_name"))
        self.btn_apply.setProperty("class", "PrimaryButton")
        self.btn_apply.setStyleSheet("font-weight: 700;")
        self.btn_apply.clicked.connect(self._on_apply)
        btn_box.addWidget(self.btn_apply)

        layout.addLayout(btn_box)

    def _load_suggestions(self):
        url = self.service_dict.get("url", "").strip()
        stype = self.service_dict.get("service_type", "WFS")
        suggestions = []
        seen = set()

        def add_sug(source_tag, val):
            if val and val.strip() and val.strip() not in seen:
                clean = " ".join(val.strip().split())
                seen.add(clean)
                suggestions.append((source_tag, clean))

        # 1. Preset matching
        norm_u = normalize_service_url(url)
        for p in get_all_presets():
            if normalize_service_url(p.get("url", "")) == norm_u:
                add_sug(tr("suggest_source_preset"), p.get("name"))
                if p.get("title_en"):
                    add_sug(f"{tr('suggest_source_preset')} (ENG)", p.get("title_en"))
                break

        # 2. Server GetCapabilities query
        try:
            sep = "&" if "?" in url else "?"
            st = "WFS" if "wfs" in url.lower() else ("WCS" if "wcs" in url.lower() else "WMS")
            ver_param = "&version=1.0.0" if st == "WCS" else ""
            cap_url = f"{url}{sep}service={st}&request=GetCapabilities{ver_param}"
            data, _, _, _, _ = self.tester.fetch_url(cap_url, self.service_dict.get("auth_type", "none"), self.service_dict.get("auth_params", {}))
            if data:
                root = ET.fromstring(data)
                title = (
                    root.findtext(".//{http://www.opengis.net/ows/1.1}Title")
                    or root.findtext(".//{http://www.opengis.net/ows}Title")
                    or root.findtext(".//{http://www.opengis.net/wms}Title")
                    or root.findtext(".//Title")
                    or root.findtext(".//Service/Title")
                    or root.findtext(".//{http://www.opengis.net/wcs}label")
                    or root.findtext(".//label")
                )
                if title:
                    add_sug(tr("suggest_source_server"), title)
                prov = (
                    root.findtext(".//{http://www.opengis.net/ows/1.1}ProviderName")
                    or root.findtext(".//{http://www.opengis.net/ows}ProviderName")
                    or root.findtext(".//ContactOrganization")
                )
                if prov and title and prov.strip() not in title:
                    add_sug(f"{tr('suggest_source_server')} (Asutusega)", f"{prov.strip()}: {title.strip()}")
        except Exception:
            pass

        # 3. Clean fallback heuristics from URL keywords
        u_low = url.lower()
        if "kataster" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: Katastriüksused (WFS)")
        elif "haldusjaotus" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: Haldus- ja asustusjaotus (WFS)")
        elif "etak" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: ETAK Eesti Topograafia (WFS)")
        elif "eelis" in u_low or "keskkonnaportaal" in u_low:
            add_sug("Soovitus", "Keskkonnaagentuur: EELIS Kaitstavad Loodusobjektid (WFS)")
        elif "pria" in u_low:
            add_sug("Soovitus", "PRIA: Põllumassiivid ja toetused (WFS)")
        elif "metsaregister" in u_low:
            add_sug("Soovitus", "Keskkonnaagentuur: Metsaregister (WFS)")
        elif "kitsendused" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: Kitsenduste kaart (WFS)")
        elif "muinas" in u_low or "muinsus" in u_low:
            add_sug("Soovitus", "Muinsuskaitseamet: Kultuurimälestiste register (WFS)")
        elif "aadress" in u_low or "ads" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: Aadressiandmed (WMS / WFS)")
        elif "planeering" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: Planeeringud (WFS)")
        elif "dtm" in u_low or "korgus" in u_low:
            add_sug("Soovitus", "Maa- ja Ruumiamet: Kõrgusmudel (WCS DTM)")

        for tag, name_val in suggestions:
            item = QtWidgets.QListWidgetItem(f"[{tag}]  {name_val}")
            item.setData(QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, name_val)
            self.list_widget.addItem(item)

        if suggestions:
            self.name_edit.setText(suggestions[0][1])
            self.list_widget.setCurrentRow(0)

    def _on_item_clicked(self, item):
        val = item.data(QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if val:
            self.name_edit.setText(val)

    def _on_item_double_clicked(self, item):
        self._on_item_clicked(item)
        self._on_apply()

    def _on_apply(self):
        val = self.name_edit.text().strip()
        if val:
            self.selected_name = val
            self.accept()
        else:
            self.reject()


class DroppableProfileTree(QtWidgets.QTreeWidget):
    """Tree widget capable of receiving dropped layers/services AND dragging items out."""

    itemDropped = QtCore.pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setDragEnabled(True)
        self.setDropIndicatorShown(True)
        self.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection if hasattr(QtWidgets.QAbstractItemView, "SelectionMode") else QtWidgets.QAbstractItemView.SingleSelection)

    def startDrag(self, supportedActions):
        """Allows dragging services and layers out of the Profile tree."""
        item = self.currentItem()
        if not item:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if not data or data in ("__placeholder__", "__group__"):
            return

        payload = None
        if isinstance(data, dict):
            payload = {"type": "service", "service": data}
        elif isinstance(data, tuple) and len(data) >= 2:
            payload = {"type": "layer", "layer": data[0], "service": data[1]}

        if payload:
            drag = QtGui.QDrag(self)
            mime = QtCore.QMimeData()
            raw_json = json.dumps(payload)
            mime.setData("application/x-geoprofile-service", QtCore.QByteArray(raw_json.encode("utf-8")))
            mime.setData("application/x-geoprofile-item", QtCore.QByteArray(raw_json.encode("utf-8")))
            mime.setText(item.text(0))
            drag.setMimeData(mime)
            drag.exec(QtCore.Qt.DropAction.CopyAction if hasattr(QtCore.Qt, "DropAction") else QtCore.Qt.CopyAction)

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat("application/x-geoprofile-item") or event.mimeData().hasFormat("application/x-geoprofile-service") or event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat("application/x-geoprofile-item") or event.mimeData().hasFormat("application/x-geoprofile-service") or event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        mime = event.mimeData()
        payload = None

        for fmt in ("application/x-geoprofile-item", "application/x-geoprofile-service"):
            if mime.hasFormat(fmt):
                try:
                    raw_bytes = mime.data(fmt)
                    payload = json.loads(bytes(raw_bytes).decode("utf-8"))
                    break
                except Exception:
                    pass

        if payload:
            if hasattr(event, "position"):
                p = event.position()
                drop_pos = p.toPoint() if hasattr(p, "toPoint") else QtCore.QPoint(int(p.x()), int(p.y()))
            elif hasattr(event, "pos"):
                drop_pos = event.pos()
            else:
                drop_pos = QtCore.QPoint()
            target_item = self.itemAt(drop_pos)
            if target_item:
                data = target_item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
                if isinstance(data, dict) and data.get("service_type") == "MIXED":
                    payload["target_mixed_group_id"] = data.get("id")
                    payload["target_mixed_group_name"] = data.get("name")
                elif isinstance(data, tuple) and len(data) >= 2:
                    parent_item = target_item.parent()
                    if parent_item:
                        p_data = parent_item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
                        if isinstance(p_data, dict) and p_data.get("service_type") == "MIXED":
                            payload["target_mixed_group_id"] = p_data.get("id")
                            payload["target_mixed_group_name"] = p_data.get("name")

            self.itemDropped.emit(payload)
            event.acceptProposedAction()
        else:
            event.ignore()


class ProfileWidget(QtWidgets.QWidget):
    """Profile builder and manager coordinating drag-and-drop layer collections."""

    profileApplied = QtCore.pyqtSignal(str, int)
    testServiceRequested = QtCore.pyqtSignal(dict)
    inspectServiceRequested = QtCore.pyqtSignal(dict)
    addLayerToCanvasRequested = QtCore.pyqtSignal(dict, dict)

    def __init__(self, profile_manager, qgis_connector, parent=None):
        super().__init__(parent)
        self.profile_manager = profile_manager
        self.qgis_connector = qgis_connector
        self.tester = ServiceTester(timeout=10)
        self.current_profile = None
        self.expand_workers = {}
        self._init_ui()
        self.refresh_profiles()
        # Launch background preloader for any un-cached services
        try:
            from ...preloader import CatalogPreloader
            CatalogPreloader.preload_all(self.profile_manager, callback=self._on_preloader_service_loaded)
        except Exception:
            pass

    def _init_ui(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(6)

        # -------------------------------------------------------------
        # 1. Profile Switcher & Actions Header
        # -------------------------------------------------------------
        header_card = QtWidgets.QFrame()
        header_card.setProperty("class", "CardFrame")
        h_layout = QtWidgets.QVBoxLayout(header_card)
        h_layout.setContentsMargins(8, 6, 8, 6)
        h_layout.setSpacing(5)

        # Row 1: Profile Selector + New + Rename + Delete
        row1 = QtWidgets.QHBoxLayout()
        row1.setSpacing(6)

        self.lbl_prof = QtWidgets.QLabel(f"<b>{tr('select_profile')}</b>")
        row1.addWidget(self.lbl_prof)

        self.prof_combo = QtWidgets.QComboBox()
        self.prof_combo.setToolTip("Klõpsa siia, et avada rippmenüü (nimekiri) ja valida teine ühenduste profiil")
        self.prof_combo.currentIndexChanged.connect(self._on_combo_profile_changed)
        row1.addWidget(self.prof_combo, stretch=2)

        self.btn_new = QtWidgets.QPushButton(tr("btn_new_profile"))
        self.btn_new.setToolTip("Loo uus tühi ühenduste profiil")
        self.btn_new.clicked.connect(self._on_create_profile)
        row1.addWidget(self.btn_new)

        self.btn_new_group = QtWidgets.QPushButton(f"📁 {tr('btn_new_group')}")
        self.btn_new_group.setToolTip(tr("btn_new_group_tooltip"))
        self.btn_new_group.clicked.connect(self._on_create_mixed_group)
        row1.addWidget(self.btn_new_group)

        self.btn_rename_prof = QtWidgets.QPushButton(tr("menu_rename"))
        self.btn_rename_prof.setToolTip("Nimeta aktiivne profiil või valitud teenus ümber")
        self.btn_rename_prof.clicked.connect(lambda: self._on_rename_service())
        row1.addWidget(self.btn_rename_prof)

        self.btn_delete = QtWidgets.QPushButton(tr("btn_delete_profile"))
        self.btn_delete.setProperty("class", "DangerButton")
        self.btn_delete.setToolTip("Kustuta aktiivne profiil")
        self.btn_delete.clicked.connect(self._on_delete_profile)
        row1.addWidget(self.btn_delete)

        h_layout.addLayout(row1)

        # Row 2: Prominent Full-Width Apply Button
        row2 = QtWidgets.QHBoxLayout()
        row2.setSpacing(6)

        self.btn_apply = QtWidgets.QPushButton(tr("btn_apply_to_qgis"))
        self.btn_apply.setProperty("class", "SuccessButton")
        self.btn_apply.setStyleSheet("font-weight: 700; padding: 7px 12px; font-size: 9.5pt;")
        self.btn_apply.setToolTip("Salvesta ja rakenda selle profiili teenused QGIS-i ühendustesse ning uuenda brauser")
        self.btn_apply.clicked.connect(self._on_apply_clicked)
        row2.addWidget(self.btn_apply)
        h_layout.addLayout(row2)

        # Row 3: Secondary tools (Sync, Export, Import, Share)
        row3 = QtWidgets.QHBoxLayout()
        row3.setSpacing(6)

        self.btn_sync_qgis = QtWidgets.QPushButton(tr("btn_sync_from_qgis"))
        self.btn_sync_qgis.setToolTip("Loeb QGIS Browseri ühenduste hetkeseisu ja sünkroonib aktiivse profiiliga")
        self.btn_sync_qgis.clicked.connect(self._on_sync_from_qgis)
        row3.addWidget(self.btn_sync_qgis)

        self.btn_export_xml = QtWidgets.QPushButton(tr("btn_export_xml"))
        self.btn_export_xml.setToolTip("Ekspordi profiili teenused standardse QGIS XML-failina jagamiseks")
        self.btn_export_xml.clicked.connect(self._on_export_xml)
        row3.addWidget(self.btn_export_xml)

        self.btn_import = QtWidgets.QPushButton(tr("btn_import_profile"))
        self.btn_import.setToolTip("Impordi profiil või teenused failist (JSON või QGIS XML)")
        self.btn_import.clicked.connect(self._on_import_profile)
        row3.addWidget(self.btn_import)

        self.btn_share = QtWidgets.QPushButton(tr("btn_share_profile"))
        self.btn_share.setToolTip("Kopeeri profiil või ühenduste nimekiri lõikelauale")
        self.btn_share.clicked.connect(self._on_share_profile)
        row3.addWidget(self.btn_share)

        h_layout.addLayout(row3)
        main_layout.addWidget(header_card)

        # -------------------------------------------------------------
        # 2. Droppable Profile Tree
        # -------------------------------------------------------------
        self.tree = DroppableProfileTree(self)
        self.tree.setSortingEnabled(True)
        self.tree.setHeaderLabels([
            tr("col_prof_service"),
            tr("col_prof_type"),
            tr("col_prof_settings")
        ])
        t_hdr = self.tree.header()
        set_header_resize_mode(t_hdr, 0, ResizeInteractive)
        set_header_resize_mode(t_hdr, 1, ResizeToContents)
        set_header_resize_mode(t_hdr, 2, ResizeInteractive)
        self.tree.setColumnWidth(0, 160)
        self.tree.setColumnWidth(1, 65)
        self.tree.setColumnWidth(2, 120)
        self.tree.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded if hasattr(QtCore.Qt, "ScrollBarPolicy") else QtCore.Qt.ScrollBarAsNeeded)
        self.tree.setMinimumWidth(100)
        self.setMinimumWidth(200)
        self.tree.itemDropped.connect(self._on_item_dropped)
        self.tree.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu if hasattr(QtCore.Qt, "ContextMenuPolicy") else QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)
        self.tree.itemDoubleClicked.connect(self._on_tree_double_clicked)
        self.tree.itemExpanded.connect(self._on_tree_item_expanded)
        main_layout.addWidget(self.tree, stretch=3)

        # -------------------------------------------------------------
        # 3. Bottom Tree Actions
        # -------------------------------------------------------------
        bottom_bar = QtWidgets.QHBoxLayout()
        bottom_bar.setSpacing(8)

        self.btn_remove = QtWidgets.QPushButton(tr("btn_remove_item"))
        self.btn_remove.setProperty("class", "DangerButton")
        self.btn_remove.setToolTip("Eemalda valitud teenus või kiht profiilist")
        self.btn_remove.clicked.connect(self._on_remove_item)
        bottom_bar.addWidget(self.btn_remove)

        self.btn_info = QtWidgets.QPushButton(f"ℹ️ {tr('menu_advanced_info')}")
        self.btn_info.setToolTip("Vaata valitud teenuse või kihi tehnilisi metaandmeid")
        self.btn_info.clicked.connect(self._on_info_btn_clicked)
        bottom_bar.addWidget(self.btn_info)

        self.btn_open_canvas = QtWidgets.QPushButton(tr("btn_add_to_canvas"))
        self.btn_open_canvas.setProperty("class", "PrimaryButton")
        self.btn_open_canvas.setToolTip("Ava valitud kiht otse QGIS-i kaardilõuendil")
        self.btn_open_canvas.clicked.connect(self._on_add_layer_canvas)
        bottom_bar.addWidget(self.btn_open_canvas)

        bottom_bar.addStretch()

        self.lbl_drop_hint = QtWidgets.QLabel(f"📥 {tr('profile_drop_zone_hint')}")
        self.lbl_drop_hint.setStyleSheet("color: #64748b; font-size: 8.5pt;")
        bottom_bar.addWidget(self.lbl_drop_hint)

        main_layout.addLayout(bottom_bar)

    def refresh_profiles(self):
        """Reloads profiles from profile manager into combo and tree."""
        profiles = self.profile_manager.get_profiles()
        active = self.profile_manager.get_active_profile()

        self.prof_combo.blockSignals(True)
        self.prof_combo.clear()
        target_idx = 0

        for idx, p in enumerate(profiles):
            is_active = active and (p.get("id") == active.get("id"))
            p_name = get_profile_name(p, get_language())
            label = f"★ {p_name}" if is_active else p_name
            self.prof_combo.addItem(label, p)
            if is_active:
                target_idx = idx

        self.prof_combo.blockSignals(False)

        if profiles:
            self.prof_combo.setCurrentIndex(target_idx)
            self.current_profile = profiles[target_idx]
            self._render_profile(self.current_profile)

    def _on_combo_profile_changed(self, index):
        if index < 0:
            return
        p = self.prof_combo.itemData(index)
        if p:
            self.current_profile = p
            self.profile_manager.set_active_profile(p["id"])
            self._render_profile(p)

    def _on_preloader_service_loaded(self, service_dict, layers):
        """Called by background preloader when an un-cached service finishes fetching."""
        if not self.current_profile or not layers:
            return
        s_url = service_dict.get("url")
        stype = service_dict.get("service_type")
        updated = False
        for s in self.current_profile.get("services", []):
            if s.get("service_type") == stype and (s.get("url") == s_url or s.get("name") == service_dict.get("name")):
                s["layers"] = layers
                updated = True
                break
        if updated:
            self._render_profile(self.current_profile)

    def _render_profile(self, p):
        """Populates the tree with services grouped by service type (Tüüp) to minimize clutter."""
        self.tree.setUpdatesEnabled(False)
        was_sorting = self.tree.isSortingEnabled()
        self.tree.setSortingEnabled(False)
        try:
            self.tree.clear()
            services = p.get("services", [])
            if not services:
                return

            # Group services by service_type
            groups = {}
            for s in services:
                stype = s.get("service_type", "WMS").upper()
                groups.setdefault(stype, []).append(s)

            standard_order = ["MIXED", "WFS", "WMS", "XYZ", "WCS", "WMTS", "OGC API", "ARCGIS"]
            sorted_types = sorted(groups.keys(), key=lambda t: (standard_order.index(t) if t in standard_order else 99, t))

            is_est = get_language() == "EST"

            for stype in sorted_types:
                group_services = groups[stype]
                count = len(group_services)

                # Create Group Header Item
                group_item = QtWidgets.QTreeWidgetItem(self.tree)
                if stype == "MIXED":
                    group_item.setText(0, f"📁 {tr('group_mixed_title')} ({count})")
                    group_item.setText(1, " MIXED ")
                    group_item.setText(2, f"{count} {'gruppi' if is_est else 'groups'}")
                    badge_color = "#d946ef"
                else:
                    group_item.setText(0, f"📁 {stype} ({count})")
                    group_item.setText(1, f" {stype} ")
                    group_item.setText(2, f"{count} {'teenust' if is_est else 'services'}")
                    badge_color = "#38bdf8" if stype == "WFS" else ("#fb923c" if stype == "WMS" else ("#a855f7" if stype == "XYZ" else ("#06b6d4" if stype == "WCS" else "#10b981")))

                group_item.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, "__group__")

                font = group_item.font(0)
                font.setBold(True)
                group_item.setFont(0, font)
                group_item.setFont(1, font)

                group_item.setForeground(0, QtGui.QBrush(QtGui.QColor(badge_color)))
                group_item.setForeground(1, QtGui.QBrush(QtGui.QColor(badge_color)))

                for s in group_services:
                    s_name = s.get("name", "Service")
                    s_url = s.get("url", "")
                    pref = s.get("preferred_settings", {})

                    svc_item = QtWidgets.QTreeWidgetItem(group_item)
                    if stype == "MIXED":
                        layers = s.get("layers", [])
                        svc_item.setText(0, f"📁 {s_name}")
                        svc_item.setText(1, " MIXED ")
                        svc_item.setText(2, f"{len(layers)} {'kihti' if is_est else 'layers'}")
                        svc_item.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, s)

                        f = svc_item.font(0)
                        f.setBold(True)
                        svc_item.setFont(0, f)
                        svc_item.setForeground(0, QtGui.QBrush(QtGui.QColor("#d946ef")))
                        svc_item.setForeground(1, QtGui.QBrush(QtGui.QColor("#d946ef")))

                        if layers:
                            for l in layers:
                                self._create_layer_child(svc_item, l, s)
                        else:
                            empty_item = QtWidgets.QTreeWidgetItem(svc_item)
                            empty_item.setText(0, f"  {tr('mixed_empty_hint')}")
                            empty_item.setForeground(0, QtGui.QBrush(QtGui.QColor("#94a3b8")))
                            empty_item.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, "__empty_mixed__")
                        svc_item.setExpanded(True)
                    else:
                        svc_item.setText(0, s_name)
                        svc_item.setText(1, f" {stype} ")

                        pref_str = f"URL: {s_url}"
                        if stype == "WFS":
                            p_en = pref.get("paging-enabled", True)
                            ps = pref.get("page-size", 1000)
                            pref_str += f" | Paging: {tr('yes_text') if p_en else tr('no_text')} ({ps})"
                        svc_item.setText(2, pref_str)
                        svc_item.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, s)

                        f = svc_item.font(0)
                        f.setBold(False)
                        svc_item.setFont(0, f)

                        layers = s.get("layers", [])
                        if not layers and stype not in ("MIXED", "XYZ"):
                            try:
                                from ...cache.layer_cache import get_layer_catalog_cache
                                c_layers = get_layer_catalog_cache().get_layers(stype, s_url)
                                if c_layers:
                                    s["layers"] = c_layers
                                    layers = c_layers
                            except Exception:
                                pass

                        if layers:
                            for l in layers:
                                self._create_layer_child(svc_item, l, s)
                        else:
                            # Add placeholder item so that the expansion arrow (>) is visible!
                            dummy = QtWidgets.QTreeWidgetItem(svc_item)
                            dummy.setText(0, f"  ⏳ {tr('expand_loading')}")
                            dummy.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, "__placeholder__")

                # Expand the group node by default so services are immediately visible
                group_item.setExpanded(True)
        finally:
            self.tree.setUpdatesEnabled(True)
            self.tree.setSortingEnabled(was_sorting)

    def _create_layer_child(self, parent_item, l, s):
        """Creates child tree item for an individual service layer."""
        child = QtWidgets.QTreeWidgetItem(parent_item)
        l_name = l.get("name", "")
        l_title = l.get("title", l_name)
        geom = l.get("geom_type", "Raster")
        is_mixed = l.get("is_mixed", False)

        child.setText(0, f"  └ {l_title}")
        child.setToolTip(0, f"{l_title}\n({l_name})")
        child.setText(1, f" {geom} ")

        if s.get("service_type") == "MIXED":
            origin_name = l.get("service_name") or l.get("service_type") or "OGC"
            child.setText(2, f"CRS: {l.get('default_crs', 'EPSG:3301')} | Allikas: {origin_name}")
        else:
            child.setText(2, f"Geom: {l.get('geom_col', '-')} | CRS: {l.get('default_crs', 'EPSG:3301')}")

        if is_mixed or "Mixed" in geom:
            child.setForeground(1, QtGui.QBrush(QtGui.QColor("#d946ef")))
            child.setFont(1, QtGui.QFont("", -1, QtGui.QFont.Weight.Bold if hasattr(QtGui.QFont, "Weight") else QtGui.QFont.Bold))
        elif "DTM" in geom or "Kõrgus" in geom:
            child.setForeground(1, QtGui.QBrush(QtGui.QColor("#06b6d4")))
            child.setFont(1, QtGui.QFont("", -1, QtGui.QFont.Weight.Bold if hasattr(QtGui.QFont, "Weight") else QtGui.QFont.Bold))
        elif "Poly" in geom:
            child.setForeground(1, QtGui.QBrush(QtGui.QColor("#38bdf8")))
        elif "Line" in geom:
            child.setForeground(1, QtGui.QBrush(QtGui.QColor("#fb923c")))
        elif "Point" in geom:
            child.setForeground(1, QtGui.QBrush(QtGui.QColor("#4ade80")))

        child.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, (l, s))
        return child

    def _on_tree_item_expanded(self, item):
        """Fetches layers dynamically when a service arrow is expanded for the first time."""
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if isinstance(data, dict):
            if data.get("service_type") == "MIXED":
                return
            if item.childCount() == 1:
                first_child = item.child(0)
                c_data = first_child.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
                if c_data == "__placeholder__":
                    self._expand_service_layers(item, data)

    def _expand_service_layers(self, item, service_dict):
        """Asynchronously queries layers for service with a non-blocking animated progress item."""
        url = service_dict.get("url")
        if not url:
            if item.childCount() > 0:
                item.takeChild(0)
            return

        svc_key = service_dict.get("id") or url
        if svc_key in self.expand_workers:
            return  # Already running

        # Locate placeholder dummy child item
        dummy = None
        if item.childCount() > 0:
            c = item.child(0)
            if c.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole) == "__placeholder__":
                dummy = c

        if not dummy:
            dummy = QtWidgets.QTreeWidgetItem(item)
            dummy.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, "__placeholder__")

        accent = "#0284c7" if get_current_theme() == "LIGHT" else "#38bdf8"
        dummy.setText(0, f"  ⏳ {tr('expand_loading')} (10%)...")
        dummy.setForeground(0, QtGui.QBrush(QtGui.QColor(accent)))

        tester = ServiceTester(timeout=10)
        worker = ProfileExpandWorker(tester, service_dict, self)

        def on_prog(pct, msg, d_item=dummy):
            try:
                d_item.setText(0, f"  ⏳ {tr('expand_loading')} ({pct}%)...")
            except Exception:
                pass

        def on_done(res, root_item=item, s_dict=service_dict, w_key=svc_key):
            try:
                if root_item.childCount() > 0:
                    first = root_item.child(0)
                    if first.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole) == "__placeholder__":
                        root_item.takeChild(0)

                if res.get("online") and res.get("layers"):
                    layers = res.get("layers")
                    s_dict["layers"] = layers
                    root_item.setData(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, s_dict)
                    if self.current_profile:
                        self.profile_manager.update_service_layers(
                            self.current_profile["id"], s_dict.get("id", ""), layers
                        )
                    # Instantly register into search index and persistent cache!
                    try:
                        from ...layer_index import get_layer_index
                        from ...cache.layer_cache import get_layer_catalog_cache
                        get_layer_index().register_service_layers(s_dict, layers)
                        get_layer_catalog_cache().set_layers(s_dict.get("service_type"), s_dict.get("url"), layers)
                    except Exception:
                        pass
                    self.tree.setUpdatesEnabled(False)
                    try:
                        for l in layers:
                            self._create_layer_child(root_item, l, s_dict)
                    finally:
                        self.tree.setUpdatesEnabled(True)
                else:
                    err_msg = res.get("error", "0 kihti leitud või viga")
                    err_item = QtWidgets.QTreeWidgetItem(root_item)
                    err_item.setText(0, f"  ❌ ({err_msg[:30]})")
                    err_item.setForeground(0, QtGui.QBrush(QtGui.QColor("#dc2626")))
            finally:
                self.expand_workers.pop(w_key, None)

        def on_err(err_text, root_item=item, w_key=svc_key):
            try:
                if root_item.childCount() > 0:
                    first = root_item.child(0)
                    if first.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole) == "__placeholder__":
                        root_item.takeChild(0)
                err_item = QtWidgets.QTreeWidgetItem(root_item)
                err_item.setText(0, f"  ❌ Viga: {err_text[:30]}")
                err_item.setForeground(0, QtGui.QBrush(QtGui.QColor("#dc2626")))
            finally:
                self.expand_workers.pop(w_key, None)

        worker.progress.connect(on_prog)
        worker.finished.connect(on_done)
        worker.error.connect(on_err)
        self.expand_workers[svc_key] = worker
        worker.start()

    def _show_context_menu(self, pos):
        """Displays rich right-click context menu for services and layers."""
        item = self.tree.itemAt(pos)
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole) if item else None

        if not item or not data or data in ("__placeholder__", "__group__", "__empty_mixed__"):
            menu = QtWidgets.QMenu(self)
            act_new_group = menu.addAction(f"📁 {tr('menu_new_mixed_group')}")
            action = menu.exec(self.tree.viewport().mapToGlobal(pos) if hasattr(self.tree, "viewport") else self.tree.mapToGlobal(pos))
            if action == act_new_group:
                self._on_create_mixed_group()
            return

        menu = QtWidgets.QMenu(self)

        if isinstance(data, dict):
            s = data
            if s.get("service_type") == "MIXED":
                layers = s.get("layers", [])
                act_open_all = menu.addAction(f"🗺️ {tr('btn_open_group_canvas')} ({len(layers)} kihti)")
                menu.addSeparator()
                act_rename = menu.addAction(f"✏️ {tr('menu_rename')}")
                act_remove = menu.addAction(f"🗑️ {tr('menu_remove')}")

                action = menu.exec(self.tree.viewport().mapToGlobal(pos) if hasattr(self.tree, "viewport") else self.tree.mapToGlobal(pos))
                if action == act_open_all:
                    ok, msg = self.qgis_connector.add_mixed_group_to_canvas(s)
                    if ok:
                        QtWidgets.QMessageBox.information(self, tr("success"), msg)
                    else:
                        QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
                elif action == act_rename:
                    self._on_rename_service(item)
                elif action == act_remove:
                    self._on_remove_item()
                return

            act_apply_single = menu.addAction(f"⚡ {tr('menu_apply_single_to_qgis')}")
            menu.addSeparator()
            act_inspect = menu.addAction(f"🔍 {tr('menu_inspect_layers')}")
            act_info = menu.addAction(f"ℹ️ {tr('menu_advanced_info')}")
            act_rename = menu.addAction(f"✏️ {tr('menu_rename')}")
            act_suggest = menu.addAction(f"💡 {tr('menu_suggest_name')}")
            menu.addSeparator()
            act_copy = menu.addAction(f"📋 {tr('btn_copy_url')}")
            menu.addSeparator()
            act_remove = menu.addAction(f"🗑️ {tr('menu_remove')}")

            action = menu.exec(self.tree.viewport().mapToGlobal(pos) if hasattr(self.tree, "viewport") else self.tree.mapToGlobal(pos))
            if action == act_apply_single:
                self._on_apply_single_service(s)
            elif action == act_inspect:
                self.inspectServiceRequested.emit(s)
            elif action == act_info:
                self._open_service_info_dialog(s)
            elif action == act_rename:
                self._on_rename_service(item)
            elif action == act_suggest:
                self._on_suggest_service_name(item, s)
            elif action == act_copy:
                clipboard = QtWidgets.QApplication.clipboard()
                clipboard.setText(s.get("url", ""))
                QtWidgets.QMessageBox.information(self, tr("notice"), f"URL kopeeritud:\n{s.get('url')}")
            elif action == act_remove:
                self._on_remove_item()

        elif isinstance(data, tuple) and len(data) >= 2:
            l, s = data
            if s.get("service_type") == "MIXED":
                act_open = menu.addAction(f"🗺️ {tr('btn_add_to_canvas')}")
                act_copy = menu.addAction(f"📋 {tr('menu_copy_layer_name')}")
                menu.addSeparator()
                act_remove_layer = menu.addAction(f"🗑️ {tr('menu_remove_from_group')}")

                action = menu.exec(self.tree.viewport().mapToGlobal(pos) if hasattr(self.tree, "viewport") else self.tree.mapToGlobal(pos))
                if action == act_open:
                    ok, msg = self.qgis_connector.add_layer_to_canvas(l, s)
                    if ok:
                        QtWidgets.QMessageBox.information(self, tr("success"), msg)
                    else:
                        QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
                elif action == act_copy:
                    clipboard = QtWidgets.QApplication.clipboard()
                    clipboard.setText(l.get("name", ""))
                    QtWidgets.QMessageBox.information(self, tr("notice"), f"Kihi nimi kopeeritud: {l.get('name')}")
                elif action == act_remove_layer:
                    self.profile_manager.remove_layer_from_mixed_group(self.current_profile["id"], s.get("id"), l.get("name"))
                    self._render_profile(self.current_profile)
                return

            act_open = menu.addAction(f"🗺️ {tr('btn_add_to_canvas')}")
            act_add_to_group = menu.addAction(f"📁 {tr('menu_add_to_mixed_group')}")
            act_inspect = menu.addAction(f"🔍 {tr('menu_inspect_layers')}")
            menu.addSeparator()
            act_copy = menu.addAction(f"📋 {tr('menu_copy_layer_name')}")
            menu.addSeparator()
            act_remove_layer = menu.addAction(f"🗑️ {tr('menu_remove_layer')}")

            action = menu.exec(self.tree.viewport().mapToGlobal(pos) if hasattr(self.tree, "viewport") else self.tree.mapToGlobal(pos))
            if action == act_open:
                ok, msg = self.qgis_connector.add_layer_to_canvas(l, s)
                if ok:
                    QtWidgets.QMessageBox.information(self, tr("success"), msg)
                else:
                    QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
            elif action == act_add_to_group:
                self._add_layer_to_mixed_group_prompt(l, s)
            elif action == act_inspect:
                self.inspectServiceRequested.emit(s)
            elif action == act_copy:
                clipboard = QtWidgets.QApplication.clipboard()
                clipboard.setText(l.get("name", ""))
                QtWidgets.QMessageBox.information(self, tr("notice"), f"Kihi nimi kopeeritud: {l.get('name')}")
            elif action == act_remove_layer:
                self._on_remove_layer_from_service(item, l, s)

    def _on_apply_single_service(self, service_dict):
        """Applies a single service directly to QGIS Browser connections."""
        ok = self.qgis_connector.apply_single_service(service_dict)
        if ok:
            self.profile_manager.save()
            name = service_dict.get("name", "Service")
            QtWidgets.QMessageBox.information(
                self, tr("success"),
                tr("msg_single_applied", name=name)
            )
        else:
            QtWidgets.QMessageBox.warning(
                self, tr("warning"),
                "Teenuse rakendamine QGIS-i ebaõnnestus."
            )

    def _on_rename_service(self, item=None):
        """Allows user to rename services in current profile."""
        item = item or self.tree.currentItem()
        if not item or not self.current_profile:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        target_s = None
        if isinstance(data, dict):
            target_s = data
        elif isinstance(data, tuple) and len(data) >= 2:
            target_s = data[1]

        if not target_s:
            return

        old_name = target_s.get("name", "")
        new_name, ok = QtWidgets.QInputDialog.getText(
            self,
            tr("rename_dialog_title"),
            tr("rename_dialog_label"),
            QtWidgets.QLineEdit.EchoMode.Normal if hasattr(QtWidgets.QLineEdit, "EchoMode") else QtWidgets.QLineEdit.Normal,
            old_name
        )
        if ok and new_name.strip() and new_name.strip() != old_name:
            new_clean = new_name.strip()
            s_id = target_s.get("id") or target_s.get("name")
            self.profile_manager.rename_service_in_profile(self.current_profile["id"], s_id, new_clean)
            target_s["name"] = new_clean
            self.refresh_profiles()
            QtWidgets.QMessageBox.information(
                self, tr("success"),
                f"Teenus nimetatud ümber: '{old_name}' ➔ '{new_clean}'"
            )
            # If in current profile, offer to apply immediately to QGIS
            is_cur = self.current_profile.get("id") == "prof_current" or "current" in self.current_profile.get("name", "").lower()
            if is_cur:
                res = QtWidgets.QMessageBox.question(
                    self, tr("confirm"),
                    tr("confirm_apply_renamed_to_qgis", old_name=old_name, new_name=new_clean),
                    QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
                )
                if res == QtWidgets.QMessageBox.StandardButton.Yes:
                    self._on_apply_single_service(target_s)

    def _on_suggest_service_name(self, item, service_dict):
        """Opens dialog suggesting official names based on presets and server metadata."""
        if not self.current_profile:
            return
        dlg = SuggestNameDialog(service_dict, self.profile_manager, self.tester, self)
        if dlg.exec():
            new_name = dlg.selected_name.strip()
            old_name = service_dict.get("name", "")
            if new_name and new_name != old_name:
                s_id = service_dict.get("id") or service_dict.get("name")
                self.profile_manager.rename_service_in_profile(self.current_profile["id"], s_id, new_name)
                service_dict["name"] = new_name
                self.refresh_profiles()
                QtWidgets.QMessageBox.information(
                    self, tr("success"),
                    f"Teenus edukalt ümber nimetatud ametliku nimega:\n'{old_name}' ➔ '{new_name}'"
                )
                is_cur = self.current_profile.get("id") == "prof_current" or "current" in self.current_profile.get("name", "").lower()
                if is_cur:
                    res = QtWidgets.QMessageBox.question(
                        self, tr("confirm"),
                        tr("confirm_apply_renamed_to_qgis", old_name=old_name, new_name=new_name),
                        QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
                    )
                    if res == QtWidgets.QMessageBox.StandardButton.Yes:
                        self._on_apply_single_service(service_dict)

    def _open_service_info_dialog(self, service_dict):
        """Opens advanced service info and metadata modal dialog."""
        dlg = ServiceInfoDialog(service_dict, self.qgis_connector, self)
        dlg.openInLayersRequested.connect(self.inspectServiceRequested.emit)
        dlg.exec()

    def _on_info_btn_clicked(self):
        """Triggers info dialog for currently selected service."""
        item = self.tree.currentItem()
        if not item:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if isinstance(data, dict):
            self._open_service_info_dialog(data)
        elif isinstance(data, tuple) and len(data) >= 2:
            self._open_service_info_dialog(data[1])

    def _on_tree_double_clicked(self, item, column):
        """Double clicking a layer adds it to canvas; on service or group toggles expand."""
        if not item:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if data == "__group__":
            item.setExpanded(not item.isExpanded())
            return
        if isinstance(data, tuple) and len(data) >= 2:
            l, s = data
            ok, msg = self.qgis_connector.add_layer_to_canvas(l, s)
            if ok:
                QtWidgets.QMessageBox.information(self, tr("success"), msg)
            else:
                QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
        elif isinstance(data, dict):
            item.setExpanded(not item.isExpanded())

    def _on_remove_layer_from_service(self, item, layer_dict, service_dict):
        """Removes a single layer from service in profile."""
        layers = service_dict.get("layers", [])
        l_name = layer_dict.get("name")
        service_dict["layers"] = [x for x in layers if x.get("name") != l_name]
        if self.current_profile:
            self.profile_manager.update_service_layers(
                self.current_profile["id"], service_dict.get("id"), service_dict["layers"]
            )
        self._render_profile(self.current_profile)

    def keyPressEvent(self, event):
        """Keyboard shortcuts: F2 = Rename, Delete = Remove item."""
        if event.key() == QtCore.Qt.Key.Key_F2 if hasattr(QtCore.Qt, "Key") else QtCore.Qt.Key_F2:
            self._on_rename_service()
        elif event.key() == QtCore.Qt.Key.Key_Delete if hasattr(QtCore.Qt, "Key") else QtCore.Qt.Key_Delete:
            self._on_remove_item()
        else:
            super().keyPressEvent(event)

    def _on_item_dropped(self, payload):
        """Handles item dropped from the Layers Panel or within profile."""
        if not self.current_profile:
            return

        target_group_id = payload.get("target_mixed_group_id")
        target_group_name = payload.get("target_mixed_group_name")
        item_type = payload.get("type")

        if target_group_id:
            l = payload.get("layer")
            s = payload.get("service")
            if not l and item_type == "service":
                s = payload
                layers = s.get("layers", [])
                if layers:
                    l = layers[0]
            if l:
                ok, status, grp = self.profile_manager.add_layer_to_mixed_group(
                    self.current_profile["id"], target_group_id, l, s
                )
                grp_name = grp.get("name") if grp else (target_group_name or "Kohandatud grupp")
                l_title = l.get("title") or l.get("name", "Kiht")
                if ok:
                    self._render_profile(self.current_profile)
                    QtWidgets.QMessageBox.information(
                        self, tr("success"),
                        tr("msg_layer_added_to_group", layer=l_title, group=grp_name)
                    )
                else:
                    if status == "duplicate":
                        QtWidgets.QMessageBox.warning(
                            self, tr("warning"),
                            tr("msg_layer_already_in_group", layer=l_title, group=grp_name)
                        )
                return

        if item_type == "layer":
            l = payload.get("layer")
            s = payload.get("service")
            if s and l:
                ok, status, svc, layer = self.profile_manager.add_layer_or_service_to_profile(
                    self.current_profile["id"], layer_dict=l, service_dict=s
                )
                svc_title = (svc or s).get("name", "Teenus")
                l_title = l.get("title") or l.get("name", "Kiht")
                prof_name = self.current_profile.get("name", "")

                if status == "layer_exists":
                    QtWidgets.QMessageBox.information(
                        self, tr("notice"),
                        f"Teenus '{svc_title}' on juba profiilis olemas ja kiht '{l_title}' sisaldub selles juba!"
                    )
                elif status == "layer_added_to_existing":
                    self.refresh_profiles()
                    QtWidgets.QMessageBox.information(
                        self, tr("notice"),
                        f"Teenus '{svc_title}' on juba profiilis olemas. Kiht '{l_title}' lisati selle teenuse alla."
                    )
                elif status == "service_added":
                    self.refresh_profiles()
                    QtWidgets.QMessageBox.information(
                        self, tr("success"),
                        f"Teenus '{svc_title}' ja kiht '{l_title}' lisati profiili '{prof_name}'!"
                    )
                return

        elif item_type == "service" or "url" in payload:
            ok, status, svc, _ = self.profile_manager.add_layer_or_service_to_profile(
                self.current_profile["id"], layer_dict=None, service_dict=payload
            )
            svc_title = (svc or payload).get("name", "Teenus")
            prof_name = self.current_profile.get("name", "")
            if status == "service_exists":
                QtWidgets.QMessageBox.information(
                    self, tr("notice"),
                    f"Teenus '{svc_title}' on juba profiilis olemas!"
                )
            else:
                self.refresh_profiles()
                QtWidgets.QMessageBox.information(
                    self, tr("success"),
                    f"Teenus '{svc_title}' lisati profiili '{prof_name}'!"
                )
            return

    def _on_create_mixed_group(self):
        """Creates a new custom MIXED group in current profile."""
        if not self.current_profile:
            return
        text, ok = QtWidgets.QInputDialog.getText(
            self, tr("dialog_new_group_title"), tr("dialog_new_group_prompt")
        )
        if ok and text.strip():
            group = self.profile_manager.create_mixed_group(self.current_profile["id"], text.strip())
            if group:
                self._render_profile(self.current_profile)
                QtWidgets.QMessageBox.information(
                    self, tr("success"),
                    tr("msg_mixed_group_created", name=group.get("name"))
                )

    def _add_layer_to_mixed_group_prompt(self, layer_dict, service_dict):
        """Prompts user to select or create a mixed group to add layer to."""
        if not self.current_profile:
            return
        mixed_groups = self.profile_manager.get_mixed_groups(self.current_profile["id"])

        target_group = None
        if not mixed_groups:
            text, ok = QtWidgets.QInputDialog.getText(
                self, tr("dialog_new_group_title"),
                "Profiilis pole veel kohandatud gruppe. Sisesta uue grupi nimi:"
            )
            if ok and text.strip():
                target_group = self.profile_manager.create_mixed_group(self.current_profile["id"], text.strip())
            else:
                return
        else:
            options = [g.get("name") for g in mixed_groups] + [f"+ {tr('dialog_new_group_title')}..."]
            item, ok = QtWidgets.QInputDialog.getItem(
                self, tr("menu_add_to_mixed_group"), "Vali sihtgrupp:", options, 0, False
            )
            if not ok or not item:
                return
            if item.startswith("+"):
                text, ok = QtWidgets.QInputDialog.getText(
                    self, tr("dialog_new_group_title"), tr("dialog_new_group_prompt")
                )
                if ok and text.strip():
                    target_group = self.profile_manager.create_mixed_group(self.current_profile["id"], text.strip())
                else:
                    return
            else:
                for g in mixed_groups:
                    if g.get("name") == item:
                        target_group = g
                        break

        if target_group:
            ok, status, grp = self.profile_manager.add_layer_to_mixed_group(
                self.current_profile["id"], target_group["id"], layer_dict, service_dict
            )
            l_title = layer_dict.get("title") or layer_dict.get("name", "Kiht")
            grp_name = grp.get("name", "Kohandatud grupp")
            if ok:
                self._render_profile(self.current_profile)
                QtWidgets.QMessageBox.information(
                    self, tr("success"),
                    tr("msg_layer_added_to_group", layer=l_title, group=grp_name)
                )
            else:
                if status == "duplicate":
                    QtWidgets.QMessageBox.warning(
                        self, tr("warning"),
                        tr("msg_layer_already_in_group", layer=l_title, group=grp_name)
                    )

    def _on_create_profile(self):
        text, ok = QtWidgets.QInputDialog.getText(
            self, tr("dialog_new_profile_title"), tr("dialog_new_profile_prompt")
        )
        if ok and text.strip():
            self.profile_manager.create_profile(text.strip())
            self.refresh_profiles()

    def _on_delete_profile(self):
        if not self.current_profile:
            return
        reply = QtWidgets.QMessageBox.question(
            self, tr("warning"),
            tr("confirm_delete_profile", name=self.current_profile.get("name")),
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
            if hasattr(QtWidgets.QMessageBox, "StandardButton") else QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
        )
        if reply == (QtWidgets.QMessageBox.StandardButton.Yes if hasattr(QtWidgets.QMessageBox, "StandardButton") else QtWidgets.QMessageBox.Yes):
            if self.profile_manager.delete_profile(self.current_profile["id"]):
                self.refresh_profiles()
            else:
                QtWidgets.QMessageBox.warning(self, tr("warning"), "Viimast profiili ei saa kustutada.")

    def _on_apply_clicked(self):
        if not self.current_profile:
            return
        count = self.qgis_connector.apply_profile(self.current_profile, clean_unlisted=True)
        self.profile_manager.save()
        msg = tr("msg_profile_applied", name=self.current_profile.get("name"), count=count)
        QtWidgets.QMessageBox.information(self, tr("success"), msg)
        self.profileApplied.emit(self.current_profile.get("name"), count)

    def _on_sync_from_qgis(self):
        """Synchronizes Current profile directly from active QGIS Browser connections."""
        prof = self.profile_manager.sync_current_qgis_profile()
        self.refresh_profiles()
        count = len(prof.get("services", [])) if prof else 0
        QtWidgets.QMessageBox.information(
            self, tr("success"),
            tr("msg_sync_from_qgis_done", count=count)
        )

    def _on_export_xml(self):
        if not self.current_profile:
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Ekspordi QGIS XML ühendused",
            os.path.expanduser(f"~/{self.current_profile.get('name')}_connections.xml"),
            "QGIS Connections XML (*.xml)"
        )
        if path:
            if self.profile_manager.export_profile_qgis_xml(self.current_profile["id"], path):
                QtWidgets.QMessageBox.information(self, tr("success"), f"QGIS XML ühendused salvestatud: {path}")

    def _on_import_profile(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Impordi profiil",
            os.path.expanduser("~"),
            "Toetatud failid (*.json *.xml);;JSON Profile (*.json);;QGIS XML (*.xml)"
        )
        if path:
            try:
                if path.lower().endswith(".xml"):
                    self.profile_manager.import_profile_qgis_xml(path)
                else:
                    self.profile_manager.import_profile_json(path)
                self.refresh_profiles()
                QtWidgets.QMessageBox.information(self, tr("success"), f"Profiil imporditud: {os.path.basename(path)}")
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, tr("error"), f"Import ebaõnnestus: {e}")

    def _on_share_profile(self):
        if not self.current_profile:
            return
        share_str = self.profile_manager.share_profile_string(self.current_profile["id"])
        clipboard = QtWidgets.QApplication.clipboard()
        clipboard.setText(share_str)
        QtWidgets.QMessageBox.information(
            self, tr("success"),
            "Profiili andmed on kopeeritud lõikelauale (JSON). Saate selle kleepida kolleegile või teise arvutisse!"
        )

    def _on_remove_item(self):
        item = self.tree.currentItem()
        if not item or not self.current_profile:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if isinstance(data, dict):
            s_id = data.get("id")
            s_name = data.get("name")
            stype = data.get("service_type")
            if s_id:
                self.profile_manager.remove_service_from_profile(self.current_profile["id"], s_id)
                is_cur = self.current_profile.get("id") == "prof_current" or "current" in self.current_profile.get("name", "").lower()
                if is_cur and s_name and stype:
                    res = QtWidgets.QMessageBox.question(
                        self, tr("confirm"),
                        f"Kas soovid teenuse '{s_name}' eemaldada ka QGIS ühendustest?",
                        QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
                    )
                    if res == QtWidgets.QMessageBox.StandardButton.Yes:
                        self.qgis_connector.remove_qgis_connection(stype, s_name)
                        self.qgis_connector.refresh_browser()
                self._render_profile(self.current_profile)

    def _on_add_layer_canvas(self):
        item = self.tree.currentItem()
        if not item:
            return
        data = item.data(0, QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if isinstance(data, tuple):
            layer_dict, svc_dict = data
            ok, msg = self.qgis_connector.add_layer_to_canvas(layer_dict, svc_dict)
            if ok:
                QtWidgets.QMessageBox.information(self, tr("success"), msg)
            else:
                QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
        elif isinstance(data, dict):
            if data.get("service_type") == "MIXED":
                ok, msg = self.qgis_connector.add_mixed_group_to_canvas(data)
                if ok:
                    QtWidgets.QMessageBox.information(self, tr("success"), msg)
                else:
                    QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
                return
            layers = data.get("layers", [])
            if layers:
                ok, msg = self.qgis_connector.add_layer_to_canvas(layers[0], data)
                if ok:
                    QtWidgets.QMessageBox.information(self, tr("success"), msg)
                else:
                    QtWidgets.QMessageBox.warning(self, tr("warning"), msg)
            else:
                QtWidgets.QMessageBox.information(self, tr("notice"), "Vali puust konkreetne kiht.")

    def retranslate_ui(self):
        """Translates all text elements in ProfileWidget dynamically."""
        self.lbl_prof.setText(f"<b>{tr('select_profile')}</b>")
        self.btn_new.setText(tr("btn_new_profile"))
        if hasattr(self, "btn_new_group"):
            self.btn_new_group.setText(f"📁 {tr('btn_new_group')}")
            self.btn_new_group.setToolTip(tr("btn_new_group_tooltip"))
        self.btn_rename_prof.setText(tr("menu_rename"))
        self.btn_delete.setText(tr("btn_delete_profile"))
        self.btn_apply.setText(tr("btn_apply_to_qgis"))
        if hasattr(self, "btn_sync_qgis"):
            self.btn_sync_qgis.setText(tr("btn_sync_from_qgis"))
        self.btn_export_xml.setText(tr("btn_export_xml"))
        self.btn_import.setText(tr("btn_import_profile"))
        self.btn_share.setText(tr("btn_share_profile"))

        self.tree.setHeaderLabels([
            tr("col_prof_service"),
            tr("col_prof_type"),
            tr("col_prof_settings")
        ])

        self.btn_remove.setText(tr("btn_remove_item"))
        self.btn_info.setText(f"ℹ️ {tr('menu_advanced_info')}")
        self.btn_open_canvas.setText(tr("btn_add_to_canvas"))
        self.lbl_drop_hint.setText(f"📥 {tr('profile_drop_zone_hint')}")

        self.refresh_profiles()
