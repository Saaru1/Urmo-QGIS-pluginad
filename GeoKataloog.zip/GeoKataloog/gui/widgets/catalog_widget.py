# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Service Catalog Widget
Displays pre-indexed Estonian geospatial services and enables live CSW catalogue discovery.
Supports full dynamic EST/ENG translation.
"""

import urllib.parse
import re
from qgis.PyQt import QtWidgets, QtCore, QtGui
from ...compat import (
    AlignLeft, AlignVCenter, AlignCenter,
    ItemIsEnabled, ItemIsSelectable,
    ResizeStretch, ResizeToContents, ResizeInteractive,
    set_header_resize_mode, exec_dialog
)
from ...i18n import tr, get_language
from ...presets import get_all_presets, search_presets
from ...csw_client import CswClient
from .custom_service_dialog import CustomServiceDialog
from .service_info_dialog import ServiceInfoDialog


def normalize_service_url(url):
    """
    Normalizes OGC service URLs for robust comparison and deduplication:
    - Trims whitespace, trailing slashes, question marks
    - Lowercases scheme and hostname (http/https normalized)
    - Strips standard default ports (:80, :443)
    - Normalizes GeoServer / OGC standard endpoint tails:
      /geoserver/workspace/ows vs /geoserver/workspace/wfs vs /geoserver/workspace/wms -> /geoserver/workspace
    - Strips common OGC query parameters: SERVICE, REQUEST, VERSION, ACCEPTVERSIONS
    """
    if not url:
        return ""
    u = url.strip()
    try:
        parsed = urllib.parse.urlparse(u)
        scheme = parsed.scheme.lower()
        if scheme in ("http", "https"):
            scheme = "https"

        netloc = parsed.netloc.lower()
        if netloc.endswith(":80") or netloc.endswith(":443"):
            netloc = netloc.split(":")[0]

        path = parsed.path.rstrip("/")
        # GeoServer endpoint normalization: /ows, /wfs, /wms, /wcs
        path = re.sub(r'/(ows|wfs|wms|wcs)$', '', path, flags=re.IGNORECASE).lower()

        # Parse query params and strip standard OGC GetCapabilities query params
        query_dict = urllib.parse.parse_qs(parsed.query, keep_blank_values=False)
        filtered_query = {}
        for k, v in query_dict.items():
            k_low = k.lower()
            if k_low not in ("service", "request", "version", "acceptversions"):
                filtered_query[k_low] = sorted([x.lower() for x in v])

        if filtered_query:
            norm_q = urllib.parse.urlencode(sorted(filtered_query.items()), doseq=True)
            return f"{scheme}://{netloc}{path}?{norm_q}"
        return f"{scheme}://{netloc}{path}"
    except Exception:
        return u.lower().rstrip("/?")


def infer_agency_for_connection(url, name=""):
    """Infers the authentic agency owner from URL and service title."""
    comb = f"{url} {name}".lower()
    if "pria" in comb:
        return "PRIA"
    elif any(k in comb for k in ("kataster", "etak", "kitsendused", "haldusjaotus", "maaamet", "maaruum", "geoportaal", "korgus", "dtm", "ads", "planeering")):
        return "Maa- ja Ruumiamet"
    elif any(k in comb for k in ("eelis", "metsaregister", "kaatri", "keskkonna", "loodusveeb", "envir")):
        return "Keskkonnaagentuur"
    elif "muinas" in comb or "muinsus" in comb:
        return "Muinsuskaitseamet"
    elif "transpordiamet" in comb or "mnt.ee" in comb or "teed" in comb:
        return "Transpordiamet"
    elif "stat.ee" in comb:
        return "Statistikaamet"
    elif "osm" in comb or "openstreetmap" in comb:
        return "OpenStreetMap"
    elif "esri" in comb or "arcgis" in comb:
        return "Esri"
    elif "carto" in comb:
        return "Carto"
    return "Avalik teenus"


class SortableEmptyItem(QtWidgets.QTableWidgetItem):
    """
    QTableWidgetItem with empty display text to prevent delegate/cell widget
    double-text ghost painting, while keeping 100% accurate column sorting via sort_key.
    """
    def __init__(self, sort_key=""):
        super().__init__("")
        self.sort_key = str(sort_key).lower()

    def __lt__(self, other):
        if hasattr(other, "sort_key"):
            return self.sort_key < other.sort_key
        return super().__lt__(other)


class CellWidgetDelegate(QtWidgets.QStyledItemDelegate):
    """
    Delegate that suppresses text painting on cells with custom widgets.
    Prevents ghost/double-text overlapping while keeping column sorting 100% functional.
    """
    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        option.text = ""  # Erase text so delegate only paints cell background / selection

    def paint(self, painter, option, index):
        opt = QtWidgets.QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.text = ""
        super().paint(painter, opt, index)


class CatalogWidget(QtWidgets.QWidget):
    """Catalog explorer for discovering Estonian and international geospatial services."""

    testServiceRequested = QtCore.pyqtSignal(dict)
    addToProfileRequested = QtCore.pyqtSignal(dict)

    def __init__(self, profile_manager, parent=None):
        super().__init__(parent)
        self.profile_manager = profile_manager
        self.csw_client = CswClient()
        self.current_services = []
        self._init_ui()
        self.load_presets()

    def _init_ui(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(6)

        # -------------------------------------------------------------
        # Filter & Search Bar
        # -------------------------------------------------------------
        search_card = QtWidgets.QFrame()
        search_card.setProperty("class", "CardFrame")
        search_layout = QtWidgets.QVBoxLayout(search_card)
        search_layout.setContentsMargins(8, 6, 8, 6)
        search_layout.setSpacing(6)

        top_row = QtWidgets.QHBoxLayout()
        top_row.setSpacing(6)

        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText(tr("search_placeholder"))
        self.search_input.setToolTip("Otsi teenust, asutust või märksõna...")
        self.search_input.textChanged.connect(self._on_search_changed)
        self.search_input.returnPressed.connect(self._on_search_btn_clicked)
        top_row.addWidget(self.search_input, stretch=4)

        self.btn_search = QtWidgets.QPushButton(tr("btn_search"))
        self.btn_search.setProperty("class", "PrimaryButton")
        self.btn_search.setToolTip("Käivita otsing (või vajuta Enter)")
        self.btn_search.clicked.connect(self._on_search_btn_clicked)
        top_row.addWidget(self.btn_search)

        self.btn_reset = QtWidgets.QPushButton(tr("btn_reset"))
        self.btn_reset.setToolTip("Tühjenda otsingu- ja filtritingimused")
        self.btn_reset.clicked.connect(self._on_reset_clicked)
        top_row.addWidget(self.btn_reset)

        search_layout.addLayout(top_row)

        filter_row = QtWidgets.QHBoxLayout()
        filter_row.setSpacing(8)

        self.lbl_type = QtWidgets.QLabel(tr("service_type_label"))
        filter_row.addWidget(self.lbl_type)

        self.type_combo = QtWidgets.QComboBox()
        self.type_combo.addItems([tr("filter_all"), "WFS", "WMS", "WCS", "WMTS", "XYZ"])
        self.type_combo.setToolTip("Filtreeri protokolli järgi (WFS, WMS, WCS, WMTS, XYZ)")
        self.type_combo.currentIndexChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self.type_combo)

        self.lbl_cat = QtWidgets.QLabel(tr("filter_category"))
        filter_row.addWidget(self.lbl_cat)

        self.cat_combo = QtWidgets.QComboBox()
        self._populate_category_combo()
        self.cat_combo.setToolTip("Filtreeri kategooria või valdkonna järgi")
        self.cat_combo.currentIndexChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self.cat_combo)

        filter_row.addStretch()

        self.csw_checkbox = QtWidgets.QCheckBox(tr("csw_toggle"))
        self.csw_checkbox.setToolTip("Otsib otse Geoportaali reaalajas CSW 2.0.2 kataloogist")
        filter_row.addWidget(self.csw_checkbox)

        search_layout.addLayout(filter_row)
        main_layout.addWidget(search_card)

        # -------------------------------------------------------------
        # Services Table
        # -------------------------------------------------------------
        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            tr("col_prof_type"),
            tr("col_service_name"),
            tr("col_owner"),
            tr("meta_abstract"),
            "EPSG:3301"
        ])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows if hasattr(QtWidgets.QAbstractItemView, "SelectionBehavior") else QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection if hasattr(QtWidgets.QAbstractItemView, "SelectionMode") else QtWidgets.QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers if hasattr(QtWidgets.QAbstractItemView, "EditTrigger") else QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setShowGrid(True)
        self.table.setAlternatingRowColors(True)

        # Suppress delegate text painting for columns with custom cell widgets to prevent ghost double-text
        self.delegate_no_text = CellWidgetDelegate(self.table)
        self.table.setItemDelegateForColumn(0, self.delegate_no_text)
        self.table.setItemDelegateForColumn(1, self.delegate_no_text)
        self.table.setItemDelegateForColumn(4, self.delegate_no_text)

        header = self.table.horizontalHeader()
        set_header_resize_mode(header, 0, ResizeToContents)
        set_header_resize_mode(header, 1, ResizeInteractive)
        set_header_resize_mode(header, 2, ResizeToContents)
        set_header_resize_mode(header, 3, ResizeStretch)
        set_header_resize_mode(header, 4, ResizeToContents)
        self.table.setSortingEnabled(True)

        self.table.setColumnWidth(1, 240)
        self.table.doubleClicked.connect(self._on_table_double_clicked)
        self.table.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu if hasattr(QtCore.Qt, "ContextMenuPolicy") else QtCore.Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._show_context_menu)
        main_layout.addWidget(self.table)

        # -------------------------------------------------------------
        # Bottom Actions Bar
        # -------------------------------------------------------------
        bottom_bar = QtWidgets.QHBoxLayout()
        bottom_bar.setSpacing(8)

        self.btn_add_custom = QtWidgets.QPushButton(tr("btn_add_custom_url"))
        self.btn_add_custom.setToolTip("Lisa kohandatud WMS, WFS, WCS või XYZ ruumiandmeteenuse URL")
        self.btn_add_custom.clicked.connect(self._on_add_custom_url)
        bottom_bar.addWidget(self.btn_add_custom)

        self.btn_remove = QtWidgets.QPushButton(f"🗑️ {tr('btn_remove_catalog')}")
        self.btn_remove.setProperty("class", "DangerButton")
        self.btn_remove.setToolTip("Eemalda või peida valitud teenus kataloogist")
        self.btn_remove.clicked.connect(self._on_remove_selected_clicked)
        bottom_bar.addWidget(self.btn_remove)

        self.btn_info = QtWidgets.QPushButton(f"ℹ️ {tr('menu_advanced_info')}")
        self.btn_info.setToolTip("Vaata valitud teenuse ametlikke metaandmeid ja tehnilisi parameetreid")
        self.btn_info.clicked.connect(self._on_info_selected_clicked)
        bottom_bar.addWidget(self.btn_info)

        self.count_lbl = QtWidgets.QLabel(tr("services_found", count=0))
        self.count_lbl.setStyleSheet("color: #64748b; font-weight: 500; margin-left: 8px;")
        bottom_bar.addWidget(self.count_lbl)

        bottom_bar.addStretch()

        self.btn_add_profile = QtWidgets.QPushButton(tr("btn_add_to_profile"))
        self.btn_add_profile.setToolTip("Lisa valitud teenus aktiivsesse profiili")
        self.btn_add_profile.clicked.connect(self._on_add_to_profile_clicked)
        bottom_bar.addWidget(self.btn_add_profile)

        self.btn_test = QtWidgets.QPushButton(tr("btn_inspect_layers"))
        self.btn_test.setProperty("class", "PrimaryButton")
        self.btn_test.setToolTip("Ava valitud teenuse kihid ja segageomeetriad Kihtide paneelis testimiseks")
        self.btn_test.clicked.connect(self._on_test_selected_clicked)
        bottom_bar.addWidget(self.btn_test)

        main_layout.addLayout(bottom_bar)

    def _populate_category_combo(self):
        curr_key = self.cat_combo.currentData() if self.cat_combo.count() > 0 else "all"
        self.cat_combo.blockSignals(True)
        self.cat_combo.clear()
        self.cat_combo.addItem(tr("cat_all"), "all")
        self.cat_combo.addItem(f"★ {tr('cat_current')}", "current")
        self.cat_combo.addItem(tr("cat_base"), "base")
        self.cat_combo.addItem(tr("cat_cadastre"), "cadastre")
        self.cat_combo.addItem(tr("cat_topo"), "topo")
        self.cat_combo.addItem(tr("cat_env"), "env")
        self.cat_combo.addItem(tr("cat_agri"), "agri")
        self.cat_combo.addItem(tr("cat_heritage"), "heritage")
        self.cat_combo.addItem(tr("cat_planning"), "planning")
        self.cat_combo.addItem(tr("cat_global"), "global")
        self.cat_combo.addItem(tr("cat_custom"), "custom")

        idx = self.cat_combo.findData(curr_key)
        if idx >= 0:
            self.cat_combo.setCurrentIndex(idx)
        self.cat_combo.blockSignals(False)

    def get_catalog_services(self):
        """Returns presets merged with user's current profile services, with smart URL deduplication."""
        presets = [dict(p) for p in get_all_presets()]
        hidden_urls = self.profile_manager.get_hidden_catalog_urls()

        # Map preset normalized URLs to preset dictionaries by (service_type, norm_url)
        preset_map = {}
        for p in presets:
            st = p.get("service_type", "").upper()
            norm = normalize_service_url(p.get("url", ""))
            if norm:
                preset_map[(st, norm)] = p
                if norm not in preset_map:
                    preset_map[norm] = p

        user_added_services = []
        seen_user_urls = set()

        cur_prof = self.profile_manager.get_active_profile()
        if cur_prof and cur_prof.get("services"):
            for s in cur_prof["services"]:
                u = s.get("url", "")
                norm = normalize_service_url(u)
                if not norm:
                    continue

                st = s.get("service_type", "").upper()
                matched = preset_map.get((st, norm)) or preset_map.get(norm)
                user_name = s.get("name", "").strip()

                # Check if matches an existing catalog preset
                if matched:
                    matched["in_user_profile"] = True
                    matched["user_profile_name"] = user_name
                    matched["user_alias"] = user_name
                else:
                    # Genuinely new user connection
                    dedup_key = (st, norm)
                    if dedup_key not in seen_user_urls:
                        seen_user_urls.add(dedup_key)
                        item = dict(s)
                        item["category"] = "current"
                        item["is_user_service"] = True
                        item["user_profile_name"] = user_name
                        if not item.get("agency") or item.get("agency") in ("-", "[Minu QGIS]", "[My QGIS]"):
                            item["agency"] = infer_agency_for_connection(u, user_name)
                        if not item.get("description"):
                            item["description"] = f"Kasutaja QGIS ühendus: {item.get('name')}"
                            item["description_en"] = f"User QGIS connection: {item.get('name')}"
                        user_added_services.append(item)

        # Merge: User's custom services first, followed by curated presets (presets never removed!)
        combined = user_added_services + presets

        # Filter out any service hidden by the user
        final_list = []
        for s in combined:
            u_norm = normalize_service_url(s.get("url", ""))
            if u_norm not in hidden_urls and s.get("url") not in hidden_urls:
                final_list.append(s)

        return final_list

    def load_presets(self):
        """Loads presets merged with user's detected QGIS connections into table."""
        services = self.get_catalog_services()
        self._populate_table(services)

    def _populate_table(self, services):
        """Fills table widget with service records cleanly and enables sorting across all columns."""
        self.current_services = services
        was_sorting = self.table.isSortingEnabled()
        self.table.setSortingEnabled(False)
        self.table.clearContents()
        self.table.setRowCount(len(services))
        is_eng = get_language() == "ENG"

        for row, s in enumerate(services):
            stype = s.get("service_type", "WMS").upper()
            name = s.get("title_en" if is_eng else "name", s.get("name", "Service"))
            agency = s.get("agency", "-")
            desc = s.get("description_en" if is_eng else "description", s.get("description", ""))
            crs_list = s.get("crs", [])
            has_3301 = any("3301" in str(c) for c in crs_list)

            # Col 0: Type Badge (SortableEmptyItem guarantees 0 ghost double-text and 100% sorting)
            badge_widget = QtWidgets.QWidget()
            badge_layout = QtWidgets.QHBoxLayout(badge_widget)
            badge_layout.setContentsMargins(4, 2, 4, 2)
            badge_lbl = QtWidgets.QLabel(f" {stype} ")
            badge_lbl.setProperty("class", f"Badge{stype}" if stype in ("WFS", "WMS", "WCS", "WMTS", "XYZ") else "BadgeWMS")
            badge_lbl.setAlignment(AlignCenter)
            badge_layout.addWidget(badge_lbl)
            self.table.setItem(row, 0, SortableEmptyItem(stype))
            self.table.setCellWidget(row, 0, badge_widget)

            # Col 1: Name (with user profile badge if already in active profile)
            name_widget = QtWidgets.QWidget()
            name_layout = QtWidgets.QHBoxLayout(name_widget)
            name_layout.setContentsMargins(6, 2, 6, 2)
            name_layout.setSpacing(8)

            lbl_name = QtWidgets.QLabel(name)
            lbl_name.setStyleSheet("font-weight: 600;")
            name_layout.addWidget(lbl_name)

            u_name = s.get("user_profile_name") or s.get("user_alias")
            if u_name in ("Current profile", "Hetke profiil", "Praegune profiil"):
                u_name = "Current profile" if is_eng else "Hetke profiil"

            if s.get("in_user_profile") and u_name:
                pill_lbl = QtWidgets.QLabel(tr("in_my_profile_pill", name=u_name))
                pill_lbl.setProperty("class", "BadgeInProfile")
                name_layout.addWidget(pill_lbl)
            elif s.get("is_user_service"):
                pill_lbl = QtWidgets.QLabel(tr("my_qgis_tag"))
                pill_lbl.setProperty("class", "BadgeInProfile")
                name_layout.addWidget(pill_lbl)

            name_layout.addStretch()

            # Item text is empty so delegate never paints text behind the cell widget; sort_key provides perfect sorting
            it_name = SortableEmptyItem(name)
            it_name.setData(QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole, s)
            if u_name:
                it_name.setToolTip(f"Ametlik kataloogi teenus: {name}\nSinu QGIS profiilis nimega: \"{u_name}\"\nURL: {s.get('url')}")
            else:
                it_name.setToolTip(f"{name}\nURL: {s.get('url')}")
            self.table.setItem(row, 1, it_name)
            self.table.setCellWidget(row, 1, name_widget)

            # Col 2: Agency
            it_agency = QtWidgets.QTableWidgetItem(agency)
            self.table.setItem(row, 2, it_agency)

            # Col 3: Description
            it_desc = QtWidgets.QTableWidgetItem(desc)
            self.table.setItem(row, 3, it_desc)

            # Col 4: EPSG:3301
            it_crs = SortableEmptyItem("1" if has_3301 else "0")
            self.table.setItem(row, 4, it_crs)

            crs_text = f" {tr('yes_text')} " if has_3301 else " - "
            crs_widget = QtWidgets.QWidget()
            crs_layout = QtWidgets.QHBoxLayout(crs_widget)
            crs_layout.setContentsMargins(4, 2, 4, 2)
            crs_lbl = QtWidgets.QLabel(crs_text)
            if has_3301:
                crs_lbl.setProperty("class", "BadgeGeom")
            crs_lbl.setAlignment(AlignCenter)
            crs_layout.addWidget(crs_lbl)
            self.table.setCellWidget(row, 4, crs_widget)

            self.table.setRowHeight(row, 34)

        self.table.setSortingEnabled(True)
        self.count_lbl.setText(tr("services_found", count=len(services)))

        self.count_lbl.setText(tr("services_found", count=len(services)))

    def _on_search_changed(self, text):
        if not self.csw_checkbox.isChecked():
            self._apply_filters()

    def _on_filter_changed(self):
        self._apply_filters()

    def _apply_filters(self):
        query = self.search_input.text().strip().lower()
        stype = self.type_combo.currentText()
        if stype in (tr("filter_all"), "Kõik tüübid", "All Types"):
            stype = None
        cat = self.cat_combo.currentData()

        # Estonian stemming helper for queries
        def get_stems(w):
            stems = [w]
            if len(w) > 4:
                for suffix in ("ad", "id", "de", "sid", "des", "delt", "dele", "dest", "sse", "ga", "le", "lt", "st", "te", "stik"):
                    if w.endswith(suffix) and len(w) - len(suffix) >= 3:
                        stems.append(w[:-len(suffix)])
            return stems

        words = query.split() if query else []
        word_stems = [get_stems(w) for w in words]

        all_svcs = self.get_catalog_services()
        filtered = []
        for s in all_svcs:
            if stype and s.get("service_type", "").upper() != stype.upper():
                continue
            if cat and cat != "all":
                if cat == "current":
                    if not (s.get("category") == "current" or s.get("in_user_profile")):
                        continue
                else:
                    s_cat = s.get("category", "")
                    if s_cat != cat:
                        continue
            if query:
                layers_str = " ".join(s.get("layers_preview", []))
                haystack = f"{s.get('name','')} {s.get('title_en','')} {s.get('agency','')} {s.get('description','')} {s.get('description_en','')} {s.get('url','')} {layers_str}".lower()
                if not all(any(stem in haystack for stem in stems) for stems in word_stems):
                    continue
            filtered.append(s)

        self._populate_table(filtered)

    def _on_search_btn_clicked(self):
        if self.csw_checkbox.isChecked():
            query = self.search_input.text().strip()
            self._run_csw_search(query)
        else:
            self._apply_filters()

    def _run_csw_search(self, query):
        QtWidgets.QApplication.setOverrideCursor(QtGui.QCursor(QtCore.Qt.CursorShape.WaitCursor if hasattr(QtCore.Qt, "CursorShape") else QtCore.Qt.WaitCursor))
        try:
            csw_res = self.csw_client.search_records(search_text=query, max_records=25)
            QtWidgets.QApplication.restoreOverrideCursor()

            if csw_res.get("success"):
                csw_records = csw_res.get("records", [])
                stype = self.type_combo.currentText()
                if stype in (tr("filter_all"), "Kõik tüübid", "All Types"):
                    stype = None
                cat = self.cat_combo.currentData()
                local_matches = search_presets(query, service_type=stype, category=cat)

                combined = list(local_matches)
                for cr in csw_records:
                    if not any(x.get("url") == cr.get("url") for x in combined):
                        combined.append(cr)

                self._populate_table(combined)
            else:
                QtWidgets.QMessageBox.warning(
                    self, tr("warning"),
                    f"Geoportaali CSW otsing ebaõnnestus: {csw_res.get('error')}"
                )
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, tr("warning"), f"Otsingu viga: {e}")

    def _on_reset_clicked(self):
        self.search_input.clear()
        self.type_combo.setCurrentIndex(0)
        self.cat_combo.setCurrentIndex(0)
        self.csw_checkbox.setChecked(False)
        self.load_presets()

    def get_selected_service(self):
        row = self.table.currentRow()
        if row >= 0 and row < len(self.current_services):
            item = self.table.item(row, 1)
            if item:
                data = item.data(QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
                if data:
                    return data
            return self.current_services[row]
        return None

    def _on_test_selected_clicked(self):
        svc = self.get_selected_service()
        if not svc:
            QtWidgets.QMessageBox.information(self, tr("notice"), "Vali esmalt tabelist teenus, mida vaadata.")
            return
        self.testServiceRequested.emit(svc)

    def _on_add_to_profile_clicked(self):
        svc = self.get_selected_service()
        if not svc:
            QtWidgets.QMessageBox.information(self, tr("notice"), "Vali esmalt tabelist teenus.")
            return
        active_prof = self.profile_manager.get_active_profile()
        if not active_prof:
            QtWidgets.QMessageBox.warning(self, tr("warning"), "Aktiivset profiili pole leitud.")
            return

        existing = self.profile_manager.find_service_in_profile(active_prof["id"], svc)
        if existing:
            QtWidgets.QMessageBox.information(
                self, tr("notice"),
                f"Teenus '{existing.get('name', svc.get('name'))}' on juba profiilis olemas!"
            )
            return

        self.profile_manager.add_service_to_profile(active_prof["id"], svc)
        QtWidgets.QMessageBox.information(
            self, tr("success"),
            f"Teenus '{svc.get('name')}' lisatud profiili '{active_prof.get('name')}'."
        )
        self.addToProfileRequested.emit(svc)

    def _show_context_menu(self, pos):
        """Displays rich right-click context menu for services in catalog."""
        item = self.table.itemAt(pos)
        if not item:
            return
        row = item.row()
        it_name = self.table.item(row, 1)
        if not it_name:
            return
        s = it_name.data(QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole)
        if not s:
            return

        menu = QtWidgets.QMenu(self)
        act_inspect = menu.addAction(f"🔍 {tr('menu_inspect_layers')}")
        act_info = menu.addAction(f"ℹ️ {tr('menu_advanced_info')}")
        menu.addSeparator()
        act_add_prof = menu.addAction(f"➕ {tr('btn_add_to_profile')}")
        act_copy = menu.addAction(f"📋 {tr('btn_copy_url')}")
        menu.addSeparator()
        act_remove = menu.addAction(f"🗑️ {tr('btn_remove_catalog')}")

        action = menu.exec(self.table.viewport().mapToGlobal(pos) if hasattr(self.table, "viewport") else self.table.mapToGlobal(pos))
        if action == act_inspect:
            self.testServiceRequested.emit(s)
        elif action == act_info:
            self._open_service_info_dialog(s)
        elif action == act_add_prof:
            self._on_add_to_profile_clicked()
        elif action == act_copy:
            clipboard = QtWidgets.QApplication.clipboard()
            clipboard.setText(s.get("url", ""))
            QtWidgets.QMessageBox.information(self, tr("notice"), f"URL kopeeritud:\n{s.get('url')}")
        elif action == act_remove:
            self._remove_service_from_catalog(s)

    def _open_service_info_dialog(self, service_dict):
        """Opens comprehensive modal metadata and layer diagnostics dialog."""
        dlg = ServiceInfoDialog(service_dict, parent=self)
        dlg.openInLayersRequested.connect(self.testServiceRequested.emit)
        exec_dialog(dlg)

    def _on_info_selected_clicked(self):
        svc = self.get_selected_service()
        if not svc:
            QtWidgets.QMessageBox.information(self, tr("notice"), "Vali esmalt tabelist teenus.")
            return
        self._open_service_info_dialog(svc)

    def _on_remove_selected_clicked(self):
        svc = self.get_selected_service()
        if not svc:
            QtWidgets.QMessageBox.information(self, tr("notice"), "Vali esmalt tabelist teenus, mida eemaldada.")
            return
        self._remove_service_from_catalog(svc)

    def _remove_service_from_catalog(self, s):
        """Removes or hides service from catalog with user confirmation."""
        name = s.get("name", "Teenus")
        res = QtWidgets.QMessageBox.question(
            self, tr("confirm_title"),
            tr("confirm_remove_catalog", name=name),
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
            if hasattr(QtWidgets.QMessageBox, "StandardButton") else
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
        )
        yes_btn = QtWidgets.QMessageBox.StandardButton.Yes if hasattr(QtWidgets.QMessageBox, "StandardButton") else QtWidgets.QMessageBox.Yes
        if res == yes_btn:
            u = s.get("url", "")
            norm_u = normalize_service_url(u)
            if norm_u:
                self.profile_manager.hide_catalog_url(norm_u)
            if u:
                self.profile_manager.hide_catalog_url(u)

            # If service was in user profile, remove it
            active_prof = self.profile_manager.get_active_profile()
            if active_prof:
                self.profile_manager.remove_service_from_profile(active_prof["id"], s.get("id"))

            self.load_presets()

    def _on_table_double_clicked(self, index):
        self._on_test_selected_clicked()

    def _on_add_custom_url(self):
        dlg = CustomServiceDialog(self)
        if exec_dialog(dlg) == 1:
            data = dlg.get_service_data()
            active_prof = self.profile_manager.get_active_profile()
            if active_prof:
                self.profile_manager.add_service_to_profile(active_prof["id"], data)
            self.current_services.insert(0, data)
            self._populate_table(self.current_services)
            self.testServiceRequested.emit(data)

    def retranslate_ui(self):
        """Re-evaluates all texts in CatalogWidget dynamically."""
        self.search_input.setPlaceholderText(tr("search_placeholder"))
        self.btn_search.setText(tr("btn_search"))
        self.btn_reset.setText(tr("btn_reset"))
        self.lbl_type.setText(tr("service_type_label"))
        self.lbl_cat.setText(tr("filter_category"))
        self.csw_checkbox.setText(tr("csw_toggle"))

        self.type_combo.setItemText(0, tr("filter_all"))
        self._populate_category_combo()

        self.table.setHorizontalHeaderLabels([
            tr("col_prof_type"),
            tr("col_service_name"),
            tr("col_owner"),
            tr("meta_abstract"),
            "EPSG:3301"
        ])

        self.btn_add_custom.setText(tr("btn_add_custom_url"))
        self.btn_remove.setText(f"🗑️ {tr('btn_remove_catalog')}")
        self.btn_info.setText(f"ℹ️ {tr('menu_advanced_info')}")
        self.btn_add_profile.setText(tr("btn_add_to_profile"))
        self.btn_test.setText(tr("btn_inspect_layers"))

        self._populate_table(self.current_services)
