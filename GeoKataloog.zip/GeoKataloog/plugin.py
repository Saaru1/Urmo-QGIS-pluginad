# -*- coding: utf-8 -*-
"""
GeoProfile Hub - Plugin Lifecycle Class
Registers dock widget in QGIS interface, Web menu, and toolbar icon.
Compatible with QGIS 3.44+ and QGIS 4.2+.
"""

import os
from qgis.PyQt import QtGui, QtWidgets, QtCore
from .gui.dock_widget import GeoProfileDockWidget
from .compat import RightDockWidgetArea
from .i18n import tr


class GeoProfileHubPlugin:
    """QGIS plugin interface implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dock_widget = None
        self.action = None

    def initGui(self):
        """Creates plugin action, menu item, toolbar icon, and registers dock widget."""
        icon_path = os.path.join(self.plugin_dir, "resources", "icon.svg")
        if os.path.exists(icon_path):
            icon = QtGui.QIcon(icon_path)
        else:
            icon = QtGui.QIcon()

        self.action = QtWidgets.QAction(icon, "GeoKataloog", self.iface.mainWindow())
        self.action.setObjectName("GeoKataloogAction")
        self.action.setToolTip("Lülita GeoKataloog sisse/välja (Eesti kaarditeenused, kihid ja profiilid)")
        self.action.setCheckable(True)
        self.action.setChecked(False)
        self.action.triggered.connect(self.run)

        # Add to Web menu and Web toolbar
        self.iface.addWebToolBarIcon(self.action)
        self.iface.addPluginToWebMenu("&GeoKataloog", self.action)

    def unload(self):
        """Removes dock widgets, menu items and toolbars when plugin is deactivated."""
        if self.action:
            self.iface.removePluginWebMenu("&GeoKataloog", self.action)
            self.iface.removeWebToolBarIcon(self.action)
            del self.action
            self.action = None

        if self.dock_widget:
            try:
                self.dock_widget.visibilityChanged.disconnect(self._on_visibility_changed)
            except Exception:
                pass
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None

    def run(self):
        """Toggles the dock widget visibility on/off."""
        if self.dock_widget is None:
            self.dock_widget = GeoProfileDockWidget(self.iface)
            self.iface.addDockWidget(RightDockWidgetArea, self.dock_widget)
            self.dock_widget.visibilityChanged.connect(self._on_visibility_changed)
            self.dock_widget.show()
            self.dock_widget.raise_()
            self.dock_widget.activateWindow()
            if self.action:
                self.action.setChecked(True)
            return

        if self.dock_widget.isVisible() and not self.dock_widget.isMinimized():
            # If currently visible and active, toggle OFF
            self.dock_widget.hide()
            if self.action:
                self.action.setChecked(False)
        else:
            # If hidden or minimized, toggle ON
            if self.dock_widget.isMinimized():
                self.dock_widget.showNormal()
            self.dock_widget.setVisible(True)
            self.dock_widget.show()
            self.dock_widget.raise_()
            self.dock_widget.activateWindow()
            if self.action:
                self.action.setChecked(True)

    def _on_visibility_changed(self, visible):
        """Keeps toolbar toggle action state in sync with panel visibility."""
        if self.action:
            self.action.setChecked(visible)
