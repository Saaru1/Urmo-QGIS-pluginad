# -*- coding: utf-8 -*-
import datetime
from qgis.PyQt.QtCore import Qt, QTimer, QSize, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QCheckBox, QLineEdit, QListWidget, QListWidgetItem,
    QAbstractItemView, QListView
)
from .thumbnail_delegate import ThumbnailDelegate
from .i18n import tr
from .theme_manager import get_theme_styles, is_dark
from ..satiladu_api import SatiladuAPI


class InlineThumbnailPanel(QWidget):
    dateSelected = pyqtSignal(str, str)

    def __init__(self, workspace, parent=None):
        super().__init__(parent)
        self.workspace = workspace
        self.plugin = workspace.plugin
        self.is_minimized = False
        self.url_list = []

        self.setStyleSheet("""
            QWidget { background: transparent; border: none; color: white; }
            QListWidget { background: transparent; border: none; outline: none; }
            QScrollBar:vertical { background: rgba(20,20,24,180); width: 10px; border-radius: 5px; }
            QScrollBar::handle:vertical { background: rgba(100,100,110,200); border-radius: 5px; min-height: 20px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
            QCheckBox { color: white; font-weight: bold; font-size: 11px; }
            QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }
            QCheckBox::indicator:checked { background: #0078d7; border: 1px solid #0078d7; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
            ibeam_cursor = Qt.CursorShape.IBeamCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor
            ibeam_cursor = Qt.IBeamCursor

        top_layout = QVBoxLayout()
        top_layout.setSpacing(6)

        self.btn_minimize = QPushButton("▲")
        self.btn_minimize.setFixedSize(30, 24)
        self.btn_minimize.setStyleSheet("background-color: #555; color: white; border: none; border-radius: 3px; font-weight: bold; font-size: 12px;")
        self.btn_minimize.setCursor(arrow_cursor)
        self.btn_minimize.setToolTip("Minimize thumbnail panel")
        self.btn_minimize.clicked.connect(self.toggle_minimize)

        self.chk_cloudless = QCheckBox(tr("cloudless_only"))
        self.chk_cloudless.setToolTip(tr("tip_cloudless"))
        self.chk_cloudless.setCursor(arrow_cursor)
        self.chk_cloudless.setChecked(True)
        self.chk_cloudless.toggled.connect(lambda: self.populate())

        header_layout = QHBoxLayout()
        header_layout.addWidget(self.btn_minimize)
        header_layout.addWidget(self.chk_cloudless)
        header_layout.addStretch()
        top_layout.addLayout(header_layout)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText(tr("search_date_placeholder"))
        self.search_box.setStyleSheet("background-color: #222; color: white; border: 1px solid #555; padding: 6px; border-radius: 3px;")
        self.search_box.setCursor(ibeam_cursor)

        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._apply_filter)
        self.search_box.textChanged.connect(lambda text: self.search_timer.start(400))

        top_layout.addWidget(self.search_box)
        layout.addLayout(top_layout)

        self.list_widget = QListWidget()
        self.list_widget.setCursor(arrow_cursor)
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        self.list_widget.itemClicked.connect(self._on_item_clicked)

        self.delegate = ThumbnailDelegate(self.plugin, dark_mode=True, parent=self.list_widget)
        self.list_widget.setItemDelegate(self.delegate)
        layout.addWidget(self.list_widget)

        self.tmp_api = SatiladuAPI()

        try:
            self.user_role = Qt.ItemDataRole.UserRole
            self.pos_center = QAbstractItemView.ScrollHint.PositionAtCenter
        except AttributeError:
            self.user_role = Qt.UserRole
            self.pos_center = QAbstractItemView.PositionAtCenter

        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

    def toggle_minimize(self):
        self.is_minimized = not self.is_minimized
        self.chk_cloudless.setVisible(not self.is_minimized)
        self.search_box.setVisible(not self.is_minimized)
        self.list_widget.setVisible(not self.is_minimized)

        if self.is_minimized:
            self.btn_minimize.setText("▼")
            self.btn_minimize.setToolTip(tr("tip_maximize"))
        else:
            self.btn_minimize.setText("▲")
            self.btn_minimize.setToolTip(tr("tip_minimize"))

        self.workspace._resize_items()

    def apply_theme(self):
        dark = is_dark()
        if hasattr(self, 'delegate') and self.delegate:
            self.delegate.dark_mode = dark
        scroll_bg = "rgba(20, 20, 24, 180)" if dark else "rgba(220, 222, 230, 200)"
        scroll_handle = "rgba(100, 100, 110, 200)" if dark else "rgba(140, 142, 155, 220)"
        min_bg = "rgba(50, 50, 55, 220)" if dark else "rgba(240, 242, 248, 230)"
        min_fg = "#ffffff" if dark else "#111827"
        input_bg = "rgba(30, 30, 34, 220)" if dark else "rgba(255, 255, 255, 230)"
        input_fg = "#ffffff" if dark else "#111827"
        input_border = "#555" if dark else "#b8bac6"

        self.setStyleSheet(f"""
            QWidget {{ background: transparent; border: none; color: white; }}
            QListWidget {{ background: transparent; border: none; outline: none; }}
            QScrollBar:vertical {{ background: {scroll_bg}; width: 10px; border-radius: 5px; }}
            QScrollBar::handle:vertical {{ background: {scroll_handle}; border-radius: 5px; min-height: 20px; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
            QCheckBox {{ color: white; font-weight: bold; font-size: 11px; }}
            QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }}
            QCheckBox::indicator:checked {{ background: #0078d7; border: 1px solid #0078d7; }}
        """)
        if hasattr(self, 'btn_minimize') and self.btn_minimize:
            self.btn_minimize.setStyleSheet(f"background-color: {min_bg}; color: {min_fg}; border: 1px solid #666; border-radius: 3px; font-weight: bold; font-size: 12px;")
        if hasattr(self, 'search_box') and self.search_box:
            self.search_box.setStyleSheet(f"background-color: {input_bg}; color: {input_fg}; border: 1px solid {input_border}; padding: 6px; border-radius: 3px;")
        if hasattr(self, 'list_widget') and self.list_widget:
            self.list_widget.viewport().update()

    def apply_language(self):
        self.chk_cloudless.setText(tr("cloudless_only"))
        self.chk_cloudless.setToolTip(tr("tip_cloudless"))
        self.search_box.setPlaceholderText(tr("search_date_placeholder"))
        self.btn_minimize.setToolTip(tr("tip_maximize") if self.is_minimized else tr("tip_minimize"))

    def populate(self, callback=None):
        self.list_widget.setEnabled(False)
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.workspace.combo_sensor.currentText()
        toode = self.workspace.combo_filter.currentData()

        def _on_fetch_done(success, url_list, err):
            self.url_list = url_list
            self.list_widget.setEnabled(True)
            self.list_widget.clear()

            bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
            for dstr, url in self.url_list:
                item = QListWidgetItem(self.list_widget)
                layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
                thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                             f"&BBOX={bbox_3301}&SRS=EPSG:3301&WIDTH=110&HEIGHT=110"
                             f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")
                item.setData(self.user_role, (dstr, url, thumb_url))

            if self.search_box.text():
                self._apply_filter()
            else:
                QTimer.singleShot(50, self._process_visible_thumbnails)

            if callback:
                callback()

        self.tmp_api.refresh_urls_async(bbox_latlon, sensor, toode, self.chk_cloudless.isChecked(), _on_fetch_done)

    def _apply_filter(self):
        search_term = self.search_box.text().lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            dstr = item.data(self.user_role)[0]
            dt_formatted = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
            item.setHidden(search_term not in dt_formatted)
        self._process_visible_thumbnails()

    def _process_visible_thumbnails(self):
        viewport_rect = self.list_widget.viewport().rect()
        first_idx = -1
        last_idx = -1

        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                rect = self.list_widget.visualItemRect(item)
                if rect.isValid() and viewport_rect.intersects(rect):
                    if first_idx == -1:
                        first_idx = i
                    last_idx = i

        if first_idx == -1:
            return

        active_urls = set()
        for i in range(first_idx, last_idx + 1):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data:
                    continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=10)

        load_start = max(0, first_idx - 5)
        load_end = min(self.list_widget.count(), last_idx + 6)

        for i in range(load_start, load_end):
            if i >= first_idx and i <= last_idx:
                continue
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data:
                    continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=1)

        self.plugin.thumbnail_manager.cancel_stale_requests(active_urls)

    def _on_item_clicked(self, item):
        self.list_widget.scrollToItem(item, self.pos_center)
        dstr, url, thumb_url = item.data(self.user_role)
        self.dateSelected.emit(dstr, url)


class HorizontalFilmstrip(QWidget):
    dateSelected = pyqtSignal(str, str)

    def __init__(self, workspace, parent=None):
        super().__init__(parent)
        self.workspace = workspace
        self.plugin = workspace.plugin
        self.url_list = []
        self.is_minimized = False

        self.setStyleSheet("""
            QWidget { background: transparent; border: none; color: white; }
            QListWidget { background: transparent; border: none; outline: none; }
            QScrollBar:horizontal { background: rgba(20, 20, 24, 180); height: 8px; border-radius: 4px; }
            QScrollBar::handle:horizontal { background: rgba(100, 100, 110, 200); border-radius: 4px; min-width: 20px; }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
            QPushButton { background-color: rgba(30, 30, 34, 220); color: white; border: 1px solid #555; border-radius: 4px; font-weight: bold; font-size: 18px; }
            QPushButton:hover { background-color: #0078d7; }
            QCheckBox { color: white; font-weight: bold; font-size: 11px; }
            QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }
            QCheckBox::indicator:checked { background: #0078d7; border: 1px solid #0078d7; }
        """)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 8, 10, 8)
        main_layout.setSpacing(8)

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
            ibeam_cursor = Qt.CursorShape.IBeamCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor
            ibeam_cursor = Qt.IBeamCursor

        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(5, 0, 5, 0)

        self.btn_minimize = QPushButton("▼")
        self.btn_minimize.setFixedSize(30, 24)
        self.btn_minimize.setStyleSheet("background-color: #555; color: white; border: none; border-radius: 3px; font-weight: bold; font-size: 12px;")
        self.btn_minimize.setCursor(arrow_cursor)
        self.btn_minimize.setToolTip("Minimize thumbnail panel")
        self.btn_minimize.clicked.connect(self.toggle_minimize)

        self.chk_cloudless = QCheckBox(tr("cloudless_only"))
        self.chk_cloudless.setCursor(arrow_cursor)
        self.chk_cloudless.setToolTip(tr("tip_cloudless"))
        self.chk_cloudless.setChecked(True)
        self.chk_cloudless.toggled.connect(lambda: self.populate())

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText(tr("search_date_placeholder"))
        self.search_box.setStyleSheet("background-color: #222; color: white; border: 1px solid #555; padding: 4px 8px; border-radius: 3px; font-size: 12px;")
        self.search_box.setFixedWidth(200)
        self.search_box.setCursor(ibeam_cursor)

        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._apply_filter)
        self.search_box.textChanged.connect(lambda text: self.search_timer.start(400))

        top_bar.addWidget(self.btn_minimize)
        top_bar.addWidget(self.chk_cloudless)
        top_bar.addWidget(self.search_box)
        top_bar.addStretch()

        self.bottom_container = QWidget()
        bottom_layout = QHBoxLayout(self.bottom_container)
        bottom_layout.setContentsMargins(0, 0, 0, 0)
        bottom_layout.setSpacing(10)

        self.btn_prev = QPushButton("<")
        self.btn_prev.setFixedSize(40, 100)
        self.btn_prev.setCursor(arrow_cursor)
        self.btn_prev.clicked.connect(self._go_prev)

        self.list_widget = QListWidget()
        try:
            flow_l2r = QListView.Flow.LeftToRight
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
            scrollbar_off = Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        except AttributeError:
            flow_l2r = QListView.LeftToRight
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
            scrollbar_off = Qt.ScrollBarAlwaysOff

        self.list_widget.setFlow(flow_l2r)
        self.list_widget.setVerticalScrollBarPolicy(scrollbar_off)
        self.list_widget.setHorizontalScrollMode(scroll_per_pixel)
        self.list_widget.setFixedHeight(170)
        self.list_widget.setCursor(arrow_cursor)
        self.list_widget.itemClicked.connect(self._on_item_clicked)

        self.delegate = ThumbnailDelegate(self.plugin, dark_mode=True, parent=self.list_widget)
        self.list_widget.setItemDelegate(self.delegate)

        self.btn_next = QPushButton(">")
        self.btn_next.setFixedSize(40, 100)
        self.btn_next.setCursor(arrow_cursor)
        self.btn_next.clicked.connect(self._go_next)

        bottom_layout.addWidget(self.btn_prev)
        bottom_layout.addWidget(self.list_widget, 1)
        bottom_layout.addWidget(self.btn_next)

        main_layout.addLayout(top_bar)
        main_layout.addWidget(self.bottom_container)

        self.tmp_api = SatiladuAPI()

        try:
            self.user_role = Qt.ItemDataRole.UserRole
            self.pos_center = QAbstractItemView.ScrollHint.PositionAtCenter
        except AttributeError:
            self.user_role = Qt.UserRole
            self.pos_center = QAbstractItemView.PositionAtCenter

        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.horizontalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

    def toggle_minimize(self):
        self.is_minimized = not self.is_minimized
        self.bottom_container.setVisible(not self.is_minimized)
        self.chk_cloudless.setVisible(not self.is_minimized)
        self.search_box.setVisible(not self.is_minimized)

        if self.is_minimized:
            self.btn_minimize.setText("▲")
            self.btn_minimize.setToolTip(tr("tip_maximize"))
        else:
            self.btn_minimize.setText("▼")
            self.btn_minimize.setToolTip(tr("tip_minimize"))

        self.workspace._resize_items()

    def apply_theme(self):
        dark = is_dark()
        if hasattr(self, 'delegate') and self.delegate:
            self.delegate.dark_mode = dark
        scroll_bg = "rgba(20, 20, 24, 180)" if dark else "rgba(220, 222, 230, 200)"
        scroll_handle = "rgba(100, 100, 110, 200)" if dark else "rgba(140, 142, 155, 220)"
        btn_nav_bg = "rgba(40, 40, 44, 220)" if dark else "rgba(245, 247, 252, 230)"
        btn_nav_fg = "#ffffff" if dark else "#111827"
        btn_nav_border = "#555" if dark else "#b8bac6"
        min_bg = "rgba(50, 50, 55, 220)" if dark else "rgba(240, 242, 248, 230)"
        min_fg = "#ffffff" if dark else "#111827"
        input_bg = "rgba(30, 30, 34, 220)" if dark else "rgba(255, 255, 255, 230)"
        input_fg = "#ffffff" if dark else "#111827"
        input_border = "#555" if dark else "#b8bac6"

        self.setStyleSheet(f"""
            QWidget {{ background: transparent; border: none; color: white; }}
            QListWidget {{ background: transparent; border: none; outline: none; }}
            QScrollBar:horizontal {{ background: {scroll_bg}; height: 8px; border-radius: 4px; }}
            QScrollBar::handle:horizontal {{ background: {scroll_handle}; border-radius: 4px; min-width: 20px; }}
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
            QPushButton {{ background-color: {btn_nav_bg}; color: {btn_nav_fg}; border: 1px solid {btn_nav_border}; border-radius: 4px; font-weight: bold; font-size: 18px; }}
            QPushButton:hover {{ background-color: #0078d7; color: white; }}
            QCheckBox {{ color: white; font-weight: bold; font-size: 11px; }}
            QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }}
            QCheckBox::indicator:checked {{ background: #0078d7; border: 1px solid #0078d7; }}
        """)
        if hasattr(self, 'btn_minimize') and self.btn_minimize:
            self.btn_minimize.setStyleSheet(f"background-color: {min_bg}; color: {min_fg}; border: 1px solid {btn_nav_border}; border-radius: 3px; font-weight: bold; font-size: 12px;")
        if hasattr(self, 'search_box') and self.search_box:
            self.search_box.setStyleSheet(f"background-color: {input_bg}; color: {input_fg}; border: 1px solid {input_border}; padding: 4px 8px; border-radius: 3px; font-size: 12px;")
        if hasattr(self, 'list_widget') and self.list_widget:
            self.list_widget.viewport().update()

    def apply_language(self):
        self.chk_cloudless.setText(tr("cloudless_only"))
        self.chk_cloudless.setToolTip(tr("tip_cloudless"))
        self.search_box.setPlaceholderText(tr("search_date_placeholder"))
        self.btn_minimize.setToolTip(tr("tip_maximize") if self.is_minimized else tr("tip_minimize"))

    def populate(self, callback=None):
        self.list_widget.setEnabled(False)
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.workspace.combo_sensor.currentText()
        toode = self.workspace.combo_filter.currentData()

        def _on_fetch_done(success, url_list, err):
            self.url_list = url_list
            self.list_widget.setEnabled(True)
            self.list_widget.clear()

            bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
            for dstr, url in self.url_list:
                item = QListWidgetItem(self.list_widget)
                layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
                thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                             f"&BBOX={bbox_3301}&SRS=EPSG:3301&WIDTH=110&HEIGHT=110"
                             f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")
                item.setData(self.user_role, (dstr, url, thumb_url))

            if self.search_box.text():
                self._apply_filter()
            else:
                self.sync_active_date(self.workspace.current_left_date)
                QTimer.singleShot(50, self._process_visible_thumbnails)

            if callback:
                callback()

        self.tmp_api.refresh_urls_async(bbox_latlon, sensor, toode, self.chk_cloudless.isChecked(), _on_fetch_done)

    def _apply_filter(self):
        search_term = self.search_box.text().lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            dstr = item.data(self.user_role)[0]
            dt_formatted = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
            item.setHidden(search_term not in dt_formatted)
        self._process_visible_thumbnails()

    def sync_active_date(self, dstr):
        if not dstr:
            return
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.isHidden():
                continue
            item_dstr = item.data(self.user_role)[0]
            if item_dstr == dstr:
                self.list_widget.blockSignals(True)
                self.list_widget.setCurrentItem(item)
                self.list_widget.scrollToItem(item, self.pos_center)
                self.list_widget.blockSignals(False)
                break
        self._process_visible_thumbnails()

    def _go_prev(self):
        row = self.list_widget.currentRow()
        if row > 0:
            self.list_widget.setCurrentRow(row - 1)
            self._on_item_clicked(self.list_widget.currentItem())

    def _go_next(self):
        row = self.list_widget.currentRow()
        if row < self.list_widget.count() - 1:
            self.list_widget.setCurrentRow(row + 1)
            self._on_item_clicked(self.list_widget.currentItem())

    def _process_visible_thumbnails(self):
        viewport_rect = self.list_widget.viewport().rect()
        first_idx = -1
        last_idx = -1

        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                rect = self.list_widget.visualItemRect(item)
                if rect.isValid() and viewport_rect.intersects(rect):
                    if first_idx == -1:
                        first_idx = i
                    last_idx = i

        if first_idx == -1:
            return

        active_urls = set()
        for i in range(first_idx, last_idx + 1):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data:
                    continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=10)

        load_start = max(0, first_idx - 5)
        load_end = min(self.list_widget.count(), last_idx + 6)

        for i in range(load_start, load_end):
            if i >= first_idx and i <= last_idx:
                continue
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data:
                    continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=1)

        self.plugin.thumbnail_manager.cancel_stale_requests(active_urls)

    def _on_item_clicked(self, item):
        self.list_widget.scrollToItem(item, self.pos_center)
        dstr, url, thumb_url = item.data(self.user_role)
        self.dateSelected.emit(dstr, url)
