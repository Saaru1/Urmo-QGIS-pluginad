# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QPainter, QColor, QPen
from qgis.PyQt.QtWidgets import QWidget


class SwipeHandle(QWidget):
    positionChanged = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        try:
            self.setCursor(Qt.CursorShape.SplitHCursor)
        except AttributeError:
            self.setCursor(Qt.SplitHCursor)

        try:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        except AttributeError:
            self.setAttribute(Qt.WA_TranslucentBackground)

        self.setFixedWidth(40)
        self.setMouseTracking(True)
        self._dragging = False
        self._is_hovering = False
        self._hover_y = 0

    def enterEvent(self, event):
        self._is_hovering = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._is_hovering = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        try:
            left_btn = Qt.MouseButton.LeftButton
        except AttributeError:
            left_btn = Qt.LeftButton
        if event.button() == left_btn:
            self._dragging = True
            self.update()

    def mouseMoveEvent(self, event):
        try:
            pos_y = event.position().y()
        except AttributeError:
            pos_y = event.pos().y()
        self._hover_y = pos_y
        self.update()
        if self._dragging:
            try:
                gpos = event.globalPosition().toPoint()
            except AttributeError:
                gpos = event.globalPos()
            parent_pos = self.parent().mapFromGlobal(gpos)
            new_x = max(0, min(parent_pos.x(), self.parent().width()))
            self.positionChanged.emit(new_x)

    def mouseReleaseEvent(self, event):
        try:
            left_btn = Qt.MouseButton.LeftButton
        except AttributeError:
            left_btn = Qt.LeftButton
        if event.button() == left_btn:
            self._dragging = False
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            aa = QPainter.RenderHint.Antialiasing
            no_pen = Qt.PenStyle.NoPen
        except AttributeError:
            aa = QPainter.Antialiasing
            no_pen = Qt.NoPen
        painter.setRenderHint(aa)

        w, h = self.width(), self.height()
        center_x = w // 2

        painter.setPen(no_pen)
        painter.setBrush(QColor(0, 0, 0, 1))
        painter.drawRect(0, 0, w, h)

        pen_shadow = QPen(QColor(0, 0, 0, 150))
        pen_shadow.setWidth(2)
        painter.setPen(pen_shadow)
        painter.drawLine(center_x, 0, center_x, h)

        pen_white = QPen(QColor(255, 255, 255, 230))
        pen_white.setWidth(1)
        painter.setPen(pen_white)
        painter.drawLine(center_x, 0, center_x, h)

        painter.setPen(no_pen)
        if self._is_hovering or self._dragging:
            dot_y = max(20, min(self._hover_y, h - 20))
            painter.setBrush(QColor(0, 0, 0, 100))
            painter.drawEllipse(center_x - 11, int(dot_y) - 11, 22, 22)
            painter.setBrush(QColor(255, 255, 255, 255))
            painter.drawEllipse(center_x - 9, int(dot_y) - 9, 18, 18)
            painter.setBrush(QColor(0, 120, 215, 255))
            painter.drawEllipse(center_x - 5, int(dot_y) - 5, 10, 10)
        painter.end()
