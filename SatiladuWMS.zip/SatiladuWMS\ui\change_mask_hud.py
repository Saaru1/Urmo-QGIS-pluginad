# -*- coding: utf-8 -*-
from qgis.core import QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QLabel, QSlider, QCheckBox, QPushButton
from .theme_manager import get_theme_styles, is_dark
from .i18n import tr

try:
    ORIENT_HORIZ = Qt.Orientation.Horizontal
except AttributeError:
    ORIENT_HORIZ = Qt.Horizontal


class ChangeMaskHUD(QWidget):
    """Compact on-canvas floating HUD allowing real-time visibility toggle and opacity control for the change mask."""
    def __init__(self, workspace, parent=None):
        super().__init__(parent or workspace.main_canvas)
        self.ws = workspace
        self.setWindowFlags(Qt.SubWindow if not hasattr(Qt, 'WindowType') else Qt.WindowType.SubWindow)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        # Header row
        header_row = QHBoxLayout()
        header_row.setSpacing(8)

        self.chk_visible = QCheckBox(tr("hud_show"))
        self.chk_visible.setChecked(True)
        self.chk_visible.toggled.connect(self._on_visibility_toggled)
        header_row.addWidget(self.chk_visible)

        header_row.addStretch()

        self.btn_settings = QPushButton(tr("hud_settings"))
        self.btn_settings.setStyleSheet("padding: 2px 8px; font-size: 11px;")
        self.btn_settings.clicked.connect(self._on_settings_clicked)
        header_row.addWidget(self.btn_settings)

        self.btn_remove = QPushButton(tr("hud_remove"))
        self.btn_remove.setStyleSheet("background-color: #d32f2f; color: white; padding: 2px 8px; font-size: 11px;")
        self.btn_remove.clicked.connect(self._on_remove_clicked)
        header_row.addWidget(self.btn_remove)

        layout.addLayout(header_row)

        # Opacity slider row
        opacity_row = QHBoxLayout()
        opacity_row.setSpacing(8)

        self.lbl_opacity = QLabel(tr("hud_opacity"))
        opacity_row.addWidget(self.lbl_opacity)

        self.slider_opacity = QSlider(ORIENT_HORIZ)
        self.slider_opacity.setRange(0, 100)
        self.slider_opacity.setValue(80)
        self.slider_opacity.valueChanged.connect(self._on_opacity_changed)
        opacity_row.addWidget(self.slider_opacity, 1)

        self.lbl_pct = QLabel("80%")
        self.lbl_pct.setFixedWidth(36)
        opacity_row.addWidget(self.lbl_pct)

        layout.addLayout(opacity_row)

        self.apply_theme()
        self.adjustSize()

    def apply_theme(self):
        styles = get_theme_styles()
        text_color = styles["text_color"]
        self.setStyleSheet(f"""
            QWidget {{
                {styles['hud_bg']}
                color: {text_color};
            }}
            QLabel {{
                color: {text_color};
                font-size: 11px;
                font-weight: bold;
            }}
            QCheckBox {{
                color: {text_color};
                font-size: 12px;
                font-weight: bold;
            }}
            QSlider::groove:horizontal {{
                background: {'#444' if styles['is_dark'] else '#d0d2da'};
                height: 5px;
                border-radius: 2px;
            }}
            QSlider::sub-page:horizontal {{
                background: #0078d7;
                border-radius: 2px;
            }}
            QSlider::handle:horizontal {{
                background: {'#00d4ff' if styles['is_dark'] else '#0078d7'};
                width: 12px;
                margin-top: -4px;
                margin-bottom: -4px;
                border-radius: 6px;
            }}
        """)
        self.btn_settings.setText(tr("hud_settings"))
        self.btn_remove.setText(tr("hud_remove"))
        self.chk_visible.setText(tr("hud_show"))
        self.lbl_opacity.setText(tr("hud_opacity"))

    def _on_visibility_toggled(self, checked):
        if self.ws.delta_layer and self.ws.delta_layer.isValid():
            opacity = (self.slider_opacity.value() / 100.0) if checked else 0.0
            self.ws.delta_layer.setOpacity(opacity)
            self.ws.delta_layer.triggerRepaint()
            self.ws.main_canvas.refresh()

    def _on_opacity_changed(self, value):
        self.lbl_pct.setText(f"{value}%")
        if self.chk_visible.isChecked() and self.ws.delta_layer and self.ws.delta_layer.isValid():
            self.ws.delta_layer.setOpacity(value / 100.0)
            self.ws.delta_layer.triggerRepaint()
            self.ws.main_canvas.refresh()

    def _on_settings_clicked(self):
        self.ws._recalibrate_change_detection()

    def _on_remove_clicked(self):
        self.ws._clear_delta_layer()
        self.hide()
