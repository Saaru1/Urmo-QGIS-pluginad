# -*- coding: utf-8 -*-
import datetime
import os
from qgis.core import (
    Qgis, QgsApplication, QgsMessageLog, QgsRasterLayer,
    QgsProject, QgsMapLayer, QgsCoordinateReferenceSystem
)
from qgis.gui import QgsMapCanvas, QgsMapToolPan
from qgis.PyQt.QtCore import Qt, QDate, QUrl, QSize, QTimer, QPoint, QRect, pyqtSignal, QObject, QEvent
from qgis.PyQt.QtGui import QIcon, QTextCharFormat, QColor, QFont, QPixmap, QImage, QRegion, QPainter, QPen, QMouseEvent
from qgis.PyQt.QtWidgets import (
    QAction, QComboBox, QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QWidget, QAbstractItemView, QFileDialog, QMessageBox, QBoxLayout, QApplication
)

from ..satiladu_api import SatiladuAPI
from ..layer_manager import LayerManager
from ..gif_dialog import GifGeneratorDialog
from ..thumbnail_worker import ThumbnailManager
from ..onnx_manager import OnnxManager, get_available_models, get_model_info
from .calendar_dialog import DarkCalendarDialog
from .filmstrip import HorizontalFilmstrip, InlineThumbnailPanel
from .swipe_handle import SwipeHandle

from ..analysis.change_detection import ChangeDetectionTask, ChangeCalibrationDialog
from ..analysis.parcel_inspector import SatiladuPointInspectorTool
from .change_mask_hud import ChangeMaskHUD
from .theme_manager import get_theme_styles, is_dark, set_current_theme
from .i18n import tr, get_current_lang, set_current_lang, get_filter_tooltip, get_filter_data, get_sensor_tooltip
from .language_switch import LanguageSwitchWidget
from .theme_switch import ThemeSwitchWidget
from ..analysis.geotiff_exporter import GeoTiffExportDialog

try:
    TOOLTIP_ROLE = Qt.ItemDataRole.ToolTipRole
except AttributeError:
    TOOLTIP_ROLE = Qt.ToolTipRole

try:
    DIR_LTR = QBoxLayout.Direction.LeftToRight
    DIR_TTB = QBoxLayout.Direction.TopToBottom
except AttributeError:
    DIR_LTR = QBoxLayout.LeftToRight
    DIR_TTB = QBoxLayout.TopToBottom

try:
    ALIGN_HCENTER = Qt.AlignmentFlag.AlignHCenter
    ALIGN_VCENTER = Qt.AlignmentFlag.AlignVCenter
except AttributeError:
    ALIGN_HCENTER = Qt.AlignHCenter
    ALIGN_VCENTER = Qt.AlignVCenter


class SatiladuWorkspace(QObject):
    def __init__(self, plugin, initial_date, initial_url):
        super().__init__(plugin.iface.mapCanvas())
        self.plugin = plugin
        self.main_canvas = plugin.iface.mapCanvas()

        self.is_compare_mode = False
        self._is_updating = False
        self.current_left_date = initial_date
        self.current_right_date = None

        # Super-resolution active state trackers
        self.upscale_scales = {"left": 2, "right": 2}
        self.upscale_models = {"left": None, "right": None}

        # Change detection active layer
        self.delta_layer = None
        self.delta_active_task = None

        # Inspector tool and dialog references
        self.inspector_tool = None
        self.previous_map_tool = None
        self.point_marker = None
        self.parcel_highlight = None
        self.active_profile_dlg = None
        self.geotiff_dlg = None

        try:
            self.arrow_cursor = Qt.CursorShape.ArrowCursor
        except AttributeError:
            self.arrow_cursor = Qt.ArrowCursor

        self.btn_style = "QPushButton { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 5px 11px; font-weight: bold; font-size: 12px; } QPushButton:hover { background-color: #555; }"
        self.btn_active_tool_style = "QPushButton { background-color: #0078d7; color: white; border: 1px solid #005a9e; border-radius: 3px; padding: 5px 11px; font-weight: bold; font-size: 12px; }"
        self.btn_disabled_style = "QPushButton { background-color: #333; color: #777; border: 1px solid #444; border-radius: 3px; padding: 5px 11px; font-weight: bold; font-size: 12px; }"
        self.btn_date_active_style = "QPushButton { background: rgba(30,30,30,220); color: white; border-radius: 4px; padding: 8px 15px; font-size: 14px; font-weight: bold; border: 2px solid #0078d7; } QPushButton:hover { background: rgba(50,50,50,240); border: 2px solid #5cb85c; }"
        self.btn_date_inactive_style = "QPushButton { background: rgba(30,30,30,220); color: white; border-radius: 4px; padding: 8px 15px; font-size: 14px; font-weight: bold; border: 1px solid #666; }"
        self.btn_date_enhanced_style = "QPushButton { background: rgba(20,30,40,230); color: #00d4ff; border-radius: 4px; padding: 8px 15px; font-size: 14px; font-weight: bold; border: 2px solid #00d4ff; } QPushButton:hover { background: rgba(30,45,60,240); border: 2px solid #5ce1e6; }"

        sensor = self.plugin.combo_sensor.currentText()
        filt = self.plugin.combo_filter.currentText()
        self.layer_left = self.plugin.layers.set_main_layer(initial_date, initial_url, sensor, filt)
        self.layer_right = None

        self.control_container = QWidget(self.main_canvas)
        self.control_container.setStyleSheet("""
            QWidget { background: rgba(30,30,30,235); border-radius: 6px; }
            QToolTip { background-color: #1e1e1e; color: #ffffff; border: 1px solid #666; font-size: 12px; font-weight: bold; padding: 5px 8px; border-radius: 3px; }
        """)
        self.toolbar_box_layout = QBoxLayout(DIR_LTR, self.control_container)
        self.toolbar_box_layout.setContentsMargins(6, 4, 6, 4)
        self.toolbar_box_layout.setSpacing(4)
        self.toolbar_box_layout.setAlignment(ALIGN_VCENTER)

        # Row 1 sub-container
        self.row1_widget = QWidget(self.control_container)
        self.row1_widget.setStyleSheet("background: transparent; border: none;")
        self.row1_layout = QHBoxLayout(self.row1_widget)
        self.row1_layout.setContentsMargins(0, 0, 0, 0)
        self.row1_layout.setSpacing(5)

        # Center separator between row 1 and row 2 in 1-row mode
        self.mid_separator = QLabel("<span style='color:#666;'>|</span>", self.control_container)
        self.mid_separator.setStyleSheet("background: transparent;")

        # Row 2 sub-container
        self.row2_widget = QWidget(self.control_container)
        self.row2_widget.setStyleSheet("background: transparent; border: none;")
        self.row2_layout = QHBoxLayout(self.row2_widget)
        self.row2_layout.setContentsMargins(0, 0, 0, 0)
        self.row2_layout.setSpacing(5)

        combo_style = "QComboBox { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 4px 8px; font-size: 12px; } QComboBox::drop-down { border: none; } QComboBox QAbstractItemView { background: #333; color: white; selection-background-color: #0078d7; border: 1px solid #222; outline: none; margin: 0px; padding: 0px; } QComboBox QListView { border: none; }"

        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_sensor.setCurrentIndex(self.plugin.combo_sensor.currentIndex())
        self.combo_sensor.setStyleSheet(combo_style)
        self.combo_sensor.setCursor(self.arrow_cursor)
        if self.combo_sensor.view():
            self.combo_sensor.view().setMouseTracking(True)
        self._update_sensor_tooltip(self.combo_sensor.currentIndex())
        self.combo_sensor.currentIndexChanged.connect(self._update_sensor_tooltip)

        self.combo_filter = QComboBox()
        for idx, (code, toode_id, desc) in enumerate(self.plugin._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, TOOLTIP_ROLE)
        self.combo_filter.setCurrentIndex(self.plugin.combo_filter.currentIndex())
        self.combo_filter.setStyleSheet(combo_style)
        self.combo_filter.setCursor(self.arrow_cursor)
        if self.combo_filter.view():
            self.combo_filter.view().setMouseTracking(True)
        self._update_filter_tooltip(self.combo_filter.currentIndex())
        self.combo_filter.currentIndexChanged.connect(self._update_filter_tooltip)

        self.btn_refresh = QPushButton("🔄 Refresh")
        self.btn_refresh.setStyleSheet(self.btn_style)
        self.btn_refresh.setCursor(self.arrow_cursor)
        self.btn_refresh.setToolTip("Reload dates and thumbnails for current map area")
        self.btn_refresh.clicked.connect(self._on_settings_changed)

        self.btn_cal = QPushButton("📅 Calendar")
        self.btn_cal.setStyleSheet(self.btn_style)
        self.btn_cal.setCursor(self.arrow_cursor)
        self.btn_cal.setToolTip("Open calendar to browse and jump between dates")
        self.btn_cal.clicked.connect(self._open_calendar)

        self.btn_snap = QPushButton("📷 Snap")
        self.btn_snap.setStyleSheet(self.btn_style)
        self.btn_snap.setCursor(self.arrow_cursor)
        self.btn_snap.setToolTip("Add current satellite view as a permanent snapshot layer")
        self.btn_snap.clicked.connect(self._take_snapshot)

        self.btn_geotiff = QPushButton("💾 GeoTIFF")
        self.btn_geotiff.setStyleSheet(self.btn_style)
        self.btn_geotiff.setCursor(self.arrow_cursor)
        self.btn_geotiff.setToolTip("Export georeferenced GeoTIFF at native 10m or AI upscaled 5m/2.5m")
        self.btn_geotiff.clicked.connect(self._open_geotiff_exporter)

        self.btn_inspector = QPushButton("🚜 Mowing")
        self.btn_inspector.setStyleSheet(self.btn_style)
        self.btn_inspector.setCursor(self.arrow_cursor)
        self.btn_inspector.setToolTip("Click a parcel or vector feature (e.g. WFS) to inspect vegetation profile and predict mowing timeframe.")
        self.btn_inspector.clicked.connect(self._toggle_point_inspector)

        self.btn_gif = QPushButton("🎞️ Timelapse")
        self.btn_gif.setStyleSheet(self.btn_style)
        self.btn_gif.setCursor(self.arrow_cursor)
        self.btn_gif.setToolTip("Generate animated GIF, WebP, or MP4 timelapse")
        self.btn_gif.clicked.connect(self._open_gif)

        self.btn_upscale = QPushButton(tr("upscale"))
        self.btn_upscale.setStyleSheet(self.btn_style)
        self.btn_upscale.setCursor(self.arrow_cursor)
        self.btn_upscale.setToolTip("Enhance active view using neural super-resolution (ONNX DirectML)")

        self.combo_model = QComboBox()
        self.combo_model.setStyleSheet(combo_style)
        self.combo_model.setCursor(self.arrow_cursor)
        self.combo_model.setToolTip("Select ONNX model for super-resolution upscaling")
        for m in get_available_models():
            self.combo_model.addItem(m)
        for i in range(self.combo_model.count()):
            if "2x" in self.combo_model.itemText(i).lower():
                self.combo_model.setCurrentIndex(i)
                break

        self.gif_blink_timer = QTimer(self)
        self.gif_blink_timer.timeout.connect(self._toggle_gif_button_blink)
        self.gif_blink_state = False

        self.btn_compare = QPushButton(tr("compare"))
        self.btn_compare.setMinimumWidth(85)
        self.btn_compare.setStyleSheet("QPushButton { background-color: #0078d7; color: white; border-radius: 3px; padding: 4px 10px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #005a9e; }")
        self.btn_compare.setCursor(self.arrow_cursor)
        self.btn_compare.clicked.connect(self._toggle_compare_mode)

        # Compare Mode Change Detection Delta button
        self.btn_delta = QPushButton(tr("change_mask"))
        self.btn_delta.setStyleSheet(self.btn_style)
        self.btn_delta.setCursor(self.arrow_cursor)
        self.btn_delta.setToolTip(tr("tip_change_mask"))
        self.btn_delta.clicked.connect(self._toggle_change_detection)
        self.btn_delta.hide()

        # Theme and Language toggles
        self.theme_switch = ThemeSwitchWidget(self.row2_widget)
        self.theme_switch.themeChanged.connect(self._on_theme_changed)

        self.lang_switch = LanguageSwitchWidget(self.row2_widget)
        self.lang_switch.languageChanged.connect(self._on_language_changed)

        # Separators
        self.sep_r1_1 = QLabel("<span style='color:#666;'>|</span>", self.row1_widget)
        self.sep_r1_1.setStyleSheet("background: transparent;")
        self.sep_r1_2 = QLabel("<span style='color:#666;'>|</span>", self.row1_widget)
        self.sep_r1_2.setStyleSheet("background: transparent;")

        self.row1_layout.addWidget(self.combo_sensor)
        self.row1_layout.addWidget(self.combo_filter)
        self.row1_layout.addWidget(self.btn_refresh)
        self.row1_layout.addWidget(self.sep_r1_1)
        self.row1_layout.addWidget(self.btn_cal)
        self.row1_layout.addWidget(self.btn_snap)
        self.row1_layout.addWidget(self.btn_geotiff)
        self.row1_layout.addWidget(self.sep_r1_2)
        self.row1_layout.addWidget(self.btn_inspector)
        self.row1_layout.addWidget(self.btn_gif)

        self.sep_r2_1 = QLabel("<span style='color:#666;'>|</span>", self.row2_widget)
        self.sep_r2_1.setStyleSheet("background: transparent;")
        self.sep_r2_2 = QLabel("<span style='color:#666;'>|</span>", self.row2_widget)
        self.sep_r2_2.setStyleSheet("background: transparent;")

        self.row2_layout.addWidget(self.btn_upscale)
        self.row2_layout.addWidget(self.combo_model)
        self.row2_layout.addWidget(self.btn_delta)
        self.row2_layout.addWidget(self.sep_r2_1)
        self.row2_layout.addWidget(self.btn_compare)
        self.row2_layout.addWidget(self.sep_r2_2)
        self.row2_layout.addWidget(self.theme_switch)
        self.row2_layout.addWidget(self.lang_switch)

        self.toolbar_box_layout.addWidget(self.row1_widget)
        self.toolbar_box_layout.addWidget(self.mid_separator)
        self.toolbar_box_layout.addWidget(self.row2_widget)

        # Floating On-Canvas Change Mask HUD
        self.delta_hud = ChangeMaskHUD(self)
        self.delta_hud.hide()

        self.control_container.adjustSize()
        self.control_container.show()

        self.onnx_manager = OnnxManager(self)

        # Intercept trigger_upscale to track active model scale per task
        orig_trigger = self.onnx_manager.trigger_upscale
        def _wrapped_trigger(task_id="left"):
            model_name = self.combo_model.currentText()
            info = get_model_info(model_name)
            target_scale = info.get("target_scale", info.get("scale", 2))
            self.upscale_scales[task_id] = target_scale
            self.upscale_models[task_id] = model_name
            return orig_trigger(task_id)
        self.onnx_manager.trigger_upscale = _wrapped_trigger

        self.btn_upscale.clicked.connect(lambda: self.onnx_manager.trigger_upscale("left"))

        # Dedicated compare upscale buttons placed directly beside date indicators on canvas
        self.btn_upscale_left = QPushButton(tr("upscale"), self.main_canvas)
        self.btn_upscale_left.setStyleSheet(self.btn_style)
        self.btn_upscale_left.setCursor(self.arrow_cursor)
        self.btn_upscale_left.clicked.connect(lambda: self.onnx_manager.trigger_upscale("left"))
        self.btn_upscale_left.hide()

        self.btn_upscale_right = QPushButton(tr("upscale"), self.main_canvas)
        self.btn_upscale_right.setStyleSheet(self.btn_style)
        self.btn_upscale_right.setCursor(self.arrow_cursor)
        self.btn_upscale_right.clicked.connect(lambda: self.onnx_manager.trigger_upscale("right"))
        self.btn_upscale_right.hide()

        self.combo_sensor.currentIndexChanged.connect(self._on_settings_changed)
        self.combo_filter.currentIndexChanged.connect(self._on_settings_changed)

        self.panel_left = InlineThumbnailPanel(self, self.main_canvas)
        self.panel_left.hide()
        self.panel_left.dateSelected.connect(self._do_change_left_date)

        self.panel_right = InlineThumbnailPanel(self, self.main_canvas)
        self.panel_right.hide()
        self.panel_right.dateSelected.connect(self._do_change_right_date)

        self.btn_left_date = QPushButton(self.current_left_date, self.main_canvas)
        self.btn_left_date.setStyleSheet(self.btn_date_inactive_style)
        self.btn_left_date.setCursor(self.arrow_cursor)
        self.btn_left_date.clicked.connect(self._toggle_left_panel)
        self.btn_left_date.adjustSize()
        self.btn_left_date.show()

        self.btn_right_date = QPushButton("", self.main_canvas)
        self.btn_right_date.setStyleSheet(self.btn_date_inactive_style)
        self.btn_right_date.setCursor(self.arrow_cursor)
        self.btn_right_date.clicked.connect(self._toggle_right_panel)
        self.btn_right_date.hide()

        self.filmstrip = HorizontalFilmstrip(self, self.main_canvas)
        self.filmstrip.dateSelected.connect(self._do_change_left_date)

        QTimer.singleShot(50, lambda: self.filmstrip.populate())
        self.filmstrip.show()

        self.top_canvas = QgsMapCanvas(self.main_canvas)
        self.top_canvas.setCanvasColor(QColor(0, 0, 0, 0))
        self.top_canvas.setStyleSheet("background: transparent;")
        self.top_canvas.setProject(QgsProject.instance())
        try:
            self.top_canvas.setPreviewJobsEnabled(True)
        except Exception:
            pass
        try:
            self.top_canvas.setParallelRenderingEnabled(True)
        except Exception:
            pass
        try:
            self.top_canvas.enableMapTileRendering(True)
        except Exception:
            pass
        try:
            transparent_mouse = Qt.WidgetAttribute.WA_TransparentForMouseEvents
        except AttributeError:
            transparent_mouse = Qt.WA_TransparentForMouseEvents
        self.top_canvas.setAttribute(transparent_mouse)
        self.top_canvas.hide()

        self.handle = SwipeHandle(self.main_canvas)
        self.handle.positionChanged.connect(self._on_handle_moved)
        self.handle.hide()

        self.split_x = self.main_canvas.width() // 2

        self.main_canvas.extentsChanged.connect(self._sync_extents)
        self.main_canvas.extentsChanged.connect(self._on_extents_settled)
        self.main_canvas.layersChanged.connect(self._sync_layers)
        try:
            self.main_canvas.panDistanceBearingChanged.connect(self._on_pan_distance_bearing_changed)
        except Exception:
            pass
        self.main_canvas.installEventFilter(self)

        self._update_layer_names()
        self.apply_theme()
        self.apply_language()
        self.update_date_button_labels()
        QTimer.singleShot(100, self._resize_items)

    def _update_filter_tooltip(self, index):
        if not hasattr(self, 'combo_filter'):
            return
        desc = self.combo_filter.itemData(index, TOOLTIP_ROLE)
        self.combo_filter.setToolTip(desc if desc else "")

    def _update_sensor_tooltip(self, index):
        if not hasattr(self, 'combo_sensor'):
            return
        desc = self.combo_sensor.itemData(index, TOOLTIP_ROLE)
        self.combo_sensor.setToolTip(desc if desc else "")

    def _update_layer_names(self):
        if not self.layer_left:
            return
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        if self.is_compare_mode:
            self.layer_left.setName(f"Compare: {sensor} {filt} {self.current_left_date} vs {self.current_right_date}")
        else:
            self.layer_left.setName(f"{sensor} {filt} {self.current_left_date}")

    def update_date_button_labels(self):
        if not hasattr(self, 'btn_left_date') or not hasattr(self, 'btn_right_date'):
            return
        up_left = self.onnx_manager.upscale_layers.get("left") if hasattr(self, 'onnx_manager') else None
        up_right = self.onnx_manager.upscale_layers.get("right") if hasattr(self, 'onnx_manager') else None

        left_enhanced = (up_left is not None and up_left.isValid())
        right_enhanced = (up_right is not None and up_right.isValid())

        left_scale = self.upscale_scales.get("left", 2)
        right_scale = self.upscale_scales.get("right", 2)

        if not self.is_compare_mode:
            if left_enhanced:
                self.btn_left_date.setText(f"✨ {left_scale}x | {self.current_left_date}")
                self.btn_left_date.setStyleSheet(self.btn_date_enhanced_style)
            else:
                self.btn_left_date.setText(self.current_left_date)
                self.btn_left_date.setStyleSheet(self.btn_date_inactive_style)
            self.btn_left_date.adjustSize()
        else:
            if left_enhanced:
                self.btn_left_date.setText(f"L: {self.current_left_date} (✨{left_scale}x)")
                self.btn_left_date.setStyleSheet(self.btn_date_enhanced_style)
            else:
                self.btn_left_date.setText(f"L: {self.current_left_date}")
                self.btn_left_date.setStyleSheet(self.btn_date_active_style)
            self.btn_left_date.adjustSize()

            if self.current_right_date:
                if right_enhanced:
                    self.btn_right_date.setText(f"R: {self.current_right_date} (✨{right_scale}x)")
                    self.btn_right_date.setStyleSheet(self.btn_date_enhanced_style)
                else:
                    self.btn_right_date.setText(f"R: {self.current_right_date}")
                    self.btn_right_date.setStyleSheet(self.btn_date_active_style)
                self.btn_right_date.adjustSize()

        self._resize_items()

    def _get_closest_valid_date(self, target_date):
        url_list = self.filmstrip.url_list if self.filmstrip.url_list else self.plugin.api.url_list
        if not url_list:
            return None, None

        best_dstr, best_url = url_list[0]
        min_diff = float('inf')
        for dstr, url in url_list:
            diff = abs((datetime.date.fromisoformat(dstr) - target_date).days)
            if diff == 0:
                return dstr, url
            if diff < min_diff:
                min_diff = diff
                best_dstr = dstr
                best_url = url
        return best_dstr, best_url

    def _on_settings_changed(self):
        self.btn_refresh.setText("⏳")
        self.btn_refresh.setEnabled(False)

        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

        self._clear_delta_layer()

        self.plugin.combo_sensor.blockSignals(True)
        self.plugin.combo_sensor.setCurrentIndex(self.combo_sensor.currentIndex())
        self.plugin.combo_sensor.blockSignals(False)
        self.plugin.combo_filter.blockSignals(True)
        self.plugin.combo_filter.setCurrentIndex(self.combo_filter.currentIndex())
        self.plugin.combo_filter.blockSignals(False)

        sensor = self.combo_sensor.currentText()
        bbox = self.plugin.layers.get_canvas_bbox_latlon_str()
        toode = self.combo_filter.currentData()

        def _main_api_done(success, url_list, err):
            if success:
                self.plugin.api.url_list = url_list
            self.filmstrip.populate(self._on_settings_async_done)

        self.plugin.api.refresh_urls_async(bbox, sensor, toode, self.filmstrip.chk_cloudless.isChecked(), _main_api_done)

    def _on_settings_async_done(self):
        self.btn_refresh.setText(tr("refresh"))
        self.btn_refresh.setEnabled(True)

        left_dt = datetime.date.fromisoformat(self.current_left_date)
        new_left_date, left_url = self._get_closest_valid_date(left_dt)
        if new_left_date:
            self._do_change_left_date(new_left_date, left_url)

        if self.is_compare_mode and self.current_right_date:
            right_dt = datetime.date.fromisoformat(self.current_right_date)
            new_right_date, right_url = self._get_closest_valid_date(right_dt)
            if new_right_date:
                self._do_change_right_date(new_right_date, right_url)

            self.panel_left.populate()
            self.panel_right.populate()

        if hasattr(self, 'gif_dialog') and self.gif_dialog:
            self.gif_dialog._refresh_url_list()
            self.gif_dialog._highlight_dates()

        if hasattr(self, 'main_canvas') and self.main_canvas:
            self.main_canvas.refresh()

    def _toggle_compare_mode(self):
        self.is_compare_mode = not self.is_compare_mode
        self._is_updating = True

        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()

        try:
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception:
            pass

        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

        self._clear_delta_layer()

        if self.is_compare_mode:
            self.filmstrip.hide()
            self.btn_compare.setText(tr("close_compare"))
            self.btn_compare.setStyleSheet("QPushButton { background-color: #d9534f; color: white; border-radius: 3px; padding: 4px 10px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #c9302c; }")

            self.btn_cal.setEnabled(False)
            self.btn_cal.setStyleSheet(self.btn_disabled_style)
            self.btn_upscale.hide()
            self.btn_delta.show()

            left_dt = datetime.date.fromisoformat(self.current_left_date)
            target_dt = left_dt - datetime.timedelta(days=5)
            r_dstr, r_url = self._get_closest_valid_date(target_dt)

            l_dstr = self.current_left_date
            l_url_tuple = self._get_closest_valid_date(left_dt)
            l_url = l_url_tuple[1] if l_url_tuple[1] else self.plugin.api.url_list[0][1]

            self.plugin.layers.setup_compare_layers(l_dstr, l_url, r_dstr, r_url, sensor, filt)
            self.layer_left = self.plugin.layers.layer_left
            self.layer_right = self.plugin.layers.layer_right

            self.current_right_date = r_dstr

            self.panel_left.is_minimized = False
            self.panel_left.chk_cloudless.setVisible(True)
            self.panel_left.search_box.setVisible(True)
            self.panel_left.list_widget.setVisible(True)
            self.panel_left.btn_minimize.setText("▲")

            self.panel_right.is_minimized = False
            self.panel_right.chk_cloudless.setVisible(True)
            self.panel_right.search_box.setVisible(True)
            self.panel_right.list_widget.setVisible(True)
            self.panel_right.btn_minimize.setText("▲")

            self.panel_left.populate()
            self.panel_right.populate()
            self.panel_left.show()
            self.panel_right.show()
            self.btn_right_date.show()

            w, h = self.main_canvas.width(), self.main_canvas.height()
            self.top_canvas.setGeometry(0, 0, w, h)
            self.split_x = w // 2
            self._update_mask()

            self.top_canvas.show()
            self.top_canvas.raise_()
            self.handle.show()
            self.handle.raise_()
            self.control_container.raise_()
            self.btn_left_date.raise_()
            self.btn_right_date.raise_()
            self.panel_left.raise_()
            self.panel_right.raise_()

            try:
                self.top_canvas.setPreviewJobsEnabled(True)
                self.top_canvas.setParallelRenderingEnabled(True)
                self.top_canvas.enableMapTileRendering(True)
            except Exception:
                pass

            self._sync_extents()
            self._sync_layers()
        else:
            self.btn_compare.setText(tr("compare"))
            self.btn_compare.setStyleSheet("QPushButton { background-color: #0078d7; color: white; border-radius: 3px; padding: 4px 10px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #005a9e; }")

            self.btn_cal.setEnabled(True)
            self.btn_cal.setStyleSheet(self.btn_style)
            self.btn_upscale.show()
            self.btn_delta.hide()

            l_dstr = self.current_left_date
            l_url_tuple = self._get_closest_valid_date(datetime.date.fromisoformat(l_dstr))
            l_url = l_url_tuple[1]

            self.layer_right = None
            self.layer_left = self.plugin.layers.set_main_layer(l_dstr, l_url, sensor, filt)

            self.btn_right_date.hide()
            self.top_canvas.hide()
            self.handle.hide()
            self.panel_left.hide()
            self.panel_right.hide()
            self.filmstrip.show()

        self._update_layer_names()
        self._is_updating = False
        self.update_date_button_labels()
        self.main_canvas.layersChanged.connect(self._sync_layers)
        if self.is_compare_mode:
            self._sync_layers()
        self.main_canvas.refresh()

    def _toggle_change_detection(self):
        if not self.is_compare_mode or not self.current_right_date:
            return

        if self.delta_layer and self.delta_layer.isValid():
            self._clear_delta_layer()
            self.btn_delta.setText(tr("change_mask"))
            self.btn_delta.setStyleSheet(self.btn_style)
            return

        # Interactive calibration dialog for sensitivity & mode
        dlg = ChangeCalibrationDialog(self)
        try:
            res = dlg.exec()
            accepted = res == 1 or (hasattr(QDialog, 'DialogCode') and res == QDialog.DialogCode.Accepted) or res == QDialog.Accepted
            if not accepted:
                return
        except Exception:
            if not dlg.exec():
                return

        settings = dlg.get_settings()

        self.btn_delta.setText(tr("change_mask_computing"))
        self.btn_delta.setEnabled(False)

        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
        w = max(400, min(1200, self.main_canvas.width()))
        h = max(300, min(900, self.main_canvas.height()))

        _, url_l = self._get_closest_valid_date(datetime.date.fromisoformat(self.current_left_date))
        _, url_r = self._get_closest_valid_date(datetime.date.fromisoformat(self.current_right_date))

        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()

        task = ChangeDetectionTask(
            bbox_3301, w, h, url_l, url_r,
            self.current_left_date, self.current_right_date,
            sensor, filt,
            threshold_pct=settings["threshold_pct"],
            mode=settings["mode"],
            min_patch_clean=settings["min_patch_clean"],
            callback=self._on_change_detection_finished
        )
        self.delta_active_task = task
        QgsApplication.taskManager().addTask(task)

    def _on_change_detection_finished(self, tif_path, d_l, d_r):
        self.btn_delta.setEnabled(True)
        self.delta_active_task = None

        if not tif_path or not os.path.exists(tif_path):
            self.btn_delta.setText(tr("change_mask"))
            self.btn_delta.setStyleSheet(self.btn_style)
            QMessageBox.warning(self.main_canvas, "Change Detection Failed", "Could not compute change detection difference mask.")
            return

        self.btn_delta.setText(tr("change_mask_active"))
        self.btn_delta.setStyleSheet(self.btn_active_tool_style)

        lyr_title = f"Δ Diff: {d_l} vs {d_r}"
        delta_lyr = QgsRasterLayer(tif_path, lyr_title, "gdal")
        delta_lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:3301"))

        if delta_lyr.isValid():
            self._clear_delta_layer()
            self.delta_layer = delta_lyr
            self.plugin.layers.add_layer_at_top(delta_lyr)
            delta_lyr.triggerRepaint()
            self.main_canvas.refresh()
            self.plugin.log(f"Change detection delta layer mounted: {lyr_title}", Qgis.Success)
            if hasattr(self, 'delta_hud') and self.delta_hud:
                self.delta_hud.show()
                self._position_delta_hud()

    def _clear_delta_layer(self):
        if self.delta_layer:
            try:
                QgsProject.instance().removeMapLayer(self.delta_layer.id())
            except Exception:
                pass
            self.delta_layer = None
        self.btn_delta.setText(tr("change_mask"))
        self.btn_delta.setStyleSheet(self.btn_style)
        if hasattr(self, 'delta_hud') and self.delta_hud:
            self.delta_hud.hide()

    def _recalibrate_change_detection(self):
        self._clear_delta_layer()
        self._toggle_change_detection()

    def _position_delta_hud(self):
        if hasattr(self, 'delta_hud') and self.delta_hud and self.delta_hud.isVisible():
            w = self.main_canvas.width()
            hud_w = self.delta_hud.sizeHint().width() + 10
            hud_h = self.delta_hud.sizeHint().height()
            cc_y = self.control_container.y() + self.control_container.height() + 8
            self.delta_hud.resize(hud_w, hud_h)
            self.delta_hud.move(int((w - hud_w) / 2), cc_y)
            self.delta_hud.raise_()

    def apply_theme(self):
        styles = get_theme_styles()
        self.btn_style = styles["btn_style"]
        self.btn_active_tool_style = styles["btn_active_tool_style"]
        self.btn_date_active_style = styles["btn_date_active_style"]
        self.btn_date_inactive_style = styles["btn_date_inactive_style"]
        self.btn_date_enhanced_style = styles["btn_date_enhanced_style"]

        self.control_container.setStyleSheet(f"""
            QWidget {{ {styles['container_bg']} }}
            QToolTip {{ background-color: #1e1e1e; color: #ffffff; border: 1px solid #777777; font-size: 12px; font-weight: bold; padding: 5px 8px; border-radius: 4px; }}
        """)

        if hasattr(self, 'row1_widget') and self.row1_widget:
            self.row1_widget.setStyleSheet("background: transparent; border: none;")
        if hasattr(self, 'row2_widget') and self.row2_widget:
            self.row2_widget.setStyleSheet("background: transparent; border: none;")

        sep_color = "#555555" if styles.get("is_dark", True) else "#bbbbbb"
        sep_html = f"<span style='color:{sep_color};'>|</span>"
        for sep in [getattr(self, 'sep_r1_1', None), getattr(self, 'sep_r1_2', None),
                    getattr(self, 'sep_r2_1', None), getattr(self, 'sep_r2_2', None),
                    getattr(self, 'mid_separator', None)]:
            if sep:
                sep.setText(sep_html)

        for btn in [self.btn_refresh, self.btn_cal, self.btn_snap, self.btn_geotiff, self.btn_gif]:
            btn.setStyleSheet(self.btn_style)

        if hasattr(self, 'lang_switch') and self.lang_switch:
            self.lang_switch.update_appearance()
        if hasattr(self, 'theme_switch') and self.theme_switch:
            self.theme_switch.update_appearance()

        if self.inspector_tool:
            self.btn_inspector.setStyleSheet(self.btn_active_tool_style)
        else:
            self.btn_inspector.setStyleSheet(self.btn_style)

        self.btn_upscale.setStyleSheet(self.btn_style)
        if hasattr(self, 'btn_upscale_left') and self.btn_upscale_left:
            self.btn_upscale_left.setStyleSheet(self.btn_style)
        if hasattr(self, 'btn_upscale_right') and self.btn_upscale_right:
            self.btn_upscale_right.setStyleSheet(self.btn_style)

        if hasattr(self, 'btn_compare') and self.btn_compare:
            if self.is_compare_mode:
                self.btn_compare.setStyleSheet("QPushButton { background-color: #d9534f; color: white; border-radius: 3px; padding: 4px 10px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #c9302c; }")
            else:
                self.btn_compare.setStyleSheet("QPushButton { background-color: #0078d7; color: white; border-radius: 3px; padding: 4px 10px; font-weight: bold; font-size: 11px; } QPushButton:hover { background-color: #005a9e; }")

        if self.delta_layer and self.delta_layer.isValid():
            self.btn_delta.setStyleSheet(self.btn_active_tool_style)
        else:
            self.btn_delta.setStyleSheet(self.btn_style)

        self.combo_sensor.setStyleSheet(styles["combo_style"])
        self.combo_filter.setStyleSheet(styles["combo_style"])
        self.combo_model.setStyleSheet(styles["combo_style"])

        if hasattr(self, 'delta_hud') and self.delta_hud:
            self.delta_hud.apply_theme()

        if hasattr(self, 'filmstrip') and self.filmstrip:
            self.filmstrip.apply_theme()
        if hasattr(self, 'panel_left') and self.panel_left:
            self.panel_left.apply_theme()
        if hasattr(self, 'panel_right') and self.panel_right:
            self.panel_right.apply_theme()

        if hasattr(self, 'active_profile_dlg') and self.active_profile_dlg:
            try:
                self.active_profile_dlg.apply_theme()
            except Exception:
                pass

        if hasattr(self, 'gif_dialog') and self.gif_dialog:
            try:
                self.gif_dialog.apply_theme()
            except Exception:
                pass

        if hasattr(self, 'geotiff_dlg') and self.geotiff_dlg:
            try:
                self.geotiff_dlg.apply_theme()
            except Exception:
                pass

        if hasattr(self, 'btn_left_date') and hasattr(self, 'btn_right_date'):
            self.update_date_button_labels()
        self.control_container.adjustSize()
        if hasattr(self, 'btn_left_date') and hasattr(self, 'btn_right_date') and hasattr(self, 'panel_left'):
            self._resize_items()

    def _on_theme_changed(self, theme_mode):
        self.apply_theme()

    def _toggle_theme(self):
        new_theme = "light" if is_dark() else "dark"
        set_current_theme(new_theme)
        self.apply_theme()

    def apply_language(self):
        lang = get_current_lang()
        self.btn_inspector.setText(tr("mowing") if not self.inspector_tool else tr("mowing_active"))
        self.btn_inspector.setToolTip(tr("tip_mowing"))
        self.btn_upscale.setText(tr("upscale"))
        self.btn_upscale.setToolTip(tr("tip_upscale"))
        if hasattr(self, 'btn_upscale_left') and self.btn_upscale_left:
            self.btn_upscale_left.setText(tr("upscale"))
        if hasattr(self, 'btn_upscale_right') and self.btn_upscale_right:
            self.btn_upscale_right.setText(tr("upscale"))
        self.btn_gif.setText(tr("timelapse"))
        self.btn_gif.setToolTip(tr("tip_timelapse"))
        self.btn_cal.setText(tr("calendar"))
        self.btn_cal.setToolTip(tr("tip_calendar"))
        self.btn_snap.setText(tr("snapshot"))
        self.btn_snap.setToolTip(tr("tip_snapshot"))
        self.btn_geotiff.setText(tr("geotiff"))
        self.btn_geotiff.setToolTip(tr("tip_geotiff"))
        self.btn_refresh.setText(tr("refresh"))
        self.btn_refresh.setToolTip(tr("tip_refresh"))
        self.btn_compare.setText(tr("close_compare") if self.is_compare_mode else tr("compare"))
        self.btn_compare.setToolTip(tr("tip_compare"))

        if self.delta_layer and self.delta_layer.isValid():
            self.btn_delta.setText(tr("change_mask_active"))
        else:
            self.btn_delta.setText(tr("change_mask"))
        self.btn_delta.setToolTip(tr("tip_change_mask"))

        if hasattr(self, 'lang_switch') and self.lang_switch:
            self.lang_switch.update_appearance()

        if hasattr(self, 'theme_switch') and self.theme_switch:
            self.theme_switch.update_language()

        if hasattr(self, 'delta_hud') and self.delta_hud:
            self.delta_hud.apply_theme()

        if hasattr(self, 'filmstrip') and self.filmstrip:
            self.filmstrip.apply_language()
        if hasattr(self, 'panel_left') and self.panel_left:
            self.panel_left.apply_language()
        if hasattr(self, 'panel_right') and self.panel_right:
            self.panel_right.apply_language()

        if hasattr(self, 'gif_dialog') and self.gif_dialog:
            try:
                self.gif_dialog.apply_language()
            except Exception:
                pass

        if hasattr(self, 'geotiff_dlg') and self.geotiff_dlg:
            try:
                self.geotiff_dlg.apply_language()
            except Exception:
                pass

        if hasattr(self, 'active_profile_dlg') and self.active_profile_dlg:
            try:
                self.active_profile_dlg.apply_language()
            except Exception:
                pass

        # Update filter descriptions & tooltips according to active language
        if hasattr(self, 'combo_filter'):
            for idx in range(self.combo_filter.count()):
                code = self.combo_filter.itemText(idx)
                tip = get_filter_tooltip(code, lang)
                self.combo_filter.setItemData(idx, tip, TOOLTIP_ROLE)
            self._update_filter_tooltip(self.combo_filter.currentIndex())

        if hasattr(self, 'combo_sensor'):
            for idx in range(self.combo_sensor.count()):
                s_name = self.combo_sensor.itemText(idx)
                s_tip = get_sensor_tooltip(s_name, lang)
                self.combo_sensor.setItemData(idx, s_tip, TOOLTIP_ROLE)
            curr_s = self.combo_sensor.currentText()
            self.combo_sensor.setToolTip(get_sensor_tooltip(curr_s, lang))

        self.control_container.adjustSize()
        if hasattr(self, 'btn_left_date') and hasattr(self, 'btn_right_date') and hasattr(self, 'panel_left'):
            self._resize_items()

    def _on_language_changed(self, lang):
        self.apply_language()

    def _toggle_language(self):
        new_lang = "EST" if get_current_lang() == "ENG" else "ENG"
        set_current_lang(new_lang)
        self.apply_language()

    def clear_inspector_visuals(self):
        if hasattr(self, 'point_marker') and self.point_marker:
            try:
                self.main_canvas.scene().removeItem(self.point_marker)
            except Exception:
                pass
            self.point_marker = None
        if hasattr(self, 'parcel_highlight') and self.parcel_highlight:
            try:
                self.parcel_highlight.hide()
            except Exception:
                pass
            self.parcel_highlight = None

    def _toggle_point_inspector(self):
        if self.inspector_tool:
            # Turn off inspector
            self.main_canvas.unsetMapTool(self.inspector_tool)
            self.inspector_tool = None
            self.btn_inspector.setStyleSheet(self.btn_style)
            self.btn_inspector.setText(tr("mowing"))
            self.clear_inspector_visuals()
            if self.previous_map_tool:
                self.main_canvas.setMapTool(self.previous_map_tool)
        else:
            # Turn on inspector
            self.previous_map_tool = self.main_canvas.mapTool()
            self.inspector_tool = SatiladuPointInspectorTool(self)
            self.main_canvas.setMapTool(self.inspector_tool)
            self.btn_inspector.setStyleSheet(self.btn_active_tool_style)
            self.btn_inspector.setText(tr("mowing_active"))

    def _open_geotiff_exporter(self):
        if hasattr(self, 'geotiff_dlg') and self.geotiff_dlg:
            try:
                self.geotiff_dlg.close()
            except Exception:
                pass
        self.geotiff_dlg = GeoTiffExportDialog(self, self.main_canvas)
        self.geotiff_dlg.show()
        self.geotiff_dlg.raise_()

    def _toggle_left_panel(self):
        if not self.is_compare_mode:
            return
        if self.panel_left.isHidden():
            self.panel_left.populate()
            self.panel_left.show()
            self.panel_left.raise_()
        else:
            self.panel_left.hide()

    def _toggle_right_panel(self):
        if not self.is_compare_mode:
            return
        if self.panel_right.isHidden():
            self.panel_right.populate()
            self.panel_right.show()
            self.panel_right.raise_()
        else:
            self.panel_right.hide()

    def _do_change_left_date(self, dstr, url):
        self.current_left_date = dstr
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()

        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers("left")
        self._clear_delta_layer()

        try:
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception:
            pass

        if self.is_compare_mode:
            self.layer_left = self.plugin.layers.update_compare_left(dstr, url, sensor, filt)
        else:
            self.panel_left.hide()
            self.layer_left = self.plugin.layers.set_main_layer(dstr, url, sensor, filt)
            self.filmstrip.sync_active_date(dstr)

        self.update_date_button_labels()
        self._update_layer_names()
        self.main_canvas.layersChanged.connect(self._sync_layers)
        self._sync_layers()
        self.main_canvas.refresh()
        self._resize_items()

    def _do_change_right_date(self, dstr, url):
        if not self.is_compare_mode:
            return
        self.current_right_date = dstr
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()

        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers("right")
        self._clear_delta_layer()

        self.layer_right = self.plugin.layers.update_compare_right(dstr, url, sensor, filt)
        self.update_date_button_labels()
        self._update_layer_names()
        self._sync_layers()
        self._resize_items()

    def _sync_layers(self):
        if not self.is_compare_mode or not self.layer_right or self._is_updating:
            return

        try:
            left_id = self.layer_left.id() if self.layer_left else None
            right_id = self.layer_right.id() if self.layer_right else None
            up_left_lyr = self.onnx_manager.upscale_layers.get("left") if hasattr(self, 'onnx_manager') else None
            up_right_lyr = self.onnx_manager.upscale_layers.get("right") if hasattr(self, 'onnx_manager') else None
            up_left_id = up_left_lyr.id() if up_left_lyr and up_left_lyr.isValid() else None
            up_right_id = up_right_lyr.id() if up_right_lyr and up_right_lyr.isValid() else None
        except RuntimeError:
            return

        mirrored_layers = []

        for lyr in self.main_canvas.layers():
            if not lyr or not lyr.isValid():
                continue
            try:
                lid = lyr.id()

                if up_left_id and lid == up_left_id:
                    if up_right_lyr and up_right_lyr.isValid():
                        mirrored_layers.append(up_right_lyr)
                    continue

                if left_id and lid == left_id:
                    if up_right_lyr and up_right_lyr.isValid() and not any(l and l.id() == up_right_id for l in mirrored_layers):
                        mirrored_layers.append(up_right_lyr)

                    right_base_lyr = QgsProject.instance().mapLayer(right_id)
                    if right_base_lyr and right_base_lyr.isValid():
                        mirrored_layers.append(right_base_lyr)
                    elif self.layer_right and self.layer_right.isValid():
                        mirrored_layers.append(self.layer_right)
                    continue

                base_lyr = QgsProject.instance().mapLayer(lid)
                if base_lyr and base_lyr.isValid():
                    mirrored_layers.append(base_lyr)
                elif lyr.isValid():
                    mirrored_layers.append(lyr)
            except RuntimeError:
                continue

        if right_id and not any(l and l.id() == right_id for l in mirrored_layers):
            if up_right_lyr and up_right_lyr.isValid() and not any(l and l.id() == up_right_id for l in mirrored_layers):
                mirrored_layers.append(up_right_lyr)

            right_base_lyr = QgsProject.instance().mapLayer(right_id)
            if right_base_lyr and right_base_lyr.isValid():
                mirrored_layers.append(right_base_lyr)
            elif self.layer_right and self.layer_right.isValid():
                mirrored_layers.append(self.layer_right)

        if up_right_lyr and up_right_lyr.isValid() and not any(l and l.id() == up_right_id for l in mirrored_layers):
            mirrored_layers.insert(0, up_right_lyr)

        safe_layers = [l for l in mirrored_layers if l is not None and l.isValid()]

        self.top_canvas.blockSignals(True)
        try:
            self.top_canvas.setLayers(safe_layers)
        except TypeError:
            self.top_canvas.setLayers([QgsProject.instance().mapLayer(l.id()) for l in safe_layers if l and QgsProject.instance().mapLayer(l.id())])
        self.top_canvas.blockSignals(False)
        self.top_canvas.refresh()

    def _on_handle_moved(self, x):
        self.split_x = x
        self._update_mask()

    def _on_extents_settled(self):
        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()
        self._clear_delta_layer()

    def _on_pan_distance_bearing_changed(self, dist, unit, bearing):
        if self.is_compare_mode and hasattr(self, 'top_canvas') and self.top_canvas and self.top_canvas.isVisible():
            QTimer.singleShot(0, self._sync_scene_rect)

    def _sync_scene_rect(self):
        if self.is_compare_mode and hasattr(self, 'top_canvas') and self.top_canvas and self.top_canvas.isVisible():
            self.top_canvas.setSceneRect(self.main_canvas.sceneRect())

    def _sync_extents(self):
        if not self.is_compare_mode:
            return
        if hasattr(self, 'top_canvas') and self.top_canvas:
            self.top_canvas.setSceneRect(self.main_canvas.sceneRect())
            self.top_canvas.blockSignals(True)
            self.top_canvas.setDestinationCrs(self.main_canvas.mapSettings().destinationCrs())
            self.top_canvas.setExtent(self.main_canvas.extent())
            self.top_canvas.blockSignals(False)
            self.top_canvas.refresh()

    def eventFilter(self, obj, event):
        try:
            res_ev = QEvent.Type.Resize
        except AttributeError:
            res_ev = QEvent.Resize
        if obj == self.main_canvas and event.type() == res_ev:
            self._resize_items()
            return super().eventFilter(obj, event)

        return super().eventFilter(obj, event)

    def _resize_items(self):
        if self._is_updating:
            return
        if not hasattr(self, 'btn_left_date') or not hasattr(self, 'btn_right_date') or not hasattr(self, 'panel_left'):
            return

        w, h = self.main_canvas.width(), self.main_canvas.height()

        # Step 0: Check if toolbar needs to split into 2 rows for smaller screens
        r1_w = self.row1_widget.sizeHint().width() if hasattr(self, 'row1_widget') else 550
        r2_w = self.row2_widget.sizeHint().width() if hasattr(self, 'row2_widget') else 550
        sep_w = self.mid_separator.sizeHint().width() if hasattr(self, 'mid_separator') else 10
        single_row_needed_w = r1_w + r2_w + sep_w + 35

        # Split into 2 rows if map canvas is narrower than single-row width + 40px buffer
        is_two_rows = (w < single_row_needed_w + 40)

        if hasattr(self, 'toolbar_box_layout'):
            if is_two_rows:
                if self.toolbar_box_layout.direction() != DIR_TTB:
                    self.toolbar_box_layout.setDirection(DIR_TTB)
                    if hasattr(self, 'mid_separator'):
                        self.mid_separator.hide()
                    self.toolbar_box_layout.setAlignment(ALIGN_HCENTER)
            else:
                if self.toolbar_box_layout.direction() != DIR_LTR:
                    self.toolbar_box_layout.setDirection(DIR_LTR)
                    if hasattr(self, 'mid_separator'):
                        self.mid_separator.show()
                    self.toolbar_box_layout.setAlignment(ALIGN_VCENTER)

        if self.control_container.layout():
            self.control_container.layout().invalidate()
            self.control_container.layout().activate()

        self.control_container.adjustSize()
        cc_w = self.control_container.sizeHint().width() + 10
        cc_h = self.control_container.sizeHint().height()

        cc_y = 10
        self.control_container.resize(cc_w, cc_h)
        self.control_container.move(max(8, int((w - cc_w) / 2)), cc_y)

        if hasattr(self, 'delta_hud') and self.delta_hud and self.delta_hud.isVisible():
            self._position_delta_hud()

        # Step 1: Adjust sizes of all canvas date and upscale buttons first
        self.btn_left_date.adjustSize()
        self.btn_right_date.adjustSize()
        if self.is_compare_mode:
            self.btn_upscale_left.adjustSize()
            self.btn_upscale_right.adjustSize()

        # Step 2: Compute full extent of left and right widget clusters
        left_cluster_w = self.btn_left_date.width() + 15
        if self.is_compare_mode:
            left_cluster_w += self.btn_upscale_left.width() + 8

        right_cluster_w = self.btn_right_date.width() + 15
        if self.is_compare_mode:
            right_cluster_w += self.btn_upscale_right.width() + 8

        cc_left = int((w - cc_w) / 2)
        cc_right = cc_left + cc_w

        # Safe clearance margin of 16px between toolbar edges and side buttons
        needs_drop = is_two_rows or (cc_left < left_cluster_w + 16) or (cc_right > w - right_cluster_w - 16) or (cc_w >= w - 50)
        date_y = cc_y + cc_h + 8 if needs_drop else 12

        self.btn_left_date.move(15, date_y)
        self.btn_right_date.move(w - self.btn_right_date.width() - 15, date_y)

        if self.is_compare_mode:
            self.btn_upscale_left.move(self.btn_left_date.x() + self.btn_left_date.width() + 8, date_y)
            self.btn_upscale_left.show()
            self.btn_upscale_left.raise_()

            self.btn_upscale_right.move(self.btn_right_date.x() - self.btn_upscale_right.width() - 8, date_y)
            self.btn_upscale_right.show()
            self.btn_upscale_right.raise_()
        else:
            self.btn_upscale_left.hide()
            self.btn_upscale_right.hide()

        panel_y = date_y + self.btn_left_date.height() + 8
        panel_w = 210
        p_left_h = 44 if self.panel_left.is_minimized else h - panel_y - 20
        p_right_h = 44 if self.panel_right.is_minimized else h - panel_y - 20

        self.panel_left.setGeometry(0, panel_y, panel_w, p_left_h)
        self.panel_right.setGeometry(w - panel_w, panel_y, panel_w, p_right_h)

        strip_h = 44 if self.filmstrip.is_minimized else 235
        self.filmstrip.setGeometry(50, h - strip_h - 20, w - 100, strip_h)

        if self.is_compare_mode:
            self.split_x = min(max(self.split_x, 0), w)
            self._update_mask()

    def _update_mask(self):
        w, h = self.main_canvas.width(), self.main_canvas.height()
        if hasattr(self, 'top_canvas') and self.top_canvas:
            self.top_canvas.setGeometry(0, 0, w, h)
            self.top_canvas.setMask(QRegion(self.split_x, 0, w - self.split_x, h))
        if hasattr(self, 'handle') and self.handle:
            self.handle.setGeometry(self.split_x - 20, 0, 40, h)

    def _open_calendar(self):
        dlg = DarkCalendarDialog(self)
        try:
            acc_code = QDialog.DialogCode.Accepted
        except AttributeError:
            acc_code = QDialog.Accepted

        if dlg.exec() == acc_code:
            cloudless_state = dlg.chk_cloudless.isChecked()
            self.filmstrip.chk_cloudless.setChecked(cloudless_state)
            if self.is_compare_mode:
                self.panel_left.chk_cloudless.setChecked(cloudless_state)
                self.panel_right.chk_cloudless.setChecked(cloudless_state)

            selected_dstr = dlg.get_selected_date()
            dstr, url = self._get_closest_valid_date(datetime.date.fromisoformat(selected_dstr))
            if dstr:
                self._do_change_left_date(dstr, url)

    def _take_snapshot(self):
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()

        if self.is_compare_mode:
            default_name = f"Compare_{sensor}_{filt}_{self.current_left_date}_vs_{self.current_right_date}.png"
            path, _ = QFileDialog.getSaveFileName(self.main_canvas, "Save Compare Snapshot", default_name, "PNG Image (*.png)")
            if path:
                self.main_canvas.grab().save(path, "PNG")
                self.plugin.log(f"Compare snapshot saved to {path}")
        else:
            date_str = self.current_left_date
            src_layer = self.plugin.layers.current_layer

            if src_layer:
                snap = QgsRasterLayer(src_layer.source(), f"Snap-Satiladu_{sensor}_{filt}_{date_str}", "wms")
                if snap.isValid():
                    self.plugin.layers.add_layer_at_top(snap)

    def _open_gif(self):
        self.stop_gif_btn_blink()

        if not hasattr(self, 'gif_dialog') or self.gif_dialog is None:
            self.gif_dialog = GifGeneratorDialog(self.plugin)
            self.gif_dialog.show()
            self.gif_dialog.raise_()
            self.gif_dialog.activateWindow()
        else:
            self.gif_dialog._refresh_url_list()
            self.gif_dialog._highlight_dates()

            if self.gif_dialog.isMinimized():
                self.gif_dialog.showNormal()
                self.gif_dialog.raise_()
                self.gif_dialog.activateWindow()
            elif self.gif_dialog.isVisible():
                self.gif_dialog.hide()
            else:
                self.gif_dialog.showNormal()
                self.gif_dialog.raise_()
                self.gif_dialog.activateWindow()

    def destroy_workspace(self):
        try:
            self.main_canvas.removeEventFilter(self)
            self.main_canvas.extentsChanged.disconnect(self._sync_extents)
            self.main_canvas.extentsChanged.disconnect(self._on_extents_settled)
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
            try:
                self.main_canvas.panDistanceBearingChanged.disconnect(self._on_pan_distance_bearing_changed)
            except Exception:
                pass
        except Exception:
            pass

        if self.inspector_tool:
            self.main_canvas.unsetMapTool(self.inspector_tool)
            self.inspector_tool = None
            if self.previous_map_tool:
                self.main_canvas.setMapTool(self.previous_map_tool)

        self.clear_inspector_visuals()

        if hasattr(self, 'active_profile_dlg') and self.active_profile_dlg:
            try:
                self.active_profile_dlg.close()
            except Exception:
                pass
            self.active_profile_dlg = None

        if hasattr(self, 'geotiff_dlg') and self.geotiff_dlg:
            try:
                self.geotiff_dlg.close()
            except Exception:
                pass
            self.geotiff_dlg = None

        self._clear_delta_layer()

        if hasattr(self, 'delta_hud') and self.delta_hud:
            try:
                self.delta_hud.close()
                self.delta_hud.deleteLater()
            except Exception:
                pass
            self.delta_hud = None

        if hasattr(self.plugin, 'thumbnail_manager') and self.plugin.thumbnail_manager:
            self.plugin.thumbnail_manager.clear_queue()
        self.onnx_manager.cleanup()

        if hasattr(self, 'gif_dialog') and self.gif_dialog:
            self.gif_dialog.close()
            self.gif_dialog.deleteLater()
            self.gif_dialog = None
        self.top_canvas.deleteLater()
        self.handle.deleteLater()
        self.control_container.deleteLater()
        self.btn_left_date.deleteLater()
        self.btn_right_date.deleteLater()
        self.btn_upscale_left.deleteLater()
        self.btn_upscale_right.deleteLater()
        self.panel_left.deleteLater()
        self.panel_right.deleteLater()
        self.filmstrip.deleteLater()
        if self.gif_blink_timer.isActive():
            self.gif_blink_timer.stop()
        self.deleteLater()

    def start_gif_btn_blink(self):
        if not self.gif_blink_timer.isActive():
            self.gif_blink_timer.start(600)

    def stop_gif_btn_blink(self):
        if self.gif_blink_timer.isActive():
            self.gif_blink_timer.stop()
        self.gif_blink_state = False
        self.btn_gif.setStyleSheet(self.btn_style)

    def _toggle_gif_button_blink(self):
        self.gif_blink_state = not self.gif_blink_state
        if self.gif_blink_state:
            blink_style = "QPushButton { background-color: #444; color: white; border: 2px solid #5cb85c; border-radius: 3px; padding: 4px 10px; font-weight: bold; font-size: 12px; } QPushButton:hover { background-color: #555; }"
            self.btn_gif.setStyleSheet(blink_style)
        else:
            self.btn_gif.setStyleSheet(self.btn_style)
