# -*- coding: utf-8 -*-
"""
Analysis tools for SatiladuWMS:
- change_detection: Live spectral / NDVI difference masking
- parcel_inspector: Interactive point / parcel vegetation index time-series curve plotting
- geotiff_exporter: Direct georeferenced GeoTIFF raster exporter
"""
