# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import QWidget, QHBoxLayout, QPushButton
from .i18n import get_current_lang, set_current_lang
from .theme_manager import get_theme_styles

class LanguageSwitchWidget(QWidget):
    """Segmented switch displaying [ 🇪🇪 EST | 🇬🇧 ENG ] with active language highlighted."""
    languageChanged = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(1)

        self.btn_est = QPushButton("🇪🇪 EST")
        self.btn_eng = QPushButton("🇬🇧 ENG")

        try:
            hand_cursor = Qt.CursorShape.PointingHandCursor
        except AttributeError:
            hand_cursor = Qt.PointingHandCursor

        self.btn_est.setCursor(hand_cursor)
        self.btn_eng.setCursor(hand_cursor)

        self.btn_est.clicked.connect(lambda: self.set_language("EST"))
        self.btn_eng.clicked.connect(lambda: self.set_language("ENG"))

        layout.addWidget(self.btn_est)
        layout.addWidget(self.btn_eng)

        self.update_appearance()

    def set_language(self, lang):
        if lang not in ("EST", "ENG"):
            return
        current = get_current_lang()
        if lang != current:
            set_current_lang(lang)
            self.update_appearance()
            self.languageChanged.emit(lang)

    def update_appearance(self):
        styles = get_theme_styles()
        dark = styles.get("is_dark", True)
        current = get_current_lang()

        active_style = (
            "QPushButton { background-color: #0078d7; color: #ffffff; font-weight: bold; "
            "border: 1px solid #005a9e; border-radius: 3px; padding: 4px 7px; font-size: 11px; } "
            "QPushButton:hover { background-color: #0063b1; }"
        )

        if dark:
            inactive_style = (
                "QPushButton { background-color: #2c2c30; color: #888894; font-weight: normal; "
                "border: 1px solid #44444c; border-radius: 3px; padding: 4px 7px; font-size: 11px; } "
                "QPushButton:hover { background-color: #383840; color: #ffffff; }"
            )
        else:
            inactive_style = (
                "QPushButton { background-color: #e4e6ee; color: #555560; font-weight: normal; "
                "border: 1px solid #c2c4ce; border-radius: 3px; padding: 4px 7px; font-size: 11px; } "
                "QPushButton:hover { background-color: #d6d8e2; color: #111111; }"
            )

        if current == "EST":
            self.btn_est.setStyleSheet(active_style)
            self.btn_eng.setStyleSheet(inactive_style)
        else:
            self.btn_est.setStyleSheet(inactive_style)
            self.btn_eng.setStyleSheet(active_style)

        self.btn_est.setToolTip("Eesti keel (Aktiivne)" if current == "EST" else "Lülita eesti keelele")
        self.btn_eng.setToolTip("English (Active)" if current == "ENG" else "Switch to English")
