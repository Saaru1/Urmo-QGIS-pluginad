# -*- coding: utf-8 -*-
import os
import io
import urllib.request
import numpy as np
from PIL import Image

from qgis.core import (
    QgsTask, QgsProject, QgsRasterLayer, QgsMessageLog, Qgis,
    QgsApplication, QgsBlockingNetworkRequest
)
from qgis.PyQt.QtCore import Qt, QUrl, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QFileDialog, QProgressBar, QMessageBox, QCheckBox
)
from qgis.PyQt.QtNetwork import QNetworkRequest
from ..onnx_worker import run_onnx_upscale, save_geotiff
from ..onnx_manager import get_model_info
from ..ui.i18n import tr
from ..ui.theme_manager import get_theme_styles

try:
    WINDOW_MIN = Qt.WindowType.WindowMinimizeButtonHint
    WINDOW_CLOSE = Qt.WindowType.WindowCloseButtonHint
    NON_MODAL = Qt.WindowModality.NonModal
except AttributeError:
    WINDOW_MIN = Qt.WindowMinimizeButtonHint
    WINDOW_CLOSE = Qt.WindowCloseButtonHint
    NON_MODAL = Qt.NonModal


class GeoTiffExportTask(QgsTask):
    sig_progress = pyqtSignal(int, str)

    def __init__(self, bbox_3301, width, height, wms_url, out_path, model_path, target_scale, callback):
        super().__init__("Exporting Satiladu GeoTIFF", QgsTask.CanCancel)
        self.bbox_3301 = bbox_3301
        self.width = width
        self.height = height
        self.wms_url = wms_url
        self.out_path = out_path
        self.model_path = model_path
        self.target_scale = target_scale
        self.callback = callback

    def run(self):
        try:
            layer_param = self.wms_url.split('?')[0].split('wms-')[-1].replace('-', '_')

            # Fetch base image
            if self.target_scale and self.target_scale > 1 and self.model_path:
                fetch_w = max(64, self.width // self.target_scale)
                fetch_h = max(64, self.height // self.target_scale)
            else:
                fetch_w = self.width
                fetch_h = self.height

            getmap_url = (f"{self.wms_url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                          f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={fetch_w}&HEIGHT={fetch_h}"
                          f"&LAYERS={layer_param}&STYLES=&FORMAT=image/png")

            self.sig_progress.emit(10, "Fetching high-resolution satellite imagery from EstHub...")
            self.setProgress(10)
            if self.isCanceled():
                return False

            raw_bytes = None
            try:
                bnr = QgsBlockingNetworkRequest()
                req = QNetworkRequest(QUrl(getmap_url))
                err = bnr.get(req)
                try:
                    no_err = QgsBlockingNetworkRequest.ErrorCode.NoError
                except AttributeError:
                    no_err = 0
                if err == no_err and bnr.reply():
                    raw_bytes = bytes(bnr.reply().content())
            except Exception:
                pass

            if not raw_bytes:
                req_py = urllib.request.Request(getmap_url, headers={'User-Agent': 'Mozilla/5.0 (QGIS Satiladu)'})
                with urllib.request.urlopen(req_py, timeout=25) as resp:
                    if self.isCanceled():
                        return False
                    raw_bytes = resp.read()

            self.sig_progress.emit(40, "Image received. Decoding raster bands...")
            self.setProgress(40)
            if not raw_bytes or self.isCanceled():
                return False

            img = Image.open(io.BytesIO(raw_bytes)).convert("RGB")

            # Apply super-resolution if requested
            if self.target_scale and self.target_scale > 1 and self.model_path and os.path.exists(self.model_path):
                def on_progress(done, total):
                    pct = 40 + int((done / float(max(1, total))) * 45)
                    self.setProgress(pct)
                    self.sig_progress.emit(pct, f"AI Upscaling ({self.target_scale}x): {done}/{total} tiles...")

                upscaled = run_onnx_upscale(
                    img,
                    self.model_path,
                    is_canceled_func=self.isCanceled,
                    progress_func=on_progress,
                    target_scale=self.target_scale
                )
                if self.isCanceled():
                    return False
                final_img = upscaled if upscaled else img
            else:
                final_img = img

            self.sig_progress.emit(90, "Writing georeferenced GeoTIFF (EPSG:3301)...")
            self.setProgress(90)
            if self.isCanceled():
                return False

            # Save GeoTIFF
            save_geotiff(final_img, self.out_path, self.bbox_3301)
            self.sig_progress.emit(100, "GeoTIFF export complete.")
            self.setProgress(100)
            return True

        except Exception as e:
            QgsMessageLog.logMessage(f"GeoTIFF Export Error: {str(e)}", "SentinelWMS", Qgis.Critical)
            return False

    def finished(self, result):
        self.callback(result and os.path.exists(self.out_path), self.out_path)


class GeoTiffExportDialog(QDialog):
    def __init__(self, workspace, parent=None):
        super().__init__(parent or workspace.main_canvas)
        self.ws = workspace
        self.plugin = workspace.plugin
        self.current_task = None

        self.setWindowTitle(tr("geotiff_title"))
        self.resize(480, 290)
        self.setWindowFlags(self.windowFlags() | WINDOW_MIN | WINDOW_CLOSE)
        self.setWindowModality(NON_MODAL)

        styles = get_theme_styles()
        self.setStyleSheet(styles["dialog_style"])

        layout = QVBoxLayout(self)

        sensor = self.ws.combo_sensor.currentText()
        filt = self.ws.combo_filter.currentText()
        date_str = self.ws.current_left_date

        self.info_lbl = QLabel(f"{tr('exporting_info')} <b>{sensor} {filt} ({date_str})</b>")
        layout.addWidget(self.info_lbl)

        # Resolution dropdown
        res_layout = QHBoxLayout()
        self.lbl_target_res = QLabel(f"<b>{tr('target_res')}</b>")
        res_layout.addWidget(self.lbl_target_res)
        self.combo_res = QComboBox()
        self.combo_res.addItem(tr("native_10m"), 1)
        self.combo_res.addItem(tr("ai_2x"), 2)
        self.combo_res.addItem(tr("ai_4x"), 4)
        res_layout.addWidget(self.combo_res)
        layout.addLayout(res_layout)

        # Add to project checkbox
        self.chk_add_to_project = QCheckBox(tr("add_to_project"))
        self.chk_add_to_project.setChecked(True)
        layout.addWidget(self.chk_add_to_project)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.progress.hide()

        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color: #00d4ff; font-size: 11px;" if styles["is_dark"] else "color: #006699; font-size: 11px;")
        layout.addWidget(self.lbl_status)

        layout.addStretch()

        btn_layout = QHBoxLayout()
        self.btn_export = QPushButton(tr("export_btn"))
        self.btn_export.clicked.connect(self._start_export)
        self.btn_cancel = QPushButton(tr("close"))
        self.btn_cancel.clicked.connect(self._on_close_clicked)

        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_export)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

    def apply_theme(self):
        styles = get_theme_styles()
        self.setStyleSheet(styles["dialog_style"])
        if hasattr(self, 'lbl_status'):
            self.lbl_status.setStyleSheet("color: #00d4ff; font-size: 11px;" if styles["is_dark"] else "color: #006699; font-size: 11px;")

    def apply_language(self):
        self.setWindowTitle(tr("geotiff_title"))
        sensor = self.ws.combo_sensor.currentText()
        filt = self.ws.combo_filter.currentText()
        date_str = self.ws.current_left_date
        if hasattr(self, 'info_lbl'):
            self.info_lbl.setText(f"{tr('exporting_info')} <b>{sensor} {filt} ({date_str})</b>")
        if hasattr(self, 'lbl_target_res'):
            self.lbl_target_res.setText(f"<b>{tr('target_res')}</b>")
        if hasattr(self, 'combo_res'):
            curr_idx = self.combo_res.currentIndex()
            self.combo_res.blockSignals(True)
            self.combo_res.setItemText(0, tr("native_10m"))
            self.combo_res.setItemText(1, tr("ai_2x"))
            self.combo_res.setItemText(2, tr("ai_4x"))
            self.combo_res.blockSignals(False)
        if hasattr(self, 'chk_add_to_project'):
            self.chk_add_to_project.setText(tr("add_to_project"))
        if hasattr(self, 'btn_export'):
            if not self.current_task:
                self.btn_export.setText(tr("export_btn"))
            else:
                self.btn_export.setText(tr("cancel_export"))
        if hasattr(self, 'btn_cancel'):
            self.btn_cancel.setText(tr("close"))

    def _start_export(self):
        sensor = self.ws.combo_sensor.currentText()
        filt = self.ws.combo_filter.currentText()
        date_str = self.ws.current_left_date
        scale = self.combo_res.currentData()

        scale_tag = f"_{scale}x" if scale > 1 else ""
        default_filename = f"Satiladu_{sensor}_{filt}_{date_str}{scale_tag}.tif"
        out_path, _ = QFileDialog.getSaveFileName(self, "Save GeoTIFF", default_filename, "GeoTIFF (*.tif);;All Files (*.*)")
        if not out_path:
            return

        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
        xmin, ymin, xmax, ymax = map(float, bbox_3301.split(','))
        ext_w = xmax - xmin
        ext_h = ymax - ymin

        native_w = max(64, int(round(ext_w / 10.0)))
        native_h = max(64, int(round(ext_h / 10.0)))

        target_w = native_w * scale
        target_h = native_h * scale

        # Check model if upscale requested
        model_path = None
        if scale > 1:
            model_name = f"Real-ESRGAN {scale}x"
            info = get_model_info(model_name)
            model_path = info.get("path")
            if not model_path or not os.path.exists(model_path):
                QMessageBox.warning(self, tr("model_missing_title"), tr("model_missing_msg").format(model_name=model_name))
                return

        # Get url
        import datetime
        _, url = self.ws._get_closest_valid_date(datetime.date.fromisoformat(date_str))
        if not url:
            QMessageBox.warning(self, tr("url_missing_title"), tr("url_missing_msg"))
            return

        self.btn_export.setEnabled(False)
        self.combo_res.setEnabled(False)
        self.btn_cancel.setText(tr("cancel_export"))
        self.progress.show()
        self.progress.setValue(5)
        self.lbl_status.setText(tr("exporting_bg"))

        task = GeoTiffExportTask(
            bbox_3301, target_w, target_h, url, out_path,
            model_path=model_path, target_scale=scale,
            callback=self._on_export_done
        )
        task.sig_progress.connect(self._on_task_progress)
        self.current_task = task
        QgsApplication.taskManager().addTask(task)

    def _on_task_progress(self, pct, msg):
        self.progress.setValue(pct)
        self.lbl_status.setText(f"{msg} ({pct}%)")

    def _on_export_done(self, success, out_path):
        self.progress.hide()
        self.btn_export.setEnabled(True)
        self.combo_res.setEnabled(True)
        self.btn_cancel.setText(tr("close"))
        self.current_task = None

        if success and os.path.exists(out_path):
            self.lbl_status.setText(tr("export_complete_title"))
            if self.chk_add_to_project.isChecked():
                layer = QgsRasterLayer(out_path, os.path.splitext(os.path.basename(out_path))[0], "gdal")
                if layer.isValid():
                    QgsProject.instance().addMapLayer(layer)
                    self.plugin.log(f"Exported GeoTIFF added to project: {out_path}", Qgis.Success)
            QMessageBox.information(self, tr("export_complete_title"), f"{tr('export_complete_msg')}\n{out_path}")
            self.accept()
        else:
            self.lbl_status.setText("Export was canceled or failed.")
            if not (self.current_task and self.current_task.isCanceled()):
                QMessageBox.critical(self, "Export Failed", "Failed to export GeoTIFF. Check QGIS Log Messages panel for details.")

    def _on_close_clicked(self):
        if self.current_task:
            reply = QMessageBox.question(
                self,
                "Cancel Export?",
                "GeoTIFF export is currently in progress. Do you want to cancel it?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.current_task.cancel()
                self.lbl_status.setText("Canceling export...")
                self.btn_cancel.setEnabled(False)
        else:
            self.close()

    def closeEvent(self, event):
        if self.current_task:
            try:
                self.current_task.cancel()
            except Exception:
                pass
            self.current_task = None
        super().closeEvent(event)
