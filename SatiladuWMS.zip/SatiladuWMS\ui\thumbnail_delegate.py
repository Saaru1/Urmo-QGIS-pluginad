# -*- coding: utf-8 -*-
import datetime
from qgis.PyQt.QtCore import Qt, QSize, QRect
from qgis.PyQt.QtGui import QColor, QFont, QPen, QPainter
from qgis.PyQt.QtWidgets import QStyledItemDelegate, QStyle
from .i18n import tr


class ThumbnailDelegate(QStyledItemDelegate):
    def __init__(self, plugin, dark_mode=True, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.dark_mode = dark_mode

        try:
            self.state_selected = QStyle.StateFlag.State_Selected
            self.state_mouseover = QStyle.StateFlag.State_MouseOver
            self.user_role = Qt.ItemDataRole.UserRole
        except AttributeError:
            self.state_selected = QStyle.State_Selected
            self.state_mouseover = QStyle.State_MouseOver
            self.user_role = Qt.UserRole

    def paint(self, painter, option, index):
        data = index.data(self.user_role)
        if not data:
            return

        painter.save()

        try:
            antialiasing = QPainter.RenderHint.Antialiasing
            align = Qt.AlignmentFlag.AlignCenter
            no_brush = Qt.BrushStyle.NoBrush
        except AttributeError:
            antialiasing = QPainter.Antialiasing
            align = Qt.AlignCenter
            no_brush = Qt.BrushStyle.NoBrush

        painter.setRenderHint(antialiasing, True)

        dstr, base_url, thumb_url = data
        dt_str = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")

        is_selected = bool(option.state & self.state_selected)
        is_hover = bool(option.state & self.state_mouseover)

        # 1. Seamless Date Text floating above thumbnail:
        # ALWAYS crisp pure white in both Light and Dark modes.
        # Uses a subtle 1px dark drop-shadow halo for 100% readability over bright clouds or map canvas.
        font = painter.font()
        try:
            font.setWeight(QFont.Weight.Bold)
        except AttributeError:
            font.setWeight(QFont.Bold)
        font.setPointSize(8)
        painter.setFont(font)

        text_rect = QRect(option.rect.x(), option.rect.y() + 5, option.rect.width(), 16)

        # Shadow for contrast against light canvas / clouds
        painter.setPen(QColor(0, 0, 0, 220))
        painter.drawText(text_rect.translated(1, 1), align, dt_str)
        # Foreground pure white in both modes
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(text_rect, align, dt_str)

        # 2. Thumbnail image floating directly without background boxes
        thumb_size = 110
        thumb_x = option.rect.x() + (option.rect.width() - thumb_size) // 2
        thumb_y = option.rect.y() + 25
        thumb_rect = QRect(thumb_x, thumb_y, thumb_size, thumb_size)

        pixmap = self.plugin.thumbnail_manager.cache.get(thumb_url)
        if pixmap:
            painter.drawPixmap(thumb_rect, pixmap)
            if is_selected:
                painter.setPen(QPen(QColor("#0078d7"), 2))
            elif is_hover:
                painter.setPen(QPen(QColor("#5ce1e6"), 1.5))
            else:
                painter.setPen(QPen(QColor(60, 60, 60, 200), 1))
            painter.setBrush(no_brush)
            painter.drawRect(thumb_rect)
        else:
            ph_bg = QColor("#1e1e22")
            painter.fillRect(thumb_rect, ph_bg)
            painter.setPen(QPen(QColor("#444"), 1))
            painter.drawRect(thumb_rect)
            painter.setPen(QColor("#ffffff"))
            painter.drawText(thumb_rect, align, tr("loading"))

        painter.restore()

    def sizeHint(self, option, index):
        return QSize(130, 145)
