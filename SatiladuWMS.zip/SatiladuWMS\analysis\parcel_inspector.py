# -*- coding: utf-8 -*-
import datetime
import os
import io
import urllib.request
import numpy as np
from PIL import Image

from qgis.core import (
    QgsProject, QgsCoordinateTransform, QgsCoordinateReferenceSystem,
    QgsPointXY, QgsTask, QgsApplication, QgsBlockingNetworkRequest, Qgis, QgsMessageLog,
    QgsMapLayer, QgsRectangle, QgsFeatureRequest, QgsGeometry
)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker, QgsHighlight
from qgis.PyQt.QtCore import Qt, QUrl, QRect, QPointF, pyqtSignal, QDate
from qgis.PyQt.QtGui import QPainter, QColor, QPen, QBrush, QFont, QCursor
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QWidget, QMessageBox, QProgressBar, QFrame, QDateEdit
)
from qgis.PyQt.QtNetwork import QNetworkRequest
from ..ui.i18n import tr
from ..ui.theme_manager import get_theme_styles, is_dark
from ..satiladu_api import SatiladuAPI

try:
    ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    ALIGN_LEFT = Qt.AlignmentFlag.AlignLeft
    CROSS_CURSOR = Qt.CursorShape.CrossCursor
    DASH_LINE = Qt.PenStyle.DashLine
    WINDOW_MIN = Qt.WindowType.WindowMinimizeButtonHint
    WINDOW_CLOSE = Qt.WindowType.WindowCloseButtonHint
    NON_MODAL = Qt.WindowModality.NonModal
except AttributeError:
    ALIGN_CENTER = Qt.AlignCenter
    ALIGN_LEFT = Qt.AlignLeft
    CROSS_CURSOR = Qt.CrossCursor
    DASH_LINE = Qt.DashLine
    WINDOW_MIN = Qt.WindowMinimizeButtonHint
    WINDOW_CLOSE = Qt.WindowCloseButtonHint
    NON_MODAL = Qt.NonModal


def detect_mowing_events(points, filter_start_date=None, filter_end_date=None):
    """
    Analyzes multi-temporal vegetation index trajectory to detect and predict mowing events.
    Calibrated for Estonian grasslands and PRIA semi-natural meadows (Pärandniidud).
    Distinguishes physical biomass drops from isolated atmospheric cloud notches.
    points: list of (dt_obj, value, dstr)
    filter_start_date: datetime.date or None (defaults to May 1st / June 1st)
    filter_end_date: datetime.date or None (defaults to August 31st / Oct 31st)
    """
    if len(points) < 2:
        return []

    # Ensure chronological order
    sorted_pts = sorted(points, key=lambda x: x[0])
    n = len(sorted_pts)

    raw_candidates = []

    for i in range(n - 1):
        dt_pre, val_pre, dstr_pre = sorted_pts[i]
        dt_post, val_post, dstr_post = sorted_pts[i + 1]

        # Enforce timeframe filter
        if filter_start_date and dt_post < filter_start_date:
            continue
        if filter_end_date and dt_pre > filter_end_date:
            continue

        # Default mowing season in Estonia: May 15 to September 30
        if not filter_start_date and not (5 <= dt_pre.month <= 9):
            continue

        days_gap = (dt_post - dt_pre).days
        if days_gap > 45:
            continue

        drop = val_post - val_pre
        pct_drop = (drop / max(0.01, val_pre)) * 100.0

        # MOWING CRITERION 1: Minimum baseline vegetative canopy before cut
        # Estonian meadows & PRIA Pärandniidud often establish canopy around 0.35-0.55
        if val_pre < 0.35:
            continue

        # MOWING CRITERION 2: Biomass reduction threshold & 3-tier classification
        # High confidence: clear, sharp drop (-16% to -45% or drop <= -0.16)
        is_high_cand = (drop <= -0.16 or pct_drop <= -22.0)
        # Medium confidence: substantial mowing (-10% to -18% or drop <= -0.10)
        is_med_cand = (drop <= -0.10 and pct_drop <= -12.0) or (pct_drop <= -15.0) or (drop <= -0.13)
        # Low confidence: subtle / partial mowing (e.g. on huge parcels like 98 ha where only a section was cut)
        is_low_cand = (drop <= -0.06 and pct_drop <= -7.5) or (pct_drop <= -10.0) or (drop <= -0.08)

        if not (is_high_cand or is_med_cand or is_low_cand):
            continue

        # MOWING CRITERION 3: Atmospheric / Cloud Notch Rejection
        # A true cloud spike is an isolated dip that rapidly bounces back to near pre-drop level.
        # In real mowing, the grass stays cut and suppressed for weeks.
        is_cloud_spike = False
        post_obs_count = 0
        sum_post_vals = 0.0

        for k in range(i + 2, n):
            dt_k, val_k, _ = sorted_pts[k]
            gap_k = (dt_k - dt_post).days
            if gap_k > 24:
                break

            post_obs_count += 1
            sum_post_vals += val_k

            # Cloud check: if observation within 14 days recovers to >= (val_pre - 0.03), it was a cloud dip!
            if gap_k <= 14 and val_k >= (val_pre - 0.03):
                is_cloud_spike = True
                break

            # Biological regrowth check: mown grass in Estonia cannot regrow by > 0.025 index units / day
            rebound_k = val_k - val_post
            if gap_k > 0 and (rebound_k / float(gap_k)) > 0.025:
                is_cloud_spike = True
                break

        if is_cloud_spike:
            continue

        # MOWING CRITERION 4: Sustained Post-Cut Suppression & 3-Tier Confidence Grading
        if post_obs_count > 0:
            avg_post = sum_post_vals / post_obs_count
            # Average post-cut canopy must remain lower than pre-cut baseline
            if avg_post > (val_pre - 0.03):
                continue

            if is_high_cand and avg_post <= (val_pre - 0.08):
                conf_level = "high"
                confidence = tr("conf_high")
            elif (is_med_cand or is_high_cand) and avg_post <= (val_pre - 0.04):
                conf_level = "medium"
                confidence = tr("conf_medium")
            else:
                conf_level = "low"
                confidence = tr("conf_low")
        else:
            if is_high_cand:
                conf_level = "high"
                confidence = tr("conf_high")
            elif is_med_cand:
                conf_level = "medium"
                confidence = tr("conf_medium")
            else:
                conf_level = "low"
                confidence = tr("conf_low")

        raw_candidates.append({
            "start_date": dstr_pre,
            "end_date": dstr_post,
            "dt_pre": dt_pre,
            "dt_post": dt_post,
            "drop_val": drop,
            "drop_pct": pct_drop,
            "pre_val": val_pre,
            "post_val": val_post,
            "confidence": confidence,
            "conf_level": conf_level,
            "idx_pre": i,
            "idx_post": i + 1
        })

    # MOWING CRITERION 5: Minimum Cut Interval
    # Grasslands in Estonia cannot be mown twice within < 24 days.
    # Keep only the cut with the greatest drop magnitude if candidates conflict.
    filtered_events = []
    for cand in raw_candidates:
        if not filtered_events:
            filtered_events.append(cand)
        else:
            last = filtered_events[-1]
            gap = (cand["dt_post"] - last["dt_post"]).days
            if gap < 24:
                if abs(cand["drop_val"]) > abs(last["drop_val"]):
                    filtered_events[-1] = cand
            else:
                filtered_events.append(cand)

    return filtered_events


class TimeSeriesPlotWidget(QWidget):
    """High-performance QPainter line chart for vegetation reflectance trajectory and mowing detection."""
    dateClicked = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data_points = []  # list of (date_obj, value, dstr)
        self.mowing_events = []
        self.hovered_idx = -1
        self.setMouseTracking(True)
        self.setMinimumHeight(240)

    def set_data(self, points, events=None):
        """points: list of tuples (date_str, value)"""
        parsed = []
        for dstr, val in points:
            try:
                dt = datetime.date.fromisoformat(dstr)
                parsed.append((dt, float(val), dstr))
            except Exception:
                pass
        parsed.sort(key=lambda x: x[0])
        self.data_points = parsed
        self.mowing_events = events if events is not None else detect_mowing_events(parsed)
        self.update()

    def set_mowing_events(self, events):
        self.mowing_events = events
        self.update()

    def mouseMoveEvent(self, event):
        if not self.data_points:
            return
        w, h = self.width(), self.height()
        pad_l, pad_r, pad_t, pad_b = 55, 25, 25, 45
        plot_w = w - pad_l - pad_r

        pos_x = event.position().x() if hasattr(event, 'position') else event.x()
        closest_idx = -1
        min_dist = 25.0

        n = len(self.data_points)
        for i, (dt, val, dstr) in enumerate(self.data_points):
            px = pad_l + (i / max(1, n - 1)) * plot_w
            dist = abs(pos_x - px)
            if dist < min_dist:
                min_dist = dist
                closest_idx = i

        if closest_idx != self.hovered_idx:
            self.hovered_idx = closest_idx
            self.update()

    def mousePressEvent(self, event):
        if self.hovered_idx >= 0 and self.hovered_idx < len(self.data_points):
            dstr = self.data_points[self.hovered_idx][2]
            self.dateClicked.emit(dstr)

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        except AttributeError:
            painter.setRenderHint(QPainter.Antialiasing)

        styles = get_theme_styles()
        dark = styles["is_dark"]

        w, h = self.width(), self.height()
        pad_l, pad_r, pad_t, pad_b = 55, 25, 25, 45
        plot_w = w - pad_l - pad_r
        plot_h = h - pad_t - pad_b

        # Background
        bg_col = QColor(25, 25, 28) if dark else QColor(250, 250, 252)
        painter.fillRect(0, 0, w, h, bg_col)

        # Border
        painter.setPen(QPen(QColor(60, 60, 65) if dark else QColor(210, 212, 220), 1))
        painter.drawRect(0, 0, w - 1, h - 1)

        if not self.data_points:
            painter.setPen(QColor(160, 160, 160) if dark else QColor(100, 100, 100))
            painter.drawText(QRect(0, 0, w, h), ALIGN_CENTER, tr("no_samples"))
            painter.end()
            return

        values = [p[1] for p in self.data_points]
        min_v = min(0.0, min(values))
        max_v = max(1.0, max(values) * 1.15)

        # Draw gridlines & Y-axis labels
        grid_col = QColor(60, 60, 65) if dark else QColor(220, 222, 228)
        lbl_col = QColor(160, 160, 170) if dark else QColor(80, 80, 85)
        painter.setFont(QFont("Arial", 8))

        steps = 4
        for s in range(steps + 1):
            y_val = min_v + (s / steps) * (max_v - min_v)
            py = pad_t + plot_h - (s / steps) * plot_h
            painter.setPen(QPen(grid_col, 1, DASH_LINE))
            painter.drawLine(int(pad_l), int(py), int(w - pad_r), int(py))

            painter.setPen(lbl_col)
            painter.drawText(5, int(py + 4), f"{y_val:.2f}")

        # Compute screen points
        n = len(self.data_points)
        screen_pts = []
        for i, (dt, val, dstr) in enumerate(self.data_points):
            px = pad_l + (i / max(1, n - 1)) * plot_w
            norm_y = (val - min_v) / max(1e-4, max_v - min_v)
            py = pad_t + plot_h - norm_y * plot_h
            screen_pts.append((px, py, dt, val, dstr))

        # Highlight detected mowing timeframe zones with 3 confidence color grades (Green, Yellow, Orange)
        for ev in self.mowing_events:
            idx_a = ev["idx_pre"]
            idx_b = ev["idx_post"]
            if idx_a < len(screen_pts) and idx_b < len(screen_pts):
                xa = screen_pts[idx_a][0]
                xb = screen_pts[idx_b][0]
                zone_w = max(28.0, xb - xa)

                conf_lvl = ev.get("conf_level", "medium")
                if conf_lvl == "high":
                    # GREEN - High Confidence
                    zone_col = QColor(16, 185, 129, 45 if dark else 55)
                    line_col = QColor(16, 185, 129, 210)
                    badge_border = QColor(52, 211, 153) if dark else QColor(16, 185, 129)
                    badge_bg = QColor(12, 42, 25, 235) if dark else QColor(236, 253, 245, 245)
                    badge_text_col = QColor(110, 231, 183) if dark else QColor(4, 120, 87)
                    badge_label = f"🚜 {tr('conf_high_short')}"
                elif conf_lvl == "low":
                    # ORANGE - Low Confidence / Partial Mowing
                    zone_col = QColor(249, 115, 22, 45 if dark else 55)
                    line_col = QColor(249, 115, 22, 210)
                    badge_border = QColor(251, 146, 60) if dark else QColor(234, 88, 12)
                    badge_bg = QColor(48, 24, 10, 235) if dark else QColor(255, 247, 237, 245)
                    badge_text_col = QColor(253, 186, 116) if dark else QColor(194, 65, 12)
                    badge_label = f"🚜 {tr('conf_low_short')}"
                else:
                    # YELLOW - Medium / Mediocre Confidence
                    zone_col = QColor(234, 179, 8, 45 if dark else 55)
                    line_col = QColor(234, 179, 8, 210)
                    badge_border = QColor(250, 204, 21) if dark else QColor(202, 138, 4)
                    badge_bg = QColor(44, 34, 10, 235) if dark else QColor(254, 252, 232, 245)
                    badge_text_col = QColor(253, 224, 71) if dark else QColor(161, 98, 7)
                    badge_label = f"🚜 {tr('conf_med_short')}"

                # Shaded vertical zone
                painter.fillRect(int(xa), int(pad_t), int(zone_w), int(plot_h), zone_col)

                # Boundary lines
                painter.setPen(QPen(line_col, 1, DASH_LINE))
                painter.drawLine(int(xa), int(pad_t), int(xa), int(pad_t + plot_h))
                painter.drawLine(int(xb), int(pad_t), int(xb), int(pad_t + plot_h))

                # Mowed badge
                center_x = (xa + xb) / 2.0
                painter.setPen(QPen(badge_border, 1))
                painter.setBrush(QBrush(badge_bg))
                badge_w = max(86, len(badge_label) * 8 + 14)
                badge_rect = QRect(int(center_x - badge_w // 2), int(pad_t + 8), badge_w, 20)
                painter.drawRoundedRect(badge_rect, 3, 3)
                painter.setPen(badge_text_col)
                painter.drawText(badge_rect, ALIGN_CENTER, badge_label)

        # Fill subtle gradient under curve
        if len(screen_pts) > 1:
            from qgis.PyQt.QtGui import QPainterPath
            path = QPainterPath()
            path.moveTo(screen_pts[0][0], pad_t + plot_h)
            for pt in screen_pts:
                path.lineTo(pt[0], pt[1])
            path.lineTo(screen_pts[-1][0], pad_t + plot_h)
            path.closeSubpath()
            fill_col = QColor(0, 180, 255, 35 if dark else 45)
            painter.fillPath(path, QBrush(fill_col))

        # Draw line chart
        pen_line = QPen(QColor(0, 180, 255) if dark else QColor(0, 120, 215), 2)
        painter.setPen(pen_line)
        for i in range(len(screen_pts) - 1):
            p1 = screen_pts[i]
            p2 = screen_pts[i + 1]
            painter.drawLine(QPointF(p1[0], p1[1]), QPointF(p2[0], p2[1]))

        # Draw points
        for i, (px, py, dt, val, dstr) in enumerate(screen_pts):
            is_hover = (i == self.hovered_idx)
            radius = 6 if is_hover else 3.5
            color = QColor(255, 220, 40) if is_hover else (QColor(0, 220, 255) if dark else QColor(0, 120, 215))

            painter.setPen(QPen(QColor(255, 255, 255) if dark else QColor(40, 40, 45), 1))
            painter.setBrush(QBrush(color))
            painter.drawEllipse(QPointF(px, py), radius, radius)

        # Draw clean, non-overlapping X date labels
        last_drawn_x = -9999
        min_label_gap = 58  # minimum horizontal distance in px between labels

        if n <= 6:
            label_indices = list(range(n))
        else:
            step = max(1, n // 6)
            label_indices = list(range(0, n, step))
            if (n - 1) not in label_indices:
                if len(label_indices) > 1 and (screen_pts[n - 1][0] - screen_pts[label_indices[-1]][0] < min_label_gap):
                    label_indices[-1] = n - 1
                else:
                    label_indices.append(n - 1)

        painter.setPen(lbl_col)
        for idx in label_indices:
            px, py, dt, val, dstr = screen_pts[idx]
            date_txt = dt.strftime("%d.%m.%y")
            lbl_w = 52
            lx = int(px - lbl_w / 2)
            lx = max(int(pad_l - 8), min(lx, int(w - pad_r - lbl_w + 8)))

            if lx >= last_drawn_x + min_label_gap or (idx == n - 1 and lx > last_drawn_x + 35):
                painter.drawText(QRect(lx, int(h - pad_b + 12), lbl_w, 20), ALIGN_CENTER, date_txt)
                last_drawn_x = lx

        # Draw hover tooltip
        if 0 <= self.hovered_idx < len(screen_pts):
            hx, hy, hdt, hval, hdstr = screen_pts[self.hovered_idx]
            tt_txt = f"{hdstr}: {hval:.3f}"

            for ev in self.mowing_events:
                if self.hovered_idx == ev["idx_post"]:
                    conf_tag = ev.get("conf_level", "medium").upper()
                    tt_txt += f"  (🚜 Cut: {ev['drop_pct']:.0f}% [{conf_tag}])"
                    break

            painter.setPen(QPen(QColor(0, 120, 215), 1))
            painter.setBrush(QBrush(QColor(20, 20, 25, 245) if dark else QColor(255, 255, 255, 245)))
            box_w = max(130, len(tt_txt) * 7 + 20)
            painter.drawRoundedRect(int(hx - box_w // 2), int(hy - 34), box_w, 26, 4, 4)
            painter.setPen(QColor(255, 255, 255) if dark else QColor(20, 20, 25))
            painter.drawText(QRect(int(hx - box_w // 2), int(hy - 34), box_w, 26), ALIGN_CENTER, tt_txt)

        painter.end()


class TimeSeriesDialog(QDialog):
    def __init__(self, pt_3301, pt_4326, sensor, filt, workspace, parcel_info=None, parent=None):
        super().__init__(parent)
        self.pt_3301 = pt_3301
        self.pt_4326 = pt_4326
        self.sensor = sensor
        self.filt = filt
        self.ws = workspace
        self.parcel_info = parcel_info or {}
        self.geom_3301 = self.parcel_info.get("geom_3301", None)
        self.sample_cache = {}
        self.samples = []
        self.mowing_events = []
        self.current_task = None
        self.parcel_api = SatiladuAPI()
        self.known_urls = {}
        self.cloudless_urls = {}

        # Timeframe filter state (default: June 1 to August 31)
        curr_year = datetime.date.today().year
        if hasattr(self.ws, 'current_left_date') and self.ws.current_left_date:
            try:
                curr_year = datetime.date.fromisoformat(self.ws.current_left_date).year
            except Exception:
                pass
        self.curr_year = curr_year
        self.timeframe_start = datetime.date(curr_year, 6, 1)
        self.timeframe_end = datetime.date(curr_year, 8, 31)
        self.timeframe_mode = "summer"

        self.setWindowTitle(tr("inspector_title"))
        self.resize(780, 560)
        self.setWindowFlags(self.windowFlags() | WINDOW_MIN | WINDOW_CLOSE)
        self.setWindowModality(NON_MODAL)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        except AttributeError:
            self.setAttribute(Qt.WA_StyledBackground, True)

        self.styles = get_theme_styles()
        dark = self.styles.get("is_dark", True)

        layout = QVBoxLayout(self)

        # Header with parcel info or coordinate display
        header_layout = QHBoxLayout()
        self.lbl_info = QLabel()
        self._update_header_text()
        header_layout.addWidget(self.lbl_info)
        header_layout.addStretch()

        self.btn_pick_vector = QPushButton(tr("pick_vector"))
        self.btn_pick_vector.setStyleSheet("background-color: #0078d7; color: white; padding: 5px 12px; font-weight: bold; font-size: 11px;")
        self.btn_pick_vector.setToolTip(tr("tip_pick_vector"))
        self.btn_pick_vector.clicked.connect(self._on_pick_parcel_clicked)
        header_layout.addWidget(self.btn_pick_vector)

        self.btn_select_vector = QPushButton(tr("load_selection"))
        btn_sel_style = (
            "background-color: #3b3b44; color: #ddd; border: 1px solid #555; padding: 5px 10px; font-size: 11px;"
            if dark else
            "background-color: #f1f3f7; color: #1e1e24; border: 1px solid #cbd0dd; padding: 5px 10px; font-size: 11px;"
        )
        self.btn_select_vector.setStyleSheet(btn_sel_style)
        self.btn_select_vector.clicked.connect(self._load_active_vector_selection)
        header_layout.addWidget(self.btn_select_vector)
        layout.addLayout(header_layout)

        subtitle_str = f"{tr('sensor_label')} <b>{sensor}</b> | {tr('spectral_product_label')} <b>{filt}</b> + {tr('veg_index_calibration')}"
        self.lbl_sub = QLabel(subtitle_str)
        layout.addWidget(self.lbl_sub)

        # Timeframe Profiles & Custom Date Bar
        self.tf_frame = QFrame()
        tf_layout = QHBoxLayout(self.tf_frame)
        tf_layout.setContentsMargins(8, 4, 8, 4)
        tf_layout.setSpacing(6)

        self.lbl_timeframe = QLabel(f"<b>{tr('timeframe')}</b>")
        tf_layout.addWidget(self.lbl_timeframe)

        self.btn_preset_summer = QPushButton(tr("preset_summer"))
        self.btn_preset_summer.setCheckable(True)
        self.btn_preset_summer.setChecked(True)
        self.btn_preset_summer.clicked.connect(lambda: self._set_timeframe_preset("summer"))
        tf_layout.addWidget(self.btn_preset_summer)

        self.btn_preset_ext = QPushButton(tr("preset_ext"))
        self.btn_preset_ext.setCheckable(True)
        self.btn_preset_ext.clicked.connect(lambda: self._set_timeframe_preset("ext"))
        tf_layout.addWidget(self.btn_preset_ext)

        self.btn_preset_season = QPushButton(tr("preset_season"))
        self.btn_preset_season.setCheckable(True)
        self.btn_preset_season.clicked.connect(lambda: self._set_timeframe_preset("season"))
        tf_layout.addWidget(self.btn_preset_season)

        tf_layout.addSpacing(10)
        tf_layout.addWidget(QLabel("<span style='color:#777;'>|</span>"))
        tf_layout.addSpacing(6)

        # Optional Custom Date Range
        self.lbl_custom = QLabel(tr("custom_dates_label"))
        tf_layout.addWidget(self.lbl_custom)

        self.date_start = QDateEdit()
        self.date_start.setCalendarPopup(True)
        self.date_start.setDisplayFormat("dd.MM.yyyy")
        self.date_start.setDate(QDate(self.timeframe_start.year, self.timeframe_start.month, self.timeframe_start.day))
        self.date_start.dateChanged.connect(self._on_custom_date_changed)
        tf_layout.addWidget(self.date_start)

        tf_layout.addWidget(QLabel("–"))

        self.date_end = QDateEdit()
        self.date_end.setCalendarPopup(True)
        self.date_end.setDisplayFormat("dd.MM.yyyy")
        self.date_end.setDate(QDate(self.timeframe_end.year, self.timeframe_end.month, self.timeframe_end.day))
        self.date_end.dateChanged.connect(self._on_custom_date_changed)
        tf_layout.addWidget(self.date_end)

        tf_layout.addStretch()
        layout.addWidget(self.tf_frame)

        # Mowing Prediction Status Card
        self.frame_mowing = QFrame()
        mowing_vbox = QVBoxLayout(self.frame_mowing)
        mowing_vbox.setContentsMargins(8, 6, 8, 6)
        mowing_vbox.setSpacing(3)

        self.lbl_mowing_title = QLabel(tr("mowing_status_analyzing"))
        mowing_vbox.addWidget(self.lbl_mowing_title)

        self.lbl_mowing_details = QLabel("Sampling cloudless Sentinel-2 acquisitions to evaluate seasonal biomass drop and regrowth.")
        mowing_vbox.addWidget(self.lbl_mowing_details)
        layout.addWidget(self.frame_mowing)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)

        self.plot_widget = TimeSeriesPlotWidget(self)
        self.plot_widget.dateClicked.connect(self._on_chart_date_clicked)
        layout.addWidget(self.plot_widget, 1)

        bottom_layout = QHBoxLayout()
        self.lbl_hint = QLabel(tr("tip_chart"))
        bottom_layout.addWidget(self.lbl_hint)
        bottom_layout.addStretch()

        self.btn_export = QPushButton(tr("export_csv"))
        self.btn_export.clicked.connect(self._export_csv)
        self.btn_export.setEnabled(False)
        bottom_layout.addWidget(self.btn_export)

        self.btn_close = QPushButton(tr("close"))
        self.btn_close.clicked.connect(self.close)
        bottom_layout.addWidget(self.btn_close)
        layout.addLayout(bottom_layout)

        self.apply_theme()
        self._start_sampling()

    def apply_theme(self):
        self.styles = get_theme_styles()
        dark = self.styles.get("is_dark", True)

        dlg_bg = "#222226" if dark else "#ffffff"
        dlg_fg = "#ffffff" if dark else "#111827"
        self.setStyleSheet(f"QDialog {{ background-color: {dlg_bg}; color: {dlg_fg}; }}")

        self._update_header_text()
        if hasattr(self, 'lbl_sub'):
            self.lbl_sub.setStyleSheet("color: #aaa; font-size: 11px; margin-bottom: 2px;" if dark else "color: #4b5563; font-size: 11px; margin-bottom: 2px;")

        if hasattr(self, 'btn_select_vector'):
            btn_sel_style = (
                "background-color: #3b3b44; color: #ddd; border: 1px solid #555; padding: 5px 10px; font-size: 11px;"
                if dark else
                "background-color: #f1f3f7; color: #1e1e24; border: 1px solid #cbd0dd; padding: 5px 10px; font-size: 11px;"
            )
            self.btn_select_vector.setStyleSheet(btn_sel_style)

        if hasattr(self, 'tf_frame'):
            self.tf_frame.setStyleSheet(
                f"background: {'#202124' if dark else '#f8fafc'}; border: 1px solid {'#3c4043' if dark else '#e2e8f0'}; border-radius: 4px; padding: 2px;"
            )

        if hasattr(self, 'lbl_timeframe'):
            self.lbl_timeframe.setStyleSheet("color: #ffffff; font-weight: bold;" if dark else "color: #111827; font-weight: bold;")

        if hasattr(self, 'lbl_custom'):
            self.lbl_custom.setStyleSheet("color: #bbb; font-size: 11px;" if dark else "color: #4b5563; font-size: 11px;")

        self._update_preset_button_styles()

        date_style = (
            "QDateEdit { background-color: #2b2b2f; color: #ffffff; border: 1px solid #5a5a60; border-radius: 3px; padding: 3px 6px; font-size: 11px; } "
            "QDateEdit::drop-down { border: none; } "
            "QDateEdit QAbstractItemView { background-color: #2b2b2f; color: #ffffff; selection-background-color: #0078d7; }"
            if dark else
            "QDateEdit { background-color: #ffffff; color: #111827; border: 1px solid #cbd0dd; border-radius: 3px; padding: 3px 6px; font-size: 11px; } "
            "QDateEdit::drop-down { border: none; } "
            "QDateEdit QAbstractItemView { background-color: #ffffff; color: #111827; selection-background-color: #0078d7; selection-color: white; }"
        )
        if hasattr(self, 'date_start'):
            self.date_start.setStyleSheet(date_style)
        if hasattr(self, 'date_end'):
            self.date_end.setStyleSheet(date_style)

        if hasattr(self, 'progress'):
            self.progress.setStyleSheet("QProgressBar { background: #222; border: 1px solid #555; border-radius: 3px; height: 12px; text-align: center; } QProgressBar::chunk { background: #0078d7; }" if dark else "QProgressBar { background: #e8eaf0; border: 1px solid #cbd0dd; border-radius: 3px; height: 12px; text-align: center; } QProgressBar::chunk { background: #0078d7; }")

        if hasattr(self, 'btn_close'):
            self.btn_close.setStyleSheet("background-color: #38383c; color: #eee; border: 1px solid #5a5a60; padding: 6px 14px;" if dark else "background-color: #f1f3f7; color: #1e1e24; border: 1px solid #cbd0dd; padding: 6px 14px;")

        if hasattr(self, 'lbl_hint'):
            self.lbl_hint.setStyleSheet("color: #aaa; font-style: italic; font-size: 11px;" if dark else "color: #6b7280; font-style: italic; font-size: 11px;")

        self._update_mowing_prediction_banner()
        if hasattr(self, 'plot_widget'):
            self.plot_widget.update()

    def apply_language(self):
        self.setWindowTitle(tr("inspector_title"))
        if hasattr(self, 'btn_pick_vector'):
            self.btn_pick_vector.setText(tr("pick_vector"))
            self.btn_pick_vector.setToolTip(tr("tip_pick_vector"))
        if hasattr(self, 'btn_load_selection'):
            self.btn_load_selection.setText(tr("load_selection"))
        if hasattr(self, 'lbl_timeframe'):
            self.lbl_timeframe.setText(f"<b>{tr('timeframe')}</b>")
        if hasattr(self, 'btn_preset_summer'):
            self.btn_preset_summer.setText(tr("preset_summer"))
        if hasattr(self, 'btn_preset_ext'):
            self.btn_preset_ext.setText(tr("preset_ext"))
        if hasattr(self, 'btn_preset_season'):
            self.btn_preset_season.setText(tr("preset_season"))
        if hasattr(self, 'lbl_custom'):
            self.lbl_custom.setText(tr("custom_dates_label"))
        if hasattr(self, 'lbl_hint'):
            self.lbl_hint.setText(tr("tip_chart"))
        if hasattr(self, 'btn_export'):
            self.btn_export.setText(tr("export_csv"))
        if hasattr(self, 'btn_close'):
            self.btn_close.setText(tr("close"))
        self._update_header_text()
        self._update_mowing_prediction_banner()
        if hasattr(self, 'plot_widget') and self.plot_widget:
            self.plot_widget.update()

    def _update_preset_button_styles(self):
        dark = self.styles.get("is_dark", True)
        active_style = (
            "QPushButton { background-color: #0078d7; color: #ffffff; border: 1px solid #005a9e; "
            "border-radius: 11px; padding: 3px 12px; font-weight: bold; font-size: 11px; } "
            "QPushButton:hover { background-color: #0063b1; }"
        )
        if dark:
            inactive_style = (
                "QPushButton { background-color: #2b2b2f; color: #cccccc; border: 1px solid #44444a; "
                "border-radius: 11px; padding: 3px 12px; font-size: 11px; } "
                "QPushButton:hover { background-color: #383840; color: #ffffff; }"
            )
        else:
            inactive_style = (
                "QPushButton { background-color: #f1f3f7; color: #374151; border: 1px solid #cbd0dd; "
                "border-radius: 11px; padding: 3px 12px; font-size: 11px; } "
                "QPushButton:hover { background-color: #e5e8f0; color: #111827; }"
            )

        self.btn_preset_summer.setStyleSheet(active_style if self.btn_preset_summer.isChecked() else inactive_style)
        self.btn_preset_ext.setStyleSheet(active_style if self.btn_preset_ext.isChecked() else inactive_style)
        self.btn_preset_season.setStyleSheet(active_style if self.btn_preset_season.isChecked() else inactive_style)

    def _update_header_text(self):
        dark = self.styles.get("is_dark", True)
        if self.parcel_info.get("label"):
            area_str = f" ({self.parcel_info['area_ha']:.2f} ha)" if "area_ha" in self.parcel_info else ""
            title_text = f"🚜 {tr('parcel_label')}: <b>{self.parcel_info['label']}</b>{area_str}  |  {tr('layer_label')}: <i>{self.parcel_info.get('layer_name', 'Vector')}</i>"
            self.lbl_info.setText(title_text)
            self.lbl_info.setStyleSheet("color: #00e5ff; font-weight: bold; font-size: 13px;" if dark else "color: #006699; font-weight: bold; font-size: 13px;")
        else:
            coords_str = f"📍 {tr('coords_label')}: X={self.pt_3301.x():.1f}, Y={self.pt_3301.y():.1f} (EPSG:3301)  |  {self.pt_4326.y():.5f}°N, {self.pt_4326.x():.5f}°E"
            self.lbl_info.setText(coords_str)
            self.lbl_info.setStyleSheet("color: #00d4ff; font-weight: bold; font-size: 13px;" if dark else "color: #006699; font-weight: bold; font-size: 13px;")

    def update_target(self, pt_3301, pt_4326, parcel_info=None):
        """Updates inspector target when user selects a feature or clicks on canvas."""
        self.pt_3301 = pt_3301
        self.pt_4326 = pt_4326
        self.parcel_info = parcel_info or {}
        self.geom_3301 = self.parcel_info.get("geom_3301", None)
        self.known_urls.clear()
        self.cloudless_urls.clear()
        self.sample_cache.clear()
        self.samples = []
        self.mowing_events = []
        self.plot_widget.set_data([])
        self._update_header_text()
        self.apply_theme()
        self._start_sampling()

    def _get_api_url_list(self):
        if hasattr(self.ws, 'filmstrip') and self.ws.filmstrip.url_list:
            return self.ws.filmstrip.url_list
        elif hasattr(self.ws, 'plugin') and hasattr(self.ws.plugin, 'api') and self.ws.plugin.api.url_list:
            return self.ws.plugin.api.url_list
        return []

    def _get_buffered_bbox_latlon_str(self, buffer_m=1200.0):
        try:
            if hasattr(self, 'geom_3301') and self.geom_3301 and not self.geom_3301.isEmpty():
                b = self.geom_3301.boundingBox()
                buf = max(buffer_m, max(b.width(), b.height()) * 0.5)
                rect_3301 = QgsRectangle(b.xMinimum() - buf, b.yMinimum() - buf, b.xMaximum() + buf, b.yMaximum() + buf)
            else:
                rect_3301 = QgsRectangle(self.pt_3301.x() - buffer_m, self.pt_3301.y() - buffer_m, self.pt_3301.x() + buffer_m, self.pt_3301.y() + buffer_m)

            dst_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
            src_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
            tx = QgsCoordinateTransform(src_3301, dst_4326, QgsProject.instance())
            ne = tx.transform(QgsPointXY(rect_3301.xMaximum(), rect_3301.yMaximum()))
            sw = tx.transform(QgsPointXY(rect_3301.xMinimum(), rect_3301.yMinimum()))
            return f"LatLng({ne.y():.6f},{ne.x():.6f})|LatLng({sw.y():.6f},{sw.x():.6f})"
        except Exception:
            return None

    def _sync_year_with_data(self):
        url_list = self._get_api_url_list()
        if url_list:
            try:
                data_year = datetime.date.fromisoformat(url_list[0][0]).year
                if self.curr_year != data_year:
                    self.curr_year = data_year
                    self.timeframe_start = self.timeframe_start.replace(year=data_year)
                    self.timeframe_end = self.timeframe_end.replace(year=data_year)
                    self.date_start.blockSignals(True)
                    self.date_end.blockSignals(True)
                    self.date_start.setDate(QDate(data_year, self.timeframe_start.month, self.timeframe_start.day))
                    self.date_end.setDate(QDate(data_year, self.timeframe_end.month, self.timeframe_end.day))
                    self.date_start.blockSignals(False)
                    self.date_end.blockSignals(False)
            except Exception:
                pass

    def _on_pick_parcel_clicked(self):
        """Hides the dialog so the user has a clear view of the canvas to click/pick any parcel polygon."""
        self.hide()
        self.ws.plugin.iface.messageBar().pushInfo(
            tr("mowing"),
            tr("tip_pick_vector")
        )
        if not self.ws.inspector_tool:
            self.ws._toggle_point_inspector()

    def _set_timeframe_preset(self, mode):
        self.timeframe_mode = mode
        self.btn_preset_summer.setChecked(mode == "summer")
        self.btn_preset_ext.setChecked(mode == "ext")
        self.btn_preset_season.setChecked(mode == "season")
        self._update_preset_button_styles()

        year = self.curr_year

        if mode == "summer":
            # June 1 to August 31 (Default in Estonia)
            self.timeframe_start = datetime.date(year, 6, 1)
            self.timeframe_end = datetime.date(year, 8, 31)
        elif mode == "ext":
            # June 1 to September 30
            self.timeframe_start = datetime.date(year, 6, 1)
            self.timeframe_end = datetime.date(year, 9, 30)
        elif mode == "season":
            # May 1 to October 31
            self.timeframe_start = datetime.date(year, 5, 1)
            self.timeframe_end = datetime.date(year, 10, 31)

        self.date_start.blockSignals(True)
        self.date_end.blockSignals(True)
        self.date_start.setDate(QDate(self.timeframe_start.year, self.timeframe_start.month, self.timeframe_start.day))
        self.date_end.setDate(QDate(self.timeframe_end.year, self.timeframe_end.month, self.timeframe_end.day))
        self.date_start.blockSignals(False)
        self.date_end.blockSignals(False)

        self._start_sampling()

    def _on_custom_date_changed(self):
        self.btn_preset_summer.setChecked(False)
        self.btn_preset_ext.setChecked(False)
        self.btn_preset_season.setChecked(False)
        self._update_preset_button_styles()

        qs = self.date_start.date()
        qe = self.date_end.date()
        self.timeframe_start = datetime.date(qs.year(), qs.month(), qs.day())
        self.timeframe_end = datetime.date(qe.year(), qe.month(), qe.day())
        self._start_sampling()

    def _reevaluate_mowing(self):
        self._update_plot_and_mowing()

    def _start_sampling(self, skip_esthub_query=False):
        self._sync_year_with_data()

        # Only merge canvas filmstrip dates if the filmstrip is in Cloudless mode!
        is_cloudless_filmstrip = (
            hasattr(self.ws, 'filmstrip') 
            and hasattr(self.ws.filmstrip, 'chk_cloudless') 
            and self.ws.filmstrip.chk_cloudless.isChecked()
        )
        if is_cloudless_filmstrip:
            for dstr, url in self._get_api_url_list():
                if dstr not in self.cloudless_urls:
                    self.cloudless_urls[dstr] = url

        # Scrape EstHub for the buffered parcel extent to discover cloudless dates (always pilvitu_bool=True)
        if not skip_esthub_query and hasattr(self.ws, 'combo_sensor') and hasattr(self.ws, 'combo_filter'):
            buffered_bbox = self._get_buffered_bbox_latlon_str(buffer_m=1200.0)
            if buffered_bbox:
                sensor = self.ws.combo_sensor.currentText()
                toode = self.ws.combo_filter.currentData()

                def _on_parcel_dates_fetched(success, url_list, err):
                    if success and url_list:
                        new_found = False
                        for dstr, url in url_list:
                            if dstr not in self.cloudless_urls:
                                self.cloudless_urls[dstr] = url
                                new_found = True
                        if new_found or not self.current_task:
                            self._start_sampling(skip_esthub_query=True)
                    elif not self.cloudless_urls:
                        self.lbl_mowing_title.setText(tr("no_samples"))
                        self.lbl_mowing_details.setText(f"{tr('timeframe')}: {self.timeframe_start.strftime('%d.%m.%Y')} – {self.timeframe_end.strftime('%d.%m.%Y')}")

                self.parcel_api.refresh_urls_async(
                    buffered_bbox, sensor, toode, pilvitu_bool=True,
                    callback=_on_parcel_dates_fetched,
                    start_date=self.timeframe_start.isoformat(),
                    end_date=self.timeframe_end.isoformat()
                )

        target_dates = []
        for dstr, url in self.cloudless_urls.items():
            try:
                dt = datetime.date.fromisoformat(dstr)
                if self.timeframe_start <= dt <= self.timeframe_end:
                    target_dates.append((dstr, url))
            except Exception:
                pass

        if not target_dates:
            self.lbl_mowing_title.setText(f"⏳ {tr('sampling_progress')}...")
            self.lbl_mowing_details.setText(tr("searching_cloudless"))
            self.progress.hide()
            return

        target_dates.sort(key=lambda x: x[0], reverse=True)
        missing_dates = [(dstr, url) for (dstr, url) in target_dates if dstr not in self.sample_cache]

        if not missing_dates:
            # All dates in this timeframe are already in cache! Instant recalculate!
            self.progress.hide()
            self._update_plot_and_mowing()
            return

        if self.current_task:
            try:
                self.current_task.cancel()
            except Exception:
                pass
            self.current_task = None

        self.progress.setMaximum(len(missing_dates))
        self.progress.setValue(0)
        self.progress.show()

        task = SampleTimeSeriesTask(self.pt_3301, missing_dates, self.sensor, self.filt, self._on_sampling_done, geom_3301=self.geom_3301)
        task.sig_progress.connect(self._on_sample_progress)
        self.current_task = task
        QgsApplication.taskManager().addTask(task)

    def _on_sample_progress(self, current, total):
        self.progress.setValue(current)

    def _on_sampling_done(self, new_samples):
        self.progress.hide()
        self.current_task = None
        if new_samples:
            for dstr, val in new_samples:
                self.sample_cache[dstr] = val
        self._update_plot_and_mowing()

    def _update_plot_and_mowing(self):
        current_samples = []
        for dstr, url in self.cloudless_urls.items():
            try:
                dt = datetime.date.fromisoformat(dstr)
                if self.timeframe_start <= dt <= self.timeframe_end and dstr in self.sample_cache:
                    current_samples.append((dstr, self.sample_cache[dstr]))
            except Exception:
                pass

        current_samples.sort(key=lambda x: x[0])
        self.samples = current_samples

        if self.samples:
            parsed = []
            for dstr, val in self.samples:
                try:
                    parsed.append((datetime.date.fromisoformat(dstr), float(val), dstr))
                except Exception:
                    pass
            self.mowing_events = detect_mowing_events(parsed, self.timeframe_start, self.timeframe_end)
            self.plot_widget.set_data(self.samples, self.mowing_events)
            self._update_mowing_prediction_banner()
            self.btn_export.setEnabled(True)
        else:
            self.plot_widget.set_data([])
            self.lbl_mowing_title.setText(tr("no_samples"))
            self.lbl_mowing_details.setText(f"{tr('timeframe')}: {self.timeframe_start.strftime('%d.%m.%Y')} – {self.timeframe_end.strftime('%d.%m.%Y')}")
            self.btn_export.setEnabled(False)

    def _update_mowing_prediction_banner(self):
        dark = self.styles.get("is_dark", True)
        if not self.mowing_events:
            if dark:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #1e242d; border: 1px solid #355375; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #90caf9;")
                self.lbl_mowing_details.setStyleSheet("color: #bbdefb; font-size: 11px;")
            else:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #f0fdf4; border: 1px solid #86efac; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #166534;")
                self.lbl_mowing_details.setStyleSheet("color: #14532d; font-size: 11px;")

            self.lbl_mowing_title.setText(tr("mowing_status_unmowed"))
            self.lbl_mowing_details.setText(tr("mowing_desc_unmowed"))
            return

        # Mowing events detected! Dynamic 3-tier styling (Green = High, Yellow = Medium, Orange = Low)
        has_high = any(ev.get("conf_level") == "high" for ev in self.mowing_events)
        has_med = any(ev.get("conf_level") == "medium" for ev in self.mowing_events)
        dominant_conf = "high" if has_high else ("medium" if has_med else "low")

        if dominant_conf == "high":
            # GREEN - Good Confidence
            if dark:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #0f291e; border: 1px solid #10b981; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #6ee7b7;")
                self.lbl_mowing_details.setStyleSheet("color: #a7f3d0; font-size: 11px;")
            else:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #ecfdf5; border: 1px solid #10b981; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #065f46;")
                self.lbl_mowing_details.setStyleSheet("color: #047857; font-size: 11px;")
        elif dominant_conf == "medium":
            # YELLOW - Mediocre / Medium Confidence
            if dark:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #2b2613; border: 1px solid #eab308; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #fde047;")
                self.lbl_mowing_details.setStyleSheet("color: #fef08a; font-size: 11px;")
            else:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #fefce8; border: 1px solid #eab308; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #854d0e;")
                self.lbl_mowing_details.setStyleSheet("color: #713f12; font-size: 11px;")
        else:
            # ORANGE - Low Confidence / Partial Mowing
            if dark:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #2e1a0e; border: 1px solid #f97316; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #fdba74;")
                self.lbl_mowing_details.setStyleSheet("color: #fed7aa; font-size: 11px;")
            else:
                self.frame_mowing.setStyleSheet("QFrame { background-color: #fff7ed; border: 1px solid #f97316; border-radius: 5px; padding: 6px; }")
                self.lbl_mowing_title.setStyleSheet("font-weight: bold; font-size: 13px; color: #9a3412;")
                self.lbl_mowing_details.setStyleSheet("color: #c2410c; font-size: 11px;")

        if len(self.mowing_events) == 1:
            ev = self.mowing_events[0]
            title_prefix = tr("mowing_detected_low") if ev.get("conf_level") == "low" else tr("mowing_detected_single")
            self.lbl_mowing_title.setText(f"{title_prefix} <b>{ev['start_date']} – {ev['end_date']}</b>")
            details = f"{tr('biomass_drop')} <b>{ev['drop_pct']:.1f}%</b> ({ev['pre_val']:.2f} → {ev['post_val']:.2f})  |  {tr('confidence')} <b>{ev['confidence']}</b>"
            self.lbl_mowing_details.setText(details)
        else:
            cuts_summary = "  |  ".join([f"#{idx+1}: <b>{ev['start_date']}–{ev['end_date']}</b> ({ev['drop_pct']:.0f}% [{ev.get('conf_level', '').upper()}])" for idx, ev in enumerate(self.mowing_events)])
            self.lbl_mowing_title.setText(f"{tr('mowing_detected_multi')} ({len(self.mowing_events)} cuts)")
            self.lbl_mowing_details.setText(cuts_summary)

    def _load_active_vector_selection(self):
        canvas = self.ws.main_canvas
        curr_layer = canvas.currentLayer()
        if not curr_layer or curr_layer.type() != QgsMapLayer.VectorLayer:
            QMessageBox.information(self, tr("layer_label"), tr("select_vector_layer_msg"))
            return

        selected_feats = curr_layer.selectedFeatures()
        if not selected_feats:
            QMessageBox.information(self, tr("parcel_label"), f"{tr('no_feature_selected_msg')} ('{curr_layer.name()}')")
            return

        feat = selected_feats[0]
        geom = feat.geometry()
        if geom.isEmpty():
            return

        self.ws.clear_inspector_visuals()
        highlight = QgsHighlight(canvas, geom, curr_layer)
        highlight.setColor(QColor(0, 220, 255, 200))
        highlight.setFillColor(QColor(0, 220, 255, 45))
        highlight.setWidth(3)
        highlight.show()
        self.ws.parcel_highlight = highlight

        try:
            pt = geom.pointOnSurface().asPoint()
        except Exception:
            pt = geom.centroid().asPoint()

        src_crs = curr_layer.crs()
        dst_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
        dst_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
        tx_3301 = QgsCoordinateTransform(src_crs, dst_3301, QgsProject.instance())
        tx_4326 = QgsCoordinateTransform(src_crs, dst_4326, QgsProject.instance())

        pt_3301 = tx_3301.transform(pt)
        pt_4326 = tx_4326.transform(pt)

        label = None
        for name_field in ['pria_id', 'tunnus', 'katastritunnus', 'id', 'name', 'nimi', 'nimetus', 'parcel_id', 'number', 'kood']:
            idx = feat.fields().indexOf(name_field)
            if idx >= 0 and feat.attribute(idx):
                label = f"{name_field.upper()}: {feat.attribute(idx)}"
                break
        if not label:
            label = f"Feature #{feat.id()}"

        area_ha = geom.area() / 10000.0 if geom.type() == 2 else 0.0
        geom_3301 = QgsGeometry(geom)
        geom_3301.transform(tx_3301)
        parcel_info = {
            "label": label,
            "layer_name": curr_layer.name(),
            "area_ha": area_ha,
            "geom_3301": geom_3301
        }

        self.update_target(pt_3301, pt_4326, parcel_info)

    def _on_chart_date_clicked(self, dstr):
        url = self.cloudless_urls.get(dstr) or self.known_urls.get(dstr)
        if url:
            self.ws._do_change_left_date(dstr, url)
        elif hasattr(self.ws, '_get_closest_valid_date'):
            closest_d, url = self.ws._get_closest_valid_date(datetime.date.fromisoformat(dstr))
            if closest_d:
                self.ws._do_change_left_date(closest_d, url)

    def _export_csv(self):
        if not self.samples:
            return
        default_csv = f"Satiladu_Mowing_Profile_{datetime.date.today().isoformat()}.csv"
        path, _ = QFileDialog.getSaveFileName(self, "Export Mowing Time-Series CSV", default_csv, "CSV Files (*.csv)")
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write("# EstHub Satiladu Mowing Detection Report\n")
                    if self.parcel_info.get("label"):
                        f.write(f"# Parcel: {self.parcel_info['label']}, Layer: {self.parcel_info.get('layer_name')}, Area: {self.parcel_info.get('area_ha', 0.0):.2f} ha\n")
                    if self.mowing_events:
                        for ev in self.mowing_events:
                            f.write(f"# Predicted Mowing: {ev['start_date']} to {ev['end_date']}, Drop: {ev['drop_pct']:.1f}%, Confidence: {ev['confidence']}\n")
                    else:
                        f.write("# Predicted Mowing: No mowing event detected within timeframe\n")

                    f.write("date,spectral_value,sensor,filter,epsg3301_x,epsg3301_y,latitude,longitude,is_mowed_timeframe\n")
                    mowed_ranges = [(datetime.date.fromisoformat(ev['start_date']), datetime.date.fromisoformat(ev['end_date'])) for ev in self.mowing_events]

                    for dstr, val in self.samples:
                        dt = datetime.date.fromisoformat(dstr)
                        in_mowed = any(r[0] <= dt <= r[1] for r in mowed_ranges)
                        f.write(f"{dstr},{val:.4f},{self.sensor},{self.filt},{self.pt_3301.x():.2f},{self.pt_3301.y():.2f},{self.pt_4326.y():.6f},{self.pt_4326.x():.6f},{in_mowed}\n")
                QMessageBox.information(self, "Export Successful", f"Saved mowing inspection report to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Export Failed", f"Failed to save CSV:\n{str(e)}")

    def closeEvent(self, event):
        if self.current_task:
            try:
                self.current_task.cancel()
            except Exception:
                pass
            self.current_task = None

        if hasattr(self, 'parcel_api') and self.parcel_api and hasattr(self.parcel_api, '_tasks'):
            for t in list(self.parcel_api._tasks):
                try:
                    t.cancel()
                except Exception:
                    pass
            self.parcel_api._tasks.clear()

        if hasattr(self.ws, 'clear_inspector_visuals'):
            self.ws.clear_inspector_visuals()

        super().closeEvent(event)


class SampleTimeSeriesTask(QgsTask):
    sig_progress = pyqtSignal(int, int)

    def __init__(self, pt_3301, date_tuples, sensor, filt, callback, geom_3301=None):
        super().__init__("Sampling Mowing Profile", QgsTask.CanCancel)
        self.pt_3301 = pt_3301
        self.date_tuples = date_tuples
        self.sensor = sensor
        self.filt = filt
        self.callback = callback
        self.geom_3301 = geom_3301
        self.results = []

    def run(self):
        try:
            total = len(self.date_tuples)

            # Determine sampling bounding box: parcel geometry bounding box or point buffer box
            if self.geom_3301 and not self.geom_3301.isEmpty():
                b = self.geom_3301.boundingBox()
                dx = b.width()
                dy = b.height()
                pad = max(20.0, min(dx, dy) * 0.05)
                bbox_str = f"{b.xMinimum() - pad},{b.yMinimum() - pad},{b.xMaximum() + pad},{b.yMaximum() + pad}"
                req_w, req_h = 32, 32
            else:
                buf = 60.0  # 120x120m buffer box around clicked point
                bbox_str = f"{self.pt_3301.x() - buf},{self.pt_3301.y() - buf},{self.pt_3301.x() + buf},{self.pt_3301.y() + buf}"
                req_w, req_h = 24, 24

            for idx, (dstr, url) in enumerate(self.date_tuples):
                if self.isCanceled():
                    return False

                layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
                getmap_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                              f"&BBOX={bbox_str}&SRS=EPSG:3301&WIDTH={req_w}&HEIGHT={req_h}"
                              f"&LAYERS={layer_param}&STYLES=&FORMAT=image/png")

                raw_bytes = None
                try:
                    bnr = QgsBlockingNetworkRequest()
                    req = QNetworkRequest(QUrl(getmap_url))
                    err = bnr.get(req)
                    try:
                        no_err = QgsBlockingNetworkRequest.ErrorCode.NoError
                    except AttributeError:
                        no_err = 0

                    if err == no_err and bnr.reply():
                        raw_bytes = bytes(bnr.reply().content())
                except Exception:
                    pass

                if not raw_bytes:
                    try:
                        req_py = urllib.request.Request(getmap_url, headers={'User-Agent': 'Mozilla/5.0 (QGIS Satiladu)'})
                        with urllib.request.urlopen(req_py, timeout=8) as resp:
                            if self.isCanceled():
                                return False
                            raw_bytes = resp.read()
                    except Exception:
                        pass

                if raw_bytes:
                    try:
                        img = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
                        arr = np.array(img, dtype=np.float32) / 255.0

                        # Crop central interior to avoid boundary edge noise
                        h, w, _ = arr.shape
                        y0, y1 = max(1, int(h * 0.15)), min(h - 1, int(h * 0.85))
                        x0, x1 = max(1, int(w * 0.15)), min(w - 1, int(w * 0.85))
                        crop = arr[y0:y1, x0:x1, :]

                        # Skip only completely empty/nodata responses outside coverage
                        mean_b = float(np.mean(crop))
                        if mean_b < 0.01:
                            continue

                        ch0 = crop[:, :, 0]
                        ch1 = crop[:, :, 1]
                        ch2 = crop[:, :, 2]

                        f_code = self.filt.upper()

                        if f_code in ("NDVI", "NDR", "PDB", "NDN", "PDN"):
                            # Filter directly encodes NDVI in channel 1
                            val_map = ch1
                        elif f_code == "DNP":
                            # DNP encodes NDVI in channel 0
                            val_map = ch0
                        elif f_code == "NRG":
                            # NRG: Band 0 is NIR, Band 1 is Red -> NDVI = (NIR - Red) / (NIR + Red)
                            val_map = (ch0 - ch1) / np.maximum(0.01, (ch0 + ch1))
                        elif f_code == "NGR":
                            # NGR: Band 0 is NIR, Band 2 is Red -> NDVI = (NIR - Red) / (NIR + Red)
                            val_map = (ch0 - ch2) / np.maximum(0.01, (ch0 + ch2))
                        elif f_code in ("NDPI", "PNB", "NGP"):
                            val_map = (ch0 if f_code == "PNB" else ch1)
                        else:
                            # RGB / True Color: Chlorophyll composite combining Excess Green & NGRDI
                            exg = 2.0 * ch1 - ch0 - ch2
                            ngrdi = (ch1 - ch0) / np.maximum(0.02, (ch1 + ch0))
                            val_map = 0.5 * (exg + 0.5) + 0.5 * (ngrdi + 0.5)

                        val = float(np.clip(np.mean(val_map), 0.0, 1.0))
                        self.results.append((dstr, val))
                    except Exception:
                        pass

                self.sig_progress.emit(idx + 1, total)
                self.setProgress(int(((idx + 1) / total) * 100))

            return True
        except Exception:
            return False

    def finished(self, result):
        self.callback(self.results)


class SatiladuPointInspectorTool(QgsMapToolEmitPoint):
    """Interactive map tool that selects vector features (e.g. WFS parcels) or clicked points for mowing inspection."""
    def __init__(self, workspace):
        super().__init__(workspace.main_canvas)
        self.ws = workspace
        self.setCursor(QCursor(CROSS_CURSOR))
        self.canvasClicked.connect(self._on_click)

    def _on_click(self, point, button):
        canvas = self.ws.main_canvas
        src_crs = canvas.mapSettings().destinationCrs()
        dst_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
        dst_4326 = QgsCoordinateReferenceSystem("EPSG:4326")

        # Clear any previous highlight or crosshair
        self.ws.clear_inspector_visuals()

        # Step 1: Query map canvas for vector features (WFS, Shapefile, GeoPackage, etc.)
        feature_found = None
        feature_layer = None

        layers_to_search = []
        curr_layer = canvas.currentLayer()
        if curr_layer and curr_layer.type() == QgsMapLayer.VectorLayer and curr_layer.isValid():
            layers_to_search.append(curr_layer)

        for lyr in canvas.layers():
            if lyr.type() == QgsMapLayer.VectorLayer and lyr.isValid() and lyr not in layers_to_search:
                layers_to_search.append(lyr)

        search_tolerance = canvas.mapUnitsPerPixel() * 5.0

        for lyr in layers_to_search:
            try:
                tx_to_lyr = QgsCoordinateTransform(src_crs, lyr.crs(), QgsProject.instance())
                pt_lyr = tx_to_lyr.transform(point)
                rect_lyr = QgsRectangle(
                    pt_lyr.x() - search_tolerance, pt_lyr.y() - search_tolerance,
                    pt_lyr.x() + search_tolerance, pt_lyr.y() + search_tolerance
                )
                req = QgsFeatureRequest().setFilterRect(rect_lyr)
                for feat in lyr.getFeatures(req):
                    geom = feat.geometry()
                    if not geom.isEmpty():
                        if geom.contains(QgsGeometry.fromPointXY(pt_lyr)) or geom.intersects(QgsGeometry.fromRect(rect_lyr)):
                            feature_found = feat
                            feature_layer = lyr
                            break
                if feature_found:
                    break
            except Exception:
                pass

        parcel_info = {}
        if feature_found and feature_layer:
            # Highlight vector feature boundary
            highlight = QgsHighlight(canvas, feature_found.geometry(), feature_layer)
            highlight.setColor(QColor(0, 220, 255, 210))
            highlight.setFillColor(QColor(0, 220, 255, 45))
            highlight.setWidth(3)
            highlight.show()
            self.ws.parcel_highlight = highlight

            try:
                sample_pt = feature_found.geometry().pointOnSurface().asPoint()
            except Exception:
                sample_pt = feature_found.geometry().centroid().asPoint()

            tx_to_3301 = QgsCoordinateTransform(feature_layer.crs(), dst_3301, QgsProject.instance())
            tx_to_4326 = QgsCoordinateTransform(feature_layer.crs(), dst_4326, QgsProject.instance())
            pt_3301 = tx_to_3301.transform(sample_pt)
            pt_4326 = tx_to_4326.transform(sample_pt)

            geom_3301 = QgsGeometry(feature_found.geometry())
            geom_3301.transform(tx_to_3301)

            label = None
            for name_field in ['pria_id', 'tunnus', 'katastritunnus', 'id', 'name', 'nimi', 'nimetus', 'parcel_id', 'number', 'kood']:
                idx = feature_found.fields().indexOf(name_field)
                if idx >= 0 and feature_found.attribute(idx):
                    label = f"{name_field.upper()}: {feature_found.attribute(idx)}"
                    break
            if not label:
                label = f"Feature #{feature_found.id()}"

            area_ha = feature_found.geometry().area() / 10000.0 if feature_found.geometry().type() == 2 else 0.0
            parcel_info = {
                "label": label,
                "layer_name": feature_layer.name(),
                "area_ha": area_ha,
                "geom_3301": geom_3301
            }
        else:
            tx_3301 = QgsCoordinateTransform(src_crs, dst_3301, QgsProject.instance())
            tx_4326 = QgsCoordinateTransform(src_crs, dst_4326, QgsProject.instance())
            pt_3301 = tx_3301.transform(point)
            pt_4326 = tx_4326.transform(point)
            geom_3301 = QgsGeometry.fromPointXY(pt_3301)
            parcel_info = {
                "geom_3301": geom_3301
            }

            marker = QgsVertexMarker(canvas)
            marker.setCenter(point)
            marker.setColor(QColor(0, 220, 255))
            marker.setIconType(QgsVertexMarker.ICON_CROSS)
            marker.setIconSize(14)
            marker.setPenWidth(3)
            self.ws.point_marker = marker

        sensor = self.ws.combo_sensor.currentText()
        filt = self.ws.combo_filter.currentText()

        # If dialog already exists, update target and restore to front
        if hasattr(self.ws, 'active_profile_dlg') and self.ws.active_profile_dlg:
            dlg = self.ws.active_profile_dlg
            dlg.update_target(pt_3301, pt_4326, parcel_info)
            dlg.showNormal()
            dlg.raise_()
            dlg.activateWindow()
        else:
            dlg = TimeSeriesDialog(pt_3301, pt_4326, sensor, filt, self.ws, parcel_info=parcel_info, parent=canvas)
            self.ws.active_profile_dlg = dlg
            dlg.show()
            dlg.raise_()
