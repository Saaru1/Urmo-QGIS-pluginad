# -*- coding: utf-8 -*-
"""
SatiladuWMS UI Components
"""
from .thumbnail_delegate import ThumbnailDelegate
from .calendar_dialog import DarkCalendarDialog, CalendarDialog
from .swipe_handle import SwipeHandle
from .filmstrip import HorizontalFilmstrip, InlineThumbnailPanel
from .workspace import SatiladuWorkspace
from .language_switch import LanguageSwitchWidget
from .theme_switch import ThemeSwitchWidget

__all__ = [
    "ThumbnailDelegate",
    "DarkCalendarDialog",
    "CalendarDialog",
    "SwipeHandle",
    "HorizontalFilmstrip",
    "InlineThumbnailPanel",
    "SatiladuWorkspace",
    "LanguageSwitchWidget",
    "ThemeSwitchWidget",
]
