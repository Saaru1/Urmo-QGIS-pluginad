# -*- coding: utf-8 -*-
import datetime
from qgis.PyQt.QtCore import Qt, QDate
from qgis.PyQt.QtGui import QTextCharFormat, QColor, QFont
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QCalendarWidget, QCheckBox, QComboBox
)
from ..satiladu_api import SatiladuAPI
from .i18n import tr
from .theme_manager import get_theme_styles


class DarkCalendarDialog(QDialog):
    def __init__(self, workspace):
        super().__init__(workspace.main_canvas)
        self.workspace = workspace
        self.setWindowTitle(tr("calendar_title"))
        self.resize(480, 430)

        styles = get_theme_styles()
        self.setStyleSheet(styles["dialog_style"])

        layout = QVBoxLayout(self)

        top_controls = QHBoxLayout()
        self.chk_cloudless = QCheckBox(tr("cloudless_only"))
        self.chk_cloudless.setChecked(self.workspace.filmstrip.chk_cloudless.isChecked())
        self.chk_cloudless.toggled.connect(self._highlight_dates)
        top_controls.addWidget(self.chk_cloudless)

        top_controls.addStretch()

        top_controls.addWidget(QLabel(f"<b>{tr('archive_depth')}</b>"))
        self.combo_depth = QComboBox()
        self.combo_depth.addItem(tr("depth_2y"), 2)
        self.combo_depth.addItem(tr("depth_5y"), 5)
        self.combo_depth.addItem(tr("depth_all"), 12)
        self.combo_depth.setCurrentIndex(1)  # Default 5 years
        self.combo_depth.currentIndexChanged.connect(self._highlight_dates)
        top_controls.addWidget(self.combo_depth)

        layout.addLayout(top_controls)

        self.calendar = QCalendarWidget()
        self.calendar.setMaximumDate(QDate.currentDate())
        self.calendar.setGridVisible(True)
        layout.addWidget(self.calendar)

        btn_layout = QHBoxLayout()
        self.btn_ok = QPushButton(tr("jump_to_date"))
        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel = QPushButton(tr("cancel"))
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

        self._highlight_dates()

    def _highlight_dates(self):
        bbox = self.workspace.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.workspace.combo_sensor.currentText()
        toode = self.workspace.combo_filter.currentData()
        years = self.combo_depth.currentData() if hasattr(self, 'combo_depth') else 5

        api_all = SatiladuAPI()
        api_all.refresh_urls_list(bbox, sensor, toode, False, years_back=years)
        all_dates = list(api_all.url_list)

        clear_fmt = QTextCharFormat()
        for dstr, u in all_dates:
            dt = datetime.date.fromisoformat(dstr)
            self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), clear_fmt)

        if self.chk_cloudless.isChecked():
            fmt_cloud = QTextCharFormat()
            fmt_cloud.setBackground(QColor("yellow"))
            fmt_cloud.setForeground(QColor("black"))
            try:
                fmt_cloud.setFontWeight(QFont.Weight.Bold)
            except AttributeError:
                fmt_cloud.setFontWeight(QFont.Bold)

            api_cloud = SatiladuAPI()
            api_cloud.refresh_urls_list(bbox, sensor, toode, True, years_back=years)
            for dstr, u in api_cloud.url_list:
                dt = datetime.date.fromisoformat(dstr)
                self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt_cloud)
        else:
            fmt_all = QTextCharFormat()
            try:
                fmt_all.setUnderlineStyle(QTextCharFormat.UnderlineStyle.SingleUnderline)
            except AttributeError:
                fmt_all.setUnderlineStyle(QTextCharFormat.SingleUnderline)
            fmt_all.setUnderlineColor(QColor("#00ff00"))
            fmt_all.setForeground(QColor("white" if get_theme_styles()["is_dark"] else "#1e1e24"))

            for dstr, u in all_dates:
                dt = datetime.date.fromisoformat(dstr)
                self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt_all)

    def get_selected_date(self):
        return self.calendar.selectedDate().toPyDate().isoformat()

CalendarDialog = DarkCalendarDialog
