# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import QWidget, QHBoxLayout, QPushButton
from .theme_manager import get_theme_styles, is_dark, set_current_theme
from .i18n import get_current_lang


class ThemeSwitchWidget(QWidget):
    """Segmented switch displaying [ ☀️ Hele | 🌙 Tume ] or [ ☀️ Light | 🌙 Dark ] with active theme highlighted."""
    themeChanged = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(1)

        self.btn_light = QPushButton("☀️ Hele")
        self.btn_dark = QPushButton("🌙 Tume")

        try:
            hand_cursor = Qt.CursorShape.PointingHandCursor
        except AttributeError:
            hand_cursor = Qt.PointingHandCursor

        self.btn_light.setCursor(hand_cursor)
        self.btn_dark.setCursor(hand_cursor)

        self.btn_light.clicked.connect(lambda: self.set_theme("light"))
        self.btn_dark.clicked.connect(lambda: self.set_theme("dark"))

        layout.addWidget(self.btn_light)
        layout.addWidget(self.btn_dark)

        self.update_appearance()

    def set_theme(self, theme_mode):
        if theme_mode not in ("light", "dark"):
            return
        curr_is_dark = is_dark()
        target_is_dark = (theme_mode == "dark")
        if curr_is_dark != target_is_dark:
            set_current_theme(theme_mode)
            self.update_appearance()
            self.themeChanged.emit(theme_mode)

    def update_language(self):
        self.update_appearance()

    def update_appearance(self):
        dark = is_dark()
        lang = get_current_lang()

        if lang == "EST":
            self.btn_light.setText("☀️ Hele")
            self.btn_dark.setText("🌙 Tume")
            self.btn_light.setToolTip("Hele teema (Aktiivne)" if not dark else "Lülita heledale teemale")
            self.btn_dark.setToolTip("Tume teema (Aktiivne)" if dark else "Lülita tumedale teemale")
        else:
            self.btn_light.setText("☀️ Light")
            self.btn_dark.setText("🌙 Dark")
            self.btn_light.setToolTip("Light theme (Active)" if not dark else "Switch to Light theme")
            self.btn_dark.setToolTip("Dark theme (Active)" if dark else "Switch to Dark theme")

        active_style = (
            "QPushButton { background-color: #0078d7; color: #ffffff; font-weight: bold; "
            "border: 1px solid #005a9e; border-radius: 3px; padding: 4px 7px; font-size: 11px; } "
            "QPushButton:hover { background-color: #0063b1; }"
        )

        if dark:
            inactive_style = (
                "QPushButton { background-color: #2c2c30; color: #888894; font-weight: normal; "
                "border: 1px solid #44444c; border-radius: 3px; padding: 4px 7px; font-size: 11px; } "
                "QPushButton:hover { background-color: #383840; color: #ffffff; }"
            )
        else:
            inactive_style = (
                "QPushButton { background-color: #e4e6ee; color: #555560; font-weight: normal; "
                "border: 1px solid #c2c4ce; border-radius: 3px; padding: 4px 7px; font-size: 11px; } "
                "QPushButton:hover { background-color: #d6d8e2; color: #111111; }"
            )

        if not dark:
            self.btn_light.setStyleSheet(active_style)
            self.btn_dark.setStyleSheet(inactive_style)
        else:
            self.btn_light.setStyleSheet(inactive_style)
            self.btn_dark.setStyleSheet(active_style)
