# -*- coding: utf-8 -*-
import os
import sys
import site
import tempfile
import io
import datetime
import urllib.request
import numpy as np

user_site = site.getusersitepackages()
if user_site not in sys.path and os.path.exists(user_site):
    sys.path.insert(0, user_site)

from PIL import Image, ImageDraw, ImageFont

from qgis.core import QgsTask, Qgis, QgsMessageLog, QgsBlockingNetworkRequest
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest
from .onnx_worker import run_onnx_upscale


class GifGeneratorTask(QgsTask):
    def __init__(self, valid_frames, bbox_3301, width, height, sensor, filt, speed_ms, smooth, overlay_path, upscale, callback,
                 model_path=None, scale=2, target_scale=2, export_format="GIF", show_scale_bar=True, show_north_arrow=True):
        super().__init__("Generating Satiladu Timelapse", QgsTask.CanCancel)
        self.valid_frames = valid_frames
        self.bbox_3301 = bbox_3301
        self.width = width
        self.height = height
        self.sensor = sensor
        self.filt = filt
        self.speed_ms = speed_ms
        self.smooth = smooth
        self.overlay_path = overlay_path
        self.upscale = upscale
        self.callback = callback
        self.model_path = model_path
        self.scale = scale if scale else 2
        self.target_scale = target_scale if target_scale else self.scale
        self.export_format = export_format.upper()
        self.show_scale_bar = show_scale_bar
        self.show_north_arrow = show_north_arrow

        self.temp_dir = tempfile.mkdtemp(prefix="qgis_satiladu_gif_")

        if self.export_format == "MP4":
            self.final_output_path = os.path.join(self.temp_dir, "timelapse.mp4")
        elif self.export_format == "WEBP":
            self.final_output_path = os.path.join(self.temp_dir, "timelapse.webp")
        else:
            self.final_output_path = os.path.join(self.temp_dir, "timelapse.gif")

        self.downloaded_files = []

    def _fetch_tile_bytes(self, url):
        """Fetches raw tile bytes using QgsBlockingNetworkRequest with fallback."""
        try:
            bnr = QgsBlockingNetworkRequest()
            req = QNetworkRequest(QUrl(url))
            err = bnr.get(req)
            try:
                no_err = QgsBlockingNetworkRequest.ErrorCode.NoError
            except AttributeError:
                no_err = 0
            if err == no_err and bnr.reply():
                return bytes(bnr.reply().content())
        except Exception:
            pass

        req_py = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (QGIS Satiladu)'})
        with urllib.request.urlopen(req_py, timeout=15) as resp:
            return resp.read()

    def _draw_decorations(self, img, dstr, current_frame_idx, total_frames):
        """Draws professional cartographic annotations: date pill, timeline progress, scale bar, and north arrow."""
        draw = ImageDraw.Draw(img)
        w, h = img.size

        # 1. Date pill
        draw_dstr = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
        anno_text = f"{self.sensor} {self.filt}  |  {draw_dstr}"

        try:
            font_name = "arial.ttf" if os.name == 'nt' else "DejaVuSans.ttf"
            font = ImageFont.truetype(font_name, 16)
            font_small = ImageFont.truetype(font_name, 11)
        except Exception:
            font = ImageFont.load_default()
            font_small = font

        if hasattr(font, 'getbbox'):
            left, top, right, bottom = font.getbbox(anno_text)
            tw, th = right - left, bottom - top
        else:
            tw, th = draw.textsize(anno_text, font=font)

        pad = 8
        pill_rect = [(10, 10), (10 + tw + pad * 2, 10 + th + pad * 2)]
        draw.rectangle(pill_rect, fill=(30, 30, 30, 220), outline=(0, 120, 215, 255), width=1)
        draw.text((10 + pad, 10 + pad), anno_text, fill="white", font=font)

        # 2. North Arrow (top-right)
        if self.show_north_arrow:
            nx = w - 42
            ny = 12
            draw.rectangle([(nx, ny), (nx + 32, ny + 32)], fill=(30, 30, 30, 200), outline=(100, 100, 100, 200), width=1)
            draw.text((nx + 10, ny + 3), "↑", fill="#00d4ff", font=font)
            draw.text((nx + 11, ny + 17), "N", fill="white", font=font_small)

        # 3. Dynamic Scale Bar (bottom-left)
        if self.show_scale_bar and self.bbox_3301:
            try:
                xmin, ymin, xmax, ymax = map(float, self.bbox_3301.split(','))
                ground_width_m = xmax - xmin
                meters_per_px = ground_width_m / float(w)

                # Target scale bar ~ 100 pixels
                target_meters = meters_per_px * 100.0
                # Round to clean metric increments
                increments = [10, 25, 50, 100, 250, 500, 1000, 2000, 5000, 10000, 25000, 50000, 100000]
                best_m = min(increments, key=lambda x: abs(x - target_meters))
                bar_px = max(20, int(round(best_m / meters_per_px)))

                label = f"{best_m} m" if best_m < 1000 else f"{int(best_m / 1000)} km"
                bx = 15
                by = h - 25

                draw.rectangle([(bx - 5, by - 16), (bx + bar_px + 5, by + 10)], fill=(30, 30, 30, 180))
                # Alternating black/white tick bar
                draw.line([(bx, by), (bx + bar_px, by)], fill="white", width=4)
                draw.line([(bx, by - 4), (bx, by + 4)], fill="white", width=2)
                draw.line([(bx + bar_px, by - 4), (bx + bar_px, by + 4)], fill="white", width=2)
                draw.text((bx, by - 15), label, fill="white", font=font_small)
            except Exception:
                pass

        # 4. Attribution (bottom-right)
        attr_text = "ESTHub / Maa- ja Ruumiamet"
        if hasattr(font_small, 'getbbox'):
            al, at, ar, ab = font_small.getbbox(attr_text)
            aw, ah = ar - al, ab - at
        else:
            aw, ah = draw.textsize(attr_text, font=font_small)
        draw.rectangle([(w - aw - 20, h - ah - 16), (w - 10, h - 6)], fill=(30, 30, 30, 160))
        draw.text((w - aw - 15, h - ah - 14), attr_text, fill=(200, 200, 200, 220), font=font_small)

        # 5. Timeline scrubber progress line (bottom edge)
        if total_frames > 1:
            progress_ratio = (current_frame_idx + 1) / float(total_frames)
            draw.line([(0, h - 3), (w, h - 3)], fill=(50, 50, 50, 180), width=3)
            draw.line([(0, h - 3), (int(w * progress_ratio), h - 3)], fill=(0, 160, 255, 240), width=3)

    def run(self):
        try:
            total = len(self.valid_frames)

            overlay_img = None
            if self.overlay_path and os.path.exists(self.overlay_path):
                overlay_img = Image.open(self.overlay_path).convert("RGBA")

            for i, (dstr, base_url) in enumerate(self.valid_frames):
                if self.isCanceled():
                    return False

                layer_param = base_url.split('?')[0].split('wms-')[-1].replace('-', '_')

                if self.upscale and self.model_path and os.path.exists(self.model_path):
                    xmin, ymin, xmax, ymax = map(float, self.bbox_3301.split(','))
                    native_w = max(64, int(round((xmax - xmin) / 10.0)))
                    fetch_w = max(64, min(self.width // self.scale, native_w))
                    fetch_h = max(64, int(fetch_w * (self.height / self.width)))

                    getmap_url = (f"{base_url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                                  f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={fetch_w}&HEIGHT={fetch_h}"
                                  f"&LAYERS={layer_param}&STYLES=&FORMAT=image/png")

                    raw_bytes = self._fetch_tile_bytes(getmap_url)
                    if not raw_bytes or self.isCanceled():
                        return False
                    raw_img = Image.open(io.BytesIO(raw_bytes)).convert("RGB")

                    upscaled = run_onnx_upscale(
                        raw_img,
                        self.model_path,
                        is_canceled_func=self.isCanceled,
                        target_scale=self.target_scale
                    )
                    if self.isCanceled():
                        return False

                    if upscaled:
                        img = upscaled.resize((self.width, self.height), Image.Resampling.LANCZOS).convert("RGBA")
                    else:
                        img = raw_img.resize((self.width, self.height), Image.Resampling.LANCZOS).convert("RGBA")
                else:
                    getmap_url = (f"{base_url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                                  f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={self.width}&HEIGHT={self.height}"
                                  f"&LAYERS={layer_param}&STYLES=&FORMAT=image/png")

                    raw_bytes = self._fetch_tile_bytes(getmap_url)
                    if not raw_bytes or self.isCanceled():
                        return False
                    img = Image.open(io.BytesIO(raw_bytes)).convert("RGBA")

                # Composite overlays on top of the satellite frame
                if overlay_img:
                    if overlay_img.size != img.size:
                        overlay_img = overlay_img.resize(img.size, Image.Resampling.LANCZOS)
                    img = Image.alpha_composite(img, overlay_img)

                # Draw cartographic annotations
                self._draw_decorations(img, dstr, i, total)

                frame_path = os.path.join(self.temp_dir, f"frame_{i:03d}.png")
                img.convert("RGB").save(frame_path, "PNG")
                self.downloaded_files.append(frame_path)

                self.setProgress((i / total) * 60)

            if self.isCanceled():
                return False
            self.setProgress(70)

            base_images = [Image.open(f).convert("RGBA") for f in self.downloaded_files]
            final_images = []
            final_durations = []

            if self.smooth:
                blend_steps = 2
                for i in range(len(base_images)):
                    if self.isCanceled():
                        return False
                    final_images.append(base_images[i])
                    final_durations.append(self.speed_ms)

                    if i < len(base_images) - 1:
                        for step in range(1, blend_steps + 1):
                            alpha = step / (blend_steps + 1)
                            blended = Image.blend(base_images[i], base_images[i + 1], alpha)
                            final_images.append(blended)
                            final_durations.append(int(self.speed_ms / 3))
            else:
                final_images = base_images
                final_durations = [self.speed_ms] * len(base_images)

            self.setProgress(90)
            if self.isCanceled():
                return False

            # Encode into the requested format
            if self.export_format == "MP4":
                try:
                    import cv2
                    fps = max(1, int(round(1000.0 / self.speed_ms)))
                    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
                    out = cv2.VideoWriter(self.final_output_path, fourcc, fps, (self.width, self.height))
                    for fimg in final_images:
                        np_frame = np.array(fimg.convert("RGB"))
                        # RGB to BGR for OpenCV
                        out.write(cv2.cvtColor(np_frame, cv2.COLOR_RGB2BGR))
                    out.release()
                except Exception as ex_cv:
                    QgsMessageLog.logMessage(f"OpenCV MP4 encoding failed: {ex_cv}, falling back to GIF", "SentinelWMS", Qgis.Warning)
                    self.export_format = "GIF"
                    self.final_output_path = os.path.join(self.temp_dir, "timelapse.gif")

            if self.export_format == "WEBP":
                try:
                    rgb_images = [img.convert("RGB") for img in final_images]
                    rgb_images[0].save(
                        self.final_output_path,
                        format='WEBP',
                        save_all=True,
                        append_images=rgb_images[1:],
                        duration=final_durations,
                        loop=0,
                        quality=85
                    )
                except Exception as ex_webp:
                    QgsMessageLog.logMessage(f"WebP encoding failed ({ex_webp}), falling back to GIF", "SentinelWMS", Qgis.Warning)
                    self.export_format = "GIF"
                    self.final_output_path = os.path.join(self.temp_dir, "timelapse.gif")

            if self.export_format == "GIF":
                try:
                    adaptive_palette = Image.Palette.ADAPTIVE
                except AttributeError:
                    adaptive_palette = Image.ADAPTIVE

                optimized_images = [
                    img.convert("RGB").convert("P", palette=adaptive_palette, colors=256)
                    for img in final_images
                ]

                optimized_images[0].save(
                    self.final_output_path,
                    format='GIF',
                    save_all=True,
                    append_images=optimized_images[1:],
                    duration=final_durations,
                    loop=0,
                    optimize=True
                )

            self.setProgress(100)
            return True

        except Exception as e:
            QgsMessageLog.logMessage(f"Timelapse Task Error: {str(e)}", "SentinelWMS", Qgis.Critical)
            return False

    def finished(self, result):
        if result and os.path.exists(self.final_output_path):
            self.callback(self.final_output_path)
        else:
            self.callback(None)
