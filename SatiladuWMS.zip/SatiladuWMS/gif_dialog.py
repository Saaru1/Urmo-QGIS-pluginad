# -*- coding: utf-8 -*-
import datetime
import shutil
import os
import sys
import site
import tempfile
from qgis.PyQt.QtCore import Qt, QDate, QUrl, QSize, QPoint, QTimer
from qgis.PyQt.QtGui import QTextCharFormat, QColor, QFont, QMovie, QPixmap, QImage, QImageReader
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QDateEdit, QComboBox, QCheckBox, QSlider, QFileDialog, 
    QListWidget, QListWidgetItem, QMessageBox, QWidget, QAbstractItemView
)
from qgis.core import QgsApplication, QgsProject, QgsMapLayer, QgsMapSettings, QgsMapRendererSequentialJob, QgsTask
from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply

from .gif_task import GifGeneratorTask
from .satiladu_api import SatiladuAPI
from .onnx_manager import get_available_models, get_model_info

class ThumbnailDateWidget(QWidget):
    def __init__(self, dstr, is_checked, url, bbox, parent=None):
        super().__init__(parent)
        self.dstr = dstr
        self.is_loaded = False
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(5, 5, 5, 5)
        
        self.chk = QCheckBox(dstr)
        self.chk.setChecked(is_checked)
        self.chk.setStyleSheet("color: white; font-weight: bold; font-size: 13px;")
        try:
            self.chk.setCursor(Qt.CursorShape.ArrowCursor)
        except AttributeError:
            self.chk.setCursor(Qt.ArrowCursor)
        self.layout.addWidget(self.chk)
        
        self.lbl_thumb = QLabel("Loading...")
        self.lbl_thumb.setFixedSize(120, 120)
        self.lbl_thumb.setAlignment(Qt.AlignCenter if not hasattr(Qt, 'AlignmentFlag') else Qt.AlignmentFlag.AlignCenter)
        self.lbl_thumb.setStyleSheet("border: 1px solid #777; background-color: #222; color: #aaa;")
        self.layout.addWidget(self.lbl_thumb)
        self.layout.addStretch()

        layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
        self.thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                          f"&BBOX={bbox}&SRS=EPSG:3301&WIDTH=120&HEIGHT=120"
                          f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")

    def set_pixmap(self, pixmap):
        self.lbl_thumb.setPixmap(pixmap.scaled(120, 120, Qt.KeepAspectRatio if not hasattr(Qt, 'AspectRatioMode') else Qt.AspectRatioMode.KeepAspectRatio))
        self.lbl_thumb.setStyleSheet("border: 1px solid #555;")
        self.is_loaded = True

class DateSelectionDialog(QDialog):
    def __init__(self, range_frames, bbox, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.setWindowTitle("Select Timelapse Dates")
        self.resize(500, 600)
        
        self.setStyleSheet("""
            QDialog { background-color: #2d2d30; color: white; }
            QLabel { color: white; font-size: 13px; margin-bottom: 5px;}
            QPushButton { background-color: #0078d7; color: white; border-radius: 4px; padding: 6px 12px; font-weight: bold; }
            QPushButton:hover { background-color: #005a9e; }
            QListWidget { background: rgba(30, 30, 30, 240); border: 1px solid #444; border-radius: 4px; outline: none; }
            QListWidget::item { border-bottom: 1px solid #444; }
            QListWidget::item:hover { background-color: rgba(80, 80, 80, 200); }
            QListWidget::item:selected { background-color: rgba(0, 120, 215, 200); }
            QScrollBar:vertical { background: #222; width: 12px; }
            QScrollBar::handle:vertical { background: #666; border-radius: 6px; min-height: 20px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
            QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #888; border-radius: 3px; background: rgba(0,0,0,100); }
            QCheckBox::indicator:checked { background: #0078d7; border: 1px solid #0078d7; }
        """)

        try:
            self.user_role = Qt.ItemDataRole.UserRole 
            arrow_cursor = Qt.CursorShape.ArrowCursor
        except AttributeError:
            self.user_role = Qt.UserRole
            arrow_cursor = Qt.ArrowCursor

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Select dates to include based on previews (newest to oldest):"))
        
        self.list_widget = QListWidget()
        self.list_widget.setIconSize(QSize(120, 120))
        
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        
        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )
        
        layout.addWidget(self.list_widget)
        
        self.preview_widgets = {}
        range_frames.sort(key=lambda x: datetime.date.fromisoformat(x[0]), reverse=True)

        for dstr, is_checked, base_url in range_frames:
            item = QListWidgetItem(self.list_widget)
            item.setSizeHint(QSize(450, 130))
            item.setData(self.user_role, dstr)
            
            widget = ThumbnailDateWidget(dstr, is_checked, base_url, bbox)
            self.list_widget.setItemWidget(item, widget)
            self.preview_widgets[dstr] = (item, widget)
            
        btn_layout = QHBoxLayout()
        btn_all = QPushButton("Select All")
        btn_none = QPushButton("Deselect All")
        btn_ok = QPushButton("OK")
        
        btn_all.setCursor(arrow_cursor)
        btn_none.setCursor(arrow_cursor)
        btn_ok.setCursor(arrow_cursor)
        
        btn_all.clicked.connect(lambda: self._set_all(True))
        btn_none.clicked.connect(lambda: self._set_all(False))
        btn_ok.clicked.connect(self.accept)
        
        btn_layout.addWidget(btn_all)
        btn_layout.addWidget(btn_none)
        btn_layout.addWidget(btn_ok)
        layout.addLayout(btn_layout)

        QTimer.singleShot(50, self._process_visible_thumbnails)

    def _process_visible_thumbnails(self):
        top_item = self.list_widget.itemAt(QPoint(10, 10))
        bottom_item = self.list_widget.itemAt(QPoint(10, self.list_widget.viewport().height() - 10))
        
        start_row = self.list_widget.row(top_item) if top_item else 0
        end_row = self.list_widget.row(bottom_item) if bottom_item else self.list_widget.count() - 1
        if start_row == -1: start_row = 0
        if end_row == -1: end_row = self.list_widget.count() - 1
        
        active_urls = set()
        
        for i in range(start_row, end_row + 1):
            item = self.list_widget.item(i)
            if item:
                dstr = item.data(self.user_role)
                widget = self.preview_widgets[dstr][1]
                if widget and not widget.is_loaded:
                    active_urls.add(widget.thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(widget.thumb_url, widget.set_pixmap, priority=10)

        load_start = max(0, start_row - 3)
        load_end = min(self.list_widget.count(), end_row + 4)
        
        for i in range(load_start, load_end):
            if i >= start_row and i <= end_row: continue
            item = self.list_widget.item(i)
            if item:
                dstr = item.data(self.user_role)
                widget = self.preview_widgets[dstr][1]
                if widget and not widget.is_loaded:
                    active_urls.add(widget.thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(widget.thumb_url, widget.set_pixmap, priority=1)
                    
        self.plugin.thumbnail_manager.cancel_stale_requests(active_urls)

    def _set_all(self, state):
        for w in self.preview_widgets.values():
            w[1].chk.setChecked(state)
            
    def get_selected_dates(self):
        return [dstr for dstr, w in self.preview_widgets.items() if w[1].chk.isChecked()]

class GifGeneratorDialog(QDialog):
    def __init__(self, parent_plugin):
        super().__init__(parent_plugin.iface.mainWindow())
        self.plugin = parent_plugin
        self.api = parent_plugin.api
        self.layers = parent_plugin.layers
        self.setWindowTitle("Generate Timelapse GIF")
        self.resize(980, 780) 
        
        try:
            self.setWindowFlags(Qt.WindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowCloseButtonHint))
        except AttributeError:
            self.setWindowFlags(Qt.Window | Qt.WindowMinimizeButtonHint | Qt.WindowCloseButtonHint)
            
        try:
            self.setWindowModality(Qt.WindowModality.NonModal)
        except AttributeError:
            self.setWindowModality(Qt.NonModal)

        try:
            align_center = Qt.AlignmentFlag.AlignCenter
            orient_horizontal = Qt.Orientation.Horizontal
            arrow_cursor = Qt.CursorShape.ArrowCursor
        except AttributeError:
            align_center = Qt.AlignCenter
            orient_horizontal = Qt.Horizontal
            arrow_cursor = Qt.ArrowCursor

        self.setStyleSheet("""
            QDialog { background-color: #2d2d30; color: white; }
            QLabel { color: white; font-weight: bold; }
            QSpinBox { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 4px; }
            QComboBox, QDateEdit { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 4px; }
            QComboBox::drop-down { border: none; }
            QComboBox QAbstractItemView { background: #444; color: white; selection-background-color: #0078d7; border: 1px solid #222; outline: none; margin: 0px; padding: 0px; }
            QComboBox QListView { border: none; }
            QPushButton { background-color: #0078d7; color: white; border-radius: 4px; padding: 6px; font-weight: bold; }
            QPushButton:hover { background-color: #005a9e; }
            QPushButton:disabled { background-color: #555; color: #888; border: none; }
            QProgressBar { border: 1px solid #666; border-radius: 3px; text-align: center; color: white; background: #222; }
            QProgressBar::chunk { background-color: #0078d7; }
            QCheckBox { color: white; font-weight: bold; }
            QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }
            QCheckBox::indicator:checked { background: #0078d7; border: 1px solid #0078d7; }
            QSlider::groove:horizontal { border: 1px solid #bbb; background: #222; height: 8px; border-radius: 4px; }
            QSlider::handle:horizontal { background: #0078d7; border: 1px solid #005a9e; width: 16px; margin: -4px 0; border-radius: 8px; }
            QCalendarWidget QWidget { alternate-background-color: #3e3e42; color: white; }
            QCalendarWidget QAbstractItemView:enabled { background-color: #2d2d30; color: white; selection-background-color: #0078d7; }
            QCalendarWidget QToolButton { color: white; icon-size: 24px; }
            QCalendarWidget QMenu { background-color: #2d2d30; color: white; }
            QCalendarWidget QSpinBox { background-color: #3e3e42; color: white; }
        """)

        layout = QVBoxLayout(self)

        controls_layout = QHBoxLayout()
        controls_layout.setContentsMargins(0, 0, 0, 10)
        controls_layout.setSpacing(15) 
        
        # --- Start Block ---
        start_layout = QVBoxLayout()
        start_layout.addWidget(QLabel("Start:"))
        self.start_date = QDateEdit()
        self.start_date.setCursor(arrow_cursor)
        self.start_date.setCalendarPopup(True)
        self.start_date.setDisplayFormat("dd.MM.yyyy") 
        self.start_date.setMaximumDate(QDate.currentDate())
        self.start_date.dateChanged.connect(self._on_start_date_changed)
        start_layout.addWidget(self.start_date)
        controls_layout.addLayout(start_layout)

        # --- End Block ---
        end_layout = QVBoxLayout()
        end_layout.addWidget(QLabel("End:"))
        self.end_date = QDateEdit()
        self.end_date.setCursor(arrow_cursor)
        self.end_date.setCalendarPopup(True)
        self.end_date.setDisplayFormat("dd.MM.yyyy") 
        self.end_date.setMaximumDate(QDate.currentDate())
        end_layout.addWidget(self.end_date)
        controls_layout.addLayout(end_layout)

        # --- Speed Block ---
        speed_layout = QVBoxLayout()
        speed_layout.addWidget(QLabel("Speed:"))
        self.combo_speed = QComboBox()
        self.combo_speed.setCursor(arrow_cursor)
        self.combo_speed.addItem("Slow", 1000)
        self.combo_speed.addItem("Normal", 500)
        self.combo_speed.addItem("Fast", 200)
        self.combo_speed.setCurrentIndex(1) 
        speed_layout.addWidget(self.combo_speed)
        controls_layout.addLayout(speed_layout)
        
        controls_layout.addStretch()

        options_layout = QHBoxLayout()
        self.chk_smooth = QCheckBox("Smooth transitions")
        self.chk_smooth.setCursor(arrow_cursor)
        options_layout.addWidget(self.chk_smooth)
        
        self.chk_include_layers = QCheckBox("Show layers")
        self.chk_include_layers.setCursor(arrow_cursor)
        options_layout.addWidget(self.chk_include_layers)

        self.chk_upscale = QCheckBox("✨ AI Upscale")
        self.chk_upscale.setCursor(arrow_cursor)
        self.chk_upscale.setToolTip("Enhance frames using neural super-resolution (ONNX DirectML)")
        options_layout.addWidget(self.chk_upscale)

        self.combo_upscale_model = QComboBox()
        self.combo_upscale_model.setCursor(arrow_cursor)
        for m in get_available_models():
            self.combo_upscale_model.addItem(m)
        self.combo_upscale_model.setEnabled(False)
        self.combo_upscale_model.setToolTip("Select ONNX model for upscaling GIF frames")
        if hasattr(self.plugin, 'workspace') and self.plugin.workspace and hasattr(self.plugin.workspace, 'combo_model'):
            self.combo_upscale_model.setCurrentText(self.plugin.workspace.combo_model.currentText())
        else:
            for i in range(self.combo_upscale_model.count()):
                if "2x" in self.combo_upscale_model.itemText(i).lower():
                    self.combo_upscale_model.setCurrentIndex(i)
                    break
                    
        # RESTORED: This attaches the list to the layout!
        self.chk_upscale.toggled.connect(self.combo_upscale_model.setEnabled)
        options_layout.addWidget(self.combo_upscale_model)

        self.btn_select_dates = QPushButton("Select Dates...")
        self.btn_select_dates.setCursor(arrow_cursor)
        self.btn_select_dates.clicked.connect(self._open_date_selection)
        options_layout.addWidget(self.btn_select_dates)

        self.btn_generate = QPushButton("Generate")
        self.btn_generate.setCursor(arrow_cursor)
        self.btn_generate.clicked.connect(self._toggle_generate)
        options_layout.addWidget(self.btn_generate)
        
        self.btn_save = QPushButton("Save to PC")
        self.btn_save.setCursor(arrow_cursor)
        self.btn_save.setEnabled(False)
        self.btn_save.clicked.connect(self._save_gif)
        options_layout.addWidget(self.btn_save)

        layout.addLayout(controls_layout)
        layout.addLayout(options_layout)

        self.lbl_gif = QLabel("Select dates and click Generate.\n(GIF generates in background, no freezing!)")
        self.lbl_gif.setAlignment(align_center)
        self.lbl_gif.setMinimumHeight(480)
        self.lbl_gif.setStyleSheet("background-color: #1e1e1e; border: 1px solid #444; border-radius: 4px;")
        layout.addWidget(self.lbl_gif, 1) 

        playback_layout = QHBoxLayout()
        self.btn_play_pause = QPushButton("Pause")
        self.btn_play_pause.setCursor(arrow_cursor)
        self.btn_play_pause.setEnabled(False)
        self.btn_play_pause.clicked.connect(self._toggle_playback)
        playback_layout.addWidget(self.btn_play_pause)

        self.slider_frames = QSlider(orient_horizontal)
        self.slider_frames.setCursor(arrow_cursor)
        self.slider_frames.setEnabled(False)
        self.slider_frames.sliderPressed.connect(self._on_slider_pressed)
        self.slider_frames.sliderReleased.connect(self._on_slider_released)
        self.slider_frames.valueChanged.connect(self._on_slider_value_changed)
        playback_layout.addWidget(self.slider_frames)
        
        layout.addLayout(playback_layout)

        self.movie = None
        self.scrub_frames = []
        self.final_gif_disk_path = None
        self._is_user_sliding = False
        self._was_playing = False
        self.active_task = None
        
        self.custom_selected_dates = None 
        self.current_url_list = []
        self.cloudless_dates_set = set()

        self._refresh_url_list()

        self.start_date.dateChanged.connect(self._validate_date_range)
        self.end_date.dateChanged.connect(self._validate_date_range)

        # Set default selection to real-time (today)
        self.start_date.blockSignals(True)
        self.end_date.blockSignals(True)
        today = QDate.currentDate()
        self.start_date.setDate(today.addMonths(-3))
        self.end_date.setDate(today)
        self.start_date.blockSignals(False)
        self.end_date.blockSignals(False)

        self._validate_date_range()
        self._highlight_dates()

    def _refresh_url_list(self):
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.plugin.combo_sensor.currentText()
        toode = self.plugin.combo_filter.currentData()
        
        api_all = SatiladuAPI()
        api_all.refresh_urls_list(bbox_latlon, sensor, toode, False)
        self.current_url_list = list(api_all.url_list)
        
        api_cloudless = SatiladuAPI()
        api_cloudless.refresh_urls_list(bbox_latlon, sensor, toode, True)
        self.cloudless_dates_set = {d for d, u in api_cloudless.url_list}
        
        self.custom_selected_dates = None

    def closeEvent(self, event):
        try:
            if hasattr(self, 'active_task') and self.active_task:
                self.active_task.cancel()
        except RuntimeError:
            pass
        self.active_task = None
        super().closeEvent(event)

    def _highlight_dates(self):
        if not self.current_url_list: return
        
        clear_fmt = QTextCharFormat()
        for dstr, _ in self.current_url_list:
            dt = datetime.date.fromisoformat(dstr)
            qdate = QDate(dt.year, dt.month, dt.day)
            if self.start_date.calendarWidget():
                self.start_date.calendarWidget().setDateTextFormat(qdate, clear_fmt)
            if self.end_date.calendarWidget():
                self.end_date.calendarWidget().setDateTextFormat(qdate, clear_fmt)
        
        fmt_all = QTextCharFormat()
        try:
            fmt_all.setUnderlineStyle(QTextCharFormat.UnderlineStyle.SingleUnderline)
        except AttributeError:
            fmt_all.setUnderlineStyle(QTextCharFormat.SingleUnderline)
        fmt_all.setUnderlineColor(QColor("#00ff00"))
        fmt_all.setForeground(QColor("white"))
        
        fmt_cloudless = QTextCharFormat()
        fmt_cloudless.setBackground(QColor("yellow"))
        fmt_cloudless.setForeground(QColor("black"))
        try:
            fmt_cloudless.setFontWeight(QFont.Weight.Bold)
        except AttributeError:
            fmt_cloudless.setFontWeight(QFont.Bold)

        for dstr, _ in self.current_url_list:
            dt = datetime.date.fromisoformat(dstr)
            qdate = QDate(dt.year, dt.month, dt.day)
            
            if self.start_date.calendarWidget():
                self.start_date.calendarWidget().setDateTextFormat(qdate, fmt_all)
            if self.end_date.calendarWidget():
                self.end_date.calendarWidget().setDateTextFormat(qdate, fmt_all)
                
        for dstr in self.cloudless_dates_set:
            dt = datetime.date.fromisoformat(dstr)
            qdate = QDate(dt.year, dt.month, dt.day)
            if self.start_date.calendarWidget():
                self.start_date.calendarWidget().setDateTextFormat(qdate, fmt_cloudless)
            if self.end_date.calendarWidget():
                self.end_date.calendarWidget().setDateTextFormat(qdate, fmt_cloudless)

    def _validate_date_range(self):
        self.start_date.setMaximumDate(self.end_date.date())
        self.end_date.setMinimumDate(self.start_date.date())
        self.custom_selected_dates = None 

    def _on_start_date_changed(self, startDate):
        if not self.start_date.hasFocus(): return 
        proposed = startDate.addDays(30)
        if proposed > QDate.currentDate(): proposed = QDate.currentDate()
        self.end_date.blockSignals(True)
        self.end_date.setDate(proposed)
        self.end_date.blockSignals(False)
        self._validate_date_range()

    def _open_date_selection(self):
        start_pydate = datetime.date(self.start_date.date().year(), self.start_date.date().month(), self.start_date.date().day())
        end_pydate = datetime.date(self.end_date.date().year(), self.end_date.date().month(), self.end_date.date().day())
        
        range_frames = []
        for dstr, url in self.current_url_list:
            d_obj = datetime.date.fromisoformat(dstr)
            if start_pydate <= d_obj <= end_pydate:
                is_cloudless = dstr in self.cloudless_dates_set
                
                if self.custom_selected_dates is not None:
                    is_checked = dstr in self.custom_selected_dates
                else:
                    is_checked = is_cloudless
                    
                range_frames.append((dstr, is_checked, url))
                
        if not range_frames:
            QMessageBox.warning(self, "No Dates", "No available dates found within the selected date range.")
            return
            
        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
        dlg = DateSelectionDialog(range_frames, bbox_3301, self.plugin, self)
        
        if dlg.exec() == (QDialog.DialogCode.Accepted if hasattr(QDialog, 'DialogCode') else QDialog.Accepted):
            self.custom_selected_dates = dlg.get_selected_dates()

    def _toggle_playback(self):
        if not self.movie: return
        
        try:
            running_state = QMovie.MovieState.Running
        except AttributeError:
            running_state = QMovie.Running
            
        if self.movie.state() == running_state: 
            self.movie.setPaused(True)
            self.btn_play_pause.setText("Play")
        else:
            if self.lbl_gif.movie() != self.movie:
                self.lbl_gif.setMovie(self.movie)
                self.movie.jumpToFrame(self.slider_frames.value())
            self.movie.setPaused(False)
            self.btn_play_pause.setText("Pause")

    def _sync_slider(self, frame_num):
        if not self._is_user_sliding:
            self.slider_frames.blockSignals(True)
            self.slider_frames.setValue(frame_num)
            self.slider_frames.blockSignals(False)

    def _on_slider_pressed(self):
        if not self.movie: return
        self._is_user_sliding = True
        
        try:
            running_state = QMovie.MovieState.Running
        except AttributeError:
            running_state = QMovie.Running
            
        self._was_playing = (self.movie.state() == running_state)
        self.movie.setPaused(True)
        self.btn_play_pause.setText("Play")
        
        self.lbl_gif.setMovie(None)

    def _on_slider_released(self):
        if not self.movie: return
        self._is_user_sliding = False
        
        self.lbl_gif.setMovie(self.movie)
        self.movie.jumpToFrame(self.slider_frames.value())
        
        if self._was_playing:
            self.movie.setPaused(False)
            self.btn_play_pause.setText("Pause")
        else:
            self.btn_play_pause.setText("Play")

    def _on_slider_value_changed(self, value):
        if not self.movie: return
        if self._is_user_sliding and hasattr(self, 'scrub_frames') and self.scrub_frames:
            if 0 <= value < len(self.scrub_frames):
                self.lbl_gif.setPixmap(self.scrub_frames[value])

    def _toggle_generate(self):
        try:
            status_queued = QgsTask.TaskStatus.Queued
            status_running = QgsTask.TaskStatus.Running
        except AttributeError:
            status_queued = QgsTask.Queued
            status_running = QgsTask.Running
            
        try:
            if self.active_task and self.active_task.status() in (status_queued, status_running):
                self.active_task.cancel()
                self.lbl_gif.setText("Timelapse generation stopped by user.")
                self._reset_generate_button()
                self.active_task = None
                return
        except RuntimeError:
            self.active_task = None
            
        self._generate_gif_async()

    def _reset_generate_button(self):
        self.btn_generate.setText("Generate")
        self.btn_generate.setStyleSheet("background-color: #0078d7; color: white; border-radius: 4px; padding: 6px; font-weight: bold;")

    def _generate_gif_async(self):
        start_pydate = datetime.date(self.start_date.date().year(), self.start_date.date().month(), self.start_date.date().day())
        end_pydate = datetime.date(self.end_date.date().year(), self.end_date.date().month(), self.end_date.date().day())
        
        if self.custom_selected_dates is not None:
            valid_frames = [(d, u) for d, u in self.current_url_list if d in self.custom_selected_dates]
        else:
            valid_frames = [(d, u) for d, u in self.current_url_list if start_pydate <= datetime.date.fromisoformat(d) <= end_pydate and d in self.cloudless_dates_set]

        if not valid_frames:
            self.lbl_gif.setText("No dates selected in this range.")
            return

        model_path = None
        scale = 2
        target_scale = 2

        if self.chk_upscale.isChecked():
            user_site = site.getusersitepackages()
            if os.path.exists(user_site) and user_site not in sys.path:
                sys.path.insert(0, user_site)
            try:
                import onnxruntime
            except ImportError:
                QMessageBox.warning(self, "Missing Dependencies", "AI Upscaling requires 'onnxruntime-directml'. Please run Upscale once in the main toolbar to install it.")
                return

            model_name = self.combo_upscale_model.currentText()
            model_info = get_model_info(model_name)
            model_path = model_info["path"]
            scale = model_info.get("scale", 2)
            target_scale = model_info.get("target_scale", scale)

            if not os.path.exists(model_path):
                QMessageBox.warning(self, "Model Missing", f"The model file was not found:\n{model_path}\nPlease download it from the main window first.")
                return

        valid_frames.reverse()
        self.lbl_gif.setText("Generating GIF in background...\nYou can keep using QGIS while it builds!")
        
        self.btn_generate.setText("Stop")
        self.btn_generate.setStyleSheet("background-color: #d9534f; color: white; border-radius: 4px; padding: 6px; font-weight: bold;")
        self.btn_save.setEnabled(False)

        canvas = self.plugin.iface.mapCanvas()
        bbox_3301 = self.layers.get_canvas_bbox_3301_str()
        
        aspect = canvas.height() / canvas.width()
        width = max(400, min(1200, self.lbl_gif.width()))
        height = int(width * aspect)
        if height > self.lbl_gif.height():
            height = self.lbl_gif.height()
            width = int(height / aspect)

        overlay_path = None
        if self.chk_include_layers.isChecked():
            overlay_settings = QgsMapSettings(canvas.mapSettings())
            
            active_layers = overlay_settings.layers()
            
            # Gather all plugin base/upscale layers to exclude from the transparent overlay
            exclude_layers = [self.layers.current_layer, self.layers.layer_left, self.layers.layer_right]
            if hasattr(self.plugin, 'workspace') and self.plugin.workspace and hasattr(self.plugin.workspace, 'onnx_manager'):
                exclude_layers.append(self.plugin.workspace.onnx_manager.upscale_layers.get("left"))
                exclude_layers.append(self.plugin.workspace.onnx_manager.upscale_layers.get("right"))
                
            filtered_layers = []
            for lyr in active_layers:
                if lyr in exclude_layers:
                    continue
                if lyr.type() == QgsMapLayer.RasterLayer and ('ortho' in lyr.name().lower() or 'ortofoto' in lyr.name().lower()):
                    continue
                filtered_layers.append(lyr)
                
            overlay_settings.setLayers(filtered_layers)
            
            try:
                transparent = Qt.GlobalColor.transparent
            except AttributeError:
                transparent = Qt.transparent
            overlay_settings.setBackgroundColor(QColor(transparent))
            overlay_settings.setOutputSize(QSize(width, height))
            
            job = QgsMapRendererSequentialJob(overlay_settings)
            job.start()
            job.waitForFinished()
            q_img = job.renderedImage()
            
            overlay_path = os.path.join(tempfile.gettempdir(), f"satiladu_overlay_{datetime.datetime.now().strftime('%H%M%S')}.png")
            q_img.save(overlay_path, "PNG")

        self.active_task = GifGeneratorTask(
            valid_frames, bbox_3301, width, height, 
            self.plugin.combo_sensor.currentText(), self.plugin.combo_filter.currentText(),
            self.combo_speed.currentData(), self.chk_smooth.isChecked(),
            overlay_path, self.chk_upscale.isChecked(), self._on_task_finished,
            model_path=model_path, scale=scale, target_scale=target_scale
        )
        QgsApplication.taskManager().addTask(self.active_task)

    def _on_task_finished(self, final_gif_path):
        self.active_task = None
        try:
            self._reset_generate_button()
        except RuntimeError:
            return 
            
        if not final_gif_path:
            return
            
        self.final_gif_disk_path = final_gif_path
        
        self.scrub_frames = []
        reader = QImageReader(self.final_gif_disk_path)
        while reader.canRead():
            img = reader.read()
            if not img.isNull():
                self.scrub_frames.append(QPixmap.fromImage(img))

        self.movie = QMovie(self.final_gif_disk_path)
        try:
            cache_all = QMovie.CacheMode.CacheAll
        except AttributeError:
            cache_all = QMovie.CacheAll
        self.movie.setCacheMode(cache_all)

        self.lbl_gif.setMovie(self.movie)
        self.movie.start()
        
        self.btn_save.setEnabled(True)
        self.btn_play_pause.setEnabled(True)
        self.btn_play_pause.setText("Pause")
        
        self.slider_frames.setEnabled(True)
        self.slider_frames.setMinimum(0)
        self.slider_frames.setMaximum(self.movie.frameCount() - 1)
        self.movie.frameChanged.connect(self._sync_slider)

        if not self.isVisible() or self.isMinimized():
            if hasattr(self.plugin, 'workspace') and self.plugin.workspace:
                if hasattr(self.plugin.workspace, 'start_gif_btn_blink'):
                    self.plugin.workspace.start_gif_btn_blink()

    def _save_gif(self):
        if self.final_gif_disk_path and os.path.exists(self.final_gif_disk_path):
            sensor = self.plugin.combo_sensor.currentText()
            filt = self.plugin.combo_filter.currentText()
            default_name = f"Satiladu_{sensor}_{filt}_timelapse.gif"
            
            path, _ = QFileDialog.getSaveFileName(self, "Save Timelapse", default_name, "GIF Files (*.gif)")
            if path:
                shutil.copy(self.final_gif_disk_path, path)
                self.plugin.log(f"Saved GIF to: {path}")