# -*- coding: utf-8 -*-
import datetime
import shutil
import os
import tempfile
from qgis.PyQt.QtCore import Qt, QDate, QUrl, QSize, QPoint, QTimer
from qgis.PyQt.QtGui import QTextCharFormat, QColor, QFont, QMovie, QPixmap, QImage, QImageReader
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QDateEdit, QComboBox, QCheckBox, QSlider, QFileDialog, 
    QListWidget, QListWidgetItem, QMessageBox, QWidget, QAbstractItemView
)
from qgis.core import QgsApplication, QgsProject, QgsMapLayer, QgsMapSettings, QgsMapRendererSequentialJob
from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply

from .gif_task import GifGeneratorTask
from .satiladu_api import SatiladuAPI

class ThumbnailDateWidget(QWidget):
    def __init__(self, dstr, is_cloudless, url, bbox, parent=None):
        super().__init__(parent)
        self.dstr = dstr
        self.is_loaded = False
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(5, 5, 5, 5)
        
        self.chk = QCheckBox(dstr)
        self.chk.setChecked(is_cloudless)
        self.layout.addWidget(self.chk)
        
        self.lbl_thumb = QLabel("Loading...")
        self.lbl_thumb.setFixedSize(120, 120)
        self.lbl_thumb.setAlignment(Qt.AlignCenter if not hasattr(Qt, 'AlignmentFlag') else Qt.AlignmentFlag.AlignCenter)
        self.lbl_thumb.setStyleSheet("border: 1px solid #ccc; background-color: #eee;")
        self.layout.addWidget(self.lbl_thumb)
        self.layout.addStretch()

        layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
        self.thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                          f"&BBOX={bbox}&SRS=EPSG:3301&WIDTH=120&HEIGHT=120"
                          f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")

    def set_pixmap(self, pixmap):
        self.lbl_thumb.setPixmap(pixmap.scaled(120, 120, Qt.KeepAspectRatio if not hasattr(Qt, 'AspectRatioMode') else Qt.AspectRatioMode.KeepAspectRatio))
        self.lbl_thumb.setStyleSheet("border: 1px solid #333;")
        self.is_loaded = True

class DateSelectionDialog(QDialog):
    def __init__(self, range_frames, bbox, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.nam = QgsNetworkAccessManager()
        self.setWindowTitle("Select Timelapse Dates")
        self.resize(500, 600)
        
        try:
            self.user_role = Qt.ItemDataRole.UserRole 
        except AttributeError:
            self.user_role = Qt.UserRole

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Select dates to include based on previews (newest to oldest):"))
        
        self.list_widget = QListWidget()
        self.list_widget.setIconSize(QSize(120, 120))
        
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        
        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )
        
        layout.addWidget(self.list_widget)
        
        self.preview_widgets = {}
        range_frames.sort(key=lambda x: datetime.date.fromisoformat(x[0]), reverse=True)

        for dstr, is_cloudless, base_url in range_frames:
            item = QListWidgetItem(self.list_widget)
            item.setSizeHint(QSize(450, 130))
            item.setData(self.user_role, dstr)
            
            widget = ThumbnailDateWidget(dstr, is_cloudless, base_url, bbox)
            self.list_widget.setItemWidget(item, widget)
            self.preview_widgets[dstr] = (item, widget)
            
        btn_layout = QHBoxLayout()
        btn_all = QPushButton("Select All")
        btn_none = QPushButton("Deselect All")
        btn_ok = QPushButton("OK")
        
        btn_all.clicked.connect(lambda: self._set_all(True))
        btn_none.clicked.connect(lambda: self._set_all(False))
        btn_ok.clicked.connect(self.accept)
        
        btn_layout.addWidget(btn_all)
        btn_layout.addWidget(btn_none)
        btn_layout.addWidget(btn_ok)
        layout.addLayout(btn_layout)

        QTimer.singleShot(50, self._process_visible_thumbnails)

    def _process_visible_thumbnails(self):
        top_item = self.list_widget.itemAt(QPoint(10, 10))
        bottom_item = self.list_widget.itemAt(QPoint(10, self.list_widget.viewport().height() - 10))
        
        start_row = self.list_widget.row(top_item) if top_item else 0
        end_row = self.list_widget.row(bottom_item) if bottom_item else self.list_widget.count() - 1
        if start_row == -1: start_row = 0
        if end_row == -1: end_row = self.list_widget.count() - 1
        
        load_start = max(0, start_row - 1)
        load_end = min(self.list_widget.count(), end_row + 2)
        
        for i in range(load_start, load_end):
            item = self.list_widget.item(i)
            if item:
                dstr = item.data(self.user_role)
                widget = self.preview_widgets[dstr][1]
                if widget and not widget.is_loaded:
                    self._load_thumbnail(widget)

    def _load_thumbnail(self, widget):
        if widget.thumb_url in self.plugin.thumbnail_cache:
            widget.set_pixmap(self.plugin.thumbnail_cache[widget.thumb_url])
            return

        req = QNetworkRequest(QUrl(widget.thumb_url))
        reply = self.nam.get(req)
        reply.finished.connect(lambda r=reply, w=widget: self._on_thumbnail_loaded(r, w))
        
    def _on_thumbnail_loaded(self, reply, widget):
        try:
            no_error = QNetworkReply.NetworkError.NoError
        except AttributeError:
            no_error = QNetworkReply.NoError

        if reply.error() == no_error:
            img_data = reply.readAll()
            img = QImage.fromData(img_data)
            if not img.isNull():
                pix = QPixmap.fromImage(img)
                self.plugin.thumbnail_cache[widget.thumb_url] = pix
                widget.set_pixmap(pix)
            else:
                widget.lbl_thumb.setText("No Image")
        else:
            widget.lbl_thumb.setText("Error")
        reply.deleteLater()

    def _set_all(self, state):
        for w in self.preview_widgets.values():
            w[1].chk.setChecked(state)
            
    def get_selected_dates(self):
        return [dstr for dstr, w in self.preview_widgets.items() if w[1].chk.isChecked()]

class GifGeneratorDialog(QDialog):
    def __init__(self, parent_plugin):
        super().__init__(parent_plugin.iface.mainWindow())
        self.plugin = parent_plugin
        self.api = parent_plugin.api
        self.layers = parent_plugin.layers
        self.setWindowTitle("Generate Timelapse GIF")
        self.resize(950, 780) 

        try:
            align_center = Qt.AlignmentFlag.AlignCenter
            orient_horizontal = Qt.Orientation.Horizontal
        except AttributeError:
            align_center = Qt.AlignCenter
            orient_horizontal = Qt.Horizontal

        layout = QVBoxLayout(self)

        controls_layout = QHBoxLayout()
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(10) 
        
        controls_layout.addWidget(QLabel("Start:"))
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDisplayFormat("dd.MM.yyyy") 
        self.start_date.setMaximumDate(QDate.currentDate())
        self.start_date.dateChanged.connect(self._on_start_date_changed)
        controls_layout.addWidget(self.start_date)

        controls_layout.addWidget(QLabel("End:"))
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDisplayFormat("dd.MM.yyyy") 
        self.end_date.setMaximumDate(QDate.currentDate())
        controls_layout.addWidget(self.end_date)

        controls_layout.addWidget(QLabel("Speed:"))
        self.combo_speed = QComboBox()
        self.combo_speed.addItem("Slow", 1000)
        self.combo_speed.addItem("Normal", 500)
        self.combo_speed.addItem("Fast", 200)
        self.combo_speed.setCurrentIndex(1) 
        controls_layout.addWidget(self.combo_speed)

        options_layout = QHBoxLayout()
        self.chk_smooth = QCheckBox("Smooth transitions")
        options_layout.addWidget(self.chk_smooth)
        
        self.chk_include_layers = QCheckBox("Show layers")
        options_layout.addWidget(self.chk_include_layers)

        self.chk_upscale = QCheckBox("Experimental: Upscale/Sharpen")
        options_layout.addWidget(self.chk_upscale)

        self.btn_select_dates = QPushButton("Select Dates...")
        self.btn_select_dates.clicked.connect(self._open_date_selection)
        options_layout.addWidget(self.btn_select_dates)

        self.btn_generate = QPushButton("Generate")
        self.btn_generate.clicked.connect(self._generate_gif_async)
        options_layout.addWidget(self.btn_generate)
        
        self.btn_save = QPushButton("Save to PC")
        self.btn_save.setEnabled(False)
        self.btn_save.clicked.connect(self._save_gif)
        options_layout.addWidget(self.btn_save)

        layout.addLayout(controls_layout)
        layout.addLayout(options_layout)

        self.lbl_gif = QLabel("Select dates and click Generate.\n(GIF generates in background, no freezing!)")
        self.lbl_gif.setAlignment(align_center)
        self.lbl_gif.setMinimumHeight(480)
        layout.addWidget(self.lbl_gif, 1) 

        playback_layout = QHBoxLayout()
        self.btn_play_pause = QPushButton("Pause")
        self.btn_play_pause.setEnabled(False)
        self.btn_play_pause.clicked.connect(self._toggle_playback)
        playback_layout.addWidget(self.btn_play_pause)

        self.slider_frames = QSlider(orient_horizontal)
        self.slider_frames.setEnabled(False)
        self.slider_frames.sliderPressed.connect(self._on_slider_pressed)
        self.slider_frames.sliderReleased.connect(self._on_slider_released)
        self.slider_frames.valueChanged.connect(self._on_slider_value_changed)
        playback_layout.addWidget(self.slider_frames)
        
        layout.addLayout(playback_layout)

        self.movie = None
        self.scrub_frames = []
        self.final_gif_disk_path = None
        self._is_user_sliding = False
        self._was_playing = False
        self.active_task = None
        self.custom_selected_dates = None 

        self.start_date.dateChanged.connect(self._validate_date_range)
        self.end_date.dateChanged.connect(self._validate_date_range)

        if self.api.url_list:
            newest_dt = datetime.date.fromisoformat(self.api.url_list[0][0])
            qnewest = QDate(newest_dt.year, newest_dt.month, newest_dt.day)
            self.start_date.blockSignals(True)
            self.end_date.blockSignals(True)
            self.start_date.setDate(qnewest.addMonths(-3))
            self.end_date.setDate(qnewest)
            self.start_date.blockSignals(False)
            self.end_date.blockSignals(False)

        self._validate_date_range()
        self._highlight_dates()

    def _highlight_dates(self):
        if not self.api.url_list: return
        fmt = QTextCharFormat()
        try:
            bold_weight = QFont.Weight.Bold
        except AttributeError:
            bold_weight = QFont.Bold

        fmt.setBackground(QColor("yellow"))
        fmt.setFontWeight(bold_weight)

        for dstr, _ in self.api.url_list:
            dt = datetime.date.fromisoformat(dstr)
            qdate = QDate(dt.year, dt.month, dt.day)
            if self.start_date.calendarWidget():
                self.start_date.calendarWidget().setDateTextFormat(qdate, fmt)
            if self.end_date.calendarWidget():
                self.end_date.calendarWidget().setDateTextFormat(qdate, fmt)

    def _validate_date_range(self):
        self.start_date.setMaximumDate(self.end_date.date())
        self.end_date.setMinimumDate(self.start_date.date())
        self.custom_selected_dates = None 

    def _on_start_date_changed(self, startDate):
        if not self.start_date.hasFocus(): return 
        proposed = startDate.addDays(30)
        if proposed > QDate.currentDate(): proposed = QDate.currentDate()
        self.end_date.blockSignals(True)
        self.end_date.setDate(proposed)
        self.end_date.blockSignals(False)
        self._validate_date_range()

    def _open_date_selection(self):
        start_pydate = datetime.date(self.start_date.date().year(), self.start_date.date().month(), self.start_date.date().day())
        end_pydate = datetime.date(self.end_date.date().year(), self.end_date.date().month(), self.end_date.date().day())
        
        tmp_api = SatiladuAPI()
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.plugin.combo_sensor.currentText()
        toode = self.plugin.combo_filter.currentData()
        tmp_api.refresh_urls_list(bbox_latlon, sensor, toode, False)
        
        cloudless_dates = {d[0] for d in self.api.url_list}
        range_frames = []
        for dstr, url in tmp_api.url_list:
            d_obj = datetime.date.fromisoformat(dstr)
            if start_pydate <= d_obj <= end_pydate:
                is_cloudless = dstr in cloudless_dates
                range_frames.append((dstr, is_cloudless, url))
                
        if not range_frames:
            QMessageBox.warning(self, "No Dates", "No available dates found within the selected date range.")
            return
            
        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
        dlg = DateSelectionDialog(range_frames, bbox_3301, self.plugin, self)
        
        if dlg.exec() == QDialog.DialogCode.Accepted if hasattr(QDialog, 'DialogCode') else QDialog.Accepted:
            self.custom_selected_dates = dlg.get_selected_dates()

    def _toggle_playback(self):
        if not self.movie: return
        
        try:
            running_state = QMovie.MovieState.Running
        except AttributeError:
            running_state = QMovie.Running
            
        if self.movie.state() == running_state: 
            self.movie.setPaused(True)
            self.btn_play_pause.setText("Play")
        else:
            if self.lbl_gif.movie() != self.movie:
                self.lbl_gif.setMovie(self.movie)
                self.movie.jumpToFrame(self.slider_frames.value())
            self.movie.setPaused(False)
            self.btn_play_pause.setText("Pause")

    def _sync_slider(self, frame_num):
        if not self._is_user_sliding:
            self.slider_frames.blockSignals(True)
            self.slider_frames.setValue(frame_num)
            self.slider_frames.blockSignals(False)

    def _on_slider_pressed(self):
        if not self.movie: return
        self._is_user_sliding = True
        
        try:
            running_state = QMovie.MovieState.Running
        except AttributeError:
            running_state = QMovie.Running
            
        self._was_playing = (self.movie.state() == running_state)
        self.movie.setPaused(True)
        self.btn_play_pause.setText("Play")
        
        # Detach movie so direct pixmap scrubbing isn't overwritten
        self.lbl_gif.setMovie(None)

    def _on_slider_released(self):
        if not self.movie: return
        self._is_user_sliding = False
        
        # Re-attach movie and force single jump
        self.lbl_gif.setMovie(self.movie)
        self.movie.jumpToFrame(self.slider_frames.value())
        
        if self._was_playing:
            self.movie.setPaused(False)
            self.btn_play_pause.setText("Pause")
        else:
            self.btn_play_pause.setText("Play")

    def _on_slider_value_changed(self, value):
        if not self.movie: return
        if self._is_user_sliding and hasattr(self, 'scrub_frames') and self.scrub_frames:
            if 0 <= value < len(self.scrub_frames):
                self.lbl_gif.setPixmap(self.scrub_frames[value])

    def _generate_gif_async(self):
        start_pydate = datetime.date(self.start_date.date().year(), self.start_date.date().month(), self.start_date.date().day())
        end_pydate = datetime.date(self.end_date.date().year(), self.end_date.date().month(), self.end_date.date().day())
        
        if self.custom_selected_dates is not None:
            valid_frames = [(d, u) for d, u in self.api.url_list if d in self.custom_selected_dates]
        else:
            valid_frames = [(d, u) for d, u in self.api.url_list if start_pydate <= datetime.date.fromisoformat(d) <= end_pydate]

        if not valid_frames:
            self.lbl_gif.setText("No dates selected in this range.")
            return

        valid_frames.reverse()
        self.lbl_gif.setText("Generating GIF in background...\nYou can keep using QGIS while it builds!")
        self.btn_generate.setEnabled(False)
        self.btn_save.setEnabled(False)

        canvas = self.plugin.iface.mapCanvas()
        bbox_3301 = self.layers.get_canvas_bbox_3301_str()
        
        aspect = canvas.height() / canvas.width()
        width = max(400, min(1200, self.lbl_gif.width()))
        height = int(width * aspect)
        if height > self.lbl_gif.height():
            height = self.lbl_gif.height()
            width = int(height / aspect)

        overlay_path = None
        if self.chk_include_layers.isChecked():
            overlay_settings = QgsMapSettings(canvas.mapSettings())
            
            active_layers = overlay_settings.layers()
            filtered_layers = []
            for lyr in active_layers:
                if lyr == self.layers.current_layer:
                    continue
                if lyr.type() == QgsMapLayer.RasterLayer and ('ortho' in lyr.name().lower() or 'ortofoto' in lyr.name().lower()):
                    continue
                filtered_layers.append(lyr)
                
            overlay_settings.setLayers(filtered_layers)
            
            try:
                transparent = Qt.GlobalColor.transparent
            except AttributeError:
                transparent = Qt.transparent
            overlay_settings.setBackgroundColor(QColor(transparent))
            overlay_settings.setOutputSize(QSize(width, height))
            
            job = QgsMapRendererSequentialJob(overlay_settings)
            job.start()
            job.waitForFinished()
            q_img = job.renderedImage()
            
            overlay_path = os.path.join(tempfile.gettempdir(), f"satiladu_overlay_{datetime.datetime.now().strftime('%H%M%S')}.png")
            q_img.save(overlay_path, "PNG")

        self.active_task = GifGeneratorTask(
            valid_frames, bbox_3301, width, height, 
            self.plugin.combo_sensor.currentText(), self.plugin.combo_filter.currentText(),
            self.combo_speed.currentData(), self.chk_smooth.isChecked(),
            overlay_path, self.chk_upscale.isChecked(), self._on_task_finished 
        )
        QgsApplication.taskManager().addTask(self.active_task)

    def _on_task_finished(self, final_gif_path):
        self.btn_generate.setEnabled(True)
        if not final_gif_path:
            self.lbl_gif.setText("Failed to generate GIF or process was cancelled.")
            return
            
        self.final_gif_disk_path = final_gif_path
        
        # Cache frames explicitly to support instant bidirectional scrubbing
        self.scrub_frames = []
        reader = QImageReader(self.final_gif_disk_path)
        while reader.canRead():
            img = reader.read()
            if not img.isNull():
                self.scrub_frames.append(QPixmap.fromImage(img))

        self.movie = QMovie(self.final_gif_disk_path)
        try:
            cache_all = QMovie.CacheMode.CacheAll
        except AttributeError:
            cache_all = QMovie.CacheAll
        self.movie.setCacheMode(cache_all)

        self.lbl_gif.setMovie(self.movie)
        self.movie.start()
        
        self.btn_save.setEnabled(True)
        self.btn_play_pause.setEnabled(True)
        self.btn_play_pause.setText("Pause")
        
        self.slider_frames.setEnabled(True)
        self.slider_frames.setMinimum(0)
        self.slider_frames.setMaximum(self.movie.frameCount() - 1)
        self.movie.frameChanged.connect(self._sync_slider)

    def _save_gif(self):
        if self.final_gif_disk_path and os.path.exists(self.final_gif_disk_path):
            sensor = self.plugin.combo_sensor.currentText()
            filt = self.plugin.combo_filter.currentText()
            default_name = f"Satiladu_{sensor}_{filt}_timelapse.gif"
            
            path, _ = QFileDialog.getSaveFileName(self, "Save Timelapse", default_name, "GIF Files (*.gif)")
            if path:
                shutil.copy(self.final_gif_disk_path, path)
                self.plugin.log(f"Saved GIF to: {path}")