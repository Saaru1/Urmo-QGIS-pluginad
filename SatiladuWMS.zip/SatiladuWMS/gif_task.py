# -*- coding: utf-8 -*-
import os
import tempfile
import io
import datetime
from urllib.request import urlopen
from PIL import Image, ImageDraw, ImageFont, ImageFilter

from qgis.core import QgsTask, Qgis, QgsMessageLog

class GifGeneratorTask(QgsTask):
    def __init__(self, valid_frames, bbox_3301, width, height, sensor, filt, speed_ms, smooth, overlay_path, upscale, callback):
        super().__init__("Generating Satiladu Timelapse", QgsTask.CanCancel)
        self.valid_frames = valid_frames
        self.bbox_3301 = bbox_3301
        self.width = width
        self.height = height
        self.sensor = sensor
        self.filt = filt
        self.speed_ms = speed_ms
        self.smooth = smooth
        self.overlay_path = overlay_path
        self.upscale = upscale
        self.callback = callback
        
        self.temp_dir = tempfile.mkdtemp(prefix="qgis_satiladu_gif_")
        self.final_gif_path = os.path.join(self.temp_dir, "timelapse.gif")
        self.downloaded_files = []

    def run(self):
        try:
            total = len(self.valid_frames)
            
            overlay_img = None
            if self.overlay_path and os.path.exists(self.overlay_path):
                overlay_img = Image.open(self.overlay_path).convert("RGBA")
            
            for i, (dstr, base_url) in enumerate(self.valid_frames):
                if self.isCanceled():
                    return False
                    
                layer_param = base_url.split('?')[0].split('wms-')[-1].replace('-', '_')
                
                # Fetch as lossless PNG instead of JPEG to prevent initial compression artifacts
                getmap_url = (f"{base_url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                              f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={self.width}&HEIGHT={self.height}"
                              f"&LAYERS={layer_param}&STYLES=&FORMAT=image/png")
                
                with urlopen(getmap_url, timeout=15) as resp:
                    img = Image.open(io.BytesIO(resp.read())).convert("RGBA")

                # 1. Upscale & Sharpen the raw satellite background FIRST
                if self.upscale:
                    w, h = img.size
                    img = img.resize((int(w * 1.25), int(h * 1.25)), Image.Resampling.LANCZOS)
                    img = img.filter(ImageFilter.SHARPEN)
                    img = img.resize((w, h), Image.Resampling.LANCZOS)

                # 2. Composite the QGIS vectors SECOND so they remain entirely unaffected by sharpening
                if overlay_img:
                    if overlay_img.size != img.size:
                        overlay_img = overlay_img.resize(img.size, Image.Resampling.LANCZOS)
                    img = Image.alpha_composite(img, overlay_img)

                # 3. Draw date stamp
                draw = ImageDraw.Draw(img)
                draw_dstr = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
                anno_text = f"{self.sensor} {self.filt}  |  {draw_dstr}"

                try:
                    font_name = "arial.ttf" if os.name == 'nt' else "DejaVuSans.ttf"
                    font = ImageFont.truetype(font_name, 18)
                except Exception:
                    font = ImageFont.load_default()
                
                if hasattr(font, 'getbbox'):
                    left, top, right, bottom = font.getbbox(anno_text)
                    tw, th = right - left, bottom - top
                else:
                    tw, th = draw.textsize(anno_text, font=font)
                
                pad = 10
                draw.rectangle([(10, 10), (10 + tw + pad*2, 10 + th + pad*2)], fill="#222222")
                draw.text((10 + pad, 10 + pad), anno_text, fill="white", font=font)
                
                # 4. Save intermediate frame to disk cache as a lossless PNG
                frame_path = os.path.join(self.temp_dir, f"frame_{i:03d}.png")
                img.convert("RGB").save(frame_path, "PNG")
                self.downloaded_files.append(frame_path)
            
                self.setProgress((i / total) * 60)

            if self.isCanceled(): return False
            self.setProgress(70)

            base_images = [Image.open(f).convert("RGBA") for f in self.downloaded_files]
            final_images = []
            final_durations = []
            
            if self.smooth:
                blend_steps = 2 
                for i in range(len(base_images)):
                    if self.isCanceled(): return False
                    final_images.append(base_images[i])
                    final_durations.append(self.speed_ms)
                    
                    if i < len(base_images) - 1:
                        for step in range(1, blend_steps + 1):
                            alpha = step / (blend_steps + 1)
                            blended = Image.blend(base_images[i], base_images[i+1], alpha)
                            final_images.append(blended)
                            final_durations.append(int(self.speed_ms / 3))
            else:
                final_images = base_images
                final_durations = [self.speed_ms] * len(base_images)

            self.setProgress(90)
            if self.isCanceled(): return False

            # Force Adaptive Palette and Dithering to maximize GIF color fidelity
            try:
                adaptive_palette = Image.Palette.ADAPTIVE
            except AttributeError:
                adaptive_palette = Image.ADAPTIVE # Fallback for older Pillow versions in QGIS 3

            optimized_images = [
                img.convert("RGB").convert("P", palette=adaptive_palette, colors=256) 
                for img in final_images
            ]

            optimized_images[0].save(
                self.final_gif_path, 
                format='GIF', 
                save_all=True, 
                append_images=optimized_images[1:], 
                duration=final_durations, 
                loop=0,
                optimize=True
            )
            
            self.setProgress(100)
            return True
            
        except Exception as e:
            QgsMessageLog.logMessage(f"GIF Task Error: {str(e)}", "SentinelWMS", Qgis.Critical)
            return False

    def finished(self, result):
        if result and os.path.exists(self.final_gif_path):
            self.callback(self.final_gif_path)
        else:
            self.callback(None)