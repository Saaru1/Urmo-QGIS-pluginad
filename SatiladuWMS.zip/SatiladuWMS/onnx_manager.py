# -*- coding: utf-8 -*-
import os
import sys
import re
import site
import importlib
import datetime
from qgis.core import (
    QgsApplication, QgsProject, QgsRasterLayer, 
    QgsCoordinateReferenceSystem, QgsMessageLog, Qgis, QgsFileDownloader
)
from qgis.PyQt.QtCore import QObject, QTimer, QUrl, Qt, QRect, pyqtSignal
from qgis.PyQt.QtGui import QPainter, QColor, QPen, QLinearGradient
from qgis.PyQt.QtWidgets import QMessageBox, QWidget
from .onnx_worker import OnnxUpscaleTask, PipInstallTask

# Qt5 / Qt6 Compatibility bindings
try:
    BTN_YES = QMessageBox.StandardButton.Yes
    BTN_NO = QMessageBox.StandardButton.No
    ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    SMOOTH_TRANSFORM = Qt.TransformationMode.SmoothTransformation
    IGNORE_ASPECT = Qt.AspectRatioMode.IgnoreAspectRatio
except AttributeError:
    BTN_YES = QMessageBox.Yes
    BTN_NO = QMessageBox.No
    ALIGN_CENTER = Qt.AlignCenter
    SMOOTH_TRANSFORM = Qt.SmoothTransformation
    IGNORE_ASPECT = Qt.IgnoreAspectRatio

MODELS_REGISTRY = {
    "Real-ESRGAN 2x": {
        "filename": "upscale_2x.onnx",
        "url": "https://huggingface.co/fernandotonon/QtMeshEditor-realesrgan-onnx/resolve/main/RealESRGAN_x2plus.onnx",
        "scale": 2,
        "target_scale": 2,
        "size_mb": 64
    },
    "Real-ESRGAN 4x": {
        "filename": "upscale_4x.onnx",
        "url": "https://huggingface.co/qualcomm/Real-ESRGAN-x4plus/resolve/83db0da6e1b4969f85fe60ee713bd2c2b3160c23/Real-ESRGAN-x4plus.onnx",
        "scale": 4,
        "target_scale": 4,
        "size_mb": 67
    }
}

def get_available_models():
    """Returns models with 2x models ordered first, followed by 4x models."""
    models = list(MODELS_REGISTRY.keys())
    profile_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "satiladu_models")
    plugin_models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")

    known_filenames = {v["filename"].lower() for v in MODELS_REGISTRY.values()}
    known_filenames.update({
        "upscale_2x.onnx", "real-esrgan-x2plus.onnx", "realesrgan_x2plus.onnx", "real-esrgan 2x.onnx",
        "upscale_4x.onnx", "real-esrgan-x4plus.onnx", "realesrgan_x4plus.onnx", "real-esrgan 4x.onnx"
    })

    for directory in (profile_dir, plugin_models_dir):
        if os.path.exists(directory):
            for f in sorted(os.listdir(directory)):
                if f.lower().endswith(".onnx") and f.lower() not in known_filenames and f not in models:
                    models.append(f)

    def sort_key(name):
        lower = name.lower()
        priority = 0 if "2x" in lower else (1 if "4x" in lower else 2)
        is_preset = 0 if name in MODELS_REGISTRY else 1
        return (priority, is_preset, name)

    models.sort(key=sort_key)
    return models

def get_model_info(model_name):
    profile_dir = os.path.join(QgsApplication.qgisSettingsDirPath(), "satiladu_models")
    os.makedirs(profile_dir, exist_ok=True)
    plugin_models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")

    if model_name in MODELS_REGISTRY:
        info = MODELS_REGISTRY[model_name].copy()
        candidates = [info["filename"]]
        if "2x" in model_name.lower():
            candidates.extend(["upscale_2x.onnx", "RealESRGAN_x2plus.onnx", "Real-ESRGAN-x2plus.onnx", "Real-ESRGAN 2x.onnx"])
        elif "4x" in model_name.lower():
            candidates.extend(["upscale_4x.onnx", "RealESRGAN_x4plus.onnx", "Real-ESRGAN-x4plus.onnx", "Real-ESRGAN 4x.onnx"])

        found_path = None
        for cand in candidates:
            p_path = os.path.join(profile_dir, cand)
            f_path = os.path.join(plugin_models_dir, cand)
            if os.path.exists(p_path):
                found_path = p_path
                break
            elif os.path.exists(f_path):
                found_path = f_path
                break

        target_path = os.path.join(profile_dir, info["filename"])
        fallback_path = os.path.join(plugin_models_dir, info["filename"])
        info["path"] = found_path or (fallback_path if os.path.exists(fallback_path) and not os.path.exists(target_path) else target_path)

        if "target_scale" not in info:
            info["target_scale"] = info.get("scale", 2 if "2x" in model_name.lower() else 4)
        return info
    else:
        path = os.path.join(profile_dir, model_name)
        if not os.path.exists(path):
            path = os.path.join(plugin_models_dir, model_name)
        m = re.search(r'(\d+)x', model_name.lower())
        detected_scale = int(m.group(1)) if m else 2
        return {
            "filename": model_name,
            "path": path,
            "url": None,
            "scale": detected_scale,
            "target_scale": detected_scale,
            "size_mb": 0
        }


class UpscaleScanOverlay(QWidget):
    finished = pyqtSignal()

    def __init__(self, parent_canvas, target_rect, task_id="left", model_name="4x"):
        super().__init__(parent_canvas)
        self.task_id = task_id
        self.model_name = model_name
        self.setGeometry(target_rect)
        self.target_rect = target_rect

        full_grab = parent_canvas.grab(target_rect)
        self.base_pixmap = full_grab

        w, h = max(1, target_rect.width()), max(1, target_rect.height())
        small = full_grab.scaled(max(1, w // 10), max(1, h // 10), IGNORE_ASPECT, SMOOTH_TRANSFORM)
        self.blurred_pixmap = small.scaled(w, h, IGNORE_ASPECT, SMOOTH_TRANSFORM)

        self.upscaled_pixmap = None
        self.state = "SCANNING"
        self.scan_y = 0
        self.scan_dir = 1
        self.reveal_y = 0

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_tick)
        self.timer.start(16)
        self.show()
        self.raise_()

    def set_upscaled_image(self, image_path):
        if os.path.exists(image_path):
            from qgis.PyQt.QtGui import QPixmap
            raw_pixmap = QPixmap(image_path)
            w, h = self.width(), self.height()
            self.upscaled_pixmap = raw_pixmap.scaled(w, h, IGNORE_ASPECT, SMOOTH_TRANSFORM)
            self.state = "REVEALING"
            self.reveal_y = 0
        else:
            self._complete()

    def _on_tick(self):
        h = self.height()
        if self.state == "SCANNING":
            step = max(3, int(h * 0.025))
            self.scan_y += step * self.scan_dir
            if self.scan_y >= h:
                self.scan_y = h
                self.scan_dir = -1
            elif self.scan_y <= 0:
                self.scan_y = 0
                self.scan_dir = 1
            self.update()
        elif self.state == "REVEALING":
            step = max(5, int(h / 25))
            self.reveal_y += step
            if self.reveal_y >= h:
                self.reveal_y = h
                self.timer.stop()
                self.update()
                QTimer.singleShot(40, self._complete)
            else:
                self.update()

    def _complete(self):
        self.finished.emit()
        self.close()
        self.deleteLater()

    def paintEvent(self, event):
        painter = QPainter(self)
        w, h = self.width(), self.height()

        if self.state == "SCANNING":
            painter.drawPixmap(0, 0, self.blurred_pixmap)
            painter.fillRect(0, 0, w, h, QColor(0, 0, 0, 70))

            line_y = int(self.scan_y)
            grad = QLinearGradient(0, line_y - 25, 0, line_y + 25)
            grad.setColorAt(0.0, QColor(0, 220, 255, 0))
            grad.setColorAt(0.5, QColor(0, 220, 255, 160))
            grad.setColorAt(1.0, QColor(0, 220, 255, 0))
            painter.fillRect(0, line_y - 25, w, 50, grad)

            painter.setPen(QPen(QColor(255, 255, 255, 240), 2))
            painter.drawLine(0, line_y, w, line_y)

            badge_w, badge_h = 240, 36
            bx = (w - badge_w) // 2
            by = (h - badge_h) // 2
            painter.setBrush(QColor(20, 20, 20, 220))
            painter.setPen(QPen(QColor(0, 220, 255, 200), 1))
            painter.drawRoundedRect(bx, by, badge_w, badge_h, 5, 5)

            painter.setPen(QColor(255, 255, 255))
            font = painter.font()
            font.setBold(True)
            font.setPointSize(9)
            painter.setFont(font)
            painter.drawText(QRect(bx, by, badge_w, badge_h), ALIGN_CENTER, f"✨ AI Upscaling ({self.model_name})...")

        elif self.state == "REVEALING":
            ry = int(self.reveal_y)
            if ry > 0 and self.upscaled_pixmap:
                painter.drawPixmap(0, 0, w, ry, self.upscaled_pixmap, 0, 0, w, ry)

            if ry < h:
                painter.drawPixmap(0, ry, w, h - ry, self.blurred_pixmap, 0, ry, w, h - ry)
                painter.fillRect(0, ry, w, h - ry, QColor(0, 0, 0, 50))

            grad = QLinearGradient(0, ry - 30, 0, ry + 10)
            grad.setColorAt(0.0, QColor(0, 255, 180, 0))
            grad.setColorAt(0.7, QColor(0, 255, 180, 180))
            grad.setColorAt(1.0, QColor(0, 255, 180, 0))
            painter.fillRect(0, ry - 30, w, 40, grad)

            painter.setPen(QPen(QColor(255, 255, 255, 255), 2))
            painter.drawLine(0, ry, w, ry)

        painter.end()


class OnnxManager(QObject):
    def __init__(self, workspace):
        super().__init__(workspace.main_canvas)
        self.ws = workspace
        self.plugin = workspace.plugin

        self.upscale_layers = {"left": None, "right": None}
        self.upscale_active_tasks = []
        self.active_overlays = {"left": None, "right": None}

        self._is_installing_pip = False
        self._is_downloading_model = False
        self.file_downloader = None
        self.pip_task = None

    def trigger_upscale(self, task_id="left"):
        sensor = self.ws.combo_sensor.currentText()
        filt = self.ws.combo_filter.currentText()

        if sensor != "Sentinel-2" or filt != "RGB":
            QMessageBox.warning(
                self.ws.main_canvas,
                "Upscale Unavailable",
                "AI Upscaling is restricted to Sentinel-2 RGB imagery to prevent spatial hallucinations on false-color filters or mismatched sensor resolutions."
            )
            return

        if self._is_installing_pip or self._is_downloading_model:
            return

        if not self._ensure_onnx_installed():
            return

        model_name = self.ws.combo_model.currentText()
        model_info = get_model_info(model_name)
        model_path = model_info["path"]

        if not os.path.exists(model_path):
            if model_info.get("url"):
                self._prompt_model_download(model_info)
            else:
                QMessageBox.warning(self.ws.main_canvas, "Model Missing", f"Custom model file not found:\n{model_path}")
            return

        canvas = self.ws.main_canvas
        w, h = canvas.width(), canvas.height()

        if not self.ws.is_compare_mode:
            target_rect = QRect(0, 0, w, h)
            dstr = self.ws.current_left_date
        else:
            split = getattr(self.ws, 'split_x', w // 2)
            if task_id == "left":
                target_rect = QRect(0, 0, split, h)
                dstr = self.ws.current_left_date
            else:
                target_rect = QRect(split, 0, w - split, h)
                dstr = self.ws.current_right_date

        if not dstr:
            return

        _, url = self.ws._get_closest_valid_date(datetime.date.fromisoformat(dstr))
        if not url:
            return

        if self.active_overlays.get(task_id):
            try:
                self.active_overlays[task_id].close()
            except Exception:
                pass
        overlay = UpscaleScanOverlay(canvas, target_rect, task_id, model_name)
        self.active_overlays[task_id] = overlay

        bbox = self.plugin.layers.get_canvas_bbox_3301_str()
        xmin, ymin, xmax, ymax = map(float, bbox.split(','))
        extent_w = xmax - xmin
        extent_h = ymax - ymin

        native_w = max(64, int(round(extent_w / 10.0)))
        native_h = max(64, int(round(extent_h / 10.0)))

        scale = model_info.get("scale", 2)
        target_scale = model_info.get("target_scale", scale)
        req_w = min(w // scale, native_w)
        req_h = min(h // scale, native_h)
        req_w = max(64, req_w)
        req_h = max(64, req_h)

        task = OnnxUpscaleTask(bbox, req_w, req_h, url, model_path, self._on_upscale_task_finished, task_id, target_scale=target_scale)
        self.upscale_active_tasks.append(task)
        self._update_button_state(task_id, True)
        QgsApplication.taskManager().addTask(task)

    def clear_upscale_layers(self):
        proj = QgsProject.instance()
        for task_id in ["left", "right"]:
            lyr = self.upscale_layers.get(task_id)
            if lyr:
                try:
                    proj.removeMapLayer(lyr.id())
                except Exception:
                    pass
            self.upscale_layers[task_id] = None

            overlay = self.active_overlays.get(task_id)
            if overlay:
                try:
                    overlay.close()
                except Exception:
                    pass
            self.active_overlays[task_id] = None

        for task in self.upscale_active_tasks:
            try:
                task.cancel()
            except Exception:
                pass
        self.upscale_active_tasks.clear()
        self._reset_button_labels()
        if hasattr(self.ws, 'update_date_button_labels'):
            self.ws.update_date_button_labels()

    def _update_button_state(self, task_id, is_busy):
        if not self.ws.is_compare_mode:
            if hasattr(self.ws, 'btn_upscale'):
                self.ws.btn_upscale.setText("⏳ Enhancing..." if is_busy else "✨ Upscale")
                self.ws.btn_upscale.setEnabled(not is_busy)
        else:
            btn = getattr(self.ws, f'btn_upscale_{task_id}', None)
            if btn:
                btn.setText("⏳ Enhancing..." if is_busy else "✨ Upscale")
                btn.setEnabled(not is_busy)
        self.ws._resize_items()

    def _reset_button_labels(self):
        if hasattr(self.ws, 'btn_upscale'):
            self.ws.btn_upscale.setText("✨ Upscale")
            self.ws.btn_upscale.setEnabled(True)
        if hasattr(self.ws, 'btn_upscale_left'):
            self.ws.btn_upscale_left.setText("✨ Upscale")
            self.ws.btn_upscale_left.setEnabled(True)
        if hasattr(self.ws, 'btn_upscale_right'):
            self.ws.btn_upscale_right.setText("✨ Upscale")
            self.ws.btn_upscale_right.setEnabled(True)
        self.ws._resize_items()

    def _ensure_onnx_installed(self):
        user_site = site.getusersitepackages()
        if os.path.exists(user_site) and user_site not in sys.path:
            sys.path.insert(0, user_site)

        try:
            import onnxruntime
            return True
        except ImportError:
            pass

        if self._is_installing_pip:
            return False

        reply = QMessageBox.question(
            self.ws.main_canvas,
            "Missing Dependencies",
            "AI Upscaling requires 'onnxruntime-directml' to run GPU-accelerated inference.\n\nWould you like QGIS to install it automatically now via pip?",
            BTN_YES | BTN_NO,
            BTN_YES
        )

        if reply == BTN_YES:
            self._is_installing_pip = True
            if hasattr(self.ws, 'btn_upscale'):
                self.ws.btn_upscale.setText("⏳ Pip: Starting...")
                self.ws.btn_upscale.setEnabled(False)
            self.ws._resize_items()

            self.pip_task = PipInstallTask("onnxruntime-directml", self._on_pip_finished)
            self.pip_task.sig_log.connect(lambda msg: self.plugin.log(msg, Qgis.Info))
            self.pip_task.sig_progress.connect(self._on_pip_progress)
            QgsApplication.taskManager().addTask(self.pip_task)

        return False

    def _on_pip_progress(self, pct, label):
        txt = f"⏳ Pip: {label}"
        if hasattr(self.ws, 'btn_upscale'):
            self.ws.btn_upscale.setText(txt)
        self.ws._resize_items()

    def _on_pip_finished(self, success, last_output):
        self._is_installing_pip = False
        self.pip_task = None
        self._reset_button_labels()

        if success:
            user_site = site.getusersitepackages()
            if os.path.exists(user_site) and user_site not in sys.path:
                sys.path.insert(0, user_site)
            importlib.invalidate_caches()
            try:
                import onnxruntime
                self.plugin.log("onnxruntime-directml verified successfully.")
            except Exception:
                QMessageBox.information(
                    self.ws.main_canvas,
                    "Restart Required",
                    "onnxruntime-directml was installed successfully into your QGIS profile.\n\nPlease restart QGIS once so Windows DirectML DLLs can register into the runtime."
                )
        else:
            self.plugin.log(f"Pip install failed:\n{last_output}", Qgis.Critical)
            QMessageBox.critical(
                self.ws.main_canvas,
                "Installation Failed",
                f"Failed to install onnxruntime-directml via pip. Open View -> Panels -> Log Messages ('SentinelWMS' tab) for details.\n\n{last_output[:250]}"
            )

    def _prompt_model_download(self, model_info):
        if self._is_downloading_model:
            return

        model_name = model_info["filename"]
        size_mb = model_info.get("size_mb", 67)
        model_path = model_info["path"]

        reply = QMessageBox.question(
            self.ws.main_canvas,
            "Missing AI Model",
            f"The AI upscaling model '{model_name}' was not found.\n\nWould you like to download it now? (~{size_mb}MB)\n\nIt will be saved persistently to your QGIS profile directory.",
            BTN_YES | BTN_NO,
            BTN_NO
        )

        if reply == BTN_YES:
            self._is_downloading_model = True
            if hasattr(self.ws, 'btn_upscale'):
                self.ws.btn_upscale.setText("⏳ Connecting...")
                self.ws.btn_upscale.setEnabled(False)
            self.ws._resize_items()

            self.file_downloader = QgsFileDownloader(QUrl(model_info["url"]), model_path)
            self.file_downloader.downloadProgress.connect(self._on_qgis_download_progress)
            self.file_downloader.downloadCompleted.connect(self._on_qgis_download_completed)
            self.file_downloader.downloadError.connect(self._on_qgis_download_error)
            self.file_downloader.downloadCanceled.connect(self._on_qgis_download_canceled)

    def _on_qgis_download_progress(self, bytes_received, bytes_total):
        if bytes_total > 0:
            pct = int((bytes_received / bytes_total) * 100)
            mb_done = bytes_received / (1024 * 1024)
            mb_tot = bytes_total / (1024 * 1024)
            txt = f"⏳ {pct}% ({mb_done:.1f}/{mb_tot:.1f}MB)"
        elif bytes_received > 0:
            mb_done = bytes_received / (1024 * 1024)
            txt = f"⏳ {mb_done:.1f} MB"
        else:
            txt = "⏳ Downloading..."

        if hasattr(self.ws, 'btn_upscale'):
            self.ws.btn_upscale.setText(txt)
        self.ws._resize_items()

    def _on_qgis_download_completed(self):
        QTimer.singleShot(150, self._after_download_success)

    def _after_download_success(self):
        self._is_downloading_model = False
        self.file_downloader = None
        self._reset_button_labels()
        self.plugin.log("Model downloaded persistently via QGIS native engine.")

    def _on_qgis_download_error(self, errors):
        self._is_downloading_model = False
        self.file_downloader = None
        err_msg = ", ".join(errors) if isinstance(errors, list) else str(errors)
        self.plugin.log(f"QGIS Downloader Error: {err_msg}", Qgis.Critical)

        self._reset_button_labels()
        QMessageBox.warning(self.ws.main_canvas, "Download Failed", f"Failed to download the model:\n{err_msg}")

    def _on_qgis_download_canceled(self):
        self._is_downloading_model = False
        self.file_downloader = None
        self._reset_button_labels()

    def _on_upscale_task_finished(self, filepath, task_id):
        self._update_button_state(task_id, False)
        overlay = self.active_overlays.get(task_id)

        if not filepath or not os.path.exists(filepath):
            if overlay:
                overlay.close()
                self.active_overlays[task_id] = None
            return

        if overlay:
            overlay.set_upscaled_image(filepath)
            overlay.finished.connect(lambda: self._mount_raster_after_reveal(filepath, task_id))
        else:
            self._mount_raster_after_reveal(filepath, task_id)

    def _mount_raster_after_reveal(self, filepath, task_id):
        layer = QgsRasterLayer(filepath, f"Enhanced {task_id.capitalize()}", "gdal")
        layer.setCrs(QgsCoordinateReferenceSystem("EPSG:3301"))

        if layer.isValid():
            old_layer = self.upscale_layers.get(task_id)
            if old_layer:
                try:
                    QgsProject.instance().removeMapLayer(old_layer.id())
                except Exception:
                    pass

            self.upscale_layers[task_id] = layer

            if task_id == "left":
                self.plugin.layers.add_layer_at_top(layer)
            else:
                QgsProject.instance().addMapLayer(layer, False)

            root = QgsProject.instance().layerTreeRoot()
            node = root.findLayer(layer.id())
            if node:
                node.setItemVisibilityChecked(True)

            layer.triggerRepaint()
            self.ws.main_canvas.refresh()

            if self.ws.is_compare_mode:
                self.ws._sync_layers()

            if hasattr(self.ws, 'update_date_button_labels'):
                self.ws.update_date_button_labels()
            self.plugin.log(f"Enhanced {task_id} layer rendered onto canvas.", Qgis.Success)

        self.active_overlays[task_id] = None

    def cleanup(self):
        self.clear_upscale_layers()
        if self.file_downloader:
            try:
                self.file_downloader.cancelDownload()
            except Exception:
                pass
            self.file_downloader = None
        if self.pip_task:
            try:
                self.pip_task.cancel()
            except Exception:
                pass
            self.pip_task = None
