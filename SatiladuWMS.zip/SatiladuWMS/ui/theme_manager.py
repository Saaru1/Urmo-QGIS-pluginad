# -*- coding: utf-8 -*-
from qgis.core import QgsSettings

_current_theme = None

def get_current_theme():
    global _current_theme
    if _current_theme is None:
        settings = QgsSettings()
        _current_theme = settings.value("satiladu/ui_theme", "dark")
        if _current_theme not in ("dark", "light"):
            _current_theme = "dark"
    return _current_theme

def set_current_theme(theme):
    global _current_theme
    if theme in ("dark", "light"):
        _current_theme = theme
        settings = QgsSettings()
        settings.setValue("satiladu/ui_theme", theme)

def is_dark():
    return get_current_theme() == "dark"


def get_theme_styles():
    dark = is_dark()

    if dark:
        return {
            "is_dark": True,
            "container_bg": "background: rgba(28, 28, 30, 245); border: 1px solid rgba(80, 80, 85, 200); border-radius: 6px;",
            "btn_style": (
                "QPushButton { background-color: #38383c; color: #f0f0f2; border: 1px solid #5a5a60; border-radius: 3px; padding: 4px 8px; font-weight: bold; font-size: 11px; } "
                "QPushButton:hover { background-color: #4a4a50; border-color: #707078; } "
                "QPushButton:disabled { background-color: #2a2a2e; color: #6a6a72; border-color: #3a3a40; }"
            ),
            "btn_active_tool_style": (
                "QPushButton { background-color: #0078d7; color: white; border: 1px solid #005a9e; border-radius: 3px; padding: 4px 8px; font-weight: bold; font-size: 11px; } "
                "QPushButton:hover { background-color: #0063b1; }"
            ),
            "btn_date_active_style": (
                "QPushButton { background: rgba(30,30,32,235); color: #ffffff; border-radius: 4px; padding: 6px 12px; font-size: 13px; font-weight: bold; border: 2px solid #0078d7; } "
                "QPushButton:hover { background: rgba(50,50,55,245); border: 2px solid #5cb85c; }"
            ),
            "btn_date_inactive_style": (
                "QPushButton { background: rgba(30,30,32,235); color: #e0e0e4; border-radius: 4px; padding: 6px 12px; font-size: 13px; font-weight: bold; border: 1px solid #606068; } "
                "QPushButton:hover { background: rgba(45,45,50,240); }"
            ),
            "btn_date_enhanced_style": (
                "QPushButton { background: rgba(20,32,45,240); color: #00d4ff; border-radius: 4px; padding: 6px 12px; font-size: 13px; font-weight: bold; border: 2px solid #00d4ff; } "
                "QPushButton:hover { background: rgba(30,48,65,245); border: 2px solid #5ce1e6; }"
            ),
            "combo_style": (
                "QComboBox { background-color: #38383c; color: #ffffff; border: 1px solid #5a5a60; border-radius: 3px; padding: 3px 6px; font-size: 11px; } "
                "QComboBox::drop-down { border: none; } "
                "QComboBox QAbstractItemView { background-color: #2b2b2f; color: #ffffff; selection-background-color: #0078d7; selection-color: #ffffff; border: 1px solid #444; outline: none; margin: 0px; padding: 2px; } "
                "QComboBox QListView { border: none; background-color: #2b2b2f; color: #ffffff; }"
            ),
            "dialog_style": (
                "QDialog { background-color: #27272a; color: #ffffff; } "
                "QLabel { color: #f0f0f2; font-size: 12px; } "
                "QCheckBox { color: #f0f0f2; font-size: 12px; } "
                "QPushButton { background-color: #0078d7; color: white; border-radius: 4px; padding: 6px 14px; font-weight: bold; } "
                "QPushButton:hover { background-color: #005a9e; } "
                "QPushButton:disabled { background-color: #444; color: #888; } "
                "QComboBox { background-color: #38383c; color: white; border: 1px solid #555; border-radius: 3px; padding: 4px; } "
                "QComboBox QAbstractItemView { background-color: #252528; color: white; selection-background-color: #0078d7; selection-color: white; border: 1px solid #444; } "
                "QDateEdit { background-color: #38383c; color: #ffffff; border: 1px solid #5a5a60; border-radius: 3px; padding: 3px 6px; } "
                "QDateEdit::drop-down { border: none; } "
                "QDateEdit QAbstractItemView { background-color: #252528; color: #ffffff; selection-background-color: #0078d7; } "
                "QSpinBox { background-color: #38383c; color: #ffffff; border: 1px solid #5a5a60; border-radius: 3px; padding: 3px; } "
                "QProgressBar { background: #222; border: 1px solid #555; border-radius: 3px; height: 14px; text-align: center; color: white; } "
                "QProgressBar::chunk { background: #0078d7; } "
                "QCalendarWidget QWidget { alternate-background-color: #35353a; color: white; } "
                "QCalendarWidget QAbstractItemView:enabled { background-color: #252528; color: white; selection-background-color: #0078d7; } "
                "QCalendarWidget QToolButton { color: white; } "
                "QCalendarWidget QMenu { background-color: #252528; color: white; } "
                "QCalendarWidget QSpinBox { background-color: #35353a; color: white; border: 1px solid #555; } "
                "QSlider::groove:horizontal { background: #444; height: 6px; border-radius: 3px; } "
                "QSlider::sub-page:horizontal { background: #0078d7; border-radius: 3px; } "
                "QSlider::handle:horizontal { background: #00d4ff; width: 14px; margin-top: -4px; margin-bottom: -4px; border-radius: 7px; }"
            ),
            "hud_bg": "background: rgba(30, 30, 32, 235); border: 1px solid #555; border-radius: 6px;",
            "text_color": "#ffffff",
            "text_sub": "#aaaaaa",
            "border_color": "#5a5a60"
        }
    else:
        return {
            "is_dark": False,
            "container_bg": "background: rgba(250, 250, 252, 248); border: 1px solid rgba(185, 188, 200, 230); border-radius: 6px;",
            "btn_style": (
                "QPushButton { background-color: #f0f0f4; color: #1e1e24; border: 1px solid #b8bac2; border-radius: 3px; padding: 4px 8px; font-weight: bold; font-size: 11px; } "
                "QPushButton:hover { background-color: #e2e4ec; border-color: #989aa4; } "
                "QPushButton:disabled { background-color: #f4f4f6; color: #9a9ba4; border-color: #dcdee4; }"
            ),
            "btn_active_tool_style": (
                "QPushButton { background-color: #0078d7; color: white; border: 1px solid #005a9e; border-radius: 3px; padding: 4px 8px; font-weight: bold; font-size: 11px; } "
                "QPushButton:hover { background-color: #0063b1; }"
            ),
            "btn_date_active_style": (
                "QPushButton { background: rgba(255,255,255,248); color: #111111; border-radius: 4px; padding: 6px 12px; font-size: 13px; font-weight: bold; border: 2px solid #0078d7; } "
                "QPushButton:hover { background: rgba(240,242,248,250); border: 2px solid #2e7d32; }"
            ),
            "btn_date_inactive_style": (
                "QPushButton { background: rgba(255,255,255,242); color: #222226; border-radius: 4px; padding: 6px 12px; font-size: 13px; font-weight: bold; border: 1px solid #b0b2ba; } "
                "QPushButton:hover { background: rgba(240,242,246,245); }"
            ),
            "btn_date_enhanced_style": (
                "QPushButton { background: rgba(235,245,255,248); color: #005a9e; border-radius: 4px; padding: 6px 12px; font-size: 13px; font-weight: bold; border: 2px solid #0078d7; } "
                "QPushButton:hover { background: rgba(220,238,255,250); border: 2px solid #005a9e; }"
            ),
            "combo_style": (
                "QComboBox { background-color: #ffffff; color: #1e1e24; border: 1px solid #b8bac2; border-radius: 3px; padding: 3px 6px; font-size: 11px; } "
                "QComboBox::drop-down { border: none; } "
                "QComboBox QAbstractItemView { background-color: #ffffff; color: #1e1e24; selection-background-color: #0078d7; selection-color: #ffffff; border: 1px solid #b0b2ba; outline: none; margin: 0px; padding: 2px; } "
                "QComboBox QListView { border: none; background-color: #ffffff; color: #1e1e24; }"
            ),
            "dialog_style": (
                "QDialog { background-color: #f7f7f9; color: #1a1a1e; } "
                "QLabel { color: #1a1a1e; font-size: 12px; } "
                "QCheckBox { color: #1a1a1e; font-size: 12px; } "
                "QPushButton { background-color: #0078d7; color: white; border-radius: 4px; padding: 6px 14px; font-weight: bold; } "
                "QPushButton:hover { background-color: #005a9e; } "
                "QPushButton:disabled { background-color: #ccc; color: #777; } "
                "QComboBox { background-color: #ffffff; color: #1a1a1e; border: 1px solid #b8bac2; border-radius: 3px; padding: 4px; } "
                "QComboBox QAbstractItemView { background-color: #ffffff; color: #1a1a1e; selection-background-color: #0078d7; selection-color: white; border: 1px solid #b0b2ba; } "
                "QDateEdit { background-color: #ffffff; color: #1e1e24; border: 1px solid #b8bac2; border-radius: 3px; padding: 3px 6px; } "
                "QDateEdit::drop-down { border: none; } "
                "QDateEdit QAbstractItemView { background-color: #ffffff; color: #1e1e24; selection-background-color: #0078d7; selection-color: white; } "
                "QSpinBox { background-color: #ffffff; color: #1e1e24; border: 1px solid #b8bac2; border-radius: 3px; padding: 3px; } "
                "QProgressBar { background: #e8eaf0; border: 1px solid #b8bac2; border-radius: 3px; height: 14px; text-align: center; color: #1e1e24; } "
                "QProgressBar::chunk { background: #0078d7; } "
                "QCalendarWidget QWidget { alternate-background-color: #f0f2f6; color: #1e1e24; } "
                "QCalendarWidget QAbstractItemView:enabled { background-color: #ffffff; color: #1e1e24; selection-background-color: #0078d7; selection-color: white; } "
                "QCalendarWidget QToolButton { color: #1e1e24; } "
                "QCalendarWidget QMenu { background-color: #ffffff; color: #1e1e24; } "
                "QCalendarWidget QSpinBox { background-color: #ffffff; color: #1e1e24; border: 1px solid #ccc; } "
                "QSlider::groove:horizontal { background: #d0d2da; height: 6px; border-radius: 3px; } "
                "QSlider::sub-page:horizontal { background: #0078d7; border-radius: 3px; } "
                "QSlider::handle:horizontal { background: #0078d7; width: 14px; margin-top: -4px; margin-bottom: -4px; border-radius: 7px; }"
            ),
            "hud_bg": "background: rgba(250, 250, 252, 245); border: 1px solid #b8bac2; border-radius: 6px;",
            "text_color": "#1a1a1e",
            "text_sub": "#555555",
            "border_color": "#b8bac2"
        }
