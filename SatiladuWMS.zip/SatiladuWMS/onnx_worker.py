# -*- coding: utf-8 -*-
import os
import sys
import re
import site
import tempfile
import urllib.request
import subprocess
import threading
import numpy as np
from PIL import Image
from qgis.core import QgsTask, QgsMessageLog, Qgis, QgsApplication, QgsCoordinateReferenceSystem
from qgis.PyQt.QtCore import pyqtSignal

# Mutex to ensure DirectML command queues are submitted sequentially across threads
_DML_LOCK = threading.Lock()

def find_qgis_python():
    """Locate the true python.exe binary associated with this QGIS instance."""
    prefix = QgsApplication.prefixPath()
    qgis_bin = os.path.normpath(os.path.join(prefix, "..", "..", "bin"))
    
    candidates = [
        os.path.join(sys.prefix, "python.exe"),
        os.path.join(sys.prefix, "bin", "python.exe"),
        os.path.join(qgis_bin, "python3.exe"),
        os.path.join(qgis_bin, "python.exe"),
        os.path.join(os.path.dirname(sys.executable), "python.exe"),
        os.path.join(os.path.dirname(sys.executable), "python3.exe"),
    ]
    for p in candidates:
        if os.path.isfile(p) and p.lower().endswith(".exe") and not p.lower().endswith("qgis-bin.exe"):
            return p
    return sys.executable


def run_onnx_upscale(img, model_path, is_canceled_func=None, progress_func=None, target_scale=None):
    """
    Executes tiled ONNX super-resolution on a PIL Image (RGB) using DirectML.
    Returns the upscaled PIL Image (RGB) or None if canceled/failed.
    """
    user_site = site.getusersitepackages()
    if user_site not in sys.path and os.path.exists(user_site):
        sys.path.insert(0, user_site)

    import onnxruntime as ort

    np_in = np.array(img, dtype=np.float32) / 255.0
    orig_h, orig_w, _ = np_in.shape

    with _DML_LOCK:
        if is_canceled_func and is_canceled_func():
            return None

        session = ort.InferenceSession(
            model_path, 
            providers=['DmlExecutionProvider', 'CPUExecutionProvider']
        )
        input_info = session.get_inputs()[0]
        output_info = session.get_outputs()[0]
        input_name = input_info.name

        shape_in = input_info.shape
        shape_out = output_info.shape

        tile_h = shape_in[2] if len(shape_in) > 2 and isinstance(shape_in[2], int) and shape_in[2] > 0 else 64
        tile_w = shape_in[3] if len(shape_in) > 3 and isinstance(shape_in[3], int) and shape_in[3] > 0 else 64

        if len(shape_out) > 2 and isinstance(shape_out[2], int) and shape_out[2] > 0 and tile_h > 0:
            scale = int(round(shape_out[2] / tile_h))
        else:
            scale = 2

        overlap = min(16, tile_h // 4) if tile_h >= 32 else 0
        step_y = max(1, tile_h - overlap)
        step_x = max(1, tile_w - overlap)

        pad_bottom = max(0, tile_h - orig_h)
        pad_right = max(0, tile_w - orig_w)
        if pad_bottom > 0 or pad_right > 0:
            np_in = np.pad(np_in, ((0, pad_bottom), (0, pad_right), (0, 0)), mode='reflect')

        h_in, w_in, _ = np_in.shape

        def get_coords(length, tile_dim, step):
            if length <= tile_dim:
                return [0]
            coords = list(range(0, length - tile_dim, step))
            if coords[-1] != length - tile_dim:
                coords.append(length - tile_dim)
            return coords

        y_coords = get_coords(h_in, tile_h, step_y)
        x_coords = get_coords(w_in, tile_w, step_x)

        out_tile_h = tile_h * scale
        out_tile_w = tile_w * scale
        feather_pad = overlap * scale

        y_ramp = np.ones(out_tile_h, dtype=np.float32)
        x_ramp = np.ones(out_tile_w, dtype=np.float32)
        if feather_pad > 0:
            ramp_y = np.linspace(0.1, 1.0, feather_pad, dtype=np.float32)
            y_ramp[:feather_pad] = ramp_y
            y_ramp[-feather_pad:] = ramp_y[::-1]
            ramp_x = np.linspace(0.1, 1.0, feather_pad, dtype=np.float32)
            x_ramp[:feather_pad] = ramp_x
            x_ramp[-feather_pad:] = ramp_x[::-1]

        tile_weight = np.outer(y_ramp, x_ramp)[:, :, np.newaxis]

        output_canvas = np.zeros((h_in * scale, w_in * scale, 3), dtype=np.float32)
        weight_canvas = np.zeros((h_in * scale, w_in * scale, 1), dtype=np.float32)

        total_tiles = len(y_coords) * len(x_coords)
        processed = 0

        for y in y_coords:
            for x in x_coords:
                if is_canceled_func and is_canceled_func():
                    return None

                tile = np_in[y:y + tile_h, x:x + tile_w, :]
                tensor = np.transpose(tile, (2, 0, 1))[np.newaxis, ...].astype(np.float32)

                out_tensor = session.run(None, {input_name: tensor})[0]
                out_tile = np.clip(np.squeeze(out_tensor), 0.0, 1.0)
                out_tile = np.transpose(out_tile, (1, 2, 0))

                oy, ox = y * scale, x * scale
                output_canvas[oy:oy + out_tile_h, ox:ox + out_tile_w, :] += out_tile * tile_weight
                weight_canvas[oy:oy + out_tile_h, ox:ox + out_tile_w, :] += tile_weight

                processed += 1
                if progress_func:
                    progress_func(processed, total_tiles)

        output_canvas /= np.maximum(weight_canvas, 1e-5)
        final_h = orig_h * scale
        final_w = orig_w * scale
        cropped_out = output_canvas[:final_h, :final_w, :]

        res_img = Image.fromarray((cropped_out * 255.0).astype(np.uint8))
        if target_scale and target_scale != scale:
            res_w = int(round(orig_w * target_scale))
            res_h = int(round(orig_h * target_scale))
            res_img = res_img.resize((res_w, res_h), Image.Resampling.LANCZOS)
        return res_img


class PipInstallTask(QgsTask):
    sig_log = pyqtSignal(str)
    sig_progress = pyqtSignal(float, str)

    def __init__(self, package_name, callback):
        super().__init__(f"Installing {package_name}", QgsTask.CanCancel)
        self.package_name = package_name
        self.callback = callback
        self.py_exe = find_qgis_python()
        self.success = False
        self.output_lines = []

    def run(self):
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

        cmd = [
            self.py_exe, "-u", "-m", "pip", "install",
            "--user",
            "--no-input",
            "--disable-pip-version-check",
            "--prefer-binary",
            self.package_name
        ]

        self.sig_log.emit(f"Python interpreter: {self.py_exe}")
        self.sig_log.emit(f"Executing: {' '.join(cmd)}")
        self.sig_progress.emit(5.0, "Resolving...")

        try:
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
                creationflags=creationflags
            )

            pct_regex = re.compile(r'(\d+)%')

            for line in iter(proc.stdout.readline, ''):
                if self.isCanceled():
                    proc.kill()
                    return False

                clean = line.strip()
                if not clean:
                    continue

                self.output_lines.append(clean)
                self.sig_log.emit(clean)

                lower = clean.lower()
                pct_match = pct_regex.search(clean)

                if pct_match:
                    pct = float(pct_match.group(1))
                    self.sig_progress.emit(pct, f"{int(pct)}%")
                elif "collecting" in lower:
                    self.sig_progress.emit(15.0, "Collecting...")
                elif "downloading" in lower:
                    self.sig_progress.emit(40.0, "Downloading...")
                elif "installing" in lower or "running setup" in lower:
                    self.sig_progress.emit(80.0, "Installing...")

            proc.wait()
            self.success = (proc.returncode == 0)

            if self.success:
                self.sig_progress.emit(100.0, "Done!")
                user_site = site.getusersitepackages()
                if user_site not in sys.path and os.path.exists(user_site):
                    sys.path.insert(0, user_site)

            return self.success
        except Exception as e:
            self.sig_log.emit(f"Pip execution error: {str(e)}")
            return False

    def finished(self, result):
        self.callback(self.success, "\n".join(self.output_lines[-10:]))


class OnnxUpscaleTask(QgsTask):
    def __init__(self, bbox_3301, width, height, wms_url, model_path, callback, task_id="left", target_scale=None):
        super().__init__(f"AI Upscaling ({task_id})", QgsTask.CanCancel)
        self.bbox_3301 = bbox_3301
        self.width = width
        self.height = height
        self.wms_url = wms_url
        self.model_path = model_path
        self.callback = callback
        self.task_id = task_id 
        self.target_scale = target_scale
        
        self.temp_dir = tempfile.mkdtemp(prefix="satiladu_onnx_")
        self.out_png = os.path.join(self.temp_dir, f"upscaled_{self.task_id}.png")
        self.out_pgw = os.path.join(self.temp_dir, f"upscaled_{self.task_id}.pgw")
        self.out_prj = os.path.join(self.temp_dir, f"upscaled_{self.task_id}.prj")
        self.out_aux = os.path.join(self.temp_dir, f"upscaled_{self.task_id}.png.aux.xml")

    def run(self):
        try:
            layer_param = self.wms_url.split('?')[0].split('wms-')[-1].replace('-', '_')
            getmap_url = (f"{self.wms_url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                          f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={self.width}&HEIGHT={self.height}"
                          f"&LAYERS={layer_param}&STYLES=&FORMAT=image/png")

            req = urllib.request.Request(getmap_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                if self.isCanceled(): return False
                img = Image.open(resp).convert("RGB")

            def on_progress(done, total):
                if done % 15 == 0 or done == total:
                    self.setProgress(int((done / total) * 100))

            final_img = run_onnx_upscale(
                img, 
                self.model_path, 
                is_canceled_func=self.isCanceled, 
                progress_func=on_progress,
                target_scale=self.target_scale
            )

            if not final_img or self.isCanceled():
                return False

            final_img.save(self.out_png)

            # World File (.pgw) Georeferencing
            xmin, ymin, xmax, ymax = map(float, self.bbox_3301.split(','))
            out_w_px, out_h_px = final_img.size

            pixel_x = (xmax - xmin) / out_w_px
            pixel_y = (ymax - ymin) / out_h_px

            with open(self.out_pgw, 'w') as f:
                f.write(f"{pixel_x}\n0.0\n0.0\n-{pixel_y}\n{xmin + (pixel_x / 2)}\n{ymax - (pixel_y / 2)}\n")

            # Sidecar Projection Metadata (.prj & .aux.xml) for EPSG:3301
            crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
            try:
                wkt_str = crs_3301.toWkt(QgsCoordinateReferenceSystem.WktVariant.WktVariant_WKT1_GDAL)
            except Exception:
                try:
                    wkt_str = crs_3301.toWkt(QgsCoordinateReferenceSystem.WKT1_GDAL)
                except Exception:
                    wkt_str = crs_3301.toWkt()

            with open(self.out_prj, 'w', encoding='utf-8') as f:
                f.write(wkt_str)

            with open(self.out_aux, 'w', encoding='utf-8') as f:
                f.write(f'<PAMDataset><SRS dataAxisToSRSAxisMapping="1,2">{wkt_str}</SRS></PAMDataset>')

            return True
        except Exception as e:
            QgsMessageLog.logMessage(f"AI Upscale Error: {str(e)}", "SentinelWMS", Qgis.Critical)
            return False

    def finished(self, result):
        if result and os.path.exists(self.out_png):
            self.callback(self.out_png, self.task_id)
        else:
            self.callback(None, self.task_id)