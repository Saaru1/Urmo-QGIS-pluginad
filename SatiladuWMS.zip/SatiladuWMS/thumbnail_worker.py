# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QObject, pyqtSignal, QUrl, Qt
from qgis.PyQt.QtGui import QImage, QPixmap
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
import collections

class ThumbnailManager(QObject):
    def __init__(self, parent=None, max_concurrent=4, max_cache_size=150):
        super().__init__(parent)
        self.nam = QNetworkAccessManager(self)
        self.max_concurrent = max_concurrent
        self.max_cache_size = max_cache_size
        
        self.cache = collections.OrderedDict() 
        self.queue = [] 
        self.active_replies = {} 
        
    def request_thumbnail(self, url, callback, priority=0):
        if url in self.cache:
            self.cache.move_to_end(url)
            self._safe_callback(callback, self.cache[url])
            return

        for item in self.queue:
            if item['url'] == url:
                item['priority'] = max(item['priority'], priority)
                item['callback'] = callback 
                self._sort_queue()
                return
        
        self.queue.append({'url': url, 'callback': callback, 'priority': priority})
        self._sort_queue()
        self._pump_queue()
        
    def _sort_queue(self):
        self.queue.sort(key=lambda x: x['priority'], reverse=True)
        
    def _pump_queue(self):
        while len(self.active_replies) < self.max_concurrent and self.queue:
            req_item = self.queue.pop(0)
            url = req_item['url']
            
            if url in self.cache:
                self._safe_callback(req_item['callback'], self.cache[url])
                continue
                
            req = QNetworkRequest(QUrl(url))
            reply = self.nam.get(req)
            
            reply.finished.connect(lambda r=reply, u=url, cb=req_item['callback']: self._on_reply_finished(r, u, cb))
            self.active_replies[reply] = url

    def _on_reply_finished(self, reply, url, callback):
        if reply in self.active_replies:
            del self.active_replies[reply]
            
        try:
            no_error = QNetworkReply.NetworkError.NoError
        except AttributeError:
            no_error = QNetworkReply.NoError
            
        if reply.error() == no_error:
            img_data = reply.readAll()
            img = QImage.fromData(img_data)
            if not img.isNull():
                pix = QPixmap.fromImage(img)
                self.cache[url] = pix
                self.cache.move_to_end(url)
                if len(self.cache) > self.max_cache_size:
                    self.cache.popitem(last=False)
                self._safe_callback(callback, pix)
        
        reply.deleteLater()
        self._pump_queue()

    def _safe_callback(self, callback, pixmap):
        """Executes callback safely, catching C++ object deletion errors."""
        try:
            callback(pixmap)
        except RuntimeError:
            pass # The widget that requested this thumbnail no longer exists

    def cancel_stale_requests(self, active_urls):
        self.queue = [req for req in self.queue if req['url'] in active_urls]

    def clear_queue(self):
        """Aborts all active network requests and clears the pending queue."""
        self.queue.clear()
        for reply in list(self.active_replies.keys()):
            try:
                reply.abort()
            except RuntimeError:
                pass
        self.active_replies.clear()