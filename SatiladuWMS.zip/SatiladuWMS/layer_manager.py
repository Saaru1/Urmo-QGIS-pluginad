# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsLayerTreeLayer,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY
)

class LayerManager:
    def __init__(self, iface):
        self.iface = iface
        self.current_layer = None
        self.layer_left = None
        self.layer_right = None

    def get_canvas_bbox_latlon_str(self):
        try:
            canvas = self.iface.mapCanvas()
            ext = canvas.extent()
            tx = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(), QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
            ne = tx.transform(QgsPointXY(ext.xMaximum(), ext.yMaximum()))
            sw = tx.transform(QgsPointXY(ext.xMinimum(), ext.yMinimum()))
            return f"LatLng({ne.y():.6f},{ne.x():.6f})|LatLng({sw.y():.6f},{sw.x():.6f})"
        except Exception:
            return None

    def get_canvas_bbox_3301_str(self):
        canvas = self.iface.mapCanvas()
        ext = canvas.extent()
        src_crs = canvas.mapSettings().destinationCrs()
        dst_crs = QgsCoordinateReferenceSystem("EPSG:3301")
        tx = QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())
        ll = tx.transform(QgsPointXY(ext.xMinimum(), ext.yMinimum()))
        ur = tx.transform(QgsPointXY(ext.xMaximum(), ext.yMaximum()))
        return f"{min(ll.x(), ur.x())},{min(ll.y(), ur.y())},{max(ll.x(), ur.x())},{max(ll.y(), ur.y())}"

    def make_layer(self, date_str, base_url, sensor, filt):
        url_no_params = base_url.split('?')[0]
        layer_param = url_no_params.split('wms-')[-1].replace('-', '_')
        ds = f"crs=EPSG:3301&dpiMode=7&featureCount=10&format=image/jpeg&layers={layer_param}&styles=&tilePixelRatio=0&url={base_url}"
        
        layer_title = f"{sensor} {filt} {date_str}"
        lyr = QgsRasterLayer(ds, layer_title, "wms")
        return lyr if lyr.isValid() else None

    def add_layer_at_top(self, lyr: QgsRasterLayer):
        proj = QgsProject.instance()
        root = proj.layerTreeRoot()
        proj.addMapLayer(lyr, False)
        children = root.children()
        insert_idx = len(children)
        for idx, node in enumerate(children):
            if isinstance(node, QgsLayerTreeLayer) and node.layer() and node.layer().providerType().lower() == "wms":
                insert_idx = idx
                break
        root.insertLayer(insert_idx, lyr)

    def replace_layer(self, lyr: QgsRasterLayer):
        self.remove_layer()
        self.remove_compare_layers()
        self.add_layer_at_top(lyr)
        self.current_layer = lyr

    def setup_compare_layers(self, d_left, u_left, d_right, u_right, sensor, filt):
        self.remove_layer()
        self.remove_compare_layers()
        
        self.layer_left = self.make_layer(d_left, u_left, sensor, filt)
        self.layer_right = self.make_layer(d_right, u_right, sensor, filt) 
        
        if self.layer_left and self.layer_right:
            self.layer_left.setName(f"[Compare] {self.layer_left.name()}")
            self.add_layer_at_top(self.layer_left)

    def update_compare_left(self, d_left, u_left, sensor, filt):
        if self.layer_left:
            try:
                if QgsProject.instance().mapLayer(self.layer_left.id()):
                    QgsProject.instance().removeMapLayer(self.layer_left.id())
            except RuntimeError:
                pass
        self.layer_left = self.make_layer(d_left, u_left, sensor, filt)
        if self.layer_left:
            self.layer_left.setName(f"[Compare] {self.layer_left.name()}")
            self.add_layer_at_top(self.layer_left)
        return self.layer_left

    def update_compare_right(self, d_right, u_right, sensor, filt):
        if self.layer_right:
            try:
                self.layer_right.deleteLater()
            except RuntimeError:
                pass
        self.layer_right = self.make_layer(d_right, u_right, sensor, filt)
        return self.layer_right

    def remove_layer(self):
        if self.current_layer:
            try:
                if QgsProject.instance().mapLayer(self.current_layer.id()):
                    QgsProject.instance().removeMapLayer(self.current_layer.id())
            except RuntimeError:
                pass
        self.current_layer = None

    def remove_compare_layers(self):
        if self.layer_left:
            try:
                if QgsProject.instance().mapLayer(self.layer_left.id()):
                    QgsProject.instance().removeMapLayer(self.layer_left.id())
            except RuntimeError:
                pass
        self.layer_left = None
        self.layer_right = None