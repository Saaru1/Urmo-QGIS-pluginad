# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsLayerTreeLayer,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY
)

class LayerManager:
    def __init__(self, iface):
        self.iface = iface
        self.current_layer = None
        self.layer_left = None
        self.layer_right = None

    def get_canvas_bbox_latlon_str(self):
        try:
            canvas = self.iface.mapCanvas()
            ext = canvas.extent()
            tx = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(), QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
            ne = tx.transform(QgsPointXY(ext.xMaximum(), ext.yMaximum()))
            sw = tx.transform(QgsPointXY(ext.xMinimum(), ext.yMinimum()))
            return f"LatLng({ne.y():.6f},{ne.x():.6f})|LatLng({sw.y():.6f},{sw.x():.6f})"
        except Exception:
            return None

    def get_canvas_bbox_3301_str(self):
        canvas = self.iface.mapCanvas()
        ext = canvas.extent()
        src_crs = canvas.mapSettings().destinationCrs()
        dst_crs = QgsCoordinateReferenceSystem("EPSG:3301")
        tx = QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())
        ll = tx.transform(QgsPointXY(ext.xMinimum(), ext.yMinimum()))
        ur = tx.transform(QgsPointXY(ext.xMaximum(), ext.yMaximum()))
        return f"{min(ll.x(), ur.x())},{min(ll.y(), ur.y())},{max(ll.x(), ur.x())},{max(ll.y(), ur.y())}"

    def _build_datasource(self, base_url):
        url_no_params = base_url.split('?')[0]
        layer_param = url_no_params.split('wms-')[-1].replace('-', '_')
        return f"crs=EPSG:3301&dpiMode=7&featureCount=10&format=image/jpeg&layers={layer_param}&styles=&tilePixelRatio=0&url={base_url}"

    def make_layer(self, date_str, base_url, sensor, filt):
        ds = self._build_datasource(base_url)
        layer_title = f"{sensor} {filt} {date_str}"
        lyr = QgsRasterLayer(ds, layer_title, "wms")
        if lyr and lyr.isValid():
            self.set_temporal_properties(lyr, date_str)
            return lyr
        return None

    def set_temporal_properties(self, lyr, date_str, enabled=True):
        if not lyr or not lyr.isValid():
            return
        try:
            from qgis.core import QgsRasterLayerTemporalProperties, QgsDateTimeRange
            from qgis.PyQt.QtCore import QDateTime, QDate, QTime
            tprops = lyr.temporalProperties()
            if tprops:
                tprops.setIsActive(enabled)
                if enabled and date_str:
                    try:
                        mode = QgsRasterLayerTemporalProperties.Mode.ModeFixedTemporalRange
                    except AttributeError:
                        mode = QgsRasterLayerTemporalProperties.ModeFixedTemporalRange
                    tprops.setMode(mode)
                    d_parsed = QDate.fromString(date_str, "yyyy-MM-dd")
                    dt_start = QDateTime(d_parsed, QTime(0, 0, 0))
                    dt_end = QDateTime(d_parsed, QTime(23, 59, 59))
                    tprops.setFixedTemporalRange(QgsDateTimeRange(dt_start, dt_end))
        except Exception:
            pass

    def add_layer_at_top(self, lyr: QgsRasterLayer):
        proj = QgsProject.instance()
        root = proj.layerTreeRoot()
        proj.addMapLayer(lyr, False)
        children = root.children()
        # Default to index 0 (top of the layer tree) so the layer is always visible over basemaps
        insert_idx = 0
        for idx, node in enumerate(children):
            if isinstance(node, QgsLayerTreeLayer) and node.layer() and node.layer().providerType().lower() == "wms":
                insert_idx = idx
                break
        root.insertLayer(insert_idx, lyr)

    def remove_left_layer(self):
        if self.layer_left:
            try:
                if QgsProject.instance().mapLayer(self.layer_left.id()):
                    QgsProject.instance().removeMapLayer(self.layer_left.id())
            except RuntimeError:
                pass
            self.layer_left = None

    def remove_right_layer(self):
        if self.layer_right:
            try:
                if QgsProject.instance().mapLayer(self.layer_right.id()):
                    QgsProject.instance().removeMapLayer(self.layer_right.id())
            except RuntimeError:
                pass
            self.layer_right = None

    def set_main_layer(self, date_str, base_url, sensor, filt):
        """Updates the current layer in-place if possible, avoiding layer tree rebuilds."""
        ds = self._build_datasource(base_url)
        layer_title = f"{sensor} {filt} {date_str}"
        
        self.remove_compare_layers()
        
        if self.current_layer and self.current_layer.isValid():
            self.current_layer.setDataSource(ds, layer_title, "wms")
            self.set_temporal_properties(self.current_layer, date_str)
            self.current_layer.triggerRepaint()
        else:
            self.remove_layer()
            self.current_layer = QgsRasterLayer(ds, layer_title, "wms")
            if self.current_layer.isValid():
                self.set_temporal_properties(self.current_layer, date_str)
                self.add_layer_at_top(self.current_layer)
                
        return self.current_layer

    def setup_compare_layers(self, d_left, u_left, d_right, u_right, sensor, filt):
        self.remove_layer()
        self.remove_compare_layers()
        
        self.layer_left = self.make_layer(d_left, u_left, sensor, filt)
        self.layer_right = self.make_layer(d_right, u_right, sensor, filt)
        
        if self.layer_left and self.layer_right:
            self.add_layer_at_top(self.layer_left)
            QgsProject.instance().addMapLayer(self.layer_right, False)

    def update_compare_left(self, d_left, u_left, sensor, filt):
        if self.layer_left and self.layer_left.isValid():
            ds = self._build_datasource(u_left)
            layer_title = f"{sensor} {filt} {d_left}"
            self.layer_left.setDataSource(ds, layer_title, "wms")
            self.set_temporal_properties(self.layer_left, d_left)
            self.layer_left.triggerRepaint()
        else:
            self.remove_left_layer()
            self.layer_left = self.make_layer(d_left, u_left, sensor, filt)
            if self.layer_left:
                self.add_layer_at_top(self.layer_left)
        return self.layer_left

    def update_compare_right(self, d_right, u_right, sensor, filt):
        if self.layer_right and self.layer_right.isValid():
            ds = self._build_datasource(u_right)
            layer_title = f"{sensor} {filt} {d_right}"
            self.layer_right.setDataSource(ds, layer_title, "wms")
            self.set_temporal_properties(self.layer_right, d_right)
            self.layer_right.triggerRepaint()
        else:
            self.remove_right_layer()
            self.layer_right = self.make_layer(d_right, u_right, sensor, filt)
            if self.layer_right:
                QgsProject.instance().addMapLayer(self.layer_right, False)
        return self.layer_right

    def remove_layer(self):
        if self.current_layer:
            try:
                if QgsProject.instance().mapLayer(self.current_layer.id()):
                    QgsProject.instance().removeMapLayer(self.current_layer.id())
            except RuntimeError:
                pass
        self.current_layer = None

    def remove_compare_layers(self):
        self.remove_left_layer()
        self.remove_right_layer()
