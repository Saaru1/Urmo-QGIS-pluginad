# -*- coding: utf-8 -*-
"""
SentinelWMS – QGIS plugin main script
Modular Architecture with Async GIF Processing
"""
import os
import datetime
from qgis.core import Qgis, QgsMessageLog, QgsRasterLayer, QgsProject, QgsNetworkAccessManager
from qgis.PyQt.QtCore import Qt, QDate, QUrl, QSize, QTimer, QPoint
from qgis.PyQt.QtGui import QIcon, QTextCharFormat, QColor, QFont, QPixmap, QImage
from qgis.PyQt.QtWidgets import (
    QAction, QComboBox, QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
    QCalendarWidget, QListWidget, QListWidgetItem, QLabel, QWidget, QAbstractItemView
)
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply

from .satiladu_api import SatiladuAPI
from .layer_manager import LayerManager
from .gif_dialog import GifGeneratorDialog

class PreviewThumbnailWidget(QWidget):
    def __init__(self, dstr, url, bbox, parent=None):
        super().__init__(parent)
        self.dstr = dstr
        self.is_loaded = False
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(5, 5, 5, 5)
        self.layout.setSpacing(2)
        
        self.lbl_date = QLabel(datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y"))
        
        try:
            align_center = Qt.AlignmentFlag.AlignCenter
        except AttributeError:
            align_center = Qt.AlignCenter
            
        self.lbl_date.setAlignment(align_center)
        self.layout.addWidget(self.lbl_date)
        
        self.lbl_thumb = QLabel("Loading...")
        self.lbl_thumb.setFixedSize(130, 130)
        self.lbl_thumb.setAlignment(align_center)
        self.lbl_thumb.setStyleSheet("border: 1px solid #aaa; background-color: #eee;")
        self.layout.addWidget(self.lbl_thumb)

        layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
        self.thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                          f"&BBOX={bbox}&SRS=EPSG:3301&WIDTH=130&HEIGHT=130"
                          f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")

    def set_pixmap(self, pixmap):
        try:
            aspect = Qt.AspectRatioMode.KeepAspectRatio
        except AttributeError:
            aspect = Qt.KeepAspectRatio
        self.lbl_thumb.setPixmap(pixmap.scaled(130, 130, aspect))
        self.lbl_thumb.setStyleSheet("border: 1px solid #333;")
        self.is_loaded = True

class CalendarSelectDialog(QDialog):
    def __init__(self, parent_plugin):
        super().__init__(parent_plugin.iface.mainWindow())
        self.plugin = parent_plugin
        self.nam = QgsNetworkAccessManager()
        self.setWindowTitle("Select Date")
        self.resize(750, 480) 
        self._is_syncing = False
        
        try:
            self.user_role = Qt.ItemDataRole.UserRole 
        except AttributeError:
            self.user_role = Qt.UserRole

        main_layout = QHBoxLayout(self)
        left_layout = QVBoxLayout()
        self.calendar = QCalendarWidget()
        self.calendar.setMaximumDate(QDate.currentDate())
        self.calendar.setGridVisible(True)
        self.calendar.selectionChanged.connect(self._on_calendar_selection_changed)
        self.calendar.currentPageChanged.connect(self._on_month_changed)
        left_layout.addWidget(self.calendar)

        btn_layout = QHBoxLayout()
        self.btn_ok = QPushButton("Jump to Date")
        self.btn_cancel = QPushButton("Cancel")
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        left_layout.addLayout(btn_layout)

        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
        main_layout.addLayout(left_layout, 1)

        self.list_widget = QListWidget()
        self.list_widget.setFixedWidth(180)
        
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        
        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

        self.list_widget.currentItemChanged.connect(self._on_preview_changed)
        main_layout.addWidget(self.list_widget)
        
        self.preview_widgets = {}
        self.all_urls = []

        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._do_blink)
        self.blink_count = 0
        self.blink_date = None

        self._fetch_all_dates_and_populate()
        self._highlight_dates()

        if self.plugin.api.url_list and 0 <= self.plugin._list_pos < len(self.plugin.api.url_list):
            dt = datetime.date.fromisoformat(self.plugin.api.url_list[self.plugin._list_pos][0])
            self.calendar.setSelectedDate(QDate(dt.year, dt.month, dt.day))
            
        self._validate_selection() 
        self._on_month_changed(self.calendar.yearShown(), self.calendar.monthShown())

    def _fetch_all_dates_and_populate(self):
        tmp_api = SatiladuAPI()
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.plugin.combo_sensor.currentText()
        toode = self.plugin.combo_filter.currentData()
        
        tmp_api.refresh_urls_list(bbox_latlon, sensor, toode, False)
        self.all_urls = tmp_api.url_list
        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()

        for dstr, url in self.all_urls:
            item = QListWidgetItem(self.list_widget)
            item.setSizeHint(QSize(150, 160))
            item.setData(self.user_role, dstr)
            
            widget = PreviewThumbnailWidget(dstr, url, bbox_3301)
            self.list_widget.setItemWidget(item, widget)
            self.preview_widgets[dstr] = (item, widget)

    def _on_month_changed(self, year, month):
        first_item_of_month = None
        
        for dstr, (item, widget) in self.preview_widgets.items():
            dt = datetime.date.fromisoformat(dstr)
            if dt.year == year and dt.month == month:
                first_item_of_month = item
                break
                
        if first_item_of_month and not self._is_syncing:
            try:
                pos_top = QAbstractItemView.ScrollHint.PositionAtTop
            except AttributeError:
                pos_top = QAbstractItemView.PositionAtTop
            
            self.list_widget.scrollToItem(first_item_of_month, pos_top)
            
            self.list_widget.blockSignals(True)
            self.list_widget.setCurrentItem(first_item_of_month)
            self.list_widget.blockSignals(False)
            
        self._process_visible_thumbnails()

    def _process_visible_thumbnails(self):
        top_item = self.list_widget.itemAt(QPoint(10, 10))
        bottom_item = self.list_widget.itemAt(QPoint(10, self.list_widget.viewport().height() - 10))
        
        start_row = self.list_widget.row(top_item) if top_item else 0
        end_row = self.list_widget.row(bottom_item) if bottom_item else self.list_widget.count() - 1
        
        if start_row == -1: start_row = 0
        if end_row == -1: end_row = self.list_widget.count() - 1
        
        load_start = max(0, start_row - 1)
        load_end = min(self.list_widget.count(), end_row + 2)
        
        for i in range(load_start, load_end):
            item = self.list_widget.item(i)
            if item:
                dstr = item.data(self.user_role)
                widget = self.preview_widgets[dstr][1]
                if widget and not widget.is_loaded:
                    self._load_thumbnail(widget)

    def _load_thumbnail(self, widget):
        if widget.thumb_url in self.plugin.thumbnail_cache:
            widget.set_pixmap(self.plugin.thumbnail_cache[widget.thumb_url])
            return

        req = QNetworkRequest(QUrl(widget.thumb_url))
        reply = self.nam.get(req)
        reply.finished.connect(lambda r=reply, w=widget: self._on_thumbnail_loaded(r, w))

    def _on_thumbnail_loaded(self, reply, widget):
        try:
            no_error = QNetworkReply.NetworkError.NoError
        except AttributeError:
            no_error = QNetworkReply.NoError

        if reply.error() == no_error:
            img_data = reply.readAll()
            img = QImage.fromData(img_data)
            if not img.isNull():
                pix = QPixmap.fromImage(img)
                self.plugin.thumbnail_cache[widget.thumb_url] = pix
                widget.set_pixmap(pix)
            else:
                widget.lbl_thumb.setText("No Image")
        else:
            widget.lbl_thumb.setText("Error")
        reply.deleteLater()

    def _on_calendar_selection_changed(self):
        self._validate_selection()
        if self._is_syncing: return

        self._is_syncing = True
        selected_qdate = self.calendar.selectedDate()
        date_str = selected_qdate.toPyDate().isoformat()
        
        self.calendar.blockSignals(True)
        self.calendar.setCurrentPage(selected_qdate.year(), selected_qdate.month())
        self.calendar.blockSignals(False)

        if date_str in self.preview_widgets:
            item = self.preview_widgets[date_str][0]
            try:
                pos_center = QAbstractItemView.ScrollHint.PositionAtCenter
            except AttributeError:
                pos_center = QAbstractItemView.PositionAtCenter
            
            self.list_widget.scrollToItem(item, pos_center)
            self.list_widget.setCurrentItem(item)
            self._process_visible_thumbnails()
        self._is_syncing = False

    def _on_preview_changed(self, current, previous):
        if not current: return
        
        dstr = current.data(self.user_role)
        dt = datetime.date.fromisoformat(dstr)
        qdate = QDate(dt.year, dt.month, dt.day)
        
        if not self._is_syncing:
            self._is_syncing = True
            
            if self.blink_timer.isActive():
                self.blink_timer.stop()
                self._highlight_dates() 
                
            self.calendar.setSelectedDate(qdate) 
            
            self.blink_count = 0
            self.blink_date = qdate
            self.blink_timer.start(200)
            
            self._is_syncing = False

    def _do_blink(self):
        if self.blink_count >= 6: 
            self.blink_timer.stop()
            self._highlight_dates() 
            return
            
        fmt = QTextCharFormat()
        try:
            bold_weight = QFont.Weight.Bold 
        except AttributeError:
            bold_weight = QFont.Bold        
        fmt.setFontWeight(bold_weight)
        
        if self.blink_count % 2 == 0:
            fmt.setBackground(QColor("red")) 
            fmt.setForeground(QColor("white"))
        else:
            fmt.setBackground(QColor("yellow") if self.plugin.action_sun.isChecked() else QColor("#E0E0E0"))
            fmt.setForeground(QColor("black"))
            
        self.calendar.setDateTextFormat(self.blink_date, fmt)
        self.blink_count += 1

    def _highlight_dates(self):
        if not self.plugin.api.url_list: return
        fmt = QTextCharFormat()
        
        try:
            bold_weight = QFont.Weight.Bold 
        except AttributeError:
            bold_weight = QFont.Bold        

        if self.plugin.action_sun.isChecked():
            fmt.setBackground(QColor("yellow"))
            fmt.setFontWeight(bold_weight)
        else:
            fmt.setBackground(QColor("#E0E0E0")) 
            fmt.setFontWeight(bold_weight)

        self.calendar.setDateTextFormat(QDate(), QTextCharFormat())
        for dstr, _ in self.plugin.api.url_list:
            dt = datetime.date.fromisoformat(dstr)
            self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt)

    def _validate_selection(self):
        self.btn_ok.setEnabled(True)

    def get_selected_date(self):
        return self.calendar.selectedDate().toPyDate()

class Sentinel2Dates:
    def __init__(self, iface):
        self.iface = iface
        self.api = SatiladuAPI()
        self.layers = LayerManager(iface)
        self.thumbnail_cache = {}

        self.action_today = None
        self.action_sun = None
        self.action_calendar = None
        self.action_snapshot = None
        self.action_prev = None
        self.action_next = None
        self.action_prev_10 = None
        self.action_next_10 = None
        self.action_gif = None
        
        self.combo_sensor = None
        self.combo_filter = None
        self.toolbar = None
        self._list_pos = 0

        self._filter_data = [
            ("RGB", 1, "harilik värvifoto"),
            ("NRG", 3, "valevärvipilt \"Lähi-infrapuna Punane Roheline\""),
            ("NDVI", 5, "normaliseeritud taimkatte indeks (NDVI)"),
            ("NGR", 7, "valevärvipilt \"Lähi-infrapuna Roheline Punane\""),
            ("NDPI", 9, "normaliseeritud veekogude indeks (NDPI)"),
            ("PNB", 11, "valevärvipilt \"NDPI Lähi-infrapuna Sinine\""),
            ("NGP", 13, "valevärvipilt \"Lähi-infrapuna Roheline NDPI\""),
            ("NDR", 15, "valevärvipilt \"Lähi-infrapuna NDVI Punane\""),
            ("PDB", 17, "valevärvipilt \"NDPI NDVI Sinine\""),
            ("NDN", 19, "valevärvipilt \"Lähi-infrapuna NDVI Lähi-infrapuna\""),
            ("PDN", 21, "valevärvipilt \"NDPI NDVI Lähi-infrapuna\""),
            ("NNR", 23, "valevärvipilt \"Lähi-infrapuna Lähi-Infrapuna Punane\""),
            ("DNP", 25, "valevärvipilt \"NDVI Lähi-infrapuna NDPI\"")
        ]

    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        def get_icon(filename):
            return QIcon(os.path.join(plugin_dir, filename))

        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_sensor.currentIndexChanged.connect(self._on_settings_changed)

        try:
            tooltip_role = Qt.ItemDataRole.ToolTipRole
        except AttributeError:
            tooltip_role = Qt.ToolTipRole

        self.combo_filter = QComboBox()
        for idx, (code, toode_id, desc) in enumerate(self._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, tooltip_role)
        self.combo_filter.currentIndexChanged.connect(self._on_settings_changed)

        self.action_today = QAction(get_icon("icon.png"), "Toggle WMS Layer", self.iface.mainWindow())
        self.action_today.setCheckable(True)
        self.action_today.toggled.connect(self._on_main_toggled)

        self.action_sun = QAction(get_icon("icon_sun.png"), "Pilvitu (Cloudless) filter", self.iface.mainWindow())
        self.action_sun.setCheckable(True)
        self.action_sun.toggled.connect(self._on_sun_toggled)

        self.action_calendar = QAction(get_icon("calendar.png"), "Select Date from Calendar", self.iface.mainWindow())
        self.action_calendar.triggered.connect(self._open_calendar_dialog)

        self.action_snapshot = QAction(get_icon("icon_snapshot.png"), "Snapshot current layer", self.iface.mainWindow())
        self.action_snapshot.triggered.connect(self._take_snapshot)

        self.action_prev = QAction(get_icon("icon_left.png"), "Prev", self.iface.mainWindow())
        self.action_prev.triggered.connect(lambda: self._open_relative_exact(-1))
        self.action_next = QAction(get_icon("icon_right.png"), "Next", self.iface.mainWindow())
        self.action_next.triggered.connect(lambda: self._open_relative_exact(1))
        self.action_prev_10 = QAction(get_icon("icon_left_10.png"), "Prev 10", self.iface.mainWindow())
        self.action_prev_10.triggered.connect(lambda: self._open_relative_exact(-10))
        self.action_next_10 = QAction(get_icon("icon_right_10.png"), "Next 10", self.iface.mainWindow())
        self.action_next_10.triggered.connect(lambda: self._open_relative_exact(10))

        self.action_gif = QAction("GIF", self.iface.mainWindow())
        self.action_gif.triggered.connect(self._open_gif_dialog)

        self.toolbar = self.iface.addToolBar("Satiladu Navigation")
        self.toolbar.setObjectName("Sentinel2DatesToolbar")
        self.toolbar.addWidget(self.combo_sensor)
        self.toolbar.addWidget(self.combo_filter)
        
        ordered_actions = [
            self.action_prev_10, self.action_prev, self.action_sun, self.action_calendar,
            self.action_today, self.action_snapshot, self.action_next, self.action_next_10, self.action_gif
        ]

        for act in ordered_actions:
            self.toolbar.addAction(act)
            self.iface.addPluginToMenu("&Sentinel WMS", act)

        self._update_ui_state()

    def unload(self):
        self.layers.remove_layer()
        if self.toolbar: self.iface.mainWindow().removeToolBar(self.toolbar)

    def _sync_api_call(self):
        bbox = self.layers.get_canvas_bbox_latlon_str()
        sensor = self.combo_sensor.currentText()
        toode = self.combo_filter.currentData()
        pilvitu = self.action_sun.isChecked()
        return self.api.refresh_urls_list(bbox, sensor, toode, pilvitu)

    def _on_main_toggled(self, checked: bool):
        if checked:
            if not self.api.url_list: 
                self._sync_api_call()
            self._load_current_index()
        else:
            self.layers.remove_layer()
            
        self._update_ui_state()

    def _on_sun_toggled(self, checked: bool):
        target_date_str = None
        if self.api.url_list and 0 <= self._list_pos < len(self.api.url_list):
            target_date_str = self.api.url_list[self._list_pos][0]

        if checked and not self.action_today.isChecked():
            self.action_today.blockSignals(True)
            self.action_today.setChecked(True)
            self.action_today.blockSignals(False)

        if self._sync_api_call():
            if target_date_str:
                target_dt = datetime.date.fromisoformat(target_date_str)
                best_idx, min_diff = 0, float('inf')
                for idx, (d_str, _) in enumerate(self.api.url_list):
                    diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
                    if diff == 0: best_idx = idx; break 
                    if diff < min_diff: min_diff = diff; best_idx = idx
                self._list_pos = best_idx
            else:
                self._list_pos = 0 

            if self.action_today.isChecked():
                self._load_current_index()
                
        self._update_ui_state()

    def _on_settings_changed(self):
        if not self.action_today.isChecked(): return
        
        target_date_str = self.api.url_list[self._list_pos][0] if self.api.url_list and 0 <= self._list_pos < len(self.api.url_list) else None

        if self._sync_api_call():
            if target_date_str:
                target_dt = datetime.date.fromisoformat(target_date_str)
                best_idx, min_diff = 0, float('inf')
                for idx, (d_str, _) in enumerate(self.api.url_list):
                    diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
                    if diff == 0: best_idx = idx; break 
                    if diff < min_diff: min_diff = diff; best_idx = idx
                self._list_pos = best_idx
            self._load_current_index()
        self._update_ui_state()

    def _load_current_index(self):
        if not self.api.url_list:
            self.action_today.setChecked(False)
            return
            
        self._list_pos = max(0, min(self._list_pos, len(self.api.url_list) - 1))
        date_str, url = self.api.url_list[self._list_pos]
        
        lyr = self.layers.make_layer(date_str, url, self.combo_sensor.currentText(), self.combo_filter.currentText())
        if lyr:
            self.layers.replace_layer(lyr)
        else:
            self.action_today.setChecked(False)

    def _open_relative_exact(self, delta: int):
        if not self.action_today.isChecked() or not self.api.url_list: return
        new_pos = max(0, min(self._list_pos - delta, len(self.api.url_list) - 1))
        if new_pos != self._list_pos:
            self._list_pos = new_pos
            self._load_current_index()

    def _open_calendar_dialog(self):
        if not self.api.url_list and self.action_today.isChecked(): self._sync_api_call()
        dialog = CalendarSelectDialog(self)
        
        accepted = dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_()
        
        if accepted:
            target_pydate = dialog.get_selected_date()
            if not self.action_today.isChecked(): self.action_today.setChecked(True)
            if not self.api.url_list:
                if not self._sync_api_call(): return
                
            best_idx, min_diff = 0, float('inf')
            for idx, (d_str, _) in enumerate(self.api.url_list):
                diff = abs((datetime.date.fromisoformat(d_str) - target_pydate).days)
                if diff == 0: best_idx = idx; break
                if diff < min_diff: min_diff = diff; best_idx = idx
                    
            self._list_pos = best_idx
            self._load_current_index()

    def _open_gif_dialog(self):
        dialog = GifGeneratorDialog(self)
        if hasattr(dialog, 'exec'):
            dialog.exec()
        else:
            dialog.exec_()

    def _take_snapshot(self):
        if self.layers.current_layer and self.api.url_list:
            date_str = self.api.url_list[self._list_pos][0]
            snap = QgsRasterLayer(self.layers.current_layer.source(), f"Snap-Satiladu_{self.combo_sensor.currentText()}_{self.combo_filter.currentText()}_{date_str}", "wms")
            if snap.isValid(): self.layers.add_layer_at_top(snap)

    def _set_secondary_actions_enabled(self, enabled: bool):
        for a in (self.action_prev, self.action_next, self.action_prev_10, self.action_next_10):
            if a: a.setEnabled(enabled)

    def _update_ui_state(self):
        if self.action_calendar: self.action_calendar.setEnabled(True)

        is_active = bool(self.action_today.isChecked() and self.api.url_list)
        self._set_secondary_actions_enabled(is_active)
        
        try:
            layer_exists = bool(self.layers.current_layer and QgsProject.instance().mapLayer(self.layers.current_layer.id()))
        except RuntimeError:
            layer_exists = False

        can_snap = bool(layer_exists and self.action_today.isChecked())
        if self.action_snapshot: self.action_snapshot.setEnabled(can_snap)
            
        can_gif = bool(is_active and self.action_sun.isChecked())
        if self.action_gif: self.action_gif.setEnabled(can_gif)