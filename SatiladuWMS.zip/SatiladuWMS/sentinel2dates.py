# -*- coding: utf-8 -*-
"""
SentinelWMS – QGIS plugin main script
Immersive Workspace Overhaul (Phase 3: Async & Virtualized)
"""
import os
import datetime
from qgis.core import Qgis, QgsApplication, QgsMessageLog, QgsRasterLayer, QgsProject, QgsMapLayer, QgsCoordinateReferenceSystem
from qgis.gui import QgsMapCanvas
from qgis.PyQt.QtCore import Qt, QDate, QUrl, QSize, QTimer, QPoint, QRect, pyqtSignal, QObject, QEvent
from qgis.PyQt.QtGui import QIcon, QTextCharFormat, QColor, QFont, QPixmap, QImage, QRegion, QPainter, QPen
from qgis.PyQt.QtWidgets import (
    QAction, QComboBox, QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
    QCalendarWidget, QListWidget, QListWidgetItem, QLabel, QWidget, QAbstractItemView,
    QCheckBox, QLineEdit, QListView, QFileDialog, QStyledItemDelegate, QStyle, QMessageBox
)

from .satiladu_api import SatiladuAPI
from .layer_manager import LayerManager
from .gif_dialog import GifGeneratorDialog
from .thumbnail_worker import ThumbnailManager
from .onnx_manager import OnnxManager, get_available_models, get_model_info

try:
    TOOLTIP_ROLE = Qt.ItemDataRole.ToolTipRole
except AttributeError:
    TOOLTIP_ROLE = Qt.ToolTipRole

# --------------------------------------------------------
# 1. UI Components (Delegates, Calendar, Panels)
# --------------------------------------------------------

class ThumbnailDelegate(QStyledItemDelegate):
    def __init__(self, plugin, dark_mode=True, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.dark_mode = dark_mode
        
        try:
            self.state_selected = QStyle.StateFlag.State_Selected
            self.state_mouseover = QStyle.StateFlag.State_MouseOver
            self.user_role = Qt.ItemDataRole.UserRole
        except AttributeError:
            self.state_selected = QStyle.State_Selected
            self.state_mouseover = QStyle.State_MouseOver
            self.user_role = Qt.UserRole
        
    def paint(self, painter, option, index):
        painter.save()
        
        if option.state & self.state_selected:
            painter.fillRect(option.rect, QColor(0, 120, 215, 200))
        elif option.state & self.state_mouseover:
            painter.fillRect(option.rect, QColor(80, 80, 80, 200))
            
        data = index.data(self.user_role)
        if not data:
            painter.restore()
            return
            
        dstr, base_url, thumb_url = data
        dt_str = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
        
        painter.setPen(QColor("white") if self.dark_mode else QColor("black"))
        font = painter.font()
        try:
            font.setWeight(QFont.Weight.Bold)
        except AttributeError:
            font.setWeight(QFont.Bold)
        font.setPointSize(8)
        painter.setFont(font)
        
        text_rect = QRect(option.rect.x(), option.rect.y() + 5, option.rect.width(), 15)
        try:
            align = Qt.AlignmentFlag.AlignCenter
        except AttributeError:
            align = Qt.AlignCenter
        painter.drawText(text_rect, align, dt_str)
        
        thumb_rect = QRect(option.rect.x() + (option.rect.width() - 110) // 2, 
                           option.rect.y() + 25, 110, 110)
                           
        pixmap = self.plugin.thumbnail_manager.cache.get(thumb_url)
        if pixmap:
            painter.drawPixmap(thumb_rect, pixmap)
            painter.setPen(QPen(QColor("#555"), 1))
            painter.drawRect(thumb_rect)
        else:
            painter.fillRect(thumb_rect, QColor("#222") if self.dark_mode else QColor("#eee"))
            painter.setPen(QPen(QColor("#777") if self.dark_mode else QColor("#aaa"), 1))
            painter.drawRect(thumb_rect)
            painter.setPen(QColor("#aaa") if self.dark_mode else QColor("#555"))
            painter.drawText(thumb_rect, align, "Loading...")
            
        painter.restore()

    def sizeHint(self, option, index):
        return QSize(130, 145)

class DarkCalendarDialog(QDialog):
    def __init__(self, workspace):
        super().__init__(workspace.main_canvas)
        self.workspace = workspace
        self.setWindowTitle("Select Date")
        self.resize(450, 390)
        
        self.setStyleSheet("""
            QDialog { background-color: #2d2d30; color: white; }
            QLabel { color: white; }
            QPushButton { background-color: #0078d7; color: white; border-radius: 4px; padding: 6px 12px; font-weight: bold; }
            QPushButton:hover { background-color: #005a9e; }
            QCalendarWidget QWidget { alternate-background-color: #3e3e42; color: white; }
            QCalendarWidget QAbstractItemView:enabled { background-color: #2d2d30; color: white; selection-background-color: #0078d7; }
            QCalendarWidget QToolButton { color: white; icon-size: 24px; }
            QCalendarWidget QMenu { background-color: #2d2d30; color: white; }
            QCalendarWidget QSpinBox { background-color: #3e3e42; color: white; }
            QCheckBox { color: white; font-weight: bold; }
        """)

        layout = QVBoxLayout(self)
        
        self.chk_cloudless = QCheckBox("Cloudless only")
        self.chk_cloudless.setChecked(self.workspace.filmstrip.chk_cloudless.isChecked())
        self.chk_cloudless.toggled.connect(self._highlight_dates)
        layout.addWidget(self.chk_cloudless)
        
        self.calendar = QCalendarWidget()
        self.calendar.setMaximumDate(QDate.currentDate())
        self.calendar.setGridVisible(True)
        layout.addWidget(self.calendar)

        btn_layout = QHBoxLayout()
        self.btn_ok = QPushButton("Jump to Date")
        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

        self._highlight_dates()

    def _highlight_dates(self):
        bbox = self.workspace.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.workspace.combo_sensor.currentText()
        toode = self.workspace.combo_filter.currentData()
        
        api_all = SatiladuAPI()
        api_all.refresh_urls_list(bbox, sensor, toode, False)
        all_dates = list(api_all.url_list)
        
        clear_fmt = QTextCharFormat()
        for dstr, u in all_dates:
            dt = datetime.date.fromisoformat(dstr)
            self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), clear_fmt)

        if self.chk_cloudless.isChecked():
            fmt_cloud = QTextCharFormat()
            fmt_cloud.setBackground(QColor("yellow"))
            fmt_cloud.setForeground(QColor("black"))
            try:
                fmt_cloud.setFontWeight(QFont.Weight.Bold)
            except AttributeError:
                fmt_cloud.setFontWeight(QFont.Bold)
                
            api_cloud = SatiladuAPI()
            api_cloud.refresh_urls_list(bbox, sensor, toode, True)
            for dstr, u in api_cloud.url_list:
                dt = datetime.date.fromisoformat(dstr)
                self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt_cloud)
        else:
            fmt_all = QTextCharFormat()
            try:
                fmt_all.setUnderlineStyle(QTextCharFormat.UnderlineStyle.SingleUnderline)
            except AttributeError:
                fmt_all.setUnderlineStyle(QTextCharFormat.SingleUnderline)
            fmt_all.setUnderlineColor(QColor("#00ff00"))
            fmt_all.setForeground(QColor("white"))
            
            for dstr, u in all_dates:
                dt = datetime.date.fromisoformat(dstr)
                self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt_all)

    def get_selected_date(self):
        return self.calendar.selectedDate().toPyDate().isoformat()

class InlineThumbnailPanel(QWidget):
    dateSelected = pyqtSignal(str, str)

    def __init__(self, workspace, parent=None):
        super().__init__(parent)
        self.workspace = workspace
        self.plugin = workspace.plugin
        self.is_minimized = False
        self.url_list = []

        self.setStyleSheet("""
            QWidget { background-color: rgba(30, 30, 30, 240); border: 1px solid #444; border-radius: 4px; color: white; }
            QListWidget { background: transparent; border: none; outline: none; }
            QScrollBar:vertical { background: #222; width: 12px; }
            QScrollBar::handle:vertical { background: #666; border-radius: 6px; min-height: 20px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
            QCheckBox { color: white; font-weight: bold; font-size: 11px; }
            QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }
            QCheckBox::indicator:checked { background: #0078d7; border: 1px solid #0078d7; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
            ibeam_cursor = Qt.CursorShape.IBeamCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor
            ibeam_cursor = Qt.IBeamCursor

        top_layout = QVBoxLayout()
        top_layout.setSpacing(6)
        
        self.btn_minimize = QPushButton("▲")
        self.btn_minimize.setFixedSize(30, 24)
        self.btn_minimize.setStyleSheet("background-color: #555; color: white; border: none; border-radius: 3px; font-weight: bold; font-size: 12px;")
        self.btn_minimize.setCursor(arrow_cursor)
        self.btn_minimize.setToolTip("Minimize thumbnail panel")
        self.btn_minimize.clicked.connect(self.toggle_minimize)
        
        self.chk_cloudless = QCheckBox("Cloudless only")
        self.chk_cloudless.setToolTip("Toggle to filter thumbnail dates to cloudless skies only")
        self.chk_cloudless.setCursor(arrow_cursor)
        self.chk_cloudless.setChecked(True)
        self.chk_cloudless.toggled.connect(lambda: self.populate())
        
        header_layout = QHBoxLayout()
        header_layout.addWidget(self.btn_minimize)
        header_layout.addWidget(self.chk_cloudless)
        header_layout.addStretch()
        top_layout.addLayout(header_layout)
        
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search date (e.g. 10.)...")
        self.search_box.setStyleSheet("background-color: #222; color: white; border: 1px solid #555; padding: 6px; border-radius: 3px;")
        self.search_box.setCursor(ibeam_cursor)
        
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._apply_filter)
        self.search_box.textChanged.connect(lambda text: self.search_timer.start(400))
        
        top_layout.addWidget(self.search_box)
        layout.addLayout(top_layout)

        self.list_widget = QListWidget()
        self.list_widget.setCursor(arrow_cursor)
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        
        self.delegate = ThumbnailDelegate(self.plugin, dark_mode=True, parent=self.list_widget)
        self.list_widget.setItemDelegate(self.delegate)
        layout.addWidget(self.list_widget)

        self.tmp_api = SatiladuAPI()

        try:
            self.user_role = Qt.ItemDataRole.UserRole
            self.pos_center = QAbstractItemView.ScrollHint.PositionAtCenter
        except AttributeError:
            self.user_role = Qt.UserRole
            self.pos_center = QAbstractItemView.PositionAtCenter

        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

    def toggle_minimize(self):
        self.is_minimized = not self.is_minimized
        self.chk_cloudless.setVisible(not self.is_minimized)
        self.search_box.setVisible(not self.is_minimized)
        self.list_widget.setVisible(not self.is_minimized)
        
        if self.is_minimized:
            self.btn_minimize.setText("▼")
            self.btn_minimize.setToolTip("Maximize thumbnail panel")
        else:
            self.btn_minimize.setText("▲")
            self.btn_minimize.setToolTip("Minimize thumbnail panel")
            
        self.workspace._resize_items()

    def hideEvent(self, event):
        super().hideEvent(event)

    def populate(self, callback=None):
        self.list_widget.setEnabled(False)
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.workspace.combo_sensor.currentText()
        toode = self.workspace.combo_filter.currentData()
        
        def _on_fetch_done(success, url_list, err):
            self.url_list = url_list
            self.list_widget.setEnabled(True)
            self.list_widget.clear()
            
            bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
            for dstr, url in self.url_list:
                item = QListWidgetItem(self.list_widget)
                layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
                thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                             f"&BBOX={bbox_3301}&SRS=EPSG:3301&WIDTH=110&HEIGHT=110"
                             f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")
                item.setData(self.user_role, (dstr, url, thumb_url))
                
            if self.search_box.text():
                self._apply_filter()
            else:
                QTimer.singleShot(50, self._process_visible_thumbnails)
                
            if callback: callback()
                
        self.tmp_api.refresh_urls_async(bbox_latlon, sensor, toode, self.chk_cloudless.isChecked(), _on_fetch_done)

    def _apply_filter(self):
        search_term = self.search_box.text().lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            dstr = item.data(self.user_role)[0]
            dt_formatted = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
            item.setHidden(search_term not in dt_formatted)
        self._process_visible_thumbnails()

    def _process_visible_thumbnails(self):
        viewport_rect = self.list_widget.viewport().rect()
        
        first_idx = -1
        last_idx = -1
        
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                rect = self.list_widget.visualItemRect(item)
                if rect.isValid() and viewport_rect.intersects(rect):
                    if first_idx == -1: first_idx = i
                    last_idx = i
                    
        if first_idx == -1: return
            
        active_urls = set()
        
        for i in range(first_idx, last_idx + 1):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data: continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=10)
                    
        load_start = max(0, first_idx - 5)
        load_end = min(self.list_widget.count(), last_idx + 6)
        
        for i in range(load_start, load_end):
            if i >= first_idx and i <= last_idx: continue 
                
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data: continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=1)
                    
        self.plugin.thumbnail_manager.cancel_stale_requests(active_urls)

    def _on_item_clicked(self, item):
        self.list_widget.scrollToItem(item, self.pos_center)
        dstr, url, thumb_url = item.data(self.user_role)
        self.dateSelected.emit(dstr, url)

# --------------------------------------------------------
# 2. Horizontal Bottom Filmstrip
# --------------------------------------------------------

class HorizontalFilmstrip(QWidget):
    dateSelected = pyqtSignal(str, str)

    def __init__(self, workspace, parent=None):
        super().__init__(parent)
        self.workspace = workspace
        self.plugin = workspace.plugin
        self.url_list = []
        self.is_minimized = False

        self.setStyleSheet("""
            QWidget { background-color: rgba(30, 30, 30, 240); border-radius: 8px; color: white; }
            QListWidget { background: transparent; border: none; outline: none; }
            QScrollBar:horizontal { background: #222; height: 10px; }
            QScrollBar::handle:horizontal { background: #666; border-radius: 5px; min-width: 20px; }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
            QPushButton { background-color: #444; color: white; border: 1px solid #555; border-radius: 4px; font-weight: bold; font-size: 18px; }
            QPushButton:hover { background-color: #0078d7; }
            QCheckBox { color: white; font-weight: bold; font-size: 11px; }
            QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #888; border-radius: 2px; background: rgba(0,0,0,100); }
            QCheckBox::indicator:checked { background: #0078d7; border: 1px solid #0078d7; }
        """)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 8, 10, 8)
        main_layout.setSpacing(8)

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
            ibeam_cursor = Qt.CursorShape.IBeamCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor
            ibeam_cursor = Qt.IBeamCursor

        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(5, 0, 5, 0)
        
        self.btn_minimize = QPushButton("▼")
        self.btn_minimize.setFixedSize(30, 24)
        self.btn_minimize.setStyleSheet("background-color: #555; color: white; border: none; border-radius: 3px; font-weight: bold; font-size: 12px;")
        self.btn_minimize.setCursor(arrow_cursor)
        self.btn_minimize.setToolTip("Minimize thumbnail panel")
        self.btn_minimize.clicked.connect(self.toggle_minimize)
        
        self.chk_cloudless = QCheckBox("Cloudless only")
        self.chk_cloudless.setCursor(arrow_cursor)
        self.chk_cloudless.setToolTip("Toggle to filter thumbnail dates to cloudless skies only")
        self.chk_cloudless.setChecked(True)
        self.chk_cloudless.toggled.connect(lambda: self.populate())
        
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search date (e.g. 10.)...")
        self.search_box.setStyleSheet("background-color: #222; color: white; border: 1px solid #555; padding: 4px 8px; border-radius: 3px; font-size: 12px;")
        self.search_box.setFixedWidth(200)
        self.search_box.setCursor(ibeam_cursor)
        
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._apply_filter)
        self.search_box.textChanged.connect(lambda text: self.search_timer.start(400))
        
        top_bar.addWidget(self.btn_minimize)
        top_bar.addWidget(self.chk_cloudless)
        top_bar.addWidget(self.search_box)
        top_bar.addStretch()

        self.bottom_container = QWidget()
        bottom_layout = QHBoxLayout(self.bottom_container)
        bottom_layout.setContentsMargins(0, 0, 0, 0)
        bottom_layout.setSpacing(10)

        self.btn_prev = QPushButton("<")
        self.btn_prev.setFixedSize(40, 100)
        self.btn_prev.setCursor(arrow_cursor)
        self.btn_prev.clicked.connect(self._go_prev)
        
        self.list_widget = QListWidget()
        try:
            flow_l2r = QListView.Flow.LeftToRight
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
            scrollbar_off = Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        except AttributeError:
            flow_l2r = QListView.LeftToRight
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
            scrollbar_off = Qt.ScrollBarAlwaysOff
            
        self.list_widget.setFlow(flow_l2r)
        self.list_widget.setVerticalScrollBarPolicy(scrollbar_off)
        self.list_widget.setHorizontalScrollMode(scroll_per_pixel)
        self.list_widget.setFixedHeight(170)
        self.list_widget.setCursor(arrow_cursor)
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        
        self.delegate = ThumbnailDelegate(self.plugin, dark_mode=True, parent=self.list_widget)
        self.list_widget.setItemDelegate(self.delegate)

        self.btn_next = QPushButton(">")
        self.btn_next.setFixedSize(40, 100)
        self.btn_next.setCursor(arrow_cursor)
        self.btn_next.clicked.connect(self._go_next)

        bottom_layout.addWidget(self.btn_prev)
        bottom_layout.addWidget(self.list_widget, 1)
        bottom_layout.addWidget(self.btn_next)

        main_layout.addLayout(top_bar)
        main_layout.addWidget(self.bottom_container)

        self.tmp_api = SatiladuAPI()

        try:
            self.user_role = Qt.ItemDataRole.UserRole
            self.pos_center = QAbstractItemView.ScrollHint.PositionAtCenter
        except AttributeError:
            self.user_role = Qt.UserRole
            self.pos_center = QAbstractItemView.PositionAtCenter

        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.horizontalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

    def toggle_minimize(self):
        self.is_minimized = not self.is_minimized
        self.bottom_container.setVisible(not self.is_minimized)
        self.chk_cloudless.setVisible(not self.is_minimized)
        self.search_box.setVisible(not self.is_minimized)
        
        if self.is_minimized:
            self.btn_minimize.setText("▲")
            self.btn_minimize.setToolTip("Maximize thumbnail panel")
        else:
            self.btn_minimize.setText("▼")
            self.btn_minimize.setToolTip("Minimize thumbnail panel")
            
        self.workspace._resize_items()

    def populate(self, callback=None):
        self.list_widget.setEnabled(False)
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.workspace.combo_sensor.currentText()
        toode = self.workspace.combo_filter.currentData()
        
        def _on_fetch_done(success, url_list, err):
            self.url_list = url_list
            self.list_widget.setEnabled(True)
            self.list_widget.clear()
            
            bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()
            for dstr, url in self.url_list:
                item = QListWidgetItem(self.list_widget)
                layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
                thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                             f"&BBOX={bbox_3301}&SRS=EPSG:3301&WIDTH=110&HEIGHT=110"
                             f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")
                item.setData(self.user_role, (dstr, url, thumb_url)) 
                
            if self.search_box.text():
                self._apply_filter()
            else:
                self.sync_active_date(self.workspace.current_left_date)
                QTimer.singleShot(50, self._process_visible_thumbnails)
                
            if callback: callback()
                
        self.tmp_api.refresh_urls_async(bbox_latlon, sensor, toode, self.chk_cloudless.isChecked(), _on_fetch_done)

    def _apply_filter(self):
        search_term = self.search_box.text().lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            dstr = item.data(self.user_role)[0]
            dt_formatted = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
            item.setHidden(search_term not in dt_formatted)
        self._process_visible_thumbnails()

    def sync_active_date(self, dstr):
        if not dstr: return
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.isHidden(): continue
            item_dstr = item.data(self.user_role)[0]
            if item_dstr == dstr:
                self.list_widget.blockSignals(True)
                self.list_widget.setCurrentItem(item)
                self.list_widget.scrollToItem(item, self.pos_center)
                self.list_widget.blockSignals(False)
                break
        self._process_visible_thumbnails()

    def _go_prev(self):
        row = self.list_widget.currentRow()
        if row > 0:
            self.list_widget.setCurrentRow(row - 1)
            self._on_item_clicked(self.list_widget.currentItem())

    def _go_next(self):
        row = self.list_widget.currentRow()
        if row < self.list_widget.count() - 1:
            self.list_widget.setCurrentRow(row + 1)
            self._on_item_clicked(self.list_widget.currentItem())

    def _process_visible_thumbnails(self):
        viewport_rect = self.list_widget.viewport().rect()
        
        first_idx = -1
        last_idx = -1
        
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                rect = self.list_widget.visualItemRect(item)
                if rect.isValid() and viewport_rect.intersects(rect):
                    if first_idx == -1: first_idx = i
                    last_idx = i
                    
        if first_idx == -1: return
            
        active_urls = set()
        
        for i in range(first_idx, last_idx + 1):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data: continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=10)
                    
        load_start = max(0, first_idx - 5)
        load_end = min(self.list_widget.count(), last_idx + 6)
        
        for i in range(load_start, load_end):
            if i >= first_idx and i <= last_idx: continue 
                
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                data = item.data(self.user_role)
                if not data: continue
                dstr, url, thumb_url = data
                if thumb_url not in self.plugin.thumbnail_manager.cache:
                    active_urls.add(thumb_url)
                    self.plugin.thumbnail_manager.request_thumbnail(thumb_url, lambda p: self.list_widget.viewport().update(), priority=1)
                    
        self.plugin.thumbnail_manager.cancel_stale_requests(active_urls)

    def _on_item_clicked(self, item):
        self.list_widget.scrollToItem(item, self.pos_center)
        dstr, url, thumb_url = item.data(self.user_role)
        self.dateSelected.emit(dstr, url)

# --------------------------------------------------------
# 3. Canvas Handle & Workspace Manager
# --------------------------------------------------------

class SwipeHandle(QWidget):
    positionChanged = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.SplitHCursor if not hasattr(Qt.CursorShape, 'SplitHCursor') else Qt.CursorShape.SplitHCursor)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        except AttributeError:
            self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(40) 
        self.setMouseTracking(True)
        self._dragging = False
        self._is_hovering = False
        self._hover_y = 0

    def enterEvent(self, event):
        self._is_hovering = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._is_hovering = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        try:
            left_btn = Qt.MouseButton.LeftButton
        except AttributeError:
            left_btn = Qt.LeftButton
        if event.button() == left_btn:
            self._dragging = True
            self.update()

    def mouseMoveEvent(self, event):
        try:
            pos_y = event.position().y()
        except AttributeError:
            pos_y = event.pos().y()
        self._hover_y = pos_y
        self.update()
        if self._dragging:
            try:
                gpos = event.globalPosition().toPoint()
            except AttributeError:
                gpos = event.globalPos()
            parent_pos = self.parent().mapFromGlobal(gpos)
            new_x = max(0, min(parent_pos.x(), self.parent().width()))
            self.positionChanged.emit(new_x)

    def mouseReleaseEvent(self, event):
        try:
            left_btn = Qt.MouseButton.LeftButton
        except AttributeError:
            left_btn = Qt.LeftButton
        if event.button() == left_btn:
            self._dragging = False
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            aa = QPainter.RenderHint.Antialiasing
            no_pen = Qt.PenStyle.NoPen
        except AttributeError:
            aa = QPainter.Antialiasing
            no_pen = Qt.NoPen
        painter.setRenderHint(aa)
        
        w, h = self.width(), self.height()
        center_x = w // 2
        
        painter.setPen(no_pen)
        painter.setBrush(QColor(0, 0, 0, 1))
        painter.drawRect(0, 0, w, h)
        
        pen_shadow = QPen(QColor(0, 0, 0, 150))
        pen_shadow.setWidth(2)
        painter.setPen(pen_shadow)
        painter.drawLine(center_x, 0, center_x, h)
        
        pen_white = QPen(QColor(255, 255, 255, 230))
        pen_white.setWidth(1)
        painter.setPen(pen_white)
        painter.drawLine(center_x, 0, center_x, h)
        
        painter.setPen(no_pen)
        if self._is_hovering or self._dragging:
            dot_y = max(20, min(self._hover_y, h - 20))
            painter.setBrush(QColor(0, 0, 0, 100))
            painter.drawEllipse(center_x - 11, int(dot_y) - 11, 22, 22)
            painter.setBrush(QColor(255, 255, 255, 255))
            painter.drawEllipse(center_x - 9, int(dot_y) - 9, 18, 18)
            painter.setBrush(QColor(0, 120, 215, 255))
            painter.drawEllipse(center_x - 5, int(dot_y) - 5, 10, 10)
        painter.end()


class SatiladuWorkspace(QObject):
    def __init__(self, plugin, initial_date, initial_url):
        super().__init__(plugin.iface.mapCanvas())
        self.plugin = plugin
        self.main_canvas = plugin.iface.mapCanvas()
        
        self.is_compare_mode = False
        self._is_updating = False
        self.current_left_date = initial_date
        self.current_right_date = None
        
        # Super-resolution active state trackers
        self.upscale_scales = {"left": 2, "right": 2}
        self.upscale_models = {"left": None, "right": None}

        try:
            self.arrow_cursor = Qt.CursorShape.ArrowCursor
        except AttributeError:
            self.arrow_cursor = Qt.ArrowCursor

        self.btn_style = "QPushButton { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 5px 12px; font-weight: bold; } QPushButton:hover { background-color: #555; }"
        self.btn_disabled_style = "QPushButton { background-color: #333; color: #777; border: 1px solid #444; border-radius: 3px; padding: 5px 12px; font-weight: bold; }"
        self.btn_date_active_style = "QPushButton { background: rgba(30,30,30,220); color: white; border-radius: 4px; padding: 8px 15px; font-size: 15px; font-weight: bold; border: 2px solid #0078d7; } QPushButton:hover { background: rgba(50,50,50,240); border: 2px solid #5cb85c; }"
        self.btn_date_inactive_style = "QPushButton { background: rgba(30,30,30,220); color: white; border-radius: 4px; padding: 8px 15px; font-size: 15px; font-weight: bold; border: 1px solid #666; }"
        self.btn_date_enhanced_style = "QPushButton { background: rgba(20,30,40,230); color: #00d4ff; border-radius: 4px; padding: 8px 15px; font-size: 15px; font-weight: bold; border: 2px solid #00d4ff; } QPushButton:hover { background: rgba(30,45,60,240); border: 2px solid #5ce1e6; }"

        sensor = self.plugin.combo_sensor.currentText()
        filt = self.plugin.combo_filter.currentText()
        self.layer_left = self.plugin.layers.set_main_layer(initial_date, initial_url, sensor, filt)
        self.layer_right = None

        self.control_container = QWidget(self.main_canvas)
        self.control_container.setStyleSheet("""
            QWidget { background: rgba(30,30,30,230); border-radius: 6px; }
            QToolTip { background-color: #1e1e1e; color: #ffffff; border: 1px solid #666; font-size: 12px; font-weight: bold; padding: 5px 8px; border-radius: 3px; }
        """)
        self.h_layout = QHBoxLayout(self.control_container)
        self.h_layout.setContentsMargins(10, 8, 10, 8)
        self.h_layout.setSpacing(10)
        
        combo_style = "QComboBox { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 4px 10px; } QComboBox::drop-down { border: none; } QComboBox QAbstractItemView { background: #333; color: white; selection-background-color: #0078d7; border: 1px solid #222; outline: none; margin: 0px; padding: 0px; } QComboBox QListView { border: none; }"
        
        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_sensor.setCurrentIndex(self.plugin.combo_sensor.currentIndex())
        self.combo_sensor.setStyleSheet(combo_style)
        self.combo_sensor.setCursor(self.arrow_cursor)
        
        self.combo_filter = QComboBox()
        for idx, (code, toode_id, desc) in enumerate(self.plugin._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, TOOLTIP_ROLE)
        self.combo_filter.setCurrentIndex(self.plugin.combo_filter.currentIndex())
        self.combo_filter.setStyleSheet(combo_style)
        self.combo_filter.setCursor(self.arrow_cursor)
        self._update_filter_tooltip(self.combo_filter.currentIndex())
        self.combo_filter.currentIndexChanged.connect(self._update_filter_tooltip)
        
        self.btn_refresh = QPushButton("🔄 Refresh")
        self.btn_refresh.setStyleSheet(self.btn_style)
        self.btn_refresh.setCursor(self.arrow_cursor)
        self.btn_refresh.setToolTip("Reload dates and thumbnails for current map area")
        self.btn_refresh.clicked.connect(self._on_settings_changed)

        self.btn_cal = QPushButton("📅 Calendar")
        self.btn_cal.setStyleSheet(self.btn_style)
        self.btn_cal.setCursor(self.arrow_cursor)
        self.btn_cal.clicked.connect(self._open_calendar)

        self.btn_snap = QPushButton("📷 Snapshot")
        self.btn_snap.setStyleSheet(self.btn_style)
        self.btn_snap.setCursor(self.arrow_cursor)
        self.btn_snap.clicked.connect(self._take_snapshot)

        self.btn_gif = QPushButton("🎞️ GIF")
        self.btn_gif.setStyleSheet(self.btn_style)
        self.btn_gif.setCursor(self.arrow_cursor)
        self.btn_gif.clicked.connect(self._open_gif)
        
        self.btn_upscale = QPushButton("✨ Upscale")
        self.btn_upscale.setStyleSheet(self.btn_style)
        self.btn_upscale.setCursor(self.arrow_cursor)
        self.btn_upscale.setToolTip("Enhance active view using neural super-resolution (ONNX DirectML)")

        self.combo_model = QComboBox()
        self.combo_model.setStyleSheet(combo_style)
        self.combo_model.setCursor(self.arrow_cursor)
        self.combo_model.setToolTip("Select ONNX model for super-resolution upscaling")
        for m in get_available_models():
            self.combo_model.addItem(m)
        for i in range(self.combo_model.count()):
            if "2x" in self.combo_model.itemText(i).lower():
                self.combo_model.setCurrentIndex(i)
                break

        self.gif_blink_timer = QTimer(self)
        self.gif_blink_timer.timeout.connect(self._toggle_gif_button_blink)
        self.gif_blink_state = False

        self.btn_compare = QPushButton("Compare")
        self.btn_compare.setFixedWidth(130)
        self.btn_compare.setStyleSheet("QPushButton { background-color: #0078d7; color: white; border-radius: 3px; padding: 5px 15px; font-weight: bold; } QPushButton:hover { background-color: #005a9e; }")
        self.btn_compare.setCursor(self.arrow_cursor)
        self.btn_compare.clicked.connect(self._toggle_compare_mode)
        
        self.h_layout.addWidget(self.combo_sensor)
        self.h_layout.addWidget(self.combo_filter)
        self.h_layout.addWidget(self.btn_refresh)
        self.h_layout.addWidget(QLabel("<span style='color:#666;'>|</span>"))
        self.h_layout.addWidget(self.btn_cal)
        self.h_layout.addWidget(self.btn_snap)
        self.h_layout.addWidget(self.btn_gif)
        self.h_layout.addWidget(self.btn_upscale)
        self.h_layout.addWidget(self.combo_model)
        self.h_layout.addWidget(QLabel("<span style='color:#666;'>|</span>"))
        self.h_layout.addWidget(self.btn_compare)
        
        self.control_container.adjustSize()
        self.control_container.show()
        
        self.onnx_manager = OnnxManager(self)
        
        # Intercept trigger_upscale to track active model scale per task
        orig_trigger = self.onnx_manager.trigger_upscale
        def _wrapped_trigger(task_id="left"):
            model_name = self.combo_model.currentText()
            info = get_model_info(model_name)
            target_scale = info.get("target_scale", info.get("scale", 2))
            self.upscale_scales[task_id] = target_scale
            self.upscale_models[task_id] = model_name
            return orig_trigger(task_id)
        self.onnx_manager.trigger_upscale = _wrapped_trigger

        self.btn_upscale.clicked.connect(lambda: self.onnx_manager.trigger_upscale("left"))

        # Dedicated compare upscale buttons placed directly beside date indicators on canvas
        self.btn_upscale_left = QPushButton("✨ Upscale", self.main_canvas)
        self.btn_upscale_left.setStyleSheet(self.btn_style)
        self.btn_upscale_left.setCursor(self.arrow_cursor)
        self.btn_upscale_left.clicked.connect(lambda: self.onnx_manager.trigger_upscale("left"))
        self.btn_upscale_left.hide()

        self.btn_upscale_right = QPushButton("✨ Upscale", self.main_canvas)
        self.btn_upscale_right.setStyleSheet(self.btn_style)
        self.btn_upscale_right.setCursor(self.arrow_cursor)
        self.btn_upscale_right.clicked.connect(lambda: self.onnx_manager.trigger_upscale("right"))
        self.btn_upscale_right.hide()
        
        self.combo_sensor.currentIndexChanged.connect(self._on_settings_changed)
        self.combo_filter.currentIndexChanged.connect(self._on_settings_changed)

        self.panel_left = InlineThumbnailPanel(self, self.main_canvas)
        self.panel_left.hide()
        self.panel_left.dateSelected.connect(self._do_change_left_date)

        self.panel_right = InlineThumbnailPanel(self, self.main_canvas)
        self.panel_right.hide()
        self.panel_right.dateSelected.connect(self._do_change_right_date)
        
        self.btn_left_date = QPushButton(self.current_left_date, self.main_canvas)
        self.btn_left_date.setStyleSheet(self.btn_date_inactive_style)
        self.btn_left_date.setCursor(self.arrow_cursor)
        self.btn_left_date.clicked.connect(self._toggle_left_panel)
        self.btn_left_date.adjustSize()
        self.btn_left_date.show()
        
        self.btn_right_date = QPushButton("", self.main_canvas)
        self.btn_right_date.setStyleSheet(self.btn_date_inactive_style)
        self.btn_right_date.setCursor(self.arrow_cursor)
        self.btn_right_date.clicked.connect(self._toggle_right_panel)
        self.btn_right_date.hide()

        self.filmstrip = HorizontalFilmstrip(self, self.main_canvas)
        self.filmstrip.dateSelected.connect(self._do_change_left_date)
        
        QTimer.singleShot(50, lambda: self.filmstrip.populate())
        self.filmstrip.show()

        self.top_canvas = QgsMapCanvas(self.main_canvas)
        self.top_canvas.setCanvasColor(QColor(0,0,0,0))
        self.top_canvas.setStyleSheet("background: transparent;")
        self.top_canvas.setProject(QgsProject.instance())
        self.top_canvas.setAttribute(Qt.WA_TransparentForMouseEvents if not hasattr(Qt.WidgetAttribute, 'WA_TransparentForMouseEvents') else Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.top_canvas.hide()
        
        self.handle = SwipeHandle(self.main_canvas)
        self.handle.positionChanged.connect(self._on_handle_moved)
        self.handle.hide()
        
        self.split_x = self.main_canvas.width() // 2
        
        self.main_canvas.extentsChanged.connect(self._sync_extents)
        self.main_canvas.extentsChanged.connect(self._on_extents_settled)
        self.main_canvas.layersChanged.connect(self._sync_layers)
        self.main_canvas.installEventFilter(self)
        
        self._update_layer_names()
        self.update_date_button_labels()
        QTimer.singleShot(100, self._resize_items)

    def _update_filter_tooltip(self, index):
        desc = self.combo_filter.itemData(index, TOOLTIP_ROLE)
        self.combo_filter.setToolTip(desc if desc else "")

    def _update_layer_names(self):
        if not self.layer_left: return
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        if self.is_compare_mode:
            self.layer_left.setName(f"Compare: {sensor} {filt} {self.current_left_date} vs {self.current_right_date}")
        else:
            self.layer_left.setName(f"{sensor} {filt} {self.current_left_date}")

    def update_date_button_labels(self):
        up_left = self.onnx_manager.upscale_layers.get("left") if hasattr(self, 'onnx_manager') else None
        up_right = self.onnx_manager.upscale_layers.get("right") if hasattr(self, 'onnx_manager') else None
        
        left_enhanced = (up_left is not None and up_left.isValid())
        right_enhanced = (up_right is not None and up_right.isValid())
        
        left_scale = self.upscale_scales.get("left", 2)
        right_scale = self.upscale_scales.get("right", 2)
        
        if not self.is_compare_mode:
            if left_enhanced:
                self.btn_left_date.setText(f"✨ {left_scale}x Enhanced | {self.current_left_date}")
                self.btn_left_date.setStyleSheet(self.btn_date_enhanced_style)
            else:
                self.btn_left_date.setText(self.current_left_date)
                self.btn_left_date.setStyleSheet(self.btn_date_inactive_style)
            self.btn_left_date.adjustSize()
        else:
            if left_enhanced:
                self.btn_left_date.setText(f"LEFT: {self.current_left_date} (✨ {left_scale}x Enhanced)")
                self.btn_left_date.setStyleSheet(self.btn_date_enhanced_style)
            else:
                self.btn_left_date.setText(f"LEFT: {self.current_left_date}")
                self.btn_left_date.setStyleSheet(self.btn_date_active_style)
            self.btn_left_date.adjustSize()
            
            if self.current_right_date:
                if right_enhanced:
                    self.btn_right_date.setText(f"RIGHT: {self.current_right_date} (✨ {right_scale}x Enhanced)")
                    self.btn_right_date.setStyleSheet(self.btn_date_enhanced_style)
                else:
                    self.btn_right_date.setText(f"RIGHT: {self.current_right_date}")
                    self.btn_right_date.setStyleSheet(self.btn_date_active_style)
                self.btn_right_date.adjustSize()
                
        self._resize_items()

    def _get_closest_valid_date(self, target_date):
        url_list = self.filmstrip.url_list if self.filmstrip.url_list else self.plugin.api.url_list
        if not url_list: return None, None
        
        best_dstr, best_url = url_list[0]
        min_diff = float('inf')
        for dstr, url in url_list:
            diff = abs((datetime.date.fromisoformat(dstr) - target_date).days)
            if diff == 0: return dstr, url
            if diff < min_diff:
                min_diff = diff
                best_dstr = dstr
                best_url = url
        return best_dstr, best_url

    def _on_settings_changed(self):
        self.btn_refresh.setText("⏳")
        self.btn_refresh.setEnabled(False)
        
        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

        self.plugin.combo_sensor.blockSignals(True)
        self.plugin.combo_sensor.setCurrentIndex(self.combo_sensor.currentIndex())
        self.plugin.combo_sensor.blockSignals(False)
        self.plugin.combo_filter.blockSignals(True)
        self.plugin.combo_filter.setCurrentIndex(self.combo_filter.currentIndex())
        self.plugin.combo_filter.blockSignals(False)
        
        sensor = self.combo_sensor.currentText()
        bbox = self.plugin.layers.get_canvas_bbox_latlon_str()
        toode = self.combo_filter.currentData()
        
        def _main_api_done(success, url_list, err):
            if success:
                self.plugin.api.url_list = url_list
            self.filmstrip.populate(self._on_settings_async_done)

        self.plugin.api.refresh_urls_async(bbox, sensor, toode, self.filmstrip.chk_cloudless.isChecked(), _main_api_done)
        
    def _on_settings_async_done(self):
        self.btn_refresh.setText("🔄 Refresh")
        self.btn_refresh.setEnabled(True)
        
        left_dt = datetime.date.fromisoformat(self.current_left_date)
        new_left_date, left_url = self._get_closest_valid_date(left_dt)
        if new_left_date:
            self._do_change_left_date(new_left_date, left_url)

        if self.is_compare_mode and self.current_right_date:
            right_dt = datetime.date.fromisoformat(self.current_right_date)
            new_right_date, right_url = self._get_closest_valid_date(right_dt)
            if new_right_date:
                self._do_change_right_date(new_right_date, right_url)
                
            self.panel_left.populate()
            self.panel_right.populate()
            
        if hasattr(self, 'gif_dialog') and self.gif_dialog:
            self.gif_dialog._refresh_url_list()
            self.gif_dialog._highlight_dates()

    def _toggle_compare_mode(self):
        self.is_compare_mode = not self.is_compare_mode
        self._is_updating = True

        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()

        try:
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception:
            pass

        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

        if self.is_compare_mode:
            self.filmstrip.hide()
            self.btn_compare.setText("Close Compare")
            self.btn_compare.setStyleSheet("QPushButton { background-color: #d9534f; color: white; border-radius: 3px; padding: 5px 15px; font-weight: bold; } QPushButton:hover { background-color: #c9302c; }")
            
            self.btn_cal.setEnabled(False)
            self.btn_cal.setStyleSheet(self.btn_disabled_style)
            # GIF button remains active!
            
            # Hide central upscale button so container adapts
            self.btn_upscale.hide()

            left_dt = datetime.date.fromisoformat(self.current_left_date)
            target_dt = left_dt - datetime.timedelta(days=5)
            r_dstr, r_url = self._get_closest_valid_date(target_dt)
            
            l_dstr = self.current_left_date
            l_url_tuple = self._get_closest_valid_date(left_dt)
            l_url = l_url_tuple[1] if l_url_tuple[1] else self.plugin.api.url_list[0][1]

            self.plugin.layers.setup_compare_layers(l_dstr, l_url, r_dstr, r_url, sensor, filt)
            self.layer_left = self.plugin.layers.layer_left
            self.layer_right = self.plugin.layers.layer_right
            
            self.current_right_date = r_dstr
            
            self.panel_left.is_minimized = False
            self.panel_left.chk_cloudless.setVisible(True)
            self.panel_left.search_box.setVisible(True)
            self.panel_left.list_widget.setVisible(True)
            self.panel_left.btn_minimize.setText("▲")

            self.panel_right.is_minimized = False
            self.panel_right.chk_cloudless.setVisible(True)
            self.panel_right.search_box.setVisible(True)
            self.panel_right.list_widget.setVisible(True)
            self.panel_right.btn_minimize.setText("▲")

            self.panel_left.populate()
            self.panel_right.populate()
            self.panel_left.show()
            self.panel_right.show()
            self.btn_right_date.show()
            
            w, h = self.main_canvas.width(), self.main_canvas.height()
            self.top_canvas.setGeometry(0, 0, w, h)
            self.split_x = w // 2
            self._update_mask()
            
            self.top_canvas.show()
            self.top_canvas.raise_() 
            self.handle.show()
            self.handle.raise_()
            self.control_container.raise_()
            self.btn_left_date.raise_()
            self.btn_right_date.raise_()
            self.panel_left.raise_()
            self.panel_right.raise_()

            self._sync_extents()
            self._sync_layers()
        else:
            self.btn_compare.setText("Compare")
            self.btn_compare.setStyleSheet("QPushButton { background-color: #0078d7; color: white; border-radius: 3px; padding: 5px 15px; font-weight: bold; } QPushButton:hover { background-color: #005a9e; }")
            
            self.btn_cal.setEnabled(True)
            self.btn_cal.setStyleSheet(self.btn_style)
            # GIF button remains active!
            
            # Restore central upscale button
            self.btn_upscale.show()

            l_dstr = self.current_left_date
            l_url_tuple = self._get_closest_valid_date(datetime.date.fromisoformat(l_dstr))
            l_url = l_url_tuple[1]
            
            self.layer_right = None
            self.layer_left = self.plugin.layers.set_main_layer(l_dstr, l_url, sensor, filt)
            
            self.btn_right_date.hide()
            self.top_canvas.hide()
            self.handle.hide()
            self.panel_left.hide()
            self.panel_right.hide()
            self.filmstrip.show()

        self._update_layer_names()

        self._is_updating = False
        self.update_date_button_labels()
        self.main_canvas.layersChanged.connect(self._sync_layers)

    def _toggle_left_panel(self):
        if not self.is_compare_mode: return 
        if self.panel_left.isHidden():
            self.panel_left.populate()
            self.panel_left.show()
            self.panel_left.raise_()
        else:
            self.panel_left.hide()

    def _toggle_right_panel(self):
        if not self.is_compare_mode: return
        if self.panel_right.isHidden():
            self.panel_right.populate()
            self.panel_right.show()
            self.panel_right.raise_()
        else:
            self.panel_right.hide()

    def _do_change_left_date(self, dstr, url):
        self.current_left_date = dstr
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        
        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

        try:
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception: pass
        
        if self.is_compare_mode:
            self.layer_left = self.plugin.layers.update_compare_left(dstr, url, sensor, filt)
        else:
            self.panel_left.hide()
            self.layer_left = self.plugin.layers.set_main_layer(dstr, url, sensor, filt)
            self.filmstrip.sync_active_date(dstr)
            
        self.update_date_button_labels()
        self._update_layer_names()
        self.main_canvas.layersChanged.connect(self._sync_layers)
        self._sync_layers()
        self._resize_items()

    def _do_change_right_date(self, dstr, url):
        if not self.is_compare_mode: return
        self.current_right_date = dstr
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        
        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

        self.layer_right = self.plugin.layers.update_compare_right(dstr, url, sensor, filt)
        self.update_date_button_labels()
        self._update_layer_names()
        self._sync_layers()
        self._resize_items()

    def _sync_layers(self):
        if not self.is_compare_mode or not self.layer_right or self._is_updating:
            return
        
        try:
            left_id = self.layer_left.id() if self.layer_left else None
            right_id = self.layer_right.id() if self.layer_right else None
            up_left_lyr = self.onnx_manager.upscale_layers.get("left")
            up_right_lyr = self.onnx_manager.upscale_layers.get("right")
            up_left_id = up_left_lyr.id() if up_left_lyr and up_left_lyr.isValid() else None
            up_right_id = up_right_lyr.id() if up_right_lyr and up_right_lyr.isValid() else None
        except RuntimeError:
            return

        mirrored_layers = []

        for lyr in self.main_canvas.layers():
            if not lyr or not lyr.isValid():
                continue
            try:
                lid = lyr.id()
                if left_id and lid == left_id:
                    right_base_lyr = QgsProject.instance().mapLayer(right_id)
                    if right_base_lyr and right_base_lyr.isValid():
                        mirrored_layers.append(right_base_lyr)
                    elif self.layer_right and self.layer_right.isValid():
                        mirrored_layers.append(self.layer_right)
                    continue 
                
                if up_left_id and lid == up_left_id:
                    if up_right_lyr and up_right_lyr.isValid():
                        mirrored_layers.append(up_right_lyr)
                    continue

                base_lyr = QgsProject.instance().mapLayer(lid)
                if base_lyr and base_lyr.isValid():
                    mirrored_layers.append(base_lyr)
                elif lyr.isValid():
                    mirrored_layers.append(lyr)
            except RuntimeError:
                continue
                
        if right_id and not any(l and l.id() == right_id for l in mirrored_layers):
            right_base_lyr = QgsProject.instance().mapLayer(right_id)
            if right_base_lyr and right_base_lyr.isValid():
                mirrored_layers.append(right_base_lyr)
            elif self.layer_right and self.layer_right.isValid():
                mirrored_layers.append(self.layer_right)
                
        if up_right_lyr and up_right_lyr.isValid() and not any(l and l.id() == up_right_id for l in mirrored_layers):
            mirrored_layers.append(up_right_lyr)

        safe_layers = [l for l in mirrored_layers if l is not None and l.isValid()]

        self.top_canvas.blockSignals(True)
        try:
            self.top_canvas.setLayers(safe_layers)
        except TypeError:
            self.top_canvas.setLayers([QgsProject.instance().mapLayer(l.id()) for l in safe_layers if l and QgsProject.instance().mapLayer(l.id())])
        self.top_canvas.blockSignals(False)
        self.top_canvas.refresh()

    def _on_handle_moved(self, x):
        self.split_x = x
        self._update_mask()

    def _on_extents_settled(self):
        if hasattr(self, 'onnx_manager'):
            self.onnx_manager.clear_upscale_layers()

    def _sync_extents(self):
        if not self.is_compare_mode: return
        self.top_canvas.blockSignals(True)
        self.top_canvas.setDestinationCrs(self.main_canvas.mapSettings().destinationCrs())
        self.top_canvas.setExtent(self.main_canvas.extent())
        self.top_canvas.blockSignals(False)
        self.top_canvas.refresh()

    def eventFilter(self, obj, event):
        if obj == self.main_canvas and event.type() == (QEvent.Resize if not hasattr(QEvent.Type, 'Resize') else QEvent.Type.Resize):
            self._resize_items()
        return super().eventFilter(obj, event)

    def _resize_items(self):
        if self._is_updating:
            return

        w, h = self.main_canvas.width(), self.main_canvas.height()
        
        # Invalidate layout so container shrinks/expands dynamically when btn_upscale toggles
        if self.control_container.layout(): 
            self.control_container.layout().invalidate()
            self.control_container.layout().activate()
            
        self.control_container.adjustSize()
        cc_w = self.control_container.sizeHint().width() + 10
        cc_h = self.control_container.sizeHint().height()
        
        self.control_container.resize(cc_w, cc_h)
        self.control_container.move(int((w - cc_w) / 2), 15)
        
        self.btn_left_date.adjustSize()
        self.btn_left_date.move(15, 15)
        
        self.btn_right_date.adjustSize()
        self.btn_right_date.move(w - self.btn_right_date.width() - 15, 15)

        # Relocate compare upscale buttons directly beside dates
        if self.is_compare_mode:
            self.btn_upscale_left.adjustSize()
            self.btn_upscale_left.move(self.btn_left_date.x() + self.btn_left_date.width() + 8, 15)
            self.btn_upscale_left.show()
            self.btn_upscale_left.raise_()

            self.btn_upscale_right.adjustSize()
            self.btn_upscale_right.move(self.btn_right_date.x() - self.btn_upscale_right.width() - 8, 15)
            self.btn_upscale_right.show()
            self.btn_upscale_right.raise_()
        else:
            self.btn_upscale_left.hide()
            self.btn_upscale_right.hide()
        
        panel_w = 210
        p_left_h = 44 if self.panel_left.is_minimized else h - 60
        p_right_h = 44 if self.panel_right.is_minimized else h - 60
        
        self.panel_left.setGeometry(0, 60, panel_w, p_left_h)
        self.panel_right.setGeometry(w - panel_w, 60, panel_w, p_right_h)
        
        strip_h = 44 if self.filmstrip.is_minimized else 235
        self.filmstrip.setGeometry(50, h - strip_h - 20, w - 100, strip_h)

        if self.is_compare_mode:
            self.top_canvas.setGeometry(0, 0, w, h)
            self.split_x = min(max(self.split_x, 0), w)
            self._update_mask()

    def _update_mask(self):
        w, h = self.main_canvas.width(), self.main_canvas.height()
        self.top_canvas.setMask(QRegion(self.split_x, 0, w - self.split_x, h))
        self.handle.setGeometry(self.split_x - 20, 0, 40, h)

    def _open_calendar(self):
        dlg = DarkCalendarDialog(self)
        if dlg.exec() == (QDialog.DialogCode.Accepted if hasattr(QDialog, 'DialogCode') else QDialog.Accepted):
            cloudless_state = dlg.chk_cloudless.isChecked()
            self.filmstrip.chk_cloudless.setChecked(cloudless_state)
            if self.is_compare_mode:
                self.panel_left.chk_cloudless.setChecked(cloudless_state)
                self.panel_right.chk_cloudless.setChecked(cloudless_state)
                
            selected_dstr = dlg.get_selected_date()
            dstr, url = self._get_closest_valid_date(datetime.date.fromisoformat(selected_dstr))
            if dstr:
                self._do_change_left_date(dstr, url)

    def _take_snapshot(self):
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        
        if self.is_compare_mode:
            default_name = f"Compare_{sensor}_{filt}_{self.current_left_date}_vs_{self.current_right_date}.png"
            path, _ = QFileDialog.getSaveFileName(self.main_canvas, "Save Compare Snapshot", default_name, "PNG Image (*.png)")
            if path:
                self.main_canvas.grab().save(path, "PNG")
                self.plugin.log(f"Compare snapshot saved to {path}")
        else:
            date_str = self.current_left_date
            src_layer = self.plugin.layers.current_layer
            
            if src_layer:
                snap = QgsRasterLayer(src_layer.source(), f"Snap-Satiladu_{sensor}_{filt}_{date_str}", "wms")
                if snap.isValid(): 
                    self.plugin.layers.add_layer_at_top(snap)

    def _open_gif(self):
        self.stop_gif_btn_blink()
        
        if not hasattr(self, 'gif_dialog') or self.gif_dialog is None:
            self.gif_dialog = GifGeneratorDialog(self.plugin)
            self.gif_dialog.show()
            self.gif_dialog.raise_()
            self.gif_dialog.activateWindow()
        else:
            self.gif_dialog._refresh_url_list()
            self.gif_dialog._highlight_dates()
            
            if self.gif_dialog.isMinimized():
                self.gif_dialog.showNormal()
                self.gif_dialog.raise_()
                self.gif_dialog.activateWindow()
            elif self.gif_dialog.isVisible():
                self.gif_dialog.hide()
            else:
                self.gif_dialog.showNormal()
                self.gif_dialog.raise_()
                self.gif_dialog.activateWindow()

    def destroy_workspace(self):
        try:
            self.main_canvas.removeEventFilter(self)
            self.main_canvas.extentsChanged.disconnect(self._sync_extents)
            self.main_canvas.extentsChanged.disconnect(self._on_extents_settled)
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception:
            pass
            
        self.plugin.thumbnail_manager.clear_queue() 
        self.onnx_manager.cleanup()
        
        if hasattr(self, 'gif_dialog') and self.gif_dialog:
            self.gif_dialog.close()
            self.gif_dialog.deleteLater()
            self.gif_dialog = None
        self.top_canvas.deleteLater()
        self.handle.deleteLater()
        self.control_container.deleteLater()
        self.btn_left_date.deleteLater()
        self.btn_right_date.deleteLater()
        self.btn_upscale_left.deleteLater()
        self.btn_upscale_right.deleteLater()
        self.panel_left.deleteLater()
        self.panel_right.deleteLater()
        self.filmstrip.deleteLater()
        if self.gif_blink_timer.isActive():
            self.gif_blink_timer.stop()
        self.deleteLater()

    def start_gif_btn_blink(self):
        if not self.gif_blink_timer.isActive():
            self.gif_blink_timer.start(600) 
            
    def stop_gif_btn_blink(self):
        if self.gif_blink_timer.isActive():
            self.gif_blink_timer.stop()
        self.gif_blink_state = False
        self.btn_gif.setStyleSheet(self.btn_style)

    def _toggle_gif_button_blink(self):
        self.gif_blink_state = not self.gif_blink_state
        if self.gif_blink_state:
            blink_style = "QPushButton { background-color: #444; color: white; border: 2px solid #5cb85c; border-radius: 3px; padding: 4px 11px; font-weight: bold; } QPushButton:hover { background-color: #555; }"
            self.btn_gif.setStyleSheet(blink_style)
        else:
            self.btn_gif.setStyleSheet(self.btn_style)


class Sentinel2Dates:
    def __init__(self, iface):
        self.iface = iface
        self.api = SatiladuAPI()
        self.layers = LayerManager(iface)
        self.thumbnail_manager = ThumbnailManager(parent=iface.mainWindow(), max_concurrent=4, max_cache_size=150)
        self.workspace = None
        
        self.action_main = None
        self.toolbar = None
        
        self.combo_sensor = QComboBox() 
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_filter = QComboBox()

        self._filter_data = [
            ("RGB", 1, "harilik värvifoto"),
            ("NRG", 3, "valevärvipilt \"Lähi-infrapuna Punane Roheline\""),
            ("NDVI", 5, "normaliseeritud taimkatte indeks (NDVI)"),
            ("NGR", 7, "valevärvipilt \"Lähi-infrapuna Roheline Punane\""),
            ("NDPI", 9, "normaliseeritud veekogude indeks (NDPI)"),
            ("PNB", 11, "valevärvipilt \"NDPI Lähi-infrapuna Sinine\""),
            ("NGP", 13, "valevärvipilt \"Lähi-infrapuna Roheline NDPI\""),
            ("NDR", 15, "valevärvipilt \"Lähi-infrapuna NDVI Punane\""),
            ("PDB", 17, "valevärvipilt \"NDPI NDVI Sinine\""),
            ("NDN", 19, "valevärvipilt \"Lähi-infrapuna NDVI Lähi-infrapuna\""),
            ("PDN", 21, "valevärvipilt \"NDPI NDVI Lähi-infrapuna\""),
            ("NNR", 23, "valevärvipilt \"Lähi-infrapuna Lähi-Infrapuna Punane\""),
            ("DNP", 25, "valevärvipilt \"NDVI Lähi-infrapuna NDPI\"")
        ]
        
        for idx, (code, toode_id, desc) in enumerate(self._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, TOOLTIP_ROLE)

    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        def get_icon(filename):
            return QIcon(os.path.join(plugin_dir, filename))

        self.action_main = QAction(get_icon("icon.png"), "Toggle Satiladu Workspace", self.iface.mainWindow())
        self.action_main.setCheckable(True)
        self.action_main.toggled.connect(self._on_main_toggled)

        self.toolbar = self.iface.addToolBar("Satiladu")
        self.toolbar.setObjectName("SatiladuToolbar")
        self.toolbar.addAction(self.action_main)
        
        self.iface.addPluginToMenu("&Sentinel WMS", self.action_main)

    def unload(self):
        if self.workspace:
            self.workspace.destroy_workspace()
        self.layers.remove_layer()
        self.layers.remove_compare_layers()
        if self.toolbar: self.iface.mainWindow().removeToolBar(self.toolbar)

    def _on_main_toggled(self, checked: bool):
        if checked:
            if not self.api.url_list:
                bbox = self.layers.get_canvas_bbox_latlon_str()
                sensor = self.combo_sensor.currentText()
                toode = self.combo_filter.currentData()
                
                self.api.refresh_urls_async(bbox, sensor, toode, True, self._on_initial_fetch_done)
            else:
                dstr, url = self.api.url_list[0]
                self.workspace = SatiladuWorkspace(self, dstr, url)
        else:
            if self.workspace:
                self.workspace.destroy_workspace()
                self.workspace = None
            self.layers.remove_layer()
            self.layers.remove_compare_layers()
            self.iface.mapCanvas().refresh()

    def _on_initial_fetch_done(self, success, url_list, err):
        if success and url_list:
            dstr, url = url_list[0]
            self.workspace = SatiladuWorkspace(self, dstr, url)
        else:
            self.log(f"Could not load initial dates: {err}", Qgis.Critical)
            self.action_main.setChecked(False)