# -*- coding: utf-8 -*-
"""
SentinelWMS – QGIS plugin main script
Modular Architecture with Async GIF Processing
"""
import os
import datetime
from qgis.core import Qgis, QgsMessageLog, QgsRasterLayer, QgsProject, QgsNetworkAccessManager
from qgis.gui import QgsMapCanvas
from qgis.PyQt.QtCore import Qt, QDate, QUrl, QSize, QTimer, QPoint, pyqtSignal, QObject, QEvent
from qgis.PyQt.QtGui import QIcon, QTextCharFormat, QColor, QFont, QPixmap, QImage, QRegion, QPainter, QPen
from qgis.PyQt.QtWidgets import (
    QAction, QComboBox, QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
    QCalendarWidget, QListWidget, QListWidgetItem, QLabel, QWidget, QAbstractItemView,
    QFrame, QMenu, QCheckBox, QLineEdit
)
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply

from .satiladu_api import SatiladuAPI
from .layer_manager import LayerManager
from .gif_dialog import GifGeneratorDialog

class PreviewThumbnailWidget(QWidget):
    def __init__(self, dstr, url, bbox, parent=None, dark_mode=False):
        super().__init__(parent)
        self.dstr = dstr
        self.is_loaded = False
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(5, 5, 5, 5)
        self.layout.setSpacing(2)
        
        self.lbl_date = QLabel(datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y"))
        
        try:
            align_center = Qt.AlignmentFlag.AlignCenter
        except AttributeError:
            align_center = Qt.AlignCenter
            
        self.lbl_date.setAlignment(align_center)
        self.layout.addWidget(self.lbl_date)
        
        self.lbl_thumb = QLabel("Loading...")
        self.lbl_thumb.setFixedSize(130, 130)
        self.lbl_thumb.setAlignment(align_center)
        self.layout.addWidget(self.lbl_thumb)

        if dark_mode:
            self.lbl_date.setStyleSheet("color: white; font-weight: bold;")
            self.lbl_thumb.setStyleSheet("border: 1px solid #777; background-color: #222; color: #aaa;")
        else:
            self.lbl_thumb.setStyleSheet("border: 1px solid #aaa; background-color: #eee;")

        layer_param = url.split('?')[0].split('wms-')[-1].replace('-', '_')
        self.thumb_url = (f"{url}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                          f"&BBOX={bbox}&SRS=EPSG:3301&WIDTH=130&HEIGHT=130"
                          f"&LAYERS={layer_param}&STYLES=&FORMAT=image/jpeg")

    def set_pixmap(self, pixmap):
        try:
            aspect = Qt.AspectRatioMode.KeepAspectRatio
        except AttributeError:
            aspect = Qt.KeepAspectRatio
        self.lbl_thumb.setPixmap(pixmap.scaled(130, 130, aspect))
        self.lbl_thumb.setStyleSheet("border: 1px solid #555;")
        self.is_loaded = True

class InlineThumbnailPanel(QWidget):
    dateSelected = pyqtSignal(str, str)

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.nam = QgsNetworkAccessManager()
        self.active_replies = set()

        self.setStyleSheet("""
            QWidget { background-color: rgba(30, 30, 30, 230); border: 1px solid #444; border-radius: 4px; color: white; }
            QListWidget { background: transparent; border: none; outline: none; }
            QListWidget::item { border-bottom: 1px solid #444; margin-bottom: 2px; }
            QListWidget::item:hover { background-color: rgba(80, 80, 80, 200); }
            QListWidget::item:selected { background-color: rgba(0, 120, 215, 200); }
            QScrollBar:vertical { background: #222; width: 12px; }
            QScrollBar::handle:vertical { background: #666; border-radius: 6px; min-height: 20px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
            ibeam_cursor = Qt.CursorShape.IBeamCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor
            ibeam_cursor = Qt.IBeamCursor

        top_layout = QVBoxLayout()
        top_layout.setSpacing(6)
        
        self.chk_cloudless = QCheckBox("Cloudless only")
        self.chk_cloudless.setStyleSheet("color: white; font-weight: bold; border: none;")
        self.chk_cloudless.setCursor(arrow_cursor)
        self.chk_cloudless.setChecked(self.plugin.action_sun.isChecked())
        self.chk_cloudless.toggled.connect(self.populate)
        top_layout.addWidget(self.chk_cloudless)
        
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search date (e.g. 10.)...")
        self.search_box.setStyleSheet("background-color: #222; color: white; border: 1px solid #555; padding: 6px; border-radius: 3px;")
        self.search_box.setCursor(ibeam_cursor)
        
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._apply_filter)
        self.search_box.textChanged.connect(lambda text: self.search_timer.start(400))
        
        top_layout.addWidget(self.search_box)
        layout.addLayout(top_layout)

        self.list_widget = QListWidget()
        self.list_widget.setCursor(arrow_cursor)
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        layout.addWidget(self.list_widget)

        self.preview_widgets = {}
        self.tmp_api = SatiladuAPI()

        try:
            self.user_role = Qt.ItemDataRole.UserRole
        except AttributeError:
            self.user_role = Qt.UserRole

        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

    def _cancel_active_requests(self):
        for reply in list(self.active_replies):
            try:
                if reply.isRunning():
                    reply.abort()
            except RuntimeError:
                pass
        self.active_replies.clear()

    def hideEvent(self, event):
        self._cancel_active_requests()
        super().hideEvent(event)

    def populate(self):
        self._cancel_active_requests()
        self.list_widget.clear()
        self.preview_widgets.clear()
        
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.plugin.combo_sensor.currentText()
        toode = self.plugin.combo_filter.currentData()
        
        self.tmp_api.refresh_urls_list(bbox_latlon, sensor, toode, self.chk_cloudless.isChecked())
        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()

        for dstr, url in self.tmp_api.url_list:
            item = QListWidgetItem(self.list_widget)
            item.setSizeHint(QSize(170, 180))
            item.setData(self.user_role, (dstr, url)) 
            
            widget = PreviewThumbnailWidget(dstr, url, bbox_3301, dark_mode=True)
            self.list_widget.setItemWidget(item, widget)
            self.preview_widgets[dstr] = widget

        if self.search_box.text():
            self._apply_filter()
        else:
            QTimer.singleShot(50, self._process_visible_thumbnails)

    def _apply_filter(self):
        self._cancel_active_requests()
        search_term = self.search_box.text().lower()
        
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            dstr = item.data(self.user_role)[0]
            dt_formatted = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
            item.setHidden(search_term not in dt_formatted)
            
        self._process_visible_thumbnails()

    def _process_visible_thumbnails(self):
        viewport_rect = self.list_widget.viewport().rect()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                rect = self.list_widget.visualItemRect(item)
                if rect.isValid() and viewport_rect.intersects(rect):
                    dstr, url = item.data(self.user_role)
                    widget = self.preview_widgets.get(dstr)
                    if widget and not widget.is_loaded:
                        self._load_thumbnail(widget)

    def _load_thumbnail(self, widget):
        if widget.thumb_url in self.plugin.thumbnail_cache:
            widget.set_pixmap(self.plugin.thumbnail_cache[widget.thumb_url])
            return

        req = QNetworkRequest(QUrl(widget.thumb_url))
        reply = self.nam.get(req)
        self.active_replies.add(reply)
        reply.finished.connect(lambda r=reply, w=widget: self._on_thumbnail_loaded(r, w))

    def _on_thumbnail_loaded(self, reply, widget):
        if reply in self.active_replies:
            self.active_replies.remove(reply)
            
        try:
            no_error = QNetworkReply.NetworkError.NoError
            cancel_error = QNetworkReply.NetworkError.OperationCanceledError
        except AttributeError:
            no_error = QNetworkReply.NoError
            cancel_error = QNetworkReply.OperationCanceledError

        if reply.error() == cancel_error:
            reply.deleteLater()
            return 

        if reply.error() == no_error:
            img_data = reply.readAll()
            img = QImage.fromData(img_data)
            if not img.isNull():
                pix = QPixmap.fromImage(img)
                self.plugin.thumbnail_cache[widget.thumb_url] = pix
                widget.set_pixmap(pix)
            else:
                widget.lbl_thumb.setText("No Image")
        else:
            widget.lbl_thumb.setText("Error")
        reply.deleteLater()

    def _on_item_clicked(self, item):
        dstr, url = item.data(self.user_role)
        self.dateSelected.emit(dstr, url)

class SwipeHandle(QWidget):
    positionChanged = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.SplitHCursor if not hasattr(Qt.CursorShape, 'SplitHCursor') else Qt.CursorShape.SplitHCursor)
        
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        except AttributeError:
            self.setAttribute(Qt.WA_TranslucentBackground)
            
        self.setFixedWidth(40) 
        self.setMouseTracking(True)
        self._dragging = False
        self._is_hovering = False
        self._hover_y = 0

    def enterEvent(self, event):
        self._is_hovering = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._is_hovering = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        try:
            left_btn = Qt.MouseButton.LeftButton
        except AttributeError:
            left_btn = Qt.LeftButton
            
        if event.button() == left_btn:
            self._dragging = True
            self.update()

    def mouseMoveEvent(self, event):
        try:
            pos_y = event.position().y()
        except AttributeError:
            pos_y = event.pos().y()
            
        self._hover_y = pos_y
        self.update()
        
        if self._dragging:
            try:
                gpos = event.globalPosition().toPoint()
            except AttributeError:
                gpos = event.globalPos()
            
            parent_pos = self.parent().mapFromGlobal(gpos)
            new_x = max(0, min(parent_pos.x(), self.parent().width()))
            self.positionChanged.emit(new_x)

    def mouseReleaseEvent(self, event):
        try:
            left_btn = Qt.MouseButton.LeftButton
        except AttributeError:
            left_btn = Qt.LeftButton
            
        if event.button() == left_btn:
            self._dragging = False
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            aa = QPainter.RenderHint.Antialiasing
            no_pen = Qt.PenStyle.NoPen
        except AttributeError:
            aa = QPainter.Antialiasing
            no_pen = Qt.NoPen
            
        painter.setRenderHint(aa)
        
        w, h = self.width(), self.height()
        center_x = w // 2
        
        painter.setPen(no_pen)
        painter.setBrush(QColor(0, 0, 0, 1))
        painter.drawRect(0, 0, w, h)
        
        pen_shadow = QPen(QColor(0, 0, 0, 150))
        pen_shadow.setWidth(2)
        painter.setPen(pen_shadow)
        painter.drawLine(center_x, 0, center_x, h)
        
        pen_white = QPen(QColor(255, 255, 255, 230))
        pen_white.setWidth(1)
        painter.setPen(pen_white)
        painter.drawLine(center_x, 0, center_x, h)
        
        painter.setPen(no_pen)
        
        if self._is_hovering or self._dragging:
            dot_y = max(20, min(self._hover_y, h - 20))
            painter.setBrush(QColor(0, 0, 0, 100))
            painter.drawEllipse(center_x - 11, int(dot_y) - 11, 22, 22)
            painter.setBrush(QColor(255, 255, 255, 255))
            painter.drawEllipse(center_x - 9, int(dot_y) - 9, 18, 18)
            painter.setBrush(QColor(0, 120, 215, 255))
            painter.drawEllipse(center_x - 5, int(dot_y) - 5, 10, 10)
            
        painter.end()


class CanvasSwipeManager(QObject):
    def __init__(self, plugin, main_canvas, layer_top, layer_bottom, date_left, date_right, close_callback):
        super().__init__(main_canvas)
        self.plugin = plugin
        self.main_canvas = main_canvas
        self.layer_top = layer_top
        self.layer_bottom = layer_bottom
        self.close_callback = close_callback
        
        self.top_canvas = QgsMapCanvas(self.main_canvas)
        self.top_canvas.setCanvasColor(QColor(0,0,0,0))
        self.top_canvas.setStyleSheet("background: transparent;")
        self.top_canvas.setProject(QgsProject.instance())
        
        self._sync_layers()
        self.top_canvas.setDestinationCrs(self.main_canvas.mapSettings().destinationCrs())
        self.top_canvas.setExtent(self.main_canvas.extent())
        
        self.top_canvas.setAttribute(Qt.WA_TransparentForMouseEvents if not hasattr(Qt.WidgetAttribute, 'WA_TransparentForMouseEvents') else Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.top_canvas.show()
        
        self.handle = SwipeHandle(self.main_canvas)
        self.handle.positionChanged.connect(self._on_handle_moved)
        self.handle.show()

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor

        self.control_container = QWidget(self.main_canvas)
        self.control_container.setStyleSheet("background: rgba(30,30,30,220); border-radius: 4px; border: 1px solid #555;")
        h_layout = QHBoxLayout(self.control_container)
        h_layout.setContentsMargins(8, 6, 8, 6)
        h_layout.setSpacing(10)
        
        combo_style = "QComboBox { background-color: #444; color: white; border: 1px solid #666; border-radius: 3px; padding: 4px 10px; } QComboBox::drop-down { border: 0px; } QComboBox QAbstractItemView { background: #444; color: white; selection-background-color: #0078d7; outline: none; }"
        
        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_sensor.setCurrentIndex(self.plugin.combo_sensor.currentIndex())
        self.combo_sensor.setStyleSheet(combo_style)
        self.combo_sensor.setCursor(arrow_cursor)
        
        self.combo_filter = QComboBox()
        for code, toode_id, desc in self.plugin._filter_data:
            self.combo_filter.addItem(code, toode_id)
        self.combo_filter.setCurrentIndex(self.plugin.combo_filter.currentIndex())
        self.combo_filter.setStyleSheet(combo_style)
        self.combo_filter.setCursor(arrow_cursor)
        
        self.btn_close = QPushButton("Close Compare")
        self.btn_close.setStyleSheet("background-color: #d9534f; color: white; font-weight: bold; border-radius: 3px; border: 1px solid #c9302c; padding: 5px 12px;")
        self.btn_close.setCursor(arrow_cursor)
        self.btn_close.clicked.connect(self._close)
        
        h_layout.addWidget(self.combo_sensor)
        h_layout.addWidget(self.combo_filter)
        h_layout.addWidget(self.btn_close)
        self.control_container.adjustSize()
        self.control_container.show()
        
        self.combo_sensor.currentIndexChanged.connect(self._on_settings_changed)
        self.combo_filter.currentIndexChanged.connect(self._on_settings_changed)

        self.panel_left = InlineThumbnailPanel(self.plugin, self.main_canvas)
        self.panel_left.hide()
        self.panel_left.dateSelected.connect(self._do_change_left_date)

        self.panel_right = InlineThumbnailPanel(self.plugin, self.main_canvas)
        self.panel_right.hide()
        self.panel_right.dateSelected.connect(self._do_change_right_date)
        
        self.btn_left = QPushButton(f"LEFT: {date_left}", self.main_canvas)
        self.btn_left.setStyleSheet("QPushButton { background: rgba(30,30,30,220); color: white; border-radius: 4px; padding: 8px 12px; font-size: 14px; font-weight: bold; border: 1px solid #666; } QPushButton:hover { background: rgba(50,50,50,240); border: 1px solid #aaa; }")
        self.btn_left.setCursor(arrow_cursor)
        self.btn_left.clicked.connect(self._toggle_left_panel)
        self.btn_left.adjustSize()
        self.btn_left.show()
        
        self.btn_right = QPushButton(f"RIGHT: {date_right}", self.main_canvas)
        self.btn_right.setStyleSheet("QPushButton { background: rgba(30,30,30,220); color: white; border-radius: 4px; padding: 8px 12px; font-size: 14px; font-weight: bold; border: 1px solid #666; } QPushButton:hover { background: rgba(50,50,50,240); border: 1px solid #aaa; }")
        self.btn_right.setCursor(arrow_cursor)
        self.btn_right.clicked.connect(self._toggle_right_panel)
        self.btn_right.adjustSize()
        self.btn_right.show()
        
        self.split_x = self.main_canvas.width() // 2
        
        self.main_canvas.extentsChanged.connect(self._sync_extents)
        self.main_canvas.layersChanged.connect(self._sync_layers)
        self.main_canvas.installEventFilter(self)
        
        self._resize_items()

    def _get_closest_date_and_url(self, target_dstr):
        if not self.plugin.api.url_list: return None, None
        if not target_dstr: return self.plugin.api.url_list[0]
        
        try:
            target_dt = datetime.date.fromisoformat(target_dstr)
        except Exception:
            return self.plugin.api.url_list[0]
            
        best_idx = 0
        min_diff = float('inf')
        for idx, (d_str, url) in enumerate(self.plugin.api.url_list):
            diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
            if diff == 0: return d_str, url
            if diff < min_diff:
                min_diff = diff
                best_idx = idx
        return self.plugin.api.url_list[best_idx]

    def _on_settings_changed(self):
        self.plugin.combo_sensor.blockSignals(True)
        self.plugin.combo_sensor.setCurrentIndex(self.combo_sensor.currentIndex())
        self.plugin.combo_sensor.blockSignals(False)
        
        self.plugin.combo_filter.blockSignals(True)
        self.plugin.combo_filter.setCurrentIndex(self.combo_filter.currentIndex())
        self.plugin.combo_filter.blockSignals(False)

        self.plugin._sync_api_call()
        
        new_left_date, left_url = self._get_closest_date_and_url(self.plugin.compare_left_date)
        new_right_date, right_url = self._get_closest_date_and_url(self.plugin.compare_right_date)
        
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        
        try:
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception: pass
        
        if left_url:
            self.layer_bottom = self.plugin.layers.update_compare_left(new_left_date, left_url, sensor, filt)
            self.plugin.compare_left_date = new_left_date
            self.btn_left.setText(f"LEFT: {new_left_date}")
            self.btn_left.adjustSize()
            
        if right_url:
            self.layer_top = self.plugin.layers.update_compare_right(new_right_date, right_url, sensor, filt)
            self.plugin.compare_right_date = new_right_date
            self.btn_right.setText(f"RIGHT: {new_right_date}")
            self.btn_right.adjustSize()
            
        self._resize_items()
        self.main_canvas.layersChanged.connect(self._sync_layers)
        self._sync_layers()
        
        if not self.panel_left.isHidden(): self.panel_left.populate()
        if not self.panel_right.isHidden(): self.panel_right.populate()

    def _toggle_left_panel(self):
        if self.panel_left.isHidden():
            self.panel_left.populate()
            self.panel_left.show()
            self.panel_left.raise_()
        else:
            self.panel_left.hide()

    def _toggle_right_panel(self):
        if self.panel_right.isHidden():
            self.panel_right.populate()
            self.panel_right.show()
            self.panel_right.raise_()
        else:
            self.panel_right.hide()

    def _do_change_left_date(self, dstr, url):
        self.panel_left.hide()
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        
        try:
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception: pass
        
        self.layer_bottom = self.plugin.layers.update_compare_left(dstr, url, sensor, filt)
        self.plugin.compare_left_date = dstr
        self.btn_left.setText(f"LEFT: {dstr}")
        self.btn_left.adjustSize()
        self._resize_items()
        
        self.main_canvas.layersChanged.connect(self._sync_layers)
        self._sync_layers()

    def _do_change_right_date(self, dstr, url):
        self.panel_right.hide()
        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        
        self.layer_top = self.plugin.layers.update_compare_right(dstr, url, sensor, filt)
        self.plugin.compare_right_date = dstr
        self.btn_right.setText(f"RIGHT: {dstr}")
        self.btn_right.adjustSize()
        self._resize_items()
        self._sync_layers()

    def _sync_layers(self):
        mirrored_layers = []
        for lyr in self.main_canvas.layers():
            if lyr == self.layer_bottom:
                mirrored_layers.append(self.layer_top)
            else:
                mirrored_layers.append(lyr)
                
        if self.layer_top not in mirrored_layers:
            mirrored_layers.append(self.layer_top)
            
        self.top_canvas.setLayers(mirrored_layers)

    def _on_handle_moved(self, x):
        self.split_x = x
        self._update_mask()

    def _sync_extents(self):
        self.top_canvas.setDestinationCrs(self.main_canvas.mapSettings().destinationCrs())
        self.top_canvas.setExtent(self.main_canvas.extent())
        self.top_canvas.refresh()

    def eventFilter(self, obj, event):
        if obj == self.main_canvas and event.type() == (QEvent.Resize if not hasattr(QEvent.Type, 'Resize') else QEvent.Type.Resize):
            self._resize_items()
        return super().eventFilter(obj, event)

    def _resize_items(self):
        w, h = self.main_canvas.width(), self.main_canvas.height()
        self.top_canvas.setGeometry(0, 0, w, h)
        
        self.split_x = min(max(self.split_x, 0), w)
        
        self.btn_left.move(20, 20)
        self.btn_right.move(w - self.btn_right.width() - 20, 20)
        
        cc_w = self.control_container.width()
        self.control_container.move((w - cc_w) // 2, 20)
        
        panel_w = 210
        self.panel_left.setGeometry(0, 60, panel_w, h - 60)
        self.panel_right.setGeometry(w - panel_w, 60, panel_w, h - 60)
        
        self._update_mask()

    def _update_mask(self):
        w, h = self.main_canvas.width(), self.main_canvas.height()
        self.top_canvas.setMask(QRegion(self.split_x, 0, w - self.split_x, h))
        self.handle.setGeometry(self.split_x - 20, 0, 40, h)

    def _close(self):
        try:
            self.main_canvas.removeEventFilter(self)
            self.main_canvas.extentsChanged.disconnect(self._sync_extents)
            self.main_canvas.layersChanged.disconnect(self._sync_layers)
        except Exception:
            pass
        self.top_canvas.deleteLater()
        self.handle.deleteLater()
        self.control_container.deleteLater()
        self.btn_left.deleteLater()
        self.btn_right.deleteLater()
        self.panel_left.deleteLater()
        self.panel_right.deleteLater()
        self.close_callback()
        self.deleteLater()

class CompareDropBox(QFrame):
    dateChanged = pyqtSignal(str)

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.current_date = None
        self.setAcceptDrops(True)
        
        try:
            strong_focus = Qt.FocusPolicy.StrongFocus
            styled_panel = QFrame.Shape.StyledPanel
        except AttributeError:
            strong_focus = Qt.StrongFocus
            styled_panel = QFrame.StyledPanel
            
        self.setFocusPolicy(strong_focus)
        self.setFrameShape(styled_panel)

        self._base_style = "CompareDropBox { border: 2px dashed #aaa; border-radius: 5px; } CompareDropBox:focus { border-color: #0078d7; }"
        self._filled_style = "CompareDropBox { border: 2px solid #5cb85c; border-radius: 5px; background-color: #f2fdf2; } CompareDropBox:focus { border-color: #0078d7; }"
        self.setStyleSheet(self._base_style)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        self.lbl_text = QLabel(f"<b>{title}</b><br><span style='color:#666;'>(Drag date here)</span>")
        
        try:
            align_center = Qt.AlignmentFlag.AlignCenter
        except AttributeError:
            align_center = Qt.AlignCenter
        self.lbl_text.setAlignment(align_center)
        layout.addWidget(self.lbl_text)

        self.btn_clear = QPushButton("×")
        self.btn_clear.setFixedSize(22, 22)
        self.btn_clear.setStyleSheet("QPushButton { border: none; font-weight: bold; font-size: 16px; color: #888; } QPushButton:hover { color: red; }")
        self.btn_clear.hide()
        self.btn_clear.clicked.connect(self.clear_date)
        layout.addWidget(self.btn_clear)

    def set_date(self, dstr):
        self.current_date = dstr
        if dstr:
            dt_formatted = datetime.date.fromisoformat(dstr).strftime("%d.%m.%Y")
            self.lbl_text.setText(f"<b>{self.title}</b><br>{dt_formatted}")
            self.btn_clear.show()
            self.setStyleSheet(self._filled_style)
        else:
            self.lbl_text.setText(f"<b>{self.title}</b><br><span style='color:#666;'>(Drag date here)</span>")
            self.btn_clear.hide()
            self.setStyleSheet(self._base_style)
        self.dateChanged.emit(self.current_date or "")

    def clear_date(self):
        self.set_date(None)

    def dragEnterEvent(self, event):
        if event.source() and event.source().inherits("QListWidget"):
            event.acceptProposedAction()

    def dropEvent(self, event):
        source = event.source()
        if source and source.inherits("QListWidget"):
            item = source.currentItem()
            if item:
                try:
                    user_role = Qt.ItemDataRole.UserRole
                except AttributeError:
                    user_role = Qt.UserRole
                dstr = item.data(user_role)
                if isinstance(dstr, tuple): dstr = dstr[0]
                if dstr:
                    self.set_date(dstr)
                    event.acceptProposedAction()

    def keyPressEvent(self, event):
        try:
            key_del = Qt.Key.Key_Delete
            key_back = Qt.Key.Key_Backspace
        except AttributeError:
            key_del = Qt.Key_Delete
            key_back = Qt.Key_Backspace
            
        if event.key() in (key_del, key_back):
            self.clear_date()
        else:
            super().keyPressEvent(event)

class CalendarSelectDialog(QDialog):
    def __init__(self, parent_plugin):
        super().__init__(parent_plugin.iface.mainWindow())
        self.plugin = parent_plugin
        self.nam = QgsNetworkAccessManager()
        self.active_replies = set()
        self.setWindowTitle("Select Date")
        self.resize(780, 520) 
        self._is_syncing = False
        
        try:
            self.user_role = Qt.ItemDataRole.UserRole 
        except AttributeError:
            self.user_role = Qt.UserRole

        main_layout = QHBoxLayout(self)
        left_layout = QVBoxLayout()
        self.calendar = QCalendarWidget()
        self.calendar.setMaximumDate(QDate.currentDate())
        self.calendar.setMinimumHeight(280) 
        self.calendar.setGridVisible(True)
        self.calendar.selectionChanged.connect(self._on_calendar_selection_changed)
        self.calendar.currentPageChanged.connect(self._on_month_changed)
        left_layout.addWidget(self.calendar)

        top_controls = QHBoxLayout()
        self.btn_compare_toggle = QPushButton("Compare Dates")
        self.btn_compare_toggle.setCheckable(True)
        self.btn_compare_toggle.toggled.connect(self._toggle_compare_panel)
        top_controls.addWidget(self.btn_compare_toggle)

        try:
            arrow_cursor = Qt.CursorShape.ArrowCursor
        except AttributeError:
            arrow_cursor = Qt.ArrowCursor
            
        self.chk_cloudless = QCheckBox("Cloudless only")
        self.chk_cloudless.setCursor(arrow_cursor)
        self.chk_cloudless.setChecked(self.plugin.action_sun.isChecked())
        self.chk_cloudless.toggled.connect(self._on_cloudless_toggled)
        top_controls.addWidget(self.chk_cloudless)
        top_controls.addStretch()

        left_layout.addLayout(top_controls)

        self.compare_container = QWidget()
        comp_layout = QVBoxLayout(self.compare_container)
        comp_layout.setContentsMargins(0, 0, 0, 0)
        
        cal_btn_layout = QHBoxLayout()
        self.btn_set_left_cal = QPushButton("↓ Set Left")
        self.btn_set_right_cal = QPushButton("↓ Set Right")
        self.btn_set_left_cal.setToolTip("Set closest available date to Left box")
        self.btn_set_right_cal.setToolTip("Set closest available date to Right box")
        cal_btn_layout.addWidget(self.btn_set_left_cal)
        cal_btn_layout.addWidget(self.btn_set_right_cal)
        comp_layout.addLayout(cal_btn_layout)

        box_layout = QHBoxLayout()
        self.box_left = CompareDropBox("Left")
        self.box_right = CompareDropBox("Right")
        box_layout.addWidget(self.box_left)
        box_layout.addWidget(self.box_right)
        comp_layout.addLayout(box_layout)

        action_layout = QHBoxLayout()
        self.btn_clear_comp = QPushButton("Clear")
        self.btn_start_swipe = QPushButton("Start Compare")
        self.btn_start_swipe.setEnabled(False)
        self.btn_start_swipe.setStyleSheet("QPushButton:enabled { background-color: #0078d7; color: white; font-weight: bold; }")
        
        action_layout.addWidget(self.btn_clear_comp)
        action_layout.addWidget(self.btn_start_swipe)
        comp_layout.addLayout(action_layout)

        left_layout.addWidget(self.compare_container)
        self.compare_container.hide() 

        self.box_left.dateChanged.connect(self._on_left_changed)
        self.box_right.dateChanged.connect(self._on_right_changed)
        
        self.btn_set_left_cal.clicked.connect(lambda: self.box_left.set_date(self._get_closest_valid_date(self.get_selected_date())))
        self.btn_set_right_cal.clicked.connect(lambda: self.box_right.set_date(self._get_closest_valid_date(self.get_selected_date())))
        
        self.btn_clear_comp.clicked.connect(lambda: (self.box_left.clear_date(), self.box_right.clear_date()))
        self.btn_start_swipe.clicked.connect(self._start_swipe)

        btn_layout = QHBoxLayout()
        self.btn_ok = QPushButton("Jump to Date")
        self.btn_cancel = QPushButton("Cancel")
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        left_layout.addLayout(btn_layout)

        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
        main_layout.addLayout(left_layout, 1)

        self.list_widget = QListWidget()
        self.list_widget.setFixedWidth(180)
        
        try:
            scroll_per_pixel = QAbstractItemView.ScrollMode.ScrollPerPixel
        except AttributeError:
            scroll_per_pixel = QAbstractItemView.ScrollPerPixel
        self.list_widget.setVerticalScrollMode(scroll_per_pixel)
        self.list_widget.verticalScrollBar().setSingleStep(25)
        self.list_widget.setDragEnabled(True)
        
        try:
            custom_context = Qt.ContextMenuPolicy.CustomContextMenu
        except AttributeError:
            custom_context = Qt.CustomContextMenu
        self.list_widget.setContextMenuPolicy(custom_context)
        self.list_widget.customContextMenuRequested.connect(self._show_context_menu)
        
        self.scroll_debounce_timer = QTimer(self)
        self.scroll_debounce_timer.setSingleShot(True)
        self.scroll_debounce_timer.timeout.connect(self._process_visible_thumbnails)
        self.list_widget.verticalScrollBar().valueChanged.connect(
            lambda: self.scroll_debounce_timer.start(250)
        )

        self.list_widget.currentItemChanged.connect(self._on_preview_changed)
        main_layout.addWidget(self.list_widget)
        
        self.preview_widgets = {}
        self.all_urls = []

        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._do_blink)
        self.blink_count = 0
        self.blink_date = None

        self._fetch_all_dates_and_populate()

        if self.plugin.compare_mode_active:
            self.btn_compare_toggle.setChecked(True)
            self.compare_container.show()
        if self.plugin.compare_left_date:
            self.box_left.set_date(self.plugin.compare_left_date)
        if self.plugin.compare_right_date:
            self.box_right.set_date(self.plugin.compare_right_date)

        if self.plugin.api.url_list and 0 <= self.plugin._list_pos < len(self.plugin.api.url_list):
            dt = datetime.date.fromisoformat(self.plugin.api.url_list[self.plugin._list_pos][0])
            self.calendar.setSelectedDate(QDate(dt.year, dt.month, dt.day))
            
        self._validate_compare_state() 
        self._validate_selection() 
        self._on_month_changed(self.calendar.yearShown(), self.calendar.monthShown())

    def hideEvent(self, event):
        for reply in list(self.active_replies):
            try:
                if reply.isRunning():
                    reply.abort()
            except RuntimeError:
                pass
        self.active_replies.clear()
        super().hideEvent(event)

    def _on_cloudless_toggled(self, checked):
        self.plugin.action_sun.blockSignals(True)
        self.plugin.action_sun.setChecked(checked)
        self.plugin.action_sun.blockSignals(False)
        self._fetch_all_dates_and_populate()

    def _get_closest_valid_date(self, target_date):
        if not self.all_urls: return None
        best_dstr = self.all_urls[0][0]
        min_diff = float('inf')
        for dstr, _ in self.all_urls:
            diff = abs((datetime.date.fromisoformat(dstr) - target_date).days)
            if diff == 0: return dstr
            if diff < min_diff:
                min_diff = diff
                best_dstr = dstr
        return best_dstr

    def _toggle_compare_panel(self, checked):
        self.plugin.compare_mode_active = checked
        self.compare_container.setVisible(checked)

    def _on_left_changed(self, dstr):
        self.plugin.compare_left_date = dstr
        self._validate_compare_state()

    def _on_right_changed(self, dstr):
        self.plugin.compare_right_date = dstr
        self._validate_compare_state()

    def _validate_compare_state(self):
        self.btn_start_swipe.setEnabled(bool(self.box_left.current_date and self.box_right.current_date))

    def _start_swipe(self):
        self.done(2)

    def _show_context_menu(self, position):
        item = self.list_widget.itemAt(position)
        if not item: return
        
        menu = QMenu()
        left_action = menu.addAction("Add to Left Comparison")
        right_action = menu.addAction("Add to Right Comparison")
        
        action = menu.exec(self.list_widget.mapToGlobal(position)) if hasattr(menu, 'exec') else menu.exec_(self.list_widget.mapToGlobal(position))
        
        if action == left_action:
            dstr = item.data(self.user_role)
            if isinstance(dstr, tuple): dstr = dstr[0]
            self.box_left.set_date(dstr)
            if not self.btn_compare_toggle.isChecked(): self.btn_compare_toggle.setChecked(True)
        elif action == right_action:
            dstr = item.data(self.user_role)
            if isinstance(dstr, tuple): dstr = dstr[0]
            self.box_right.set_date(dstr)
            if not self.btn_compare_toggle.isChecked(): self.btn_compare_toggle.setChecked(True)

    def _fetch_all_dates_and_populate(self):
        self.list_widget.clear()
        self.preview_widgets.clear()
        
        tmp_api = SatiladuAPI()
        bbox_latlon = self.plugin.layers.get_canvas_bbox_latlon_str()
        sensor = self.plugin.combo_sensor.currentText()
        toode = self.plugin.combo_filter.currentData()
        
        is_cloudless = self.chk_cloudless.isChecked()
        tmp_api.refresh_urls_list(bbox_latlon, sensor, toode, is_cloudless)
        self.all_urls = tmp_api.url_list
        bbox_3301 = self.plugin.layers.get_canvas_bbox_3301_str()

        self.calendar.setDateTextFormat(QDate(), QTextCharFormat())

        for dstr, url in self.all_urls:
            item = QListWidgetItem(self.list_widget)
            item.setSizeHint(QSize(150, 160))
            item.setData(self.user_role, dstr)
            
            widget = PreviewThumbnailWidget(dstr, url, bbox_3301)
            self.list_widget.setItemWidget(item, widget)
            self.preview_widgets[dstr] = (item, widget)
            
        self._highlight_dates()
        QTimer.singleShot(50, self._process_visible_thumbnails)

    def _on_month_changed(self, year, month):
        first_item_of_month = None
        
        for dstr, (item, widget) in self.preview_widgets.items():
            dt = datetime.date.fromisoformat(dstr)
            if dt.year == year and dt.month == month:
                first_item_of_month = item
                break
                
        if first_item_of_month and not self._is_syncing:
            try:
                pos_top = QAbstractItemView.ScrollHint.PositionAtTop
            except AttributeError:
                pos_top = QAbstractItemView.PositionAtTop
            
            self.list_widget.scrollToItem(first_item_of_month, pos_top)
            
            self.list_widget.blockSignals(True)
            self.list_widget.setCurrentItem(first_item_of_month)
            self.list_widget.blockSignals(False)
            
        self._process_visible_thumbnails()

    def _process_visible_thumbnails(self):
        viewport_rect = self.list_widget.viewport().rect()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item and not item.isHidden():
                rect = self.list_widget.visualItemRect(item)
                if rect.isValid() and viewport_rect.intersects(rect):
                    dstr = item.data(self.user_role)
                    if isinstance(dstr, tuple): dstr = dstr[0]
                    widget = self.preview_widgets.get(dstr)
                    if isinstance(widget, tuple): widget = widget[1]
                    if widget and not widget.is_loaded:
                        self._load_thumbnail(widget)

    def _load_thumbnail(self, widget):
        if widget.thumb_url in self.plugin.thumbnail_cache:
            widget.set_pixmap(self.plugin.thumbnail_cache[widget.thumb_url])
            return

        req = QNetworkRequest(QUrl(widget.thumb_url))
        reply = self.nam.get(req)
        self.active_replies.add(reply)
        reply.finished.connect(lambda r=reply, w=widget: self._on_thumbnail_loaded(r, w))

    def _on_thumbnail_loaded(self, reply, widget):
        if reply in self.active_replies:
            self.active_replies.remove(reply)
            
        try:
            no_error = QNetworkReply.NetworkError.NoError
            cancel_error = QNetworkReply.NetworkError.OperationCanceledError
        except AttributeError:
            no_error = QNetworkReply.NoError
            cancel_error = QNetworkReply.OperationCanceledError

        if reply.error() == cancel_error:
            reply.deleteLater()
            return

        if reply.error() == no_error:
            img_data = reply.readAll()
            img = QImage.fromData(img_data)
            if not img.isNull():
                pix = QPixmap.fromImage(img)
                self.plugin.thumbnail_cache[widget.thumb_url] = pix
                widget.set_pixmap(pix)
            else:
                widget.lbl_thumb.setText("No Image")
        else:
            widget.lbl_thumb.setText("Error")
        reply.deleteLater()

    def _on_calendar_selection_changed(self):
        self._validate_selection()
        if self._is_syncing: return

        self._is_syncing = True
        selected_qdate = self.calendar.selectedDate()
        date_str = selected_qdate.toPyDate().isoformat()
        
        self.calendar.blockSignals(True)
        self.calendar.setCurrentPage(selected_qdate.year(), selected_qdate.month())
        self.calendar.blockSignals(False)

        if date_str in self.preview_widgets:
            item = self.preview_widgets[date_str][0]
            try:
                pos_center = QAbstractItemView.ScrollHint.PositionAtCenter
            except AttributeError:
                pos_center = QAbstractItemView.PositionAtCenter
            
            self.list_widget.scrollToItem(item, pos_center)
            self.list_widget.setCurrentItem(item)
            self._process_visible_thumbnails()
        self._is_syncing = False

    def _on_preview_changed(self, current, previous):
        if not current: return
        
        dstr = current.data(self.user_role)
        if isinstance(dstr, tuple): dstr = dstr[0]
        dt = datetime.date.fromisoformat(dstr)
        qdate = QDate(dt.year, dt.month, dt.day)
        
        if not self._is_syncing:
            self._is_syncing = True
            
            if self.blink_timer.isActive():
                self.blink_timer.stop()
                self._highlight_dates() 
                
            self.calendar.setSelectedDate(qdate) 
            
            self.blink_count = 0
            self.blink_date = qdate
            self.blink_timer.start(200)
            
            self._is_syncing = False

    def _do_blink(self):
        if self.blink_count >= 6: 
            self.blink_timer.stop()
            self._highlight_dates() 
            return
            
        fmt = QTextCharFormat()
        try:
            bold_weight = QFont.Weight.Bold 
        except AttributeError:
            bold_weight = QFont.Bold        
        fmt.setFontWeight(bold_weight)
        
        if self.blink_count % 2 == 0:
            fmt.setBackground(QColor("red")) 
            fmt.setForeground(QColor("white"))
        else:
            fmt.setBackground(QColor("yellow") if self.chk_cloudless.isChecked() else QColor("#E0E0E0"))
            fmt.setForeground(QColor("black"))
            
        self.calendar.setDateTextFormat(self.blink_date, fmt)
        self.blink_count += 1

    def _highlight_dates(self):
        if not self.all_urls: return
        fmt = QTextCharFormat()
        
        try:
            bold_weight = QFont.Weight.Bold 
        except AttributeError:
            bold_weight = QFont.Bold        

        if self.chk_cloudless.isChecked():
            fmt.setBackground(QColor("yellow"))
            fmt.setFontWeight(bold_weight)
        else:
            fmt.setBackground(QColor("#E0E0E0")) 
            fmt.setFontWeight(bold_weight)

        self.calendar.setDateTextFormat(QDate(), QTextCharFormat())
        for dstr, _ in self.all_urls:
            dt = datetime.date.fromisoformat(dstr)
            self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt)

    def _validate_selection(self):
        self.btn_ok.setEnabled(True)

    def get_selected_date(self):
        return self.calendar.selectedDate().toPyDate()

class Sentinel2Dates:
    def __init__(self, iface):
        self.iface = iface
        self.api = SatiladuAPI()
        self.layers = LayerManager(iface)
        self.thumbnail_cache = {}
        self.swipe_manager = None
        
        self.compare_mode_active = False
        self.compare_left_date = None
        self.compare_right_date = None

        self.action_today = None
        self.action_sun = None
        self.action_calendar = None
        self.action_snapshot = None
        self.action_prev = None
        self.action_next = None
        self.action_prev_10 = None
        self.action_next_10 = None
        self.action_gif = None
        
        self.combo_sensor = None
        self.combo_filter = None
        self.toolbar = None
        self._list_pos = 0

        self._filter_data = [
            ("RGB", 1, "harilik värvifoto"),
            ("NRG", 3, "valevärvipilt \"Lähi-infrapuna Punane Roheline\""),
            ("NDVI", 5, "normaliseeritud taimkatte indeks (NDVI)"),
            ("NGR", 7, "valevärvipilt \"Lähi-infrapuna Roheline Punane\""),
            ("NDPI", 9, "normaliseeritud veekogude indeks (NDPI)"),
            ("PNB", 11, "valevärvipilt \"NDPI Lähi-infrapuna Sinine\""),
            ("NGP", 13, "valevärvipilt \"Lähi-infrapuna Roheline NDPI\""),
            ("NDR", 15, "valevärvipilt \"Lähi-infrapuna NDVI Punane\""),
            ("PDB", 17, "valevärvipilt \"NDPI NDVI Sinine\""),
            ("NDN", 19, "valevärvipilt \"Lähi-infrapuna NDVI Lähi-infrapuna\""),
            ("PDN", 21, "valevärvipilt \"NDPI NDVI Lähi-infrapuna\""),
            ("NNR", 23, "valevärvipilt \"Lähi-infrapuna Lähi-Infrapuna Punane\""),
            ("DNP", 25, "valevärvipilt \"NDVI Lähi-infrapuna NDPI\"")
        ]

    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        def get_icon(filename):
            return QIcon(os.path.join(plugin_dir, filename))

        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_sensor.currentIndexChanged.connect(self._on_settings_changed)

        try:
            tooltip_role = Qt.ItemDataRole.ToolTipRole
        except AttributeError:
            tooltip_role = Qt.ToolTipRole

        self.combo_filter = QComboBox()
        for idx, (code, toode_id, desc) in enumerate(self._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, tooltip_role)
        self.combo_filter.currentIndexChanged.connect(self._on_settings_changed)

        self.action_today = QAction(get_icon("icon.png"), "Toggle WMS Layer", self.iface.mainWindow())
        self.action_today.setCheckable(True)
        self.action_today.toggled.connect(self._on_main_toggled)

        self.action_sun = QAction(get_icon("icon_sun.png"), "Pilvitu (Cloudless) filter", self.iface.mainWindow())
        self.action_sun.setCheckable(True)
        self.action_sun.toggled.connect(self._on_sun_toggled)

        self.action_calendar = QAction(get_icon("calendar.png"), "Select Date from Calendar", self.iface.mainWindow())
        self.action_calendar.triggered.connect(self._open_calendar_dialog)

        self.action_snapshot = QAction(get_icon("icon_snapshot.png"), "Snapshot current layer", self.iface.mainWindow())
        self.action_snapshot.triggered.connect(self._take_snapshot)

        self.action_prev = QAction(get_icon("icon_left.png"), "Prev", self.iface.mainWindow())
        self.action_prev.triggered.connect(lambda: self._open_relative_exact(-1))
        self.action_next = QAction(get_icon("icon_right.png"), "Next", self.iface.mainWindow())
        self.action_next.triggered.connect(lambda: self._open_relative_exact(1))
        self.action_prev_10 = QAction(get_icon("icon_left_10.png"), "Prev 10", self.iface.mainWindow())
        self.action_prev_10.triggered.connect(lambda: self._open_relative_exact(-10))
        self.action_next_10 = QAction(get_icon("icon_right_10.png"), "Next 10", self.iface.mainWindow())
        self.action_next_10.triggered.connect(lambda: self._open_relative_exact(10))

        self.action_gif = QAction("GIF", self.iface.mainWindow())
        self.action_gif.triggered.connect(self._open_gif_dialog)

        self.toolbar = self.iface.addToolBar("Satiladu Navigation")
        self.toolbar.setObjectName("Sentinel2DatesToolbar")
        self.toolbar.addWidget(self.combo_sensor)
        self.toolbar.addWidget(self.combo_filter)
        
        ordered_actions = [
            self.action_prev_10, self.action_prev, self.action_sun, self.action_calendar,
            self.action_today, self.action_snapshot, self.action_next, self.action_next_10, self.action_gif
        ]

        for act in ordered_actions:
            self.toolbar.addAction(act)
            self.iface.addPluginToMenu("&Sentinel WMS", act)

        self._update_ui_state()

    def unload(self):
        self.layers.remove_layer()
        self.layers.remove_compare_layers()
        if self.swipe_manager:
            self.swipe_manager._close()
        if self.toolbar: self.iface.mainWindow().removeToolBar(self.toolbar)

    def _sync_api_call(self):
        bbox = self.layers.get_canvas_bbox_latlon_str()
        sensor = self.combo_sensor.currentText()
        toode = self.combo_filter.currentData()
        pilvitu = self.action_sun.isChecked()
        return self.api.refresh_urls_list(bbox, sensor, toode, pilvitu)

    def _on_main_toggled(self, checked: bool):
        if checked:
            if not self.api.url_list: 
                self._sync_api_call()
            self._load_current_index()
        else:
            self.layers.remove_layer()
            if self.swipe_manager:
                self.swipe_manager._close()
            self.iface.mapCanvas().refresh()
            
        self._update_ui_state()

    def _on_sun_toggled(self, checked: bool):
        target_date_str = None
        if self.api.url_list and 0 <= self._list_pos < len(self.api.url_list):
            target_date_str = self.api.url_list[self._list_pos][0]

        if checked and not self.action_today.isChecked():
            self.action_today.blockSignals(True)
            self.action_today.setChecked(True)
            self.action_today.blockSignals(False)

        if self._sync_api_call():
            if target_date_str:
                target_dt = datetime.date.fromisoformat(target_date_str)
                best_idx, min_diff = 0, float('inf')
                for idx, (d_str, _) in enumerate(self.api.url_list):
                    diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
                    if diff == 0: best_idx = idx; break 
                    if diff < min_diff: min_diff = diff; best_idx = idx
                self._list_pos = best_idx
            else:
                self._list_pos = 0 

            if self.action_today.isChecked() and not self.swipe_manager:
                self._load_current_index()
                
        self._update_ui_state()

    def _on_settings_changed(self):
        if not self.action_today.isChecked(): return
        
        target_date_str = self.api.url_list[self._list_pos][0] if self.api.url_list and 0 <= self._list_pos < len(self.api.url_list) else None

        if self._sync_api_call():
            if target_date_str:
                target_dt = datetime.date.fromisoformat(target_date_str)
                best_idx, min_diff = 0, float('inf')
                for idx, (d_str, _) in enumerate(self.api.url_list):
                    diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
                    if diff == 0: best_idx = idx; break 
                    if diff < min_diff: min_diff = diff; best_idx = idx
                self._list_pos = best_idx
            
            if not self.swipe_manager:
                self._load_current_index()
        self._update_ui_state()

    def _load_current_index(self):
        if not self.api.url_list:
            self.action_today.setChecked(False)
            return
            
        self._list_pos = max(0, min(self._list_pos, len(self.api.url_list) - 1))
        date_str, url = self.api.url_list[self._list_pos]
        
        lyr = self.layers.make_layer(date_str, url, self.combo_sensor.currentText(), self.combo_filter.currentText())
        if lyr:
            self.layers.replace_layer(lyr)
        else:
            self.action_today.setChecked(False)

    def _open_relative_exact(self, delta: int):
        if not self.action_today.isChecked() or not self.api.url_list: return
        
        if self.swipe_manager:
            self.swipe_manager._close()
            
        new_pos = max(0, min(self._list_pos - delta, len(self.api.url_list) - 1))
        if new_pos != self._list_pos:
            self._list_pos = new_pos
            self._load_current_index()

    def _open_calendar_dialog(self):
        if not self.api.url_list and self.action_today.isChecked(): self._sync_api_call()
        dialog = CalendarSelectDialog(self)
        
        result = dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_()
        
        if result == 1: 
            target_pydate = dialog.get_selected_date()
            if not self.action_today.isChecked(): self.action_today.setChecked(True)
            if not self.api.url_list:
                if not self._sync_api_call(): return
                
            best_idx, min_diff = 0, float('inf')
            for idx, (d_str, _) in enumerate(self.api.url_list):
                diff = abs((datetime.date.fromisoformat(d_str) - target_pydate).days)
                if diff == 0: best_idx = idx; break
                if diff < min_diff: min_diff = diff; best_idx = idx
                    
            self._list_pos = best_idx
            
            if self.swipe_manager:
                self.swipe_manager._close()
            else:
                self._load_current_index()
                
        elif result == 2: 
            date_left = dialog.box_left.current_date
            date_right = dialog.box_right.current_date
            
            url_left = next((u for d, u in dialog.all_urls if d == date_left), None)
            url_right = next((u for d, u in dialog.all_urls if d == date_right), None)
            
            if url_left and url_right:
                self._start_compare_mode(date_left, url_left, date_right, url_right)
            else:
                self.log(f"Swipe Compare failed: Missing URL for {date_left} or {date_right}", Qgis.Warning)

    def _start_compare_mode(self, date_left, url_left, date_right, url_right):
        if not self.action_today.isChecked(): 
            self.action_today.blockSignals(True)
            self.action_today.setChecked(True)
            self.action_today.blockSignals(False)

        sensor = self.combo_sensor.currentText()
        filt = self.combo_filter.currentText()
        self.layers.setup_compare_layers(date_left, url_left, date_right, url_right, sensor, filt)
        
        if self.swipe_manager:
            self.swipe_manager._close()

        self.swipe_manager = CanvasSwipeManager(
            self, 
            self.iface.mapCanvas(), 
            self.layers.layer_right, 
            self.layers.layer_left,
            date_left, 
            date_right, 
            self._end_compare_mode
        )
        self._update_ui_state()

    def _end_compare_mode(self):
        self.layers.remove_compare_layers()
        self.swipe_manager = None
        if self.action_today.isChecked():
            self._load_current_index() 

    def _open_gif_dialog(self):
        dialog = GifGeneratorDialog(self)
        if hasattr(dialog, 'exec'):
            dialog.exec()
        else:
            dialog.exec_()

    def _take_snapshot(self):
        if self.layers.current_layer and self.api.url_list:
            date_str = self.api.url_list[self._list_pos][0]
            snap = QgsRasterLayer(self.layers.current_layer.source(), f"Snap-Satiladu_{self.combo_sensor.currentText()}_{self.combo_filter.currentText()}_{date_str}", "wms")
            if snap.isValid(): self.layers.add_layer_at_top(snap)

    def _set_secondary_actions_enabled(self, enabled: bool):
        for a in (self.action_prev, self.action_next, self.action_prev_10, self.action_next_10):
            if a: a.setEnabled(enabled)

    def _update_ui_state(self):
        if self.action_calendar: self.action_calendar.setEnabled(True)

        is_active = bool(self.action_today.isChecked() and self.api.url_list)
        self._set_secondary_actions_enabled(is_active)
        
        try:
            layer_exists = bool(self.layers.current_layer and QgsProject.instance().mapLayer(self.layers.current_layer.id()))
        except RuntimeError:
            layer_exists = False

        can_snap = bool((layer_exists or self.swipe_manager) and self.action_today.isChecked())
        if self.action_snapshot: self.action_snapshot.setEnabled(can_snap)
            
        can_gif = bool(is_active and self.action_sun.isChecked())
        if self.action_gif: self.action_gif.setEnabled(can_gif)