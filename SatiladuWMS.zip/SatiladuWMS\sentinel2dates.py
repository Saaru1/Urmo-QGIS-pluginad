# -*- coding: utf-8 -*-
"""
SatiladuWMS – Main QGIS Plugin Lifecycle Entry Point
"""
import os
from qgis.core import Qgis, QgsMessageLog
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QComboBox

from .satiladu_api import SatiladuAPI
from .layer_manager import LayerManager
from .thumbnail_worker import ThumbnailManager
from .ui import (
    ThumbnailDelegate,
    DarkCalendarDialog,
    SwipeHandle,
    HorizontalFilmstrip,
    InlineThumbnailPanel,
    SatiladuWorkspace,
)
from .ui.i18n import get_filter_data, get_current_lang

try:
    TOOLTIP_ROLE = Qt.ItemDataRole.ToolTipRole
except AttributeError:
    TOOLTIP_ROLE = Qt.ToolTipRole

# Re-export UI classes for full backwards compatibility
__all__ = [
    "Sentinel2Dates",
    "SatiladuWorkspace",
    "ThumbnailDelegate",
    "DarkCalendarDialog",
    "SwipeHandle",
    "HorizontalFilmstrip",
    "InlineThumbnailPanel",
]


class Sentinel2Dates:
    def __init__(self, iface):
        self.iface = iface
        self.api = SatiladuAPI()
        self.layers = LayerManager(iface)
        self.thumbnail_manager = ThumbnailManager(parent=iface.mainWindow(), max_concurrent=4, max_cache_size=150)
        self.workspace = None

        self.action_main = None
        self.toolbar = None

        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_filter = QComboBox()

        self._filter_data = get_filter_data(get_current_lang())

        for idx, (code, toode_id, desc) in enumerate(self._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, TOOLTIP_ROLE)

    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)

        def get_icon(filename):
            return QIcon(os.path.join(plugin_dir, filename))

        self.action_main = QAction(get_icon("icon.png"), "Toggle Satiladu Workspace", self.iface.mainWindow())
        self.action_main.setCheckable(True)
        self.action_main.toggled.connect(self._on_main_toggled)

        self.toolbar = self.iface.addToolBar("Satiladu")
        self.toolbar.setObjectName("SatiladuToolbar")
        self.toolbar.addAction(self.action_main)

        self.iface.addPluginToMenu("&Sentinel WMS", self.action_main)

    def unload(self):
        if self.workspace:
            self.workspace.destroy_workspace()
            self.workspace = None
        self.layers.remove_layer()
        self.layers.remove_compare_layers()
        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)

    def _on_main_toggled(self, checked: bool):
        if checked:
            if not self.api.url_list:
                bbox = self.layers.get_canvas_bbox_latlon_str()
                sensor = self.combo_sensor.currentText()
                toode = self.combo_filter.currentData()

                self.api.refresh_urls_async(bbox, sensor, toode, True, self._on_initial_fetch_done)
            else:
                dstr, url = self.api.url_list[0]
                self.workspace = SatiladuWorkspace(self, dstr, url)
        else:
            if self.workspace:
                self.workspace.destroy_workspace()
                self.workspace = None
            self.layers.remove_layer()
            self.layers.remove_compare_layers()
            self.iface.mapCanvas().refresh()

    def _on_initial_fetch_done(self, success, url_list, err):
        if success and url_list:
            dstr, url = url_list[0]
            self.workspace = SatiladuWorkspace(self, dstr, url)
        else:
            self.log(f"Could not load initial dates: {err}", Qgis.Critical)
            self.action_main.setChecked(False)
