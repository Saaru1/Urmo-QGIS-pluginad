# -*- coding: utf-8 -*-
from qgis.core import QgsSettings

TRANSLATIONS = {
    "ENG": {
        # Workspace Toolbar
        "mowing": "🚜 Mowing",
        "mowing_active": "🚜 Inspecting...",
        "tip_mowing": "Click a parcel or vector feature (e.g. WFS) to inspect vegetation profile and predict mowing timeframe.",
        "upscale": "✨ Upscale",
        "upscale_active": "⏳ Enhancing...",
        "connecting": "⏳ Connecting...",
        "upscale_failed": "AI Super-Resolution enhancement failed for the current extent.",
        "tip_upscale": "AI Super-Resolution on current satellite extent (DirectML GPU)",
        "timelapse": "🎞️ Timelapse",
        "tip_timelapse": "Generate animated GIF, WebP, or MP4 timelapse",
        "change_mask": "Δ Change Mask",
        "change_mask_computing": "⏳ Computing...",
        "change_mask_active": "Δ Mask Active",
        "tip_change_mask": "Compute calibrated change detection difference mask (forestry clearcuts, mowing, regrowth)",
        "calendar": "📅 Calendar",
        "tip_calendar": "Browse available cloudless dates in interactive calendar",
        "snapshot": "📸 Snapshot",
        "tip_snapshot": "Save current canvas view as high-resolution PNG image",
        "geotiff": "💾 GeoTIFF",
        "tip_geotiff": "Export georeferenced GeoTIFF at native 10m or AI upscaled 5m/2.5m",
        "refresh": "🔄 Refresh",
        "tip_refresh": "Refresh satellite layer from EstHub WMS",
        "compare": "Compare",
        "close_compare": "Close Compare",
        "tip_compare": "Toggle side-by-side split swipe comparison mode",
        "theme_toggle": "🌙 Theme",
        "tip_theme": "Toggle Dark / Light UI theme",
        "lang_toggle": "🌐 EST",
        "tip_lang": "Lülita eesti keelele (Switch to Estonian)",
        "tip_cloudless": "Toggle to filter thumbnail dates to cloudless skies only",
        "tip_minimize": "Minimize thumbnail panel",
        "tip_maximize": "Maximize thumbnail panel",

        # Mowing Inspector Dialog
        "inspector_title": "Parcel Profile & Mowing Detection Inspector",
        "pick_vector": "🔲 Pick Parcel on Canvas",
        "tip_pick_vector": "Return to canvas and click any parcel polygon or point to analyze",
        "load_selection": "📋 Load Active Selection",
        "parcel_label": "Parcel",
        "layer_label": "Layer",
        "area_label": "Area",
        "coords_label": "Coordinates",
        "sensor_label": "Sensor:",
        "spectral_product_label": "Spectral Product:",
        "veg_index_calibration": "Multi-spectral Vegetation Index Calibration",
        "custom_dates_label": "Custom:",
        "mowing_status_analyzing": "🚜 Analyzing multi-temporal vegetation trajectory for mowing events...",
        "mowing_status_unmowed": "🌾 Mowing Status: Continuous Vegetation Cover (Unmowed)",
        "mowing_desc_unmowed": "No significant biomass drop detected within the selected timeframe.",
        "mowing_detected_single": "🚜 Predicted Mowing Timeframe:",
        "mowing_detected_multi": "🚜 Mowing Cuts Detected:",
        "mowing_detected_low": "🚜 Predicted Mowing (Low Confidence / Partial Mowing):",
        "biomass_drop": "Biomass drop:",
        "confidence": "Confidence:",
        "conf_high": "High (Verified by post-cut suppression)",
        "conf_medium": "Medium (Clear biomass drop)",
        "conf_low": "Low (Subtle drop / Partial mowing)",
        "conf_high_short": "HIGH",
        "conf_med_short": "MEDIUM",
        "conf_low_short": "LOW",
        "mowed_badge": "🚜 MOWED",
        "searching_cloudless": "Querying EstHub: discovering cloudless Sentinel-2 acquisitions for parcel...",
        "no_samples": "No time-series samples available.",
        "could_not_sample": "Could not sample pixel reflectance",
        "wms_timeout": "WMS request timed out or returned no valid data for this position.",
        "select_vector_layer_msg": "Please select a vector polygon layer (e.g., PRIA agricultural parcels / WFS) in the QGIS Layers panel first.",
        "no_feature_selected_msg": "No feature is selected in layer. Select a parcel on the map canvas first.",
        "tip_chart": "💡 Tip: Zones indicate predicted mowing (🟢 Green = High, 🟡 Yellow = Medium, 🟠 Orange = Low confidence). Click any point to open that satellite date.",
        "export_csv": "Export CSV Report",
        "close": "Close",
        "timeframe": "Timeframe:",
        "preset_summer": "Summer (June–Aug)",
        "preset_ext": "Extended (June–Sept)",
        "preset_season": "Full Season (May–Oct)",
        "custom_dates": "Custom Range...",

        # Change Detection Dialog
        "change_title": "Calibrate Change Detection",
        "change_mode": "Target Analysis Mode:",
        "mode_loss": "🌲 Forest Clearcut & Canopy Loss (Red only)",
        "mode_gain": "🌱 Vegetation Regrowth & Greening (Green only)",
        "mode_both": "🔄 Bidirectional (Loss = Red, Gain = Green)",
        "sensitivity": "Sensitivity Threshold:",
        "recommended_clearcut": "(Recommended for Clearcuts)",
        "filter_speckle": "Filter noise & isolated speckles (Clean patches)",
        "apply_mask": "Apply Change Mask",
        "cancel": "Cancel",

        # Change Mask On-Canvas HUD
        "hud_title": "Change Mask Control",
        "hud_show": "Show Mask",
        "hud_opacity": "Opacity:",
        "hud_settings": "⚙️ Recalibrate",
        "hud_remove": "❌ Remove",

        # Calendar Dialog
        "calendar_title": "Select Date",
        "cloudless_only": "Cloudless only",
        "search_date_placeholder": "Search date (e.g. 10.)...",
        "archive_depth": "Archive Depth:",
        "depth_2y": "2 Years",
        "depth_5y": "5 Years",
        "depth_all": "Full Archive",
        "jump_to_date": "Jump to Date",

        # GeoTIFF Dialog
        "geotiff_title": "Export Georeferenced GeoTIFF",
        "exporting_info": "Exporting:",
        "target_res": "Target Resolution:",
        "native_10m": "Native (10 m)",
        "ai_2x": "✨ 2x AI Enhanced (5 m)",
        "ai_4x": "✨ 4x AI Enhanced (2.5 m)",
        "add_to_project": "Add exported GeoTIFF layer to current project",
        "export_btn": "Export GeoTIFF...",
        "save_geotiff_title": "Save GeoTIFF",
        "model_missing_title": "Model Missing",
        "model_missing_msg": "The required model '{model_name}' was not found. Please upscale once on the canvas first to download it.",
        "url_missing_title": "URL Missing",
        "url_missing_msg": "Could not resolve WMS URL for the selected date.",
        "exporting_bg": "Exporting GeoTIFF in background...",
        "cancel_export": "Cancel Export",
        "export_complete_title": "Export Complete",
        "export_complete_msg": "GeoTIFF successfully exported to:",

        # Timelapse Dialog
        "timelapse_title": "Generate Timelapse Animation",
        "select_dates_title": "Select Timelapse Dates",
        "select_dates_desc": "Select dates to include based on previews (newest to oldest):",
        "select_all": "Select All",
        "deselect_all": "Deselect All",
        "ok": "OK",
        "start_date": "Start:",
        "end_date": "End:",
        "format": "Format:",
        "speed": "Speed:",
        "speed_slow": "Slow",
        "speed_normal": "Normal",
        "speed_fast": "Fast",
        "generate": "Generate Timelapse",
        "play": "▶ Play",
        "pause": "⏸ Pause",
        "save_anim": "Save to PC",
        "save_to_pc": "Save to PC",
        "select_dates": "Select Dates...",
        "btn_select_dates": "Select Dates...",
        "smooth_transitions": "Smooth transitions",
        "show_layers": "Show layers",
        "scale_bar": "Scale bar",
        "north_arrow": "North arrow",
        "ai_upscale_chk": "✨ AI Upscale",
        "tip_ai_upscale": "Enhance frames using neural super-resolution (ONNX DirectML)",
        "tip_upscale_model": "Select ONNX model for upscaling GIF frames",
        "stop": "⏹ Stop",
        "stopped_by_user": "Timelapse generation stopped by user.",
        "no_dates_selected": "No dates selected in this range.",
        "no_dates_title": "No Dates",
        "no_dates_msg": "No available dates found within the selected date range.",
        "missing_deps_title": "Missing Dependencies",
        "missing_deps_msg": "AI Upscaling requires 'onnxruntime-directml'. Please run Upscale once in the main toolbar to install it.",
        "model_not_found_msg": "The model file was not found:\n{model_path}\nPlease download it from the main window first.",
        "loading": "Loading...",
        "timelapse_initial_hint": "Select dates and click Generate.\n(Animation generates in background, no freezing!)",
        "generating": "Generating timelapse...",
        "saving": "Saving...",
        "save_success_title": "Saved Successfully",
        "save_success_msg": "Timelapse saved to:",
        "tip_sensor_s2": "Sentinel-2 (ESA) — 10 m resolution (RGB, NIR), revisit rate ~2-3 days.",
        "tip_sensor_l8": "Landsat-8 (USGS/NASA) — 30 m resolution (15 m panchromatic), revisit rate 16 days.",
        "tip_filter_combo": "Satellite visualization composite filter & indices. Hover over items to see descriptions and primary use cases.",
    },

    "EST": {
        # Workspace Toolbar
        "mowing": "🚜 Niitmine",
        "mowing_active": "🚜 Tuvastamine...",
        "tip_mowing": "Klõpsa kaardil või vali vektorobjekt (nt WFS), et analüüsida taimkatte profiili ja tuvastada niitmist.",
        "upscale": "✨ AI Suurendus",
        "upscale_active": "⏳ Töötlemine...",
        "connecting": "⏳ Ühendamine...",
        "upscale_failed": "AI suurendamine ebaõnnestus antud vaates.",
        "tip_upscale": "AI super-resolutsioon satelliidipildil (DirectML GPU)",
        "timelapse": "🎞️ Aegvõte",
        "tip_timelapse": "Loo animeeritud GIF, WebP või MP4 aegvõte",
        "change_mask": "Δ Muutuste mask",
        "change_mask_computing": "⏳ Arvutamine...",
        "change_mask_active": "Δ Mask aktiivne",
        "tip_change_mask": "Arvuta kalibreeritud maakatte muutuste mask (lageraied, niitmine, taastumine)",
        "calendar": "📅 Kalender",
        "tip_calendar": "Sirvi pilveta kuupäevi interaktiivses kalendris",
        "snapshot": "📸 Kuvatõmmis",
        "tip_snapshot": "Salvesta hetke kaardivaade kõrge resolutsiooniga PNG pildina",
        "geotiff": "💾 GeoTIFF",
        "tip_geotiff": "Ekspordi georefereeritud GeoTIFF 10m või AI abil 5m/2.5m lahutusega",
        "refresh": "🔄 Värskenda",
        "tip_refresh": "Värskenda satelliidikiht EstHub WMS-ist",
        "compare": "Võrdle",
        "close_compare": "Sulge võrdlus",
        "tip_compare": "Lülita sisse kahe kuupäeva võrdlusrežiim (poolitatav ekraan)",
        "theme_toggle": "🌙 Teema",
        "tip_theme": "Lülita Tume / Hele kasutajaliides",
        "lang_toggle": "🌐 ENG",
        "tip_lang": "Switch to English (Lülita inglise keelele)",
        "tip_cloudless": "Filtreeri ainult pilvitud kuupäevad",
        "tip_minimize": "Minimeeri pisipiltide paneel",
        "tip_maximize": "Taasta pisipiltide paneel",

        # Mowing Inspector Dialog
        "inspector_title": "Põllu profiil ja niitmise tuvastamine",
        "pick_vector": "🔲 Vali põld kaardilt",
        "tip_pick_vector": "Mine kaardile ja klõpsa analüüsitaval põllul või punktil",
        "load_selection": "📋 Laadi valitud objekt",
        "parcel_label": "Põld / Kataster",
        "layer_label": "Kiht",
        "area_label": "Pindala",
        "coords_label": "Koordinaadid",
        "sensor_label": "Sensor:",
        "spectral_product_label": "Spektraaltoode:",
        "veg_index_calibration": "Multispektraalne taimkatteindeksi kalibreerimine",
        "custom_dates_label": "Määra ise:",
        "mowing_status_analyzing": "🚜 Analüüsin taimkatte aegrida niitmise tuvastamiseks...",
        "mowing_status_unmowed": "🌾 Niitmise staatus: pidev taimkate (niitmata)",
        "mowing_desc_unmowed": "Valitud ajavahemikul olulist taimkatte biomassi langust ei tuvastatud.",
        "mowing_detected_single": "🚜 Prognoositud niitmise ajavahemik:",
        "mowing_detected_multi": "🚜 Tuvastatud niitmiskorrad:",
        "mowing_detected_low": "🚜 Prognoositud niitmine (madal usaldusväärsus / osaline):",
        "biomass_drop": "Biomassi langus:",
        "confidence": "Usaldusväärsus:",
        "conf_high": "Kõrge (kinnitatud madala taseme püsimisega)",
        "conf_medium": "Keskmine (selge biomassi langus)",
        "conf_low": "Madal (väike langus / osaline niitmine)",
        "conf_high_short": "KÕRGE",
        "conf_med_short": "KESKMINE",
        "conf_low_short": "MADAL",
        "mowed_badge": "🚜 NIIDETUD",
        "searching_cloudless": "Päring EstHubist: otsin maatüki pilvituid Sentinel-2 vaatlusi...",
        "no_samples": "Aegrea andmed puuduvad või pole valitud punkti kohta saadaval.",
        "could_not_sample": "Piksliväärtuste pärimine ebaõnnestus",
        "wms_timeout": "WMS päring aegus või ei tagastanud selle asukoha kohta kehtivaid andmeid.",
        "select_vector_layer_msg": "Palun vali esmalt QGIS kihtide paneelis polügoonidega vektorikiht (nt PRIA põllumassiivid / WFS).",
        "no_feature_selected_msg": "Kihis pole ühtegi objekti valitud. Vali esmalt kaardil põllu objekt.",
        "tip_chart": "💡 Vihje: Tsoonid tähistavad prognoositud niitmist (🟢 Roheline = kõrge, 🟡 Kollane = keskmine, 🟠 Oranž = madal usaldusväärsus). Klõpsa punktil, et avada vastav satelliidipilt.",
        "export_csv": "Ekspordi CSV aruanne",
        "close": "Sulge",
        "timeframe": "Ajavahemik:",
        "preset_summer": "Suvi (Juuni–August)",
        "preset_ext": "Pikendatud (Juuni–Sept)",
        "preset_season": "Kogu hooaeg (Mai–Okt)",
        "custom_dates": "Määra ise...",

        # Change Detection Dialog
        "change_title": "Kalibreeri muutuste tuvastamist",
        "change_mode": "Analüüsi tüüp:",
        "mode_loss": "🌲 Metsa lageraie ja võra kadu (ainult punane)",
        "mode_gain": "🌱 Taimkatte taastumine ja rohenemine (ainult roheline)",
        "mode_both": "🔄 Mõlemasuunaline (Kadu = Punane, Kasv = Roheline)",
        "sensitivity": "Tundlikkuse lävi:",
        "recommended_clearcut": "(Soovitatav lageraiete tuvastamiseks)",
        "filter_speckle": "Filtreeri müra ja üksikud pikslid (puhtad laigud)",
        "apply_mask": "Rakenda muutuste mask",
        "cancel": "Loobu",

        # Change Mask On-Canvas HUD
        "hud_title": "Muutuste maski juhtpaneel",
        "hud_show": "Kuva mask",
        "hud_opacity": "Läbipaistvus:",
        "hud_settings": "⚙️ Muuda seadeid",
        "hud_remove": "❌ Eemalda",

        # Calendar Dialog
        "calendar_title": "Vali kuupäev",
        "cloudless_only": "Ainult pilvitu",
        "search_date_placeholder": "Otsi kuupäeva (nt 10.)...",
        "archive_depth": "Arhiivi sügavus:",
        "depth_2y": "2 aastat",
        "depth_5y": "5 aastat",
        "depth_all": "Kogu arhiiv",
        "jump_to_date": "Hüppa kuupäevale",

        # GeoTIFF Dialog
        "geotiff_title": "Ekspordi georefereeritud GeoTIFF",
        "exporting_info": "Eksporditav:",
        "target_res": "Lahutusvõime:",
        "native_10m": "Algne (10 m)",
        "ai_2x": "✨ 2x AI Täiustatud (5 m)",
        "ai_4x": "✨ 4x AI Täiustatud (2.5 m)",
        "add_to_project": "Lisa eksporditud GeoTIFF kiht aktiivsesse projekti",
        "export_btn": "Ekspordi GeoTIFF...",
        "save_geotiff_title": "Salvesta GeoTIFF",
        "model_missing_title": "Mudel puudub",
        "model_missing_msg": "Vajalikku mudelit '{model_name}' ei leitud. Palun tee esmalt üks suurendus kaardil, et mudel alla laadida.",
        "url_missing_title": "URL puudub",
        "url_missing_msg": "Valitud kuupäevale vastavat WMS URL-i ei leitud.",
        "exporting_bg": "Ekspordin GeoTIFF faili taustal...",
        "cancel_export": "Tühista eksport",
        "export_complete_title": "Eksport edukalt lõpetatud",
        "export_complete_msg": "GeoTIFF edukalt salvestatud faili:",

        # Timelapse Dialog
        "timelapse_title": "Loo aegvõtte animatsioon",
        "select_dates_title": "Vali aegvõtte kuupäevad",
        "select_dates_desc": "Vali kaasatavad kuupäevad eelvaadete põhjal (uuemast vanemani):",
        "select_all": "Vali kõik",
        "deselect_all": "Tühista valik",
        "ok": "Sobib",
        "start_date": "Algus:",
        "end_date": "Lõpp:",
        "format": "Formaat:",
        "speed": "Kiirus:",
        "speed_slow": "Aeglane",
        "speed_normal": "Tavaline",
        "speed_fast": "Kiire",
        "generate": "Loo aegvõte",
        "play": "▶ Mängi",
        "pause": "⏸ Paus",
        "save_anim": "Salvesta arvutisse",
        "save_to_pc": "Salvesta arvutisse",
        "select_dates": "Vali kuupäevad...",
        "btn_select_dates": "Vali kuupäevad...",
        "smooth_transitions": "Sujuvad üleminekud",
        "show_layers": "Kuva kihid",
        "scale_bar": "Mõõtkavariba",
        "north_arrow": "Põhjanool",
        "ai_upscale_chk": "✨ AI Suurendus",
        "tip_ai_upscale": "Paranda kaadreid tehisintellekti super-resolutsiooniga (ONNX DirectML)",
        "tip_upscale_model": "Vali kaadrite suurendamiseks ONNX mudel",
        "stop": "⏹ Peata",
        "stopped_by_user": "Aegvõtte genereerimine peatatud kasutaja poolt.",
        "no_dates_selected": "Selles vahemikus pole ühtegi kuupäeva valitud.",
        "no_dates_title": "Kuupäevi ei leitud",
        "no_dates_msg": "Valitud ajavahemikus ei leitud ühtegi kuupäeva.",
        "missing_deps_title": "Puuduvad teegid",
        "missing_deps_msg": "AI suurendus vajab 'onnxruntime-directml' teeki. Palun käivita üks kord suurendus peamenüüst selle paigaldamiseks.",
        "model_not_found_msg": "Mudeli faili ei leitud:\n{model_path}\nPalun laadi see esmalt alla põhiaknast.",
        "loading": "Laadin...",
        "timelapse_initial_hint": "Vali kuupäevad ja klõpsa 'Loo aegvõte'.\n(Aegvõte valmib taustal ilma programmi hangumiseta!)",
        "generating": "Genereerin aegvõtet...",
        "saving": "Salvestan...",
        "save_success_title": "Edukalt salvestatud",
        "save_success_msg": "Aegvõte salvestatud faili:",
        "tip_sensor_s2": "Sentinel-2 (ESA) — 10 m lahutusvõime (RGB, NIR), kordusvaatlus ~2-3 päeva tagant.",
        "tip_sensor_l8": "Landsat-8 (USGS/NASA) — 30 m lahutusvõime (15 m pankromaatiline), kordusvaatlus 16 päeva tagant.",
        "tip_filter_combo": "Satelliidipildi visualiseerimise valevärvipildid ja indeksid. Liigu hiirega filtritele, et näha kirjeldust ja peamist kasutusala.",
    }
}

FILTER_METADATA = {
    "RGB": {
        "toode_id": 1,
        "EST": {
            "name": "Harilik värvifoto (looduslähedane vaade)",
            "use_case": "Maastiku üldine visuaalne kontroll, pilvisuse ja lumikatte tuvastamine, teede ja hoonestuse kaardistus."
        },
        "ENG": {
            "name": "True Color (Natural color composite)",
            "use_case": "General visual landscape inspection, cloud and snow cover assessment, roads and infrastructure."
        }
    },
    "NRG": {
        "toode_id": 3,
        "EST": {
            "name": "Traditsiooniline valevärvipilt (Lähi-infrapuna + Punane + Roheline)",
            "use_case": "Taimkatte elujõud ja biomass (elujõuline taimkate on erkpunane), okas- ja lehtmetsa eristamine, talvine lumikate ja jää."
        },
        "ENG": {
            "name": "Color Infrared / CIR (Near-Infrared + Red + Green)",
            "use_case": "Vegetation health and vigor (healthy flora appears bright red), separating coniferous vs deciduous forests, snow and ice mapping."
        }
    },
    "NDVI": {
        "toode_id": 5,
        "EST": {
            "name": "Normaliseeritud taimkatte indeks: (NIR - Punane) / (NIR + Punane)",
            "use_case": "Taimestiku rohelus ja biomassi tihedus, saagikuse hindamine, niitmise tuvastamine rohumaadel ning metsaraiete seire."
        },
        "ENG": {
            "name": "Normalized Difference Vegetation Index: (NIR - Red) / (NIR + Red)",
            "use_case": "Crop growth monitoring, green biomass density, grassland mowing detection, and forest clear-cut tracking."
        }
    },
    "NGR": {
        "toode_id": 7,
        "EST": {
            "name": "Metsanduslik valevärvipilt (Lähi-infrapuna + Roheline + Punane)",
            "use_case": "Metsamassiivide ja puuliikide analüüs, noore ja vana metsa kontrastne eraldamine suvisel perioodil."
        },
        "ENG": {
            "name": "Forestry False Color (Near-Infrared + Green + Red)",
            "use_case": "Forest canopy assessment, tree species differentiation, contrasting young regrowth and mature stands."
        }
    },
    "NDPI": {
        "toode_id": 9,
        "EST": {
            "name": "Veekogude ja tiikide indeks: (SWIR - Roheline) / (SWIR + Roheline)",
            "use_case": "Madalate veekogude, tiikide, kraavide, üleujutusalade ja märgalade täpne piiritlemine läbi tiheda taimkatte."
        },
        "ENG": {
            "name": "Normalized Difference Pond Index: (SWIR - Green) / (SWIR + Green)",
            "use_case": "Accurate delineation of small water bodies, ponds, drainage ditches, flood extents, and wetland shorelines."
        }
    },
    "PNB": {
        "toode_id": 11,
        "EST": {
            "name": "Valevärvipilt (NDPI + Lähi-infrapuna + Sinine)",
            "use_case": "Vee ja kuiva maapinna kontrastne eraldamine; märgade mudaste rannikualade, lompide ja kraavivõrgu tuvastamine."
        },
        "ENG": {
            "name": "Water-Land Boundary (NDPI + NIR + Blue)",
            "use_case": "Sharp water-to-land boundary separation; mapping muddy shores, shallow puddles, and drainage networks."
        }
    },
    "NGP": {
        "toode_id": 13,
        "EST": {
            "name": "Valevärvipilt (Lähi-infrapuna + Roheline + NDPI)",
            "use_case": "Rannikuroostike, lammialade, madalsoode ja turbamaade niiskustingimuste ning veerežiimi dünaamika jälgimine."
        },
        "ENG": {
            "name": "Wetland Dynamics (NIR + Green + NDPI)",
            "use_case": "Monitoring coastal reedbeds, floodplain inundation, fens, and peatland hydrological dynamics."
        }
    },
    "NDR": {
        "toode_id": 15,
        "EST": {
            "name": "Valevärvipilt (Lähi-infrapuna + NDVI + Punane)",
            "use_case": "Põllukultuuride biomassi ja klorofüllisisalduse kontrastne analüüs, põllusiseste kasvuerinevuste ja stressi tuvastamine."
        },
        "ENG": {
            "name": "Crop Vitality Contrast (NIR + NDVI + Red)",
            "use_case": "Accentuating crop chlorophyll and biomass variations, detecting crop stress and within-field variability."
        }
    },
    "PDB": {
        "toode_id": 17,
        "EST": {
            "name": "Valevärvipilt (NDPI + NDVI + Sinine)",
            "use_case": "Pinnase niiskuse ja taimkatte üheaegne hindamine; dreenirikete ja vettinud põllulaikude kiire avastamine."
        },
        "ENG": {
            "name": "Moisture & Vigor (NDPI + NDVI + Blue)",
            "use_case": "Simultaneous evaluation of surface moisture and vegetation vigor; identifying sub-surface tile drainage failures and waterlogged crop patches."
        }
    },
    "NDN": {
        "toode_id": 19,
        "EST": {
            "name": "Valevärvipilt (Lähi-infrapuna + NDVI + Lähi-infrapuna)",
            "use_case": "Taimkatte struktuuri ja võrastiku tiheduse spetsiifiline esiletoomine ilma maapinna taustapeegelduse häireteta."
        },
        "ENG": {
            "name": "Canopy Structure (NIR + NDVI + NIR)",
            "use_case": "Emphasizing canopy structure and vertical foliage density while suppressing background soil reflectance."
        }
    },
    "PDN": {
        "toode_id": 21,
        "EST": {
            "name": "Valevärvipilt (NDPI + NDVI + Lähi-infrapuna)",
            "use_case": "Kompleksne ökosüsteemianalüüs: ühendab veeseisu (NDPI), biomassi elujõu (NDVI) ja infrapunapeegelduse (NIR)."
        },
        "ENG": {
            "name": "Multi-Spectral Ecosystem (NDPI + NDVI + NIR)",
            "use_case": "Comprehensive ecosystem analysis integrating surface water, biomass vitality, and near-infrared reflectance."
        }
    },
    "NNR": {
        "toode_id": 23,
        "EST": {
            "name": "Valevärvipilt (Lähi-infrapuna + Lähi-infrapuna + Punane)",
            "use_case": "Hiljutiste metsaraiete, maapinna kahjustuste, pinnasetööde, tormimurdude ja põlengute kiire tuvastamine."
        },
        "ENG": {
            "name": "Disturbance & Bare Soil (NIR + NIR + Red)",
            "use_case": "Rapid detection of recent clear-cuts, storm windthrow, excavation, wildfires, and exposed bare ground."
        }
    },
    "DNP": {
        "toode_id": 25,
        "EST": {
            "name": "Valevärvipilt (NDVI + Lähi-infrapuna + NDPI)",
            "use_case": "Maakatete kiirklassifitseerimine: eristab kontrastsete värvidega taimestiku (roheline), avavee (sinine) ja tehispinnad."
        },
        "ENG": {
            "name": "Land Cover Classification (NDVI + NIR + NDPI)",
            "use_case": "Quick visual classification separating dense vegetation (green), open water (blue), and built-up/bare surfaces."
        }
    }
}

SENSOR_METADATA = {
    "Sentinel-2": {
        "EST": "Sentinel-2 (ESA) — 10 m lahutusvõime (RGB, NIR), kordusvaatlus ~2-3 päeva tagant.",
        "ENG": "Sentinel-2 (ESA) — 10 m resolution (RGB, NIR), revisit rate ~2-3 days."
    },
    "Landsat-8": {
        "EST": "Landsat-8 (USGS/NASA) — 30 m lahutusvõime (15 m pankromaatiline), kordusvaatlus 16 päeva tagant.",
        "ENG": "Landsat-8 (USGS/NASA) — 30 m resolution (15 m panchromatic), revisit rate 16 days."
    }
}

def get_filter_tooltip(code, lang=None):
    if lang is None:
        lang = get_current_lang()
    info = FILTER_METADATA.get(code)
    if not info:
        return code
    loc = info.get(lang, info.get("EST", {}))
    name = loc.get("name", code)
    use_case = loc.get("use_case", "")
    header = "Peamine kasutusala" if lang == "EST" else "Primary use-case"
    if use_case:
        return f"{code} — {name}\n• {header}: {use_case}"
    return f"{code} — {name}"

def get_filter_data(lang=None):
    if lang is None:
        lang = get_current_lang()
    data = []
    for code, info in FILTER_METADATA.items():
        toode_id = info["toode_id"]
        tip = get_filter_tooltip(code, lang)
        data.append((code, toode_id, tip))
    return data

def get_sensor_tooltip(sensor_name, lang=None):
    if lang is None:
        lang = get_current_lang()
    s = SENSOR_METADATA.get(sensor_name, {})
    return s.get(lang, s.get("EST", sensor_name))

_current_lang = None

def get_current_lang():
    global _current_lang
    if _current_lang is None:
        settings = QgsSettings()
        _current_lang = settings.value("satiladu/language", "EST")
        if _current_lang not in ("ENG", "EST"):
            _current_lang = "EST"
    return _current_lang

def set_current_lang(lang):
    global _current_lang
    if lang in ("ENG", "EST"):
        _current_lang = lang
        settings = QgsSettings()
        settings.setValue("satiladu/language", lang)

def tr(key, lang=None):
    if lang is None:
        lang = get_current_lang()
    table = TRANSLATIONS.get(lang, TRANSLATIONS["EST"])
    if key in table:
        return table[key]
    # Fallback to English if not found
    return TRANSLATIONS["ENG"].get(key, key)
