# -*- coding: utf-8 -*-
import re
import datetime
from urllib.parse import quote
from urllib.request import urlopen, Request
from qgis.core import QgsMessageLog, Qgis, QgsTask, QgsApplication, QgsBlockingNetworkRequest
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

class ApiScraperTask(QgsTask):
    def __init__(self, url, callback):
        super().__init__("Fetching ESTHub Dates", QgsTask.CanCancel)
        self.url = url
        self.callback = callback
        self.url_list = []
        self.success = False
        self.error_msg = ""

    def run(self):
        try:
            if self.isCanceled():
                return False

            html = ""
            # Priority 1: Use QGIS Blocking Network Request (respects QGIS proxy, SSL, and auth settings)
            try:
                req = QNetworkRequest(QUrl(self.url))
                user_agent = getattr(QgsApplication, "defaultUserAgent", lambda: "Mozilla/5.0 (QGIS)")()
                try:
                    req.setHeader(QNetworkRequest.KnownHeaders.UserAgentHeader, user_agent)
                except AttributeError:
                    req.setHeader(QNetworkRequest.UserAgentHeader, user_agent)

                bnr = QgsBlockingNetworkRequest()
                err = bnr.get(req)
                
                try:
                    no_error = QgsBlockingNetworkRequest.ErrorCode.NoError
                except AttributeError:
                    no_error = 0

                if err == no_error and bnr.reply():
                    html = bytes(bnr.reply().content()).decode("utf-8", errors="replace")
                else:
                    self.error_msg = bnr.errorMessage() or f"Network error code: {err}"
            except Exception as net_ex:
                self.error_msg = str(net_ex)

            # Priority 2: Fallback to standard urlopen if QgsBlockingNetworkRequest didn't get html
            if not html:
                try:
                    req_py = Request(self.url, headers={'User-Agent': 'Mozilla/5.0 (QGIS Satiladu)'})
                    with urlopen(req_py, timeout=15) as resp:
                        if self.isCanceled():
                            return False
                        html = resp.read().decode("utf-8", errors="replace")
                except Exception as py_ex:
                    if not self.error_msg:
                        self.error_msg = str(py_ex)

            if not html:
                return False

            if self.isCanceled():
                return False

            url_re = re.compile(r"(https://teenus\.maaamet\.ee/ows/wms-[\w\-]+\?date=(\d{4}-\d{2}-\d{2}))")
            matches = url_re.findall(html)

            if matches:
                unique_urls = {date_str: full_url for full_url, date_str in matches}
                sorted_dates = sorted(unique_urls.keys(), reverse=True)
                self.url_list = [(d, unique_urls[d]) for d in sorted_dates]
            else:
                self.url_list = []

            self.success = True
            return True
        except Exception as e:
            self.error_msg = str(e)
            return False

    def finished(self, result):
        self.callback(self.success, self.url_list, self.error_msg)


class SatiladuAPI:
    def __init__(self):
        self.url_list = []
        self._tasks = []  # Keep a Python reference to prevent garbage collection

    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def _build_url(self, bbox_str, sensor_name, toode_id, pilvitu_bool, start_date=None, end_date=None, years_back=5):
        satelliit = "L8" if sensor_name == "Landsat-8" else "S2"
        pilvitu = 1 if pilvitu_bool else 0

        if not end_date:
            end_date = datetime.date.today()
        elif isinstance(end_date, str):
            end_date = datetime.date.fromisoformat(end_date)

        if not start_date:
            start_date = end_date - datetime.timedelta(days=int(years_back * 365.25))
        elif isinstance(start_date, str):
            start_date = datetime.date.fromisoformat(start_date)

        return (f"https://esthub.maaruum.ee/index.php?lang_id=1&page_id=1"
                f"&kuupaev_algus={start_date.isoformat()}&kuupaev_lopp={end_date.isoformat()}"
                f"&toode={toode_id}&pilvitu={pilvitu}&satelliit={satelliit}&bbox={quote(bbox_str, safe='')}")

    def refresh_urls_list(self, bbox_str, sensor_name, toode_id, pilvitu_bool, start_date=None, end_date=None, years_back=5):
        """Synchronous fetch (used safely in blocking dialogs)"""
        if not bbox_str:
            return False
        url = self._build_url(bbox_str, sensor_name, toode_id, pilvitu_bool, start_date=start_date, end_date=end_date, years_back=years_back)
        self.log(f"Scraping ESTHub index (Sync):\n{url}")

        task = ApiScraperTask(url, lambda s, u, e: None)
        task.run()
        if task.success:
            self.url_list = task.url_list
        else:
            self.log(f"ESTHub scrape failed: {task.error_msg}", Qgis.Critical)
            self.url_list = []
        return task.success

    def refresh_urls_async(self, bbox_str, sensor_name, toode_id, pilvitu_bool, callback, start_date=None, end_date=None, years_back=5):
        """Asynchronous fetch executing on a background QgsTask worker"""
        if not bbox_str:
            callback(False, [], "No Canvas BBOX")
            return

        url = self._build_url(bbox_str, sensor_name, toode_id, pilvitu_bool, start_date=start_date, end_date=end_date, years_back=years_back)
        self.log(f"Scraping ESTHub index (Async):\n{url}")

        task = None
        def internal_cb(success, url_list, err):
            if task in self._tasks:
                self._tasks.remove(task)  # Clean up reference once finished

            if success:
                self.url_list = url_list
            else:
                self.log(f"ESTHub scrape failed: {err}", Qgis.Critical)
                self.url_list = []

            callback(success, url_list, err)

        task = ApiScraperTask(url, internal_cb)
        self._tasks.append(task)
        QgsApplication.taskManager().addTask(task)
