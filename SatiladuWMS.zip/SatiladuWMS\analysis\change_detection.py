# -*- coding: utf-8 -*-
import os
import io
import tempfile
import urllib.request
import numpy as np
from PIL import Image, ImageFilter

from qgis.core import (
    QgsTask, QgsProject, QgsRasterLayer, QgsMessageLog, Qgis,
    QgsCoordinateReferenceSystem, QgsBlockingNetworkRequest
)
from qgis.PyQt.QtCore import Qt, QUrl, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QSlider, QCheckBox, QMessageBox
)
from qgis.PyQt.QtNetwork import QNetworkRequest
from ..ui.i18n import tr
from ..ui.theme_manager import get_theme_styles


def _fetch_tile_bytes(url):
    try:
        bnr = QgsBlockingNetworkRequest()
        req = QNetworkRequest(QUrl(url))
        err = bnr.get(req)
        try:
            no_err = QgsBlockingNetworkRequest.ErrorCode.NoError
        except AttributeError:
            no_err = 0
        if err == no_err and bnr.reply():
            return bytes(bnr.reply().content())
    except Exception:
        pass

    req_py = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (QGIS Satiladu)'})
    with urllib.request.urlopen(req_py, timeout=15) as resp:
        return resp.read()


class ChangeDetectionTask(QgsTask):
    def __init__(self, bbox_3301, width, height, url_left, url_right, dstr_left, dstr_right,
                 sensor, filt, threshold_pct=25, mode="loss_only", min_patch_clean=True, callback=None):
        super().__init__(f"Computing Calibrated Change Mask ({dstr_left} vs {dstr_right})", QgsTask.CanCancel)
        self.bbox_3301 = bbox_3301
        self.width = width
        self.height = height
        self.url_left = url_left
        self.url_right = url_right
        self.dstr_left = dstr_left
        self.dstr_right = dstr_right
        self.sensor = sensor
        self.filt = filt
        self.threshold = float(threshold_pct) / 100.0  # e.g. 0.25
        self.mode = mode  # 'loss_only', 'gain_only', 'bidirectional'
        self.min_patch_clean = min_patch_clean
        self.callback = callback

        self.temp_dir = tempfile.mkdtemp(prefix="satiladu_change_")
        self.out_tif = os.path.join(self.temp_dir, "change_delta.tif")

    def run(self):
        try:
            param_l = self.url_left.split('?')[0].split('wms-')[-1].replace('-', '_')
            param_r = self.url_right.split('?')[0].split('wms-')[-1].replace('-', '_')

            getmap_l = (f"{self.url_left}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                        f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={self.width}&HEIGHT={self.height}"
                        f"&LAYERS={param_l}&STYLES=&FORMAT=image/png")

            getmap_r = (f"{self.url_right}&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
                        f"&BBOX={self.bbox_3301}&SRS=EPSG:3301&WIDTH={self.width}&HEIGHT={self.height}"
                        f"&LAYERS={param_r}&STYLES=&FORMAT=image/png")

            self.setProgress(10)
            if self.isCanceled():
                return False

            raw_l = _fetch_tile_bytes(getmap_l)
            self.setProgress(35)
            if self.isCanceled():
                return False

            raw_r = _fetch_tile_bytes(getmap_r)
            self.setProgress(60)
            if self.isCanceled():
                return False

            if not raw_l or not raw_r:
                return False

            img_l_raw = Image.open(io.BytesIO(raw_l)).convert("RGB")
            img_r_raw = Image.open(io.BytesIO(raw_r)).convert("RGB")

            arr_l = np.array(img_l_raw, dtype=np.float32) / 255.0
            arr_r = np.array(img_r_raw, dtype=np.float32) / 255.0

            # CALIBRATED EXTRACTION:
            # When examining reeds and forestry, spectral products (NDVI, NRG, NDR)
            # have vegetation signal strongly in the Green (band 1) or Red/NIR ratio.
            if "ndvi" in self.filt.lower():
                # NDVI color composite from ESTHub maps high NDVI to green
                sig_l = arr_l[:, :, 1]
                sig_r = arr_r[:, :, 1]
            elif "nrg" in self.filt.lower():
                # Near-infrared is channel 0 (red) in NRG composites
                sig_l = arr_l[:, :, 0]
                sig_r = arr_r[:, :, 0]
            else:
                # Color excess / Excess Green Index (ExG = 2G - R - B) or normalized difference
                # to cancel seasonal sun-angle & shadow brightness shifts
                sig_l = (2.0 * arr_l[:, :, 1] - arr_l[:, :, 0] - arr_l[:, :, 2])
                sig_r = (2.0 * arr_r[:, :, 1] - arr_r[:, :, 0] - arr_r[:, :, 2])

            # Baseline normalization to eliminate sun elevation & atmosphere differences:
            # We align the median background levels of non-cloud pixels
            med_l = np.median(sig_l)
            med_r = np.median(sig_r)
            sig_r_calibrated = sig_r - (med_r - med_l)

            # Delta: Right (Later date) minus Left (Earlier date)
            delta = sig_r_calibrated - sig_l

            h, w = delta.shape
            rgba = np.zeros((h, w, 4), dtype=np.uint8)

            thresh = self.threshold

            # Mask Loss (Vegetation drop / forest clearcut / reed mowing): delta < -thresh
            mask_loss = delta < -thresh

            # Mask Gain (Vegetation flush / regrowth): delta > +thresh
            mask_gain = delta > thresh

            # Morphological noise filter: Remove isolated single-pixel speckles
            if self.min_patch_clean:
                from PIL import ImageFilter
                mask_loss_img = Image.fromarray((mask_loss * 255).astype(np.uint8))
                mask_gain_img = Image.fromarray((mask_gain * 255).astype(np.uint8))
                # 3x3 min filter (erosion) removes speckles
                mask_loss_clean = np.array(mask_loss_img.filter(ImageFilter.MinFilter(3))) > 128
                mask_gain_clean = np.array(mask_gain_img.filter(ImageFilter.MinFilter(3))) > 128
            else:
                mask_loss_clean = mask_loss
                mask_gain_clean = mask_gain

            if self.mode in ("loss_only", "bidirectional"):
                # Vivid Red for canopy loss / clearcuts
                rgba[mask_loss_clean] = [235, 30, 30, 210]

            if self.mode in ("gain_only", "bidirectional"):
                # Vivid Green for vegetation emergence / greening
                rgba[mask_gain_clean] = [30, 210, 40, 210]

            self.setProgress(85)
            if self.isCanceled():
                return False

            # Write GeoTIFF
            from osgeo import gdal, osr
            gdal.UseExceptions()

            xmin, ymin, xmax, ymax = map(float, self.bbox_3301.split(','))
            pixel_x = (xmax - xmin) / float(w)
            pixel_y = (ymax - ymin) / float(h)

            driver = gdal.GetDriverByName('GTiff')
            ds = driver.Create(self.out_tif, w, h, 4, gdal.GDT_Byte, ['COMPRESS=DEFLATE', 'TILED=YES'])
            srs = osr.SpatialReference()
            srs.ImportFromEPSG(3301)
            ds.SetProjection(srs.ExportToWkt())
            ds.SetGeoTransform([xmin, pixel_x, 0.0, ymax, 0.0, -pixel_y])

            for b in range(4):
                ds.GetRasterBand(b + 1).WriteArray(rgba[:, :, b])

            ds.FlushCache()
            ds = None

            self.setProgress(100)
            return True

        except Exception as e:
            QgsMessageLog.logMessage(f"Calibrated Change Detection Error: {str(e)}", "SentinelWMS", Qgis.Critical)
            return False

    def finished(self, result):
        if result and os.path.exists(self.out_tif):
            if self.callback:
                self.callback(self.out_tif, self.dstr_left, self.dstr_right)
        else:
            if self.callback:
                self.callback(None, self.dstr_left, self.dstr_right)


class ChangeCalibrationDialog(QDialog):
    """Interactive settings dialog allowing users to calibrate sensitivity for forestry & wetland detection."""
    def __init__(self, workspace, parent=None):
        super().__init__(parent or workspace.main_canvas)
        self.ws = workspace
        self.setWindowTitle(tr("change_title"))
        self.resize(400, 270)

        styles = get_theme_styles()
        self.setStyleSheet(styles["dialog_style"])

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(f"<b>{tr('change_mode')}</b>"))
        self.combo_mode = QComboBox()
        self.combo_mode.addItem(tr("mode_loss"), "loss_only")
        self.combo_mode.addItem(tr("mode_gain"), "gain_only")
        self.combo_mode.addItem(tr("mode_both"), "bidirectional")
        layout.addWidget(self.combo_mode)

        layout.addSpacing(10)
        self.lbl_thresh = QLabel(f"{tr('sensitivity')} <b>25%</b> {tr('recommended_clearcut')}")
        layout.addWidget(self.lbl_thresh)

        self.slider_thresh = QSlider(Qt.Horizontal if not hasattr(Qt, 'Orientation') else Qt.Orientation.Horizontal)
        self.slider_thresh.setMinimum(10)
        self.slider_thresh.setMaximum(50)
        self.slider_thresh.setValue(25)
        self.slider_thresh.valueChanged.connect(self._on_slider_changed)
        layout.addWidget(self.slider_thresh)

        self.chk_speckle = QCheckBox(tr("filter_speckle"))
        self.chk_speckle.setChecked(True)
        layout.addWidget(self.chk_speckle)

        layout.addStretch()

        btn_layout = QHBoxLayout()
        self.btn_apply = QPushButton(tr("apply_mask"))
        self.btn_apply.clicked.connect(self.accept)
        self.btn_cancel = QPushButton(tr("cancel"))
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_apply)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

    def _on_slider_changed(self, val):
        rec = f" {tr('recommended_clearcut')}" if val == 25 else ""
        self.lbl_thresh.setText(f"{tr('sensitivity')} <b>{val}%</b>{rec}")

    def get_settings(self):
        return {
            "mode": self.combo_mode.currentData(),
            "threshold_pct": self.slider_thresh.value(),
            "min_patch_clean": self.chk_speckle.isChecked()
        }
