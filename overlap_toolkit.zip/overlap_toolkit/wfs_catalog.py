# -*- coding: utf-8 -*-
"""
WFS Catalog Manager and Selector Dialog for Overlap Suite
Provides direct access to Estonian and custom WFS servers with search,
filtering, background capability fetching, and seamless layer instantiation.
"""

import os
import json
import traceback
import urllib.request
import xml.etree.ElementTree as ET

from qgis.PyQt.QtCore import Qt, QSize, QUrl
from qgis.PyQt.QtGui import QIcon, QFont, QColor
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTreeWidget, QTreeWidgetItem, QHeaderView,
    QMessageBox, QInputDialog, QCheckBox, QFrame, QSplitter,
    QApplication, QProgressBar
)
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsSettings, QgsTask,
    QgsApplication, QgsBlockingNetworkRequest
)
from .compat import (
    QT_USER_ROLE, QT_HEADER_STRETCH, QFRAME_NO_FRAME, QLINEEDIT_NORMAL,
    QMESSAGEBOX_YES, QMESSAGEBOX_NO, QT_WAIT_CURSOR, QT_WINDOW_FLAGS,
    QGS_TASK_CANCEL
)

HEADER_STRETCH = QT_HEADER_STRETCH
FRAME_NO_FRAME = QFRAME_NO_FRAME

DEFAULT_WFS_SERVERS = {
    "EELIS (Avalik / Public)": "https://gsavalik.envir.ee/geoserver/eelis/ows",
    "EELIS (Sise / Internal)": "https://gsa.envir.ee/geoserver/eelis/wfs",
    "Maa-amet Kataster": "https://gsavalik.envir.ee/geoserver/kataster/wfs",
    "PRIA (Avalik / Public)": "https://kls.pria.ee/geoserver/pria_avalik/wfs",
    "Eesti Topo (ETAK)": "https://gsavalik.envir.ee/geoserver/etak/wfs"
}


class WfsCatalogParser:
    """Parses WFS GetCapabilities XML to extract feature types."""

    @staticmethod
    def fetch_layers(url):
        try:
            base_url = url.split('?')[0].strip()
            req_url = f"{base_url}?SERVICE=WFS&REQUEST=GetCapabilities&VERSION=1.0.0"

            content = None
            # Attempt via QgsBlockingNetworkRequest first
            try:
                req = QgsBlockingNetworkRequest()
                err = req.get(QNetworkRequest(QUrl(req_url)), forceRefresh=True)
                if err == 0 and req.reply():
                    content = req.reply().content().data()
            except Exception:
                content = None

            # Fallback to standard urllib
            if not content:
                req = urllib.request.Request(req_url, headers={'User-Agent': 'QGIS/OverlapToolkit'})
                with urllib.request.urlopen(req, timeout=12) as resp:
                    content = resp.read()

            if not content:
                return False, [], "No data received from WFS server."

            root = ET.fromstring(content)
            layers = []

            for elem in root.iter():
                if elem.tag.endswith('FeatureType'):
                    name_val = None
                    title_val = None
                    abstract_val = None
                    for child in elem:
                        if child.tag.endswith('Name'):
                            name_val = child.text.strip() if child.text else None
                        elif child.tag.endswith('Title'):
                            title_val = child.text.strip() if child.text else None
                        elif child.tag.endswith('Abstract'):
                            abstract_val = child.text.strip() if child.text else None

                    if name_val:
                        layers.append({
                            'name': name_val,
                            'title': title_val or name_val,
                            'abstract': abstract_val or ""
                        })

            return True, layers, None
        except Exception as e:
            return False, [], f"WFS Parse Error: {str(e)}"


class WfsCatalogFetchTask(QgsTask):
    """Background task to fetch WFS server capabilities without blocking GUI."""

    def __init__(self, description, server_name, server_url, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.server_name = server_name
        self.server_url = server_url
        self.callback = callback
        self.success = False
        self.layers = []
        self.error_msg = None

    def run(self):
        self.success, self.layers, self.error_msg = WfsCatalogParser.fetch_layers(self.server_url)
        return True

    def finished(self, result):
        if not self.isCanceled() and self.callback:
            self.callback(self.server_name, self.server_url, self.layers if self.success else [], self.error_msg)


class WfsCatalogDialog(QDialog):
    """Interactive WFS Catalog Browser and Layer Selector Dialog."""

    def __init__(self, iface, parent=None, lang="est", theme="system"):
        super().__init__(parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.lang = lang
        self.theme = theme
        self.selected_layer = None
        self.active_tasks = []
        self._is_closed = False
        self.server_data = {}  # server_name: {"url": str, "layers": list, "status": str}

        # Window properties
        w_title = "WFS Teenuste Kataloog" if self.lang == "est" else "WFS Service Catalog"
        self.setWindowTitle(w_title)
        self.resize(750, 560)

        # Cross-version window flags (minimizable, maximizable)
        self.setWindowFlags(QT_WINDOW_FLAGS)

        self.init_ui()
        self.load_servers()

    def t(self, key_est, key_eng):
        return key_est if self.lang == "est" else key_eng

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Top Bar: Search and Server Operations
        top_bar = QHBoxLayout()
        top_bar.setSpacing(8)

        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText(
            self.t("Otsi kihti või serverit (nt kataster, mets, eelis)...", "Search layer or server (e.g. cadastre, eelis)...")
        )
        self.txt_search.textChanged.connect(self.filter_tree)
        top_bar.addWidget(self.txt_search, 1)

        self.btn_clear_search = QPushButton("✕")
        self.btn_clear_search.setFixedWidth(28)
        self.btn_clear_search.setToolTip(self.t("Tühjenda otsing", "Clear search"))
        self.btn_clear_search.clicked.connect(lambda: self.txt_search.clear())
        top_bar.addWidget(self.btn_clear_search)

        self.btn_refresh = QPushButton(self.t("🔄 Värskenda", "🔄 Refresh"))
        self.btn_refresh.setToolTip(self.t("Laadi serverite info uuesti", "Reload server capabilities"))
        self.btn_refresh.clicked.connect(self.refresh_all_servers)
        top_bar.addWidget(self.btn_refresh)

        self.btn_add_server = QPushButton(self.t("➕ Lisa server...", "➕ Add Server..."))
        self.btn_add_server.setToolTip(self.t("Lisa kohandatud WFS serveri URL", "Add custom WFS server URL"))
        self.btn_add_server.clicked.connect(self.prompt_add_server)
        top_bar.addWidget(self.btn_add_server)

        self.btn_remove_server = QPushButton(self.t("🗑️ Eemalda server", "🗑️ Remove Server"))
        self.btn_remove_server.setToolTip(self.t("Eemalda valitud kohandatud server", "Remove selected custom server"))
        self.btn_remove_server.clicked.connect(self.remove_selected_server)
        top_bar.addWidget(self.btn_remove_server)

        main_layout.addLayout(top_bar)

        # Tree Widget for Servers and Layers
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels([
            self.t("Server / Kihi nimi", "Server / Layer Name"),
            self.t("Kirjeldus / Pealkiri", "Description / Title")
        ])
        self.tree.setColumnWidth(0, 360)
        self.tree.header().setSectionResizeMode(1, HEADER_STRETCH)
        self.tree.itemSelectionChanged.connect(self.on_selection_changed)
        self.tree.itemDoubleClicked.connect(self.on_item_double_clicked)
        main_layout.addWidget(self.tree, 1)

        # Details Panel
        self.lbl_details = QLabel(self.t("Vali kiht nimekirjast...", "Select a layer from the list..."))
        self.lbl_details.setStyleSheet("font-size: 11px; padding: 4px; border-radius: 4px;")
        self.lbl_details.setWordWrap(True)
        main_layout.addWidget(self.lbl_details)

        # Bottom Bar: Options & Actions
        bottom_bar = QHBoxLayout()
        bottom_bar.setSpacing(10)

        self.chk_restrict_bbox = QCheckBox(
            self.t("Piira päring kaardi vaateväljaga (restrictToRequestBBOX)", "Restrict query to map canvas extent (restrictToRequestBBOX)")
        )
        settings = QgsSettings()
        default_bbox = bool(settings.value("OverlapToolkit/wfs_restrict_bbox", settings.value("OverlapSuite/wfs_restrict_bbox", True, type=bool)))
        self.chk_restrict_bbox.setChecked(default_bbox)
        self.chk_restrict_bbox.toggled.connect(self.on_restrict_bbox_toggled)
        self.chk_restrict_bbox.setToolTip(
            self.t(
                "Kiirem laadimine: ei laadi korraga alla kogu Eesti andmeid, vaid ainult kuvatava ala objektid.",
                "Faster loading: queries only features within the active bounding box instead of entire country."
            )
        )
        bottom_bar.addWidget(self.chk_restrict_bbox)

        bottom_bar.addStretch()

        self.btn_select = QPushButton(self.t("Kasuta valitud kihti", "Use Selected Layer"))
        self.btn_select.setObjectName("primaryAction")
        self.btn_select.setEnabled(False)
        self.btn_select.setMinimumWidth(150)
        self.btn_select.clicked.connect(self.accept_selection)
        bottom_bar.addWidget(self.btn_select)

        self.btn_close = QPushButton(self.t("Sulge", "Close"))
        self.btn_close.clicked.connect(self.reject)
        bottom_bar.addWidget(self.btn_close)

        main_layout.addLayout(bottom_bar)

    def on_restrict_bbox_toggled(self, checked):
        QgsSettings().setValue("OverlapToolkit/wfs_restrict_bbox", bool(checked))

    def load_servers(self):
        """Loads default and saved custom WFS servers from QgsSettings."""
        settings = QgsSettings()
        custom_json = settings.value("OverlapToolkit/wfs_servers", settings.value("OverlapSuite/wfs_servers", "{}"))
        try:
            custom_servers = json.loads(custom_json)
        except Exception:
            custom_servers = {}

        all_servers = dict(DEFAULT_WFS_SERVERS)
        all_servers.update(custom_servers)

        self.tree.clear()
        self.server_nodes = {}

        for name, url in all_servers.items():
            node = QTreeWidgetItem(self.tree, [f"{name} [{self.t('Laadin...', 'Loading...')}]", url])
            node.setData(0, QT_USER_ROLE, {"type": "server", "name": name, "url": url})
            font = node.font(0)
            font.setBold(True)
            node.setFont(0, font)
            self.server_nodes[name] = node

            # Launch background fetch task
            task = WfsCatalogFetchTask(f"Fetching WFS: {name}", name, url, self.on_wfs_fetched)
            self.active_tasks.append(task)
            QgsApplication.taskManager().addTask(task)

    def _cancel_active_tasks(self):
        self._is_closed = True
        for task in getattr(self, "active_tasks", []):
            try:
                task.on_complete = None
                task.cancel()
            except Exception:
                pass

    def reject(self):
        self._cancel_active_tasks()
        super().reject()

    def closeEvent(self, event):
        self._cancel_active_tasks()
        super().closeEvent(event)

    def on_wfs_fetched(self, server_name, server_url, layers, error_msg):
        """Callback when a WFS server capabilities have been fetched."""
        if getattr(self, "_is_closed", False):
            return

        node = self.server_nodes.get(server_name)
        if not node:
            return

        try:
            node.takeChildren()

            if error_msg:
                node.setText(0, f"❌ {server_name} [{self.t('Viga', 'Failed')}]")
                node.setToolTip(0, error_msg)
                self.server_data[server_name] = {"url": server_url, "layers": [], "status": "error"}
                return

            node.setText(0, f"🌐 {server_name} ({len(layers)})")
            self.server_data[server_name] = {"url": server_url, "layers": layers, "status": "ok"}

            for layer in layers:
                l_name = layer['name']
                l_title = layer['title']
                child = QTreeWidgetItem(node, [l_name, l_title])
                child.setData(0, QT_USER_ROLE, {
                    "type": "layer",
                    "server_name": server_name,
                    "server_url": server_url,
                    "layer_name": l_name,
                    "layer_title": l_title,
                    "abstract": layer.get('abstract', '')
                })

            # Keep server expanded if search has active filter
            if self.txt_search.text().strip():
                self.filter_tree(self.txt_search.text())
            else:
                node.setExpanded(False)
        except RuntimeError:
            # Dialog / tree widget C++ object was already deleted
            return

    def refresh_all_servers(self):
        """Refreshes all WFS servers."""
        self.load_servers()

    def prompt_add_server(self):
        """Prompts user to add a custom WFS server."""
        url, ok = QInputDialog.getText(
            self,
            self.t("Lisa WFS server", "Add WFS Server"),
            self.t("Sisesta WFS serveri URL (nt https://.../geoserver/ows):", "Enter WFS Server URL:"),
            QLINEEDIT_NORMAL, ""
        )
        if not ok or not url.strip():
            return

        url = url.strip()
        name, ok2 = QInputDialog.getText(
            self,
            self.t("Serveri nimi", "Server Name"),
            self.t("Sisesta serveri kuvatav nimi:", "Enter server display name:"),
            QLINEEDIT_NORMAL, "Custom WFS"
        )
        if not ok2 or not name.strip():
            name = "Custom WFS"

        name = name.strip()

        # Save to QgsSettings
        settings = QgsSettings()
        try:
            custom_servers = json.loads(settings.value("OverlapToolkit/wfs_servers", settings.value("OverlapSuite/wfs_servers", "{}")))
        except Exception:
            custom_servers = {}

        custom_servers[name] = url
        settings.setValue("OverlapToolkit/wfs_servers", json.dumps(custom_servers))

        # Add node and fetch
        node = QTreeWidgetItem(self.tree, [f"{name} [{self.t('Laadin...', 'Loading...')}]", url])
        node.setData(0, QT_USER_ROLE, {"type": "server", "name": name, "url": url})
        font = node.font(0)
        font.setBold(True)
        node.setFont(0, font)
        self.server_nodes[name] = node

        task = WfsCatalogFetchTask(f"Fetching WFS: {name}", name, url, self.on_wfs_fetched)
        self.active_tasks.append(task)
        QgsApplication.taskManager().addTask(task)

    def remove_selected_server(self):
        """Removes the selected custom WFS server."""
        item = self.tree.currentItem()
        if not item:
            return

        data = item.data(0, QT_USER_ROLE)
        if not data or data.get("type") != "server":
            return

        server_name = data.get("name")
        if server_name in DEFAULT_WFS_SERVERS:
            QMessageBox.information(
                self,
                self.t("Teade", "Notice"),
                self.t("Vaikeservereid ei saa eemaldada.", "Default servers cannot be removed.")
            )
            return

        reply = QMessageBox.question(
            self,
            self.t("Kinnita eemaldamine", "Confirm Removal"),
            self.t(f"Kas soovid serveri '{server_name}' eemaldada?", f"Remove server '{server_name}'?"),
            QMESSAGEBOX_YES | QMESSAGEBOX_NO
        )
        if reply == QMESSAGEBOX_YES:
            settings = QgsSettings()
            try:
                custom_servers = json.loads(settings.value("OverlapToolkit/wfs_servers", settings.value("OverlapSuite/wfs_servers", "{}")))
            except Exception:
                custom_servers = {}

            if server_name in custom_servers:
                del custom_servers[server_name]
                settings.setValue("OverlapToolkit/wfs_servers", json.dumps(custom_servers))

            idx = self.tree.indexOfTopLevelItem(item)
            if idx >= 0:
                self.tree.takeTopLevelItem(idx)

    def filter_tree(self, text):
        """Filters tree items based on search query in layer name, title, or server name."""
        query = text.strip().lower()

        for i in range(self.tree.topLevelItemCount()):
            server_node = self.tree.topLevelItem(i)
            server_name = server_node.text(0).lower()
            server_matches = query in server_name

            matched_children_count = 0
            for j in range(server_node.childCount()):
                child = server_node.child(j)
                name = child.text(0).lower()
                title = child.text(1).lower()

                if not query or query in name or query in title or server_matches:
                    child.setHidden(False)
                    matched_children_count += 1
                else:
                    child.setHidden(True)

            if not query:
                server_node.setHidden(False)
            else:
                server_node.setHidden(matched_children_count == 0 and not server_matches)
                if matched_children_count > 0:
                    server_node.setExpanded(True)

    def on_selection_changed(self):
        """Updates details and enable/disable state of Select button."""
        item = self.tree.currentItem()
        if not item:
            self.btn_select.setEnabled(False)
            self.lbl_details.setText(self.t("Vali kiht nimekirjast...", "Select a layer from the list..."))
            return

        data = item.data(0, QT_USER_ROLE)
        if data and data.get("type") == "layer":
            self.btn_select.setEnabled(True)
            s_name = data.get("server_name")
            l_name = data.get("layer_name")
            l_title = data.get("layer_title")
            abstract = data.get("abstract")

            info = f"<b>{l_title}</b> (<code>{l_name}</code>)<br><b>Server:</b> {s_name}"
            if abstract:
                info += f"<br><i>{abstract}</i>"
            self.lbl_details.setText(info)
        else:
            self.btn_select.setEnabled(False)
            if data and data.get("type") == "server":
                self.lbl_details.setText(f"<b>Server:</b> {data.get('name')}<br><code>{data.get('url')}</code>")

    def on_item_double_clicked(self, item, column):
        """Double clicking a layer immediately accepts selection."""
        data = item.data(0, QT_USER_ROLE)
        if data and data.get("type") == "layer":
            self.accept_selection()

    def accept_selection(self):
        """Instantiates selected WFS layer and adds it to QGIS."""
        item = self.tree.currentItem()
        if not item:
            return

        data = item.data(0, QT_USER_ROLE)
        if not data or data.get("type") != "layer":
            return

        server_url = data.get("server_url").split('?')[0].strip()
        layer_name = data.get("layer_name")
        layer_title = data.get("layer_title") or layer_name

        crs_authid = QgsProject.instance().crs().authid() or "EPSG:3301"

        # Build URI
        if self.chk_restrict_bbox.isChecked():
            uri = f"restrictToRequestBBOX='1' srsname='{crs_authid}' typename='{layer_name}' url='{server_url}'"
        else:
            uri = f"srsname='{crs_authid}' typename='{layer_name}' url='{server_url}'"

        QApplication.setOverrideCursor(QT_WAIT_CURSOR)
        try:
            vlayer = QgsVectorLayer(uri, layer_title, "WFS")
            if not vlayer or not vlayer.isValid():
                # Retry with basic URI if BBOX parameter was rejected
                basic_uri = f"srsname='{crs_authid}' typename='{layer_name}' url='{server_url}'"
                vlayer = QgsVectorLayer(basic_uri, layer_title, "WFS")

            if not vlayer or not vlayer.isValid():
                QApplication.restoreOverrideCursor()
                QMessageBox.critical(
                    self,
                    self.t("WFS viga", "WFS Error"),
                    self.t(
                        f"WFS kihi loomine ebaõnnestus:\n{layer_name}\nURL: {server_url}",
                        f"Failed to create WFS layer:\n{layer_name}\nURL: {server_url}"
                    )
                )
                return

            # Add to QGIS Project
            QgsProject.instance().addMapLayer(vlayer)
            self.selected_layer = vlayer
            QApplication.restoreOverrideCursor()
            self.accept()
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, self.t("WFS viga", "WFS Error"), f"Error:\n{str(e)}")
