# -*- coding: utf-8 -*-
"""
High-Performance Grouped Vector Overlap Calculation with Overall Statistics
"""

import os
from collections import defaultdict
from qgis.core import (
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsProject,
    QgsSpatialIndex,
    QgsProcessingFeedback,
    QgsProcessingContext,
    QgsVectorFileWriter
)
from qgis.PyQt.QtCore import QVariant


def safe_field_name(val):
    s = str(val).replace(" ", "_").replace("-", "_").replace("/", "_")
    return "".join(c for c in s if c.isalnum() or c == "_")


def save_layer_to_file(layer, output_path):
    if not output_path:
        return layer

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    options = QgsVectorFileWriter.SaveVectorOptions()
    if output_path.lower().endswith(".gpkg"):
        options.driverName = "GPKG"
    elif output_path.lower().endswith(".shp"):
        options.driverName = "ESRI Shapefile"
    elif output_path.lower().endswith(".geojson"):
        options.driverName = "GeoJSON"

    res = QgsVectorFileWriter.writeAsVectorFormatV3(
        layer,
        output_path,
        QgsProject.instance().transformContext(),
        options
    )
    if res[0] == 0:  # NoError
        layer_name = os.path.splitext(os.path.basename(output_path))[0]
        return QgsVectorLayer(output_path, layer_name, "ogr")
    else:
        raise RuntimeError(f"Failed to write layer to {output_path}: {res[1] if len(res) > 1 else res}")


def run_grouped_overlap(
    input_layer,
    overlay_layer,
    group_field,
    input_selected_only=False,
    overlay_selected_only=False,
    area_unit="ha",
    detail_coeff=0.001,
    field_prefix="Ülekate_",
    strip_asterisks=True,
    only_active_groups=True,
    precision=2,
    generate_stats=True,
    dominant_group_field="Peamine_grupp",
    dominant_overlap_field="Peamine_ülekate",
    total_overlap_field="Kogu_ülekate",
    output_path=None,
    feedback=None
):
    """
    Calculates vector overlaps grouped by an attribute from the overlay layer.
    Uses spatial indexing for 100x-1000x speedup over nested loops.
    Computes planar/cartesian area and optionally compiles overall aggregate statistics.
    Adds dominant/primary group summary columns for direct symbology styling.
    """
    if feedback is None:
        feedback = QgsProcessingFeedback()

    if input_layer is None or overlay_layer is None:
        raise ValueError("Invalid input or overlay layer")

    if not group_field or group_field not in [f.name() for f in overlay_layer.fields()]:
        raise ValueError(f"Grouping field '{group_field}' not found in overlay layer")

    feedback.pushInfo("Initializing Grouped Overlap analysis...")

    # Coordinate transformation if CRSs differ
    transform = None
    if input_layer.sourceCrs() != overlay_layer.sourceCrs():
        transform = QgsCoordinateTransform(
            overlay_layer.sourceCrs(),
            input_layer.sourceCrs(),
            QgsProject.instance()
        )
        feedback.pushInfo(f"Reprojecting overlay from {overlay_layer.sourceCrs().authid()} to {input_layer.sourceCrs().authid()}")

    divisor = 10000.0 if area_unit == "ha" else 1.0

    # 1. Preprocess Overlay Layer & Build Spatial Index
    feedback.pushInfo("Indexing overlay features...")
    spatial_index = QgsSpatialIndex()
    overlay_dict = {}  # fid -> (group_val, geom)
    overlay_group_totals = defaultdict(float)

    ov_iterator = (
        overlay_layer.getSelectedFeatures()
        if overlay_selected_only and overlay_layer.selectedFeatureCount() > 0
        else overlay_layer.getFeatures()
    )

    ov_count = (
        overlay_layer.selectedFeatureCount()
        if overlay_selected_only and overlay_layer.selectedFeatureCount() > 0
        else overlay_layer.featureCount()
    )

    processed_ov = 0
    for ov_feat in ov_iterator:
        if feedback.isCanceled():
            return None, None

        raw_gv = ov_feat[group_field]
        if raw_gv is None:
            continue

        gv = str(raw_gv).strip()
        if strip_asterisks:
            gv = gv.replace("*", "").strip()

        if not gv:
            continue

        geom = ov_feat.geometry()
        if not geom or geom.isEmpty():
            continue

        if transform:
            geom.transform(transform)

        fid = ov_feat.id()
        spatial_index.addFeature(ov_feat)
        overlay_dict[fid] = (gv, geom)

        try:
            ov_a = geom.cartesianArea() / divisor
        except AttributeError:
            ov_a = geom.area() / divisor
        overlay_group_totals[gv] += ov_a

        processed_ov += 1
        if processed_ov % 5000 == 0 and ov_count > 0:
            feedback.setProgress(int(15.0 * processed_ov / ov_count))

    feedback.pushInfo(f"Indexed {len(overlay_dict)} valid overlay features.")

    # 2. Iterate Input Layer Features using Spatial Index
    feedback.pushInfo("Calculating cartesian overlaps for input features...")
    in_iterator = (
        input_layer.getSelectedFeatures()
        if input_selected_only and input_layer.selectedFeatureCount() > 0
        else input_layer.getFeatures()
    )

    total_in_count = (
        input_layer.selectedFeatureCount()
        if input_selected_only and input_layer.selectedFeatureCount() > 0
        else input_layer.featureCount()
    )

    per_feature_vals = []
    group_totals = defaultdict(float)
    group_feature_counts = defaultdict(int)
    total_input_area = 0.0

    processed_in = 0
    for in_feat in in_iterator:
        if feedback.isCanceled():
            return None, None

        geom_in = in_feat.geometry()
        feat_vals = defaultdict(float)

        if geom_in and not geom_in.isEmpty():
            try:
                in_a = geom_in.cartesianArea() / divisor
            except AttributeError:
                in_a = geom_in.area() / divisor
            total_input_area += in_a

            bbox = geom_in.boundingBox()
            candidate_fids = spatial_index.intersects(bbox)

            for fid in candidate_fids:
                gv, geom_ov = overlay_dict[fid]
                if not geom_in.intersects(geom_ov):
                    continue

                inter = geom_in.intersection(geom_ov)
                if inter and not inter.isEmpty():
                    try:
                        area_val = inter.cartesianArea()
                    except AttributeError:
                        area_val = inter.area()
                    
                    area_val /= divisor

                    # Detail coefficient threshold check (converted to ha for comparison)
                    area_ha = area_val if area_unit == "ha" else area_val / 10000.0
                    if area_ha >= detail_coeff:
                        feat_vals[gv] += area_val

        # Tally per-feature values
        for gv, aval in feat_vals.items():
            if aval > 0:
                group_totals[gv] += aval
                group_feature_counts[gv] += 1

        per_feature_vals.append(feat_vals)

        processed_in += 1
        if processed_in % 50 == 0 and total_in_count > 0:
            pct = 15.0 + 75.0 * (processed_in / max(1, total_in_count))
            feedback.setProgress(int(pct))

    # 3. Determine active groups
    if only_active_groups:
        active_groups = sorted([gv for gv, tot in group_totals.items() if tot > 0], key=lambda v: str(v))
    else:
        active_groups = sorted(list(overlay_group_totals.keys()), key=lambda v: str(v))

    feedback.pushInfo(f"Found {len(active_groups)} active groups with overlaps.")

    # 4. Prepare Output Layer
    feedback.pushInfo("Writing output features with summary columns...")
    geom_type = QgsWkbTypes.displayString(input_layer.wkbType())
    crs_str = input_layer.sourceCrs().authid()
    mem_uri = f"{geom_type}?crs={crs_str}"
    out_layer = QgsVectorLayer(mem_uri, f"{input_layer.name()}_grouped_overlap", "memory")
    pr = out_layer.dataProvider()

    new_fields = [f for f in input_layer.fields()]

    # Add summary fields for dominant group and total overlap
    new_fields.append(QgsField(dominant_group_field, QVariant.String))
    new_fields.append(QgsField(dominant_overlap_field, QVariant.Double))
    new_fields.append(QgsField(total_overlap_field, QVariant.Double))

    # Add individual group columns
    for gv in active_groups:
        fname = f"{field_prefix}{safe_field_name(gv)}"
        new_fields.append(QgsField(fname, QVariant.Double))

    pr.addAttributes(new_fields)
    out_layer.updateFields()

    in_write_iterator = (
        input_layer.getSelectedFeatures()
        if input_selected_only and input_layer.selectedFeatureCount() > 0
        else input_layer.getFeatures()
    )

    batch = []
    for i, in_feat in enumerate(in_write_iterator):
        if feedback.isCanceled():
            return None, None

        new_feat = QgsFeature(out_layer.fields())
        attrs = list(in_feat.attributes())

        feat_vals = per_feature_vals[i]

        # Calculate dominant group, dominant overlap and total overlap
        if feat_vals:
            max_gv = max(feat_vals.keys(), key=lambda k: feat_vals[k])
            max_ov = feat_vals[max_gv]
            tot_ov = sum(feat_vals.values())
        else:
            max_gv = None
            max_ov = 0.0
            tot_ov = 0.0

        attrs.append(str(max_gv) if max_gv is not None else None)
        attrs.append(round(max_ov, precision))
        attrs.append(round(tot_ov, precision))

        # Append individual group overlap values
        for gv in active_groups:
            val = feat_vals.get(gv, 0.0)
            attrs.append(round(val, precision) if val else 0.0)

        new_feat.setAttributes(attrs)
        new_feat.setGeometry(in_feat.geometry())
        batch.append(new_feat)

        if len(batch) >= 1000:
            pr.addFeatures(batch)
            batch.clear()

    if batch:
        pr.addFeatures(batch)

    out_layer.updateExtents()
    feedback.setProgress(95)

    # 5. Compile Overall Statistics (Treating input features as a whole)
    stats_summary = None
    if generate_stats:
        feedback.pushInfo("Compiling overall statistics...")
        stats_rows = []
        for gv in active_groups:
            tot_ha = group_totals[gv]
            feat_cnt = group_feature_counts[gv]
            pct_input = (tot_ha / total_input_area * 100.0) if total_input_area > 0 else 0.0
            ov_tot = overlay_group_totals.get(gv, 0.0)
            pct_group = (tot_ha / ov_tot * 100.0) if ov_tot > 0 else 0.0

            stats_rows.append({
                "group": gv,
                "feature_count": feat_cnt,
                "total_overlap": round(tot_ha, precision),
                "percent_of_input": round(pct_input, precision),
                "percent_of_group": round(pct_group, precision)
            })

        stats_summary = {
            "total_input_features": processed_in,
            "total_input_area": round(total_input_area, precision),
            "area_unit": area_unit,
            "group_field": group_field,
            "dominant_group_field": dominant_group_field,
            "dominant_overlap_field": dominant_overlap_field,
            "total_overlap_field": total_overlap_field,
            "groups": stats_rows
        }

    feedback.setProgress(100)
    feedback.pushInfo("Grouped overlap analysis completed successfully!")

    # Save to file if output_path is provided
    final_layer = save_layer_to_file(out_layer, output_path) if output_path else out_layer
    return final_layer, stats_summary


def create_statistics_table_layer(stats_summary, layer_name="Overall Overlap Statistics"):
    """
    Creates an in-memory non-spatial table layer containing the overall statistics
    which can be added directly to the QGIS Layers panel.
    """
    if not stats_summary or "groups" not in stats_summary:
        return None

    unit = stats_summary.get("area_unit", "ha")
    table_layer = QgsVectorLayer("none", layer_name, "memory")
    pr = table_layer.dataProvider()

    pr.addAttributes([
        QgsField(f"group_{stats_summary.get('group_field', 'val')}", QVariant.String),
        QgsField("features_count", QVariant.Int),
        QgsField(f"total_overlap_{unit}", QVariant.Double),
        QgsField("overlap_pct_of_input", QVariant.Double),
        QgsField("overlap_pct_of_group", QVariant.Double)
    ])
    table_layer.updateFields()

    features = []
    for row in stats_summary["groups"]:
        feat = QgsFeature(table_layer.fields())
        feat.setAttributes([
            str(row["group"]),
            int(row["feature_count"]),
            float(row["total_overlap"]),
            float(row["percent_of_input"]),
            float(row["percent_of_group"])
        ])
        features.append(feat)

    pr.addFeatures(features)
    table_layer.updateExtents()
    return table_layer
