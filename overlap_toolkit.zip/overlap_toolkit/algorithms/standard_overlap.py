# -*- coding: utf-8 -*-
"""
Standard Vector Overlap Calculation
"""

import os
from collections import defaultdict
from qgis.core import (
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsProject,
    QgsProcessingFeedback,
    QgsProcessingContext,
    QgsVectorFileWriter
)
from qgis.PyQt.QtCore import QVariant
import processing


def safe_field_name(val):
    s = str(val).replace(" ", "_").replace("-", "_").replace("/", "_")
    return "".join(c for c in s if c.isalnum() or c == "_")


def save_layer_to_file(layer, output_path):
    if not output_path:
        return layer

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    options = QgsVectorFileWriter.SaveVectorOptions()
    if output_path.lower().endswith(".gpkg"):
        options.driverName = "GPKG"
    elif output_path.lower().endswith(".shp"):
        options.driverName = "ESRI Shapefile"
    elif output_path.lower().endswith(".geojson"):
        options.driverName = "GeoJSON"

    res = QgsVectorFileWriter.writeAsVectorFormatV3(
        layer,
        output_path,
        QgsProject.instance().transformContext(),
        options
    )
    if res[0] == 0:  # NoError
        layer_name = os.path.splitext(os.path.basename(output_path))[0]
        return QgsVectorLayer(output_path, layer_name, "ogr")
    else:
        raise RuntimeError(f"Failed to write layer to {output_path}: {res[1] if len(res) > 1 else res}")


def run_standard_overlap(
    input_layer,
    overlay_layers,
    input_selected_only=False,
    overlay_selected_only=False,
    area_field="Area_ha",
    percent_field="Overlap_%",
    min_area_ha=0.001,
    unit="ha",
    precision=2,
    output_path=None,
    feedback=None
):
    """
    Calculates overlap area and percentage between an input layer and one or more overlay layers.
    Optimized to eliminate redundant spatial joins and preserve all input features.
    """
    if feedback is None:
        feedback = QgsProcessingFeedback()

    if input_layer is None or not overlay_layers:
        raise ValueError("Invalid input layer or no overlay layers provided")

    context = QgsProcessingContext()
    feedback.pushInfo("Running vector overlap calculation...")
    
    # Check if we should filter selected features
    in_source = input_layer
    if input_selected_only and input_layer.selectedFeatureCount() > 0:
        in_source = processing.run(
            "native:saveselectedfeatures",
            {"INPUT": input_layer, "OUTPUT": "memory:"},
            context=context, feedback=feedback
        )["OUTPUT"]

    ov_sources = []
    for ov in overlay_layers:
        if overlay_selected_only and ov.selectedFeatureCount() > 0:
            ov_filtered = processing.run(
                "native:saveselectedfeatures",
                {"INPUT": ov, "OUTPUT": "memory:"},
                context=context, feedback=feedback
            )["OUTPUT"]
            ov_sources.append(ov_filtered)
        else:
            ov_sources.append(ov)

    # Run native calculate vector overlaps
    overlap_res = processing.run(
        "native:calculatevectoroverlaps",
        {
            "INPUT": in_source,
            "LAYERS": ov_sources,
            "OUTPUT": "memory:"
        },
        context=context, feedback=feedback
    )["OUTPUT"]

    if feedback.isCanceled():
        return None

    # Detect the generated area and percent field names from the overlay result
    area_fields = []
    pc_fields = []
    in_field_names = set(fld.name() for fld in in_source.fields())

    for f in overlap_res.fields():
        fname = f.name().lower()
        if fname.endswith("_area") or "area" in fname:
            if f.name() not in in_field_names:
                area_fields.append(f.name())
        elif fname.endswith("_pc") or "percent" in fname or "pc" in fname:
            if f.name() not in in_field_names:
                pc_fields.append(f.name())

    # Build destination in-memory layer
    geom_type = QgsWkbTypes.displayString(input_layer.wkbType())
    crs_str = input_layer.sourceCrs().authid()
    mem_uri = f"{geom_type}?crs={crs_str}"
    out_layer = QgsVectorLayer(mem_uri, f"{input_layer.name()}_overlap", "memory")
    pr = out_layer.dataProvider()

    # Destination attributes: original input attributes + area_field + percent_field
    new_fields = [f for f in input_layer.fields()]
    new_fields.append(QgsField(area_field, QVariant.Double))
    new_fields.append(QgsField(percent_field, QVariant.Double))

    extra_layer_fields = []
    if len(overlay_layers) > 1 and len(area_fields) > 1:
        for i, ov in enumerate(overlay_layers):
            af = area_fields[i] if i < len(area_fields) else None
            pf = pc_fields[i] if i < len(pc_fields) else None
            ov_name = safe_field_name(ov.name())
            f_area = f"{ov_name}_{area_field}"
            f_pc = f"{ov_name}_{percent_field}"
            new_fields.append(QgsField(f_area, QVariant.Double))
            new_fields.append(QgsField(f_pc, QVariant.Double))
            extra_layer_fields.append((af, pf, f_area, f_pc))

    pr.addAttributes(new_fields)
    out_layer.updateFields()

    total_count = overlap_res.featureCount()
    processed = 0
    divisor = 10000.0 if unit == "ha" else 1.0

    batch = []
    for feat in overlap_res.getFeatures():
        if feedback.isCanceled():
            break

        geom = feat.geometry()
        attrs = feat.attributes()[:len(input_layer.fields())]

        tot_area_m2 = 0.0
        tot_pc = 0.0

        for af in area_fields:
            val = feat[af]
            if val is not None and val > 0:
                tot_area_m2 += float(val)

        for pf in pc_fields:
            val = feat[pf]
            if val is not None and val > 0:
                tot_pc += float(val)

        calc_area = tot_area_m2 / divisor
        calc_pc = min(100.0, tot_pc)

        area_in_ha = tot_area_m2 / 10000.0
        if area_in_ha < min_area_ha:
            calc_area = 0.0
            calc_pc = 0.0

        attrs.append(round(calc_area, precision))
        attrs.append(round(calc_pc, precision))

        for af, pf, _, _ in extra_layer_fields:
            l_area_m2 = feat[af] or 0.0
            l_pc = feat[pf] or 0.0
            l_area = l_area_m2 / divisor
            if (l_area_m2 / 10000.0) < min_area_ha:
                l_area = 0.0
                l_pc = 0.0
            attrs.append(round(l_area, precision))
            attrs.append(round(l_pc, precision))

        new_feat = QgsFeature(out_layer.fields())
        new_feat.setGeometry(geom)
        new_feat.setAttributes(attrs)
        batch.append(new_feat)

        if len(batch) >= 1000:
            pr.addFeatures(batch)
            batch.clear()

        processed += 1
        if processed % 100 == 0 and total_count > 0:
            feedback.setProgress(int(100.0 * processed / total_count))

    if batch:
        pr.addFeatures(batch)

    out_layer.updateExtents()

    # Save to file if output_path is provided
    if output_path:
        return save_layer_to_file(out_layer, output_path)

    return out_layer
