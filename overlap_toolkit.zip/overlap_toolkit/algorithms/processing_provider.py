# -*- coding: utf-8 -*-
"""
QGIS Processing Provider and Algorithms for Overlap Suite
"""

import os
from qgis.core import (
    QgsProcessingProvider,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterField,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessing
)
from qgis.PyQt.QtGui import QIcon

from .standard_overlap import run_standard_overlap
from .grouped_overlap import run_grouped_overlap, create_statistics_table_layer


class OverlapStandardAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OVERLAY = 'OVERLAY'
    AREA_FIELD = 'AREA_FIELD'
    PERCENT_FIELD = 'PERCENT_FIELD'
    MIN_AREA_HA = 'MIN_AREA_HA'
    UNIT = 'UNIT'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                'Input polygon layer',
                [QgsProcessing.TypeVectorPolygon]
            )
        )
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.OVERLAY,
                'Overlay / mask layer(s)',
                QgsProcessing.TypeVectorPolygon
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.AREA_FIELD,
                'Field name for overlap area',
                defaultValue='Ülekate_ha'
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.PERCENT_FIELD,
                'Field name for overlap percentage',
                defaultValue='Ülekate_%'
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.MIN_AREA_HA,
                'Detail coefficient / Minimum overlap area (ha)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.001
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                'Area unit',
                options=['Hectares (ha)', 'Square meters (m²)'],
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                'Output layer'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        input_layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        overlay_layers = self.parameterAsLayerList(parameters, self.OVERLAY, context)
        area_field = self.parameterAsString(parameters, self.AREA_FIELD, context)
        percent_field = self.parameterAsString(parameters, self.PERCENT_FIELD, context)
        min_area_ha = self.parameterAsDouble(parameters, self.MIN_AREA_HA, context)
        unit_idx = self.parameterAsEnum(parameters, self.UNIT, context)
        unit = "ha" if unit_idx == 0 else "m2"

        out_sink_id = parameters[self.OUTPUT]

        result_layer = run_standard_overlap(
            input_layer=input_layer,
            overlay_layers=overlay_layers,
            area_field=area_field,
            percent_field=percent_field,
            min_area_ha=min_area_ha,
            unit=unit,
            output_path=out_sink_id if isinstance(out_sink_id, str) and not out_sink_id.startswith("memory:") else None,
            feedback=feedback
        )

        return {self.OUTPUT: result_layer.id() if result_layer else None}

    def name(self):
        return 'standard_overlap'

    def displayName(self):
        return 'Calculate Overlap (Standard)'

    def group(self):
        return 'Vector Overlap'

    def groupId(self):
        return 'vector_overlap'

    def shortHelpString(self):
        return (
            'Calculates cartesian overlap area and percentage between an input polygon layer '
            'and one or more overlay mask layers. Preserves all input features and '
            'filters sliver intersections using the detail coefficient threshold.'
        )

    def createInstance(self):
        return OverlapStandardAlgorithm()


class OverlapGroupedAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OVERLAY = 'OVERLAY'
    GROUP_FIELD = 'GROUP_FIELD'
    FIELD_PREFIX = 'FIELD_PREFIX'
    STRIP_ASTERISKS = 'STRIP_ASTERISKS'
    DETAIL_COEFF = 'DETAIL_COEFF'
    UNIT = 'UNIT'
    GENERATE_STATS = 'GENERATE_STATS'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                'Input polygon layer',
                [QgsProcessing.TypeVectorPolygon]
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.OVERLAY,
                'Overlay layer',
                [QgsProcessing.TypeVectorPolygon]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.GROUP_FIELD,
                'Group overlay features by field',
                parentLayerParameterName=self.OVERLAY,
                optional=False
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.FIELD_PREFIX,
                'Prefix for result fields',
                defaultValue='Ülekate_'
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.STRIP_ASTERISKS,
                'Merge priority asterisks (*) and trim whitespace',
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DETAIL_COEFF,
                'Detail coefficient / Minimum overlap threshold (ha)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.001
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                'Area unit',
                options=['Hectares (ha)', 'Square meters (m²)'],
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.GENERATE_STATS,
                'Generate overall statistics report',
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                'Output layer'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        input_layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        overlay_layer = self.parameterAsVectorLayer(parameters, self.OVERLAY, context)
        group_field = self.parameterAsString(parameters, self.GROUP_FIELD, context)
        field_prefix = self.parameterAsString(parameters, self.FIELD_PREFIX, context)
        strip_asterisks = self.parameterAsBool(parameters, self.STRIP_ASTERISKS, context)
        detail_coeff = self.parameterAsDouble(parameters, self.DETAIL_COEFF, context)
        unit_idx = self.parameterAsEnum(parameters, self.UNIT, context)
        unit = "ha" if unit_idx == 0 else "m2"
        gen_stats = self.parameterAsBool(parameters, self.GENERATE_STATS, context)

        out_sink_id = parameters[self.OUTPUT]

        result_layer, stats = run_grouped_overlap(
            input_layer=input_layer,
            overlay_layer=overlay_layer,
            group_field=group_field,
            area_unit=unit,
            detail_coeff=detail_coeff,
            field_prefix=field_prefix,
            strip_asterisks=strip_asterisks,
            generate_stats=gen_stats,
            output_path=out_sink_id if isinstance(out_sink_id, str) and not out_sink_id.startswith("memory:") else None,
            feedback=feedback
        )

        return {self.OUTPUT: result_layer.id() if result_layer else None}

    def name(self):
        return 'grouped_overlap'

    def displayName(self):
        return 'Calculate Overlap (Grouped + Statistics)'

    def group(self):
        return 'Vector Overlap'

    def groupId(self):
        return 'vector_overlap'

    def shortHelpString(self):
        return (
            'Calculates planar / cartesian overlaps between input features and grouped categories of '
            'an overlay layer. Uses spatial indexing for high performance and optionally generates '
            'overall aggregate statistics for all groups.'
        )

    def createInstance(self):
        return OverlapGroupedAlgorithm()


class OverlapProcessingProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(OverlapStandardAlgorithm())
        self.addAlgorithm(OverlapGroupedAlgorithm())

    def id(self):
        return 'overlaptoolkit'

    def name(self):
        return 'Overlap Toolkit'

    def icon(self):
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'icons', 'icon.svg')
        return QIcon(icon_path)

    def longName(self):
        return 'Overlap Toolkit Processing Provider'
