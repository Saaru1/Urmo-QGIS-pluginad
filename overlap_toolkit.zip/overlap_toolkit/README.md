# Overlap Toolkit - QGIS Vektorülekatete Analüüsi Pistikprogramm / Vector Overlap Analysis Plugin

**Overlap Toolkit** on suure jõudlusega QGIS-i pistikprogramm polügoonide tavaliste ja grupeeritud ülekatete arvutamiseks, koondstatistika analüüsiks ning tulemuskihtide automaatseks kujundamiseks.

---

## 🎨 Automaatne kihtide kujundus / Automatic Layer Styling

Pistikprogramm sisaldab nüüd täielikku automaatset kujundusmootorit, mille saab sisse või välja lülitada:

### 1. Tavaline ülekate (Standard Overlap):
- **Kujunduse alus**: Vali kujundamine **ülekatte protsendi (%)** või **ülekatte pindala (ha)** järgi.
- **Sagedustabeli klassid**: Klassifitseerimine sagedussammuga (vaikimisi `10`, vabalt seadistatav):
  - **`0` on eraldi klass**: Hall / neutraalne taust ilma katteta objektidele.
  - **`1 - 10`**, **`11 - 20`**, **`21 - 30`**, jne kuni maksimumini.
  - Värvitoonid heledast tumedani (oranž-punane sujuv värvigradient).

### 2. Grupeeritud ülekate (Grouped Overlap):
- **Grupeerimisvälja järgi (vaikestiil)**:
  - Tulemuskiht saab lisaks veerud **`Peamine_grupp`** (`Dominant_Group`), **`Peamine_ülekate`** (`Dominant_Overlap`) ja **`Kogu_ülekate`** (`Total_Overlap`).
  - Iga unikaalne grupp saab oma eristuva baasvärvi.
  - **Alamstiil heledast tumedani**: Grupi sees jaotatakse objektid ülekatte väärtuse järgi heledast tumedani vastava kategooria värvitoonis!
  - **`0` on eraldi klass**: Objektid, millel ülekate puudub, on selgelt eraldatud neutraalse värviga.
- **Võimalus valida ka**: Koguülekatte sagedusklassid (`0`, `1-10`, `11-20`...).

---

## 🌐 Uued ja laiendatud funktsioonid / New & Expanded Features

1. **"Käivita" / "Run" nupp allservas (Bottom Footing)**:
   - Peamine käivitusnupp asub nüüd akna allservas nupu "Sulge" kõrval.
   - Käivitab automaatselt hetkel aktiivse vahekaardi analüüsi (Tavaline ülekate või Grupeeritud ülekate).
   - Seadete vahekaardil olles on nupp deaktiveeritud viitega valida analüüsikaart.

2. **Dokitav ja minimeeritav aken (Dockable & Minimizable Window)**:
   - Tööriist on realiseeritud `QgsDockWidget` komponendina.
   - **Dokitav**: Kinnitub QGIS-i küljepaneelide (nt parem või vasak külgriba) või vahekaartide külge.
   - **Hõljuv ja minimeeritav**: Päises asuva nupu abil saab akna igal hetkel vabalt hõljuma panna (`Float Window`), seda Windowsi tegumiribale minimeerida, suurendada või tagasi dokkida.
   - Mõõtmed ja kerimisalad kohanduvad sujuvalt ka kitsal ekraanil.

3. **Sisendkihtide lisamine otse arvutist (From PC)**:
   - Sisendi ja kattekihi valiku kõrval on nupp **`📁 Fail...`** (`📁 File...`).
   - Võimaldab valida vektorfaili (`.gpkg`, `.shp`, `.geojson`, `.kml` jne) otse kettalt ilma seda eelnevalt QGIS-i projekti avamata.
   - Mitmekihiliste failide (nt GeoPackage) puhul pakub dialoog soovitud polügoonikihi valikut ning lisab selle automaatselt kaardile ja valikusse.

4. **Kihtide valimine otse WFS kataloogist (WFS Catalog Integration)**:
   - Nupu **`🌐 WFS...`** abil avaneb sisseehitatud WFS teenuste kataloog.
   - **Eesti ametlikud vaikeserverid**:
     - *EELIS (Avalik)*: Kaitstavad loodusobjektid, elupaigad, veekogud jpm.
     - *EELIS (Sise)*: Sisevõrgu kihid.
     - *Maa-amet Kataster*: Katastriüksused, piirid, kitsendused.
     - *PRIA (Avalik)*: Põllumajandusmassiivid, toetusõiguslikud maad.
     - *Eesti Topo (ETAK)*: Pinnakatted, hooned, teed, veed.
   - **Võimalused**:
     - Reaalajas kiirotsing ja filtreerimine nime või pealkirja järgi.
     - Kohandatud WFS serverite lisamine ja salvestamine.
     - Päringu piiramine kaardi vaateväljaga (`restrictToRequestBBOX`), mis väldib hiiglaslike andmemahtude allalaadimist.
     - Valitud kiht luuakse automaatselt WFS vektorina ja seatakse analüüsi sisendiks.

5. **Keelte lüliti (EST & ENG)**:
   - Kiirlüliti päises ja seadetes.
   - **EST režiimis**: `Ülekate_ha`, `Ülekate_%`, `Ülekate_`.
   - **ENG režiimis**: `Overlap_ha`, `Overlap_%`, `Overlap_`.

2. **Värviteemad (Hele, Tume, Süsteemi vaike)**:
   - Kõrge kontrastiga stiilid tagavad, et valget teksti heledal taustal ega tumedat teksti tumedal taustal ei teki.

3. **Kartesiaalne pindala**:
   - Arvutus kasutab rangelt tasapinnalist kartesiaalset pindala (`inter.cartesianArea()`).

4. **Taustatöö koos % ja dünaamilise ETA-ga**:
   - Reaalajas järelejäänud aja prognoos (nt `40% (Jäänud: 00:15)`).

---

## ⚡ Jõudluse võrdlus / Performance Benchmarks

Testandmed: `A:\Overlapp\Test Data` (6 135 toetusala ja 81 283 elupaika):
- Algne Script 2: ~30-45 minutit (indekseerimata $498\text{M}$ kontrolli).
- **Overlap Toolkit**: **13,2 sekundit** (ruumiline indeks `QgsSpatialIndex`).
- **Tulemused**: **100% identsed algse skriptiga**.
