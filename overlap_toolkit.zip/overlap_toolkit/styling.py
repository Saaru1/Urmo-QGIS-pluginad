# -*- coding: utf-8 -*-
"""
Automatic Layer Styling for Overlap Suite
- Standard Overlap: Frequency table by overlap area or percentage, step (default 10), 0 as separate class.
- Grouped Overlap: Categorized by grouping field (dominant group), sub-styled light to dark by overlap value, 0 as separate class.
"""

import math
from qgis.core import (
    QgsVectorLayer,
    QgsRuleBasedRenderer,
    QgsFillSymbol
)
from qgis.PyQt.QtGui import QColor

# Vibrant, visually distinct palette for categorical grouping
CATEGORICAL_PALETTE = [
    "#3366CC", "#DC3912", "#FF9900", "#109618", "#990099",
    "#0099C6", "#DD4477", "#66AA00", "#B82E2E", "#316395",
    "#994499", "#22AA99", "#AAAA11", "#6633CC", "#E67300",
    "#8B0707", "#329262", "#5574A6", "#3B3EAC", "#1A8554"
]


def apply_standard_overlap_styling(layer, value_field, step=10):
    """
    Applies frequency table styling for standard overlap results.
    - Class 0 is separate (neutral / transparent / light gray).
    - Other classes are equal frequency intervals: 1-step, (step+1)-2*step, etc.
    - Shaded from light to dark.
    """
    if not layer or not layer.isValid():
        return None

    step = max(1, int(step))
    root_rule = QgsRuleBasedRenderer.Rule(None)

    # 1. Class 0 (Separate class)
    sym_zero = QgsFillSymbol.createSimple({
        'color': '#f2f2f2',
        'outline_color': '#b0b0b0',
        'outline_width': '0.26'
    })
    rule_zero = QgsRuleBasedRenderer.Rule(
        sym_zero, 0, 0,
        f'"{value_field}" <= 0 OR "{value_field}" IS NULL',
        '0'
    )
    root_rule.appendChild(rule_zero)

    # 2. Determine maximum value
    is_percent = ("%" in value_field or "pc" in value_field.lower())
    if is_percent:
        max_val = 100.0
    else:
        vals = [f[value_field] for f in layer.getFeatures() if f[value_field] is not None]
        max_val = max(vals) if vals else 50.0
        max_val = max(float(step), math.ceil(max_val / float(step)) * float(step))

    num_classes = int(math.ceil(max_val / float(step)))
    
    # Warm sequential gradient: Light Cream / Orange to Deep Red
    start_color = QColor(254, 237, 222)
    end_color = QColor(166, 54, 3)

    current = 0.0
    for i in range(num_classes):
        high = min(max_val, current + step)
        ratio = (i + 1) / float(num_classes)
        
        r = int(start_color.red() + ratio * (end_color.red() - start_color.red()))
        g = int(start_color.green() + ratio * (end_color.green() - start_color.green()))
        b = int(start_color.blue() + ratio * (end_color.blue() - start_color.blue()))
        col = QColor(r, g, b)

        sym = QgsFillSymbol.createSimple({
            'color': col.name(),
            'outline_color': '#555555',
            'outline_width': '0.2'
        })

        if current == 0.0:
            filter_expr = f'"{value_field}" > 0 AND "{value_field}" <= {int(high)}'
            label = f'1 - {int(high)}'
        else:
            filter_expr = f'"{value_field}" > {int(current)} AND "{value_field}" <= {int(high)}'
            label = f'{int(current)+1} - {int(high)}'

        rule = QgsRuleBasedRenderer.Rule(sym, 0, 0, filter_expr, label)
        root_rule.appendChild(rule)
        current = high

    renderer = QgsRuleBasedRenderer(root_rule)
    layer.setRenderer(renderer)
    layer.triggerRepaint()
    return renderer


def apply_grouped_overlap_styling(
    layer,
    group_col,
    val_col,
    step=10,
    style_type="categorized"
):
    """
    Applies styling for grouped overlap results:
    - Default ("categorized"): Categorized by the grouping field (dominant group),
      sub-styled from light to dark (category base color) based on overlap value.
      Class 0 is separate.
    - "frequency": Frequency classes (0, 1-step, ...) based on the value column (total/dominant overlap).
    """
    if not layer or not layer.isValid():
        return None

    step = max(1, int(step))
    root_rule = QgsRuleBasedRenderer.Rule(None)

    # 1. Class 0 (Separate class for zero/no overlap)
    sym_zero = QgsFillSymbol.createSimple({
        'color': '#f2f2f2',
        'outline_color': '#b0b0b0',
        'outline_width': '0.26'
    })
    rule_zero = QgsRuleBasedRenderer.Rule(
        sym_zero, 0, 0,
        f'"{val_col}" <= 0 OR "{val_col}" IS NULL',
        '0'
    )
    root_rule.appendChild(rule_zero)

    if style_type == "frequency":
        # Pure frequency intervals on val_col
        vals = [f[val_col] for f in layer.getFeatures() if f[val_col] is not None]
        max_val = max(vals) if vals else 50.0
        max_val = max(float(step), math.ceil(max_val / float(step)) * float(step))
        num_classes = int(math.ceil(max_val / float(step)))

        start_color = QColor(235, 248, 255)
        end_color = QColor(8, 69, 148)

        current = 0.0
        for i in range(num_classes):
            high = min(max_val, current + step)
            ratio = (i + 1) / float(num_classes)
            r = int(start_color.red() + ratio * (end_color.red() - start_color.red()))
            g = int(start_color.green() + ratio * (end_color.green() - start_color.green()))
            b = int(start_color.blue() + ratio * (end_color.blue() - start_color.blue()))
            col = QColor(r, g, b)

            sym = QgsFillSymbol.createSimple({
                'color': col.name(),
                'outline_color': '#555555',
                'outline_width': '0.2'
            })

            if current == 0.0:
                filter_expr = f'"{val_col}" > 0 AND "{val_col}" <= {int(high)}'
                label = f'1 - {int(high)}'
            else:
                filter_expr = f'"{val_col}" > {int(current)} AND "{val_col}" <= {int(high)}'
                label = f'{int(current)+1} - {int(high)}'

            rule = QgsRuleBasedRenderer.Rule(sym, 0, 0, filter_expr, label)
            root_rule.appendChild(rule)
            current = high

    else:
        # Categorized by grouping field, sub-style light to dark
        groups = sorted(list(set(
            str(f[group_col]).strip() for f in layer.getFeatures()
            if f[group_col] not in (None, "", "NULL")
        )))

        for g_idx, gv in enumerate(groups):
            base_hex = CATEGORICAL_PALETTE[g_idx % len(CATEGORICAL_PALETTE)]
            base_color = QColor(base_hex)

            # Find maximum value for this group
            group_vals = [
                float(f[val_col]) for f in layer.getFeatures()
                if str(f[group_col]).strip() == gv and f[val_col] is not None
            ]
            max_v = max(group_vals) if group_vals else float(step)
            num_sub = max(2, min(5, int(math.ceil(max_v / float(step)))))

            # Parent rule acts as the category heading in legend
            cat_rule = QgsRuleBasedRenderer.Rule(
                None, 0, 0,
                f'"{group_col}" = \'{gv}\'',
                str(gv)
            )

            current = 0.0
            for s_idx in range(num_sub):
                high = current + step
                is_last = (s_idx == num_sub - 1)

                # Shading from light (high lightness) to dark (saturated/deep)
                col = QColor(base_color)
                if num_sub > 1:
                    frac = s_idx / float(num_sub - 1)
                    # 170% lightness for lowest down to 90% for highest
                    light_factor = int(170 - frac * 80)
                    col = col.lighter(light_factor)

                sym = QgsFillSymbol.createSimple({
                    'color': col.name(),
                    'outline_color': '#444444',
                    'outline_width': '0.2'
                })

                if current == 0.0:
                    if is_last:
                        f_expr = f'"{group_col}" = \'{gv}\' AND "{val_col}" > 0'
                        lbl = f'1 - {int(high)}'
                    else:
                        f_expr = f'"{group_col}" = \'{gv}\' AND "{val_col}" > 0 AND "{val_col}" <= {int(high)}'
                        lbl = f'1 - {int(high)}'
                else:
                    if is_last:
                        f_expr = f'"{group_col}" = \'{gv}\' AND "{val_col}" > {int(current)}'
                        lbl = f'> {int(current)}'
                    else:
                        f_expr = f'"{group_col}" = \'{gv}\' AND "{val_col}" > {int(current)} AND "{val_col}" <= {int(high)}'
                        lbl = f'{int(current)+1} - {int(high)}'

                sub_rule = QgsRuleBasedRenderer.Rule(sym, 0, 0, f_expr, lbl)
                cat_rule.appendChild(sub_rule)
                current = high

            root_rule.appendChild(cat_rule)

    renderer = QgsRuleBasedRenderer(root_rule)
    layer.setRenderer(renderer)
    layer.triggerRepaint()
    return renderer
