# -*- coding: utf-8 -*-
"""
Cross-version compatibility module for QGIS 3 (PyQt5) and QGIS 4 (PyQt6 / Qt6).
Handles strictly-scoped enums across Qt versions cleanly and safely.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QMessageBox, QLineEdit, QHeaderView, QFrame,
    QDockWidget, QAbstractItemView, QTreeWidgetItem
)
from qgis.core import QgsWkbTypes, QgsTask, QgsMapLayerProxyModel
from qgis.gui import QgsFileWidget

# --- QDialog DialogCode ---
QDIALOG_ACCEPTED = getattr(QDialog, 'Accepted', getattr(getattr(QDialog, 'DialogCode', None), 'Accepted', 1))
QDIALOG_REJECTED = getattr(QDialog, 'Rejected', getattr(getattr(QDialog, 'DialogCode', None), 'Rejected', 0))

# --- QMessageBox StandardButton ---
QMESSAGEBOX_YES = getattr(QMessageBox, 'Yes', getattr(getattr(QMessageBox, 'StandardButton', None), 'Yes', 0x00004000))
QMESSAGEBOX_NO = getattr(QMessageBox, 'No', getattr(getattr(QMessageBox, 'StandardButton', None), 'No', 0x00010000))
QMESSAGEBOX_OK = getattr(QMessageBox, 'Ok', getattr(getattr(QMessageBox, 'StandardButton', None), 'Ok', 0x00000400))
QMESSAGEBOX_CANCEL = getattr(QMessageBox, 'Cancel', getattr(getattr(QMessageBox, 'StandardButton', None), 'Cancel', 0x00400000))

# --- QLineEdit EchoMode ---
QLINEEDIT_NORMAL = getattr(QLineEdit, 'Normal', getattr(getattr(QLineEdit, 'EchoMode', None), 'Normal', 0))

# --- Qt CursorShape ---
QT_WAIT_CURSOR = getattr(Qt, 'WaitCursor', getattr(getattr(Qt, 'CursorShape', None), 'WaitCursor', 3))
QT_ARROW_CURSOR = getattr(Qt, 'ArrowCursor', getattr(getattr(Qt, 'CursorShape', None), 'ArrowCursor', 0))

# --- Qt AlignmentFlag ---
QT_ALIGN_RIGHT = getattr(Qt, 'AlignRight', getattr(getattr(Qt, 'AlignmentFlag', None), 'AlignRight', 0x0002))
QT_ALIGN_VCENTER = getattr(Qt, 'AlignVCenter', getattr(getattr(Qt, 'AlignmentFlag', None), 'AlignVCenter', 0x0080))
QT_ALIGN_CENTER = getattr(Qt, 'AlignCenter', getattr(getattr(Qt, 'AlignmentFlag', None), 'AlignCenter', 0x0084))

# --- Qt UserRole ---
QT_USER_ROLE = getattr(Qt, 'UserRole', getattr(getattr(Qt, 'ItemDataRole', None), 'UserRole', 32))

# --- QHeaderView ResizeMode ---
QT_HEADER_STRETCH = getattr(QHeaderView, 'Stretch', getattr(getattr(QHeaderView, 'ResizeMode', None), 'Stretch', 1))

# --- QFrame Shape ---
QFRAME_NO_FRAME = getattr(QFrame, 'NoFrame', getattr(getattr(QFrame, 'Shape', None), 'NoFrame', 0))

# --- QDockWidget Features & Areas ---
_feat = getattr(QDockWidget, 'DockWidgetFeature', QDockWidget)
QDOCK_FEATURES = (
    getattr(_feat, 'DockWidgetMovable') |
    getattr(_feat, 'DockWidgetFloatable') |
    getattr(_feat, 'DockWidgetClosable')
)
_dock_area = getattr(Qt, 'DockWidgetArea', Qt)
QT_RIGHT_DOCK_WIDGET_AREA = getattr(_dock_area, 'RightDockWidgetArea', getattr(Qt, 'RightDockWidgetArea', 2))

# --- Qt Window Flags ---
_w_type = getattr(Qt, 'WindowType', Qt)
QT_WINDOW_FLAGS = (
    getattr(_w_type, 'Window') |
    getattr(_w_type, 'WindowMinimizeButtonHint') |
    getattr(_w_type, 'WindowMaximizeButtonHint') |
    getattr(_w_type, 'WindowCloseButtonHint')
)

# --- Qt Widget Attributes ---
QT_WA_STYLED_BACKGROUND = getattr(Qt, 'WA_StyledBackground', getattr(getattr(Qt, 'WidgetAttribute', None), 'WA_StyledBackground', 23))

# --- QGIS Specific Enums ---
QGS_FILE_SAVE = getattr(QgsFileWidget, 'SaveFile', getattr(getattr(QgsFileWidget, 'StorageMode', None), 'SaveFile', 3))
QGS_POLYGON_FILTER = getattr(QgsMapLayerProxyModel, 'PolygonLayer', getattr(getattr(QgsMapLayerProxyModel, 'Filter', None), 'PolygonLayer', None))
QGS_WKB_POLYGON = getattr(QgsWkbTypes, 'PolygonGeometry', getattr(getattr(QgsWkbTypes, 'GeometryType', None), 'PolygonGeometry', 2))
QGS_TASK_CANCEL = getattr(QgsTask, 'CanCancel', getattr(getattr(QgsTask, 'Flag', None), 'CanCancel', 1))
