# -*- coding: utf-8 -*-
"""
Overlap Suite Main Dialog with 3 Panels:
1. Standard Overlap
2. Grouped Overlap & Overall Statistics
3. Settings & Preferences

Includes:
- Dynamic EST / ENG Language Support
- Dark / Light / System Mode with Contrast Protection
- Cartesian Area Calculation
- Background Processing with Progress % and Dynamic ETA
- Automatic Layer Styling:
  - Standard Overlap: Frequency table by overlap area or %, step (default 10), 0 as separate class.
  - Grouped Overlap: Categorized by grouping field, sub-style light-to-dark by overlap value, 0 as separate class.
"""

import os
import csv
import time
from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtGui import QIcon, QFont, QColor
from qgis.PyQt.QtWidgets import (
    QDialog, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QFormLayout, QLabel, QLineEdit, QDoubleSpinBox,
    QSpinBox, QComboBox, QCheckBox, QPushButton, QProgressBar,
    QGroupBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QFileDialog, QApplication, QSplitter, QFrame,
    QScrollArea, QDockWidget, QInputDialog
)
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsMapLayerProxyModel,
    QgsApplication, QgsTask, QgsProcessingFeedback, QgsSettings,
    QgsWkbTypes, QgsProviderRegistry
)
from qgis.gui import QgsDockWidget, QgsMapLayerComboBox, QgsFieldComboBox, QgsFileWidget

from .algorithms.standard_overlap import run_standard_overlap
from .algorithms.grouped_overlap import run_grouped_overlap, create_statistics_table_layer
from .styling import apply_standard_overlap_styling, apply_grouped_overlap_styling
from .i18n import TRANSLATIONS, LIGHT_STYLESHEET, DARK_STYLESHEET, get_translation
from .wfs_catalog import WfsCatalogDialog
from .compat import (
    QDIALOG_ACCEPTED, QDIALOG_REJECTED, QMESSAGEBOX_YES, QMESSAGEBOX_NO,
    QMESSAGEBOX_OK, QMESSAGEBOX_CANCEL, QLINEEDIT_NORMAL, QT_WAIT_CURSOR,
    QT_ARROW_CURSOR, QT_ALIGN_RIGHT, QT_ALIGN_VCENTER, QT_ALIGN_CENTER,
    QT_USER_ROLE, QT_HEADER_STRETCH, QFRAME_NO_FRAME, QDOCK_FEATURES,
    QT_RIGHT_DOCK_WIDGET_AREA, QT_WINDOW_FLAGS, QT_WA_STYLED_BACKGROUND,
    QGS_FILE_SAVE, QGS_POLYGON_FILTER, QGS_WKB_POLYGON, QGS_TASK_CANCEL
)

# Qt5 / Qt6 compatibility aliases
ALIGN_RIGHT = QT_ALIGN_RIGHT
ALIGN_VCENTER = QT_ALIGN_VCENTER
HEADER_STRETCH = QT_HEADER_STRETCH
FRAME_NO_FRAME = QFRAME_NO_FRAME
FILE_SAVE = QGS_FILE_SAVE
POLYGON_FILTER = QGS_POLYGON_FILTER


class WorkerTask(QgsTask):
    """Background task to execute overlap algorithms without blocking the GUI."""
    def __init__(self, description, target_func, kwargs, on_progress_callback, on_success_callback, on_error_callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.target_func = target_func
        self.kwargs = kwargs
        self.on_progress_callback = on_progress_callback
        self.on_success_callback = on_success_callback
        self.on_error_callback = on_error_callback
        self.result = None
        self.error_msg = None

        class TaskFeedback(QgsProcessingFeedback):
            def __init__(self, task):
                super().__init__()
                self.task = task
            def setProgress(self, progress):
                self.task.setProgress(progress)
            def isCanceled(self):
                return self.task.isCanceled()
            def pushInfo(self, info):
                pass

        self.feedback = TaskFeedback(self)
        self.kwargs['feedback'] = self.feedback

    def run(self):
        try:
            self.result = self.target_func(**self.kwargs)
            return bool(self.result is not None)
        except Exception as e:
            import traceback
            self.error_msg = f"{str(e)}\n\n{traceback.format_exc()}"
            return False

    def finished(self, result):
        if self.isCanceled():
            if self.on_error_callback:
                self.on_error_callback("CANCELED")
        elif result:
            if self.on_success_callback:
                self.on_success_callback(self.result)
        else:
            if self.on_error_callback:
                self.on_error_callback(self.error_msg or "Unknown error occurred.")


class OverlapToolkitDockWidget(QgsDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Overlap Toolkit", parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.setObjectName("OverlapToolkitDockWidget")

        # Set dock widget features: Movable, Floatable, Closable
        self.setFeatures(QDOCK_FEATURES)
        self.topLevelChanged.connect(self.on_top_level_changed)

        self.current_task = None
        self.task_start_time = None
        self.last_grouped_stats = None
        self.current_lang = "est"
        self.current_theme = "system"

        self.plugin_dir = os.path.dirname(__file__)
        self.icon_path = os.path.join(self.plugin_dir, "icons", "icon.svg")
        if not os.path.exists(self.icon_path):
            self.icon_path = os.path.join(self.plugin_dir, "icons", "icon.png")

        self.setWindowTitle("Overlap Toolkit")
        self.setWindowIcon(QIcon(self.icon_path))
        self.resize(840, 740)

        self.init_ui()
        self.load_settings()
        self.apply_theme(self.current_theme)
        self.retranslate_ui()
        self.setup_connections()

    def t(self, key):
        return get_translation(key, self.current_lang)

    # -------------------------------------------------------------
    # UI CONSTRUCTION
    # -------------------------------------------------------------
    def init_ui(self):
        self.main_container = QWidget()
        self.main_container.setObjectName("mainDockContainer")
        self.main_container.setAttribute(QT_WA_STYLED_BACKGROUND, True)
        self.main_container.setAutoFillBackground(True)
        self.setWidget(self.main_container)

        main_layout = QVBoxLayout(self.main_container)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Header Banner with Title and Quick Controls
        self.header_frame = QFrame()
        self.header_frame.setObjectName("headerBanner")
        self.header_frame.setAttribute(QT_WA_STYLED_BACKGROUND, True)
        self.header_frame.setAutoFillBackground(True)
        self.header_frame.setFrameShape(FRAME_NO_FRAME)

        header_layout = QHBoxLayout(self.header_frame)
        header_layout.setContentsMargins(0, 0, 0, 4)

        icon_label = QLabel()
        icon_label.setPixmap(QIcon(self.icon_path).pixmap(42, 42))
        header_layout.addWidget(icon_label)

        title_layout = QVBoxLayout()
        self.lbl_title = QLabel("Overlap Toolkit")
        self.lbl_title.setObjectName("headerTitle")
        title_font = QFont()
        title_font.setPointSize(13)
        title_font.setBold(True)
        self.lbl_title.setFont(title_font)

        self.lbl_subtitle = QLabel("Vector Overlap, Grouped Overlap & Aggregate Statistics")
        self.lbl_subtitle.setObjectName("headerSubtitle")
        title_layout.addWidget(self.lbl_title)
        title_layout.addWidget(self.lbl_subtitle)
        header_layout.addLayout(title_layout)

        header_layout.addStretch()

        # Top Quick Selectors: Language, Theme & Dock/Float
        top_ctrl_box = QHBoxLayout()
        top_ctrl_box.setSpacing(6)

        self.cmb_quick_lang = QComboBox()
        self.cmb_quick_lang.addItems(["🇪🇪 Eesti (EST)", "🇬🇧 English (ENG)"])
        self.cmb_quick_lang.setToolTip("Switch Language / Vali keel")
        top_ctrl_box.addWidget(self.cmb_quick_lang)

        self.cmb_quick_theme = QComboBox()
        self.cmb_quick_theme.addItems(["Auto (System)", "☀️ Light", "🌙 Dark"])
        self.cmb_quick_theme.setToolTip("Color Theme / Värviteema")
        top_ctrl_box.addWidget(self.cmb_quick_theme)

        self.btn_dock_toggle = QPushButton("🗖 " + self.t("float_window"))
        self.btn_dock_toggle.setToolTip(self.t("btn_dock_toggle"))
        self.btn_dock_toggle.clicked.connect(self.toggle_dock_mode)
        top_ctrl_box.addWidget(self.btn_dock_toggle)

        header_layout.addLayout(top_ctrl_box)
        main_layout.addWidget(self.header_frame)

        # Tabs
        self.tabs = QTabWidget()
        self.tab_standard = QWidget()
        self.tab_grouped = QWidget()
        self.tab_settings = QWidget()

        self.init_standard_tab()
        self.init_grouped_tab()
        self.init_settings_tab()

        self.tabs.addTab(self.tab_standard, "1. Overlap (Standard)")
        self.tabs.addTab(self.tab_grouped, "2. Overlap Grouped (+ Statistics)")
        self.tabs.addTab(self.tab_settings, "3. Settings")
        main_layout.addWidget(self.tabs)

        # Bottom Progress Bar & Real-time ETA Status
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.hide()
        main_layout.addWidget(self.progress_bar)

        self.status_label = QLabel("Ready")
        self.status_label.setObjectName("statusLabel")
        main_layout.addWidget(self.status_label)

        # Bottom Buttons
        self.footer_frame = QFrame()
        self.footer_frame.setObjectName("footerBar")
        self.footer_frame.setAttribute(QT_WA_STYLED_BACKGROUND, True)
        self.footer_frame.setAutoFillBackground(True)
        self.footer_frame.setFrameShape(FRAME_NO_FRAME)

        bottom_box = QHBoxLayout(self.footer_frame)
        bottom_box.setContentsMargins(0, 4, 0, 0)
        bottom_box.setSpacing(8)

        self.btn_run_main = QPushButton(self.t("btn_run_main"))
        self.btn_run_main.setObjectName("primaryAction")
        self.btn_run_main.setMinimumWidth(120)
        self.btn_run_main.setToolTip(self.t("tooltip_run_main"))

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.hide()
        self.btn_close = QPushButton("Close")

        bottom_box.addStretch()
        bottom_box.addWidget(self.btn_run_main)
        bottom_box.addWidget(self.btn_cancel)
        bottom_box.addWidget(self.btn_close)
        main_layout.addWidget(self.footer_frame)

    # -------------------------------------------------------------
    # TAB 1: STANDARD OVERLAP
    # -------------------------------------------------------------
    def init_standard_tab(self):
        scroll = QScrollArea(self.tab_standard)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(FRAME_NO_FRAME)
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)

        # Layers Group
        self.grp_std_layers = QGroupBox("Layers")
        form_layers = QFormLayout(self.grp_std_layers)

        self.cmb_std_input = QgsMapLayerComboBox()
        self.cmb_std_input.setFilters(POLYGON_FILTER)
        self.chk_std_input_selected = QCheckBox("Selected features only")
        self.btn_std_input_pc = QPushButton("📁 Fail...")
        self.btn_std_input_pc.setToolTip(self.t("tooltip_browse_pc"))
        self.btn_std_input_pc.clicked.connect(lambda: self.browse_layer_from_pc(self.cmb_std_input))
        self.btn_std_input_wfs = QPushButton("🌐 WFS...")
        self.btn_std_input_wfs.setToolTip(self.t("tooltip_wfs"))
        self.btn_std_input_wfs.clicked.connect(lambda: self.select_layer_from_wfs(self.cmb_std_input))

        in_box = QHBoxLayout()
        in_box.addWidget(self.cmb_std_input, 1)
        in_box.addWidget(self.btn_std_input_pc)
        in_box.addWidget(self.btn_std_input_wfs)
        in_box.addWidget(self.chk_std_input_selected)
        self.lbl_std_input = QLabel("Input polygon layer:")
        form_layers.addRow(self.lbl_std_input, in_box)

        self.cmb_std_overlay = QgsMapLayerComboBox()
        self.cmb_std_overlay.setFilters(POLYGON_FILTER)
        self.chk_std_overlay_selected = QCheckBox("Selected features only")
        self.btn_std_overlay_pc = QPushButton("📁 Fail...")
        self.btn_std_overlay_pc.setToolTip(self.t("tooltip_browse_pc"))
        self.btn_std_overlay_pc.clicked.connect(lambda: self.browse_layer_from_pc(self.cmb_std_overlay))
        self.btn_std_overlay_wfs = QPushButton("🌐 WFS...")
        self.btn_std_overlay_wfs.setToolTip(self.t("tooltip_wfs"))
        self.btn_std_overlay_wfs.clicked.connect(lambda: self.select_layer_from_wfs(self.cmb_std_overlay))

        ov_box = QHBoxLayout()
        ov_box.addWidget(self.cmb_std_overlay, 1)
        ov_box.addWidget(self.btn_std_overlay_pc)
        ov_box.addWidget(self.btn_std_overlay_wfs)
        ov_box.addWidget(self.chk_std_overlay_selected)
        self.lbl_std_overlay = QLabel("Overlay / mask layer:")
        form_layers.addRow(self.lbl_std_overlay, ov_box)

        layout.addWidget(self.grp_std_layers)

        # Parameters Group
        self.grp_std_params = QGroupBox("Calculation Parameters")
        grid_params = QGridLayout(self.grp_std_params)

        self.lbl_std_area = QLabel("Area field name:")
        grid_params.addWidget(self.lbl_std_area, 0, 0)
        self.txt_std_area_field = QLineEdit("Ülekate_ha")
        grid_params.addWidget(self.txt_std_area_field, 0, 1)

        self.lbl_std_percent = QLabel("Percentage field name:")
        grid_params.addWidget(self.lbl_std_percent, 0, 2)
        self.txt_std_percent_field = QLineEdit("Ülekate_%")
        grid_params.addWidget(self.txt_std_percent_field, 0, 3)

        self.lbl_std_detail = QLabel("Detail coefficient (min ha):")
        grid_params.addWidget(self.lbl_std_detail, 1, 0)
        self.spn_std_min_area = QDoubleSpinBox()
        self.spn_std_min_area.setRange(0.00000, 1000.0)
        self.spn_std_min_area.setDecimals(5)
        self.spn_std_min_area.setValue(0.00100)
        self.spn_std_min_area.setSingleStep(0.001)
        grid_params.addWidget(self.spn_std_min_area, 1, 1)

        self.lbl_std_unit = QLabel("Area calculation unit:")
        grid_params.addWidget(self.lbl_std_unit, 1, 2)
        self.cmb_std_unit = QComboBox()
        self.cmb_std_unit.addItems(["Hectares (ha)", "Square meters (m²)"])
        grid_params.addWidget(self.cmb_std_unit, 1, 3)

        self.lbl_std_precision = QLabel("Decimal precision:")
        grid_params.addWidget(self.lbl_std_precision, 2, 0)
        self.spn_std_precision = QSpinBox()
        self.spn_std_precision.setRange(0, 6)
        self.spn_std_precision.setValue(2)
        grid_params.addWidget(self.spn_std_precision, 2, 1)

        layout.addWidget(self.grp_std_params)

        # Styling Group
        self.grp_std_style = QGroupBox("Layer Styling Options")
        form_style = QFormLayout(self.grp_std_style)

        self.chk_std_apply_style = QCheckBox("Apply automatic styling to output layer")
        self.chk_std_apply_style.setChecked(True)
        self.chk_std_apply_style.setStyleSheet("font-weight: bold;")
        form_style.addRow(self.chk_std_apply_style)

        style_row = QHBoxLayout()
        self.lbl_std_style_by = QLabel("Style by:")
        self.cmb_std_style_by = QComboBox()
        self.cmb_std_style_by.addItems(["Overlap Percentage (%)", "Overlap Area (ha)"])
        style_row.addWidget(self.lbl_std_style_by)
        style_row.addWidget(self.cmb_std_style_by, 1)

        self.lbl_std_style_step = QLabel("Frequency step:")
        self.spn_std_style_step = QSpinBox()
        self.spn_std_style_step.setRange(1, 1000)
        self.spn_std_style_step.setValue(10)
        style_row.addWidget(self.lbl_std_style_step)
        style_row.addWidget(self.spn_std_style_step)

        form_style.addRow("", style_row)
        layout.addWidget(self.grp_std_style)

        # Output Group
        self.grp_std_output = QGroupBox("Output")
        form_out = QFormLayout(self.grp_std_output)

        self.file_std_output = QgsFileWidget()
        self.file_std_output.setStorageMode(FILE_SAVE)
        self.file_std_output.setFilter("GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson)")
        self.file_std_output.setDefaultRoot(QgsProject.instance().homePath() or "")
        self.lbl_std_save = QLabel("Save to file (leave empty for memory layer):")
        form_out.addRow(self.lbl_std_save, self.file_std_output)

        self.chk_std_open_output = QCheckBox("Open output layer after running")
        self.chk_std_open_output.setChecked(True)
        form_out.addRow("", self.chk_std_open_output)

        layout.addWidget(self.grp_std_output)
        layout.addStretch()

        scroll.setWidget(container)
        tab_layout = QVBoxLayout(self.tab_standard)
        tab_layout.setContentsMargins(0, 0, 0, 0)
        tab_layout.addWidget(scroll)

    # -------------------------------------------------------------
    # TAB 2: GROUPED OVERLAP & STATISTICS
    # -------------------------------------------------------------
    def init_grouped_tab(self):
        scroll = QScrollArea(self.tab_grouped)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(FRAME_NO_FRAME)
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)

        # Layers Group
        self.grp_grp_layers = QGroupBox("Layers & Grouping")
        form_layers = QFormLayout(self.grp_grp_layers)

        self.cmb_grp_input = QgsMapLayerComboBox()
        self.cmb_grp_input.setFilters(POLYGON_FILTER)
        self.chk_grp_input_selected = QCheckBox("Selected features only")
        self.btn_grp_input_pc = QPushButton("📁 Fail...")
        self.btn_grp_input_pc.setToolTip(self.t("tooltip_browse_pc"))
        self.btn_grp_input_pc.clicked.connect(lambda: self.browse_layer_from_pc(self.cmb_grp_input))
        self.btn_grp_input_wfs = QPushButton("🌐 WFS...")
        self.btn_grp_input_wfs.setToolTip(self.t("tooltip_wfs"))
        self.btn_grp_input_wfs.clicked.connect(lambda: self.select_layer_from_wfs(self.cmb_grp_input))

        in_box = QHBoxLayout()
        in_box.addWidget(self.cmb_grp_input, 1)
        in_box.addWidget(self.btn_grp_input_pc)
        in_box.addWidget(self.btn_grp_input_wfs)
        in_box.addWidget(self.chk_grp_input_selected)
        self.lbl_grp_input = QLabel("Input polygon layer:")
        form_layers.addRow(self.lbl_grp_input, in_box)

        self.cmb_grp_overlay = QgsMapLayerComboBox()
        self.cmb_grp_overlay.setFilters(POLYGON_FILTER)
        self.chk_grp_overlay_selected = QCheckBox("Selected features only")
        self.btn_grp_overlay_pc = QPushButton("📁 Fail...")
        self.btn_grp_overlay_pc.setToolTip(self.t("tooltip_browse_pc"))
        self.btn_grp_overlay_pc.clicked.connect(lambda: self.browse_layer_from_pc(self.cmb_grp_overlay))
        self.btn_grp_overlay_wfs = QPushButton("🌐 WFS...")
        self.btn_grp_overlay_wfs.setToolTip(self.t("tooltip_wfs"))
        self.btn_grp_overlay_wfs.clicked.connect(lambda: self.select_layer_from_wfs(self.cmb_grp_overlay))

        ov_box = QHBoxLayout()
        ov_box.addWidget(self.cmb_grp_overlay, 1)
        ov_box.addWidget(self.btn_grp_overlay_pc)
        ov_box.addWidget(self.btn_grp_overlay_wfs)
        ov_box.addWidget(self.chk_grp_overlay_selected)
        self.lbl_grp_overlay = QLabel("Overlay layer:")
        form_layers.addRow(self.lbl_grp_overlay, ov_box)

        self.cmb_grp_field = QgsFieldComboBox()
        self.lbl_grp_field = QLabel("Grouping field:")
        form_layers.addRow(self.lbl_grp_field, self.cmb_grp_field)

        layout.addWidget(self.grp_grp_layers)

        # Options Group
        self.grp_grp_options = QGroupBox("Grouping & Calculation Options")
        grid_params = QGridLayout(self.grp_grp_options)

        self.lbl_grp_prefix = QLabel("Result field prefix:")
        grid_params.addWidget(self.lbl_grp_prefix, 0, 0)
        self.txt_grp_prefix = QLineEdit("Ülekate_")
        grid_params.addWidget(self.txt_grp_prefix, 0, 1)

        self.lbl_grp_detail = QLabel("Detail coefficient (min ha):")
        grid_params.addWidget(self.lbl_grp_detail, 0, 2)
        self.spn_grp_detail_coeff = QDoubleSpinBox()
        self.spn_grp_detail_coeff.setRange(0.00000, 1000.0)
        self.spn_grp_detail_coeff.setDecimals(5)
        self.spn_grp_detail_coeff.setValue(0.00100)
        self.spn_grp_detail_coeff.setSingleStep(0.001)
        grid_params.addWidget(self.spn_grp_detail_coeff, 0, 3)

        self.chk_grp_strip_asterisk = QCheckBox("Merge priority asterisks (*) and trim whitespace")
        self.chk_grp_strip_asterisk.setChecked(True)
        grid_params.addWidget(self.chk_grp_strip_asterisk, 1, 0, 1, 2)

        self.chk_grp_only_active = QCheckBox("Only add columns for groups with overlap > 0")
        self.chk_grp_only_active.setChecked(True)
        grid_params.addWidget(self.chk_grp_only_active, 1, 2, 1, 2)

        self.lbl_grp_unit = QLabel("Area unit:")
        grid_params.addWidget(self.lbl_grp_unit, 2, 0)
        self.cmb_grp_unit = QComboBox()
        self.cmb_grp_unit.addItems(["Hectares (ha)", "Square meters (m²)"])
        grid_params.addWidget(self.cmb_grp_unit, 2, 1)

        self.lbl_grp_precision = QLabel("Decimal precision:")
        grid_params.addWidget(self.lbl_grp_precision, 2, 2)
        self.spn_grp_precision = QSpinBox()
        self.spn_grp_precision.setRange(0, 6)
        self.spn_grp_precision.setValue(2)
        grid_params.addWidget(self.spn_grp_precision, 2, 3)

        layout.addWidget(self.grp_grp_options)

        # Grouped Styling Group
        self.grp_grp_style = QGroupBox("Layer Styling Options")
        form_grp_style = QFormLayout(self.grp_grp_style)

        self.chk_grp_apply_style = QCheckBox("Apply automatic styling to output layer")
        self.chk_grp_apply_style.setChecked(True)
        self.chk_grp_apply_style.setStyleSheet("font-weight: bold;")
        form_grp_style.addRow(self.chk_grp_apply_style)

        style_grp_row = QHBoxLayout()
        self.lbl_grp_style_by = QLabel("Style by:")
        self.cmb_grp_style_mode = QComboBox()
        self.cmb_grp_style_mode.addItems([
            "Categorized by grouping field (light-to-dark by overlap, 0 separate)",
            "Frequency classes by total overlap (0, 1-10, ...)"
        ])
        style_grp_row.addWidget(self.lbl_grp_style_by)
        style_grp_row.addWidget(self.cmb_grp_style_mode, 1)

        self.lbl_grp_style_step = QLabel("Frequency step:")
        self.spn_grp_style_step = QSpinBox()
        self.spn_grp_style_step.setRange(1, 1000)
        self.spn_grp_style_step.setValue(10)
        style_grp_row.addWidget(self.lbl_grp_style_step)
        style_grp_row.addWidget(self.spn_grp_style_step)

        form_grp_style.addRow("", style_grp_row)
        layout.addWidget(self.grp_grp_style)

        # Overall Statistics Group
        self.grp_grp_stats = QGroupBox("Overall Statistics")
        form_stats_opt = QFormLayout(self.grp_grp_stats)

        self.chk_grp_generate_stats = QCheckBox("Generate overall statistics (treat input features as a whole)")
        self.chk_grp_generate_stats.setChecked(True)
        self.chk_grp_generate_stats.setStyleSheet("font-weight: bold;")
        form_stats_opt.addRow(self.chk_grp_generate_stats)

        self.chk_grp_add_stats_layer = QCheckBox("Add overall statistics table as layer to QGIS project")
        self.chk_grp_add_stats_layer.setChecked(True)
        form_stats_opt.addRow("", self.chk_grp_add_stats_layer)

        layout.addWidget(self.grp_grp_stats)

        # Output Group
        self.grp_grp_output = QGroupBox("Output")
        form_out = QFormLayout(self.grp_grp_output)

        self.file_grp_output = QgsFileWidget()
        self.file_grp_output.setStorageMode(FILE_SAVE)
        self.file_grp_output.setFilter("GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson)")
        self.file_grp_output.setDefaultRoot(QgsProject.instance().homePath() or "")
        self.lbl_grp_save = QLabel("Save to file (leave empty for memory layer):")
        form_out.addRow(self.lbl_grp_save, self.file_grp_output)

        self.chk_grp_open_output = QCheckBox("Open output layer after running")
        self.chk_grp_open_output.setChecked(True)
        form_out.addRow("", self.chk_grp_open_output)

        layout.addWidget(self.grp_grp_output)

        # Interactive Statistics Results Section
        self.grp_stats_display = QGroupBox("Overall Statistics Results")
        stats_display_layout = QVBoxLayout(self.grp_stats_display)

        self.lbl_stats_summary = QLabel("Run grouped overlap to view overall statistics.")
        self.lbl_stats_summary.setStyleSheet("font-weight: bold;")
        stats_display_layout.addWidget(self.lbl_stats_summary)

        # Filter bar
        filter_box = QHBoxLayout()
        self.lbl_stats_filter = QLabel("Filter group:")
        filter_box.addWidget(self.lbl_stats_filter)
        self.txt_stats_filter = QLineEdit()
        self.txt_stats_filter.setPlaceholderText("Type to filter groups...")
        filter_box.addWidget(self.txt_stats_filter)
        stats_display_layout.addLayout(filter_box)

        # Table Widget
        self.tbl_stats = QTableWidget()
        self.tbl_stats.setColumnCount(5)
        self.tbl_stats.setHorizontalHeaderLabels([
            "Group", "Features Count", "Total Overlap", "Overlap % of Input", "Overlap % of Group"
        ])
        self.tbl_stats.horizontalHeader().setSectionResizeMode(HEADER_STRETCH)
        self.tbl_stats.setMinimumHeight(190)
        stats_display_layout.addWidget(self.tbl_stats)

        # Export and Copy Buttons
        tbl_btn_box = QHBoxLayout()
        self.btn_copy_stats = QPushButton("Copy to Clipboard")
        self.btn_export_stats_csv = QPushButton("Export to CSV...")
        self.btn_add_stats_table = QPushButton("Add Table to QGIS")
        tbl_btn_box.addWidget(self.btn_copy_stats)
        tbl_btn_box.addWidget(self.btn_export_stats_csv)
        tbl_btn_box.addWidget(self.btn_add_stats_table)
        tbl_btn_box.addStretch()
        stats_display_layout.addLayout(tbl_btn_box)

        layout.addWidget(self.grp_stats_display)
        self.grp_stats_display.hide()

        scroll.setWidget(container)
        tab_layout = QVBoxLayout(self.tab_grouped)
        tab_layout.setContentsMargins(0, 0, 0, 0)
        tab_layout.addWidget(scroll)

    # -------------------------------------------------------------
    # TAB 3: SETTINGS
    # -------------------------------------------------------------
    def init_settings_tab(self):
        scroll = QScrollArea(self.tab_settings)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(FRAME_NO_FRAME)
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)

        # UI Preferences (Language & Theme)
        self.grp_ui_prefs = QGroupBox("Appearance & Language")
        form_ui = QFormLayout(self.grp_ui_prefs)

        self.cmb_set_language = QComboBox()
        self.cmb_set_language.addItems(["🇪🇪 Eesti (EST)", "🇬🇧 English (ENG)"])
        self.lbl_set_lang = QLabel("Interface Language:")
        form_ui.addRow(self.lbl_set_lang, self.cmb_set_language)

        self.cmb_set_theme = QComboBox()
        self.cmb_set_theme.addItems(["System Default", "Light Mode", "Dark Mode"])
        self.lbl_set_theme = QLabel("Color Theme:")
        form_ui.addRow(self.lbl_set_theme, self.cmb_set_theme)

        layout.addWidget(self.grp_ui_prefs)

        # Default Parameters Group
        self.grp_set_defaults = QGroupBox("Default Parameters")
        form_def = QFormLayout(self.grp_set_defaults)

        self.spn_set_detail_coeff = QDoubleSpinBox()
        self.spn_set_detail_coeff.setRange(0.0, 100.0)
        self.spn_set_detail_coeff.setDecimals(5)
        self.spn_set_detail_coeff.setValue(0.00100)
        self.spn_set_detail_coeff.setSingleStep(0.001)
        self.lbl_set_detail = QLabel("Default detail coefficient (ha):")
        form_def.addRow(self.lbl_set_detail, self.spn_set_detail_coeff)

        self.cmb_set_unit = QComboBox()
        self.cmb_set_unit.addItems(["Hectares (ha)", "Square meters (m²)"])
        self.lbl_set_unit = QLabel("Default area unit:")
        form_def.addRow(self.lbl_set_unit, self.cmb_set_unit)

        self.spn_set_precision = QSpinBox()
        self.spn_set_precision.setRange(0, 6)
        self.spn_set_precision.setValue(2)
        self.lbl_set_precision = QLabel("Default decimal precision:")
        form_def.addRow(self.lbl_set_precision, self.spn_set_precision)

        self.txt_set_std_area_field = QLineEdit("Ülekate_ha")
        self.lbl_set_std_area = QLabel("Standard overlap area field:")
        form_def.addRow(self.lbl_set_std_area, self.txt_set_std_area_field)

        self.txt_set_std_percent_field = QLineEdit("Ülekate_%")
        self.lbl_set_std_percent = QLabel("Standard overlap % field:")
        form_def.addRow(self.lbl_set_std_percent, self.txt_set_std_percent_field)

        self.txt_set_grp_prefix = QLineEdit("Ülekate_")
        self.lbl_set_grp_prefix = QLabel("Grouped overlap field prefix:")
        form_def.addRow(self.lbl_set_grp_prefix, self.txt_set_grp_prefix)

        self.chk_set_strip_asterisk = QCheckBox("Merge priority asterisks (*) by default")
        self.chk_set_strip_asterisk.setChecked(True)
        form_def.addRow("", self.chk_set_strip_asterisk)

        self.chk_set_open_output = QCheckBox("Auto-open created layers in QGIS canvas")
        self.chk_set_open_output.setChecked(True)
        form_def.addRow("", self.chk_set_open_output)

        self.chk_set_apply_style = QCheckBox("Auto-apply layer styling by default")
        self.chk_set_apply_style.setChecked(True)
        form_def.addRow("", self.chk_set_apply_style)

        self.chk_set_wfs_restrict_bbox = QCheckBox("Restrict WFS query to map canvas extent by default")
        self.chk_set_wfs_restrict_bbox.setChecked(True)
        form_def.addRow("", self.chk_set_wfs_restrict_bbox)

        self.spn_set_style_step = QSpinBox()
        self.spn_set_style_step.setRange(1, 1000)
        self.spn_set_style_step.setValue(10)
        self.lbl_set_style_step = QLabel("Default frequency step:")
        form_def.addRow(self.lbl_set_style_step, self.spn_set_style_step)

        layout.addWidget(self.grp_set_defaults)

        # Performance & Calculation Info Group
        self.grp_set_perf = QGroupBox("Calculation Method & Styling Info")
        info_layout = QVBoxLayout(self.grp_set_perf)
        self.lbl_set_perf_info = QLabel()
        self.lbl_set_perf_info.setWordWrap(True)
        info_layout.addWidget(self.lbl_set_perf_info)
        layout.addWidget(self.grp_set_perf)

        layout.addStretch()

        # Settings Actions
        btn_box = QHBoxLayout()
        self.btn_reset_settings = QPushButton("Restore Defaults")
        self.btn_save_settings = QPushButton("Save Settings")
        self.btn_save_settings.setObjectName("primaryAction")
        btn_box.addWidget(self.btn_reset_settings)
        btn_box.addStretch()
        btn_box.addWidget(self.btn_save_settings)
        layout.addLayout(btn_box)

        scroll.setWidget(container)
        tab_layout = QVBoxLayout(self.tab_settings)
        tab_layout.setContentsMargins(0, 0, 0, 0)
        tab_layout.addWidget(scroll)

    # -------------------------------------------------------------
    # SIGNALS & CONNECTIONS
    # -------------------------------------------------------------
    def setup_connections(self):
        # Header quick controls
        self.cmb_quick_lang.currentIndexChanged.connect(self.on_quick_lang_changed)
        self.cmb_quick_theme.currentIndexChanged.connect(self.on_quick_theme_changed)

        # Settings selectors sync
        self.cmb_set_language.currentIndexChanged.connect(self.on_settings_lang_changed)
        self.cmb_set_theme.currentIndexChanged.connect(self.on_settings_theme_changed)

        # Tab selection sync
        self.tabs.currentChanged.connect(self.on_tab_changed)

        # Update field combo box when overlay layer changes
        self.cmb_grp_overlay.layerChanged.connect(self.on_grouped_overlay_changed)
        self.on_grouped_overlay_changed(self.cmb_grp_overlay.currentLayer())

        # Check selection availability
        self.cmb_std_input.layerChanged.connect(lambda l: self.update_selection_check(l, self.chk_std_input_selected))
        self.cmb_std_overlay.layerChanged.connect(lambda l: self.update_selection_check(l, self.chk_std_overlay_selected))
        self.cmb_grp_input.layerChanged.connect(lambda l: self.update_selection_check(l, self.chk_grp_input_selected))
        self.cmb_grp_overlay.layerChanged.connect(lambda l: self.update_selection_check(l, self.chk_grp_overlay_selected))

        # Initial selection check
        self.update_selection_check(self.cmb_std_input.currentLayer(), self.chk_std_input_selected)
        self.update_selection_check(self.cmb_std_overlay.currentLayer(), self.chk_std_overlay_selected)
        self.update_selection_check(self.cmb_grp_input.currentLayer(), self.chk_grp_input_selected)
        self.update_selection_check(self.cmb_grp_overlay.currentLayer(), self.chk_grp_overlay_selected)

        # Run button
        self.btn_run_main.clicked.connect(self.run_current_tab_analysis)
        self.btn_cancel.clicked.connect(self.cancel_current_task)
        self.btn_close.clicked.connect(self.close)

        # Settings buttons
        self.btn_save_settings.clicked.connect(self.save_settings)
        self.btn_reset_settings.clicked.connect(self.reset_settings)

        # Statistics buttons
        self.txt_stats_filter.textChanged.connect(self.filter_stats_table)
        self.btn_copy_stats.clicked.connect(self.copy_stats_to_clipboard)
        self.btn_export_stats_csv.clicked.connect(self.export_stats_csv)
        self.btn_add_stats_table.clicked.connect(self.add_stats_table_layer)

    # -------------------------------------------------------------
    # DOCKING & INPUT ACTIONS
    # -------------------------------------------------------------
    def toggle_dock_mode(self):
        self.setFloating(not self.isFloating())
        self.update_dock_button_text()

    def update_dock_button_text(self):
        if hasattr(self, 'btn_dock_toggle'):
            if self.isFloating():
                self.btn_dock_toggle.setText("🗗 " + self.t("dock_window"))
            else:
                self.btn_dock_toggle.setText("🗖 " + self.t("float_window"))

    def on_top_level_changed(self, floating):
        if floating:
            self.setWindowFlags(QT_WINDOW_FLAGS)
            self.show()
        self.update_dock_button_text()

    def run_current_tab_analysis(self):
        idx = self.tabs.currentIndex()
        if idx == 0:
            self.run_standard_analysis()
        elif idx == 1:
            self.run_grouped_analysis()
        else:
            self.tabs.setCurrentIndex(0)

    def on_tab_changed(self, idx):
        if idx == 2:
            self.btn_run_main.setEnabled(False)
            self.btn_run_main.setToolTip(
                "Vali ülekatte vahekaart käivitamiseks" if self.current_lang == "est" else "Select an overlap tab to run"
            )
        else:
            if not self.current_task:
                self.btn_run_main.setEnabled(True)
                self.btn_run_main.setToolTip(self.t("tooltip_run_main"))

    def browse_layer_from_pc(self, target_combo):
        home = QgsProject.instance().homePath() or os.path.expanduser("~")
        file_filter = (
            "Vektorandmed (*.gpkg *.shp *.geojson *.json *.kml *.gml *.tab *.sqlite);;Kõik failid (*.*)"
            if self.current_lang == "est"
            else "Vector Data (*.gpkg *.shp *.geojson *.json *.kml *.gml *.tab *.sqlite);;All Files (*.*)"
        )
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            self.t("browse_file_title"),
            home,
            file_filter
        )
        if not file_path:
            return

        layer_name = os.path.splitext(os.path.basename(file_path))[0]
        uri = file_path

        if file_path.lower().endswith(".gpkg"):
            try:
                meta = QgsProviderRegistry.instance().providerMetadata('ogr')
                if hasattr(meta, 'querySublayers'):
                    subs = meta.querySublayers(file_path)
                    if len(subs) > 1:
                        names = [s.name() for s in subs]
                        chosen, ok = QInputDialog.getItem(
                            self,
                            self.t("select_layer_title"),
                            self.t("select_layer_prompt"),
                            names, 0, False
                        )
                        if not ok or not chosen:
                            return
                        uri = f"{file_path}|layername={chosen}"
                        layer_name = chosen
                    elif len(subs) == 1:
                        uri = f"{file_path}|layername={subs[0].name()}"
                        layer_name = subs[0].name()
            except Exception:
                pass

        vlayer = QgsVectorLayer(uri, layer_name, "ogr")
        if not vlayer or not vlayer.isValid():
            QMessageBox.critical(
                self,
                self.t("title"),
                f"{self.t('msg_file_load_error')}\n{file_path}"
            )
            return

        if vlayer.geometryType() != QGS_WKB_POLYGON:
            reply = QMessageBox.question(
                self,
                self.t("title"),
                f"{self.t('msg_not_polygon_warn')}\n\n{self.t('msg_continue_anyway')}",
                QMESSAGEBOX_YES | QMESSAGEBOX_NO
            )
            if reply != QMESSAGEBOX_YES:
                return

        QgsProject.instance().addMapLayer(vlayer)
        target_combo.setLayer(vlayer)

    def select_layer_from_wfs(self, target_combo):
        dlg = WfsCatalogDialog(self.iface, self, lang=self.current_lang, theme=self.current_theme)
        exec_func = getattr(dlg, 'exec', getattr(dlg, 'exec_', None))
        result = exec_func()
        if (result == QDIALOG_ACCEPTED or result == 1) and dlg.selected_layer:
            target_combo.setLayer(dlg.selected_layer)

    # -------------------------------------------------------------
    # LANGUAGE & THEME SWITCHING
    # -------------------------------------------------------------
    def on_quick_lang_changed(self, idx):
        new_lang = "est" if idx == 0 else "eng"
        if new_lang != self.current_lang:
            self.set_language(new_lang)

    def on_settings_lang_changed(self, idx):
        new_lang = "est" if idx == 0 else "eng"
        if new_lang != self.current_lang:
            self.set_language(new_lang)

    def on_quick_theme_changed(self, idx):
        themes = ["system", "light", "dark"]
        self.apply_theme(themes[idx])

    def on_settings_theme_changed(self, idx):
        themes = ["system", "light", "dark"]
        self.apply_theme(themes[idx])

    def set_language(self, lang):
        old_lang = self.current_lang
        self.current_lang = lang

        lang_idx = 0 if lang == "est" else 1
        self.cmb_quick_lang.blockSignals(True)
        self.cmb_quick_lang.setCurrentIndex(lang_idx)
        self.cmb_quick_lang.blockSignals(False)

        self.cmb_set_language.blockSignals(True)
        self.cmb_set_language.setCurrentIndex(lang_idx)
        self.cmb_set_language.blockSignals(False)

        old_defaults = TRANSLATIONS[old_lang]
        new_defaults = TRANSLATIONS[lang]

        if self.txt_std_area_field.text() in (old_defaults["default_std_area"], "Area_ha", "Ülekatte_ha"):
            self.txt_std_area_field.setText(new_defaults["default_std_area"])
        if self.txt_std_percent_field.text() in (old_defaults["default_std_percent"], "Overlap_%"):
            self.txt_std_percent_field.setText(new_defaults["default_std_percent"])
        if self.txt_grp_prefix.text() in (old_defaults["default_grp_prefix"], "Ülekatte_", "Overlap_"):
            self.txt_grp_prefix.setText(new_defaults["default_grp_prefix"])

        if self.txt_set_std_area_field.text() in (old_defaults["default_std_area"], "Area_ha", "Ülekatte_ha"):
            self.txt_set_std_area_field.setText(new_defaults["default_std_area"])
        if self.txt_set_std_percent_field.text() in (old_defaults["default_std_percent"], "Overlap_%"):
            self.txt_set_std_percent_field.setText(new_defaults["default_std_percent"])
        if self.txt_set_grp_prefix.text() in (old_defaults["default_grp_prefix"], "Ülekatte_", "Overlap_"):
            self.txt_set_grp_prefix.setText(new_defaults["default_grp_prefix"])

        self.retranslate_ui()

    def retranslate_ui(self):
        t = self.t
        self.setWindowTitle(t("title"))
        self.lbl_title.setText(t("title"))
        self.lbl_subtitle.setText(t("subtitle"))

        self.tabs.setTabText(0, t("tab_standard"))
        self.tabs.setTabText(1, t("tab_grouped"))
        self.tabs.setTabText(2, t("tab_settings"))

        # Tab 1
        self.grp_std_layers.setTitle(t("grp_layers"))
        self.lbl_std_input.setText(t("input_layer"))
        self.lbl_std_overlay.setText(t("overlay_layer"))
        self.grp_std_params.setTitle(t("grp_params"))
        self.lbl_std_area.setText(t("area_field"))
        self.lbl_std_percent.setText(t("percent_field"))
        self.lbl_std_detail.setText(t("detail_coeff"))
        self.spn_std_min_area.setToolTip(t("detail_coeff_tooltip"))
        self.lbl_std_unit.setText(t("area_unit"))
        unit_idx = self.cmb_std_unit.currentIndex()
        self.cmb_std_unit.clear()
        self.cmb_std_unit.addItems([t("unit_ha"), t("unit_m2")])
        self.cmb_std_unit.setCurrentIndex(unit_idx)
        self.lbl_std_precision.setText(t("precision"))
        self.grp_std_output.setTitle(t("grp_output"))
        self.lbl_std_save.setText(t("save_to_file"))
        self.chk_std_open_output.setText(t("open_output"))
        self.btn_std_input_pc.setText(t("btn_browse_pc"))
        self.btn_std_input_pc.setToolTip(t("tooltip_browse_pc"))
        self.btn_std_input_wfs.setText(t("btn_wfs"))
        self.btn_std_input_wfs.setToolTip(t("tooltip_wfs"))
        self.btn_std_overlay_pc.setText(t("btn_browse_pc"))
        self.btn_std_overlay_pc.setToolTip(t("tooltip_browse_pc"))
        self.btn_std_overlay_wfs.setText(t("btn_wfs"))
        self.btn_std_overlay_wfs.setToolTip(t("tooltip_wfs"))

        # Tab 1 Styling
        self.grp_std_style.setTitle(t("grp_styling"))
        self.chk_std_apply_style.setText(t("chk_apply_style"))
        self.lbl_std_style_by.setText(t("lbl_style_by"))
        cur_std_style_idx = self.cmb_std_style_by.currentIndex()
        self.cmb_std_style_by.clear()
        self.cmb_std_style_by.addItems([t("style_opt_percent"), t("style_opt_area")])
        self.cmb_std_style_by.setCurrentIndex(cur_std_style_idx if cur_std_style_idx >= 0 else 0)
        self.lbl_std_style_step.setText(t("lbl_step"))
        self.spn_std_style_step.setToolTip(t("tooltip_step"))

        # Tab 2
        self.grp_grp_layers.setTitle(t("grp_layers"))
        self.lbl_grp_input.setText(t("input_layer_1"))
        self.lbl_grp_overlay.setText(t("overlay_mask_layer"))
        self.lbl_grp_field.setText(t("group_field"))
        self.cmb_grp_field.setToolTip(t("group_field_tooltip"))
        self.grp_grp_options.setTitle(t("grp_grouped_options"))
        self.lbl_grp_prefix.setText(t("field_prefix"))
        self.lbl_grp_detail.setText(t("detail_coeff"))
        self.spn_grp_detail_coeff.setToolTip(t("detail_coeff_tooltip"))
        self.chk_grp_strip_asterisk.setText(t("strip_asterisks"))
        self.chk_grp_strip_asterisk.setToolTip(t("strip_asterisks_tooltip"))
        self.chk_grp_only_active.setText(t("only_active"))
        self.lbl_grp_unit.setText(t("area_unit"))
        unit_grp_idx = self.cmb_grp_unit.currentIndex()
        self.cmb_grp_unit.clear()
        self.cmb_grp_unit.addItems([t("unit_ha"), t("unit_m2")])
        self.cmb_grp_unit.setCurrentIndex(unit_grp_idx)
        self.lbl_grp_precision.setText(t("precision"))

        # Tab 2 Styling
        self.grp_grp_style.setTitle(t("grp_styling"))
        self.chk_grp_apply_style.setText(t("chk_apply_style"))
        self.lbl_grp_style_by.setText(t("lbl_style_by"))
        cur_grp_style_idx = self.cmb_grp_style_mode.currentIndex()
        self.cmb_grp_style_mode.clear()
        self.cmb_grp_style_mode.addItems([t("style_grp_categorized"), t("style_grp_frequency")])
        self.cmb_grp_style_mode.setCurrentIndex(cur_grp_style_idx if cur_grp_style_idx >= 0 else 0)
        self.lbl_grp_style_step.setText(t("lbl_step"))
        self.spn_grp_style_step.setToolTip(t("tooltip_step"))

        self.grp_grp_stats.setTitle(t("grp_overall_stats"))
        self.chk_grp_generate_stats.setText(t("generate_stats"))
        self.chk_grp_add_stats_layer.setText(t("add_stats_layer"))
        self.grp_grp_output.setTitle(t("grp_output"))
        self.lbl_grp_save.setText(t("save_to_file"))
        self.chk_grp_open_output.setText(t("open_output"))
        self.btn_grp_input_pc.setText(t("btn_browse_pc"))
        self.btn_grp_input_pc.setToolTip(t("tooltip_browse_pc"))
        self.btn_grp_input_wfs.setText(t("btn_wfs"))
        self.btn_grp_input_wfs.setToolTip(t("tooltip_wfs"))
        self.btn_grp_overlay_pc.setText(t("btn_browse_pc"))
        self.btn_grp_overlay_pc.setToolTip(t("tooltip_browse_pc"))
        self.btn_grp_overlay_wfs.setText(t("btn_wfs"))
        self.btn_grp_overlay_wfs.setToolTip(t("tooltip_wfs"))

        # Stats section
        self.grp_stats_display.setTitle(t("grp_stats_results"))
        self.lbl_stats_filter.setText(t("filter_group"))
        self.txt_stats_filter.setPlaceholderText(t("filter_placeholder"))
        self.btn_copy_stats.setText(t("btn_copy_clipboard"))
        self.btn_export_stats_csv.setText(t("btn_export_csv"))
        self.btn_add_stats_table.setText(t("btn_add_table_qgis"))

        # Tab 3
        self.grp_ui_prefs.setTitle(t("grp_ui_prefs"))
        self.lbl_set_lang.setText(t("language_label"))
        self.lbl_set_theme.setText(t("theme_label"))
        self.grp_set_defaults.setTitle(t("grp_defaults"))
        self.lbl_set_detail.setText(t("def_detail_coeff"))
        self.lbl_set_unit.setText(t("def_unit"))
        set_unit_idx = self.cmb_set_unit.currentIndex()
        self.cmb_set_unit.clear()
        self.cmb_set_unit.addItems([t("unit_ha"), t("unit_m2")])
        self.cmb_set_unit.setCurrentIndex(set_unit_idx)
        self.lbl_set_precision.setText(t("def_precision"))
        self.lbl_set_std_area.setText(t("def_std_area_field"))
        self.lbl_set_std_percent.setText(t("def_std_percent_field"))
        self.lbl_set_grp_prefix.setText(t("def_grp_prefix"))
        self.chk_set_strip_asterisk.setText(t("def_strip_asterisk"))
        self.chk_set_open_output.setText(t("def_open_output"))
        self.chk_set_apply_style.setText(t("def_apply_style"))
        self.chk_set_wfs_restrict_bbox.setText(t("def_wfs_restrict_bbox"))
        self.chk_set_wfs_restrict_bbox.setToolTip(t("def_wfs_restrict_bbox_tooltip"))
        self.lbl_set_style_step.setText(t("def_style_step"))
        self.grp_set_perf.setTitle(t("grp_perf_info"))
        self.lbl_set_perf_info.setText(t("perf_info_text"))
        self.btn_save_settings.setText(t("btn_save_settings"))
        self.btn_reset_settings.setText(t("btn_reset_settings"))

        # Bottom
        self.btn_run_main.setText(t("btn_run_main"))
        self.btn_run_main.setToolTip(t("tooltip_run_main"))
        self.btn_cancel.setText(t("btn_cancel"))
        self.btn_close.setText(t("btn_close"))
        self.update_dock_button_text()
        if self.current_task is None:
            self.status_label.setText(t("status_ready"))

        self.update_selection_check(self.cmb_std_input.currentLayer(), self.chk_std_input_selected)
        self.update_selection_check(self.cmb_std_overlay.currentLayer(), self.chk_std_overlay_selected)
        self.update_selection_check(self.cmb_grp_input.currentLayer(), self.chk_grp_input_selected)
        self.update_selection_check(self.cmb_grp_overlay.currentLayer(), self.chk_grp_overlay_selected)

        if self.last_grouped_stats:
            self.display_statistics(self.last_grouped_stats)

    def apply_theme(self, theme_name):
        self.current_theme = theme_name
        theme_idx = {"system": 0, "light": 1, "dark": 2}.get(theme_name, 0)

        self.cmb_quick_theme.blockSignals(True)
        self.cmb_quick_theme.setCurrentIndex(theme_idx)
        self.cmb_quick_theme.blockSignals(False)

        self.cmb_set_theme.blockSignals(True)
        self.cmb_set_theme.setCurrentIndex(theme_idx)
        self.cmb_set_theme.blockSignals(False)

        if theme_name == "light":
            self.setStyleSheet(LIGHT_STYLESHEET)
        elif theme_name == "dark":
            self.setStyleSheet(DARK_STYLESHEET)
        else:
            self.setStyleSheet("")

    def on_grouped_overlay_changed(self, layer):
        self.cmb_grp_field.setLayer(layer)
        if layer:
            field_names = [f.name() for f in layer.fields()]
            for target in ["pohityyp", "elupaik", "tyyp", "type", "habitat"]:
                if target in field_names:
                    idx = self.cmb_grp_field.findText(target)
                    if idx >= 0:
                        self.cmb_grp_field.setCurrentIndex(idx)
                        break

    def update_selection_check(self, layer, checkbox):
        t = self.t
        sel_text = t("selected_only")
        if layer and hasattr(layer, "selectedFeatureCount") and layer.selectedFeatureCount() > 0:
            checkbox.setEnabled(True)
            checkbox.setText(f"{sel_text} ({layer.selectedFeatureCount()})")
        else:
            checkbox.setEnabled(False)
            checkbox.setChecked(False)
            checkbox.setText(f"{sel_text} (0)")

    # -------------------------------------------------------------
    # EXECUTION: STANDARD OVERLAP
    # -------------------------------------------------------------
    def run_standard_analysis(self):
        in_layer = self.cmb_std_input.currentLayer()
        ov_layer = self.cmb_std_overlay.currentLayer()

        if not in_layer:
            QMessageBox.warning(self, self.t("title"), self.t("msg_missing_input"))
            return
        if not ov_layer:
            QMessageBox.warning(self, self.t("title"), self.t("msg_missing_overlay"))
            return

        out_path = self.file_std_output.filePath().strip() or None
        unit = "ha" if self.cmb_std_unit.currentIndex() == 0 else "m2"

        area_fld = self.txt_std_area_field.text().strip() or self.t("default_std_area")
        pct_fld = self.txt_std_percent_field.text().strip() or self.t("default_std_percent")

        kwargs = {
            "input_layer": in_layer,
            "overlay_layers": [ov_layer],
            "input_selected_only": self.chk_std_input_selected.isChecked(),
            "overlay_selected_only": self.chk_std_overlay_selected.isChecked(),
            "area_field": area_fld,
            "percent_field": pct_fld,
            "min_area_ha": self.spn_std_min_area.value(),
            "unit": unit,
            "precision": self.spn_std_precision.value(),
            "output_path": out_path
        }

        self.std_styling_field = pct_fld if self.cmb_std_style_by.currentIndex() == 0 else area_fld
        self.std_style_step = self.spn_std_style_step.value()
        self.std_apply_style = self.chk_std_apply_style.isChecked()

        self.start_task(
            description=self.t("btn_run_standard"),
            target_func=run_standard_overlap,
            kwargs=kwargs,
            on_success=self.on_standard_success
        )

    def on_standard_success(self, result_layer):
        self.finish_task(self.t("status_completed"))
        if result_layer:
            # Apply styling if requested
            if getattr(self, 'std_apply_style', True):
                try:
                    apply_standard_overlap_styling(
                        result_layer,
                        self.std_styling_field,
                        step=self.std_style_step
                    )
                except Exception as e:
                    print(f"Error applying styling: {e}")

            if self.chk_std_open_output.isChecked():
                QgsProject.instance().addMapLayer(result_layer)

        if self.iface:
            self.iface.messageBar().pushSuccess("Overlap Toolkit", self.t("status_completed"))

    # -------------------------------------------------------------
    # EXECUTION: GROUPED OVERLAP
    # -------------------------------------------------------------
    def run_grouped_analysis(self):
        in_layer = self.cmb_grp_input.currentLayer()
        ov_layer = self.cmb_grp_overlay.currentLayer()
        group_field = self.cmb_grp_field.currentText().strip()

        if not in_layer:
            QMessageBox.warning(self, self.t("title"), self.t("msg_missing_input"))
            return
        if not ov_layer:
            QMessageBox.warning(self, self.t("title"), self.t("msg_missing_overlay"))
            return
        if not group_field:
            QMessageBox.warning(self, self.t("title"), self.t("msg_missing_field"))
            return

        out_path = self.file_grp_output.filePath().strip() or None
        unit = "ha" if self.cmb_grp_unit.currentIndex() == 0 else "m2"

        dom_grp_name = "Peamine_grupp" if self.current_lang == "est" else "Dominant_Group"
        dom_ov_name = "Peamine_ülekate" if self.current_lang == "est" else "Dominant_Overlap"
        tot_ov_name = "Kogu_ülekate" if self.current_lang == "est" else "Total_Overlap"

        kwargs = {
            "input_layer": in_layer,
            "overlay_layer": ov_layer,
            "group_field": group_field,
            "input_selected_only": self.chk_grp_input_selected.isChecked(),
            "overlay_selected_only": self.chk_grp_overlay_selected.isChecked(),
            "area_unit": unit,
            "detail_coeff": self.spn_grp_detail_coeff.value(),
            "field_prefix": self.txt_grp_prefix.text() or self.t("default_grp_prefix"),
            "strip_asterisks": self.chk_grp_strip_asterisk.isChecked(),
            "only_active_groups": self.chk_grp_only_active.isChecked(),
            "precision": self.spn_grp_precision.value(),
            "generate_stats": self.chk_grp_generate_stats.isChecked(),
            "dominant_group_field": dom_grp_name,
            "dominant_overlap_field": dom_ov_name,
            "total_overlap_field": tot_ov_name,
            "output_path": out_path
        }

        self.grp_apply_style = self.chk_grp_apply_style.isChecked()
        self.grp_style_mode = "categorized" if self.cmb_grp_style_mode.currentIndex() == 0 else "frequency"
        self.grp_style_step = self.spn_grp_style_step.value()
        self.grp_dom_grp_col = dom_grp_name
        self.grp_dom_ov_col = dom_ov_name
        self.grp_tot_ov_col = tot_ov_name

        self.start_task(
            description=self.t("btn_run_grouped"),
            target_func=run_grouped_overlap,
            kwargs=kwargs,
            on_success=self.on_grouped_success
        )

    def on_grouped_success(self, result):
        result_layer, stats_summary = result
        self.finish_task(self.t("status_completed"))

        if result_layer:
            # Apply styling if requested
            if getattr(self, 'grp_apply_style', True):
                try:
                    val_col = self.grp_dom_ov_col if self.grp_style_mode == "categorized" else self.grp_tot_ov_col
                    apply_grouped_overlap_styling(
                        result_layer,
                        group_col=self.grp_dom_grp_col,
                        val_col=val_col,
                        step=self.grp_style_step,
                        style_type=self.grp_style_mode
                    )
                except Exception as e:
                    print(f"Error applying grouped styling: {e}")

            if self.chk_grp_open_output.isChecked():
                QgsProject.instance().addMapLayer(result_layer)

        if stats_summary:
            self.last_grouped_stats = stats_summary
            self.display_statistics(stats_summary)

            if self.chk_grp_add_stats_layer.isChecked():
                self.add_stats_table_layer()

        if self.iface:
            self.iface.messageBar().pushSuccess("Overlap Toolkit", self.t("status_completed"))

    # -------------------------------------------------------------
    # STATISTICS DISPLAY & EXPORT
    # -------------------------------------------------------------
    def display_statistics(self, stats):
        self.grp_stats_display.show()
        unit = stats.get("area_unit", "ha")
        total_feats = stats.get("total_input_features", 0)
        total_area = stats.get("total_input_area", 0.0)
        groups = stats.get("groups", [])
        t = self.t

        if self.current_lang == "est":
            summary_txt = f"Sisendobjekte: {total_feats:,} | Sisendi kartesiaalne kogupindala: {total_area:,.2f} {unit} | Ülekattega gruppe: {len(groups)}"
        else:
            summary_txt = f"Input features: {total_feats:,} | Total cartesian area: {total_area:,.2f} {unit} | Active groups: {len(groups)}"

        self.lbl_stats_summary.setText(summary_txt)
        self.tbl_stats.setRowCount(len(groups))
        self.tbl_stats.setHorizontalHeaderLabels([
            f"{t('col_group')} ({stats.get('group_field', '')})",
            t("col_features_count"),
            f"{t('col_total_overlap')} ({unit})",
            t("col_pct_input"),
            t("col_pct_group")
        ])

        for row_idx, row in enumerate(groups):
            item_grp = QTableWidgetItem(str(row["group"]))
            item_cnt = QTableWidgetItem(f"{row['feature_count']:,}")
            item_cnt.setTextAlignment(ALIGN_RIGHT | ALIGN_VCENTER)
            item_ov = QTableWidgetItem(f"{row['total_overlap']:,.2f}")
            item_ov.setTextAlignment(ALIGN_RIGHT | ALIGN_VCENTER)
            item_pct_in = QTableWidgetItem(f"{row['percent_of_input']:.2f}%")
            item_pct_in.setTextAlignment(ALIGN_RIGHT | ALIGN_VCENTER)
            item_pct_ov = QTableWidgetItem(f"{row['percent_of_group']:.2f}%")
            item_pct_ov.setTextAlignment(ALIGN_RIGHT | ALIGN_VCENTER)

            self.tbl_stats.setItem(row_idx, 0, item_grp)
            self.tbl_stats.setItem(row_idx, 1, item_cnt)
            self.tbl_stats.setItem(row_idx, 2, item_ov)
            self.tbl_stats.setItem(row_idx, 3, item_pct_in)
            self.tbl_stats.setItem(row_idx, 4, item_pct_ov)

    def filter_stats_table(self, query):
        query = query.strip().lower()
        for row in range(self.tbl_stats.rowCount()):
            item = self.tbl_stats.item(row, 0)
            if query in item.text().lower():
                self.tbl_stats.setRowHidden(row, False)
            else:
                self.tbl_stats.setRowHidden(row, True)

    def copy_stats_to_clipboard(self):
        if not self.last_grouped_stats or "groups" not in self.last_grouped_stats:
            return

        lines = []
        headers = [self.tbl_stats.horizontalHeaderItem(col).text() for col in range(self.tbl_stats.columnCount())]
        lines.append("\t".join(headers))

        for row in range(self.tbl_stats.rowCount()):
            if not self.tbl_stats.isRowHidden(row):
                row_vals = [self.tbl_stats.item(row, col).text() for col in range(self.tbl_stats.columnCount())]
                lines.append("\t".join(row_vals))

        QApplication.clipboard().setText("\n".join(lines))
        if self.iface:
            self.iface.messageBar().pushInfo("Overlap Toolkit", self.t("msg_copied"))

    def export_stats_csv(self):
        if not self.last_grouped_stats or "groups" not in self.last_grouped_stats:
            return

        path, _ = QFileDialog.getSaveFileName(self, self.t("btn_export_csv"), "", "CSV Files (*.csv)")
        if not path:
            return

        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                headers = [self.tbl_stats.horizontalHeaderItem(col).text() for col in range(self.tbl_stats.columnCount())]
                writer.writerow(headers)
                for row in range(self.tbl_stats.rowCount()):
                    row_vals = [self.tbl_stats.item(row, col).text().replace("%", "").replace(",", "") for col in range(self.tbl_stats.columnCount())]
                    writer.writerow(row_vals)

            if self.iface:
                self.iface.messageBar().pushSuccess("Overlap Toolkit", f"{self.t('msg_exported')} {os.path.basename(path)}!")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"CSV export error:\n{str(e)}")

    def add_stats_table_layer(self):
        if not self.last_grouped_stats:
            return
        tbl_name = "Koondstatistika" if self.current_lang == "est" else "Overall Overlap Statistics"
        tbl_layer = create_statistics_table_layer(self.last_grouped_stats, tbl_name)
        if tbl_layer:
            QgsProject.instance().addMapLayer(tbl_layer)
            if self.iface:
                self.iface.messageBar().pushSuccess("Overlap Toolkit", self.t("msg_added_table"))

    # -------------------------------------------------------------
    # BACKGROUND TASK, PROGRESS & DYNAMIC ETA
    # -------------------------------------------------------------
    def start_task(self, description, target_func, kwargs, on_success):
        self.btn_run_main.setEnabled(False)
        self.btn_cancel.show()
        self.progress_bar.show()
        self.progress_bar.setValue(0)
        self.task_start_time = time.time()
        self.status_label.setText(f"{description} (0%)")

        self.current_task = WorkerTask(
            description=description,
            target_func=target_func,
            kwargs=kwargs,
            on_progress_callback=self.on_task_progress,
            on_success_callback=on_success,
            on_error_callback=self.on_task_error
        )
        self.current_task.progressChanged.connect(self.on_task_progress)
        QgsApplication.taskManager().addTask(self.current_task)

    def on_task_progress(self, progress):
        progress = max(0, min(100, int(progress)))
        self.progress_bar.setValue(progress)

        if self.task_start_time:
            elapsed = time.time() - self.task_start_time
            mins_el, secs_el = divmod(int(elapsed), 60)
            elapsed_str = f"{mins_el:02d}:{secs_el:02d}"

            if progress > 1:
                total_est = elapsed * (100.0 / progress)
                rem = max(0, total_est - elapsed)
                mins_rem, secs_rem = divmod(int(rem), 60)
                eta_str = f"{mins_rem:02d}:{secs_rem:02d}"
                progress_txt = f"{progress}%  ({self.t('eta')}: {eta_str})"
                status_txt = f"{self.t('status_calculating')} [{progress}%] | {self.t('elapsed')}: {elapsed_str} | {self.t('eta')}: ~{eta_str}"
            else:
                progress_txt = f"{progress}%"
                status_txt = f"{self.t('status_calculating')} [{progress}%] | {self.t('elapsed')}: {elapsed_str}"

            self.progress_bar.setFormat(progress_txt)
            self.status_label.setText(status_txt)

    def cancel_current_task(self):
        if self.current_task and self.current_task.status() in (QgsTask.Queued, QgsTask.Running):
            self.status_label.setText(self.t("status_canceling"))
            self.current_task.cancel()

    def finish_task(self, message):
        if self.tabs.currentIndex() != 2:
            self.btn_run_main.setEnabled(True)
        self.btn_cancel.hide()
        self.progress_bar.setValue(100)
        
        elapsed_str = ""
        if self.task_start_time:
            elapsed = time.time() - self.task_start_time
            mins_el, secs_el = divmod(int(elapsed), 60)
            elapsed_str = f" ({self.t('elapsed')}: {mins_el:02d}:{secs_el:02d})"

        self.progress_bar.setFormat(f"100%{elapsed_str}")
        self.status_label.setText(f"{message}{elapsed_str}")
        self.current_task = None
        self.task_start_time = None

    def on_task_error(self, error_msg):
        if error_msg == "CANCELED":
            self.finish_task(self.t("status_canceled"))
        else:
            self.finish_task(self.t("status_ready"))
            QMessageBox.critical(self, self.t("title"), f"Error:\n\n{error_msg}")

    # -------------------------------------------------------------
    # SETTINGS PERSISTENCE
    # -------------------------------------------------------------
    def load_settings(self):
        s = QgsSettings()
        lang = str(s.value("OverlapToolkit/language", s.value("OverlapSuite/language", "est")))
        theme = str(s.value("OverlapToolkit/theme", s.value("OverlapSuite/theme", "system")))
        detail_coeff = float(s.value("OverlapToolkit/detail_coeff", s.value("OverlapSuite/detail_coeff", 0.001)))
        unit_idx = int(s.value("OverlapToolkit/unit_idx", s.value("OverlapSuite/unit_idx", 0)))
        precision = int(s.value("OverlapToolkit/precision", s.value("OverlapSuite/precision", 2)))
        
        default_area = "Ülekate_ha" if lang == "est" else "Overlap_ha"
        default_pc = "Ülekate_%" if lang == "est" else "Overlap_%"
        default_pref = "Ülekate_" if lang == "est" else "Overlap_"

        std_area_fld = str(s.value("OverlapToolkit/std_area_field", s.value("OverlapSuite/std_area_field", default_area)))
        std_pct_fld = str(s.value("OverlapToolkit/std_percent_field", s.value("OverlapSuite/std_percent_field", default_pc)))
        grp_prefix = str(s.value("OverlapToolkit/grp_prefix", s.value("OverlapSuite/grp_prefix", default_pref)))
        strip_ast = bool(s.value("OverlapToolkit/strip_asterisk", s.value("OverlapSuite/strip_asterisk", True)))
        open_out = bool(s.value("OverlapToolkit/open_output", s.value("OverlapSuite/open_output", True)))
        apply_st = bool(s.value("OverlapToolkit/apply_style", s.value("OverlapSuite/apply_style", True)))
        st_step = int(s.value("OverlapToolkit/style_step", s.value("OverlapSuite/style_step", 10)))
        wfs_restrict = bool(s.value("OverlapToolkit/wfs_restrict_bbox", s.value("OverlapSuite/wfs_restrict_bbox", True, type=bool)))

        self.current_lang = lang
        self.current_theme = theme

        # Standard Tab
        self.spn_std_min_area.setValue(detail_coeff)
        self.cmb_std_unit.setCurrentIndex(unit_idx)
        self.spn_std_precision.setValue(precision)
        self.txt_std_area_field.setText(std_area_fld)
        self.txt_std_percent_field.setText(std_pct_fld)
        self.chk_std_open_output.setChecked(open_out)
        self.chk_std_apply_style.setChecked(apply_st)
        self.spn_std_style_step.setValue(st_step)

        # Grouped Tab
        self.spn_grp_detail_coeff.setValue(detail_coeff)
        self.cmb_grp_unit.setCurrentIndex(unit_idx)
        self.spn_grp_precision.setValue(precision)
        self.txt_grp_prefix.setText(grp_prefix)
        self.chk_grp_strip_asterisk.setChecked(strip_ast)
        self.chk_grp_open_output.setChecked(open_out)
        self.chk_grp_apply_style.setChecked(apply_st)
        self.spn_grp_style_step.setValue(st_step)

        # Settings Tab
        self.spn_set_detail_coeff.setValue(detail_coeff)
        self.cmb_set_unit.setCurrentIndex(unit_idx)
        self.spn_set_precision.setValue(precision)
        self.txt_set_std_area_field.setText(std_area_fld)
        self.txt_set_std_percent_field.setText(std_pct_fld)
        self.txt_set_grp_prefix.setText(grp_prefix)
        self.chk_set_strip_asterisk.setChecked(strip_ast)
        self.chk_set_open_output.setChecked(open_out)
        self.chk_set_apply_style.setChecked(apply_st)
        self.chk_set_wfs_restrict_bbox.setChecked(wfs_restrict)
        self.spn_set_style_step.setValue(st_step)

        # Theme & Language Sync
        lang_idx = 0 if lang == "est" else 1
        self.cmb_quick_lang.blockSignals(True)
        self.cmb_quick_lang.setCurrentIndex(lang_idx)
        self.cmb_quick_lang.blockSignals(False)
        self.cmb_set_language.blockSignals(True)
        self.cmb_set_language.setCurrentIndex(lang_idx)
        self.cmb_set_language.blockSignals(False)

        theme_idx = {"system": 0, "light": 1, "dark": 2}.get(theme, 0)
        self.cmb_quick_theme.blockSignals(True)
        self.cmb_quick_theme.setCurrentIndex(theme_idx)
        self.cmb_quick_theme.blockSignals(False)
        self.cmb_set_theme.blockSignals(True)
        self.cmb_set_theme.setCurrentIndex(theme_idx)
        self.cmb_set_theme.blockSignals(False)

    def save_settings(self):
        s = QgsSettings()
        s.setValue("OverlapToolkit/language", self.current_lang)
        s.setValue("OverlapToolkit/theme", self.current_theme)
        s.setValue("OverlapToolkit/detail_coeff", self.spn_set_detail_coeff.value())
        s.setValue("OverlapToolkit/unit_idx", self.cmb_set_unit.currentIndex())
        s.setValue("OverlapToolkit/precision", self.spn_set_precision.value())
        s.setValue("OverlapToolkit/std_area_field", self.txt_set_std_area_field.text())
        s.setValue("OverlapToolkit/std_percent_field", self.txt_set_std_percent_field.text())
        s.setValue("OverlapToolkit/grp_prefix", self.txt_set_grp_prefix.text())
        s.setValue("OverlapToolkit/strip_asterisk", self.chk_set_strip_asterisk.isChecked())
        s.setValue("OverlapToolkit/open_output", self.chk_set_open_output.isChecked())
        s.setValue("OverlapToolkit/apply_style", self.chk_set_apply_style.isChecked())
        s.setValue("OverlapToolkit/wfs_restrict_bbox", self.chk_set_wfs_restrict_bbox.isChecked())
        s.setValue("OverlapToolkit/style_step", self.spn_set_style_step.value())

        self.load_settings()
        QMessageBox.information(self, self.t("title"), self.t("msg_settings_saved"))

    def reset_settings(self):
        s = QgsSettings()
        for k in ["language", "theme", "detail_coeff", "unit_idx", "precision", "std_area_field", "std_percent_field", "grp_prefix", "strip_asterisk", "open_output", "apply_style", "style_step", "wfs_restrict_bbox"]:
            s.remove(f"OverlapToolkit/{k}")
            s.remove(f"OverlapSuite/{k}")
        self.load_settings()
        self.apply_theme("system")
        self.retranslate_ui()
        QMessageBox.information(self, self.t("title"), self.t("msg_settings_reset"))


# Backward compatibility aliases
OverlapSuiteDockWidget = OverlapToolkitDockWidget
OverlapToolkitDialog = OverlapToolkitDockWidget
OverlapSuiteDialog = OverlapToolkitDockWidget
