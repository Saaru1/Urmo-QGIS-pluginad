# -*- coding: utf-8 -*-
"""
Overlap Toolkit Translations and Theme Palettes
Supports English (ENG) and Estonian (EST), plus Light, Dark, and System themes.
"""

TRANSLATIONS = {
    "eng": {
        "title": "Overlap Toolkit",
        "subtitle": "Vector Overlap, Grouped Overlap & Aggregate Statistics",
        "tab_standard": "1. Overlap (Standard)",
        "tab_grouped": "2. Overlap Grouped (+ Statistics)",
        "tab_settings": "3. Settings",
        
        # Standard tab
        "grp_layers": "Layers",
        "input_layer": "Input polygon layer:",
        "overlay_layer": "Overlay / mask layer:",
        "selected_only": "Selected features only",
        "grp_params": "Calculation Parameters",
        "area_field": "Area field name:",
        "percent_field": "Percentage field name:",
        "detail_coeff": "Detail coefficient (min ha):",
        "detail_coeff_tooltip": "Intersections smaller than this threshold (in ha) are filtered out to avoid sliver artifacts.",
        "area_unit": "Area calculation unit:",
        "unit_ha": "Hectares (ha)",
        "unit_m2": "Square meters (m²)",
        "precision": "Decimal precision:",
        "grp_output": "Output",
        "save_to_file": "Save to file (leave empty for memory layer):",
        "open_output": "Open output layer after running",
        "btn_run_standard": "Run Overlap Analysis",
        
        # Standard Styling
        "grp_styling": "Layer Styling Options",
        "chk_apply_style": "Apply automatic styling to output layer",
        "lbl_style_by": "Style by:",
        "lbl_step": "Frequency step:",
        "tooltip_step": "Frequency step for intervals (e.g. 10 -> 0, 1-10, 11-20, ...)",
        "style_opt_percent": "Overlap Percentage (%)",
        "style_opt_area": "Overlap Area (ha / m²)",
        
        # Grouped tab
        "input_layer_1": "Input polygon layer:",
        "overlay_mask_layer": "Overlay layer:",
        "group_field": "Grouping field:",
        "group_field_tooltip": "Field in the overlay layer used to group features.",
        "grp_grouped_options": "Grouping & Calculation Options",
        "field_prefix": "Result field prefix:",
        "strip_asterisks": "Merge priority asterisks (*) and trim whitespace",
        "strip_asterisks_tooltip": "Strips '*' so priority categories like '1150*' and '1150' merge into the same group.",
        "only_active": "Only add columns for groups with overlap > 0",
        "grp_overall_stats": "Overall Statistics",
        "generate_stats": "Generate overall statistics (treat input features as a whole)",
        "add_stats_layer": "Add overall statistics table as layer to QGIS project",
        "btn_run_grouped": "Run Grouped Overlap Analysis",
        "style_grp_categorized": "Categorized by grouping field (light-to-dark by overlap, 0 separate)",
        "style_grp_frequency": "Frequency classes by total overlap (0, 1-10, ...)",
        
        # Stats Results
        "grp_stats_results": "Overall Statistics Results",
        "run_to_view_stats": "Run grouped overlap to view overall statistics.",
        "filter_group": "Filter group:",
        "filter_placeholder": "Type to filter groups...",
        "col_group": "Group",
        "col_features_count": "Features Count",
        "col_total_overlap": "Total Overlap",
        "col_pct_input": "Overlap % of Input",
        "col_pct_group": "Overlap % of Group",
        "btn_copy_clipboard": "Copy to Clipboard",
        "btn_export_csv": "Export to CSV...",
        "btn_add_table_qgis": "Add Table to QGIS",
        
        # Settings tab
        "grp_defaults": "Default Parameters",
        "def_detail_coeff": "Default detail coefficient (ha):",
        "def_unit": "Default area unit:",
        "def_precision": "Default decimal precision:",
        "def_std_area_field": "Standard overlap area field:",
        "def_std_percent_field": "Standard overlap % field:",
        "def_grp_prefix": "Grouped overlap field prefix:",
        "def_strip_asterisk": "Merge priority asterisks (*) by default",
        "def_open_output": "Auto-open created layers in QGIS canvas",
        "def_apply_style": "Auto-apply layer styling by default",
        "def_style_step": "Default frequency step:",
        "def_wfs_restrict_bbox": "Restrict WFS queries to map canvas extent by default",
        "def_wfs_restrict_bbox_tooltip": "When adding WFS layers, queries features within the active map canvas bounding box by default for significantly faster loading.",
        "grp_ui_prefs": "Appearance & Language",
        "language_label": "Interface Language:",
        "theme_label": "Color Theme:",
        "theme_system": "System Default",
        "theme_light": "Light Mode",
        "theme_dark": "Dark Mode",
        "grp_perf_info": "Calculation Method & Styling Info",
        "perf_info_text": (
            "• <b>Cartesian Area:</b> Overlap area is computed as planar/cartesian area (inter.cartesianArea()) in layer CRS units.<br>"
            "• <b>Spatial Index:</b> Overlay features are indexed via QgsSpatialIndex for up to 1000x faster execution.<br>"
            "• <b>Detail Coefficient:</b> Overlaps below the threshold (e.g. 0.001 ha = 10 m²) are zeroed to filter slivers.<br>"
            "• <b>Automatic Styling:</b> Output layers can be styled with frequency table rules (0, 1-10, ...) or categorized by group with light-to-dark sub-styles."
        ),
        "btn_save_settings": "Save Settings",
        "btn_reset_settings": "Restore Defaults",
        
        # Common
        "btn_run_main": "Run",
        "tooltip_run_main": "Run analysis for the currently active tab",
        "btn_browse_pc": "📁 File...",
        "tooltip_browse_pc": "Select a vector data file from PC (.gpkg, .shp, .geojson, etc.)",
        "btn_wfs": "🌐 WFS...",
        "tooltip_wfs": "Select layer directly from WFS catalog (EELIS, Cadastre, PRIA, ETAK, etc.)",
        "browse_file_title": "Select Vector Data File",
        "select_layer_title": "Select Layer",
        "select_layer_prompt": "File contains multiple layers. Select desired layer:",
        "msg_file_load_error": "Failed to open vector file:",
        "msg_not_polygon_warn": "Warning: Selected layer does not appear to be a polygon layer.",
        "msg_continue_anyway": "Do you want to continue anyway?",
        "dock_window": "Dock Panel",
        "float_window": "Float Window",
        "btn_dock_toggle": "Dock / Float",
        "btn_cancel": "Cancel",
        "btn_close": "Close",
        "status_ready": "Ready",
        "status_calculating": "Calculating...",
        "status_canceling": "Canceling task...",
        "status_canceled": "Operation was canceled by user.",
        "status_completed": "Calculation completed successfully!",
        "elapsed": "Elapsed",
        "eta": "ETA",
        "msg_missing_input": "Please select an input polygon layer.",
        "msg_missing_overlay": "Please select an overlay polygon layer.",
        "msg_missing_field": "Please select a grouping field from the overlay layer.",
        "msg_settings_saved": "Preferences have been successfully saved!",
        "msg_settings_reset": "Default settings restored!",
        "msg_copied": "Statistics table copied to clipboard (TSV format)!",
        "msg_exported": "Exported statistics to",
        "msg_added_table": "Added statistics table layer to Layers panel!",
        
        # Defaults
        "default_std_area": "Overlap_ha",
        "default_std_percent": "Overlap_%",
        "default_grp_prefix": "Overlap_"
    },
    "est": {
        "title": "Overlap Toolkit",
        "subtitle": "Vektorpolügoonide ülekatete, grupeeritud ülekatete ja koondstatistika analüüs",
        "tab_standard": "1. Ülekate (tavaline)",
        "tab_grouped": "2. Grupeeritud ülekate (+ statistika)",
        "tab_settings": "3. Seaded",
        
        # Standard tab
        "grp_layers": "Kihid",
        "input_layer": "Sisendpolügoonide kiht:",
        "overlay_layer": "Kattekiht / maskikiht:",
        "selected_only": "Ainult valitud objektid",
        "grp_params": "Arvutusparameetrid",
        "area_field": "Pindala välja nimi:",
        "percent_field": "Protsendi välja nimi:",
        "detail_coeff": "Detailuskoefitsient (min ha):",
        "detail_coeff_tooltip": "Väiksemad lõikumised kui see lävi (hektarites) jäetakse välja liblika-/ribaelemntide vältimiseks.",
        "area_unit": "Pindala mõõtühik:",
        "unit_ha": "Hektarid (ha)",
        "unit_m2": "Ruutmeetrid (m²)",
        "precision": "Kümnendkohtade arv:",
        "grp_output": "Väljund",
        "save_to_file": "Salvesta faili (jäta tühjaks mälukihi jaoks):",
        "open_output": "Ava tulemuskiht pärast arvutamist",
        "btn_run_standard": "Käivita ülekatte analüüs",
        
        # Standard Styling
        "grp_styling": "Kihi kujunduse valikud",
        "chk_apply_style": "Rakenda tulemuskihile automaatne kujundus",
        "lbl_style_by": "Kujunduse alus:",
        "lbl_step": "Sagedussamm:",
        "tooltip_step": "Klasside sagedussamm (nt 10 -> 0, 1-10, 11-20, ...)",
        "style_opt_percent": "Ülekatte protsent (%)",
        "style_opt_area": "Ülekatte pindala (ha / m²)",
        
        # Grouped tab
        "input_layer_1": "Sisendpolügoonide kiht:",
        "overlay_mask_layer": "Kattekiht:",
        "group_field": "Grupeerimisväli:",
        "group_field_tooltip": "Kattekihi atribuudiväli, mille väärtuste järgi grupeeritakse.",
        "grp_grouped_options": "Grupeerimise ja arvutuse valikud",
        "field_prefix": "Tulemusvälja eesliide:",
        "strip_asterisks": "Liida prioriteetse elupaiga tärnid (*) ja eemalda tühikud",
        "strip_asterisks_tooltip": "Eemaldab tärni (*), et nt '1150*' ja '1150' liidetaks ühte gruppi.",
        "only_active": "Loo veerud ainult gruppidele, mille ülekate > 0",
        "grp_overall_stats": "Koondstatistika",
        "generate_stats": "Genereeri koondstatistika (käsitle sisendkihi objekte tervikuna)",
        "add_stats_layer": "Lisa koondstatistika tabel kihina QGIS projekti",
        "btn_run_grouped": "Käivita grupeeritud ülekatte analüüs",
        "style_grp_categorized": "Grupeerimisvälja järgi (alamstiil heledast tumedani, 0 eraldi)",
        "style_grp_frequency": "Sagedusklassid koguülekatte järgi (0, 1-10, ...)",
        
        # Stats Results
        "grp_stats_results": "Koondstatistika tulemused",
        "run_to_view_stats": "Koondstatistika vaatamiseks käivita grupeeritud ülekate.",
        "filter_group": "Filtreeri gruppi:",
        "filter_placeholder": "Kirjuta grupi filtreerimiseks...",
        "col_group": "Grupp",
        "col_features_count": "Objektide arv",
        "col_total_overlap": "Koguülekate",
        "col_pct_input": "Ülekatte % sisendist",
        "col_pct_group": "Ülekatte % grupist",
        "btn_copy_clipboard": "Kopeeri lõikelauale",
        "btn_export_csv": "Ekspordi CSV-sse...",
        "btn_add_table_qgis": "Lisa tabel QGISi",
        
        # Settings tab
        "grp_defaults": "Vaikeparameetrid",
        "def_detail_coeff": "Vaikimisi detailuskoefitsient (ha):",
        "def_unit": "Vaikimisi pindalaühik:",
        "def_precision": "Vaikimisi kümnendkohti:",
        "def_std_area_field": "Tavalise ülekatte pindala väli:",
        "def_std_percent_field": "Tavalise ülekatte % väli:",
        "def_grp_prefix": "Grupeeritud ülekatte välja eesliide:",
        "def_strip_asterisk": "Liida prioriteetse elupaiga tärnid (*) vaikimisi",
        "def_open_output": "Ava loodud kihid automaatselt kaardil",
        "def_apply_style": "Rakenda kihi kujundus vaikimisi",
        "def_style_step": "Vaikimisi sagedussamm:",
        "def_wfs_restrict_bbox": "Piira WFS päring kaardi vaateväljaga (restrictToRequestBBOX)",
        "def_wfs_restrict_bbox_tooltip": "WFS kihtide lisamisel tehakse päring vaikimisi ainult hetkel kaardil kuvatava ala (vaatevälja) ulatuses, mis teeb kihtide laadimise oluliselt kiiremaks.",
        "grp_ui_prefs": "Välimus ja keel",
        "language_label": "Kasutajaliidese keel:",
        "theme_label": "Värviteema:",
        "theme_system": "Süsteemi vaike",
        "theme_light": "Hele teema",
        "theme_dark": "Tume teema",
        "grp_perf_info": "Arvutusmeetod ja kujundusinfo",
        "perf_info_text": (
            "• <b>Kartesiaalne pindala:</b> Ülekatte pindala arvutatakse tasapinnalise kartesiaalse pindalana (inter.cartesianArea()) kihi koordinaatsüsteemis.<br>"
            "• <b>Ruumiline indeks:</b> Kattekiht indekseeritakse QgsSpatialIndex abil, mis teeb arvutuse kuni 1000x kiiremaks.<br>"
            "• <b>Detailuskoefitsient:</b> Väiksemad ülekatte pinnad kui lävi (nt 0,001 ha = 10 m²) seatakse nulliks.<br>"
            "• <b>Automaatne kujundus:</b> Tulemuskihti saab automaatselt kujundada sagedustabeli klassidega (0, 1-10, ...) või grupeerimisvälja järgi heledast tumedani."
        ),
        "btn_save_settings": "Salvesta seaded",
        "btn_reset_settings": "Taasta vaikesätted",
        
        # Common
        "btn_run_main": "Käivita",
        "tooltip_run_main": "Käivita aktiivse vahekaardi analüüs",
        "btn_browse_pc": "📁 Fail...",
        "tooltip_browse_pc": "Vali vektorandmete fail arvutist (.gpkg, .shp, .geojson jne)",
        "btn_wfs": "🌐 WFS...",
        "tooltip_wfs": "Vali kiht otse WFS kataloogist (EELIS, Kataster, PRIA, ETAK jne)",
        "browse_file_title": "Vali vektorandmete fail",
        "select_layer_title": "Vali kiht",
        "select_layer_prompt": "Fail sisaldab mitut kihti. Vali soovitud kiht:",
        "msg_file_load_error": "Faili avamisel tekkis viga:",
        "msg_not_polygon_warn": "Hoiatus: Valitud kiht ei paista olevat polügoonikiht.",
        "msg_continue_anyway": "Kas soovid sellegipoolest jätkata?",
        "dock_window": "Doki paneeli",
        "float_window": "Hõljuv aken",
        "btn_dock_toggle": "Doki / Hõljuv",
        "btn_cancel": "Katkesta",
        "btn_close": "Sulge",
        "status_ready": "Valmis",
        "status_calculating": "Arvutan...",
        "status_canceling": "Katkestan...",
        "status_canceled": "Toiming katkestati kasutaja poolt.",
        "status_completed": "Arvutus edukalt lõpetatud!",
        "elapsed": "Kulunud",
        "eta": "Jäänud",
        "msg_missing_input": "Palun vali sisendpolügoonide kiht.",
        "msg_missing_overlay": "Palun vali kattekiht.",
        "msg_missing_field": "Palun vali kattekihist grupeerimisväli.",
        "msg_settings_saved": "Seaded on edukalt salvestatud!",
        "msg_settings_reset": "Vaikesätted on taastatud!",
        "msg_copied": "Statistikatabel kopeeritud lõikelauale (TSV vormingus)!",
        "msg_exported": "Statistika eksporditud faili",
        "msg_added_table": "Koondstatistika tabel lisati kihtide paneeli!",
        
        # Defaults
        "default_std_area": "Ülekate_ha",
        "default_std_percent": "Ülekate_%",
        "default_grp_prefix": "Ülekate_"
    }
}


# Complete stylesheets ensuring high contrast and preventing white-on-light / dark-on-dark bugs
LIGHT_STYLESHEET = """
QDialog, QDockWidget, QWidget#mainDockContainer, QFrame#mainDockContainer, QFrame#headerBanner, QFrame#footerBar, QScrollArea, QScrollArea > QWidget > QWidget {
    background-color: #f6f8fa;
    color: #24292f;
}
QFrame#headerBanner {
    background-color: #f6f8fa;
    border-bottom: 1px solid #d0d7de;
    padding-bottom: 4px;
}
QFrame#footerBar {
    background-color: #f6f8fa;
    border-top: 1px solid #d0d7de;
    padding-top: 4px;
}
QDockWidget::title {
    background-color: #eaeef2;
    color: #24292f;
    padding: 6px;
    font-weight: bold;
    border-bottom: 1px solid #d0d7de;
}
QTreeWidget {
    background-color: #ffffff;
    color: #24292f;
    border: 1px solid #d0d7de;
    border-radius: 4px;
}
QTreeWidget::item:selected {
    background-color: #0969da;
    color: #ffffff;
}
QWidget {
    color: #24292f;
    font-size: 12px;
}
QGroupBox {
    font-weight: bold;
    border: 1px solid #d0d7de;
    border-radius: 6px;
    margin-top: 14px;
    padding-top: 14px;
    background-color: #ffffff;
    color: #24292f;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 2px 8px;
    color: #0969da;
    background-color: #ffffff;
    border-radius: 3px;
}
QTabWidget::pane {
    border: 1px solid #d0d7de;
    border-radius: 6px;
    background-color: #ffffff;
}
QTabBar::tab {
    background: #eaeef2;
    color: #57606a;
    border: 1px solid #d0d7de;
    border-bottom-color: #d0d7de;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 7px 16px;
    margin-right: 2px;
    font-weight: 500;
}
QTabBar::tab:selected {
    background: #ffffff;
    color: #0969da;
    border-bottom-color: #ffffff;
    font-weight: bold;
}
QTabBar::tab:hover {
    background: #f3f4f6;
    color: #24292f;
}
QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox {
    background-color: #ffffff;
    color: #24292f;
    border: 1px solid #d0d7de;
    border-radius: 4px;
    padding: 4px 8px;
    selection-background-color: #0969da;
    selection-color: #ffffff;
}
QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {
    border: 1px solid #0969da;
}
QComboBox QAbstractItemView {
    background-color: #ffffff;
    color: #24292f;
    selection-background-color: #0969da;
    selection-color: #ffffff;
}
QPushButton {
    background-color: #f6f8fa;
    color: #24292f;
    border: 1px solid #d0d7de;
    border-radius: 5px;
    padding: 6px 14px;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #f3f4f6;
    border-color: #1b1f2426;
}
QPushButton:pressed {
    background-color: #ebecf0;
}
QPushButton:disabled {
    background-color: #f6f8fa;
    color: #8c959f;
    border-color: #d0d7de;
}
QPushButton#primaryAction {
    background-color: #2da44e;
    color: #ffffff;
    border: 1px solid #2c974b;
    font-weight: bold;
}
QPushButton#primaryAction:hover {
    background-color: #2c974b;
}
QPushButton#primaryAction:pressed {
    background-color: #298e46;
}
QTableWidget {
    background-color: #ffffff;
    color: #24292f;
    gridline-color: #e1e4e8;
    border: 1px solid #d0d7de;
    border-radius: 4px;
}
QHeaderView::section {
    background-color: #f6f8fa;
    color: #24292f;
    font-weight: bold;
    padding: 5px;
    border: 1px solid #d0d7de;
}
QProgressBar {
    border: 1px solid #d0d7de;
    border-radius: 4px;
    text-align: center;
    background-color: #eaeef2;
    color: #24292f;
    font-weight: bold;
}
QProgressBar::chunk {
    background-color: #2da44e;
    border-radius: 3px;
}
QCheckBox {
    color: #24292f;
}
QLabel {
    color: #24292f;
}
QLabel#headerTitle {
    color: #1f2328;
    background-color: transparent;
}
QLabel#headerSubtitle {
    color: #57606a;
    background-color: transparent;
}
QLabel#statusLabel {
    color: #57606a;
}
"""

DARK_STYLESHEET = """
QDialog, QDockWidget, QWidget#mainDockContainer, QFrame#mainDockContainer, QFrame#headerBanner, QFrame#footerBar, QScrollArea, QScrollArea > QWidget > QWidget {
    background-color: #1e1f22;
    color: #dfe1e5;
}
QFrame#headerBanner {
    background-color: #1e1f22;
    border-bottom: 1px solid #3c3f41;
    padding-bottom: 4px;
}
QFrame#footerBar {
    background-color: #1e1f22;
    border-top: 1px solid #3c3f41;
    padding-top: 4px;
}
QDockWidget::title {
    background-color: #2b2d30;
    color: #dfe1e5;
    padding: 6px;
    font-weight: bold;
    border-bottom: 1px solid #3c3f41;
}
QTreeWidget {
    background-color: #1e1f22;
    color: #dfe1e5;
    border: 1px solid #3c3f41;
    border-radius: 4px;
}
QTreeWidget::item:selected {
    background-color: #1f6feb;
    color: #ffffff;
}
QWidget {
    color: #dfe1e5;
    font-size: 12px;
}
QGroupBox {
    font-weight: bold;
    border: 1px solid #3c3f41;
    border-radius: 6px;
    margin-top: 14px;
    padding-top: 14px;
    background-color: #26282c;
    color: #dfe1e5;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 2px 8px;
    color: #79c0ff;
    background-color: #26282c;
    border-radius: 3px;
}
QTabWidget::pane {
    border: 1px solid #3c3f41;
    border-radius: 6px;
    background-color: #26282c;
}
QTabBar::tab {
    background: #1e1f22;
    color: #8b949e;
    border: 1px solid #3c3f41;
    border-bottom-color: #3c3f41;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 7px 16px;
    margin-right: 2px;
    font-weight: 500;
}
QTabBar::tab:selected {
    background: #26282c;
    color: #58a6ff;
    border-bottom-color: #26282c;
    font-weight: bold;
}
QTabBar::tab:hover {
    background: #2d3135;
    color: #dfe1e5;
}
QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox {
    background-color: #1e1f22;
    color: #dfe1e5;
    border: 1px solid #4e5157;
    border-radius: 4px;
    padding: 4px 8px;
    selection-background-color: #1f6feb;
    selection-color: #ffffff;
}
QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {
    border: 1px solid #58a6ff;
}
QComboBox QAbstractItemView {
    background-color: #1e1f22;
    color: #dfe1e5;
    selection-background-color: #1f6feb;
    selection-color: #ffffff;
}
QPushButton {
    background-color: #2b2d30;
    color: #dfe1e5;
    border: 1px solid #4e5157;
    border-radius: 5px;
    padding: 6px 14px;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #36393e;
    border-color: #58a6ff;
}
QPushButton:pressed {
    background-color: #1e1f22;
}
QPushButton:disabled {
    background-color: #202124;
    color: #656c76;
    border-color: #34373c;
}
QPushButton#primaryAction {
    background-color: #238636;
    color: #ffffff;
    border: 1px solid #2ea043;
    font-weight: bold;
}
QPushButton#primaryAction:hover {
    background-color: #2ea043;
}
QPushButton#primaryAction:pressed {
    background-color: #238636;
}
QTableWidget {
    background-color: #1e1f22;
    color: #dfe1e5;
    gridline-color: #34373c;
    border: 1px solid #3c3f41;
    border-radius: 4px;
}
QHeaderView::section {
    background-color: #26282c;
    color: #dfe1e5;
    font-weight: bold;
    padding: 5px;
    border: 1px solid #3c3f41;
}
QProgressBar {
    border: 1px solid #4e5157;
    border-radius: 4px;
    text-align: center;
    background-color: #1e1f22;
    color: #dfe1e5;
    font-weight: bold;
}
QProgressBar::chunk {
    background-color: #238636;
    border-radius: 3px;
}
QCheckBox {
    color: #dfe1e5;
}
QLabel {
    color: #dfe1e5;
}
QLabel#headerTitle {
    color: #f0f6fc;
    background-color: transparent;
}
QLabel#headerSubtitle {
    color: #8b949e;
    background-color: transparent;
}
QLabel#statusLabel {
    color: #8b949e;
}
"""


def get_translation(key, lang="eng"):
    strings = TRANSLATIONS.get(lang, TRANSLATIONS["eng"])
    return strings.get(key, TRANSLATIONS["eng"].get(key, key))
