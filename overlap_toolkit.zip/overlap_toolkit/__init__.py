# -*- coding: utf-8 -*-
"""
Overlap Toolkit QGIS Plugin
"""

import importlib
import sys


def classFactory(iface):
    # Ensure all submodules are freshly reloaded when reinstalling or reloading the plugin
    submodules = [
        "overlap_toolkit.compat",
        "overlap_toolkit.i18n",
        "overlap_toolkit.styling",
        "overlap_toolkit.algorithms.standard_overlap",
        "overlap_toolkit.algorithms.grouped_overlap",
        "overlap_toolkit.algorithms.processing_provider",
        "overlap_toolkit.wfs_catalog",
        "overlap_toolkit.dialog",
        "overlap_toolkit.plugin",
    ]
    for mod_name in submodules:
        if mod_name in sys.modules:
            try:
                importlib.reload(sys.modules[mod_name])
            except Exception:
                pass

    from .plugin import OverlapToolkitPlugin
    return OverlapToolkitPlugin(iface)
