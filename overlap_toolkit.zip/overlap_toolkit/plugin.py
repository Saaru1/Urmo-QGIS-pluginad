# -*- coding: utf-8 -*-
"""
Overlap Toolkit QGIS Plugin Main Module
"""

import os
from qgis.PyQt.QtCore import Qt, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QDockWidget
from qgis.core import QgsApplication, QgsSettings

from .dialog import OverlapToolkitDialog, OverlapSuiteDialog
from .algorithms.processing_provider import OverlapProcessingProvider
from .compat import QT_RIGHT_DOCK_WIDGET_AREA


class OverlapToolkitPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.action = None
        self.provider = None

        self.plugin_dir = os.path.dirname(__file__)
        self.icon_path = os.path.join(self.plugin_dir, "icons", "icon.svg")
        if not os.path.exists(self.icon_path):
            self.icon_path = os.path.join(self.plugin_dir, "icons", "icon.png")

    def _cleanup_orphaned_docks(self):
        if not self.iface or not self.iface.mainWindow():
            return
        for dock in self.iface.mainWindow().findChildren(QDockWidget):
            if (
                dock.objectName() in ("OverlapToolkitDockWidget", "OverlapSuiteDockWidget")
                or dock.windowTitle() in ("Overlap Toolkit", "Overlap Suite")
            ):
                if dock is not self.dialog:
                    try:
                        self.iface.removeDockWidget(dock)
                        dock.close()
                        dock.deleteLater()
                    except Exception:
                        pass

    def initProcessing(self):
        self.provider = OverlapProcessingProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self._cleanup_orphaned_docks()

        icon = QIcon(self.icon_path)
        lang = str(QgsSettings().value("OverlapToolkit/language", QgsSettings().value("OverlapSuite/language", "est")))
        text = "Overlap Toolkit"
        tooltip = "Ülekatete ja grupeeritud ülekatete analüüs koos koondstatistikaga" if lang == "est" else "Vector Overlaps, Grouped Overlaps and Overall Statistics"

        self.action = QAction(icon, text, self.iface.mainWindow())
        self.action.setToolTip(tooltip)
        self.action.triggered.connect(self.run)

        self.iface.addVectorToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("&Overlap Toolkit", self.action)

        self.initProcessing()

    def unload(self):
        if self.action:
            self.iface.removePluginVectorMenu("&Overlap Toolkit", self.action)
            self.iface.removeVectorToolBarIcon(self.action)

        if self.provider:
            try:
                QgsApplication.processingRegistry().removeProvider(self.provider)
            except Exception:
                pass

        if self.dialog:
            try:
                self.iface.removeDockWidget(self.dialog)
                self.dialog.close()
                self.dialog.deleteLater()
            except Exception:
                pass
            self.dialog = None

        self._cleanup_orphaned_docks()

    def run(self):
        if self.dialog is None:
            self._cleanup_orphaned_docks()
            self.dialog = OverlapToolkitDialog(self.iface)
            self.iface.addDockWidget(QT_RIGHT_DOCK_WIDGET_AREA, self.dialog)

            is_floating = bool(QgsSettings().value("OverlapToolkit/is_floating", QgsSettings().value("OverlapSuite/is_floating", False, type=bool)))
            self.dialog.setFloating(is_floating)

        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()


# Backward compatibility alias
OverlapSuitePlugin = OverlapToolkitPlugin
