import pandas as pd
from qgis.PyQt.QtWidgets import (
    QListWidget, QAbstractItemView, QTableView, QDialog,
    QVBoxLayout, QHBoxLayout, QLineEdit, QDialogButtonBox, QStyledItemDelegate,
    QStyle, QTreeWidget, QMenu, QApplication, QListWidgetItem, QStyleOptionViewItem, QMessageBox,
    QCheckBox, QDoubleSpinBox, QLabel
)
from qgis.PyQt.QtCore import Qt, QAbstractTableModel, QRect, QEvent, pyqtSignal, QObject
from qgis.PyQt.QtGui import QColor, QBrush, QFont, QKeySequence

from qgis.core import QgsMimeDataUtils, QgsProject
from .compat import *
from .i18n import tr
from .theme import ThemeManager
from .wfs_manager import WfsAuthManager


class LogEmitter(QObject):
    log_signal = pyqtSignal(str, bool)


class CatalogTreeWidget(QTreeWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setSelectionMode(QT_EXTENDED_SELECTION)

    def mimeData(self, items):
        mime_data = super().mimeData(items)
        qgis_uris = []

        for item in items:
            data = item.data(0, QT_USER_ROLE)
            if isinstance(data, dict):
                l_type = data.get("type")
                uri_val = data.get("uri")
                name_val = data.get("name")

                if l_type == "wfs" and uri_val and name_val:
                    crs_authid = QgsProject.instance().crs().authid() or 'EPSG:3301'
                    full_uri = WfsAuthManager.build_wfs_uri(
                        uri_val, name_val, crs_authid=crs_authid,
                        server_name=data.get("server_name")
                    )

                    u = QgsMimeDataUtils.Uri()
                    u.layerType = "vector"
                    u.providerKey = "WFS"
                    u.name = name_val
                    u.uri = full_uri
                    qgis_uris.append(u)

                elif l_type == "local" and uri_val and name_val:
                    u = QgsMimeDataUtils.Uri()
                    u.layerType = "vector"
                    u.providerKey = "ogr"
                    u.name = name_val
                    u.uri = uri_val
                    qgis_uris.append(u)

        if qgis_uris:
            qgis_mime = QgsMimeDataUtils.encodeUriList(qgis_uris)
            for f in qgis_mime.formats():
                mime_data.setData(f, qgis_mime.data(f))

        return mime_data


class GeometrySelectionDialog(QDialog):
    def __init__(self, layer_name, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("WFS Geometry Types: {name}", name=layer_name))
        ThemeManager.apply_dialog_theme(self)
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(tr("Select geometry types to include.<br><i>Points and Lines will be buffered into Polygons.</i>")))

        self.cb_poly = QCheckBox(tr("Include Polygons"))
        self.cb_poly.setChecked(True)
        layout.addWidget(self.cb_poly)

        h_line = QHBoxLayout()
        self.cb_line = QCheckBox(tr("Include Lines"))
        self.cb_line.setChecked(True)
        self.sb_line = QDoubleSpinBox()
        self.sb_line.setRange(0.01, 100000.0)
        self.sb_line.setPrefix(tr("Buffer (m): "))
        self.sb_line.setValue(5.0)
        h_line.addWidget(self.cb_line)
        h_line.addWidget(self.sb_line)
        layout.addLayout(h_line)

        h_pt = QHBoxLayout()
        self.cb_pt = QCheckBox(tr("Include Points"))
        self.cb_pt.setChecked(True)
        self.sb_pt = QDoubleSpinBox()
        self.sb_pt.setRange(0.01, 100000.0)
        self.sb_pt.setPrefix(tr("Buffer (m): "))
        self.sb_pt.setValue(10.0)
        h_pt.addWidget(self.cb_pt)
        h_pt.addWidget(self.sb_pt)
        layout.addLayout(h_pt)

        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def get_settings(self):
        return {
            "include_polygons": self.cb_poly.isChecked(),
            "include_lines": self.cb_line.isChecked(),
            "include_points": self.cb_pt.isChecked(),
            "ln_buffer": self.sb_line.value(),
            "pt_buffer": self.sb_pt.value()
        }


class SearchableListDialog(QDialog):
    def __init__(self, title, items, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(320, 420)
        ThemeManager.apply_dialog_theme(self)
        layout = QVBoxLayout(self)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText(tr("Search values..."))
        self.search_box.textChanged.connect(self.filter_items)
        layout.addWidget(self.search_box)

        self.list_widget = QListWidget()
        self.list_widget.addItems(items)
        self.list_widget.itemDoubleClicked.connect(lambda _: self.accept())
        layout.addWidget(self.list_widget)

        self.button_box = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.selected_value = None

    def filter_items(self, text):
        search_text = text.lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item.setHidden(search_text not in item.text().lower())

    def accept(self):
        selected = self.list_widget.currentItem()
        if selected:
            self.selected_value = selected.text()
        super().accept()


class HoverDeleteDelegate(QStyledItemDelegate):
    def __init__(self, parent=None, hierarchical=False, confirm_delete=False):
        super().__init__(parent)
        self.hierarchical = hierarchical
        self.confirm_delete = confirm_delete

    def paint(self, painter, option, index):
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)

        painter.save()
        if self.hierarchical:
            if index.row() == 0:
                opt.font.setBold(True)
            else:
                opt.font.setBold(False)
                opt.rect.setLeft(opt.rect.left() + 15)

        self.parent().style().drawControl(QSTYLE_CE_ITEMVIEWITEM, opt, painter)

        if option.state & QSTYLE_STATE_MOUSEOVER:
            rect = option.rect
            c = ThemeManager.colors()
            painter.setPen(QColor(c["delete_icon"]))
            font = painter.font()
            font.setBold(True)
            font.setPointSize(12)
            painter.setFont(font)
            painter.drawText(QRect(rect.right() - 20, rect.top(), 20, rect.height()), QT_ALIGN_CENTER, "×")

        painter.restore()

    def editorEvent(self, event, model, option, index):
        if event.type() == QEVENT_MOUSEBUTTONRELEASE and event.button() == QT_LEFT_BUTTON:
            rect = option.rect
            x_rect = QRect(rect.right() - 20, rect.top(), 20, rect.height())
            if x_rect.contains(event.pos()):
                if self.confirm_delete:
                    reply = QMessageBox.question(
                        None,
                        tr("Confirm Deletion"),
                        tr("Are you sure you want to delete '{name}'?", name=index.data()),
                        QMESSAGEBOX_YES | QMESSAGEBOX_NO
                    )
                    if reply == QMESSAGEBOX_YES:
                        model.removeRow(index.row())
                else:
                    model.removeRow(index.row())
                return True
        return super().editorEvent(event, model, option, index)


class DragDropList(QListWidget):
    item_deleted = pyqtSignal(str)

    def __init__(self, title, removable=False, accept_drops=True, hierarchical=False, confirm_delete=False, parent=None):
        super().__init__(parent)
        self.title = title
        self.setDragEnabled(True)
        self.confirm_delete = confirm_delete
        self.setAcceptDrops(accept_drops)
        self.setDropIndicatorShown(True)
        self.setSelectionMode(QT_EXTENDED_SELECTION)
        self.setMinimumHeight(1)

        if removable:
            self.setMouseTracking(True)
            self.setItemDelegate(HoverDeleteDelegate(self, hierarchical=hierarchical, confirm_delete=confirm_delete))

        self.setDefaultDropAction(QT_MOVE_ACTION)
        self.setDragDropMode(QT_DRAG_DROP if accept_drops else QT_DRAG_ONLY)

        self.model().rowsRemoved.connect(self.on_row_removed)

    def on_row_removed(self, parent, start, end):
        self.item_deleted.emit("removed")

    def keyPressEvent(self, event):
        if event.key() in (QT_KEY_DELETE, QT_KEY_BACKSPACE):
            if self.selectedItems():
                if self.confirm_delete:
                    names = ", ".join([item.text() for item in self.selectedItems()])
                    reply = QMessageBox.question(
                        None,
                        tr("Confirm Deletion"),
                        tr("Are you sure you want to delete '{name}'?", name=names),
                        QMESSAGEBOX_YES | QMESSAGEBOX_NO
                    )
                    if reply != QMESSAGEBOX_YES:
                        return
                for item in self.selectedItems():
                    self.takeItem(self.row(item))
        else:
            super().keyPressEvent(event)


class FieldDropList(DragDropList):
    def dragEnterEvent(self, event):
        if isinstance(event.source(), QTreeWidget):
            event.ignore()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if isinstance(event.source(), QTreeWidget):
            event.ignore()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if isinstance(event.source(), QTreeWidget):
            event.ignore()
        else:
            super().dropEvent(event)

            for i in range(self.count()):
                item = self.item(i)

                if getattr(self, 'title', '') != "Filters":
                    item.setData(QT_USER_ROLE + 1, None)

                raw_name = item.data(QT_USER_ROLE)
                text = item.text()

                if not raw_name:
                    if ": " in text and "Calculate area" not in text:
                        raw_name = text.split(": ")[0].strip()
                        if text.startswith("["):
                            b_idx = text.find("]")
                            if b_idx != -1:
                                remainder = text[b_idx + 1:]
                                if ": " in remainder:
                                    raw_name = (text[:b_idx + 1] + remainder.split(": ", 1)[0]).strip()
                    else:
                        raw_name = text

                if raw_name:
                    if getattr(self, 'title', '') == "Values":
                        if not text.startswith(f"{raw_name}:"):
                            item.setText(f"{raw_name}: Sum")
                    else:
                        if getattr(self, 'title', '') == "Filters" and item.data(QT_USER_ROLE + 1) is not None:
                            pass
                        else:
                            item.setText(raw_name)

                    item.setToolTip(item.text())


class ProfileDropList(DragDropList):
    edit_requested = pyqtSignal(str)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setContextMenuPolicy(QT_CUSTOM_CONTEXT_MENU)
        self.customContextMenuRequested.connect(self.show_context_menu)

    def show_context_menu(self, pos):
        item = self.itemAt(pos)
        if not item:
            return
        menu = QMenu(self)
        edit_action = menu.addAction(tr("✏️ Edit Profile Settings..."))

        action = menu.exec(self.mapToGlobal(pos)) if hasattr(menu, 'exec') else menu.exec_(self.mapToGlobal(pos))
        if action == edit_action:
            self.edit_requested.emit(item.text())

    def supportedDropActions(self):
        return QT_COPY_ACTION


class BaseLayerDropList(DragDropList):
    def dragEnterEvent(self, event):
        if isinstance(event.source(), QTreeWidget) or event.source() == self:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if isinstance(event.source(), QTreeWidget) or event.source() == self:
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        source = event.source()
        if isinstance(source, QTreeWidget):
            added = False
            for item in source.selectedItems():
                data = item.data(0, QT_USER_ROLE)
                if isinstance(data, dict) and data.get("type") in ["canvas", "local", "wfs"]:
                    if not added:
                        data = dict(data)
                        display_text = item.text(0)

                        if data.get("type") == "wfs":
                            dlg = GeometrySelectionDialog(display_text, self)
                            if dlg.exec() if hasattr(dlg, 'exec') else dlg.exec_():
                                settings = dlg.get_settings()
                                data.update(settings)

                                types = []
                                if settings["include_polygons"]:
                                    types.append("Pg")
                                if settings["include_lines"]:
                                    types.append("Ln")
                                if settings["include_points"]:
                                    types.append("Pt")

                                label_suffix = f" [{','.join(types)}] (Buf: {settings['ln_buffer']}m/{settings['pt_buffer']}m)"
                                display_text = f"{display_text.split(' [')[0]}{label_suffix}"
                            else:
                                continue

                        self.clear()
                        new_item = QListWidgetItem(display_text)
                        new_item.setData(QT_USER_ROLE, data)
                        new_item.setIcon(item.icon(0))
                        self.addItem(new_item)
                        added = True
            event.accept()
        elif source == self:
            super().dropEvent(event)
        else:
            event.ignore()


class JoinLayerDropList(DragDropList):
    def dragEnterEvent(self, event):
        if isinstance(event.source(), QTreeWidget) or event.source() == self:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if isinstance(event.source(), QTreeWidget) or event.source() == self:
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        source = event.source()
        if isinstance(source, QTreeWidget):
            for item in source.selectedItems():
                data = item.data(0, QT_USER_ROLE)
                if isinstance(data, dict) and data.get("type") in ["canvas", "local", "wfs"]:
                    exists = False
                    for i in range(self.count()):
                        if self.item(i).text().startswith(item.text(0).split(' [')[0]):
                            exists = True

                    if not exists:
                        data = dict(data)
                        display_text = item.text(0)

                        if data.get("type") == "wfs":
                            dlg = GeometrySelectionDialog(display_text, self)
                            if dlg.exec() if hasattr(dlg, 'exec') else dlg.exec_():
                                settings = dlg.get_settings()
                                data.update(settings)

                                types = []
                                if settings["include_polygons"]:
                                    types.append("Pg")
                                if settings["include_lines"]:
                                    types.append("Ln")
                                if settings["include_points"]:
                                    types.append("Pt")

                                label_suffix = f" [{','.join(types)}] (Buf: {settings['ln_buffer']}m/{settings['pt_buffer']}m)"
                                display_text = f"{display_text.split(' [')[0]}{label_suffix}"
                            else:
                                continue

                        new_item = QListWidgetItem(display_text)
                        new_item.setData(QT_USER_ROLE, data)
                        new_item.setIcon(item.icon(0))
                        self.addItem(new_item)
            event.accept()
        elif source == self:
            super().dropEvent(event)
        else:
            event.ignore()


class TargetListWidget(DragDropList):
    schema_requested = pyqtSignal(object)
    filter_requested = pyqtSignal(object)
    buffer_role_requested = pyqtSignal(object)
    secondary_requested = pyqtSignal(object)

    def __init__(self, title, dialog_ref, parent=None):
        super().__init__(title, removable=True, parent=parent)
        self.dialog_ref = dialog_ref
        self.setContextMenuPolicy(QT_CUSTOM_CONTEXT_MENU)
        self.customContextMenuRequested.connect(self.show_context_menu)

    def show_context_menu(self, pos):
        item = self.itemAt(pos)
        if not item:
            return
        menu = QMenu(self)
        set_group_action = menu.addAction(tr("Set Grouping Field..."))
        set_sec_action = menu.addAction(tr("ƒx Set Secondary Expression..."))
        set_filter_action = menu.addAction(tr("⚙️ Set Attribute Filter..."))
        set_buffer_role = menu.addAction(tr("🎯 Assign Buffer Roles..."))

        action = menu.exec(self.mapToGlobal(pos)) if hasattr(menu, 'exec') else menu.exec_(self.mapToGlobal(pos))

        if action == set_group_action:
            self.schema_requested.emit(item)
        elif action == set_sec_action:
            self.secondary_requested.emit(item)
        elif action == set_filter_action:
            self.filter_requested.emit(item)
        elif action == set_buffer_role:
            self.buffer_role_requested.emit(item)

    def dragEnterEvent(self, event):
        source = event.source()
        if isinstance(source, QTreeWidget) or source == self.dialog_ref.geo_profile_list or source == self:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        source = event.source()
        if isinstance(source, QTreeWidget) or source == self.dialog_ref.geo_profile_list or source == self:
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        source = event.source()
        if isinstance(source, QTreeWidget):
            for item in source.selectedItems():
                data = item.data(0, QT_USER_ROLE)
                if isinstance(data, dict) and data.get("type") in ["canvas", "local", "wfs"]:
                    self.dialog_ref.add_target_layer(item.text(0), data)
            event.accept()
        elif source == self.dialog_ref.geo_profile_list:
            for item in source.selectedItems():
                self.dialog_ref.profile_io.load_wfs_profile(item.text())
            event.setDropAction(QT_COPY_ACTION)
            event.accept()
        elif source == self:
            super().dropEvent(event)
        else:
            event.ignore()


class DashboardTableView(QTableView):
    row_selected = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(1)
        self.setSelectionBehavior(QT_SELECT_ROWS)

    def selectionChanged(self, selected, deselected):
        super().selectionChanged(selected, deselected)
        indexes = self.selectionModel().selectedRows()

        if not indexes:
            self.row_selected.emit({})
            return

        model = self.model()
        if model and hasattr(model, '_data') and not model._data.empty:
            row_idx = indexes[0].row()
            try:
                row_data = model._data.iloc[row_idx].to_dict()
                self.row_selected.emit(row_data)
            except Exception:
                pass

    def keyPressEvent(self, event):
        if event.matches(QKEYSEQUENCE_COPY):
            self.copy_selection()
        else:
            super().keyPressEvent(event)

    def copy_selection(self):
        selection = self.selectedIndexes()
        if not selection:
            return
        rows = {}
        for idx in selection:
            rows.setdefault(idx.row(), []).append(idx)
        text = ""
        for row in sorted(rows.keys()):
            text += "\t".join([str(idx.data()) for idx in sorted(rows[row], key=lambda x: x.column())]) + "\n"
        QApplication.clipboard().setText(text)


class PandasModel(QAbstractTableModel):
    def __init__(self, data):
        super().__init__()
        self._data = data
        self.row_colors = {}
        self.alert_rows = set()
        self.subtotal_rows = set()
        self.grandtotal_rows = set()
        self.recalculate_colors()

    def recalculate_colors(self):
        self.row_colors.clear()
        self.alert_rows.clear()
        self.subtotal_rows.clear()
        self.grandtotal_rows.clear()
        if not self._data.empty and self._data.shape[1] > 0:
            has_alert = 'Sensitive Alert' in self._data.columns
            current_bg = False
            last_val = None
            for row in range(self._data.shape[0]):
                row_vals = [str(v) for v in self._data.iloc[row]]
                val = str(self._data.iloc[row, 0])
                if val == 'GRAND TOTAL' or 'GRAND TOTAL' in row_vals:
                    self.grandtotal_rows.add(row)
                    self.row_colors[row] = False
                    continue
                if any('SUBTOTAL' in v for v in row_vals):
                    self.subtotal_rows.add(row)

                if val != last_val and last_val is not None:
                    current_bg = not current_bg
                self.row_colors[row] = current_bg
                last_val = val

                if has_alert and str(self._data.iloc[row].get('Sensitive Alert', '')) == 'YES':
                    self.alert_rows.add(row)

    def sort(self, Ncol, order):
        if self._data.empty:
            return
        self.layoutAboutToBeChanged.emit()
        try:
            is_asc = order == Qt.SortOrder.AscendingOrder
        except AttributeError:
            is_asc = order == Qt.AscendingOrder

        c_name = self._data.columns[Ncol]
        c0_name = self._data.columns[0]

        gt_mask = self._data.iloc[:, 0].astype(str) == 'GRAND TOTAL'
        gt_row = self._data[gt_mask]
        main_data = self._data[~gt_mask].copy()

        if main_data.empty:
            self.layoutChanged.emit()
            return

        main_data['_is_subtotal'] = main_data.apply(lambda row: any('SUBTOTAL' in str(v) for v in row), axis=1)

        if not main_data[c0_name].duplicated().any() or Ncol == 0:
            main_data = main_data.sort_values(by=[c_name, '_is_subtotal'], ascending=[is_asc, True])
        else:
            main_data = main_data.sort_values(by=[c0_name, '_is_subtotal', c_name], ascending=[True, True, is_asc])

        self._data = pd.concat([main_data.drop(columns=['_is_subtotal']), gt_row]).reset_index(drop=True)
        self.recalculate_colors()
        self.layoutChanged.emit()

    def rowCount(self, parent=None):
        return self._data.shape[0]

    def columnCount(self, parent=None):
        return self._data.shape[1]

    def data(self, index, role):
        if not index.isValid():
            return None

        r = index.row()
        is_alert = r in self.alert_rows
        is_gt = r in self.grandtotal_rows
        is_sub = r in self.subtotal_rows

        if role == QT_DISPLAY_ROLE:
            val = self._data.iloc[r, index.column()]
            return "" if pd.isna(val) else str(val)

        if role == QT_BACKGROUND_ROLE:
            c = ThemeManager.colors()
            if is_alert:
                return QBrush(QColor(c["table_alert_bg"]))
            if is_gt:
                return QBrush(QColor(c["table_grandtotal_bg"]))
            if is_sub:
                return QBrush(QColor(c["table_subtotal_bg"]))
            return QBrush(QColor(c["table_odd_bg"] if self.row_colors.get(r, False) else c["table_even_bg"]))

        if role == QT_FOREGROUND_ROLE:
            c = ThemeManager.colors()
            if is_alert:
                return QBrush(QColor(c["table_alert_fg"]))
            return QBrush(QColor(c["table_text"]))

        if role == QT_FONT_ROLE:
            if is_gt or is_sub or is_alert:
                font = QFont()
                font.setBold(True)
                return font

        return None

    def headerData(self, col, orientation, role):
        if orientation == QT_HORIZONTAL and role == QT_DISPLAY_ROLE and col < len(self._data.columns):
            return str(self._data.columns[col])
        if orientation == QT_VERTICAL and role == QT_DISPLAY_ROLE and col < len(self._data.index):
            return str(self._data.index[col])
        return None
