import os
import traceback
import json
import tempfile
import pandas as pd

from qgis.PyQt.QtWidgets import (QDockWidget, QVBoxLayout, QHBoxLayout, QDialog, 
                                 QLabel, QPushButton, QWidget, QFileDialog, 
                                 QMessageBox, QListWidgetItem, QInputDialog, QLineEdit,
                                 QRadioButton, QButtonGroup, QDialogButtonBox, QSizePolicy,
                                 QApplication, QMenu, QTreeWidgetItem, QListWidget, QAbstractItemView, QCheckBox, QDoubleSpinBox)
from qgis.PyQt.QtCore import QTimer, Qt, QEvent, QUrl
from qgis.PyQt.QtGui import QColor
from qgis.core import (QgsProject, QgsApplication, QgsSettings, QgsGeometry, QgsIconUtils)
from qgis.gui import QgsRubberBand

from .compat import *
from .export_dialogs import ExportGeoDialog, CanvasDisplayDialog
from .buffer_manager import BufferManagerDialog
from .profile_manager import ProfileEditorDialog
from .geodata_exporter import GeodataExporter
from .wfs_manager import WfsManager
from .profile_io import ProfileIO
from .custom_widgets import LogEmitter, SearchableListDialog, PandasModel, GeometrySelectionDialog
from .pivot_logic import PivotEngine, PivotCalculationTask
from .geosearch_logic import GeosearchTask, WfsSchemaFetchTask
from .ui_builder import PivotUIBuilder
from .export_pdf_report import ReportGenerator
from .temporal_logic import TemporalManager

class BufferRoleDialog(QDialog):
    def __init__(self, current_role, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Assign Buffer Role")
        layout = QVBoxLayout(self)
        
        layout.addWidget(QLabel("Select which buffers this Target Layer should intersect:"))
        
        self.bg = QButtonGroup(self)
        self.r_none = QRadioButton("None (AOI Only)")
        self.r_main = QRadioButton("Main Only")
        self.r_custom = QRadioButton("Custom Only")
        self.r_both = QRadioButton("Main + Custom")
        
        self.bg.addButton(self.r_none); layout.addWidget(self.r_none)
        self.bg.addButton(self.r_main); layout.addWidget(self.r_main)
        self.bg.addButton(self.r_custom); layout.addWidget(self.r_custom)
        self.bg.addButton(self.r_both); layout.addWidget(self.r_both)
        
        if current_role == "None": self.r_none.setChecked(True)
        elif current_role == "Custom Only": self.r_custom.setChecked(True)
        elif current_role == "Main + Custom": self.r_both.setChecked(True)
        else: self.r_main.setChecked(True) 
            
        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        
    def get_role(self):
        if self.r_none.isChecked(): return "None"
        elif self.r_custom.isChecked(): return "Custom Only"
        elif self.r_both.isChecked(): return "Main + Custom"
        return "Main Only"

class MultiSelectFilterDialog(QDialog):
    def __init__(self, title, items, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(350, 400)
        layout = QVBoxLayout(self)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search values...")
        self.search.textChanged.connect(self.filter_list)
        layout.addWidget(self.search)

        self.list_widget = QListWidget()
        for i in items:
            item = QListWidgetItem(str(i))
            item.setCheckState(QT_UNCHECKED)
            self.list_widget.addItem(item)
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        self.btn_all = QPushButton("Select All")
        self.btn_none = QPushButton("Clear All")
        self.btn_all.clicked.connect(self.select_all)
        self.btn_none.clicked.connect(self.clear_all)
        btn_layout.addWidget(self.btn_all)
        btn_layout.addWidget(self.btn_none)
        layout.addLayout(btn_layout)

        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def filter_list(self, text):
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item.setHidden(text.lower() not in item.text().lower())

    def select_all(self):
        for i in range(self.list_widget.count()):
            if not self.list_widget.item(i).isHidden():
                self.list_widget.item(i).setCheckState(QT_CHECKED)

    def clear_all(self):
        for i in range(self.list_widget.count()):
            if not self.list_widget.item(i).isHidden():
                self.list_widget.item(i).setCheckState(QT_UNCHECKED)

    def get_selected(self):
        return [self.list_widget.item(i).text() for i in range(self.list_widget.count()) if self.list_widget.item(i).checkState() == QT_CHECKED]

class PivotDockWidget(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Spatial Pivot Dashboard", parent)
        self.iface = iface
        self.log_emitter = LogEmitter()
        self.log_emitter.log_signal.connect(self.log_message)
        
        self.engine = PivotEngine()
        self.engine.set_logger(lambda msg, err=False: self.log_emitter.log_signal.emit(msg, err))
        self.exporter = GeodataExporter(self)
        self.wfs_manager = WfsManager(self)
        self.profile_io = ProfileIO(self)
        
        self.current_listening_layer = None
        self.saved_column_widths = {}
        
        self.query_caches = {}      
        self.spatial_setup_hash = None   
        self.active_tasks = []
        
        self.current_geo_raw_data = None
        self.current_geo_aoi = None
        self.current_geo_aoi_buffered = [] 
        
        self.last_run_buffer_dists_main = [] 
        self.last_run_buffer_dists_custom = [] 
        
        self.last_geo_group = None
        self.precalculated_layers = [] 
        self.last_export_choices = None 
        self._was_canvas_showing = False 
        
        self.dashboard_mode = None 
        self.current_pivot_df = None
        self.display_df = None
        
        self.dock_content = QWidget()
        self.setWidget(self.dock_content)
        self.setMinimumHeight(100)
        self.dock_content.setMinimumHeight(100)
        
        self.setSizePolicy(QSIZEPOLICY_EXPANDING, QSIZEPOLICY_IGNORED)
        self.setAllowedAreas(QT_BOTTOM_DOCK_WIDGET_AREA | QT_TOP_DOCK_WIDGET_AREA)
            
        self.initUI()
        
        # --- THE FIX: Point/Line buffering dialog hook ---
        self.base_layer_list.itemDoubleClicked.connect(self.set_geometry_buffers)
        self.join_layer_list.itemDoubleClicked.connect(self.set_geometry_buffers)

        self.transpose_btn.toggled.connect(self.toggle_transpose)
        self.dash_filter_input.textChanged.connect(self.apply_dashboard_filter)
        self.chart_btn.toggled.connect(self.toggle_chart_view)
        
        try:
            self.fields_list.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        except AttributeError:
            self.fields_list.setDragDropMode(QAbstractItemView.DragOnly)
            
        self.fields_list.setDefaultDropAction(QT_COPY_ACTION)
        
        self.log_tab_index = self.tabs.indexOf(self.tab_logs)
        self.log_blink_timer = QTimer(self)
        self.log_blink_timer.timeout.connect(self.toggle_log_tab_color)
        self.blink_state = False
        self.blink_color = QColor()
        self.tabs.currentChanged.connect(self.on_tab_changed)

        self.result_table.setContextMenuPolicy(QT_CUSTOM_CONTEXT_MENU)
        self.result_table.customContextMenuRequested.connect(self.show_table_context_menu)
        
        self.profile_io.load_wfs_profiles()
        
        self.project = QgsProject.instance()
        self.project.layersAdded.connect(self.update_canvas_tree)
        self.project.layersRemoved.connect(self.update_canvas_tree)
        self.project.cleared.connect(self.update_canvas_tree)
        
        self.live_timer = QTimer()
        self.live_timer.setSingleShot(True)
        self.live_timer.timeout.connect(self.calculate_pivot)
        self.iface.mapCanvas().extentsChanged.connect(self.on_canvas_panned)
        
        self.edit_timer = QTimer()
        self.edit_timer.setSingleShot(True)
        self.edit_timer.timeout.connect(self.calculate_pivot)
        
        self.update_canvas_tree()
        self.wfs_manager.load_all_wfs_catalogs()
        
        self.temporal_manager = TemporalManager(self)
        
        self.log_message("Plugin Initialized successfully.")
        
        self.rows_list.installEventFilter(self)
        self.cols_list.installEventFilter(self)
        self.vals_list.installEventFilter(self)
        self.filters_list.installEventFilter(self)

    # --- THE FIX: Dialog for resolving non-polygon geometry overlap issues ---
    def set_geometry_buffers(self, item):
        data = item.data(QT_USER_ROLE)
        if not isinstance(data, dict): return
        
        display_text = item.text().split(" [")[0]
        d = GeometrySelectionDialog(display_text, self)
        
        # Pre-fill with existing settings
        d.cb_poly.setChecked(data.get("include_polygons", True))
        d.cb_line.setChecked(data.get("include_lines", True))
        d.cb_pt.setChecked(data.get("include_points", True))
        d.sb_line.setValue(data.get("ln_buffer", 5.0))
        d.sb_pt.setValue(data.get("pt_buffer", 10.0))
        
        if d.exec() if hasattr(d, 'exec') else d.exec_():
            settings = d.get_settings()
            data.update(settings)
            
            types = []
            if settings["include_polygons"]: types.append("Pg")
            if settings["include_lines"]: types.append("Ln")
            if settings["include_points"]: types.append("Pt")
            
            if not types: types.append("None")
            
            label_suffix = f" [{','.join(types)}] (Buf: {settings['ln_buffer']}m/{settings['pt_buffer']}m)"
            item.setText(f"{display_text}{label_suffix}")
            item.setData(QT_USER_ROLE, data)
            self.log_message(f"Updated geometry settings for {display_text}")

    # ========================================================
    # CHARTING & DASHBOARD VIEW LOGIC
    # ========================================================
    def toggle_chart_view(self, checked):
        if checked:
            self.dash_stack.setCurrentIndex(1)
            self.render_dashboard_chart()
        else:
            self.dash_stack.setCurrentIndex(0)

    def render_dashboard_chart(self):
        if self.display_df is None or self.display_df.empty:
            return

        try:
            df = self.display_df.copy()
            
            filter_text = self.dash_filter_input.text().lower()
            if filter_text:
                mask = df.astype(str).apply(lambda x: x.str.lower().str.contains(filter_text, regex=False)).any(axis=1)
                df = df[mask]

            if df.empty: return

            numeric_cols = df.select_dtypes(include='number').columns.tolist()
            if not numeric_cols:
                self.log_message("No numeric columns found to chart.", True)
                return

            categorical_cols = [c for c in df.columns if c not in numeric_cols]
            
            for cat in categorical_cols:
                df = df[~df[cat].astype(str).apply(lambda s: 'GRAND TOTAL' in s.upper() or 'SUBTOTAL' in s.upper())]
                
            if df.empty:
                return

            # --- THE FIX: Concatenate multiple categories row-by-row ---
            if len(categorical_cols) > 1:
                labels = df[categorical_cols].astype(str).agg(' | '.join, axis=1).tolist()
            elif len(categorical_cols) == 1:
                labels = df[categorical_cols[0]].astype(str).tolist()
            else:
                labels = ["All Data"] * len(df)
            # -----------------------------------------------------------

            # Check Qt UI for barmode, fallback to 'group'
            b_mode_raw = getattr(self, 'chart_barmode_combo', None)
            b_mode = b_mode_raw.currentText().lower() if b_mode_raw else "group"

            traces = []
            for col in numeric_cols:
                clean_data = df[col].fillna(0).tolist()
                traces.append({
                    'x': labels,
                    'y': clean_data,
                    'name': str(col),
                    'type': 'bar'
                })
                
            # Prepare data for HTML table
            table_headers = ["Category"] + [str(col) for col in numeric_cols]
            js_data = []
            for i, label in enumerate(labels):
                row = [label]
                for col in numeric_cols:
                    val = df[col].iloc[i]
                    row.append(val if not pd.isna(val) else 0)
                js_data.append(row)

            import json
            import os
            import tempfile
            plugin_dir = os.path.dirname(os.path.abspath(__file__))
            local_plotly_path = os.path.join(plugin_dir, 'js', 'plotly.min.js').replace("\\", "/")
            
            html_template = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Pivot Analysis Dashboard</title>
                <script src="file:///{local_plotly_path}"></script>
                <script>if (typeof Plotly === 'undefined') document.write('<script src="https://cdn.plot.ly/plotly-2.27.0.min.js"><\\/script>');</script>
                <style>
                    body {{ margin: 0; padding: 20px; background-color: #f4f6f7; font-family: 'Segoe UI', Tahoma, sans-serif; }}
                    .dashboard-container {{ max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
                    
                    /* Toolbar Styles */
                    .toolbar {{ display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; background: #ecf0f1; padding: 15px; border-radius: 6px; }}
                    .toolbar-group {{ display: flex; flex-direction: column; gap: 5px; }}
                    .toolbar label {{ font-size: 12px; font-weight: bold; color: #2c3e50; text-transform: uppercase; }}
                    .toolbar input, .toolbar select {{ padding: 8px; border: 1px solid #bdc3c7; border-radius: 4px; font-size: 14px; min-width: 160px; }}
                    .toolbar button {{ padding: 8px 15px; background: #2980b9; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; margin-top: 19px; }}
                    .toolbar button:hover {{ background: #3498db; }}
                    
                    #chart-container {{ width: 100%; height: 60vh; min-height: 400px; margin-bottom: 30px; }}
                    
                    /* Table Styles */
                    .data-table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
                    .data-table th {{ background-color: #ecf0f1; color: #2c3e50; padding: 12px; text-align: left; border-bottom: 2px solid #bdc3c7; position: sticky; top: 0; transition: background 0.2s; }}
                    .data-table th:hover {{ background-color: #d5dbdb; }}
                    .data-table td {{ padding: 10px 12px; border-bottom: 1px solid #ecf0f1; color: #34495e; }}
                    .data-table tr:hover {{ background-color: #f9fbfc; }}
                </style>
            </head>
            <body>
                <div class="dashboard-container">
                    <div class="toolbar">
                        <div class="toolbar-group">
                            <label>Chart Title</label>
                            <input type="text" id="in-title" value="Pivot Analysis Dashboard">
                        </div>
                        <div class="toolbar-group">
                            <label>X-Axis Title</label>
                            <input type="text" id="in-xaxis" placeholder="e.g., Category">
                        </div>
                        <div class="toolbar-group">
                            <label>Y-Axis Title</label>
                            <input type="text" id="in-yaxis" value="Value">
                        </div>
                        <div class="toolbar-group">
                            <label>Chart Type</label>
                            <select id="in-type">
                                <option value="bar">Bar Chart</option>
                                <option value="scatter">Line Chart</option>
                            </select>
                        </div>
                        <button onclick="updateChart()">Apply Changes</button>
                    </div>
                    
                    <div id="chart-container"></div>
                    
                    <h3 style="color: #2c3e50; margin-top: 20px;">Data Table</h3>
                    <div style="overflow-x: auto; max-height: 400px; border: 1px solid #bdc3c7; border-radius: 4px;">
                        <table class="data-table" id="data-table">
                            <!-- Populated by JS -->
                        </table>
                    </div>
                </div>

                <script>
                    var traces = {json.dumps(traces)};
                    var tableHeaders = {json.dumps(table_headers)};
                    var tableData = {json.dumps(js_data)};
                    
                    var layout = {{
                        title: 'Pivot Analysis Dashboard',
                        barmode: '{b_mode}',
                        margin: {{ t: 50, b: 120, l: 60, r: 20 }},
                        xaxis: {{ type: 'category', automargin: true, tickangle: -45, title: '' }},
                        yaxis: {{ title: 'Value', automargin: true, gridcolor: '#e5e8e8' }},
                        hovermode: 'closest',
                        plot_bgcolor: 'rgba(0,0,0,0)',
                        paper_bgcolor: 'rgba(0,0,0,0)',
                        legend: {{ orientation: 'h', y: -0.3 }}
                    }};
                    var config = {{ responsive: true, displayModeBar: true, displaylogo: false }};
                    
                    Plotly.newPlot('chart-container', traces, layout, config);

                    function updateChart() {{
                        var newTitle = document.getElementById('in-title').value;
                        var newX = document.getElementById('in-xaxis').value;
                        var newY = document.getElementById('in-yaxis').value;
                        var newType = document.getElementById('in-type').value;
                        
                        var updateLayout = {{
                            title: newTitle,
                            'xaxis.title.text': newX,
                            'yaxis.title.text': newY,
                            'xaxis.type': 'category'
                        }};
                        
                        var updateTrace = {{ type: newType }};
                        if (newType === 'scatter') {{
                            updateTrace.mode = 'lines+markers';
                        }}
                        
                        Plotly.restyle('chart-container', updateTrace);
                        Plotly.relayout('chart-container', updateLayout);
                    }}

                    var sortDirs = {{}};

                    function sortTable(colIndex) {{
                        var isAsc = !sortDirs[colIndex];
                        sortDirs[colIndex] = isAsc;
                        
                        tableData.sort(function(a, b) {{
                            var valA = a[colIndex];
                            var valB = b[colIndex];
                            
                            var numA = typeof valA === 'number' ? valA : parseFloat(String(valA).replace(/[^0-9.-]+/g,""));
                            var numB = typeof valB === 'number' ? valB : parseFloat(String(valB).replace(/[^0-9.-]+/g,""));
                            
                            var isNumA = !isNaN(numA) && String(valA).match(/[0-9]/);
                            var isNumB = !isNaN(numB) && String(valB).match(/[0-9]/);
                            
                            if (isNumA && isNumB) {{
                                return isAsc ? numA - numB : numB - numA;
                            }}
                            return isAsc ? String(valA).localeCompare(String(valB)) : String(valB).localeCompare(String(valA));
                        }});
                        
                        buildTable();
                        syncChartWithTable();
                    }}

                    function syncChartWithTable() {{
                        var newX = tableData.map(function(row) {{ return String(row[0]); }});
                        var xData = [];
                        var yData = [];
                        
                        for (var t = 0; t < traces.length; t++) {{
                            xData.push(newX);
                            yData.push(tableData.map(function(row) {{ return row[t + 1]; }}));
                        }}
                        
                        Plotly.update('chart-container', 
                            {{ x: xData, y: yData }}, 
                            {{ 'xaxis.type': 'category' }}
                        );
                    }}

                    function buildTable() {{
                        var table = document.getElementById('data-table');
                        var thead = '<thead><tr>';
                        tableHeaders.forEach(function(h, index) {{
                            thead += '<th style="cursor: pointer;" onclick="sortTable(' + index + ')" title="Click to sort">' + h + ' ↕</th>';
                        }});
                        thead += '</tr></thead><tbody>';
                        
                        var tbody = '';
                        tableData.forEach(function(row) {{
                            tbody += '<tr>';
                            row.forEach(function(cell, index) {{
                                if (index > 0 && typeof cell === 'number') {{
                                    tbody += '<td>' + cell.toLocaleString(undefined, {{minimumFractionDigits: 0, maximumFractionDigits: 4}}) + '</td>';
                                }} else {{
                                    tbody += '<td>' + cell + '</td>';
                                }}
                            }});
                            tbody += '</tr>';
                        }});
                        tbody += '</tbody>';
                        table.innerHTML = thead + tbody;
                    }}
                    
                    buildTable();
                </script>
            </body>
            </html>
            """
            
            temp_file = os.path.join(tempfile.gettempdir(), 'spatial_pivot_bar_chart.html')
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(html_template)
            
            from qgis.PyQt.QtCore import QUrl
            if getattr(self, 'chart_view', None) is not None:
                self.chart_view.load(QUrl.fromLocalFile(temp_file))
            else:
                import webbrowser
                webbrowser.open(f'file://{temp_file}')
                self.chart_btn.setChecked(False)

        except Exception as e:
            self.log_message(f"Chart rendering failed: {e}", True)
            import traceback
            traceback.print_exc()

    def toggle_transpose(self, checked):
        if getattr(self, 'dashboard_mode', None) == 'pivot' and self.current_pivot_df is not None:
            if checked:
                try:
                    df = self.current_pivot_df.copy()
                    df.set_index(df.columns[0], inplace=True)
                    df_t = df.T
                    df_t.reset_index(inplace=True)
                    df_t.rename(columns={'index': ' '}, inplace=True)
                    df_t.columns = [str(c) for c in df_t.columns]
                    self.display_df = df_t
                except Exception as e:
                    self.log_message(f"Transpose failed: {e}", True)
                    self.display_df = self.current_pivot_df
            else:
                self.display_df = self.current_pivot_df
                
            self.result_table.setModel(PandasModel(self.display_df))
            self.result_table.resizeColumnsToContents()
            self.apply_dashboard_filter(self.dash_filter_input.text())

    def apply_dashboard_filter(self, text):
        model = self.result_table.model()
        if not model: return
        text = text.lower()
        for row in range(model.rowCount()):
            match = False
            for col in range(model.columnCount()):
                idx = model.index(row, col)
                val = str(model.data(idx, QT_DISPLAY_ROLE)).lower()
                if text in val:
                    match = True
                    break
            self.result_table.setRowHidden(row, not match)
            
        if hasattr(self, 'chart_btn') and self.chart_btn.isChecked():
            self.render_dashboard_chart()

    def _get_raw_field_name(self, item):
        raw = item.data(QT_USER_ROLE)
        if raw:
            return raw
            
        # Fallback for old workspaces: split ONLY on ": " (colon + space) 
        text = item.text()
        if text.startswith("["):
            b_idx = text.find("]")
            if b_idx != -1:
                remainder = text[b_idx+1:]
                if ": " in remainder:
                    return (text[:b_idx+1] + remainder.split(": ", 1)[0]).strip()
                return text.strip()
                
        if ": " in text:
            return text.split(": ", 1)[0].strip()
            
        return text.strip()

    def eventFilter(self, source, event):
        if event.type() == QEVENT_KEYPRESS and event.key() in (QT_KEY_DELETE, QT_KEY_BACKSPACE):
            if source in [self.rows_list, self.cols_list, self.vals_list, self.filters_list]:
                for item in source.selectedItems():
                    row = source.row(item)
                    source.takeItem(row)
                    
                if self.live_check.isChecked() and self.live_check.isEnabled():
                    self.calculate_pivot()
                return True
        return super().eventFilter(source, event)

    def initUI(self):
        PivotUIBuilder.build(self)

    def show_table_context_menu(self, pos):
        menu = QMenu(self)
        copy_action = menu.addAction("📝 Copy Selection")
        
        if hasattr(menu, 'exec'): action = menu.exec(self.result_table.viewport().mapToGlobal(pos))
        else: action = menu.exec_(self.result_table.viewport().mapToGlobal(pos))
        
        if action == copy_action:
            self.result_table.copy_selection()

    def toggle_log_tab_color(self):
        self.blink_state = not self.blink_state
        color = self.blink_color if self.blink_state else QColor() 
        self.tabs.tabBar().setTabTextColor(self.log_tab_index, color)

    def on_tab_changed(self, index):
        if index == getattr(self, 'log_tab_index', -1) and self.log_blink_timer.isActive():
            self.log_blink_timer.stop()
            self.tabs.tabBar().setTabTextColor(self.log_tab_index, QColor())
            
        if hasattr(self, 'tab_temporal') and index == self.tabs.indexOf(self.tab_temporal):
            self.sync_temporal_wfs_tree()
            
        if hasattr(self, 'tab_dashboard'):
            is_dash = (index == self.tabs.indexOf(self.tab_dashboard))
            can_be_live = is_dash and not self.overlap_btn.isChecked()
            self.live_check.setEnabled(can_be_live)
            
            if not can_be_live or not self.live_check.isChecked():
                if self.live_timer.isActive():
                    self.live_timer.stop()

    def sync_temporal_wfs_tree(self):
        if hasattr(self, 'temp_root_wfs') and hasattr(self, 'geo_root_wfs'):
            self.temp_root_wfs.takeChildren()
            for i in range(self.geo_root_wfs.childCount()):
                self.temp_root_wfs.addChild(self.geo_root_wfs.child(i).clone())

    def log_message(self, message, is_error=False):
        import datetime
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        
        is_warn = "[WARN]" in message
        prefix = "[ERROR]" if is_error else "[WARN]" if is_warn else "[INFO]"
        
        if is_error: color = "#e74c3c"
        elif is_warn: color = "#e67e22"
        elif "successfully" in message: color = "#2ecc71"
        else: color = "inherit"

        self.log_text.append(f"<span style='color:{color};'><b>{timestamp} {prefix}:</b> {message}</span>")
        
        if (is_error or is_warn) and self.tabs.currentIndex() != getattr(self, 'log_tab_index', -1):
            self.blink_color = QColor(color)
            if not self.log_blink_timer.isActive():
                self.log_blink_timer.start(500) 

    def _refresh_target_label(self, item):
        base_name = item.text().split(" [")[0].split(" (")[0].split(" {")[0].split(" 🎯")[0]
        g_field = item.data(QT_USER_ROLE + 1)
        f_str = item.data(QT_USER_ROLE + 2)
        role = item.data(QT_USER_ROLE + 3) or "Main Only"
        sec_expr = item.data(QT_USER_ROLE + 4)
        
        label = base_name
        if g_field: label += f" [{g_field}]"
        if sec_expr: label += f" ({sec_expr})"
        if f_str: label += f" {{{f_str}}}"
        label += f" 🎯({role})"
        item.setText(label)
        item.setToolTip(label) 

    def filter_tree(self, text, tree):
        text = text.lower()
        def search_node(node):
            match = text in node.text(0).lower()
            child_match = False
            for i in range(node.childCount()):
                if search_node(node.child(i)): child_match = True
            visible = match or child_match or text == ""
            node.setHidden(not visible)
            if text and child_match: node.setExpanded(True)
            return visible
        for i in range(tree.topLevelItemCount()): search_node(tree.topLevelItem(i))

    def show_catalog_context_menu(self, pos, tree_widget):
        item = tree_widget.itemAt(pos)
        if not item: return
        data = item.data(0, QT_USER_ROLE)
        if not data: return
        
        menu = QMenu(self)
        is_local_root_child = item.parent() == self.global_root_local
        
        if data.get("type") == "canvas":
            action_count = menu.addAction("🔢 Count Features")
            if hasattr(menu, 'exec'): action_triggered = menu.exec(tree_widget.mapToGlobal(pos))
            else: action_triggered = menu.exec_(tree_widget.mapToGlobal(pos))
            
            if action_triggered == action_count:
                lyr = QgsProject.instance().mapLayer(data.get("uri"))
                if lyr:
                    c = lyr.featureCount()
                    item.setText(0, f"{item.text(0).split(' [')[0]} [{c:,} features]")
        
        elif data.get("type") in ["local", "local_parent"] and is_local_root_child:
            action = menu.addAction("❌ Remove Local File")
            if hasattr(menu, 'exec'): action_triggered = menu.exec(tree_widget.mapToGlobal(pos))
            else: action_triggered = menu.exec_(tree_widget.mapToGlobal(pos))
            
            if action_triggered == action:
                self.remove_catalog_item(item)
                
        elif data.get("type") == "wfs_server":
            action_rename = menu.addAction("✏️ Rename WFS Server")
            action_del = menu.addAction("❌ Remove WFS Server")
            if hasattr(menu, 'exec'): action_triggered = menu.exec(tree_widget.mapToGlobal(pos))
            else: action_triggered = menu.exec_(tree_widget.mapToGlobal(pos))
            
            if action_triggered == action_del:
                self.remove_catalog_item(item)
            elif action_triggered == action_rename:
                self.rename_catalog_item(item)

    def rename_catalog_item(self, item):
        data = item.data(0, QT_USER_ROLE)
        name = item.text(0)
        
        if data.get("type") == "wfs_server":
            clean_name = name.replace(" [Failed]", "").replace(" [Loading...]", "")
            new_name, ok = QInputDialog.getText(self, "Rename WFS Server", "Enter new name:", QLINEEDIT_NORMAL, clean_name)
            
            if ok and new_name.strip() and new_name.strip() != clean_name:
                if self.wfs_manager.rename_wfs_server(clean_name, new_name):
                    self.wfs_manager.force_refresh_wfs()
                    self.log_message(f"Renamed WFS server '{clean_name}' to '{new_name.strip()}'")
                else:
                    QMessageBox.warning(self, "Rename Failed", "A server with that name already exists or the name is invalid.")

    def remove_catalog_item(self, item):
        data = item.data(0, QT_USER_ROLE)
        name = item.text(0)
        
        if data.get("type") == "wfs_server":
            clean_name = name.replace(" [Failed]", "").replace(" [Loading...]", "")
            reply = QMessageBox.question(self, "Confirm Deletion", f"Are you sure you want to remove the WFS server '{clean_name}'?", QMESSAGEBOX_YES | QMESSAGEBOX_NO)
            if reply != QMESSAGEBOX_YES: return
            
            self.wfs_manager.remove_wfs_server(clean_name)
            self._remove_item_from_tree(self.global_root_wfs, name)
            self.log_message(f"Removed WFS server: {clean_name}")
            
        elif data.get("type") in ["local", "local_parent"]:
            reply = QMessageBox.question(self, "Confirm Deletion", f"Remove local file '{name}' from the catalog?", QMESSAGEBOX_YES | QMESSAGEBOX_NO)
            if reply != QMESSAGEBOX_YES: return
            
            self._remove_item_from_tree(self.global_root_local, name)
            self.log_message(f"Removed local file: {name}")

    def _remove_item_from_tree(self, parent_node, child_name):
        for i in range(parent_node.childCount()):
            child = parent_node.child(i)
            if child and child.text(0) == child_name:
                parent_node.removeChild(child)
                break

    def on_aoi_updated(self, geom):
        has_geom = geom is not None
        self.overlap_btn.setEnabled(has_geom)
        self.run_geosearch_btn.setEnabled(has_geom)
        self.geo_predicate_combo.setEnabled(has_geom)
        self.geo_buffer_main_btn.setEnabled(has_geom)
        self.geo_buffer_custom_btn.setEnabled(has_geom)
        
        if has_geom:
            self.update_buffer_ui_labels()
            self.aoi_widget.on_buffer_captured_main(self.last_run_buffer_dists_main)
            self.aoi_widget.on_buffer_captured_custom(self.last_run_buffer_dists_custom)
        
        if not geom:
            w = self.overlap_btn.isChecked()
            self.overlap_btn.blockSignals(True); self.overlap_btn.setChecked(False); self.overlap_btn.setText(" AOI Pivot Overlap: OFF"); self.overlap_btn.setStyleSheet(""); self.overlap_btn.blockSignals(False)
            self.live_check.setEnabled(True)
            self.last_run_buffer_dists_main = []
            self.last_run_buffer_dists_custom = []
            self.update_buffer_ui_labels()
            if w and self.live_check.isChecked(): self.calculate_pivot()
        elif self.overlap_btn.isChecked() and self.live_check.isChecked(): self.calculate_pivot()

    def update_buffer_ui_labels(self):
        if not self.last_run_buffer_dists_main: self.geo_buffer_main_btn.setText("⚙️ Main Buffers: [ 0m ]")
        else:
            v_str = ", ".join([f"{d:g}m" for d in self.last_run_buffer_dists_main])
            self.geo_buffer_main_btn.setText(f"⚙️ Main Buffers: [ {v_str} ]")
            
        if not self.last_run_buffer_dists_custom: self.geo_buffer_custom_btn.setText("⚙️ Custom Buffers: [ 0m ]")
        else:
            v_str = ", ".join([f"{d:g}m" for d in self.last_run_buffer_dists_custom])
            self.geo_buffer_custom_btn.setText(f"⚙️ Custom Buffers: [ {v_str} ]")

    def open_buffer_manager_main(self):
        d = BufferManagerDialog(self.last_run_buffer_dists_main, self)
        if d.exec() if hasattr(d, 'exec') else d.exec_():
            self.last_run_buffer_dists_main = d.get_current_list()
            self.update_buffer_ui_labels()
            if self.aoi_widget.current_aoi_geom:
                self.aoi_widget.on_buffer_captured_main(self.last_run_buffer_dists_main)
                
    def open_buffer_manager_custom(self):
        d = BufferManagerDialog(self.last_run_buffer_dists_custom, self)
        if d.exec() if hasattr(d, 'exec') else d.exec_():
            self.last_run_buffer_dists_custom = d.get_current_list()
            self.update_buffer_ui_labels()
            if self.aoi_widget.current_aoi_geom:
                self.aoi_widget.on_buffer_captured_custom(self.last_run_buffer_dists_custom)

    def on_interactive_buffer_captured_main(self, dists):
        self.last_run_buffer_dists_main = dists
        self.update_buffer_ui_labels()
        self.tabs.setCurrentWidget(self.tab_geosearch)
        self.aoi_widget.on_buffer_captured_main(dists) 
        self.aoi_widget.activate_click_tool() 
        self.log_message(f"Interactive Main buffer captured: {dists}")

    def on_interactive_buffer_captured_custom(self, dists):
        self.last_run_buffer_dists_custom = dists
        self.update_buffer_ui_labels()
        self.tabs.setCurrentWidget(self.tab_geosearch)
        self.aoi_widget.on_buffer_captured_custom(dists)
        self.aoi_widget.activate_click_tool() 
        self.log_message(f"Interactive Custom buffer captured: {dists}")

    def open_profile_manager(self, profile_name):
        d = ProfileEditorDialog(profile_name, self)
        if d.exec() if hasattr(d, 'exec') else d.exec_():
            self.log_message(f"Profile '{profile_name}' configuration saved successfully.")
            self.profile_io.load_wfs_profiles()
            self.geo_target_list.clear()
            self.profile_io.load_wfs_profile(profile_name)

    def request_schema(self, list_item):
        if not list_item: return
        layer_name = list_item.text().split(" [")[0].split(" (")[0].split(" {")[0].split(" 🎯")[0]
        data = list_item.data(QT_USER_ROLE)
        self.log_message(f"Fetching schema for {layer_name}...")
        task = WfsSchemaFetchTask("Fetching Schema", layer_name, data, list_item, self.on_schema_fetched)
        self.active_tasks.append(task); QgsApplication.taskManager().addTask(task)

    def on_schema_fetched(self, success, fields, list_item):
        if not success: return self.log_message(f"Failed to fetch schema for {list_item.text()}.", is_error=True)
        d = SearchableListDialog("Select Grouping Field", fields, self)
        if (d.exec() if hasattr(d, 'exec') else d.exec_()) and d.selected_value:
            list_item.setData(QT_USER_ROLE + 1, d.selected_value) 
            self._refresh_target_label(list_item)
            self.log_message(f"Custom group field set: {d.selected_value}")

    def request_secondary_expr(self, item):
        if not item: return
        current_expr = item.data(QT_USER_ROLE + 4) or ""
        expr, ok = QInputDialog.getText(self, "Secondary Expression", "Enter QGIS Expression (e.g. \"Type\" or substr(@layer_name, 1, 3)):", QLINEEDIT_NORMAL, current_expr)
        if ok:
            item.setData(QT_USER_ROLE + 4, expr.strip() if expr.strip() else None)
            self._refresh_target_label(item)
            self.log_message(f"Secondary expression set for {item.text().split(' [')[0]}")

    def request_filter(self, list_item):
        if not list_item: return
        current_filter = list_item.data(QT_USER_ROLE + 2) or ""
        f_str, ok = QInputDialog.getText(self, "Set Attribute Filter", "Enter SQL/CQL expression (e.g. Type = 'Residential'):", QLINEEDIT_NORMAL, current_filter)
        if ok:
            f_str = f_str.strip()
            list_item.setData(QT_USER_ROLE + 2, f_str if f_str else None)
            self._refresh_target_label(list_item)
            self.log_message(f"Filter updated for {list_item.text().split(' [')[0]}")

    def request_buffer_role(self, list_item):
        if not list_item: return
        current_role = list_item.data(QT_USER_ROLE + 3) or "Main Only"
        d = BufferRoleDialog(current_role, self)
        if d.exec() if hasattr(d, 'exec') else d.exec_():
            new_role = d.get_role()
            list_item.setData(QT_USER_ROLE + 3, new_role)
            self._refresh_target_label(list_item)
            self.log_message(f"Buffer Role updated to: {new_role}")
        
    def on_row_selected(self, row_data):
        if not hasattr(self, 'highlight_rb'):
            self.highlight_rb = QgsRubberBand(self.iface.mapCanvas(), QGS_WKB_POLYGON)
            self.highlight_rb.setColor(QColor(0, 255, 255, 120)) 
            self.highlight_rb.setStrokeColor(QColor(0, 255, 255, 255))
            self.highlight_rb.setWidth(3)

        self.highlight_rb.reset()

        if not row_data or not self.current_geo_raw_data:
            return

        is_geosearch = 'Layer' in row_data and 'Type' in row_data and 'Group' in row_data
        target_geoms = []
        
        if is_geosearch:
            target_layer = str(row_data.get('Layer', ''))
            target_group = str(row_data.get('Group', ''))
            
            target_zone = "AOI"
            for k in row_data.keys():
                if "Area (ha)" in k and row_data[k] and k != "Area (ha)":
                    target_zone = k.replace(" Area (ha)", "")
                    break
            
            for item in self.current_geo_raw_data:
                if str(item.get('Layer')) == target_layer and str(item.get('Group')) == target_group and item.get('Zone') == target_zone:
                    target_geoms.append(item['Geometry'])
        else:
            r_list = [self.rows_list.item(i).text() for i in range(self.rows_list.count())]
            if not r_list: target_group = "All Data"
            else: target_group = " | ".join([str(row_data.get(r, '')) for r in r_list])
            
            if "GRAND TOTAL" in target_group:
                target_geoms = [item['Geometry'] for item in self.current_geo_raw_data]
            elif "SUBTOTAL" in target_group:
                real_vals = [str(row_data.get(r, '')) for r in r_list]
                valid_prefix = " | ".join([v for v in real_vals if v != 'SUBTOTAL'])
                for item in self.current_geo_raw_data:
                    if str(item.get('Group', '')).startswith(valid_prefix):
                        target_geoms.append(item['Geometry'])
            else:
                for item in self.current_geo_raw_data:
                    if str(item.get('Group')) == target_group:
                        target_geoms.append(item['Geometry'])

        if target_geoms:
            combined_geom = QgsGeometry.collectGeometry(target_geoms)
            self.highlight_rb.setToGeometry(combined_geom, None)
            self.highlight_rb.show()

    def update_canvas_tree(self):
        self.global_root_canvas.takeChildren()
        layers = self.project.mapLayers().values()
        v_layers = [lyr for lyr in layers if lyr.type() == lyr.VectorLayer]
        for lyr in v_layers:
            item = QTreeWidgetItem(self.global_root_canvas, [lyr.name()])
            item.setData(0, QT_USER_ROLE, {"type": "canvas", "uri": lyr.id(), "name": lyr.name()})
            item.setToolTip(0, lyr.name()) 
            # --- THE FIX: Geometry icon detection ---
            item.setIcon(0, QgsIconUtils.iconForWkbType(lyr.wkbType()))
            
            # --- PROPER RENAME FIX: Hook directly to the layer ---
            try:
                lyr.nameChanged.disconnect(self.update_canvas_tree)
            except TypeError:
                pass # First time connecting, safe to ignore
            lyr.nameChanged.connect(self.update_canvas_tree)
            
        self.global_root_canvas.setExpanded(True)

    def add_local_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Add Local Vector Layer", "", "Vector Files (*.shp *.gpkg *.geojson *.tab)")
        if not path: return
        
        name = path.split("/")[-1]
        
        try:
            from qgis.core import QgsProviderRegistry
            sublayers = QgsProviderRegistry.instance().querySublayers(path)
        except Exception:
            sublayers = []
            
        if sublayers and len(sublayers) > 1:
            item = QTreeWidgetItem(self.global_root_local, [name])
            item.setData(0, QT_USER_ROLE, {"type": "local_parent", "uri": path, "name": name})
            item.setToolTip(0, name) 
            for sl in sublayers:
                sub_name = sl.name()
                sub_uri = sl.uri()
                c = QTreeWidgetItem(item, [sub_name])
                c.setData(0, QT_USER_ROLE, {"type": "local", "uri": sub_uri, "name": f"{name} - {sub_name}"})
                c.setToolTip(0, f"{name} - {sub_name}") 
            self.global_root_local.setExpanded(True); item.setExpanded(True)
            self.log_message(f"Added local GPKG with {len(sublayers)} layers: {name}")
        else:
            uri = sublayers[0].uri() if sublayers else path
            item = QTreeWidgetItem(self.global_root_local, [name])
            item.setData(0, QT_USER_ROLE, {"type": "local", "uri": uri, "name": name})
            item.setToolTip(0, name) 
            self.global_root_local.setExpanded(True)
            self.log_message(f"Added local file: {name}")

    def on_sources_changed(self):
        # Cleanly extract base names without the UI suffix [Pg,Ln,Pt]...
        active_joins = [self.join_layer_list.item(i).text().split(" [")[0] for i in range(self.join_layer_list.count())]
        has_base = self.base_layer_list.count() > 0
        
        for list_widget in [self.rows_list, self.cols_list, self.filters_list, self.vals_list]:
            for i in range(list_widget.count() - 1, -1, -1):
                item_text = list_widget.item(i).text()
                if item_text.startswith("["):
                    b_idx = item_text.find("]")
                    if b_idx != -1:
                        layer_name = item_text[1:b_idx]
                        if layer_name not in active_joins:
                            list_widget.takeItem(i)
                elif not has_base:
                    list_widget.takeItem(i)
        
        self.load_fields()

    def get_layer_defs(self, list_widget):
        defs = []
        for i in range(list_widget.count()):
            defs.append(list_widget.item(i).data(QT_USER_ROLE))
        return defs

    def load_fields(self):
        try:
            QApplication.setOverrideCursor(QT_WAIT_CURSOR)
        except Exception:
            pass
        
        try:
            self.fields_list.clear()
            base_defs = self.get_layer_defs(self.base_layer_list)
            if base_defs:
                b_def = base_defs[0]
                lyr = self.engine._load_layer_headless(b_def)
                if lyr and lyr.isValid():
                    for f in lyr.fields(): 
                        item = QListWidgetItem(f.name())
                        item.setToolTip(f.name()) 
                        item.setData(QT_USER_ROLE, f.name()) # <-- STORE PRISTINE BASE NAME
                        self.fields_list.addItem(item)
                        
                    calc_item = QListWidgetItem("Calculate area (ha)")
                    calc_item.setToolTip("Calculate area (ha)") 
                    calc_item.setData(QT_USER_ROLE, "Calculate area (ha)") # <-- STORE PRISTINE CALC NAME
                    font = calc_item.font(); font.setItalic(True); calc_item.setFont(font)
                    calc_item.setForeground(QColor("#7f8c8d")) 
                    self.fields_list.addItem(calc_item)

            join_defs = self.get_layer_defs(self.join_layer_list)
            for j_def in join_defs:
                j_lyr = self.engine._load_layer_headless(j_def)
                if j_lyr and j_lyr.isValid():
                    for f in j_lyr.fields(): 
                        fname = f"[{j_def['name']}] {f.name()}"
                        item = QListWidgetItem(fname)
                        item.setToolTip(fname) 
                        item.setData(QT_USER_ROLE, fname) # <-- STORE PRISTINE JOIN NAME
                        self.fields_list.addItem(item)
        finally:
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                pass

    def clear_setup(self):
        self.base_layer_list.clear()
        self.join_layer_list.clear()
        self.fields_list.clear()
        self.filters_list.clear()
        self.rows_list.clear()
        self.cols_list.clear()
        self.vals_list.clear()
        self.query_caches.clear()      
        self.spatial_setup_hash = None   
        self.clear_dashboard()

    def clear_canvas_memory(self):
        try:
            if getattr(self, 'last_geo_group', None) is not None:
                _ = self.last_geo_group.name() 
                root = QgsProject.instance().layerTreeRoot()
                root.removeChildNode(self.last_geo_group)
        except (RuntimeError, AttributeError, Exception):
            pass
            
        self.last_geo_group = None
        self.precalculated_layers = [] 
        
        try: self.iface.mapCanvas().refresh()
        except Exception: pass

    def clear_dashboard(self):
        self.clear_canvas_memory()
        
        if hasattr(self, 'highlight_rb') and self.highlight_rb:
            self.highlight_rb.reset()
            
        self.status_label.setText(""); self.status_label.setToolTip("") 
        self.result_table.setModel(PandasModel(pd.DataFrame()))
        self.export_geo_btn.setEnabled(False)
        self.export_pdf_btn.setEnabled(False) 
        self.toggle_canvas_btn.setEnabled(False)
        self.toggle_canvas_btn.setText("👁️ Show on Canvas")
        self.toggle_canvas_btn.setChecked(False)
        self.transpose_btn.setChecked(False)
        self.transpose_btn.setEnabled(False)
        
        self.chart_btn.setChecked(False)
        self.chart_btn.setEnabled(False)
        if hasattr(self, 'dash_stack'):
            self.dash_stack.setCurrentIndex(0)
            
        self.dash_filter_input.setText("") 
        self.current_geo_raw_data = None
        self.current_geo_aoi = None
        self.current_geo_aoi_buffered = []
        self.last_export_choices = None
        self._was_canvas_showing = False
        self.dashboard_mode = None
        self.current_pivot_df = None
        self.display_df = None

    def calculate_pivot(self):
        # --- THE FIX: Halt execution if no Values added ---
        if self.vals_list.count() == 0:
            QMessageBox.warning(self, "Missing Values", "Please add at least one field to the Values pillar before calculating.")
            self.calc_btn.setEnabled(True); self.calc_btn.setText("Calculate Pivot")
            return

        self.calc_btn.setEnabled(False); self.calc_btn.setText("Calculating...")
        
        self._was_canvas_showing = self.toggle_canvas_btn.isChecked()
        self.clear_canvas_memory()
        
        if hasattr(self, 'highlight_rb') and self.highlight_rb:
            self.highlight_rb.reset()
            
        self.current_geo_raw_data = None 
        
        self.result_table.setModel(PandasModel(pd.DataFrame()))
        self.status_label.setText("Crunching data...")
        
        self.export_geo_btn.setEnabled(False)
        self.export_pdf_btn.setEnabled(False) 
        self.toggle_canvas_btn.setEnabled(False)
        self.toggle_canvas_btn.setText("👁️ Show on Canvas")
        self.toggle_canvas_btn.setChecked(False)
        
        try:
            base_defs = self.get_layer_defs(self.base_layer_list)
            if not base_defs:
                self.calc_btn.setEnabled(True); self.calc_btn.setText("Calculate Pivot"); return
                
            base_def = base_defs[0]
            join_defs = self.get_layer_defs(self.join_layer_list)
            
            f_dict = {}
            for i in range(self.filters_list.count()):
                item = self.filters_list.item(i)
                text = item.text()
                fn = self._get_raw_field_name(item) # <-- Pass item
                
                selected_vals = item.data(QT_USER_ROLE + 1)
                if selected_vals:
                    f_dict[fn] = selected_vals
                else:
                    remainder = text[len(fn):].strip()
                    if remainder.startswith(":"):
                        f_dict[fn] = [v.strip() for v in remainder[1:].split(",")]

            # Robust extraction for Rows and Cols
            r_list = [self._get_raw_field_name(self.rows_list.item(i)) for i in range(self.rows_list.count())]
            c_list = [self._get_raw_field_name(self.cols_list.item(i)) for i in range(self.cols_list.count())]
            
            v_dict = {}
            for i in range(self.vals_list.count()):
                item = self.vals_list.item(i)
                text = item.text()
                fn = self._get_raw_field_name(item) # <-- Pass item
                remainder = text[len(fn):].strip()
                
                if remainder.startswith(":"):
                    agg = remainder[1:].strip()
                else:
                    agg = "Sum"
                    
                if fn not in v_dict:
                    v_dict[fn] = []
                if agg not in v_dict[fn]:
                    v_dict[fn].append(agg)
            
            if not r_list and not c_list and not v_dict: 
                self.status_label.setText("Add Rows, Columns, or Values to calculate.")
                self.calc_btn.setEnabled(True); self.calc_btn.setText("Calculate Pivot"); return

            ext = self.iface.mapCanvas().extent() if self.live_check.isChecked() and self.live_check.isEnabled() else None
            aoi = self.aoi_widget.current_aoi_geom if self.overlap_btn.isChecked() else None
            
            aoi_bounds = aoi.boundingBox().toString() if aoi else None
            h_str = str({'b': base_def['name'], 'j': [j['name'] for j in join_defs], 'e': ext.toString() if ext else None, 'aoi': aoi_bounds})
            
            rd = self.query_caches.get(h_str)
            self.spatial_setup_hash = h_str
            
            self.saved_column_widths.clear()
            if self.result_table.model():
                for i in range(self.result_table.model().columnCount()): self.saved_column_widths[self.result_table.model().headerData(i, QT_HORIZONTAL, QT_DISPLAY_ROLE)] = self.result_table.columnWidth(i)
                
            kwargs = {
                'base_layer_def': base_def,
                'join_layer_defs': join_defs,
                'rows': r_list,
                'cols': c_list,
                'vals_dict': v_dict,
                'filters': f_dict,
                'show_totals': self.totals_check.isChecked(),
                'force_zeros': getattr(self, 'force_zeros_check', QCheckBox()).isChecked(),
                'extent': ext,
                'aoi_geom': aoi,
                'raw_data_cache': rd
            }
            task = PivotCalculationTask("Spatial Pivot Calc", self.engine, kwargs, self.on_task_finished)
            self.active_tasks.append(task)
            
            self.progress_bar.setValue(0)
            self.progress_bar.setVisible(True)
            self.cancel_task_btn.setVisible(True)

            task.progressChanged.connect(lambda val: self.progress_bar.setValue(int(val)))

            try: self.cancel_task_btn.clicked.disconnect()
            except TypeError: pass
            self.cancel_task_btn.clicked.connect(task.cancel)
            
            QgsApplication.taskManager().addTask(task)
            
        except Exception as e:
            self.status_label.setText("Initialization Error.")
            self.calc_btn.setEnabled(True); self.calc_btn.setText("Calculate Pivot"); self.log_message(str(e), True)

    def on_task_finished(self, res, raw, raw_geodata, exc):
        self.progress_bar.setVisible(False)
        self.cancel_task_btn.setVisible(False)
        
        self.calc_btn.setEnabled(True); self.calc_btn.setText("Calculate Pivot")
        if exc: 
            if "Task canceled" in str(exc):
                self.status_label.setText("Calculation aborted by user.")
                return self.log_message("Calculation aborted by user.", True)
                
            self.status_label.setText("Calculation Failed")
            QMessageBox.critical(self, "Calculation Error", f"A background error occurred:\n{str(exc)}")
            return self.log_message(str(exc), True)
        
        if raw is not None:
            self.query_caches[self.spatial_setup_hash] = raw 
            
        self.current_geo_raw_data = raw_geodata
        self.current_geo_aoi = self.aoi_widget.current_aoi_geom
        self.current_geo_aoi_buffered = []

        if res is not None and not res.empty:
            self.dashboard_mode = "pivot"
            self.current_pivot_df = res 
            self.display_df = res
            
            self.transpose_btn.blockSignals(True)
            self.transpose_btn.setChecked(False)
            self.transpose_btn.setEnabled(True)
            self.transpose_btn.blockSignals(False)
            
            self.chart_btn.blockSignals(True)
            self.chart_btn.setChecked(False)
            self.chart_btn.setEnabled(True)
            self.chart_btn.blockSignals(False)
            if hasattr(self, 'dash_stack'):
                self.dash_stack.setCurrentIndex(0)
            
            self.result_table.setModel(PandasModel(res))
            for i in range(self.result_table.model().columnCount()):
                h = self.result_table.model().headerData(i, QT_HORIZONTAL, QT_DISPLAY_ROLE)
                if h in self.saved_column_widths: self.result_table.setColumnWidth(i, self.saved_column_widths[h])
                elif i == 0: self.result_table.resizeColumnToContents(0)
            
            self.apply_dashboard_filter(self.dash_filter_input.text())
            
            sl = []
            if self.filters_list.count(): sl.append("Filtered")
            if self.overlap_btn.isChecked(): sl.append("AOI")
            if getattr(self, 'force_zeros_check', QCheckBox()).isChecked(): sl.append("Force Zeros")
            if self.live_check.isChecked() and self.live_check.isEnabled(): sl.append("LIVE")
            if self.join_layer_list.count() > 0: sl.append(f"Joined ({self.join_layer_list.count()})")
            self.status_label.setText(f"Showing: {' + '.join(sl)}" if sl else "Showing: All Data")
            
            if raw_geodata and not res.empty:
                self.export_geo_btn.setEnabled(True)
                self.export_pdf_btn.setEnabled(False) 
                self.export_pdf_btn.setToolTip("PDF generation is reserved for Geosearch reports.")
                self.toggle_canvas_btn.setEnabled(True)
                
                if self._was_canvas_showing and self.last_export_choices and self.live_check.isChecked():
                    self.exporter.generate_spatial_outputs(None, True, *self.last_export_choices, is_pivot=True, pivot_df=self.display_df)
                    self.toggle_canvas_btn.setChecked(True)
                    self.toggle_canvas_btn.setText("👁️ Toggle Canvas Layers")
            else:
                self.export_geo_btn.setEnabled(False)
                self.export_pdf_btn.setEnabled(False) 
                self.toggle_canvas_btn.setEnabled(False)
                
            self.tabs.setCurrentWidget(self.tab_dashboard)
        else:
            self.result_table.setModel(PandasModel(pd.DataFrame()))
            self.status_label.setText("No data matched the criteria.") 
            self.export_geo_btn.setEnabled(False)
            self.export_pdf_btn.setEnabled(False) 
            self.toggle_canvas_btn.setEnabled(False)
            self.transpose_btn.setEnabled(False)
            
            self.chart_btn.setChecked(False)
            self.chart_btn.setEnabled(False)
            if hasattr(self, 'dash_stack'):
                self.dash_stack.setCurrentIndex(0)
            
            self.dash_filter_input.setText("")
            
            self.tabs.setCurrentWidget(self.tab_dashboard)

    def add_target_layer(self, layer_name, layer_def):
        for i in range(self.geo_target_list.count()):
            if self.geo_target_list.item(i).text().startswith(layer_name): return
        new_item = QListWidgetItem(layer_name)
        new_item.setData(QT_USER_ROLE, layer_def)
        new_item.setData(QT_USER_ROLE + 3, "Main Only")
        new_item.setToolTip(layer_name)
        
        self.geo_target_list.addItem(new_item)
        self._refresh_target_label(new_item)

    def on_wfs_tree_double_clicked(self, item, column):
        data = item.data(0, QT_USER_ROLE)
        if not data: return
        
        if isinstance(data, dict) and data.get("type") == "add_custom_wfs":
            self.wfs_manager.prompt_add_wfs()
        elif isinstance(data, dict) and data.get("type") == "wfs_server":
            if item.childCount() == 0 or "Failed" in item.text(0):
                url = data.get("uri")
                self.wfs_manager.fetch_wfs_server(item.text(0).replace(" [Failed]", ""), url)
        elif isinstance(data, dict) and data.get("type") in ["canvas", "local", "wfs"]:
            if self.tabs.currentIndex() == self.tabs.indexOf(getattr(self, 'tab_geosearch', None)):
                self.add_target_layer(item.text(0), data)
            elif self.tabs.currentIndex() == self.tabs.indexOf(getattr(self, 'tab_temporal', None)):
                if hasattr(self, 'timeline_list'):
                    name = item.text(0)
                    exists = False
                    for i in range(self.timeline_list.count()):
                        clean_text = self.timeline_list.item(i).text().replace("🟢 [BASE] ", "").replace("🔵 ", "")
                        if clean_text == name:
                            exists = True
                            break
                            
                    if not exists:
                        new_item = QListWidgetItem(name)
                        new_item.setData(QT_USER_ROLE, data)
                        new_item.setFlags(new_item.flags() | QT_ITEM_IS_EDITABLE)
                        new_item.setToolTip(name) 
                        self.timeline_list.addItem(new_item)
                        self.timeline_list._auto_sort_chronologically()
                        self.timeline_list._update_timeline_visuals()
                        self.timeline_list.layers_updated.emit()

    def run_geosearch(self):
        if self.geo_target_list.count() == 0: return self.log_message("No targets selected.", is_error=True)
        if self.aoi_widget.current_aoi_geom is None: return self.log_message("Geosearch requires AOI.", is_error=True)
        
        self.clear_canvas_memory()
        
        if hasattr(self, 'highlight_rb') and self.highlight_rb:
            self.highlight_rb.reset()
            
        targets = []
        for i in range(self.geo_target_list.count()):
            item = self.geo_target_list.item(i)
            data = item.data(QT_USER_ROLE)
            l_name = item.text().split(" [")[0].split(" (")[0].split(" {")[0].split(" 🎯")[0]
            
            targets.append({
                "url": data.get("uri"), 
                "layer": l_name, 
                "type": data.get("type"), 
                "custom_field": item.data(QT_USER_ROLE + 1),
                "custom_filter": item.data(QT_USER_ROLE + 2),
                "buffer_role": item.data(QT_USER_ROLE + 3) or "Main Only",
                "secondary_expr": item.data(QT_USER_ROLE + 4),
                "sensitive_features": item.data(QT_USER_ROLE + 5) or {}
            })
            
        self.run_geosearch_btn.setEnabled(False); self.run_geosearch_btn.setText("Searching...")
        
        predicate = self.geo_predicate_combo.currentText()
        
        task = GeosearchTask("Spatial WFS Geosearch", targets, self.aoi_widget.current_aoi_geom, predicate, self.last_run_buffer_dists_main, self.last_run_buffer_dists_custom, self.strict_mode_check.isChecked(), self.on_geosearch_finished)
        self.active_tasks.append(task); QgsApplication.taskManager().addTask(task)

    def on_geosearch_finished(self, df_result, raw_geodata, buffered_geoms, log_messages, exception):
        self.run_geosearch_btn.setEnabled(True); self.run_geosearch_btn.setText("▶ Run Geosearch in AOI")
        for msg in log_messages: self.log_message(msg, is_error="[WARN]" in msg)
        if exception: return self.log_message(f"Geosearch failed: {str(exception)}", is_error=True)
        
        self.current_geo_raw_data = raw_geodata
        self.current_geo_aoi = self.aoi_widget.current_aoi_geom
        self.current_geo_aoi_buffered = buffered_geoms 
        
        self.last_export_choices = None
        self.toggle_canvas_btn.setText("👁️ Show on Canvas")
        self.toggle_canvas_btn.setChecked(False)

        if df_result is not None:
            self.dashboard_mode = "geosearch"
            self.display_df = df_result
            self.transpose_btn.setEnabled(False) 
            
            self.result_table.setModel(PandasModel(df_result))
            self.result_table.resizeColumnsToContents()
            self.apply_dashboard_filter(self.dash_filter_input.text())
            
            self.export_geo_btn.setEnabled(not df_result.empty) 
            
            self.export_pdf_btn.setEnabled(not df_result.empty) 
            self.export_pdf_btn.setToolTip("Export a formal PDF report of this Geosearch.")
            
            self.toggle_canvas_btn.setEnabled(not df_result.empty) 
            
            self.status_label.setText(f"Showing: Geosearch Results ({len(df_result)} records)")
            self.status_label.setStyleSheet("font-weight: bold; color: #27ae60;") 
            self.tabs.setCurrentWidget(self.tab_dashboard)
            
            if df_result.empty:
                self.log_message("Geosearch finished. No features found matching your criteria. Showing empty dashboard.")
            else:
                self.log_message(f"Geosearch complete. Found {len(df_result)} records.")
        else:
            self.result_table.setModel(PandasModel(pd.DataFrame()))
            self.status_label.setText("") 
            self.export_geo_btn.setEnabled(False)
            self.export_pdf_btn.setEnabled(False) 
            self.toggle_canvas_btn.setEnabled(False)
            self.transpose_btn.setEnabled(False)
            self.log_message("Geosearch failed to generate a Data Model.", is_error=True)

    def _get_dynamic_fields(self):
        if not self.current_geo_raw_data: return []
        dynamic_fields = set()
        for item in self.current_geo_raw_data:
            dynamic_fields.update(item.get('feature_attrs', {}).keys())
        return sorted([f for f in dynamic_fields if f not in ["Layer", "Group", "Secondary", "Sensitive Alert", "Threshold (m)"]])

    def prompt_export_geodata(self):
        if not self.current_geo_raw_data: return self.log_message("No spatial data to export.", True)
        
        has_aoi = self.current_geo_aoi is not None
        has_buffered_aoi = bool(self.current_geo_aoi_buffered)
        available_fields = self._get_dynamic_fields()
        
        is_pivot = (getattr(self, 'dashboard_mode', None) == "pivot")
        
        dialog = ExportGeoDialog(available_fields=available_fields, has_aoi=has_aoi, has_buffered_aoi=has_buffered_aoi, parent=self)
        
        if is_pivot:
            dialog.cb_sensitive.setVisible(False); dialog.cb_sensitive.setChecked(False)
            dialog.cb_buffered_aoi.setVisible(False); dialog.cb_buffered_aoi.setChecked(False)
            dialog.cb_rep.setText("Aggregated Pivot Dashboard Results")
        
        if dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_():
            export_gpkg = dialog.cb_gpkg.isChecked()
            load_temp = dialog.cb_temp.isChecked()
            inc_aoi = dialog.cb_aoi.isChecked()
            inc_buffered_aoi = dialog.cb_buffered_aoi.isChecked()
            inc_raw = dialog.cb_raw.isChecked()
            inc_rep = dialog.cb_rep.isChecked()
            inc_sensitive = dialog.cb_sensitive.isChecked()
            aoi_name = dialog.aoi_name_input.text().strip() or "AOI"
            sym_style = dialog.symbology_combo.currentText()
            sym_field = dialog.sym_field_combo.currentText()
            
            if not (export_gpkg or load_temp): return self.log_message("No destination selected.", True)
            if not (inc_aoi or inc_buffered_aoi or inc_raw or inc_rep or inc_sensitive): return self.log_message("No content selected.", True)
            
            save_path = None
            if export_gpkg:
                save_path, _ = QFileDialog.getSaveFileName(self, "Save GeoPackage", "", "GeoPackage (*.gpkg)")
                if not save_path: return 
                if not save_path.endswith(".gpkg"): save_path += ".gpkg"
            
            if load_temp:
                self.last_export_choices = (inc_aoi, inc_buffered_aoi, inc_raw, inc_rep, inc_sensitive, aoi_name, sym_style, sym_field)
                
            self.exporter.generate_spatial_outputs(save_path, load_temp, inc_aoi, inc_buffered_aoi, inc_raw, inc_rep, inc_sensitive, aoi_name, sym_style, sym_field, is_pivot=is_pivot, pivot_df=getattr(self, 'display_df', None))

    def toggle_geosearch_canvas(self, checked):
        if not checked:
            try:
                if getattr(self, 'last_geo_group', None) is not None:
                    _ = self.last_geo_group.name() 
                    root = QgsProject.instance().layerTreeRoot()
                    root.removeChildNode(self.last_geo_group)
            except (RuntimeError, AttributeError, Exception):
                pass
            self.last_geo_group = None
            self.iface.mapCanvas().refresh() 
        else:
            if hasattr(self, 'precalculated_layers') and self.precalculated_layers:
                self.exporter.build_layer_tree_from_blueprint()
                self.toggle_canvas_btn.setText("👁️ Toggle Canvas Layers")
                self.toggle_canvas_btn.setChecked(True)
                self.iface.mapCanvas().refresh() 
            else:
                self.trigger_rebuild_from_scratch()

    def trigger_rebuild_from_scratch(self):
        has_aoi = self.current_geo_aoi is not None
        has_buffered_aoi = bool(self.current_geo_aoi_buffered)
        available_fields = self._get_dynamic_fields()
        
        is_pivot = (getattr(self, 'dashboard_mode', None) == "pivot")
        
        dialog = CanvasDisplayDialog(available_fields=available_fields, has_aoi=has_aoi, has_buffered_aoi=has_buffered_aoi, parent=self)
        
        if is_pivot:
            dialog.cb_sensitive.setVisible(False); dialog.cb_sensitive.setChecked(False)
            dialog.cb_buffered_aoi.setVisible(False); dialog.cb_buffered_aoi.setChecked(False)
            dialog.cb_rep.setText("Aggregated Pivot Dashboard Results")

        if dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_():
            inc_raw = dialog.cb_raw.isChecked()
            inc_rep = dialog.cb_rep.isChecked()
            inc_aoi = dialog.cb_aoi.isChecked()
            inc_buffered_aoi = dialog.cb_buffered_aoi.isChecked()
            inc_sensitive = dialog.cb_sensitive.isChecked()
            sym_style = dialog.symbology_combo.currentText()
            sym_field = dialog.sym_field_combo.currentText()
            
            if not (inc_raw or inc_rep or inc_aoi or inc_buffered_aoi or inc_sensitive): 
                self.toggle_canvas_btn.setChecked(False)
                return
            
            self.last_export_choices = (inc_aoi, inc_buffered_aoi, inc_raw, inc_rep, inc_sensitive, "AOI", sym_style, sym_field)
            
            self.exporter.generate_spatial_outputs(None, True, inc_aoi, inc_buffered_aoi, inc_raw, inc_rep, inc_sensitive, "AOI", sym_style, sym_field, is_pivot=is_pivot, pivot_df=getattr(self, 'display_df', None))
            self.toggle_canvas_btn.setText("👁️ Toggle Canvas Layers")
            self.toggle_canvas_btn.setChecked(True)
        else:
            self.toggle_canvas_btn.setChecked(False) 

    def on_totals_toggled(self):
        if self.spatial_setup_hash in self.query_caches: self.calculate_pivot()
        
    def on_live_toggled(self):
        if not self.live_check.isChecked():
            if self.live_timer.isActive():
                self.live_timer.stop()
            self.log_message("Live View disabled. Background tasks paused.")
        elif self.spatial_setup_hash in self.query_caches: 
            self.calculate_pivot()

    def set_filter_value(self, item):
        try:
            fn = self._get_raw_field_name(item) # <-- Remove .text()
            self.log_message(f"Preparing filter dialog for '{fn}'...")
            
            base_defs = self.get_layer_defs(self.base_layer_list)
            join_defs = self.get_layer_defs(self.join_layer_list)
            
            target_layer = None
            clean_fn = fn
            
            if fn.startswith("[") and "]" in fn:
                b_idx = fn.find("]")
                j_name = fn[1:b_idx]
                clean_fn = fn[b_idx+1:].strip()
                
                for jd in join_defs:
                    if jd['name'] == j_name:
                        target_layer = self.engine._load_layer_headless(jd)
                        break
            elif base_defs:
                target_layer = self.engine._load_layer_headless(base_defs[0])

            if not target_layer: 
                self.log_message(f"Error: Could not load layer to fetch values for '{fn}'.", True)
                return
                
            idx = target_layer.fields().indexOf(clean_fn)
            if idx == -1: 
                self.log_message(f"Error: Field '{clean_fn}' not found in the source layer.", True)
                return
            
            try:
                QApplication.setOverrideCursor(QT_WAIT_CURSOR)
            except Exception:
                pass
            
            try:
                raw_vals = target_layer.uniqueValues(idx)
                vals_set = set()
                for v in raw_vals:
                    if v is not None:
                        str_v = str(v).strip()
                        if str_v and str_v != "NULL":
                            vals_set.add(str_v)
                vals = sorted(list(vals_set))
            finally:
                try:
                    QApplication.restoreOverrideCursor()
                except Exception:
                    pass

            if not vals: 
                self.log_message(f"Warning: No valid unique values found for '{fn}'.", True)
                return
            
            d = MultiSelectFilterDialog(f"Filter: {fn}", vals, self)
            
            existing_data = item.data(QT_USER_ROLE + 1)
            if existing_data:
                for i in range(d.list_widget.count()):
                    if d.list_widget.item(i).text() in existing_data:
                        d.list_widget.item(i).setCheckState(QT_CHECKED)

            if (d.exec() if hasattr(d, 'exec') else d.exec_()):
                selected = d.get_selected()
                if selected:
                    display_text = ", ".join(selected)
                    if len(display_text) > 40:
                        display_text = display_text[:37] + "..."
                    new_text = f"{fn}: {display_text}"
                    item.setText(new_text)
                    item.setToolTip(new_text) 
                    item.setData(QT_USER_ROLE + 1, selected)
                else:
                    item.setText(f"{fn}")
                    item.setToolTip(f"{fn}") 
                    item.setData(QT_USER_ROLE + 1, None)

            if self.live_check.isChecked() and self.live_check.isEnabled():
                self.calculate_pivot()
                
        except Exception as e:
            self.log_message(f"Filter Dialog Error: {str(e)}", True)
            traceback.print_exc()

    def set_value_agg(self, item):
        fn = self._get_raw_field_name(item) # <-- Remove .text()
        v, ok = QInputDialog.getItem(self, "Agg", f"Select for '{fn}':", ["Count", "Sum", "Mean", "Min", "Max"], 0, False)
        if ok and v: 
            new_text = f"{fn}: {v}"
            item.setText(new_text)
            item.setToolTip(new_text) 

    def export_data(self):
        model = self.result_table.model()
        if model is None or model._data.empty: return self.log_message("No data.", True)
        path, _ = QFileDialog.getSaveFileName(self, "Export", "", "Excel Files (*.xlsx);;CSV Files (*.csv)")
        if path:
            try:
                if path.endswith('.xlsx'):
                    try: model._data.to_excel(path, index=False, engine='xlsxwriter'); self.log_message(f"Exported {path}")
                    except ImportError: model._data.to_csv(path.replace('.xlsx', '.csv'), index=False); self.log_message(f"Exported CSV safely")
                else: model._data.to_csv(path, index=False); self.log_message(f"Exported {path}")
            except Exception as e: self.log_message(f"Fail: {str(e)}", True)

    def export_pdf_report(self):
        model = self.result_table.model()
        if model is None or model._data.empty: 
            return self.log_message("No data to export to PDF.", True)
        ReportGenerator.export_pdf_report(self, model._data)

    def on_overlap_toggled(self, checked):
        if checked:
            self.overlap_btn.setText(" AOI Pivot Overlap: ON "); self.overlap_btn.setStyleSheet("font-weight: bold; color: #27ae60;")
            self.live_check.setChecked(False); self.live_check.setEnabled(False)
        else: 
            self.overlap_btn.setText(" AOI Pivot Overlap: OFF"); self.overlap_btn.setStyleSheet(""); self.live_check.setEnabled(True)

    def on_canvas_panned(self):
        if self.live_check.isChecked() and self.live_check.isEnabled(): self.live_timer.start(500)