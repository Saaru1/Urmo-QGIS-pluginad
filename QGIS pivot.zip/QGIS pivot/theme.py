from qgis.PyQt.QtWidgets import QApplication
from qgis.PyQt.QtGui import QColor, QBrush
from .compat import QPALETTE_WINDOW, QPALETTE_BASE


class ThemeManager:
    @staticmethod
    def is_dark_mode():
        try:
            app = QApplication.instance()
            if app:
                win_color = app.palette().color(QPALETTE_WINDOW)
                base_color = app.palette().color(QPALETTE_BASE)
                return win_color.lightness() < 128 or base_color.lightness() < 128
        except Exception:
            pass
        return False

    @classmethod
    def colors(cls):
        dark = cls.is_dark_mode()
        if dark:
            return {
                "is_dark": True,
                "bg_main": "#1e2227",
                "bg_panel": "#252a31",
                "bg_input": "#181b20",
                "bg_alt": "#2a3038",
                "bg_hover": "#323943",
                "bg_selected": "#1d4ed8",
                "text_main": "#e2e8f0",
                "text_muted": "#94a3b8",
                "text_selected": "#ffffff",
                "border": "#3b424d",
                "border_focus": "#3b82f6",
                "header_bg": "#2c323b",
                "header_text": "#f1f5f9",
                "accent_primary": "#2563eb",
                "accent_primary_hover": "#3b82f6",
                "accent_success": "#16a34a",
                "accent_success_hover": "#22c55e",
                "accent_warning": "#f59e0b",
                "accent_danger": "#dc2626",
                "accent_danger_hover": "#ef4444",
                "primary": "#3b82f6",
                "success": "#22c55e",
                "warning": "#f59e0b",
                "danger": "#ef4444",
                "btn_bg": "#2d333b",
                "btn_hover": "#373e47",
                "btn_disabled_bg": "#22262c",
                "btn_disabled_text": "#64748b",
                # Table semantic colors
                "table_even_bg": "#1e2227",
                "table_odd_bg": "#262c34",
                "table_text": "#e2e8f0",
                "table_subtotal_bg": "#1e3a5f",
                "table_grandtotal_bg": "#172554",
                "table_alert_bg": "#4c1d24",
                "table_alert_fg": "#fda4af",
                "delete_icon": "#f87171",
            }
        else:
            return {
                "is_dark": False,
                "bg_main": "#f8fafc",
                "bg_panel": "#ffffff",
                "bg_input": "#ffffff",
                "bg_alt": "#f1f5f9",
                "bg_hover": "#e2e8f0",
                "bg_selected": "#dbeafe",
                "text_main": "#1e293b",
                "text_muted": "#64748b",
                "text_selected": "#1e3a8a",
                "border": "#cbd5e1",
                "border_focus": "#2563eb",
                "header_bg": "#f1f5f9",
                "header_text": "#0f172a",
                "accent_primary": "#2563eb",
                "accent_primary_hover": "#1d4ed8",
                "accent_success": "#16a34a",
                "accent_success_hover": "#15803d",
                "accent_warning": "#d97706",
                "accent_danger": "#dc2626",
                "accent_danger_hover": "#b91c1c",
                "primary": "#2563eb",
                "success": "#16a34a",
                "warning": "#d97706",
                "danger": "#dc2626",
                "btn_bg": "#f1f5f9",
                "btn_hover": "#e2e8f0",
                "btn_disabled_bg": "#e2e8f0",
                "btn_disabled_text": "#94a3b8",
                # Table semantic colors
                "table_even_bg": "#ffffff",
                "table_odd_bg": "#f0f7ff",
                "table_text": "#1e293b",
                "table_subtotal_bg": "#e0f2fe",
                "table_grandtotal_bg": "#bae6fd",
                "table_alert_bg": "#ffe4e6",
                "table_alert_fg": "#b91c1c",
                "delete_icon": "#dc2626",
            }

    @classmethod
    def get_stylesheet(cls):
        c = cls.colors()
        return f"""
            QDockWidget {{
                color: {c['text_main']};
                font-family: 'Segoe UI', -apple-system, sans-serif;
            }}
            QDockWidget > QWidget {{
                background-color: {c['bg_main']};
                color: {c['text_main']};
            }}
            QDialog {{
                background-color: {c['bg_main']};
                color: {c['text_main']};
                font-family: 'Segoe UI', -apple-system, sans-serif;
            }}
            QWidget {{
                color: {c['text_main']};
            }}
            QLabel {{
                color: {c['text_main']};
                background: transparent;
            }}
            QLabel[role="sectionHeader"] {{
                color: {c['header_text']};
                font-weight: 600;
                font-size: 12px;
                padding: 2px 0px;
            }}
            QLabel[role="muted"] {{
                color: {c['text_muted']};
                font-size: 11px;
            }}

            /* --- Buttons --- */
            QPushButton, QToolButton {{
                background-color: {c['btn_bg']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 4px;
                padding: 4px 10px;
                min-height: 20px;
                font-weight: 500;
            }}
            QPushButton:hover, QToolButton:hover {{
                background-color: {c['bg_hover']};
                border-color: {c['border_focus']};
            }}
            QPushButton:checked, QToolButton:checked {{
                background-color: {c['bg_selected']};
                color: {c['text_selected']};
                border: 1px solid {c['border_focus']};
                font-weight: 600;
            }}
            QPushButton:disabled, QToolButton:disabled {{
                background-color: {c['btn_disabled_bg']};
                color: {c['btn_disabled_text']};
                border-color: {c['border']};
            }}

            /* Primary Action Buttons */
            QPushButton[btnRole="primary"] {{
                background-color: {c['accent_primary']};
                color: #ffffff;
                border: 1px solid {c['accent_primary']};
                font-weight: 600;
                min-height: 26px;
            }}
            QPushButton[btnRole="primary"]:hover {{
                background-color: {c['accent_primary_hover']};
            }}
            QPushButton[btnRole="primary"]:disabled {{
                background-color: {c['btn_disabled_bg']};
                color: {c['btn_disabled_text']};
                border-color: {c['border']};
            }}

            /* Success Action Buttons (Geosearch / Calculate) */
            QPushButton[btnRole="success"] {{
                background-color: {c['accent_success']};
                color: #ffffff;
                border: 1px solid {c['accent_success']};
                font-weight: 600;
                min-height: 26px;
            }}
            QPushButton[btnRole="success"]:hover {{
                background-color: {c['accent_success_hover']};
            }}
            QPushButton[btnRole="success"]:disabled {{
                background-color: {c['btn_disabled_bg']};
                color: {c['btn_disabled_text']};
                border-color: {c['border']};
            }}

            /* Danger Buttons */
            QPushButton[btnRole="danger"] {{
                background-color: {c['accent_danger']};
                color: #ffffff;
                border: 1px solid {c['accent_danger']};
                font-weight: 600;
            }}
            QPushButton[btnRole="danger"]:hover {{
                background-color: {c['accent_danger_hover']};
            }}

            /* --- Inputs, SpinBoxes & ComboBoxes (with Dark/Light Dropdown Readability) --- */
            QLineEdit, QDoubleSpinBox, QTextEdit {{
                background-color: {c['bg_input']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 4px;
                padding: 4px 8px;
                selection-background-color: {c['accent_primary']};
                selection-color: #ffffff;
            }}
            QLineEdit:focus, QDoubleSpinBox:focus, QTextEdit:focus {{
                border: 1px solid {c['border_focus']};
            }}
            QComboBox {{
                background-color: {c['bg_input']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 4px;
                padding: 4px 8px;
                min-height: 20px;
            }}
            QComboBox:hover, QComboBox:focus {{
                border-color: {c['border_focus']};
            }}
            QComboBox:disabled {{
                background-color: {c['btn_disabled_bg']};
                color: {c['btn_disabled_text']};
            }}
            QComboBox QAbstractItemView {{
                background-color: {c['bg_panel']};
                color: {c['text_main']};
                border: 1px solid {c['border_focus']};
                selection-background-color: {c['bg_selected']};
                selection-color: {c['text_selected']};
                outline: 0;
                padding: 2px;
            }}
            QComboBox QAbstractItemView::item {{
                min-height: 24px;
                padding: 3px 8px;
                color: {c['text_main']};
                background-color: {c['bg_panel']};
            }}
            QComboBox QAbstractItemView::item:selected,
            QComboBox QAbstractItemView::item:hover {{
                background-color: {c['bg_selected']};
                color: {c['text_selected']};
            }}

            /* --- Lists, Trees & Tables --- */
            QListWidget, QTreeWidget, QTableView, QTableWidget {{
                background-color: {c['bg_panel']};
                alternate-background-color: {c['bg_alt']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 4px;
                gridline-color: {c['border']};
                outline: 0;
            }}
            QListWidget::item, QTreeWidget::item {{
                padding: 3px 6px;
                border-radius: 3px;
                color: {c['text_main']};
            }}
            QListWidget::item:hover, QTreeWidget::item:hover {{
                background-color: {c['bg_hover']};
            }}
            QListWidget::item:selected, QTreeWidget::item:selected {{
                background-color: {c['bg_selected']};
                color: {c['text_selected']};
            }}
            QTableView::item:selected, QTableWidget::item:selected {{
                background-color: {c['bg_selected']};
                color: {c['text_selected']};
            }}
            QHeaderView::section {{
                background-color: {c['header_bg']};
                color: {c['header_text']};
                font-weight: 600;
                padding: 5px 8px;
                border: none;
                border-right: 1px solid {c['border']};
                border-bottom: 1px solid {c['border']};
            }}

            /* --- Tabs --- */
            QTabWidget::pane {{
                border: 1px solid {c['border']};
                border-radius: 4px;
                background-color: {c['bg_main']};
                top: -1px;
            }}
            QTabBar::tab {{
                background-color: {c['btn_bg']};
                color: {c['text_muted']};
                border: 1px solid {c['border']};
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                padding: 5px 12px;
                margin-right: 2px;
                font-weight: 500;
            }}
            QTabBar::tab:hover {{
                background-color: {c['bg_hover']};
                color: {c['text_main']};
            }}
            QTabBar::tab:selected {{
                background-color: {c['bg_panel']};
                color: {c['header_text']};
                font-weight: 600;
                border-bottom: 2px solid {c['accent_primary']};
            }}

            /* --- Checkboxes & RadioButtons --- */
            QCheckBox, QRadioButton {{
                color: {c['text_main']};
                spacing: 6px;
            }}
            QCheckBox:disabled, QRadioButton:disabled {{
                color: {c['btn_disabled_text']};
            }}

            /* --- Context Menus --- */
            QMenu {{
                background-color: {c['bg_panel']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                padding: 4px;
            }}
            QMenu::item {{
                padding: 5px 22px 5px 12px;
                border-radius: 3px;
            }}
            QMenu::item:selected {{
                background-color: {c['bg_selected']};
                color: {c['text_selected']};
            }}
            QMenu::separator {{
                height: 1px;
                background: {c['border']};
                margin: 4px 6px;
            }}

            /* --- Splitters & ProgressBar --- */
            QSplitter::handle {{
                background-color: {c['border']};
            }}
            QSplitter::handle:horizontal {{
                width: 2px;
                margin: 0px 2px;
            }}
            QSplitter::handle:vertical {{
                height: 2px;
                margin: 2px 0px;
            }}
            QProgressBar {{
                background-color: {c['bg_input']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 4px;
                text-align: center;
                font-weight: 600;
                min-height: 18px;
            }}
            QProgressBar::chunk {{
                background-color: {c['accent_primary']};
                border-radius: 3px;
            }}
        """

    @classmethod
    def apply_dialog_theme(cls, widget):
        try:
            widget.setStyleSheet(cls.get_stylesheet())
        except Exception:
            pass

    @classmethod
    def set_button_role(cls, btn, role):
        try:
            btn.setProperty("btnRole", role)
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        except Exception:
            pass
