from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QCheckBox, QLineEdit, QDialogButtonBox, QComboBox
from .compat import *
from .i18n import tr
from .theme import ThemeManager


class ExportGeoDialog(QDialog):
    def __init__(self, available_fields=None, has_aoi=False, has_buffered_aoi=False, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("Export Spatial Results"))
        self.setMinimumWidth(380)
        ThemeManager.apply_dialog_theme(self)
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(tr("<b>Output Destinations:</b>")))
        self.cb_gpkg = QCheckBox(tr("Save to GeoPackage (.gpkg)"))
        self.cb_gpkg.setChecked(True)
        self.cb_temp = QCheckBox(tr("Load as Temporary Layers on Map"))
        self.cb_temp.setChecked(False)
        layout.addWidget(self.cb_gpkg)
        layout.addWidget(self.cb_temp)

        layout.addWidget(QLabel(tr("<br><b>Include Content:</b>")))

        self.cb_sensitive = QCheckBox(tr("⚠️ Sensitive Detections (Alerts Only)"))
        self.cb_sensitive.setChecked(True)
        layout.addWidget(self.cb_sensitive)

        self.cb_rep = QCheckBox(tr("Query Report (Merged by Geometry Type)"))
        self.cb_rep.setChecked(True)
        self.cb_raw = QCheckBox(tr("Raw Geometries (Separate Layers)"))
        self.cb_raw.setChecked(True)
        self.cb_aoi = QCheckBox(tr("Original AOI Bounding Polygon"))
        self.cb_buffered_aoi = QCheckBox(tr("Multi-Ring Buffer Zones"))

        layout.addWidget(self.cb_rep)
        layout.addWidget(self.cb_raw)
        layout.addWidget(self.cb_aoi)
        layout.addWidget(self.cb_buffered_aoi)

        layout.addWidget(QLabel(tr("<br><b>Symbology Style:</b>")))
        sym_layout = QHBoxLayout()
        self.symbology_combo = QComboBox()
        self.symbology_combo.addItem(tr("Categorized"), "Categorized")
        self.symbology_combo.addItem(tr("Uniform Color"), "Uniform Color")
        sym_layout.addWidget(self.symbology_combo)

        self.sym_field_combo = QComboBox()

        fields_to_add = ["Group", "Layer"]
        if available_fields:
            fields_to_add.extend(available_fields)
        self.sym_field_combo.addItems(fields_to_add)

        sym_layout.addWidget(self.sym_field_combo)
        layout.addLayout(sym_layout)

        self.symbology_combo.currentIndexChanged.connect(self.toggle_field_combo)

        aoi_layout = QHBoxLayout()
        self.aoi_name_input = QLineEdit("AOI")
        self.aoi_name_input.setPlaceholderText(tr("Name (Optional)"))
        aoi_layout.addWidget(QLabel(tr("<br>AOI Layer Name:")))
        aoi_layout.addWidget(self.aoi_name_input)
        layout.addLayout(aoi_layout)

        if not has_aoi:
            self.cb_aoi.setChecked(False)
            self.cb_aoi.setEnabled(False)
            self.aoi_name_input.setEnabled(False)
        else:
            self.cb_aoi.setChecked(True)

        if not has_buffered_aoi:
            self.cb_buffered_aoi.setChecked(False)
            self.cb_buffered_aoi.setEnabled(False)
        else:
            self.cb_buffered_aoi.setChecked(True)

        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        btns.button(QDIALOG_BTN_OK).setText(tr("Generate"))
        layout.addWidget(btns)

    def toggle_field_combo(self, _idx=None):
        self.sym_field_combo.setEnabled(self.get_symbology_style() == "Categorized")

    def get_symbology_style(self):
        return self.symbology_combo.currentData() or "Categorized"


class CanvasDisplayDialog(QDialog):
    def __init__(self, available_fields=None, has_aoi=False, has_buffered_aoi=False, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("Show on Canvas"))
        self.setMinimumWidth(380)
        ThemeManager.apply_dialog_theme(self)
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(tr("<b>Select layers to generate and show:</b>")))

        self.cb_sensitive = QCheckBox(tr("⚠️ Sensitive Detections (Alerts Only)"))
        self.cb_sensitive.setChecked(True)
        layout.addWidget(self.cb_sensitive)

        self.cb_rep = QCheckBox(tr("Query Report (Merged by Geometry Type)"))
        self.cb_rep.setChecked(True)
        self.cb_raw = QCheckBox(tr("Raw Geometries (Separate Layers)"))
        self.cb_raw.setChecked(False)
        self.cb_aoi = QCheckBox(tr("Original AOI Bounding Polygon"))
        self.cb_buffered_aoi = QCheckBox(tr("Multi-Ring Buffer Zones"))

        layout.addWidget(self.cb_rep)
        layout.addWidget(self.cb_raw)
        layout.addWidget(self.cb_aoi)
        layout.addWidget(self.cb_buffered_aoi)

        layout.addWidget(QLabel(tr("<br><b>Symbology Style:</b>")))
        sym_layout = QHBoxLayout()
        self.symbology_combo = QComboBox()
        self.symbology_combo.addItem(tr("Categorized"), "Categorized")
        self.symbology_combo.addItem(tr("Uniform Color"), "Uniform Color")
        sym_layout.addWidget(self.symbology_combo)

        self.sym_field_combo = QComboBox()

        fields_to_add = ["Group", "Layer"]
        if available_fields:
            fields_to_add.extend(available_fields)
        self.sym_field_combo.addItems(fields_to_add)

        sym_layout.addWidget(self.sym_field_combo)
        layout.addLayout(sym_layout)

        self.symbology_combo.currentIndexChanged.connect(self.toggle_field_combo)

        if not has_aoi:
            self.cb_aoi.setChecked(False)
            self.cb_aoi.setEnabled(False)
        else:
            self.cb_aoi.setChecked(True)

        if not has_buffered_aoi:
            self.cb_buffered_aoi.setChecked(False)
            self.cb_buffered_aoi.setEnabled(False)
        else:
            self.cb_buffered_aoi.setChecked(True)

        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        btns.button(QDIALOG_BTN_OK).setText(tr("Show Layers"))
        layout.addWidget(btns)

    def toggle_field_combo(self, _idx=None):
        self.sym_field_combo.setEnabled(self.get_symbology_style() == "Categorized")

    def get_symbology_style(self):
        return self.symbology_combo.currentData() or "Categorized"
