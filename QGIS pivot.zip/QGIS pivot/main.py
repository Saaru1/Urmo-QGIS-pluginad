import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from .dialog import PivotDockWidget
from .i18n import tr, TranslationManager
from .compat import QT_BOTTOM_DOCK_WIDGET_AREA, QT_VERTICAL


class SpatialPivotPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dockwidget = None
        self.menu_name = "&Spatial Pivot"

    def _get_icon(self):
        svg_path = os.path.join(self.plugin_dir, 'icon.svg')
        png_path = os.path.join(self.plugin_dir, 'icon.png')
        legacy_path = os.path.join(self.plugin_dir, 'popup_button.png')
        if os.path.exists(png_path):
            return QIcon(png_path)
        if os.path.exists(svg_path):
            return QIcon(svg_path)
        return QIcon(legacy_path)

    def initGui(self):
        icon = self._get_icon()
        self.action = QAction(icon, tr("Spatial Pivot Dashboard"), self.iface.mainWindow())
        self.action.setToolTip(tr("Spatial Pivot Dashboard"))
        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu(self.menu_name, self.action)
        self.iface.addToolBarIcon(self.action)
        TranslationManager.add_listener(self._on_language_changed)

    def _on_language_changed(self, _lang):
        if self.action:
            self.action.setText(tr("Spatial Pivot Dashboard"))
            self.action.setToolTip(tr("Spatial Pivot Dashboard"))

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(self.menu_name, self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)
            self.dockwidget = None

    def run(self):
        """Docks the dashboard and handles visibility / un-minimizing."""
        main_window = self.iface.mainWindow()

        if self.dockwidget is None:
            self.dockwidget = PivotDockWidget(self.iface)
            self.dockwidget.setWindowIcon(self._get_icon())
            self.iface.addDockWidget(QT_BOTTOM_DOCK_WIDGET_AREA, self.dockwidget)

            try:
                main_window.resizeDocks([self.dockwidget], [360], QT_VERTICAL)
            except Exception:
                pass
        else:
            if getattr(self.dockwidget, 'is_collapsed', False):
                self.dockwidget.toggle_collapse(False)

        self.dockwidget.show()
        self.dockwidget.raise_()
