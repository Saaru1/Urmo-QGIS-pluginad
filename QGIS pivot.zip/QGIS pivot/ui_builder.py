from qgis.PyQt.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget, QTabWidget, 
                                 QTextEdit, QCheckBox, QSplitter, QTreeWidget, 
                                 QTreeWidgetItem, QLineEdit, QComboBox, QAbstractItemView, QProgressBar)

from .compat import *
from .aoi_tools import AOIWidget
from .custom_widgets import (DragDropList, FieldDropList, ProfileDropList, TargetListWidget, 
                             DashboardTableView, BaseLayerDropList, JoinLayerDropList, CatalogTreeWidget)

class PivotUIBuilder:
    @staticmethod
    def create_panel(title, widget):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel(title)
        lbl.setStyleSheet("font-weight: bold; color: #333;")
        layout.addWidget(lbl)
        layout.addWidget(widget)
        return panel

    @staticmethod
    def build(dock):
        main_layout = QVBoxLayout(dock.dock_content)
        main_layout.setContentsMargins(2, 2, 2, 2)
        
        top_bar_layout = QHBoxLayout()
        dock.aoi_widget = AOIWidget(dock.iface.mapCanvas(), dock)
        dock.aoi_widget.aoi_changed.connect(dock.on_aoi_updated)
        dock.aoi_widget.buffer_captured_main.connect(dock.on_interactive_buffer_captured_main)
        dock.aoi_widget.buffer_captured_custom.connect(dock.on_interactive_buffer_captured_custom)
        
        top_bar_layout.addWidget(dock.aoi_widget)
        top_bar_layout.addSpacing(10)
        
        dock.overlap_btn = QPushButton(" AOI Pivot Overlap: OFF")
        dock.overlap_btn.setCheckable(True)
        dock.overlap_btn.setEnabled(False)
        dock.overlap_btn.toggled.connect(dock.on_overlap_toggled)
        top_bar_layout.addWidget(dock.overlap_btn)
        
        dock.live_check = QCheckBox("LIVE view")
        dock.live_check.setStyleSheet("font-weight: bold; color: #d35400;")
        dock.live_check.clicked.connect(dock.on_live_toggled)
        top_bar_layout.addWidget(dock.live_check)
        
        top_bar_layout.addStretch()
        main_layout.addLayout(top_bar_layout)

        dock.global_splitter = QSplitter(QT_HORIZONTAL)

        left_pane = QWidget()
        left_layout = QVBoxLayout(left_pane)
        left_layout.setContentsMargins(0, 0, 5, 0)
        
        left_layout.addWidget(QLabel("<b>Data Catalog</b><br><i>Double-click to send to active tab</i>"))
        
        search_layout = QHBoxLayout()
        dock.global_search = QLineEdit()
        dock.global_search.setPlaceholderText("Search catalog...")
        dock.global_search.textChanged.connect(lambda t: dock.filter_tree(t, dock.global_sources_tree))
        
        dock.global_refresh_btn = QPushButton("🔄")
        dock.global_refresh_btn.setToolTip("Force Refresh")
        dock.global_refresh_btn.setFixedWidth(30)
        dock.global_refresh_btn.clicked.connect(dock.wfs_manager.force_refresh_wfs)
        
        search_layout.addWidget(dock.global_search)
        search_layout.addWidget(dock.global_refresh_btn)
        left_layout.addLayout(search_layout)
        
        dock.global_sources_tree = CatalogTreeWidget()
        dock.global_sources_tree.setHeaderHidden(True)
        dock.global_sources_tree.setDragEnabled(True)
        dock.global_sources_tree.setMinimumHeight(1) 
        dock.global_sources_tree.itemDoubleClicked.connect(dock.on_wfs_tree_double_clicked)
        
        dock.global_sources_tree.setContextMenuPolicy(QT_CUSTOM_CONTEXT_MENU)
        dock.global_sources_tree.customContextMenuRequested.connect(lambda pos: dock.show_catalog_context_menu(pos, dock.global_sources_tree))
        
        dock.global_root_canvas = QTreeWidgetItem(dock.global_sources_tree, ["🗺️ Map Canvas"])
        dock.global_root_local = QTreeWidgetItem(dock.global_sources_tree, ["📁 Local Files"])
        dock.global_root_wfs = QTreeWidgetItem(dock.global_sources_tree, ["🌐 WFS Catalog"])
            
        left_layout.addWidget(dock.global_sources_tree)
        dock.global_add_local_btn = QPushButton("Add Local File (.shp, .gpkg, .tab)")
        dock.global_add_local_btn.clicked.connect(dock.add_local_file)
        left_layout.addWidget(dock.global_add_local_btn)
        
        dock.global_splitter.addWidget(left_pane)

        right_pane = QWidget()
        right_layout = QVBoxLayout(right_pane)
        right_layout.setContentsMargins(5, 0, 0, 0)

        dock.tabs = QTabWidget()
        dock.tabs.setMinimumHeight(1) 
        right_layout.addWidget(dock.tabs)
        
        # --- PIVOT SETUP TAB ---
        dock.tab_setup = QWidget()
        setup_layout = QVBoxLayout(dock.tab_setup)
        
        ws_layout = QHBoxLayout()
        dock.save_ws_btn = QPushButton("Save Workspace"); dock.save_ws_btn.clicked.connect(dock.profile_io.save_workspace)
        dock.load_ws_btn = QPushButton("Load Workspace"); dock.load_ws_btn.clicked.connect(dock.profile_io.load_workspace)
        dock.clear_btn = QPushButton("Clear Pivot Setup"); dock.clear_btn.clicked.connect(dock.clear_setup)
        ws_layout.addWidget(dock.save_ws_btn); ws_layout.addWidget(dock.load_ws_btn)
        ws_layout.addStretch(); ws_layout.addWidget(dock.clear_btn)
        setup_layout.addLayout(ws_layout)

        setup_main_splitter = QSplitter(QT_HORIZONTAL)

        fields_panel = QWidget()
        f_layout = QVBoxLayout(fields_panel)
        f_layout.setContentsMargins(0, 0, 0, 0)
        dock.fields_list = DragDropList("Fields", removable=False, accept_drops=False)
        f_layout.addWidget(PivotUIBuilder.create_panel("Available Fields", dock.fields_list))
        setup_main_splitter.addWidget(fields_panel)

        right_setup_panel = QWidget()
        rs_layout = QVBoxLayout(right_setup_panel)
        rs_layout.setContentsMargins(0, 0, 0, 0)
        
        drop_panel = QWidget(); d_layout = QVBoxLayout(drop_panel); d_layout.setContentsMargins(0,0,0,0)
        dock.base_layer_list = BaseLayerDropList("Base Layer", removable=True)
        dock.base_layer_list.model().rowsInserted.connect(dock.on_sources_changed)
        dock.base_layer_list.item_deleted.connect(dock.on_sources_changed)
        d_layout.addWidget(PivotUIBuilder.create_panel("Base Layer (1 max)", dock.base_layer_list))
        
        dock.join_layer_list = JoinLayerDropList("Spatial Join Layers", removable=True)
        dock.join_layer_list.model().rowsInserted.connect(dock.on_sources_changed)
        dock.join_layer_list.item_deleted.connect(dock.on_sources_changed)
        d_layout.addWidget(PivotUIBuilder.create_panel("Spatial Join Layers", dock.join_layer_list))
        rs_layout.addWidget(drop_panel, stretch=1)

        zones_splitter = QSplitter(QT_HORIZONTAL)
        dock.filters_list = FieldDropList("Filters", removable=True); dock.filters_list.itemDoubleClicked.connect(dock.set_filter_value)
        dock.rows_list = FieldDropList("Rows", removable=True, hierarchical=True) 
        dock.cols_list = FieldDropList("Columns", removable=True, hierarchical=True) 
        dock.vals_list = FieldDropList("Values", removable=True); dock.vals_list.itemDoubleClicked.connect(dock.set_value_agg) 
        
        zones_splitter.addWidget(PivotUIBuilder.create_panel("Filters", dock.filters_list))
        zones_splitter.addWidget(PivotUIBuilder.create_panel("Rows", dock.rows_list))
        zones_splitter.addWidget(PivotUIBuilder.create_panel("Columns", dock.cols_list))
        
        val_panel = QWidget(); val_layout = QVBoxLayout(val_panel); val_layout.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel("Values"); lbl.setStyleSheet("font-weight: bold; color: #333;")
        
        opt_lyt = QVBoxLayout()
        opt_lyt.setSpacing(2)
        opt_lyt.setContentsMargins(0, 0, 0, 5)
        dock.totals_check = QCheckBox("Show Totals & Subtotals"); dock.totals_check.clicked.connect(dock.on_totals_toggled) 
        dock.force_zeros_check = QCheckBox("Show 0-value Filter Items")
        dock.force_zeros_check.setToolTip("Force items selected in Filters to appear in the table even if their calculated value is 0.")
        opt_lyt.addWidget(dock.totals_check)
        opt_lyt.addWidget(dock.force_zeros_check)
        
        val_layout.addWidget(lbl); val_layout.addLayout(opt_lyt); val_layout.addWidget(dock.vals_list)
        zones_splitter.addWidget(val_panel)
        
        rs_layout.addWidget(zones_splitter, stretch=1)
        setup_main_splitter.addWidget(right_setup_panel)

        setup_main_splitter.setStretchFactor(0, 2) 
        setup_main_splitter.setStretchFactor(1, 8) 

        setup_layout.addWidget(setup_main_splitter, stretch=1)
        dock.calc_btn = QPushButton("Calculate Pivot"); dock.calc_btn.setStyleSheet("font-weight: bold; height: 30px;"); dock.calc_btn.clicked.connect(dock.calculate_pivot)
        setup_layout.addWidget(dock.calc_btn)
        dock.tabs.addTab(dock.tab_setup, "Pivot Setup")

        # --- GEOSEARCH TAB ---
        dock.tab_geosearch = QWidget()
        geo_layout = QVBoxLayout(dock.tab_geosearch)
        
        geo_top_bar = QHBoxLayout()
        geo_top_bar.addStretch()
        dock.clear_geo_btn = QPushButton("Clear Targets")
        geo_top_bar.addWidget(dock.clear_geo_btn)
        geo_layout.addLayout(geo_top_bar)
        
        geo_splitter = QSplitter(QT_HORIZONTAL)
        
        target_panel = QWidget(); target_layout = QVBoxLayout(target_panel); target_layout.setContentsMargins(0,0,0,0)
        t_header_layout = QHBoxLayout()
        t_header_layout.addWidget(QLabel("<b>Target Layers</b><br><i>Right-click to set Rules</i>"))
        t_header_layout.addStretch()
        target_layout.addLayout(t_header_layout)
        
        dock.geo_target_list = TargetListWidget("Targets", dialog_ref=dock)
        dock.geo_target_list.schema_requested.connect(dock.request_schema) 
        dock.geo_target_list.filter_requested.connect(dock.request_filter) 
        dock.geo_target_list.buffer_role_requested.connect(dock.request_buffer_role)
        try: dock.geo_target_list.secondary_requested.connect(dock.request_secondary_expr)
        except AttributeError: pass
        
        target_layout.addWidget(dock.geo_target_list)
        dock.clear_geo_btn.clicked.connect(dock.geo_target_list.clear)
        geo_splitter.addWidget(target_panel)
        
        profile_panel = QWidget(); profile_layout = QVBoxLayout(profile_panel); profile_layout.setContentsMargins(0,0,0,0)
        profile_layout.addWidget(QLabel("<b>Saved Search Profiles</b><br><i>Double-click or drag to unpack</i>"))
        
        dock.geo_profile_list = ProfileDropList("Profiles", removable=True, confirm_delete=True, accept_drops=False)
        dock.geo_profile_list.setDragEnabled(True)
        dock.geo_profile_list.itemDoubleClicked.connect(dock.profile_io.load_wfs_profile_click_trigger); dock.geo_profile_list.item_deleted.connect(dock.profile_io.delete_wfs_profile) 
        dock.geo_profile_list.edit_requested.connect(dock.open_profile_manager)
        
        prof_btn_layout = QHBoxLayout()
        prof_btn = QPushButton("Save Current as Profile"); prof_btn.clicked.connect(dock.profile_io.save_wfs_profile)
        prof_import_btn = QPushButton("📂")
        prof_import_btn.setFixedWidth(30)
        prof_import_btn.setToolTip("Import Profile JSON")
        prof_import_btn.clicked.connect(dock.profile_io.import_profile)
        
        prof_export_btn = QPushButton("💾")
        prof_export_btn.setFixedWidth(30)
        prof_export_btn.setToolTip("Export Profile JSON")
        prof_export_btn.clicked.connect(dock.profile_io.export_profile)
        
        prof_btn_layout.addWidget(prof_btn, stretch=1)
        prof_btn_layout.addWidget(prof_import_btn)
        prof_btn_layout.addWidget(prof_export_btn)
        
        profile_layout.addWidget(dock.geo_profile_list); profile_layout.addLayout(prof_btn_layout)
        geo_splitter.addWidget(profile_panel)
        
        geo_splitter.setStretchFactor(0, 6)
        geo_splitter.setStretchFactor(1, 4)
        geo_layout.addWidget(geo_splitter)
        
        geo_btn_layout = QHBoxLayout()
        
        dock.geo_predicate_combo = QComboBox()
        dock.geo_predicate_combo.addItems(["Intersects", "Contains", "Within", "Touches"])
        dock.geo_predicate_combo.setToolTip("Spatial rule against your AOI")
        dock.geo_predicate_combo.setEnabled(False) 
        
        dock.geo_buffer_main_btn = QPushButton("⚙️ Main Buffers: [ 0m ]")
        dock.geo_buffer_main_btn.setEnabled(False)
        dock.geo_buffer_main_btn.clicked.connect(dock.open_buffer_manager_main)
        
        dock.geo_buffer_custom_btn = QPushButton("⚙️ Custom Buffers: [ 0m ]")
        dock.geo_buffer_custom_btn.setEnabled(False)
        dock.geo_buffer_custom_btn.clicked.connect(dock.open_buffer_manager_custom)
        
        geo_btn_layout.addWidget(QLabel("Rule:"))
        geo_btn_layout.addWidget(dock.geo_predicate_combo)
        geo_btn_layout.addWidget(dock.geo_buffer_main_btn)
        geo_btn_layout.addWidget(dock.geo_buffer_custom_btn)
        
        dock.strict_mode_check = QCheckBox("Strict Profile Enforcement")
        dock.strict_mode_check.setToolTip("Enforce layer-specific buffer roles and hide completely empty buffer columns.")
        dock.strict_mode_check.setChecked(False)
        geo_btn_layout.addWidget(dock.strict_mode_check)
        
        dock.run_geosearch_btn = QPushButton("▶ Run Geosearch in AOI")
        dock.run_geosearch_btn.setEnabled(False) 
        dock.run_geosearch_btn.setStyleSheet("""
            QPushButton { font-weight: bold; height: 35px; background-color: #27ae60; color: white; border-radius: 3px; }
            QPushButton:disabled { background-color: #bdc3c7; color: #7f8c8d; }
        """)
        dock.run_geosearch_btn.clicked.connect(dock.run_geosearch)
        
        geo_btn_layout.addWidget(dock.run_geosearch_btn, stretch=1)
        geo_layout.addLayout(geo_btn_layout)
        dock.tabs.addTab(dock.tab_geosearch, "Geosearch")

        # --- DASHBOARD TAB ---
        dock.tab_dashboard = QWidget()
        dash_layout = QVBoxLayout(dock.tab_dashboard)
        dash_btn_layout = QHBoxLayout()
        
        dock.export_btn = QPushButton("Export Data Table"); dock.export_btn.clicked.connect(dock.export_data) 
        dock.export_geo_btn = QPushButton("Export Geodata (GPKG/Map)"); dock.export_geo_btn.clicked.connect(dock.prompt_export_geodata)
        dock.export_geo_btn.setEnabled(False)
        
        dock.export_pdf_btn = QPushButton("Generate PDF Report")
        dock.export_pdf_btn.setEnabled(False) 
        dock.export_pdf_btn.clicked.connect(dock.export_pdf_report)
        
        dock.toggle_canvas_btn = QPushButton("👁️ Show on Canvas")
        dock.toggle_canvas_btn.setCheckable(True)
        dock.toggle_canvas_btn.setEnabled(False) 
        dock.toggle_canvas_btn.clicked.connect(dock.toggle_geosearch_canvas)
        
        dock.transpose_btn = QPushButton("⇄ Transpose Matrix")
        dock.transpose_btn.setCheckable(True)
        dock.transpose_btn.setToolTip("Flip Rows and Columns (Pivot Only)")

        dock.chart_btn = QPushButton("📊 Open Chart in Browser")
        dock.chart_btn.setEnabled(False)
        dock.chart_btn.setToolTip("Generate and open an interactive chart dashboard in your web browser")

        dock.clear_dash_btn = QPushButton("Clear Dashboard"); dock.clear_dash_btn.clicked.connect(dock.clear_dashboard)
        
        dash_btn_layout.addWidget(dock.export_btn)
        dash_btn_layout.addWidget(dock.export_geo_btn)
        dash_btn_layout.addWidget(dock.export_pdf_btn)
        dash_btn_layout.addWidget(dock.toggle_canvas_btn)
        dash_btn_layout.addWidget(dock.transpose_btn)
        dash_btn_layout.addWidget(dock.chart_btn)
        dash_btn_layout.addWidget(dock.clear_dash_btn)
        dash_btn_layout.addStretch()
        
        dock.status_label = QLabel(""); dock.status_label.setStyleSheet("font-size: 13px;")
        dash_btn_layout.addWidget(dock.status_label)
        dash_layout.addLayout(dash_btn_layout)
        
        dock.dash_filter_input = QLineEdit()
        dock.dash_filter_input.setPlaceholderText("🔍 Filter Dashboard Rows (type to search...)")
        dock.dash_filter_input.setStyleSheet("padding: 4px; border: 1px solid #bdc3c7; border-radius: 3px;")
        dash_layout.addWidget(dock.dash_filter_input)
        
        dock.result_table = DashboardTableView()
        dock.result_table.setSortingEnabled(True)
        dock.result_table.row_selected.connect(dock.on_row_selected)
        
        dash_layout.addWidget(dock.result_table)
        
        dock.tabs.addTab(dock.tab_dashboard, "Dashboard")

        # --- TEMPORAL ANALYSIS TAB ---
        from .temporal_ui import TemporalUIBuilder
        TemporalUIBuilder.build(dock)

        # --- LOG TAB ---
        dock.tab_logs = QWidget()
        log_layout = QVBoxLayout(dock.tab_logs)
        dock.log_text = QTextEdit(); dock.log_text.setReadOnly(True)
        dock.log_text.setMinimumHeight(1) 
        log_layout.addWidget(dock.log_text)
        dock.tabs.addTab(dock.tab_logs, "Log Panel")
        
        dock.global_splitter.addWidget(right_pane)
        dock.global_splitter.setStretchFactor(0, 1) 
        dock.global_splitter.setStretchFactor(1, 3) 
        main_layout.addWidget(dock.global_splitter, stretch=1)

        dock.progress_bar = QProgressBar()
        dock.progress_bar.setRange(0, 100)
        dock.progress_bar.setVisible(False)

        dock.cancel_task_btn = QPushButton("🛑 Cancel")
        dock.cancel_task_btn.setStyleSheet("background-color: #e74c3c; color: white; font-weight: bold; padding: 2px 10px;")
        dock.cancel_task_btn.setVisible(False)

        prog_layout = QHBoxLayout()
        prog_layout.addWidget(dock.progress_bar)
        prog_layout.addWidget(dock.cancel_task_btn)
        main_layout.addLayout(prog_layout)