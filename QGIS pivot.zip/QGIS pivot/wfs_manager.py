import base64
import json
from urllib.parse import urlparse

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QLabel, QLineEdit, QPushButton, QCheckBox, QDialogButtonBox,
    QMessageBox, QTreeWidgetItem, QApplication
)
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.core import QgsSettings, QgsApplication, QgsProject

from .compat import (
    QT_USER_ROLE, QLINEEDIT_NORMAL, QLINEEDIT_PASSWORD,
    QDIALOG_BTN_OK, QDIALOG_BTN_CANCEL, QT_WAIT_CURSOR
)
from .i18n import tr
from .theme import ThemeManager


class WfsAuthManager:
    """Manages WFS server and domain authentication credentials."""
    SETTINGS_KEY = "spatial_pivot/wfs_auth_v1"

    @classmethod
    def _encode_secret(cls, text):
        if not text:
            return ""
        try:
            return base64.b64encode(text.encode("utf-8")).decode("ascii")
        except Exception:
            return ""

    @classmethod
    def _decode_secret(cls, encoded):
        if not encoded:
            return ""
        try:
            return base64.b64decode(encoded.encode("ascii")).decode("utf-8")
        except Exception:
            return encoded

    @classmethod
    def extract_domain(cls, url):
        if not url:
            return ""
        try:
            parsed = urlparse(url.strip())
            return (parsed.netloc or parsed.path.split("/")[0]).lower()
        except Exception:
            return ""

    @classmethod
    def _load_store(cls):
        try:
            raw = QgsSettings().value(cls.SETTINGS_KEY, "{}")
            data = json.loads(raw) if raw else {}
            if not isinstance(data, dict):
                data = {}
        except Exception:
            data = {}
        data.setdefault("servers", {})
        data.setdefault("domains", {})
        return data

    @classmethod
    def _save_store(cls, data):
        try:
            QgsSettings().setValue(cls.SETTINGS_KEY, json.dumps(data))
        except Exception:
            pass

    @classmethod
    def save_credentials(cls, server_name, url, username, password, authcfg="", apply_to_domain=True):
        store = cls._load_store()
        domain = cls.extract_domain(url)
        clean_name = cls.clean_server_label(server_name)

        if not username and not password and not authcfg:
            cls.clear_credentials(clean_name, url)
            return

        entry = {
            "username": username.strip(),
            "password_b64": cls._encode_secret(password),
            "authcfg": authcfg.strip(),
            "apply_to_domain": bool(apply_to_domain),
            "domain": domain,
            "url": (url or "").split("?")[0].strip(),
        }
        if clean_name:
            store["servers"][clean_name] = entry
        if apply_to_domain and domain:
            store["domains"][domain] = entry
        elif domain and store["domains"].get(domain, {}).get("url") == entry["url"]:
            store["domains"].pop(domain, None)

        cls._save_store(store)

    @classmethod
    def clear_credentials(cls, server_name=None, url=None):
        store = cls._load_store()
        clean_name = cls.clean_server_label(server_name) if server_name else ""
        domain = cls.extract_domain(url) if url else ""

        if clean_name and clean_name in store["servers"]:
            removed = store["servers"].pop(clean_name, {})
            rem_dom = removed.get("domain") or domain
            if rem_dom and rem_dom in store["domains"]:
                store["domains"].pop(rem_dom, None)

        if domain and domain in store["domains"]:
            store["domains"].pop(domain, None)

        cls._save_store(store)

    @classmethod
    def rename_server_credentials(cls, old_name, new_name):
        store = cls._load_store()
        c_old = cls.clean_server_label(old_name)
        c_new = cls.clean_server_label(new_name)
        if c_old in store["servers"] and c_new:
            store["servers"][c_new] = store["servers"].pop(c_old)
            cls._save_store(store)

    @classmethod
    def get_credentials(cls, url=None, server_name=None):
        store = cls._load_store()
        clean_name = cls.clean_server_label(server_name) if server_name else ""
        clean_url = (url or "").split("?")[0].strip()
        domain = cls.extract_domain(url) if url else ""

        entry = None
        if clean_name and clean_name in store["servers"]:
            entry = store["servers"][clean_name]
        if not entry and clean_url:
            for srv_entry in store["servers"].values():
                if srv_entry.get("url") == clean_url:
                    entry = srv_entry
                    break
        if not entry and domain and domain in store["domains"]:
            entry = store["domains"][domain]

        if not entry:
            return None

        username = entry.get("username", "")
        password = cls._decode_secret(entry.get("password_b64", ""))
        authcfg = entry.get("authcfg", "")
        if not username and not password and not authcfg:
            return None

        return {
            "username": username,
            "password": password,
            "authcfg": authcfg,
            "apply_to_domain": entry.get("apply_to_domain", True),
        }

    @classmethod
    def has_credentials(cls, url=None, server_name=None):
        return cls.get_credentials(url=url, server_name=server_name) is not None

    @classmethod
    def clean_server_label(cls, text):
        if not text:
            return ""
        clean = str(text)
        if clean.startswith("🔒 "):
            clean = clean[2:].strip()
        for suffix in [
            " [Failed]", " [Loading...]", " [Auth Required]",
            f" [{tr('Failed')}]", f" [{tr('Loading...')}]", f" [{tr('Auth Required')}]",
            " [Ebaõnnestus]", " [Laadimine...]", " [Vajab autentimist]"
        ]:
            clean = clean.replace(suffix, "")
        return clean.strip()

    @classmethod
    def build_wfs_uri(cls, url, layer_name, crs_authid=None, server_name=None):
        if not crs_authid:
            try:
                crs_authid = QgsProject.instance().crs().authid() or "EPSG:3301"
            except Exception:
                crs_authid = "EPSG:3301"

        url_clean = (url or "").split("?")[0].strip()
        parts = [
            "restrictToRequestBBOX='1'",
            f"srsname='{crs_authid}'",
            f"typename='{layer_name}'",
            f"url='{url_clean}'"
        ]

        creds = cls.get_credentials(url=url_clean, server_name=server_name)
        if creds:
            authcfg = creds.get("authcfg", "").strip()
            user = creds.get("username", "").strip()
            pw = creds.get("password", "")
            if authcfg:
                parts.append(f"authcfg='{authcfg}'")
            if user:
                safe_user = user.replace("'", "\\'")
                safe_pw = pw.replace("'", "\\'")
                parts.append(f"user='{safe_user}'")
                parts.append(f"password='{safe_pw}'")

        return " ".join(parts)

    @classmethod
    def prepare_network_request(cls, req_url, raw_url=None, server_name=None, override_creds=None):
        creds = override_creds if override_creds is not None else cls.get_credentials(url=raw_url or req_url, server_name=server_name)
        qurl = QUrl(req_url)

        authcfg = ""
        if creds:
            user = creds.get("username", "").strip()
            pw = creds.get("password", "")
            authcfg = creds.get("authcfg", "").strip()
            if user:
                # Setting credentials on QUrl allows Qt QNetworkAccessManager to handle 401 Basic, Digest & NTLM domain challenges
                qurl.setUserName(user)
                qurl.setPassword(pw)

        net_req = QNetworkRequest(qurl)
        if creds and creds.get("username"):
            user = creds.get("username", "").strip()
            pw = creds.get("password", "")
            token = base64.b64encode(f"{user}:{pw}".encode("utf-8")).decode("ascii")
            net_req.setRawHeader(b"Authorization", f"Basic {token}".encode("ascii"))

        return net_req, authcfg


class WfsServerSettingsDialog(QDialog):
    """Unified dialog for adding/editing a WFS server and configuring domain/basic authentication."""

    def __init__(self, server_name="", server_url="", is_new=False, parent=None):
        super().__init__(parent)
        self.is_new = is_new
        self.original_name = WfsAuthManager.clean_server_label(server_name)
        self.setWindowTitle(tr("Add Custom WFS Server") if is_new else tr("WFS Server Settings & Authentication"))
        self.resize(480, 410)
        ThemeManager.apply_dialog_theme(self)

        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(10)

        # --- Server Configuration Group ---
        srv_group = QGroupBox(tr("Server Configuration"))
        srv_form = QFormLayout(srv_group)
        srv_form.setSpacing(8)

        self.in_name = QLineEdit(self.original_name or ("Custom WFS" if is_new else ""))
        self.in_name.setPlaceholderText(tr("e.g. EELIS (Internal)"))
        srv_form.addRow(QLabel(tr("Display Name:")), self.in_name)

        self.in_url = QLineEdit(server_url or "")
        self.in_url.setPlaceholderText(tr("https://example.com/geoserver/wfs"))
        srv_form.addRow(QLabel(tr("WFS Endpoint URL:")), self.in_url)

        main_layout.addWidget(srv_group)

        # --- Authentication Group ---
        auth_group = QGroupBox(tr("Domain / Basic Authentication"))
        auth_layout = QVBoxLayout(auth_group)
        auth_layout.setSpacing(8)

        self.cb_use_auth = QCheckBox(tr("Use credentials for this server (e.g. previous domain login)"))
        auth_layout.addWidget(self.cb_use_auth)

        auth_form = QFormLayout()
        auth_form.setSpacing(8)

        self.in_user = QLineEdit()
        self.in_user.setPlaceholderText(tr("e.g. OLD_DOMAIN\\username or username"))
        auth_form.addRow(QLabel(tr("Username:")), self.in_user)

        pw_row = QHBoxLayout()
        self.in_pass = QLineEdit()
        self.in_pass.setEchoMode(QLINEEDIT_PASSWORD)
        self.in_pass.setPlaceholderText(tr("Enter password"))
        self.btn_toggle_pw = QPushButton(tr("Show"))
        self.btn_toggle_pw.setCheckable(True)
        self.btn_toggle_pw.setFixedWidth(68)
        self.btn_toggle_pw.toggled.connect(self._toggle_password_echo)
        pw_row.addWidget(self.in_pass, stretch=1)
        pw_row.addWidget(self.btn_toggle_pw)
        auth_form.addRow(QLabel(tr("Password:")), pw_row)

        self.in_authcfg = QLineEdit()
        self.in_authcfg.setPlaceholderText(tr("Optional 7-char QGIS authcfg ID"))
        auth_form.addRow(QLabel(tr("QGIS Auth Config ID (Optional):")), self.in_authcfg)

        auth_layout.addLayout(auth_form)

        self.cb_domain_wide = QCheckBox(tr("Apply credentials to all WFS services on the same domain/host"))
        self.cb_domain_wide.setChecked(True)
        auth_layout.addWidget(self.cb_domain_wide)

        # Action row: Test Connection & Clear Credentials
        act_row = QHBoxLayout()
        self.btn_test = QPushButton(tr("🔌 Test Connection"))
        self.btn_test.clicked.connect(self._test_connection)
        self.btn_clear_creds = QPushButton(tr("🧹 Clear Credentials"))
        self.btn_clear_creds.clicked.connect(self._clear_credentials)
        act_row.addWidget(self.btn_test)
        act_row.addWidget(self.btn_clear_creds)
        act_row.addStretch()
        auth_layout.addLayout(act_row)

        self.lbl_status = QLabel("")
        self.lbl_status.setWordWrap(True)
        auth_layout.addWidget(self.lbl_status)

        main_layout.addWidget(auth_group)

        # --- Pre-fill Existing Credentials ---
        existing = WfsAuthManager.get_credentials(url=server_url, server_name=self.original_name)
        if existing:
            self.cb_use_auth.setChecked(True)
            self.in_user.setText(existing.get("username", ""))
            self.in_pass.setText(existing.get("password", ""))
            self.in_authcfg.setText(existing.get("authcfg", ""))
            self.cb_domain_wide.setChecked(existing.get("apply_to_domain", True))
        else:
            self.cb_use_auth.setChecked(not is_new)

        self.cb_use_auth.toggled.connect(self._update_auth_enabled)
        self._update_auth_enabled(self.cb_use_auth.isChecked())

        # --- Dialog Buttons ---
        btns = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        btns.accepted.connect(self._validate_and_accept)
        btns.rejected.connect(self.reject)
        main_layout.addWidget(btns)

    def _toggle_password_echo(self, checked):
        self.in_pass.setEchoMode(QLINEEDIT_NORMAL if checked else QLINEEDIT_PASSWORD)
        self.btn_toggle_pw.setText(tr("Hide") if checked else tr("Show"))

    def _update_auth_enabled(self, enabled):
        self.in_user.setEnabled(enabled)
        self.in_pass.setEnabled(enabled)
        self.btn_toggle_pw.setEnabled(enabled)
        self.in_authcfg.setEnabled(enabled)
        self.cb_domain_wide.setEnabled(enabled)

    def _get_override_creds(self):
        if not self.cb_use_auth.isChecked():
            return {}
        return {
            "username": self.in_user.text().strip(),
            "password": self.in_pass.text(),
            "authcfg": self.in_authcfg.text().strip(),
            "apply_to_domain": self.cb_domain_wide.isChecked(),
        }

    def _clear_credentials(self):
        self.in_user.clear()
        self.in_pass.clear()
        self.in_authcfg.clear()
        self.cb_use_auth.setChecked(False)
        WfsAuthManager.clear_credentials(self.original_name, self.in_url.text().strip())
        c = ThemeManager.colors()
        self.lbl_status.setStyleSheet(f"color: {c['text_muted']}; font-weight: 600;")
        self.lbl_status.setText(tr("Credentials cleared."))

    def _test_connection(self):
        from .geosearch_logic import WfsCatalogParser

        url = self.in_url.text().strip()
        if not url:
            QMessageBox.warning(self, tr("Invalid Input"), tr("Please provide both a display name and a valid WFS URL."))
            return

        c = ThemeManager.colors()
        self.lbl_status.setStyleSheet(f"color: {c['text_muted']};")
        self.lbl_status.setText(tr("Testing connection..."))
        QApplication.processEvents()

        try:
            QApplication.setOverrideCursor(QT_WAIT_CURSOR)
            override_creds = self._get_override_creds()
            ok, layers, err = WfsCatalogParser.fetch_layers(url, override_creds=override_creds)
        finally:
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                pass

        if ok:
            self.lbl_status.setStyleSheet(f"color: {c['accent_success']}; font-weight: 600;")
            self.lbl_status.setText(tr("✅ Connection successful! Found {count} layers.", count=len(layers)))
        else:
            self.lbl_status.setStyleSheet(f"color: {c['accent_danger']}; font-weight: 600;")
            self.lbl_status.setText(tr("❌ Connection failed: {error}", error=err))

    def _validate_and_accept(self):
        if not self.in_name.text().strip() or not self.in_url.text().strip():
            QMessageBox.warning(self, tr("Invalid Input"), tr("Please provide both a display name and a valid WFS URL."))
            return
        self.accept()

    def get_result(self):
        return {
            "name": WfsAuthManager.clean_server_label(self.in_name.text().strip()),
            "url": self.in_url.text().strip(),
            "use_auth": self.cb_use_auth.isChecked(),
            "username": self.in_user.text().strip() if self.cb_use_auth.isChecked() else "",
            "password": self.in_pass.text() if self.cb_use_auth.isChecked() else "",
            "authcfg": self.in_authcfg.text().strip() if self.cb_use_auth.isChecked() else "",
            "apply_to_domain": self.cb_domain_wide.isChecked(),
        }


class WfsManager:
    def __init__(self, dock):
        self.dock = dock
        self.active_tasks = []

    def prompt_add_wfs(self):
        dlg = WfsServerSettingsDialog(is_new=True, parent=self.dock)
        if dlg.exec() if hasattr(dlg, "exec") else dlg.exec_():
            res = dlg.get_result()
            name = res["name"]
            url = res["url"]
            self.save_wfs_server(name, url)
            if res["use_auth"] and (res["username"] or res["password"] or res["authcfg"]):
                WfsAuthManager.save_credentials(
                    name, url, res["username"], res["password"],
                    res["authcfg"], res["apply_to_domain"]
                )
            self.fetch_wfs_server(name, url)

    def open_server_settings(self, item):
        if not item:
            return
        data = item.data(0, QT_USER_ROLE) or {}
        old_name = WfsAuthManager.clean_server_label(data.get("name") or item.text(0))
        old_url = data.get("uri", "")

        dlg = WfsServerSettingsDialog(server_name=old_name, server_url=old_url, is_new=False, parent=self.dock)
        if dlg.exec() if hasattr(dlg, "exec") else dlg.exec_():
            res = dlg.get_result()
            new_name = res["name"]
            new_url = res["url"]

            settings = QgsSettings()
            servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
            if old_name in servers and new_name != old_name:
                del servers[old_name]
                WfsAuthManager.rename_server_credentials(old_name, new_name)
            servers[new_name] = new_url
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))

            if res["use_auth"] and (res["username"] or res["password"] or res["authcfg"]):
                WfsAuthManager.save_credentials(
                    new_name, new_url, res["username"], res["password"],
                    res["authcfg"], res["apply_to_domain"]
                )
            else:
                WfsAuthManager.clear_credentials(new_name, new_url)

            data["name"] = new_name
            data["uri"] = new_url
            item.setData(0, QT_USER_ROLE, data)
            self.fetch_wfs_server(new_name, new_url)
            self.dock.log_message(f"Updated WFS server settings for '{new_name}'.")

    def save_wfs_server(self, name, url):
        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        clean_name = WfsAuthManager.clean_server_label(name)
        servers[clean_name] = url
        settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))

    def remove_wfs_server(self, name):
        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        clean_name = WfsAuthManager.clean_server_label(name)
        if clean_name in servers:
            url = servers.pop(clean_name)
            WfsAuthManager.clear_credentials(clean_name, url)
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))
            return True
        return False

    def rename_wfs_server(self, old_name, new_name):
        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))
        clean_old = WfsAuthManager.clean_server_label(old_name)
        new_name_clean = WfsAuthManager.clean_server_label(new_name)

        if clean_old in servers and new_name_clean and new_name_clean not in servers:
            url = servers.pop(clean_old)
            servers[new_name_clean] = url
            WfsAuthManager.rename_server_credentials(clean_old, new_name_clean)
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))
            return True
        return False

    def _format_server_display_name(self, server_name, url, status=None):
        clean = WfsAuthManager.clean_server_label(server_name)
        prefix = "🔒 " if WfsAuthManager.has_credentials(url=url, server_name=clean) else ""
        if status:
            return f"{prefix}{clean} [{status}]"
        return f"{prefix}{clean}"

    def load_all_wfs_catalogs(self):
        from .geosearch_logic import WfsCatalogFetchTask  # local import to avoid circular dependency

        self.dock.global_root_wfs.takeChildren()

        item_add1 = QTreeWidgetItem(self.dock.global_root_wfs, [tr("➕ Add Custom WFS Server...")])
        item_add1.setData(0, QT_USER_ROLE, {"type": "add_custom_wfs"})

        settings = QgsSettings()
        servers = json.loads(settings.value("spatial_pivot/wfs_servers", "{}"))

        needs_save = False
        if "Estonian Topo (ETA)" in servers:
            del servers["Estonian Topo (ETA)"]
            needs_save = True

        for k, v in list(servers.items()):
            if "geoserver/eta/wfs" in v:
                del servers[k]
                needs_save = True

        if needs_save:
            settings.setValue("spatial_pivot/wfs_servers", json.dumps(servers))

        if not servers:
            servers = {
                "EELIS (Public)": "https://gsavalik.envir.ee/geoserver/eelis/ows",
                "EELIS (Internal)": "https://gsa.envir.ee/geoserver/eelis/wfs",
                "Maa-amet Kataster": "https://gsavalik.envir.ee/geoserver/kataster/wfs",
                "PRIA (Public)": "https://kls.pria.ee/geoserver/pria_avalik/wfs",
                "Estonian Topo (ETAK)": "https://gsavalik.envir.ee/geoserver/etak/wfs"
            }
            for name, url in servers.items():
                self.save_wfs_server(name, url)

        for name, url in servers.items():
            self.fetch_wfs_server(name, url)

    def force_refresh_wfs(self):
        self.load_all_wfs_catalogs()
        self.dock.log_message("Forced WFS catalog refresh.")

    def fetch_wfs_server(self, server_name, url):
        from .geosearch_logic import WfsCatalogFetchTask

        clean_name = WfsAuthManager.clean_server_label(server_name)
        node1 = None
        for i in range(self.dock.global_root_wfs.childCount()):
            child = self.dock.global_root_wfs.child(i)
            c_data = child.data(0, QT_USER_ROLE) or {}
            if c_data.get("type") == "wfs_server" and WfsAuthManager.clean_server_label(c_data.get("name", "")) == clean_name:
                node1 = child
                break

        loading_label = self._format_server_display_name(clean_name, url, tr("Loading..."))
        if not node1:
            node1 = QTreeWidgetItem(self.dock.global_root_wfs, [loading_label])
            node1.setData(0, QT_USER_ROLE, {"type": "wfs_server", "uri": url, "name": clean_name})
        else:
            node1.setText(0, loading_label)
            node1.setData(0, QT_USER_ROLE, {"type": "wfs_server", "uri": url, "name": clean_name})
            node1.takeChildren()

        task = WfsCatalogFetchTask(f"Fetching WFS: {clean_name}", url, node1, None, self.on_wfs_fetched, server_name=clean_name)
        self.active_tasks.append(task)
        QgsApplication.taskManager().addTask(task)

    def on_wfs_fetched(self, layers, error_msg, n1, n2=None):
        try:
            data = n1.data(0, QT_USER_ROLE) or {}
        except RuntimeError:
            return
        s_name = WfsAuthManager.clean_server_label(data.get("name", ""))
        url = data.get("uri", "")

        if error_msg:
            is_auth_err = any(k in error_msg.lower() for k in ("401", "403", "unauthorized", "authentication", "forbidden", "login"))
            status_tag = tr("Auth Required") if is_auth_err else tr("Failed")
            n1.setText(0, self._format_server_display_name(s_name, url, status_tag))
            n1.setToolTip(0, f"{error_msg}\n\nRight-click -> {tr('🔑 Authenticate / Server Settings...')}")
            self.dock.log_message(f"WFS fetch failed for '{s_name}': {error_msg}", True)
            return

        n1.setText(0, self._format_server_display_name(s_name, url))
        n1.setToolTip(0, url)

        for lyr_name in layers:
            c1 = QTreeWidgetItem(n1, [lyr_name])
            c1.setData(0, QT_USER_ROLE, {"type": "wfs", "uri": url, "name": lyr_name, "server_name": s_name})
            c1.setToolTip(0, lyr_name)
