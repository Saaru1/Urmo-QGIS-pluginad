import re
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QSplitter, QListWidget, QListWidgetItem,
    QTableWidget, QAbstractItemView, QHeaderView, QMenu
)
from qgis.PyQt.QtCore import Qt, pyqtSignal

from .compat import (
    QT_HORIZONTAL, QT_USER_ROLE, QT_CUSTOM_CONTEXT_MENU,
    QT_ITEM_IS_EDITABLE, QT_KEY_DELETE, QT_KEY_BACKSPACE,
    QT_DRAG_DROP, QT_EXTENDED_SELECTION, QT_MOVE_ACTION, QT_HEADER_STRETCH
)
from .i18n import tr


class TimelineDropList(QListWidget):
    """A chronological pillar that auto-sorts dropped layers by year."""
    layers_updated = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setDragEnabled(True)

        self.setContextMenuPolicy(QT_CUSTOM_CONTEXT_MENU)
        self.customContextMenuRequested.connect(self.show_context_menu)

        self.setDragDropMode(QT_DRAG_DROP)
        self.setSelectionMode(QT_EXTENDED_SELECTION)
        self.setAlternatingRowColors(True)

    def show_context_menu(self, pos):
        item = self.itemAt(pos)
        if not item:
            return
        menu = QMenu(self)
        remove_action = menu.addAction(tr("❌ Remove Layer"))

        action = menu.exec(self.mapToGlobal(pos)) if hasattr(menu, 'exec') else menu.exec_(self.mapToGlobal(pos))

        if action == remove_action:
            self.takeItem(self.row(item))
            self._update_timeline_visuals()
            self.layers_updated.emit()

    def keyPressEvent(self, event):
        if event.key() in (QT_KEY_DELETE, QT_KEY_BACKSPACE):
            for item in self.selectedItems():
                self.takeItem(self.row(item))
            self._update_timeline_visuals()
            self.layers_updated.emit()
        else:
            super().keyPressEvent(event)

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat('application/x-qabstractitemmodeldatalist') or event.mimeData().hasText():
            event.accept()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat('application/x-qabstractitemmodeldatalist') or event.mimeData().hasText():
            event.accept()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        source = event.source()

        if source == self:
            event.setDropAction(QT_MOVE_ACTION)
            super().dropEvent(event)
            self._auto_sort_chronologically()
            self._update_timeline_visuals()
            self.layers_updated.emit()
            return

        if hasattr(source, 'selectedItems'):
            items = source.selectedItems()
            for tree_item in items:
                data = tree_item.data(0, QT_USER_ROLE)

                if not data or data.get("type") in ["add_custom_wfs", "local_parent", "wfs_server"]:
                    continue

                name = tree_item.text(0)

                exists = False
                for i in range(self.count()):
                    clean_text = self.item(i).text().replace("🟢 [BASE] ", "").replace("🔵 ", "")
                    if clean_text == name:
                        exists = True
                        break

                if not exists:
                    new_item = QListWidgetItem(name)
                    new_item.setData(QT_USER_ROLE, data)
                    new_item.setFlags(new_item.flags() | QT_ITEM_IS_EDITABLE)
                    self.addItem(new_item)

            self._auto_sort_chronologically()
            self._update_timeline_visuals()
            self.layers_updated.emit()
            event.accept()
            return

        super().dropEvent(event)

    def _auto_sort_chronologically(self):
        items = []
        for _ in range(self.count()):
            item = self.takeItem(0)
            match = re.search(r'(19|20)\d{2}', item.text())
            year = int(match.group()) if match else 9999
            items.append((year, item))

        items.sort(key=lambda x: x[0])

        for _, item in items:
            self.addItem(item)

    def _update_timeline_visuals(self):
        count = self.count()
        for i in range(count):
            item = self.item(i)
            clean_text = item.text().replace('🟢 [BASE] ', '').replace('🔵 ', '')
            if i == 0:
                item.setText(f"🟢 [BASE] {clean_text}")
            else:
                item.setText(f"🔵 {clean_text}")


class TemporalUIBuilder:
    @staticmethod
    def build(dock):
        dock.tab_temporal = QWidget()
        layout = QVBoxLayout(dock.tab_temporal)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        top_bar = QHBoxLayout()
        dock.lbl_temporal_intro = QLabel(
            tr("<b>Temporal Time-Series Analysis</b><br><i>Drag layers into timeline. <b>Double-click timeline items to rename them. Press Delete to remove.</b></i>")
        )
        top_bar.addWidget(dock.lbl_temporal_intro)
        top_bar.addStretch()
        dock.clear_temporal_btn = QPushButton(tr("Clear Timeline"))
        top_bar.addWidget(dock.clear_temporal_btn)
        layout.addLayout(top_bar)

        splitter = QSplitter(QT_HORIZONTAL)

        pillar_panel = QWidget()
        p_layout = QVBoxLayout(pillar_panel)
        p_layout.setContentsMargins(0, 0, 0, 0)

        dock.lbl_temporal_pillar = QLabel(tr("<b>Chronological Pillar</b> (Oldest to Newest)"))
        p_layout.addWidget(dock.lbl_temporal_pillar)
        dock.timeline_list = TimelineDropList()
        p_layout.addWidget(dock.timeline_list)

        dock.lbl_temporal_help = QLabel(
            tr("<small><i>Drag layers from the Universal Data Catalog. Double-click names to edit. Press Delete to remove.</i></small>")
        )
        dock.lbl_temporal_help.setWordWrap(True)
        dock.lbl_temporal_help.setProperty("role", "muted")
        p_layout.addWidget(dock.lbl_temporal_help)

        splitter.addWidget(pillar_panel)

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)

        dock.lbl_temporal_schema = QLabel(tr("<b>Schema Auto-Mapper</b>"))
        right_layout.addWidget(dock.lbl_temporal_schema)

        dock.schema_table = QTableWidget()
        dock.schema_table.setColumnCount(0)
        dock.schema_table.setRowCount(0)
        dock.schema_table.horizontalHeader().setSectionResizeMode(QT_HEADER_STRETCH)

        right_layout.addWidget(dock.schema_table)

        btn_layout = QHBoxLayout()
        dock.auto_match_btn = QPushButton(tr("Auto-Match Schema"))
        dock.auto_match_btn.setToolTip(tr("Uses fuzzy-matching to link columns across time"))
        dock.auto_match_btn.setEnabled(False)

        dock.generate_chart_btn = QPushButton(tr("📊 Generate Temporal Dashboard"))
        dock.generate_chart_btn.setProperty("btnRole", "primary")
        dock.generate_chart_btn.setEnabled(False)

        btn_layout.addWidget(dock.auto_match_btn)
        btn_layout.addWidget(dock.generate_chart_btn, stretch=1)
        right_layout.addLayout(btn_layout)

        splitter.addWidget(right_panel)

        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        layout.addWidget(splitter)
        dock.tabs.addTab(dock.tab_temporal, tr("Temporal Analysis"))
