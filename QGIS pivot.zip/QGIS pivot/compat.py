from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QTreeWidgetItem, QStyle, QDialogButtonBox,
    QMessageBox, QLineEdit, QHeaderView, QSizePolicy, QDockWidget
)
from qgis.PyQt.QtCore import Qt, QEvent
from qgis.PyQt.QtGui import QKeySequence, QPalette
from qgis.PyQt.QtPrintSupport import QPrinter
from qgis.core import QgsWkbTypes, QgsVectorFileWriter, QgsTask, QgsLayoutTable, QgsLayoutMultiFrame, QgsRenderContext

# --- QGIS 3 (PyQt5) / QGIS 4 (PyQt6) Universal Enum Translator ---
try:
    # PyQt6 / QGIS 4
    from qgis.PyQt.QtGui import QPageSize

    QT_HORIZONTAL = Qt.Orientation.Horizontal
    QT_VERTICAL = Qt.Orientation.Vertical
    QT_USER_ROLE = int(Qt.ItemDataRole.UserRole)
    QT_DISPLAY_ROLE = Qt.ItemDataRole.DisplayRole
    QT_TOOLTIP_ROLE = Qt.ItemDataRole.ToolTipRole
    QT_BACKGROUND_ROLE = Qt.ItemDataRole.BackgroundRole
    QT_FOREGROUND_ROLE = Qt.ItemDataRole.ForegroundRole
    QT_FONT_ROLE = Qt.ItemDataRole.FontRole
    QT_TEXT_ALIGNMENT_ROLE = Qt.ItemDataRole.TextAlignmentRole

    QT_WINDOW_MODAL = Qt.WindowModality.WindowModal
    QT_APPLICATION_MODAL = Qt.WindowModality.ApplicationModal
    QT_WAIT_CURSOR = Qt.CursorShape.WaitCursor
    QT_POINTING_HAND_CURSOR = Qt.CursorShape.PointingHandCursor

    QT_EXTENDED_SELECTION = QAbstractItemView.SelectionMode.ExtendedSelection
    QT_SINGLE_SELECTION = QAbstractItemView.SelectionMode.SingleSelection
    QT_SELECT_ROWS = QAbstractItemView.SelectionBehavior.SelectRows
    QT_DRAG_DROP = QAbstractItemView.DragDropMode.DragDrop
    QT_DRAG_ONLY = QAbstractItemView.DragDropMode.DragOnly
    QT_SHOW_INDICATOR = QTreeWidgetItem.ChildIndicatorPolicy.ShowIndicator

    QT_LEFT_BUTTON = Qt.MouseButton.LeftButton
    QT_RIGHT_BUTTON = Qt.MouseButton.RightButton
    QT_ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    QT_ALIGN_LEFT = Qt.AlignmentFlag.AlignLeft
    QT_ALIGN_RIGHT = Qt.AlignmentFlag.AlignRight
    QT_ALIGN_VCENTER = Qt.AlignmentFlag.AlignVCenter
    QT_KEY_DELETE = Qt.Key.Key_Delete
    QT_KEY_BACKSPACE = Qt.Key.Key_Backspace
    QT_CUSTOM_CONTEXT_MENU = Qt.ContextMenuPolicy.CustomContextMenu
    QT_MATCH_EXACTLY = Qt.MatchFlag.MatchExactly

    QT_COPY_ACTION = Qt.DropAction.CopyAction
    QT_MOVE_ACTION = Qt.DropAction.MoveAction
    QT_CHECKED = Qt.CheckState.Checked
    QT_UNCHECKED = Qt.CheckState.Unchecked

    QSTYLE_STATE_MOUSEOVER = QStyle.StateFlag.State_MouseOver
    QSTYLE_CE_ITEMVIEWITEM = QStyle.ControlElement.CE_ItemViewItem
    QEVENT_MOUSEBUTTONRELEASE = QEvent.Type.MouseButtonRelease
    QEVENT_KEYPRESS = QEvent.Type.KeyPress
    QEVENT_PALETTE_CHANGE = QEvent.Type.PaletteChange
    QKEYSEQUENCE_COPY = QKeySequence.StandardKey.Copy

    QGS_WKB_POLYGON = QgsWkbTypes.GeometryType.PolygonGeometry
    QGS_WKB_LINE = QgsWkbTypes.GeometryType.LineGeometry
    QGS_WKB_POINT = QgsWkbTypes.GeometryType.PointGeometry

    QGS_ACTION_OVERWRITE_FILE = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile
    QGS_ACTION_OVERWRITE_LAYER = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer

    QDIALOG_BTN_OK = QDialogButtonBox.StandardButton.Ok
    QDIALOG_BTN_CANCEL = QDialogButtonBox.StandardButton.Cancel
    QDIALOG_BTN_SAVE = QDialogButtonBox.StandardButton.Save

    QGS_TASK_CANCEL = QgsTask.Flag.CanCancel

    QMESSAGEBOX_YES = QMessageBox.StandardButton.Yes
    QMESSAGEBOX_NO = QMessageBox.StandardButton.No

    QLINEEDIT_NORMAL = QLineEdit.EchoMode.Normal
    QLINEEDIT_PASSWORD = QLineEdit.EchoMode.Password
    QT_ITEM_IS_EDITABLE = Qt.ItemFlag.ItemIsEditable

    QT_HEADER_STRETCH = QHeaderView.ResizeMode.Stretch
    QT_HEADER_INTERACTIVE = QHeaderView.ResizeMode.Interactive
    QT_HEADER_RESIZE_TO_CONTENTS = QHeaderView.ResizeMode.ResizeToContents

    QSIZEPOLICY_EXPANDING = QSizePolicy.Policy.Expanding
    QSIZEPOLICY_PREFERRED = QSizePolicy.Policy.Preferred
    QSIZEPOLICY_FIXED = QSizePolicy.Policy.Fixed
    QSIZEPOLICY_IGNORED = QSizePolicy.Policy.Ignored

    QT_BOTTOM_DOCK_WIDGET_AREA = Qt.DockWidgetArea.BottomDockWidgetArea
    QT_TOP_DOCK_WIDGET_AREA = Qt.DockWidgetArea.TopDockWidgetArea
    QT_LEFT_DOCK_WIDGET_AREA = Qt.DockWidgetArea.LeftDockWidgetArea
    QT_RIGHT_DOCK_WIDGET_AREA = Qt.DockWidgetArea.RightDockWidgetArea
    QT_ALL_DOCK_WIDGET_AREAS = Qt.DockWidgetArea.AllDockWidgetAreas

    QDOCKWIDGET_CLOSABLE = QDockWidget.DockWidgetFeature.DockWidgetClosable
    QDOCKWIDGET_MOVABLE = QDockWidget.DockWidgetFeature.DockWidgetMovable
    QDOCKWIDGET_FLOATABLE = QDockWidget.DockWidgetFeature.DockWidgetFloatable

    QPALETTE_WINDOW = QPalette.ColorRole.Window
    QPALETTE_WINDOW_TEXT = QPalette.ColorRole.WindowText
    QPALETTE_BASE = QPalette.ColorRole.Base
    QPALETTE_ALTERNATE_BASE = QPalette.ColorRole.AlternateBase
    QPALETTE_TEXT = QPalette.ColorRole.Text
    QPALETTE_BUTTON = QPalette.ColorRole.Button
    QPALETTE_BUTTON_TEXT = QPalette.ColorRole.ButtonText
    QPALETTE_HIGHLIGHT = QPalette.ColorRole.Highlight
    QPALETTE_HIGHLIGHTED_TEXT = QPalette.ColorRole.HighlightedText

    # Print & Layout Enums
    QPRINTER_HIGH_RES = QPrinter.PrinterMode.HighResolution
    QPRINTER_PDF_FORMAT = QPrinter.OutputFormat.PdfFormat
    QPRINTER_A4 = QPageSize(QPageSize.PageSizeId.A4)
    QGSLAYOUTTABLE_ALLFRAMES = QgsLayoutTable.HeaderMode.AllFrames
    QGSLAYOUTMULTIFRAME_USEEXISTINGFRAMES = QgsLayoutMultiFrame.ResizeMode.UseExistingFrames
    QGSRENDERCONTEXT_TEXTFORMATALWAYSTEXT = QgsRenderContext.TextRenderFormat.TextFormatAlwaysText

except AttributeError:
    # PyQt5 / QGIS 3
    QT_HORIZONTAL = Qt.Horizontal
    QT_VERTICAL = Qt.Vertical
    QT_USER_ROLE = int(Qt.UserRole)
    QT_DISPLAY_ROLE = Qt.DisplayRole
    QT_TOOLTIP_ROLE = Qt.ToolTipRole
    QT_BACKGROUND_ROLE = Qt.BackgroundRole
    QT_FOREGROUND_ROLE = Qt.ForegroundRole
    QT_FONT_ROLE = Qt.FontRole
    QT_TEXT_ALIGNMENT_ROLE = Qt.TextAlignmentRole

    QT_WINDOW_MODAL = Qt.WindowModal
    QT_APPLICATION_MODAL = Qt.ApplicationModal
    QT_WAIT_CURSOR = Qt.WaitCursor
    QT_POINTING_HAND_CURSOR = Qt.PointingHandCursor

    QT_EXTENDED_SELECTION = QAbstractItemView.ExtendedSelection
    QT_SINGLE_SELECTION = QAbstractItemView.SingleSelection
    QT_SELECT_ROWS = QAbstractItemView.SelectRows
    QT_DRAG_DROP = QAbstractItemView.DragDrop
    QT_DRAG_ONLY = QAbstractItemView.DragOnly
    QT_SHOW_INDICATOR = QTreeWidgetItem.ShowIndicator

    QT_LEFT_BUTTON = Qt.LeftButton
    QT_RIGHT_BUTTON = Qt.RightButton
    QT_ALIGN_CENTER = Qt.AlignCenter
    QT_ALIGN_LEFT = Qt.AlignLeft
    QT_ALIGN_RIGHT = Qt.AlignRight
    QT_ALIGN_VCENTER = Qt.AlignVCenter
    QT_KEY_DELETE = Qt.Key_Delete
    QT_KEY_BACKSPACE = Qt.Key_Backspace
    QT_CUSTOM_CONTEXT_MENU = Qt.CustomContextMenu
    QT_MATCH_EXACTLY = Qt.MatchExactly

    QT_COPY_ACTION = Qt.CopyAction
    QT_MOVE_ACTION = Qt.MoveAction
    QT_CHECKED = Qt.Checked
    QT_UNCHECKED = Qt.Unchecked

    QSTYLE_STATE_MOUSEOVER = QStyle.State_MouseOver
    QSTYLE_CE_ITEMVIEWITEM = QStyle.CE_ItemViewItem
    QEVENT_MOUSEBUTTONRELEASE = QEvent.MouseButtonRelease
    QEVENT_KEYPRESS = QEvent.KeyPress
    QEVENT_PALETTE_CHANGE = QEvent.PaletteChange
    QKEYSEQUENCE_COPY = QKeySequence.Copy

    QGS_WKB_POLYGON = QgsWkbTypes.PolygonGeometry
    QGS_WKB_LINE = QgsWkbTypes.LineGeometry
    QGS_WKB_POINT = QgsWkbTypes.PointGeometry

    QGS_ACTION_OVERWRITE_FILE = QgsVectorFileWriter.CreateOrOverwriteFile
    QGS_ACTION_OVERWRITE_LAYER = QgsVectorFileWriter.CreateOrOverwriteLayer

    QDIALOG_BTN_OK = QDialogButtonBox.Ok
    QDIALOG_BTN_CANCEL = QDialogButtonBox.Cancel
    QDIALOG_BTN_SAVE = QDialogButtonBox.Save

    QGS_TASK_CANCEL = QgsTask.CanCancel

    QMESSAGEBOX_YES = QMessageBox.Yes
    QMESSAGEBOX_NO = QMessageBox.No

    QLINEEDIT_NORMAL = QLineEdit.Normal
    QLINEEDIT_PASSWORD = QLineEdit.Password
    QT_ITEM_IS_EDITABLE = Qt.ItemIsEditable

    QT_HEADER_STRETCH = QHeaderView.Stretch
    QT_HEADER_INTERACTIVE = QHeaderView.Interactive
    QT_HEADER_RESIZE_TO_CONTENTS = QHeaderView.ResizeToContents

    QSIZEPOLICY_EXPANDING = QSizePolicy.Expanding
    QSIZEPOLICY_PREFERRED = QSizePolicy.Preferred
    QSIZEPOLICY_FIXED = QSizePolicy.Fixed
    QSIZEPOLICY_IGNORED = QSizePolicy.Ignored

    QT_BOTTOM_DOCK_WIDGET_AREA = Qt.BottomDockWidgetArea
    QT_TOP_DOCK_WIDGET_AREA = Qt.TopDockWidgetArea
    QT_LEFT_DOCK_WIDGET_AREA = Qt.LeftDockWidgetArea
    QT_RIGHT_DOCK_WIDGET_AREA = Qt.RightDockWidgetArea
    QT_ALL_DOCK_WIDGET_AREAS = Qt.AllDockWidgetAreas

    QDOCKWIDGET_CLOSABLE = QDockWidget.DockWidgetClosable
    QDOCKWIDGET_MOVABLE = QDockWidget.DockWidgetMovable
    QDOCKWIDGET_FLOATABLE = QDockWidget.DockWidgetFloatable

    QPALETTE_WINDOW = QPalette.Window
    QPALETTE_WINDOW_TEXT = QPalette.WindowText
    QPALETTE_BASE = QPalette.Base
    QPALETTE_ALTERNATE_BASE = QPalette.AlternateBase
    QPALETTE_TEXT = QPalette.Text
    QPALETTE_BUTTON = QPalette.Button
    QPALETTE_BUTTON_TEXT = QPalette.ButtonText
    QPALETTE_HIGHLIGHT = QPalette.Highlight
    QPALETTE_HIGHLIGHTED_TEXT = QPalette.HighlightedText

    # Print & Layout Enums
    QPRINTER_HIGH_RES = QPrinter.HighResolution
    QPRINTER_PDF_FORMAT = QPrinter.PdfFormat
    QPRINTER_A4 = QPrinter.A4
    QGSLAYOUTTABLE_ALLFRAMES = getattr(QgsLayoutTable, "AllFrames", 1)
    QGSLAYOUTMULTIFRAME_USEEXISTINGFRAMES = getattr(QgsLayoutMultiFrame, "UseExistingFrames", 0)
    QGSRENDERCONTEXT_TEXTFORMATALWAYSTEXT = getattr(QgsRenderContext, "TextFormatAlwaysText", 1)
