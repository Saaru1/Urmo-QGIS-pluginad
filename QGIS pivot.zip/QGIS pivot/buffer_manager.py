import json
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QComboBox,
    QToolButton, QInputDialog, QMessageBox, QListWidget,
    QLabel, QDialogButtonBox, QListWidgetItem
)
from qgis.PyQt.QtGui import QColor
from qgis.core import QgsSettings

from .compat import *
from .i18n import tr
from .theme import ThemeManager


class BufferManagerDialog(QDialog):
    def __init__(self, current_dists=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("Buffer Zone Manager"))
        self.resize(370, 420)
        ThemeManager.apply_dialog_theme(self)

        self.current_dists = current_dists or []

        self.layout = QVBoxLayout(self)

        # Profile Header
        prof_layout = QHBoxLayout()
        self.combo = QComboBox()
        self.combo.setToolTip(tr("Select a saved buffer profile"))
        self.combo.currentIndexChanged.connect(self.on_profile_selected)

        self.save_btn = QToolButton()
        self.save_btn.setText("💾")
        self.save_btn.setToolTip(tr("Save current list as a Profile"))
        self.save_btn.clicked.connect(self.save_profile)

        self.del_btn = QToolButton()
        self.del_btn.setText("❌")
        self.del_btn.setToolTip(tr("Delete selected Profile"))
        self.del_btn.clicked.connect(self.delete_profile)

        prof_layout.addWidget(QLabel(tr("Profile:")))
        prof_layout.addWidget(self.combo, stretch=1)
        prof_layout.addWidget(self.save_btn)
        prof_layout.addWidget(self.del_btn)
        self.layout.addLayout(prof_layout)

        # Inline Editable Buffer List
        self.layout.addWidget(QLabel(tr("<b>Buffer Distances (m):</b>")))
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QT_EXTENDED_SELECTION)
        self.list_widget.setToolTip(tr("Double-click an item to edit. Press Delete to remove."))
        self.layout.addWidget(self.list_widget)

        self.list_widget.itemChanged.connect(self.on_item_changed)

        self.button_box = QDialogButtonBox(QDIALOG_BTN_OK | QDIALOG_BTN_CANCEL)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.layout.addWidget(self.button_box)

        self._is_updating = False
        self.load_profiles()
        self.populate_list(self.current_dists)
        self.check_initial_profile_match()

    def load_profiles(self):
        settings = QgsSettings()
        p_str = settings.value("spatial_pivot/buffer_profiles_v2", '{"Standard (50m)": [50.0]}')
        try:
            self.profiles = json.loads(p_str)
        except Exception:
            self.profiles = {"Standard (50m)": [50.0]}

        self._is_updating = True
        self.combo.clear()
        self.combo.addItem(tr("-- Custom --"))
        self.combo.addItems(sorted(self.profiles.keys()))
        self._is_updating = False

    def check_initial_profile_match(self):
        matched = tr("-- Custom --")
        for name, dists in self.profiles.items():
            if sorted(dists) == sorted(self.current_dists):
                matched = name
                break
        self._is_updating = True
        self.combo.setCurrentText(matched)
        self._is_updating = False

    def populate_list(self, dists):
        self.list_widget.blockSignals(True)
        self.list_widget.clear()

        for d in sorted(list(set(dists))):
            if d > 0:
                item = QListWidgetItem(f"{d:g}")
                item.setFlags(item.flags() | QT_ITEM_IS_EDITABLE)
                self.list_widget.addItem(item)

        c = ThemeManager.colors()
        self.add_item = QListWidgetItem(tr("➕ Double-click to add distance..."))
        self.add_item.setForeground(QColor(c["text_muted"]))
        font = self.add_item.font()
        font.setItalic(True)
        self.add_item.setFont(font)
        self.add_item.setFlags(self.add_item.flags() | QT_ITEM_IS_EDITABLE)
        self.list_widget.addItem(self.add_item)

        self.list_widget.blockSignals(False)

    def on_item_changed(self, item):
        self.list_widget.blockSignals(True)

        new_dists = []
        for i in range(self.list_widget.count()):
            try:
                v = float(self.list_widget.item(i).text().replace(',', '.').strip())
                if v > 0:
                    new_dists.append(v)
            except ValueError:
                pass

        self.populate_list(new_dists)

        self._is_updating = True
        self.combo.setCurrentIndex(0)
        self._is_updating = False

    def get_current_list(self):
        dists = []
        for i in range(self.list_widget.count()):
            if self.list_widget.item(i) == self.add_item:
                continue
            try:
                val = float(self.list_widget.item(i).text().replace(',', '.').strip())
                if val > 0:
                    dists.append(val)
            except ValueError:
                pass
        return sorted(list(set(dists)))

    def keyPressEvent(self, event):
        if event.key() in (QT_KEY_DELETE, QT_KEY_BACKSPACE) and self.list_widget.hasFocus():
            modified = False
            for item in self.list_widget.selectedItems():
                if item != self.add_item:
                    self.list_widget.takeItem(self.list_widget.row(item))
                    modified = True
            if modified:
                self._is_updating = True
                self.combo.setCurrentIndex(0)
                self._is_updating = False
                self.populate_list(self.get_current_list())
        else:
            super().keyPressEvent(event)

    def on_profile_selected(self):
        if self._is_updating:
            return
        text = self.combo.currentText()
        if text in self.profiles:
            self.populate_list(self.profiles[text])

    def save_profile(self):
        dists = self.get_current_list()
        if not dists:
            return QMessageBox.warning(self, tr("Empty Buffers"), tr("Add at least one valid buffer distance before saving."))

        name, ok = QInputDialog.getText(self, tr("Save Buffer Profile"), tr("Profile Name:"), QLINEEDIT_NORMAL)
        if ok and name:
            self.profiles[name] = dists
            QgsSettings().setValue("spatial_pivot/buffer_profiles_v2", json.dumps(self.profiles))
            self.load_profiles()
            self._is_updating = True
            self.combo.setCurrentText(name)
            self._is_updating = False

    def delete_profile(self):
        text = self.combo.currentText()
        if text in self.profiles:
            reply = QMessageBox.question(
                self,
                tr("Delete Profile"),
                tr("Delete buffer profile '{name}'?", name=text),
                QMESSAGEBOX_YES | QMESSAGEBOX_NO
            )
            if reply == QMESSAGEBOX_YES:
                del self.profiles[text]
                QgsSettings().setValue("spatial_pivot/buffer_profiles_v2", json.dumps(self.profiles))
                self.load_profiles()
