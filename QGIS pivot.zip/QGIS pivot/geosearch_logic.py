import traceback
import xml.etree.ElementTree as ET
import pandas as pd
from qgis.core import (
    QgsTask, QgsVectorLayer, QgsFeatureRequest, QgsWkbTypes,
    QgsGeometry, QgsBlockingNetworkRequest, QgsProject,
    QgsExpression, QgsExpressionContext, QgsExpressionContextUtils,
    QgsDistanceArea, QgsCoordinateReferenceSystem, QgsCoordinateTransform
)

from .compat import *
from .wfs_manager import WfsAuthManager


class WfsCatalogParser:
    @staticmethod
    def fetch_layers(url, server_name=None, override_creds=None):
        try:
            base_url = url.split('?')[0].strip()
            req_url = f"{base_url}?SERVICE=WFS&REQUEST=GetCapabilities&VERSION=1.0.0"

            req = QgsBlockingNetworkRequest()
            net_req, authcfg = WfsAuthManager.prepare_network_request(
                req_url, raw_url=base_url, server_name=server_name, override_creds=override_creds
            )
            if authcfg:
                try:
                    req.setAuthCfg(authcfg)
                except Exception:
                    pass

            result_code = req.get(net_req, forceRefresh=True)

            if result_code != 0:
                domain = base_url.split('/')[2] if '//' in base_url else base_url
                return False, [], f"Network Error ({domain}): {req.errorMessage()}"

            content = req.reply().content().data()
            root = ET.fromstring(content)
            layers = []

            for elem in root.iter():
                if elem.tag.endswith('FeatureType'):
                    name_val = None
                    title_val = None
                    for child in elem:
                        if child.tag.endswith('Name'):
                            name_val = child.text
                        elif child.tag.endswith('Title'):
                            title_val = child.text
                    if name_val:
                        layers.append({'name': name_val, 'title': title_val if title_val else name_val})

            return True, layers, None

        except Exception:
            return False, [], f"Failed to parse WFS:\n{traceback.format_exc()}"


class WfsCatalogFetchTask(QgsTask):
    def __init__(self, description, url, n1, n2, callback, server_name=None):
        super().__init__(description, QGS_TASK_CANCEL)
        self.url = url
        self.n1 = n1
        self.n2 = n2
        self.callback = callback
        self.server_name = server_name
        self.success = False
        self.layers = []
        self.error_msg = None

    def run(self):
        self.success, parsed_layers, self.error_msg = WfsCatalogParser.fetch_layers(
            self.url, server_name=self.server_name
        )
        if self.success:
            self.layers = [layer['name'] for layer in parsed_layers]
        return True

    def finished(self, result):
        self.callback(self.layers if self.success else [], self.error_msg, self.n1, self.n2)


class WfsSchemaFetchTask(QgsTask):
    def __init__(self, description, layer_name, layer_def, list_item, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.layer_name = layer_name
        self.layer_def = layer_def
        self.list_item = list_item
        self.callback = callback
        self.fields = []
        self.success = False

    def run(self):
        l_type = self.layer_def.get("type", "wfs")
        if l_type == "wfs":
            url = self.layer_def.get("uri", "").split('?')[0]
            crs_authid = QgsProject.instance().crs().authid() or 'EPSG:3301'
            uri = WfsAuthManager.build_wfs_uri(
                url, self.layer_name, crs_authid=crs_authid,
                server_name=self.layer_def.get("server_name")
            )
            vlayer = QgsVectorLayer(uri, self.layer_name, "WFS")
        elif l_type == "canvas":
            vlayer = QgsProject.instance().mapLayer(self.layer_def.get("uri"))
        else:
            vlayer = QgsVectorLayer(self.layer_def.get("uri"), self.layer_name, "ogr")

        if vlayer and vlayer.isValid():
            self.fields = vlayer.fields().names()
            self.success = True
        return True

    def finished(self, result):
        self.callback(self.success, self.fields, self.list_item)


class GeosearchTask(QgsTask):
    def __init__(self, description, targets, aoi_geom, predicate, main_buffer_dists, custom_buffer_dists, strict_mode, callback):
        super().__init__(description, QGS_TASK_CANCEL)
        self.targets = targets
        self.aoi_geom = aoi_geom
        self.predicate = predicate
        self.main_buffer_dists = main_buffer_dists
        self.custom_buffer_dists = custom_buffer_dists
        self.strict_mode = strict_mode
        self.callback = callback
        self.df_result = None
        self.raw_geodata = []
        self.buffered_geoms = []
        self.log_messages = []
        self.exception = None

    def _buffer_metric(self, geom, dist_m, crs, transform_context):
        """Buffers geometry accurately in meters even if the project CRS is geographic."""
        if dist_m <= 0:
            return QgsGeometry(geom)
        g_copy = QgsGeometry(geom)
        if crs and crs.isValid() and crs.isGeographic():
            proj_crs = QgsCoordinateReferenceSystem("EPSG:3857")
            xform_fwd = QgsCoordinateTransform(crs, proj_crs, transform_context)
            xform_rev = QgsCoordinateTransform(proj_crs, crs, transform_context)
            try:
                g_copy.transform(xform_fwd)
                buffered = g_copy.buffer(dist_m, 36)
                buffered.transform(xform_rev)
                return buffered
            except Exception:
                pass
        return g_copy.buffer(dist_m, 36)

    def _generate_rings(self, dists, prefix, crs, transform_context):
        rings = []
        prev_dist = 0.0
        for dist in dists:
            outer = self._buffer_metric(self.aoi_geom, dist, crs, transform_context)
            inner = self._buffer_metric(self.aoi_geom, prev_dist, crs, transform_context)
            ring_geom = outer.difference(inner)
            name = f"{prefix} B: {dist:g}m"
            rings.append((name, ring_geom, dist, prefix))
            self.buffered_geoms.append((name, ring_geom, dist, prefix))
            prev_dist = dist
        return rings

    def run(self):
        try:
            data = []
            proj = QgsProject.instance()
            proj_crs = proj.crs()
            transform_context = proj.transformContext()
            crs_authid = proj_crs.authid() or 'EPSG:3301'

            da = QgsDistanceArea()
            da.setSourceCrs(proj_crs, transform_context)
            if proj_crs.isGeographic():
                da.setEllipsoid(proj.ellipsoid() or 'WGS84')
            else:
                da.setEllipsoid('NONE')

            self.main_rings = self._generate_rings(self.main_buffer_dists, "Main", proj_crs, transform_context)
            self.custom_rings = self._generate_rings(self.custom_buffer_dists, "Custom", proj_crs, transform_context)

            max_dist = 0.0
            if self.main_buffer_dists:
                max_dist = max(max_dist, self.main_buffer_dists[-1])
            if self.custom_buffer_dists:
                max_dist = max(max_dist, self.custom_buffer_dists[-1])

            for t in self.targets:
                for _, s_dist in t.get('sensitive_features', {}).items():
                    if s_dist > max_dist:
                        max_dist = s_dist

            max_search_geom = self._buffer_metric(self.aoi_geom, max_dist, proj_crs, transform_context) if max_dist > 0 else self.aoi_geom
            bbox = max_search_geom.boundingBox()

            total_layers = max(1, len(self.targets))

            dynamic_cols = []
            for b_name, _, _, _ in self.main_rings + self.custom_rings:
                dynamic_cols.extend([f"{b_name} Count", f"{b_name} Area (ha)", f"{b_name} Length (m)"])

            for idx, target in enumerate(self.targets):
                if self.isCanceled():
                    return False
                self.setProgress((idx / total_layers) * 100)

                layer_name = target['layer']
                custom_field = target.get('custom_field')
                custom_filter = target.get('custom_filter')
                sec_expr_str = target.get('secondary_expr')
                sensitive_features = target.get('sensitive_features', {})
                buffer_role = target.get('buffer_role', 'Main Only')
                l_type = target.get('type', 'wfs')

                if l_type == 'wfs':
                    wfs_url = target['url'].split('?')[0]
                    uri = WfsAuthManager.build_wfs_uri(
                        wfs_url, layer_name, crs_authid=crs_authid,
                        server_name=target.get('server_name')
                    )
                    vlayer = QgsVectorLayer(uri, layer_name, "WFS")
                elif l_type == 'canvas':
                    vlayer = proj.mapLayer(target['url'])
                else:
                    vlayer = QgsVectorLayer(target['url'], layer_name, "ogr")

                if not vlayer or not vlayer.isValid():
                    self.log_messages.append(f"[WARN] Failed to load {layer_name}. Skipping.")
                    continue

                exp = None
                context = None
                if sec_expr_str:
                    exp = QgsExpression(sec_expr_str)
                    context = QgsExpressionContext()
                    context.appendScope(QgsExpressionContextUtils.globalScope())
                    context.appendScope(QgsExpressionContextUtils.projectScope(proj))
                    context.appendScope(QgsExpressionContextUtils.layerScope(vlayer))
                    exp.prepare(context)

                request = QgsFeatureRequest().setFilterRect(bbox)
                if custom_filter:
                    request.setFilterExpression(custom_filter)

                for feature in vlayer.getFeatures(request):
                    if self.isCanceled():
                        return False
                    geom = feature.geometry()
                    if not geom or geom.isEmpty():
                        continue

                    if self.predicate == 'Intersects' and not geom.intersects(max_search_geom):
                        continue
                    elif self.predicate == 'Contains' and not max_search_geom.contains(geom):
                        continue
                    elif self.predicate == 'Within' and not max_search_geom.within(geom):
                        continue
                    elif self.predicate == 'Touches' and not geom.touches(max_search_geom):
                        continue

                    fields = feature.fields().names()
                    name_val = "N/A"
                    field_used = "Name"
                    secondary_val = "N/A"

                    if custom_field and custom_field in fields:
                        val = feature[custom_field]
                        if val:
                            name_val = str(val)
                        field_used = custom_field
                    else:
                        for n_field in ['nimi', 'name', 'nimetus', 'kood', 'objekti_id']:
                            if n_field in fields:
                                val = feature[n_field]
                                if val:
                                    name_val = str(val)
                                    field_used = n_field
                                    break

                    if sec_expr_str:
                        if exp:
                            context.setFeature(feature)
                            res = exp.evaluate(context)
                            if not exp.hasEvalError():
                                secondary_val = str(res) if res is not None else ""
                            else:
                                secondary_val = "Eval Error"
                        else:
                            secondary_val = ""

                    geom_type_enum = geom.type()
                    geom_string = "Polygon" if geom_type_enum == QGS_WKB_POLYGON else "Line" if geom_type_enum == QGS_WKB_LINE else "Point"

                    row_data = {
                        "Layer": layer_name, "Type": geom_string, "Group": name_val, "Secondary": secondary_val,
                        "Sensitive Alert": "", "Threshold (m)": 0.0,
                        "AOI Count": 0, "AOI (ha)": 0.0, "AOI Length (m)": 0.0
                    }

                    for d_col in dynamic_cols:
                        row_data[d_col] = 0.0 if "Area" in d_col or "Length" in d_col else 0

                    matched_any = False
                    is_sensitive_hit = False
                    hit_threshold = 0.0
                    sensitive_dist = sensitive_features.get(name_val)

                    match_aoi = False
                    if self.predicate == 'Intersects':
                        match_aoi = geom.intersects(self.aoi_geom)
                    elif self.predicate == 'Contains':
                        match_aoi = self.aoi_geom.contains(geom)
                    elif self.predicate == 'Within':
                        match_aoi = self.aoi_geom.within(geom)
                    elif self.predicate == 'Touches':
                        match_aoi = self.aoi_geom.touches(geom)

                    if match_aoi:
                        ix_aoi = geom.intersection(self.aoi_geom) if self.predicate == 'Intersects' else geom
                        if not ix_aoi.isEmpty():
                            matched_any = True
                            row_data["AOI Count"] = 1
                            if geom_type_enum == QGS_WKB_POLYGON:
                                area_m2 = da.measureArea(ix_aoi) if proj_crs.isGeographic() else ix_aoi.area()
                                row_data["AOI (ha)"] = area_m2 / 10000.0
                            elif geom_type_enum == QGS_WKB_LINE:
                                row_data["AOI Length (m)"] = da.measureLength(ix_aoi) if proj_crs.isGeographic() else ix_aoi.length()

                            zone_alert = "YES" if sensitive_dist is not None else ""
                            if zone_alert:
                                is_sensitive_hit = True
                                hit_threshold = float(sensitive_dist)

                            f_attrs = {field_used: name_val, "Sensitive Alert": zone_alert, "Threshold (m)": sensitive_dist if zone_alert else 0.0}
                            self.raw_geodata.append({
                                "Layer": layer_name, "Group": name_val, "Secondary": secondary_val, "Geometry": QgsGeometry(ix_aoi),
                                "Type": geom_type_enum, "Zone": "AOI", "feature_attrs": f_attrs
                            })

                    rings_to_test = []
                    if self.strict_mode:
                        if buffer_role in ['Main Only', 'Main + Custom']:
                            rings_to_test.extend(self.main_rings)
                        if buffer_role in ['Custom Only', 'Main + Custom']:
                            rings_to_test.extend(self.custom_rings)
                    else:
                        rings_to_test.extend(self.main_rings)
                        rings_to_test.extend(self.custom_rings)

                    for b_name, b_geom, b_dist, prefix in rings_to_test:
                        if self.strict_mode and prefix == "Custom":
                            if sensitive_dist is None or b_dist > sensitive_dist:
                                continue

                        match_ring = False
                        if self.predicate == 'Intersects':
                            match_ring = geom.intersects(b_geom)
                        elif self.predicate == 'Contains':
                            match_ring = b_geom.contains(geom)
                        elif self.predicate == 'Within':
                            match_ring = b_geom.within(geom)
                        elif self.predicate == 'Touches':
                            match_ring = geom.touches(b_geom)

                        if match_ring:
                            ix_ring = geom.intersection(b_geom) if self.predicate == 'Intersects' else geom
                            if not ix_ring.isEmpty():
                                matched_any = True
                                row_data[f"{b_name} Count"] = 1
                                if geom_type_enum == QGS_WKB_POLYGON:
                                    area_m2 = da.measureArea(ix_ring) if proj_crs.isGeographic() else ix_ring.area()
                                    row_data[f"{b_name} Area (ha)"] = area_m2 / 10000.0
                                elif geom_type_enum == QGS_WKB_LINE:
                                    row_data[f"{b_name} Length (m)"] = da.measureLength(ix_ring) if proj_crs.isGeographic() else ix_ring.length()

                                zone_alert = "YES" if prefix == "Custom" and (sensitive_dist is not None and b_dist <= sensitive_dist) else ""
                                if zone_alert:
                                    is_sensitive_hit = True
                                    hit_threshold = float(sensitive_dist)

                                f_attrs = {field_used: name_val, "Sensitive Alert": zone_alert, "Threshold (m)": sensitive_dist if zone_alert else 0.0}
                                self.raw_geodata.append({
                                    "Layer": layer_name, "Group": name_val, "Secondary": secondary_val, "Geometry": QgsGeometry(ix_ring),
                                    "Type": geom_type_enum, "Zone": b_name, "feature_attrs": f_attrs
                                })

                    if matched_any:
                        row_data["Sensitive Alert"] = "YES" if is_sensitive_hit else ""
                        row_data["Threshold (m)"] = hit_threshold if is_sensitive_hit else 0.0
                        data.append(row_data)

            self.setProgress(100)
            df = pd.DataFrame(data)

            cols_order = ['Layer', 'Type', 'Group', 'Secondary', 'Sensitive Alert', 'Threshold (m)', 'AOI Count', 'AOI (ha)', 'AOI Length (m)']
            for b_name, _, _, _ in self.main_rings:
                cols_order.extend([f"{b_name} Count", f"{b_name} Area (ha)", f"{b_name} Length (m)"])
            for b_name, _, _, _ in self.custom_rings:
                cols_order.extend([f"{b_name} Count", f"{b_name} Area (ha)", f"{b_name} Length (m)"])

            if not df.empty:
                for c in df.columns:
                    if c not in cols_order:
                        cols_order.append(c)

                agg_funcs = {'Sensitive Alert': 'max', 'Threshold (m)': 'max'}
                numeric_keys = [c for c in cols_order if 'Count' in c or 'Area' in c or 'Length' in c or 'AOI (ha)' in c]
                for nk in numeric_keys:
                    agg_funcs[nk] = 'sum'

                for c in list(agg_funcs.keys()):
                    if c not in df.columns:
                        df[c] = 0.0 if c not in ['Sensitive Alert', 'Threshold (m)'] else ""

                self.df_result = df.groupby(['Layer', 'Type', 'Group', 'Secondary'], as_index=False).agg(agg_funcs)
                self.df_result = self.df_result[[c for c in cols_order if c in self.df_result.columns]]

                numeric_cols = [c for c in self.df_result.columns if 'Area' in c or 'Length' in c or 'AOI (ha)' in c]
                for c in numeric_cols:
                    self.df_result[c] = pd.to_numeric(self.df_result[c], errors='coerce')
                    if not self.df_result[c].isna().all():
                        decimals = 2 if 'Area' in c or 'AOI (ha)' in c else 0
                        self.df_result[c] = self.df_result[c].round(decimals)
                    self.df_result[c] = self.df_result[c].replace(0, pd.NA)

                count_cols = [c for c in self.df_result.columns if 'Count' in c]
                for c in count_cols:
                    self.df_result[c] = self.df_result[c].replace(0, pd.NA)

                if 'Threshold (m)' in self.df_result.columns:
                    self.df_result['Threshold (m)'] = self.df_result['Threshold (m)'].replace(0.0, "")
            else:
                self.df_result = pd.DataFrame(columns=cols_order)

            if self.strict_mode and not self.df_result.empty:
                self.log_messages.append("[INFO] Strict Mode: Pruning visually empty metrics.")
                cols_to_drop = []
                protected_cols = ['Layer', 'Type', 'Group', 'Secondary', 'Sensitive Alert', 'Threshold (m)', 'AOI Count', 'AOI (ha)', 'AOI Length (m)']

                for c in self.df_result.columns:
                    if c not in protected_cols:
                        if self.df_result[c].isna().all() or (self.df_result[c] == '').all():
                            cols_to_drop.append(c)

                if cols_to_drop:
                    self.df_result.drop(columns=cols_to_drop, inplace=True, errors='ignore')
            elif self.strict_mode:
                self.log_messages.append("[INFO] Strict Mode: Report is empty, maintaining template structure.")
            else:
                self.log_messages.append("[INFO] Debug Mode: Calculating all intersections; Preserving full metric template.")

            return True
        except Exception:
            self.exception = traceback.format_exc()
            return False

    def finished(self, result):
        self.callback(self.df_result, self.raw_geodata, self.buffered_geoms, self.log_messages, self.exception)
