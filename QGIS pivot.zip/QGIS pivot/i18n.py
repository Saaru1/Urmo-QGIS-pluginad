try:
    from qgis.core import QgsSettings
except ImportError:
    QgsSettings = None


class TranslationManager:
    _lang = None
    _listeners = []

    # Complete English -> Estonian translation dictionary
    TRANSLATIONS = {
        # Plugin & Main Window
        "Spatial Pivot Dashboard": "Ruumiline Pivot Töölaud",
        "&Spatial Pivot": "&Ruumiline Pivot",
        "Plugin Initialized successfully.": "Plugin edukalt käivitatud.",

        # Top Bar & Window Controls
        " AOI Pivot Overlap: OFF": " AOI Pivot kattuvus: VÄLJAS",
        " AOI Pivot Overlap: ON ": " AOI Pivot kattuvus: SEES ",
        "LIVE view": "REAALAJA vaade",
        "Automatically recalculate pivot when map canvas extent changes": "Arvuta pivot automaatselt uuesti kaardi kuvaala muutumisel",
        "Restrict pivot calculation to the drawn AOI polygon": "Piira pivoti arvutus joonistatud huvialaga (AOI)",
        "Switch language (English / Eesti)": "Vaheta keelt (English / Eesti)",
        "Minimize panel to compact bar": "Minimeeri paneel kompaktsele ribale",
        "Expand panel": "Ava paneel täissuuruses",
        "Float / Dock panel": "Haagi paneel lahti / kinnita dokki",
        "▼ Minimize": "▼ Minimeeri",
        "▲ Expand": "▲ Ava paneel",
        "Ready": "Valmis",

        # AOI Widget & Map Tools
        "Select Feature by Click": "Vali nähtus klikiga",
        "Draw Polygon": "Joonista polügoon",
        "Draw Freehand": "Joonista vabakäega",
        "Draw Radius": "Joonista raadius",
        "Interactive Main Multi-Ring...": "Interaktiivne põhipuhvri mitmikring...",
        "Interactive Custom Multi-Ring...": "Interaktiivne kohandatud mitmikring...",
        "❌ Clear AOI": "❌ Tühjenda AOI",
        "Clear current Area of Interest": "Eemalda valitud huviala (AOI)",
        "Click Feature": "Kliki nähtusel",
        "Polygon": "Polügoon",
        "Freehand": "Vabakäsi",
        "Radius": "Raadius",
        "Main Ring": "Põhiring",
        "Custom Ring": "Kohandatud ring",
        "AOI": "AOI",
        "No Active Layer": "Aktiivne kiht puudub",
        "Please click on a vector layer in the QGIS Layers Panel first so the tool knows which layer to select from.": "Palun vali esmalt QGIS-i kihtide paneelil vektorkiht, millelt nähtust valida.",

        # Data Catalog (Left Pane)
        "<b>Data Catalog</b><br><i>Double-click to send to active tab</i>": "<b>Andmekataloog</b><br><i>Topeltklõps saadab aktiivsele vahelehele</i>",
        "Data Catalog": "Andmekataloog",
        "Double-click or drag layers to active tab": "Topeltklõpsa või lohista kihid aktiivsele vahelehele",
        "Search catalog...": "Otsi kataloogist...",
        "Force Refresh": "Värskenda kataloogi",
        "🗺️ Map Canvas": "🗺️ Kaardiaken",
        "📁 Local Files": "📁 Kohalikud failid",
        "🌐 WFS Catalog": "🌐 WFS Kataloog",
        "➕ Add Local File (.shp, .gpkg, .tab)": "➕ Lisa kohalik fail (.shp, .gpkg, .tab)",
        "Add Local File (.shp, .gpkg, .tab)": "Lisa kohalik fail (.shp, .gpkg, .tab)",
        "Add Local Vector Layer": "Lisa kohalik vektorkiht",
        "Vector Files (*.shp *.gpkg *.geojson *.tab)": "Vektorfailid (*.shp *.gpkg *.geojson *.tab)",
        "➕ Add Custom WFS Server...": "➕ Lisa kohandatud WFS server...",
        "🔢 Count Features": "🔢 Loenda nähtused",
        "❌ Remove Local File": "❌ Eemalda kohalik fail",
        "🔑 Authenticate / Server Settings...": "🔑 Autentimine / Serveri seaded...",
        "🔄 Refresh Server": "🔄 Värskenda serverit",
        "✏️ Rename WFS Server": "✏️ Nimeta WFS server ümber",
        "❌ Remove WFS Server": "❌ Eemalda WFS server",
        "Rename WFS Server": "Nimeta WFS server ümber",
        "Enter new name:": "Sisesta uus nimi:",
        "Rename Failed": "Ümbernimetamine ebaõnnestus",
        "A server with that name already exists or the name is invalid.": "Sellise nimega server on juba olemas või nimi on vigane.",
        "Confirm Deletion": "Kinnita kustutamine",
        "Are you sure you want to remove the WFS server '{name}'?": "Kas oled kindel, et soovid eemaldada WFS serveri '{name}'?",
        "Remove local file '{name}' from the catalog?": "Kas eemaldada kohalik fail '{name}' kataloogist?",
        "Are you sure you want to delete '{name}'?": "Kas oled kindel, et soovid kustutada '{name}'?",
        "Loading...": "Laadimine...",
        "Failed": "Ebaõnnestus",
        "Auth Required": "Vajab autentimist",

        # WFS Server Settings & Authentication Dialog
        "WFS Server Settings & Authentication": "WFS serveri seaded ja autentimine",
        "Add Custom WFS Server": "Lisa kohandatud WFS server",
        "Server Configuration": "Serveri seadistamine",
        "Display Name:": "Kuvatav nimi:",
        "WFS Endpoint URL:": "WFS teenuse URL:",
        "e.g. EELIS (Internal)": "nt EELIS (Sisemine)",
        "https://example.com/geoserver/wfs": "https://naide.ee/geoserver/wfs",
        "Domain / Basic Authentication": "Domeeni / Basic autentimine",
        "Use credentials for this server (e.g. previous domain login)": "Kasuta selle serveri jaoks sisselogimisandmeid (nt vana domeeni konto)",
        "Username:": "Kasutajanimi:",
        "e.g. OLD_DOMAIN\\username or username": "nt VANA_DOMEEN\\kasutaja või kasutaja",
        "Password:": "Parool:",
        "Enter password": "Sisesta parool",
        "Show": "Näita",
        "Hide": "Peida",
        "Apply credentials to all WFS services on the same domain/host": "Rakenda mandaati kõigile sama domeeni/hosti WFS teenustele",
        "QGIS Auth Config ID (Optional):": "QGIS Auth Config ID (valikuline):",
        "Optional 7-char QGIS authcfg ID": "Valikuline 7-märgiline QGIS authcfg ID",
        "🔌 Test Connection": "🔌 Testi ühendust",
        "🧹 Clear Credentials": "🧹 Puhasta mandaat",
        "Testing connection...": "Ühenduse testimine...",
        "✅ Connection successful! Found {count} layers.": "✅ Ühendus õnnestus! Leiti {count} kihti.",
        "❌ Connection failed: {error}": "❌ Ühendus ebaõnnestus: {error}",
        "Invalid Input": "Vigane sisend",
        "Please provide both a display name and a valid WFS URL.": "Palun sisesta nii kuvatav nimi kui ka kehtiv WFS URL.",
        "Credentials cleared.": "Autentimisandmed eemaldatud.",

        # Tabs
        "Pivot Setup": "Pivoti seadistus",
        "Geosearch": "Ruumiotsing",
        "Dashboard": "Tulemuste töölaud",
        "Temporal Analysis": "Aegridade analüüs",
        "Log Panel": "Logipaneel",

        # Pivot Setup Tab
        "Save Workspace": "Salvesta töölaud",
        "Load Workspace": "Laadi töölaud",
        "Clear Pivot Setup": "Tühjenda seadistus",
        "Available Fields": "Saadaolevad väljad",
        "Base Layer (1 max)": "Aluskiht (max 1)",
        "Spatial Join Layers": "Ruumilise liitmise kihid",
        "Filters": "Filtrid",
        "Rows": "Read",
        "Columns": "Veerud",
        "Values": "Väärtused",
        "Show Totals & Subtotals": "Kuva summad ja vahesummad",
        "Show 0-value Filter Items": "Kuva 0-väärtusega filtri elemendid",
        "Force items selected in Filters to appear in the table even if their calculated value is 0.": "Sunni filtris valitud väärtused tabelis kuvama ka siis, kui nende arvutatud väärtus on 0.",
        "Calculate Pivot": "▶ Arvuta Pivot",
        "Calculating...": "Arvutamine...",
        "Calculate area (ha)": "Calculate area (ha)",
        "Calculate area (ha) [Arvuta pindala (ha)]": "Arvuta pindala (ha)",
        "Missing Values": "Väärtused puuduvad",
        "Please add at least one field to the Values pillar before calculating.": "Palun lisa enne arvutamist vähemalt üks väli 'Väärtused' tulpa.",
        "Add Rows, Columns, or Values to calculate.": "Lisa arvutamiseks read, veerud või väärtused.",
        "Crunching data...": "Andmete töötlemine...",
        "Initialization Error.": "Algväärtustamise viga.",
        "Calculation aborted by user.": "Arvutus katkestati kasutaja poolt.",
        "Calculation Failed": "Arvutus ebaõnnestus",
        "Calculation Error": "Arvutuse viga",
        "A background error occurred:\n{error}": "Taustatöös tekkis viga:\n{error}",
        "Select Aggregation": "Vali agregeerimine",
        "Select aggregation function for '{field}':": "Vali välja '{field}' agregeerimisfunktsioon:",

        # Geosearch Tab
        "Clear Targets": "Tühjenda sihtkihid",
        "<b>Target Layers</b><br><i>Right-click to set Rules</i>": "<b>Sihtkihid</b><br><i>Paremklõps reeglite seadmiseks</i>",
        "Target Layers": "Sihtkihid",
        "Right-click layer to configure rules & filters": "Paremklõpsa kihil reeglite ja filtrite seadmiseks",
        "<b>Saved Search Profiles</b><br><i>Double-click or drag to unpack</i>": "<b>Salvestatud otsinguprofiilid</b><br><i>Topeltklõpsa või lohista laadimiseks</i>",
        "Saved Search Profiles": "Salvestatud otsinguprofiilid",
        "Double-click or drag profile to load": "Topeltklõpsa või lohista profiil laadimiseks",
        "Save Current as Profile": "Salvesta profiilina",
        "Import Profile JSON": "Impordi profiili JSON",
        "Export Profile JSON": "Ekspordi profiili JSON",
        "Rule:": "Reegel:",
        "Spatial rule against your AOI": "Ruumiline reegel huviala (AOI) suhtes",
        "Intersects": "Lõikub (Intersects)",
        "Contains": "Sisaldab (Contains)",
        "Within": "Asub sees (Within)",
        "Touches": "Puutub (Touches)",
        "⚙️ Main Buffers: [ 0m ]": "⚙️ Põhipuhvrid: [ 0m ]",
        "⚙️ Main Buffers: [ {vals} ]": "⚙️ Põhipuhvrid: [ {vals} ]",
        "⚙️ Custom Buffers: [ 0m ]": "⚙️ Kohandatud puhvrid: [ 0m ]",
        "⚙️ Custom Buffers: [ {vals} ]": "⚙️ Kohandatud puhvrid: [ {vals} ]",
        "Strict Profile Enforcement": "Range profiili rakendamine",
        "Enforce layer-specific buffer roles and hide completely empty buffer columns.": "Rakenda kihupõhiseid puhvrirolle ja peida täielikult tühjad puhvriveerud.",
        "▶ Run Geosearch in AOI": "▶ Käivita ruumiotsing AOI-s",
        "Searching...": "Otsimine...",
        "Set Grouping Field...": "📋 Määra grupeerimisväli...",
        "ƒx Set Secondary Expression...": "ƒx Määra täiendav avaldis...",
        "⚙️ Set Attribute Filter...": "⚙️ Määra atribuudifilter...",
        "🎯 Assign Buffer Roles...": "🎯 Määra puhvri rollid...",
        "✏️ Edit Profile Settings...": "✏️ Muuda profiili seadeid...",
        "Select Grouping Field": "Vali grupeerimisväli",
        "Secondary Expression": "Täiendav avaldis",
        "Enter QGIS Expression (e.g. \"Type\" or substr(@layer_name, 1, 3)):": "Sisesta QGIS avaldis (nt \"Type\" või substr(@layer_name, 1, 3)):",
        "Set Attribute Filter": "Määra atribuudifilter",
        "Enter SQL/CQL expression (e.g. Type = 'Residential'):": "Sisesta SQL/CQL avaldis (nt Type = 'Residential'):",

        # Buffer Role Dialog
        "Assign Buffer Role": "Määra puhvri roll",
        "Select which buffers this Target Layer should intersect:": "Vali, milliste puhvritega see sihtkiht peab lõikuma:",
        "None (AOI Only)": "Puudub (ainult AOI)",
        "Main Only": "Ainult põhipuhver",
        "Custom Only": "Ainult kohandatud puhver",
        "Main + Custom": "Põhi + Kohandatud",

        # Multi-Select & Searchable Dialogs
        "Search values...": "Otsi väärtusi...",
        "Select All": "Vali kõik",
        "Clear All": "Tühjenda valik",
        "Filter: {field}": "Filter: {field}",

        # Geometry Selection Dialog
        "WFS Geometry Types: {name}": "WFS geomeetria tüübid: {name}",
        "Select geometry types to include.<br><i>Points and Lines will be buffered into Polygons.</i>": "Vali kaasatavad geomeetria tüübid.<br><i>Punktid ja jooned puhverdatakse polügoonideks.</i>",
        "Include Polygons": "Kaasa polügoonid",
        "Include Lines": "Kaasa jooned",
        "Include Points": "Kaasa punktid",
        "Buffer (m): ": "Puhver (m): ",

        # Buffer Manager Dialog
        "Buffer Zone Manager": "Puhvertsoonide haldur",
        "Select a saved buffer profile": "Vali salvestatud puhvriprofiil",
        "Save current list as a Profile": "Salvesta praegune nimekiri profiilina",
        "Delete selected Profile": "Kustuta valitud profiil",
        "Profile:": "Profiil:",
        "<b>Buffer Distances (m):</b>": "<b>Puhvri kaugused (m):</b>",
        "Double-click an item to edit. Press Delete to remove.": "Topeltklõpsa muutmiseks. Vajuta Delete eemaldamiseks.",
        "-- Custom --": "-- Kohandatud --",
        "➕ Double-click to add distance...": "➕ Topeltklõpsa kauguse lisamiseks...",
        "Invalid Number": "Vigane number",
        "Please enter a valid positive number for the buffer distance.": "Palun sisesta puhvri kauguseks kehtiv positiivne arv.",
        "Empty Buffers": "Tühjad puhvrid",
        "Add at least one valid buffer distance before saving.": "Lisa enne salvestamist vähemalt üks kehtiv puhvri kaugus.",
        "Save Buffer Profile": "Salvesta puhvriprofiil",
        "Profile Name:": "Profiili nimi:",
        "Delete Profile": "Kustuta profiil",
        "Delete buffer profile '{name}'?": "Kas kustutada puhvriprofiil '{name}'?",

        # Profile Editor Dialog & Profile I/O
        "Edit Profile: {name}": "Muuda profiili: {name}",
        "Select a layer to edit settings": "Vali kiht seadete muutmiseks",
        "Layer: {name}": "Kiht: {name}",
        "Group Field:": "Grupeerimisväli:",
        "Filter:": "Filter:",
        "Secondary Expr:": "Täiendav avaldis:",
        "e.g., \"Category\" or substr(@layer_name, 1, 5)": "nt \"Category\" või substr(@layer_name, 1, 5)",
        "<br><b>Sensitive Features (Only used for Custom Buffers)</b>": "<br><b>Tundlikud nähtused (kasutatakse ainult kohandatud puhvrites)</b>",
        "Feature Name (e.g. Lanius collurio (punaselg-õgija))": "Nähtuse nimi (nt Lanius collurio (punaselg-õgija))",
        "➕ Add": "➕ Lisa",
        "Feature Group Name": "Nähtuse grupi nimi",
        "Sensitivity Buffer (m)": "Tundlikkuse puhver (m)",
        "❌ Remove Selected": "❌ Eemalda valitud",
        "Empty": "Tühi",
        "Add targets first.": "Lisa esmalt sihtkihid.",
        "Save Profile": "Salvesta profiil",
        "Enter profile name:": "Sisesta profiili nimi:",
        "Overwrite Profile": "Kirjuta profiil üle",
        "The profile '{name}' already exists.\n\nAre you sure you want to overwrite it?": "Profiil '{name}' on juba olemas.\n\nKas oled kindel, et soovid selle üle kirjutada?",
        "Invalid File": "Vigane fail",
        "This file does not appear to be a valid Pivot Workspace JSON.\n\nDid you accidentally select a Geosearch Profile?": "See fail ei ole kehtiv Pivoti töölaua JSON.\n\nKas valisid kogemata ruumiotsingu profiili?",
        "This file does not appear to be a valid Geosearch Profile JSON.\n\nDid you accidentally select a Pivot Workspace?": "See fail ei ole kehtiv ruumiotsingu profiili JSON.\n\nKas valisid kogemata Pivoti töölaua?",
        "Import Buffer Profile": "Impordi profiil",
        "Export Buffer Profile": "Ekspordi profiil",

        # Dashboard Tab
        "Export Data Table": "📥 Ekspordi andmetabel",
        "Export Geodata (GPKG/Map)": "🗺️ Ekspordi geoandmed (GPKG/Kaart)",
        "Generate PDF Report": "📄 Genereeri PDF aruanne",
        "👁️ Show on Canvas": "👁️ Kuva kaardil",
        "👁️ Toggle Canvas Layers": "👁️ Halda kaardikihte",
        "⇄ Transpose Matrix": "⇄ Transponeeri maatriks",
        "Flip Rows and Columns (Pivot Only)": "Vaheta read ja veerud (ainult Pivot)",
        "📊 Open Chart in Browser": "📊 Ava diagramm brauseris",
        "Generate and open an interactive chart dashboard in your web browser": "Genereeri ja ava interaktiivne diagrammide töölaud veebibrauseris",
        "Clear Dashboard": "Tühjenda töölaud",
        "🔍 Filter Dashboard Rows (type to search...)": "🔍 Filtreeri töölaua ridu (kirjuta otsimiseks...)",
        "📝 Copy Selection": "📝 Kopeeri valik",
        "Showing: All Data": "Kuvatakse: Kõik andmed",
        "Showing: {items}": "Kuvatakse: {items}",
        "Showing: Geosearch Results ({count} records)": "Kuvatakse: Ruumiotsingu tulemused ({count} kirjet)",
        "No data matched the criteria.": "Kriteeriumidele vastavaid andmeid ei leitud.",
        "PDF generation is reserved for Geosearch reports.": "PDF aruande genereerimine on mõeldud ruumiotsingu tulemustele.",
        "Export a formal PDF report of this Geosearch.": "Ekspordi selle ruumiotsingu ametlik PDF aruanne.",
        "🛑 Cancel": "🛑 Katkesta",

        # Export & Canvas Display Dialogs
        "Export Spatial Results": "Ekspordi ruumiandmete tulemused",
        "Show on Canvas": "Kuva kaardil",
        "<b>Output Destinations:</b>": "<b>Väljundi sihtkohad:</b>",
        "Save to GeoPackage (.gpkg)": "Salvesta GeoPackage faili (.gpkg)",
        "Load as Temporary Layers on Map": "Laadi kaardile ajutiste kihtidena",
        "<br><b>Include Content:</b>": "<br><b>Kaasatav sisu:</b>",
        "<b>Select layers to generate and show:</b>": "<b>Vali genereeritavad ja kuvatavad kihid:</b>",
        "⚠️ Sensitive Detections (Alerts Only)": "⚠️ Tundlikud leiud (ainult hoiatused)",
        "Query Report (Merged by Geometry Type)": "Päringu aruanne (ühendatud geomeetria tüübi järgi)",
        "Aggregated Pivot Dashboard Results": "Agregeeritud Pivoti töölaua tulemused",
        "Raw Geometries (Separate Layers)": "Toorgeomeetriad (eraldi kihtidena)",
        "Original AOI Bounding Polygon": "Algne huviala (AOI) piiripolügoon",
        "Multi-Ring Buffer Zones": "Mitmikring-puhvertsoonid",
        "<br><b>Symbology Style:</b>": "<br><b>Sümboloogia stiil:</b>",
        "Categorized": "Kategoriseeritud",
        "Uniform Color": "Ühtne värv",
        "<br>AOI Layer Name:": "<br>AOI kihi nimi:",
        "Name (Optional)": "Nimi (valikuline)",
        "Generate": "Genereeri",
        "Show Layers": "Kuva kihid",
        "Please Wait": "Palun oota",
        "Generating Spatial Data...": "Ruumiandmete genereerimine...",
        "Cancel": "Tühista",

        # Temporal Analysis Tab & Dialogs
        "<b>Temporal Time-Series Analysis</b><br><i>Drag layers into timeline. <b>Double-click timeline items to rename them. Press Delete to remove.</b></i>": "<b>Aegridade analüüs</b><br><i>Lohista kihid ajateljele. <b>Topeltklõpsa ümbernimetamiseks. Vajuta Delete eemaldamiseks.</b></i>",
        "Clear Timeline": "Tühjenda ajatelg",
        "<b>Chronological Pillar</b> (Oldest to Newest)": "<b>Kronoloogiline tulp</b> (vanimast uusimani)",
        "<small><i>Drag layers from the Universal Data Catalog. Double-click names to edit. Press Delete to remove.</i></small>": "<small><i>Lohista kihid andmekataloogist. Topeltklõpsa nime muutmiseks. Vajuta Delete eemaldamiseks.</i></small>",
        "<b>Schema Auto-Mapper</b>": "<b>Skeemi automaatvastendus</b>",
        "Auto-Match Schema": "Vastenda väljad automaatselt",
        "Uses fuzzy-matching to link columns across time": "Kasutab hägusat vastendust veergude sidumiseks läbi aja",
        "📊 Generate Temporal Dashboard": "📊 Genereeri aegridade töölaud",
        "❌ Remove Layer": "❌ Eemalda kiht",
        "Crunching Temporal Data": "Aegridade andmete töötlemine",
        "Initializing data processors...": "Andmetöötlejate käivitamine...",
        "Aborting process safely... please wait.": "Protsessi ohutu katkestamine... palun oota.",
        "Configure Temporal Dashboard": "Seadista aegridade töölaud",
        "<b>Numeric Value to Graph (Y-Axis):</b>": "<b>Graafiku arvväärtus (Y-telg):</b>",
        "<b>Select Grouping Fields (Up to 3)</b>": "<b>Vali grupeerimisväljad (kuni 3)</b>",
        "<b>Filter Specific Categories (Optional)</b>": "<b>Filtreeri kategooriaid (valikuline)</b>",
        "[Auto-Calculate Area (ha)]": "[Auto-Calculate Area (ha)]",
        "A background error occurred:\n{err}": "Taustaprotsessis tekkis tõrge:\n{err}",
        "Aggregation": "Agregeerimine",
        "Select aggregation for '{fn}':": "Vali välja '{fn}' agregeerimisviis:",
        "Showing:": "Kuvatakse:",
        "Save GeoPackage": "Salvesta GeoPackage",
        "GeoPackage (*.gpkg)": "GeoPackage (*.gpkg)",
        "Export": "Ekspordi",
        "Excel Files (*.xlsx);;CSV Files (*.csv)": "Exceli failid (*.xlsx);;CSV failid (*.csv)",
    }

    @classmethod
    def get_language(cls):
        if cls._lang is None:
            cls._lang = "en"
            if QgsSettings is not None:
                try:
                    s = QgsSettings()
                    saved = s.value("spatial_pivot/language", "")
                    if saved in ("en", "et"):
                        cls._lang = saved
                    else:
                        locale = str(s.value("locale/userLocale", "")).lower()
                        if locale.startswith("et"):
                            cls._lang = "et"
                except Exception:
                    pass
        return cls._lang

    @classmethod
    def set_language(cls, lang):
        if lang not in ("en", "et"):
            return
        cls._lang = lang
        if QgsSettings is not None:
            try:
                QgsSettings().setValue("spatial_pivot/language", lang)
            except Exception:
                pass
        for cb in list(cls._listeners):
            try:
                cb(lang)
            except Exception:
                pass

    @classmethod
    def toggle_language(cls):
        new_lang = "et" if cls.get_language() == "en" else "en"
        cls.set_language(new_lang)
        return new_lang

    @classmethod
    def add_listener(cls, callback):
        if callback not in cls._listeners:
            cls._listeners.append(callback)

    @classmethod
    def tr(cls, text, **kwargs):
        if text is None:
            return ""
        lang = cls.get_language()
        result = cls.TRANSLATIONS.get(text, text) if lang == "et" else text
        if kwargs:
            try:
                result = result.format(**kwargs)
            except Exception:
                pass
        return result


def tr(text, **kwargs):
    return TranslationManager.tr(text, **kwargs)
