# -*- coding: utf-8 -*-

def classFactory(iface):
    """Load ExactTabExporterPlugin class from file ExactTabExporter."""
    from .exact_tab_exporter import ExactTabExporterPlugin
    return ExactTabExporterPlugin(iface)