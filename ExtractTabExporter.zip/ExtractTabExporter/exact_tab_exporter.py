# -*- coding: utf-8 -*-
import os
import re
import unicodedata
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP, getcontext

# QGIS 3.x and 4.x compatible PyQt imports
from qgis.PyQt.QtCore import QSettings, Qt, QDate, QDateTime
from qgis.PyQt.QtWidgets import (QAction, QFileDialog, QDialog, QVBoxLayout, 
                                 QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                                 QCheckBox, QApplication, QMessageBox,
                                 QTableWidget, QTableWidgetItem, QHeaderView,
                                 QProgressDialog)
from qgis.PyQt.QtGui import QIcon

from qgis.core import (QgsProject, QgsVectorLayer, QgsGeometry, 
                       QgsPointXY, QgsWkbTypes, Qgis)
from osgeo import ogr, osr

# High precision for snapping
getcontext().prec = 28

# ---------------------------------------------------------------------------
# PyQt5 / PyQt6 Enum Compatibility Wrapper
# ---------------------------------------------------------------------------
try:
    WaitCursor = Qt.CursorShape.WaitCursor
    ArrowCursor = Qt.CursorShape.ArrowCursor
    CheckState_Checked = Qt.CheckState.Checked
    CheckState_Unchecked = Qt.CheckState.Unchecked
    ItemFlag_Checkable = Qt.ItemFlag.ItemIsUserCheckable
    ItemFlag_Enabled = Qt.ItemFlag.ItemIsEnabled
    UserRole = Qt.ItemDataRole.UserRole
    WindowModal = Qt.WindowModality.WindowModal
except AttributeError:
    WaitCursor = Qt.WaitCursor
    ArrowCursor = Qt.ArrowCursor
    CheckState_Checked = Qt.Checked
    CheckState_Unchecked = Qt.Unchecked
    ItemFlag_Checkable = Qt.ItemIsUserCheckable
    ItemFlag_Enabled = Qt.ItemIsEnabled
    UserRole = Qt.UserRole
    WindowModal = Qt.WindowModal


class ExportDialog(QDialog):
    """The UI Dialog for selecting layers and export settings."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("QGIS TAB Exporter")
        self.resize(550, 430)
        
        layout = QVBoxLayout()
        
        # 1. Output Folder Selection
        folder_layout = QHBoxLayout()
        self.folder_input = QLineEdit()
        self.folder_input.setReadOnly(True)
        btn_browse = QPushButton("Browse...")
        btn_browse.clicked.connect(self.browse_folder)
        
        folder_layout.addWidget(QLabel("Output Folder:"))
        folder_layout.addWidget(self.folder_input)
        folder_layout.addWidget(btn_browse)
        layout.addLayout(folder_layout)
        
        # Load last used folder
        self.settings = QSettings()
        last_dir = self.settings.value("ExactTabExporter/output_dir", "")
        self.folder_input.setText(last_dir)

        # 2. Options Checkboxes
        options_layout = QVBoxLayout()
        self.chk_overwrite = QCheckBox("Overwrite existing files with the same name")
        self.chk_overwrite.setChecked(False)
        
        self.chk_load_layers = QCheckBox("Load exported layers into QGIS after export")
        self.chk_load_layers.setChecked(True)
        
        options_layout.addWidget(self.chk_overwrite)
        options_layout.addWidget(self.chk_load_layers)
        layout.addLayout(options_layout)

        # 3. Layer Selection Table
        layout.addWidget(QLabel("Select Vector Layers to Export:"))
        self.layer_table = QTableWidget(0, 2)
        self.layer_table.setHorizontalHeaderLabels(["Layer Name", "Export Options"])
        self.layer_table.horizontalHeader().setStretchLastSection(True)
        self.layer_table.verticalHeader().setVisible(False)
        self.layer_table.setShowGrid(False)
        self.layer_table.itemChanged.connect(self.update_button_state)
        
        self.populate_layers()
        self.layer_table.resizeColumnToContents(0)
        layout.addWidget(self.layer_table)

        # 4. Action Buttons
        btn_layout = QHBoxLayout()
        self.btn_export = QPushButton("Export Selected")
        self.btn_export.setEnabled(False)
        
        self.btn_cancel = QPushButton("Cancel")
        self.btn_export.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
        
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_cancel)
        btn_layout.addWidget(self.btn_export)
        layout.addLayout(btn_layout)
        
        self.setLayout(layout)

    def browse_folder(self):
        current_dir = self.folder_input.text() or os.path.expanduser("~")
        new_dir = QFileDialog.getExistingDirectory(self, "Select Output Folder", current_dir)
        if new_dir:
            self.folder_input.setText(new_dir)
            self.settings.setValue("ExactTabExporter/output_dir", new_dir)

    def populate_layers(self):
        layers = [l for l in QgsProject.instance().mapLayers().values() if isinstance(l, QgsVectorLayer)]
        self.layer_table.setRowCount(len(layers))
        
        self.layer_table.blockSignals(True)
        for row, layer in enumerate(layers):
            item_layer = QTableWidgetItem(layer.name())
            item_layer.setFlags(ItemFlag_Enabled | ItemFlag_Checkable)
            item_layer.setCheckState(CheckState_Unchecked)
            item_layer.setData(UserRole, layer)
            self.layer_table.setItem(row, 0, item_layer)

            sel_count = layer.selectedFeatureCount()
            item_sel = QTableWidgetItem(f"Selected only ({sel_count})")
            item_sel.setFlags(ItemFlag_Enabled | ItemFlag_Checkable)
            item_sel.setCheckState(CheckState_Unchecked)
            
            if sel_count == 0:
                item_sel.setFlags(item_sel.flags() & ~ItemFlag_Enabled) 
                
            self.layer_table.setItem(row, 1, item_sel)
            
        self.layer_table.blockSignals(False)

    def update_button_state(self):
        has_checked = False
        for row in range(self.layer_table.rowCount()):
            if self.layer_table.item(row, 0).checkState() == CheckState_Checked:
                has_checked = True
                break
        self.btn_export.setEnabled(has_checked)

    def get_selected_layers(self):
        selected_data = []
        for row in range(self.layer_table.rowCount()):
            item_layer = self.layer_table.item(row, 0)
            if item_layer.checkState() == CheckState_Checked:
                layer = item_layer.data(UserRole)
                use_selected = (self.layer_table.item(row, 1).checkState() == CheckState_Checked)
                selected_data.append((layer, use_selected))
        return selected_data


class ExactTabExporterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.menu = '&QGIS TAB Exporter'
        
        self.B_XMIN, self.B_YMIN = "-503054.5255", "5371945.474"
        self.B_XMAX, self.B_YMAX = "1503054.526", "7378054.526"
        self.GRID = 0.001
        self.DEFAULT_ENCODING = 'ISO-8859-15'

    def initGui(self):
        icon_export_path = os.path.join(self.plugin_dir, 'icon_export.png')
        self.action_main = QAction(QIcon(icon_export_path), "Batch Export Exact TABs", self.iface.mainWindow())
        self.action_main.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action_main)
        self.iface.addPluginToMenu(self.menu, self.action_main)

    def unload(self):
        self.iface.removeToolBarIcon(self.action_main)
        self.iface.removePluginMenu(self.menu, self.action_main)

    def run(self):
        dialog = ExportDialog(self.iface.mainWindow())
        result = dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_()
        
        if result:
            layers_data = dialog.get_selected_layers()
            out_dir = dialog.folder_input.text()
            overwrite = dialog.chk_overwrite.isChecked()
            load_layers = dialog.chk_load_layers.isChecked()
            
            if not layers_data:
                return
                
            if not out_dir or not os.path.isdir(out_dir):
                self.iface.messageBar().pushMessage("Error", "Invalid output folder.", level=Qgis.Critical, duration=5)
                return

            self._process_exports(layers_data, out_dir, overwrite, load_layers)

    def _snap_val(self, val):
        d_val = Decimal(str(val))
        d_grid = Decimal(str(self.GRID))
        return float((d_val / d_grid).to_integral_value(rounding=ROUND_HALF_UP) * d_grid)

    def _snap_point(self, pt):
        return QgsPointXY(self._snap_val(pt.x()), self._snap_val(pt.y()))

    def _snap_geometry_safe(self, geom):
        if not geom: return geom
        flat = QgsWkbTypes.flatType(geom.wkbType())
        try:
            if flat == QgsWkbTypes.Point: return QgsGeometry.fromPointXY(self._snap_point(geom.asPoint()))
            elif flat == QgsWkbTypes.MultiPoint: return QgsGeometry.fromMultiPointXY([self._snap_point(p) for p in geom.asMultiPoint()])
            elif flat == QgsWkbTypes.LineString: return QgsGeometry.fromPolylineXY([self._snap_point(p) for p in geom.asPolyline()])
            elif flat == QgsWkbTypes.MultiLineString: return QgsGeometry.fromMultiPolylineXY([[self._snap_point(p) for p in ln] for ln in geom.asMultiPolyline()])
            elif flat == QgsWkbTypes.Polygon: return QgsGeometry.fromPolygonXY([[self._snap_point(p) for p in r] for r in geom.asPolygon()])
            elif flat == QgsWkbTypes.MultiPolygon: return QgsGeometry.fromMultiPolygonXY([[[self._snap_point(p) for p in r] for r in poly] for poly in geom.asMultiPolygon()])
        except Exception:
            return geom
        return geom

    @staticmethod
    def _can_encode(s: str, enc: str) -> bool:
        try:
            s.encode(enc)
            return True
        except UnicodeEncodeError:
            return False

    def _process_exports(self, layers_data, out_dir, overwrite, load_layers):
        QApplication.setOverrideCursor(WaitCursor)
        success_count = 0
        error_messages = []
        exported_files = [] 

        total_features = 0
        for layer, use_selected in layers_data:
            total_features += layer.selectedFeatureCount() if use_selected else layer.featureCount()

        progress = QProgressDialog("Exporting TAB files...", "Cancel", 0, total_features, self.iface.mainWindow())
        progress.setWindowTitle("TAB Export Progress")
        progress.setWindowModality(WindowModal)     
        progress.setMinimumDuration(0) 
        current_feature_idx = 0

        try:
            for layer, use_selected in layers_data:
                if progress.wasCanceled():
                    break
                    
                base_name = "".join([c for c in layer.name() if c.isalpha() or c.isdigit() or c=='_']).rstrip()
                if not base_name: base_name = "export"
                
                safe_name = base_name
                out_tab_path = os.path.join(out_dir, f"{safe_name}.tab")
                
                if not overwrite:
                    counter = 1
                    while os.path.exists(out_tab_path):
                        safe_name = f"{base_name}_{counter}"
                        out_tab_path = os.path.join(out_dir, f"{safe_name}.tab")
                        counter += 1

                # STRICT ENCODING ENFORCEMENT
                enc = 'ISO-8859-15'

                drv = ogr.GetDriverByName("MapInfo File")
                if os.path.exists(out_tab_path):
                    try: drv.DeleteDataSource(out_tab_path)
                    except Exception: pass

                ds = drv.CreateDataSource(out_tab_path)
                if ds is None:
                    error_messages.append(f"Failed to create file for {layer.name()}")
                    continue

                srs = osr.SpatialReference()
                srs.ImportFromWkt(layer.sourceCrs().toWkt())

                lco = [
                    f"BOUNDS={self.B_XMIN},{self.B_YMIN},{self.B_XMAX},{self.B_YMAX}",
                    f"ENCODING={enc}",
                    "STRICT_FIELDS_NAME_LAUNDERING=NO"
                ]

                ol = ds.CreateLayer(safe_name, srs, geom_type=ogr.wkbUnknown, options=lco)
                if ol is None:
                    error_messages.append(f"Failed MapInfo schema for {layer.name()}")
                    continue

                fields = layer.fields()
                sanitized_names = set()

                for field in fields:
                    raw_name = field.name()
                    
                    # 1. Replace spaces, dots, and hyphens with underscores
                    safe_field_name = re.sub(r'[\s\.-]+', '_', raw_name)
                    # 2. Remove accents/diacritics to make it MapInfo compatible
                    safe_field_name = unicodedata.normalize('NFKD', safe_field_name).encode('ASCII', 'ignore').decode('ASCII')
                    # 3. Strip any remaining non-alphanumeric chars
                    safe_field_name = re.sub(r'[^\w_]', '', safe_field_name)
                    
                    # 4. MapInfo fields cannot start with a number or be completely empty
                    if not safe_field_name or safe_field_name[0].isdigit():
                        safe_field_name = 'F_' + safe_field_name
                        
                    # 5. Enforce 31 character limit
                    safe_field_name = safe_field_name[:31]
                    
                    # 6. Prevent duplicates after sanitization
                    base_safe = safe_field_name
                    counter = 1
                    while safe_field_name in sanitized_names:
                        suffix = f"_{counter}"
                        safe_field_name = base_safe[:31-len(suffix)] + suffix
                        counter += 1
                        
                    sanitized_names.add(safe_field_name)
                    
                    fd = ogr.FieldDefn(safe_field_name, ogr.OFTString)
                    fd.SetWidth(254)
                    ol.CreateField(fd)

                feature_iter = layer.getSelectedFeatures() if use_selected else layer.getFeatures()

                for i, feat in enumerate(feature_iter):
                    if progress.wasCanceled():
                        break

                    newf = ogr.Feature(ol.GetLayerDefn())

                    if feat.hasGeometry():
                        snapped = self._snap_geometry_safe(feat.geometry())
                        if snapped:
                            newf.SetGeometry(ogr.CreateGeometryFromWkb(snapped.asWkb()))

                    attrs = feat.attributes()
                    for j in range(len(fields)):
                        v = attrs[j]
                        
                        if isinstance(v, QDate):
                            s = v.toString("yyyy-MM-dd")
                        elif isinstance(v, QDateTime):
                            s = v.toString("yyyy-MM-dd HH:mm:ss")
                        elif isinstance(v, date):
                            s = v.strftime("%Y-%m-%d")
                        elif isinstance(v, datetime):
                            s = v.strftime("%Y-%m-%d %H:%M:%S")
                        else:
                            s = "" if v is None else str(v)

                        if not self._can_encode(s, enc):
                            s = "[Encoding Error]"
                            
                        b = s.encode(enc, errors='replace')
                        if len(b) > 254: b = b[:254]
                        newf.SetField(j, b.decode(enc, errors='ignore'))

                    ol.CreateFeature(newf)
                    
                    current_feature_idx += 1
                    if current_feature_idx % 10 == 0: 
                        progress.setValue(current_feature_idx)
                        QApplication.processEvents()

                ds = None 
                
                success_count += 1
                exported_files.append((out_tab_path, safe_name)) 

        finally:
            progress.setValue(total_features) 
            QApplication.restoreOverrideCursor()

        if load_layers and not progress.wasCanceled():
            for filepath, layer_name in exported_files:
                vlayer = QgsVectorLayer(filepath, layer_name, "ogr")
                if vlayer.isValid():
                    QgsProject.instance().addMapLayer(vlayer)

        if progress.wasCanceled():
            self.iface.messageBar().pushMessage("Cancelled", f"Export was cancelled. {success_count} layer(s) were completed before cancelling.", level=Qgis.Warning, duration=5)
        elif success_count > 0:
            self.iface.messageBar().pushMessage("Success", f"Successfully exported {success_count} layer(s).", level=Qgis.Success, duration=7)
            
        if error_messages:
            self.iface.messageBar().pushMessage("Errors", " | ".join(error_messages), level=Qgis.Warning, duration=10)