FORMS = ../address_search_dockwidget_base.ui ../address_search_settings.ui
SOURCES = ../address_search.py ../address_search_dockwidget.py
TRANSLATIONS = ../AddressSearch_et.ts