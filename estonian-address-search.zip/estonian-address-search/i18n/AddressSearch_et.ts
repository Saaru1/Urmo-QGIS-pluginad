<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>AddressSearch</name>
    <message>
        <location filename="../address_search.py" line="222"/>
        <source>&amp;Estonian Address Search</source>
        <translation>Aadressiotsing</translation>
    </message>
    <message>
        <location filename="../address_search.py" line="184"/>
        <source>Estonian Address Search</source>
        <translation>Aadressiotsing</translation>
    </message>
</context>
<context>
    <name>AddressSearchDockWidgetBase</name>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="17"/>
        <source>Estonian Address Search</source>
        <translation>Aadressiotsing</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="32"/>
        <source>Settings</source>
        <translation>Seaded</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="45"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="42"/>
        <source>Toggle button: click on the map to get the address</source>
        <translation>kliki kaardil et saada aadress</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="60"/>
        <source>Enter an address / cadastral unit ID / point of interest</source>
        <translation>Sisesta aadress / katastritunnus / huvipunkt</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="83"/>
        <source>Show details</source>
        <translation>Näita täpsemalt</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="115"/>
        <source>attribute</source>
        <translation>väli</translation>
    </message>
    <message>
        <location filename="../address_search_dockwidget_base.ui" line="120"/>
        <source>value</source>
        <translation>väärtus</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../address_search_settings.ui" line="14"/>
        <source>Settings</source>
        <translation>Seaded</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="32"/>
        <source>Default value is 10</source>
        <translation>Vaikeväärtus on 10</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="38"/>
        <source>Number of results shown (1-100)</source>
        <translation>Näidatakse tulemusi (1-100)</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="51"/>
        <source>Only objects with uniqueness requirement are returned</source>
        <translation>Näidatakse ainult unikaalseid kirjeid</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="54"/>
        <source>Unique addresses only</source>
        <translation>Ainult unikaalsed aadressid</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="67"/>
        <source>Pan or zoom to selected address</source>
        <translation>Nihuta või suurenda valitud aadressini</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="70"/>
        <source>Zoom controls:</source>
        <translation>Kaardivaate liigutamine</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="76"/>
        <source>pan</source>
        <translation>nihuta</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="86"/>
        <source>zoom</source>
        <translation>suurenda</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="117"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="130"/>
        <source>Select between address- or object-based search</source>
        <translation>Vali aadressi- või objektipõhine otsing</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="133"/>
        <source>Search type:</source>
        <translation>Otsingu tüüp</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="139"/>
        <source>General address search</source>
        <translation>Üldine aadressiotsing</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="149"/>
        <source>Address object type based search</source>
        <translation>Aadressiobjekti tüübi põhine otsing</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="171"/>
        <source>Only address objects of selected types are returned</source>
        <translation>Näidatakse ainult valitud tüüpi aadressiobjekte</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="174"/>
        <source>Select address object types:</source>
        <translation>Vali aadressiobjekti tüübid:</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="189"/>
        <source>Search building addresses</source>
        <translation>Otsi hooonete aadresse</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="195"/>
        <source>Building</source>
        <translation>Hoone</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="205"/>
        <source>Search the addresses of cadastral units</source>
        <translation>Otsi katastriüksute aadresse</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="211"/>
        <source>Cadastral unit</source>
        <translation>Katastriüksus</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="221"/>
        <source>Search traffic surfaces (e.g. streets)</source>
        <translation>Otsi liikluspindasid (nt. tänavaid)</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="224"/>
        <source>Traffic surface</source>
        <translation>Liikluspind</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="234"/>
        <source> Search Estonian Administrative and Settlement Classification</source>
        <translation>Otsi Eesti haldus- ja asustusüksuste klassifikaatorist</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="240"/>
        <source>EHAK</source>
        <translation>EHAK</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="250"/>
        <source>Search small places</source>
        <translation>Otsi väikekohti</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="256"/>
        <source>Small place</source>
        <translation>Väikekohad</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="282"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../address_search_settings.ui" line="298"/>
        <source>Cancel</source>
        <translation>Tühista</translation>
    </message>
</context>
</TS>
