# -*- coding: utf-8 -*-
"""
Main plugin orchestrator for MaRu ALS 3D QGIS Plugin.

Leaves ONLY the main plugin toggle button on the QGIS toolbar and hosts all
other tools, multi-year layer selector, extra MaRu dataset downloader (DSM/DTM/Ortho),
3D scene & 2D canvas layer browser, customizable 2D/3D styling, 2D canvas layer
draping with LOS occlusion, vertical wall interpolation, measurement modes, and
drone flight controls inside the custom OpenGL 3D Panel (`Als3DPanel`).
"""

import os
from typing import List, Optional

from qgis.PyQt.QtCore import QObject
from qgis.PyQt.QtGui import QIcon
try:
    from qgis.PyQt.QtWidgets import QAction, QActionGroup, QMenu, QToolButton
except ImportError:
    from qgis.PyQt.QtGui import QAction, QActionGroup
    from qgis.PyQt.QtWidgets import QMenu, QToolButton
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsPointCloudLayer,
    QgsPointXY,
    QgsProject,
    QgsSettings,
    QgsVectorLayer,
)
from qgis.gui import QgisInterface

from .core.cache_manager import CacheManager
from .core.downloader import (
    DownloadWorker,
    ExtraLayersMetadataWorker,
    MetadataWorker,
    dismiss_crs_undefined_banners,
    ensure_default_crs_3301,
    install_crs_banner_filter,
    load_pointcloud_layer,
    load_raster_layer,
)
from .core.geoportaal_api import AlsFileInfo, GeoportaalClient, PREF_LATEST_ANY
from .gui.arrow_tool import AlsArrowMapTool, MODE_ARROW, MODE_RECTANGLE
from .gui.qt_compat import BottomDockWidgetArea
from .gui.settings_dialog import AlsSettingsDialog
from .gui.symbology import PointCloudSymbology
from .gui.viewer3d import Als3DPanel
from .gui.viewer3d.drone_canvas_item import DroneCanvas2DOverlay
from .gui.viewer3d.gl_viewer import STATE_FAILED, STATE_NODATA
from .i18n import tr


class MaruAlsPlugin(QObject):
    """Maa- ja Ruumiamet 3D ALS LiDAR & Open Data QGIS Plugin."""

    def __init__(self, iface: QgisInterface):
        super().__init__()
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = os.path.dirname(__file__)

        self.toolbar = None
        self.actions: List[QAction] = []
        self.action_arrow: Optional[QAction] = None
        self.btn_main: Optional[QToolButton] = None
        self.aoi_mode: str = MODE_ARROW
        self.arrow_tool: Optional[AlsArrowMapTool] = None
        self.panel_3d: Optional[Als3DPanel] = None
        self.drone_overlay: Optional[DroneCanvas2DOverlay] = None

        self.last_azimuth: Optional[float] = None
        self.last_p1: Optional[QgsPointXY] = None
        self.last_p2: Optional[QgsPointXY] = None

        self.active_workers: List[DownloadWorker] = []
        self.metadata_workers: List[MetadataWorker] = []
        self.extra_workers: List[ExtraLayersMetadataWorker] = []
        self.last_selected_tiles: List[str] = []
        self.session_layer_ids: Set[str] = set()
        self._is_toggling: bool = False

    def get_icon(self, filename: str) -> QIcon:
        """Helper to load icon from resources."""
        path = os.path.join(self.plugin_dir, "resources", filename)
        return QIcon(path) if os.path.exists(path) else QIcon()

    def initGui(self):
        """Constructs single-button QGIS toolbar, arrow map tool, and unified 3D panel."""
        # Configure silent EPSG:3301 default CRS in QgsSettings without dirtying QgsProject at startup
        ensure_default_crs_3301(touch_project=False)
        install_crs_banner_filter(self.iface)

        # 1. Single Main Toggle Button on the QGIS Toolbar (with Arrow/Rectangle AOI mode dropdown)
        self.toolbar = self.iface.addToolBar(tr("toolbar_title"))
        self.toolbar.setObjectName("MaruAlsToolbar")

        self.action_arrow = QAction(
            self.get_icon("icon_arrow.svg"),
            tr("plugin_name"),
            self.iface.mainWindow(),
        )
        self.action_arrow.setCheckable(True)
        self.action_arrow.setToolTip(tr("tool_arrow_tooltip"))
        self.action_arrow.triggered.connect(self.toggle_main_plugin)

        self.btn_main = QToolButton(self.toolbar)
        self.btn_main.setDefaultAction(self.action_arrow)
        self.btn_main.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)

        self.menu_main_aoi = QMenu(self.btn_main)
        self.act_main_arrow = QAction(
            self.get_icon("icon_arrow.svg"),
            tr("v3d_aoi_mode_arrow"),
            self.iface.mainWindow(),
        )
        self.act_main_arrow.setCheckable(True)
        self.act_main_arrow.setChecked(True)
        self.act_main_arrow.triggered.connect(lambda: self.set_aoi_mode(MODE_ARROW))

        self.act_main_rect = QAction(
            self.get_icon("icon_rect.svg"),
            tr("v3d_aoi_mode_rect"),
            self.iface.mainWindow(),
        )
        self.act_main_rect.setCheckable(True)
        self.act_main_rect.triggered.connect(lambda: self.set_aoi_mode(MODE_RECTANGLE))

        self.grp_main_aoi = QActionGroup(self.iface.mainWindow())
        self.grp_main_aoi.addAction(self.act_main_arrow)
        self.grp_main_aoi.addAction(self.act_main_rect)

        self.menu_main_aoi.addAction(self.act_main_arrow)
        self.menu_main_aoi.addAction(self.act_main_rect)
        self.btn_main.setMenu(self.menu_main_aoi)

        self.toolbar.addWidget(self.btn_main)
        self.iface.addPluginToMenu(tr("plugin_name"), self.action_arrow)
        self.actions.append(self.action_arrow)

        # 2. Initialize Interactive Arrow Map Tool on 2D Canvas
        self.arrow_tool = AlsArrowMapTool(self.canvas, self.iface)
        self.arrow_tool.tiles_selected.connect(self.on_tiles_selected)
        self.arrow_tool.deactivated.connect(self.on_arrow_tool_deactivated)
        self.arrow_tool.mode_changed.connect(self.set_aoi_mode)

        # 3. 3D panel and 2D drone overlay are strictly lazy (initialized only when activated)
        self.panel_3d = None
        self.drone_overlay = None

    def _ensure_panel_3d(self) -> Optional[Als3DPanel]:
        """Lazily creates and initializes 3D Panel and 2D overlay if not yet created."""
        if self.panel_3d is not None:
            return self.panel_3d
        try:
            self._init_panel_3d()
            return self.panel_3d
        except Exception as e:
            QgsMessageLog.logMessage(f"MaRu ALS 3D paneeli initsialiseerimise viga: {e}", "MaRu ALS", Qgis.Critical)
            if hasattr(self, "iface") and self.iface:
                self.iface.messageBar().pushCritical("MaRu ALS", f"3D vaate käivitamine ebaõnnestus: {e}")
            self.panel_3d = None
            return None

    def _init_panel_3d(self):
        """Initializes 3D Panel, 2D overlay, and connects core signals."""
        self.panel_3d = Als3DPanel(self.iface.mainWindow(), self.plugin_dir, canvas=self.canvas)
        self.panel_3d.arrow_tool_toggled.connect(self.set_arrow_tool_active)
        self.panel_3d.aoi_mode_changed.connect(self.set_aoi_mode)
        self.panel_3d.load_file_requested.connect(self.on_load_file_requested)
        self.panel_3d.load_all_requested.connect(self.on_load_all_requested)
        self.panel_3d.tile_stream_requested.connect(self.on_tile_stream_needed)
        self.panel_3d.toggle_grid_requested.connect(self.toggle_grid_layer)
        self.panel_3d.open_settings_requested.connect(self.open_settings)
        self.panel_3d.symbology_2d_requested.connect(self.apply_symbology)
        self.panel_3d.fetch_extra_requested.connect(self.on_fetch_extra_requested)
        self.panel_3d.clear_session_requested.connect(self.remove_session_layers_from_2d)
        self.panel_3d.viewer.status_message.connect(
            lambda msg: self.iface.mainWindow().statusBar().showMessage(msg, 4000)
        )

        # 4. Initialize 2D Drone Location & Bearing Cone Overlay on Main Map Canvas
        self.drone_overlay = DroneCanvas2DOverlay(self.canvas)
        self.panel_3d.viewer.camera_moved.connect(self.drone_overlay.update_telemetry)
        self.panel_3d.drone_2d_toggled.connect(self.drone_overlay.set_enabled)
        self.panel_3d.drone_2d_cone_toggled.connect(self.drone_overlay.set_show_cone)
        self.panel_3d.drone_2d_path_toggled.connect(self.drone_overlay.set_show_path)
        self.panel_3d.drone_2d_follow_toggled.connect(self.drone_overlay.set_auto_follow)
        self.panel_3d.drone_2d_center_requested.connect(self.drone_overlay.center_on_drone)

        # Keep Tab 3's 2D Canvas Layers tree in sync with QGIS project layers
        proj = QgsProject.instance()
        proj.layersAdded.connect(self._on_project_layers_changed)
        proj.layersRemoved.connect(self._on_project_layers_changed)

        self.iface.addDockWidget(BottomDockWidgetArea, self.panel_3d)
        screen = self.iface.mainWindow().screen()
        if screen:
            sg = screen.availableGeometry()
            w = min(1200, max(750, int(sg.width() * 0.85)))
            h = min(640, max(460, int(sg.height() * 0.65)))
            self.panel_3d.resize(w, h)
        else:
            self.panel_3d.resize(1100, 600)

        self.panel_3d.panel_closed.connect(self._on_dock_closed_by_user)
        self.panel_3d.hide()

    def _on_dock_closed_by_user(self):
        """Syncs main toolbar toggle when dock widget is closed via [X] titlebar button."""
        if self._is_toggling:
            return
        if self.action_arrow and self.action_arrow.isChecked():
            self.action_arrow.blockSignals(True)
            self.action_arrow.setChecked(False)
            self.action_arrow.blockSignals(False)
        self.toggle_main_plugin(False)

    def _on_project_layers_changed(self, *args):
        if self.panel_3d:
            self.panel_3d.refresh_canvas_2d_tree()

    def unload(self):
        """Clean up when plugin is deactivated or uninstalled without causing QGIS crashes."""
        # 1. Uninstall CRS banner hook so no dead closure is called by QGIS messageBar
        try:
            from .core.downloader import uninstall_crs_banner_filter
            uninstall_crs_banner_filter()
        except Exception:
            pass

        # 2. Disconnect project layer listeners
        try:
            proj = QgsProject.instance()
            proj.layersAdded.disconnect(self._on_project_layers_changed)
            proj.layersRemoved.disconnect(self._on_project_layers_changed)
        except Exception:
            pass

        # 3. Clean up map tool
        if self.arrow_tool:
            try:
                if self.canvas and self.canvas.mapTool() == self.arrow_tool:
                    self.canvas.unsetMapTool(self.arrow_tool)
                self.arrow_tool.tiles_selected.disconnect()
                self.arrow_tool.deactivated.disconnect()
                self.arrow_tool.reset_rubberbands()
            except Exception:
                pass
            self.arrow_tool = None

        # 4. Clean up 2D drone overlay map canvas item
        if hasattr(self, "drone_overlay") and self.drone_overlay:
            try:
                self.drone_overlay.clear_fix()
                self.drone_overlay.hide()
                from qgis.PyQt import sip
                sip.delete(self.drone_overlay)
            except Exception:
                pass
            self.drone_overlay = None

        # 5. Cleanly shut down 3D panel and its background threads/GL widgets
        if self.panel_3d:
            try:
                self.panel_3d.panel_closed.disconnect(self._on_dock_closed_by_user)
            except Exception:
                pass
            try:
                self.panel_3d.shutdown()
                self.iface.removeDockWidget(self.panel_3d)
                self.panel_3d.setParent(None)
                from qgis.PyQt import sip
                sip.delete(self.panel_3d)
            except Exception:
                pass
            self.panel_3d = None

        # 6. Remove menu items and toolbar
        for action in self.actions:
            try:
                self.iface.removePluginMenu(tr("plugin_name"), action)
                action.deleteLater()
            except Exception:
                pass
        self.actions.clear()

        if self.btn_main:
            try:
                self.btn_main.deleteLater()
            except Exception:
                pass
            self.btn_main = None

        if self.toolbar:
            try:
                self.iface.mainWindow().removeToolBar(self.toolbar)
                self.toolbar.deleteLater()
            except Exception:
                pass
            self.toolbar = None

    # ------------------------------------------------------------------ #
    # Main Toggle & Arrow Map Tool Sync
    # ------------------------------------------------------------------ #
    def toggle_main_plugin(self, checked: bool):
        """Main QGIS toolbar button handler: activates arrow tool, controls 3D panel and 2D canvas data."""
        if self._is_toggling:
            return
        self._is_toggling = True
        try:
            if checked:
                if self.panel_3d is None:
                    try:
                        self._init_panel_3d()
                    except Exception as e:
                        self.iface.messageBar().pushCritical("MaRu ALS", f"3D vaate käivitamine ebaõnnestus: {e}")
                        return
                if self.action_arrow:
                    self.action_arrow.blockSignals(True)
                    self.action_arrow.setChecked(True)
                    self.action_arrow.blockSignals(False)
                if self.panel_3d:
                    self.panel_3d.setVisible(True)
                    if hasattr(self.panel_3d, "setUserVisible"):
                        self.panel_3d.setUserVisible(True)
                    self.panel_3d.show()
                    self.panel_3d.raise_()
                    self.panel_3d.activateWindow()
                if hasattr(self, "drone_overlay") and self.drone_overlay:
                    self.drone_overlay.show()
                if self.panel_3d:
                    self.panel_3d.show_photo_layer_2d()
                    if hasattr(self.panel_3d, "signal_dialog") and self.panel_3d.signal_dialog:
                        if self.panel_3d.signal_dialog.overlay_2d:
                            self.panel_3d.signal_dialog.overlay_2d._update_visibility()
                self.set_session_layers_visibility(True)
                self.set_arrow_tool_active(True)
            else:
                # Check if there is an active 3D session
                has_session = False
                if self.panel_3d:
                    has_session = bool(self.panel_3d.session_data or self.panel_3d.viewer.tiles)

                if has_session:
                    from qgis.PyQt.QtWidgets import QMessageBox
                    reply = QMessageBox.question(
                        self.iface.mainWindow(),
                        tr("plugin_name"),
                        "Kas soovid 3D vaate sessiooni andmed mälus säilitada või tühjendada?\n\n"
                        "• [Jah / Yes] — Säilita sessioon (vaikimisi): peidab 3D paneeli ja 2D kaardikihid, võimaldades hiljem kohe jätkata.\n"
                        "• [Ei / No] — Puhasta mälust: sulgeb vaate ja vabastab punktipilved mälust.\n"
                        "• [Loobu / Cancel] — Jääb avatuks.",
                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                        QMessageBox.StandardButton.Yes,
                    )
                    if reply == QMessageBox.StandardButton.Cancel:
                        if self.action_arrow:
                            self.action_arrow.blockSignals(True)
                            self.action_arrow.setChecked(True)
                            self.action_arrow.blockSignals(False)
                        if self.panel_3d:
                            self.panel_3d.setVisible(True)
                            if hasattr(self.panel_3d, "setUserVisible"):
                                self.panel_3d.setUserVisible(True)
                            self.panel_3d.show()
                            self.panel_3d.raise_()
                        return
                    elif reply == QMessageBox.StandardButton.No:
                        if self.panel_3d:
                            self.panel_3d.clear_session()

                if self.action_arrow:
                    self.action_arrow.blockSignals(True)
                    self.action_arrow.setChecked(False)
                    self.action_arrow.blockSignals(False)

                # Untoggle and hide all plugin components from 2D canvas and dock
                if self.panel_3d:
                    if hasattr(self.panel_3d, "setUserVisible"):
                        self.panel_3d.setUserVisible(False)
                    self.panel_3d.hide()
                    self.panel_3d.hide_photo_layer_2d()
                    if hasattr(self.panel_3d, "signal_dialog") and self.panel_3d.signal_dialog:
                        if self.panel_3d.signal_dialog.overlay_2d:
                            self.panel_3d.signal_dialog.overlay_2d.setVisible(False)

                self.set_session_layers_visibility(False)

                if hasattr(self, "drone_overlay") and self.drone_overlay:
                    self.drone_overlay.clear_fix()
                    self.drone_overlay.hide()

                if self.arrow_tool:
                    self.arrow_tool.reset_rubberbands()

                self.set_arrow_tool_active(False)
                if self.canvas:
                    self.canvas.refresh()
        finally:
            self._is_toggling = False

    def set_arrow_tool_active(self, active: bool):
        """Activates or deactivates the 2D Arrow Map Tool and syncs both buttons."""
        if active:
            if self.canvas.mapTool() != self.arrow_tool:
                self.canvas.setMapTool(self.arrow_tool)
        else:
            if self.canvas.mapTool() == self.arrow_tool:
                self.canvas.unsetMapTool(self.arrow_tool)

        if self.action_arrow and self.action_arrow.isChecked() != active:
            self.action_arrow.blockSignals(True)
            self.action_arrow.setChecked(active)
            self.action_arrow.blockSignals(False)

        if self.panel_3d:
            self.panel_3d.set_arrow_checked(active)

    def set_aoi_mode(self, mode: str):
        """Switches AOI selection mode ('arrow' vs 'rectangle') across all components."""
        self.aoi_mode = mode
        if self.arrow_tool:
            self.arrow_tool.set_mode(mode)
        if self.panel_3d:
            self.panel_3d.set_aoi_mode(mode, emit_signal=False)

        if mode == MODE_RECTANGLE:
            self.action_arrow.setIcon(self.get_icon("icon_rect.svg"))
            self.action_arrow.setToolTip(tr("v3d_tb_rect_tip"))
            if hasattr(self, "act_main_rect"):
                self.act_main_rect.blockSignals(True)
                self.act_main_rect.setChecked(True)
                self.act_main_rect.blockSignals(False)
        else:
            self.action_arrow.setIcon(self.get_icon("icon_arrow.svg"))
            self.action_arrow.setToolTip(tr("tool_arrow_tooltip"))
            if hasattr(self, "act_main_arrow"):
                self.act_main_arrow.blockSignals(True)
                self.act_main_arrow.setChecked(True)
                self.act_main_arrow.blockSignals(False)

        if not self.action_arrow.isChecked():
            self.toggle_main_plugin(True)
        else:
            self.set_arrow_tool_active(True)

    def on_arrow_tool_deactivated(self):
        """Ensure toolbar and 3D panel buttons sync when map tool changes externally."""
        if self.action_arrow and self.action_arrow.isChecked():
            self.action_arrow.blockSignals(True)
            self.action_arrow.setChecked(False)
            self.action_arrow.blockSignals(False)
        if self.panel_3d:
            self.panel_3d.set_arrow_checked(False)

    # ------------------------------------------------------------------ #
    # Arrow Selection -> Priority 1 Download & 3D Streaming
    # ------------------------------------------------------------------ #
    def on_tiles_selected(
        self,
        tiles: List[str],
        azimuth: float,
        distance: float,
        p1_3301: QgsPointXY,
        p2_3301: QgsPointXY,
    ):
        """
        Triggered when user releases the arrow on the 2D map.
        1. Opens/raises the custom 3D panel and aligns the 3D drone camera at p1 looking
           toward p2 along `azimuth`.
        2. Priority 1: Immediately fetches & opens the latest LAZ for the primary tile
           in both 2D and the 3D OpenGL viewer (styled in natural RGB by default).
        3. Background: Queries and streams secondary tiles along the arrow, plus queries
           available extra MaRu datasets (DSM, DTM, Orthophotos, Basic Map).
        """
        ensure_default_crs_3301()
        install_crs_banner_filter(self.iface)
        dismiss_crs_undefined_banners(self.iface)

        self.last_azimuth = azimuth
        self.last_p1 = p1_3301
        self.last_p2 = p2_3301
        self.last_selected_tiles = list(tiles)

        if not tiles:
            return

        is_rect = getattr(self.arrow_tool, "mode", "arrow") == MODE_RECTANGLE

        if self.panel_3d is None:
            self._ensure_panel_3d()

        # Show 3D panel and orient camera along trajectory or overview
        if self.panel_3d:
            if not self.panel_3d.isVisible():
                self.panel_3d.show()
            self.panel_3d.raise_()
            for t in tiles:
                self.panel_3d.mark_tile_queued(t)

            if is_rect:
                cam_agl = max(110.0, min(500.0, distance * 0.28))
                cam_pitch = -32.0
            else:
                cam_agl = 85.0
                cam_pitch = -22.0

            self.panel_3d.viewer.set_camera_abs(
                p1_3301.x(),
                p1_3301.y(),
                heading=azimuth,
                pitch=cam_pitch,
                agl=cam_agl,
            )
            self.panel_3d.refresh_canvas_2d_tree()
            self.panel_3d.refresh_canvas_layers_in_3d()
            self.panel_3d.viewer.setFocus()

        settings = QgsSettings()
        pref = settings.value("maru_als/flight_preference", PREF_LATEST_ANY)

        # Priority 1: Primary tile
        primary_tile = tiles[0]
        if self.panel_3d:
            self.panel_3d.set_progress(4, tr("fetching_metadata", tile=primary_tile), visible=True)
        f_list = GeoportaalClient.fetch_tile_files(primary_tile)
        if f_list:
            if self.panel_3d:
                self.panel_3d.add_tile_files(primary_tile, f_list)
            preferred = GeoportaalClient.select_preferred_file(f_list, pref)
            if preferred:
                self.download_and_open_file(preferred, zoom_to=(not is_rect), align_view=(not is_rect))
                if is_rect and len(tiles) > 1:
                    from .core.grid_engine import GridEngine
                    all_rects = [GridEngine.tile_to_rect(t) for t in tiles if GridEngine.tile_to_rect(t)]
                    if all_rects:
                        full_box = all_rects[0]
                        for r in all_rects[1:]:
                            full_box.combineExtentWith(r)
                        self.canvas.setExtent(full_box.buffered(150.0))
                        self.canvas.refresh()
        else:
            if self.panel_3d:
                self.panel_3d.viewer.set_tile_state(primary_tile, STATE_NODATA)
                self.panel_3d.set_progress(100, "", visible=False)
            self.iface.mainWindow().statusBar().showMessage(
                tr("no_als_data_tile", tile=primary_tile), 4000
            )

        # Background: Secondary tiles along arrow
        if len(tiles) > 1:
            sec_tiles = tiles[1:]
            meta_worker = MetadataWorker(sec_tiles, self)
            meta_worker.tile_metadata_ready.connect(self.on_secondary_tile_metadata_ready)
            self.metadata_workers.append(meta_worker)
            meta_worker.finished.connect(
                lambda: self.metadata_workers.remove(meta_worker)
                if meta_worker in self.metadata_workers
                else None
            )
            meta_worker.start()

        # Background: Also query extra MaRu layers (DSM, DTM, Ortho, Basic Map) for session tiles
        if self.panel_3d:
            self.on_fetch_extra_requested(self.panel_3d.selected_extra_categories(), tiles=tiles)

    def on_secondary_tile_metadata_ready(self, tile_id: str, files: List[AlsFileInfo]):
        """Callback when background metadata worker finishes querying a secondary/streamed tile."""
        if not files:
            if self.panel_3d:
                self.panel_3d.viewer.set_tile_state(tile_id, STATE_NODATA)
            return

        if self.panel_3d:
            self.panel_3d.add_tile_files(tile_id, files)

        settings = QgsSettings()
        pref = settings.value("maru_als/flight_preference", PREF_LATEST_ANY)
        preferred = GeoportaalClient.select_preferred_file(files, pref)
        if preferred:
            self.download_and_open_file(preferred, zoom_to=False, align_view=False)

    # ------------------------------------------------------------------ #
    # Extra MaRu Datasets (DSM 1m, DTM 1m, Orthophotos, Basic Map)
    # ------------------------------------------------------------------ #
    def on_fetch_extra_requested(
        self,
        categories: List[str],
        tiles: Optional[List[str]] = None,
    ):
        """Queries Geoportaal in background for additional datasets for session tiles with live %."""
        if not self.panel_3d:
            return
        target_tiles = tiles or list(self.panel_3d.session_data.keys()) or self.last_selected_tiles
        if not target_tiles or not categories:
            return

        self.panel_3d.set_progress(
            5,
            f"Pärin lisakihte ({len(target_tiles)} ruutu)...",
            visible=True,
        )

        worker = ExtraLayersMetadataWorker(target_tiles, categories, self)
        worker.extra_metadata_ready.connect(self.panel_3d.add_extra_tile_files)
        worker.progress_updated.connect(
            lambda pct, txt: self.panel_3d.set_progress(pct, txt, visible=(pct < 100))
            if self.panel_3d
            else None
        )
        self.extra_workers.append(worker)
        worker.finished.connect(
            lambda: self.extra_workers.remove(worker)
            if worker in self.extra_workers
            else None
        )
        worker.start()

    # ------------------------------------------------------------------ #
    # File Download & Opening (LAZ Point Clouds + Extra GeoTIFF/ZIP Rasters)
    # ------------------------------------------------------------------ #
    def download_and_open_file(
        self,
        file_info: AlsFileInfo,
        zoom_to: bool = False,
        align_view: bool = False,
    ):
        """Downloads (if needed) and opens a LAZ point cloud or Extra MaRu raster layer in 3D + 2D."""
        local_path = CacheManager.get_file_path(file_info.filename)
        file_info.local_path = local_path

        # 1. If already cached on disk, load immediately into 3D and 2D
        if CacheManager.is_cached(file_info.filename):
            file_info.downloaded = True
            self._open_local_file(file_info, zoom_to=zoom_to, align_view=align_view)
            self.iface.mainWindow().statusBar().showMessage(
                f"Avatud vahemälust (3D + 2D): {file_info.filename}", 4000
            )
            return

        # 2. Download in background worker thread with live %
        if self.panel_3d:
            if not file_info.is_raster:
                self.panel_3d.mark_tile_queued(file_info.tile_id)
            self.panel_3d.set_progress(
                2,
                f"Laadin alla: {file_info.filename} ({file_info.size_str})...",
                visible=True,
            )

        self.iface.mainWindow().statusBar().showMessage(
            tr(
                "downloading_tile",
                tile=file_info.tile_id,
                filename=file_info.filename,
                size=file_info.size_str,
            ),
            5000,
        )

        worker = DownloadWorker([file_info], self)
        self.active_workers.append(worker)

        def on_dl_progress(pct: int, txt: str):
            self.iface.mainWindow().statusBar().showMessage(txt, 2500)
            if self.panel_3d:
                # Map download progress to 2%..75%, leaving 75%..100% for 3D decoding
                scaled_pct = max(2, min(75, int(round(pct * 0.75))))
                self.panel_3d.set_progress(scaled_pct, txt, visible=True)

        worker.progress_updated.connect(on_dl_progress)

        def on_fail(err: str):
            if self.panel_3d:
                if not file_info.is_raster:
                    self.panel_3d.viewer.set_tile_state(file_info.tile_id, STATE_FAILED)
                self.panel_3d.set_progress(100, "", visible=False)
            self.iface.messageBar().pushCritical("MaRu ALS", err)

        worker.failed.connect(on_fail)

        def on_done(files: List[AlsFileInfo]):
            if worker in self.active_workers:
                self.active_workers.remove(worker)
            for f in files:
                self._open_local_file(f, zoom_to=zoom_to, align_view=align_view)
            self.iface.messageBar().pushSuccess(
                "MaRu ALS",
                f"Kiht {file_info.filename} edukalt alla laaditud ja avatud (3D + 2D)!",
            )

        worker.all_completed.connect(on_done)
        worker.start()

    def _open_local_file(
        self,
        file_info: AlsFileInfo,
        zoom_to: bool = False,
        align_view: bool = False,
    ):
        """Routes a local file to BOTH the 3D OpenGL viewer and the 2D QGIS canvas."""
        ensure_default_crs_3301()
        install_crs_banner_filter(self.iface)
        if file_info.is_raster:
            # 1. Enqueue for 3D OpenGL viewer (DSM/DTM/Orthophoto/Basic Map in 3D!)
            if self.panel_3d:
                self.panel_3d.enqueue_raster_for_3d(file_info)

            # 2. Also open on 2D QGIS canvas
            try:
                stem = os.path.splitext(file_info.filename)[0]
                rl = load_raster_layer(
                    file_info.local_path,
                    stem,
                    category=file_info.flight_type,
                    file_info=file_info,
                    iface_obj=self.iface,
                )
                if rl is not None and rl.isValid():
                    self.session_layer_ids.add(rl.id())
            except Exception as e:
                QgsMessageLog.logMessage(f"Viga rasterkihi avamisel: {e}", "MaRu ALS", Qgis.Warning)
            dismiss_crs_undefined_banners(self.iface)
            if self.panel_3d:
                self.panel_3d.refresh_tree_statuses()
            return

        self._open_local_laz(file_info, zoom_to=zoom_to, align_view=align_view)

    def _open_local_laz(
        self,
        file_info: AlsFileInfo,
        zoom_to: bool = False,
        align_view: bool = False,
    ):
        """Loads a local LAZ file into the 3D OpenGL viewer and 2D QGIS canvas (natural RGB default)."""
        # Queue immediately for the custom 3D OpenGL viewer
        if self.panel_3d:
            self.panel_3d.enqueue_laz_for_3d(file_info)

        # Also add to 2D canvas with active symbology (defaults to natural RGB)
        try:
            layer = load_pointcloud_layer(
                file_info.local_path,
                file_info.filename.replace(".laz", ""),
                iface_obj=self.iface,
            )
            if layer and layer.isValid():
                self.session_layer_ids.add(layer.id())
                PointCloudSymbology.apply_current_style(layer)
                if zoom_to:
                    self.canvas.setExtent(layer.extent())
                    self.canvas.refresh()
                if align_view:
                    settings = QgsSettings()
                    if (
                        settings.value("maru_als/rotate_2d", False, type=bool)
                        and self.last_azimuth is not None
                    ):
                        self.canvas.setMapRotation(self.last_azimuth)
        except Exception as e:
            QgsMessageLog.logMessage(f"Viga 2D kihi avamisel: {e}", "MaRu ALS", Qgis.Warning)

        dismiss_crs_undefined_banners(self.iface)
        if self.panel_3d:
            self.panel_3d.refresh_tree_statuses()

    def set_session_layers_visibility(self, visible: bool):
        """Hides or reveals session layers on 2D canvas without removing them from project."""
        proj = QgsProject.instance()
        root = proj.layerTreeRoot()
        for lyr_id, lyr in list(proj.mapLayers().items()):
            if not lyr.isValid():
                continue
            name = lyr.name()
            is_session_lyr = (
                lyr_id in self.session_layer_ids
                or isinstance(lyr, QgsPointCloudLayer)
                or name == "MaRu ALS Droonifotod"
                or any(c in lyr.source().lower() for c in ["maru", "geoportaal", "cache"])
            )
            if is_session_lyr:
                node = root.findLayer(lyr_id)
                if node:
                    node.setItemVisibilityChecked(visible)

    def remove_session_layers_from_2d(self):
        """Removes all session ALS point clouds, extra rasters, photo layer, and overlays from 2D canvas."""
        proj = QgsProject.instance()
        to_remove = set(self.session_layer_ids)

        for lyr_id, lyr in list(proj.mapLayers().items()):
            if not lyr.isValid():
                continue
            name = lyr.name()
            # 1. Any Point Cloud Layer (LAZ)
            if isinstance(lyr, QgsPointCloudLayer):
                to_remove.add(lyr_id)
            # 2. Drone photo layer
            elif name == "MaRu ALS Droonifotod":
                to_remove.add(lyr_id)
            # 3. Any extra MaRu rasters (DSM, DTM, Orthophotos, Basic map)
            elif any(tag in name.lower() for tag in ["dsm", "dtm", "orto", "ortho", "pohikaart"]):
                if lyr_id in self.session_layer_ids or any(c in lyr.source() for c in ["maru", "geoportaal", "cache"]):
                    to_remove.add(lyr_id)

        for lid in to_remove:
            try:
                proj.removeMapLayer(lid)
            except Exception:
                pass
        self.session_layer_ids.clear()

        if hasattr(self, "drone_overlay") and self.drone_overlay:
            self.drone_overlay.clear_fix()
            self.drone_overlay.hide()

        if self.arrow_tool:
            self.arrow_tool.reset_rubberbands()

        if self.canvas:
            self.canvas.refresh()

    # ------------------------------------------------------------------ #
    # Panel & Streaming Callbacks
    # ------------------------------------------------------------------ #
    def on_load_file_requested(self, file_info: AlsFileInfo):
        """Called when user selects a specific flight year or extra dataset in the 3D panel's drawer."""
        self.download_and_open_file(file_info, zoom_to=False, align_view=False)

    def on_load_all_requested(self):
        """Downloads and opens the preferred file for all tiles in current session."""
        if not self.panel_3d:
            return
        settings = QgsSettings()
        pref = settings.value("maru_als/flight_preference", PREF_LATEST_ANY)
        for tile_id, files in self.panel_3d.session_data.items():
            preferred = GeoportaalClient.select_preferred_file(files, pref)
            if preferred:
                self.download_and_open_file(preferred, zoom_to=False, align_view=False)

    def on_tile_stream_needed(self, tile_id: str):
        """Auto-streams adjacent 1:2000 tiles when the user flies outside loaded grids."""
        if self.panel_3d and tile_id in self.panel_3d.session_data:
            files = self.panel_3d.session_data[tile_id]
            settings = QgsSettings()
            pref = settings.value("maru_als/flight_preference", PREF_LATEST_ANY)
            preferred = GeoportaalClient.select_preferred_file(files, pref)
            if preferred:
                self.download_and_open_file(preferred, zoom_to=False, align_view=False)
            return

        self.iface.mainWindow().statusBar().showMessage(
            tr("fetching_metadata", tile=tile_id), 2500
        )
        meta_worker = MetadataWorker([tile_id], self)
        meta_worker.tile_metadata_ready.connect(self.on_secondary_tile_metadata_ready)
        self.metadata_workers.append(meta_worker)
        meta_worker.finished.connect(
            lambda: self.metadata_workers.remove(meta_worker)
            if meta_worker in self.metadata_workers
            else None
        )
        meta_worker.start()

    def toggle_grid_layer(self):
        """Toggles the official Maa-amet 1:2000 WFS Kaardilehed grid overlay on 2D canvas."""
        layer_name = tr("grid_layer_name")

        existing_layers = QgsProject.instance().mapLayersByName(layer_name)
        if existing_layers:
            lyr = existing_layers[0]
            node = QgsProject.instance().layerTreeRoot().findLayer(lyr.id())
            if node:
                node.setItemVisibilityChecked(not node.isVisible())
            return

        source = (
            "pagingEnabled='default' preferCoordinatesForWfsT11='false' "
            "srsname='EPSG:3301' typename='ms:epk_2T' "
            "url='https://teenus.maaamet.ee/ows/kaardivorgud?version=2.0.0' version='auto'"
        )
        grid_lyr = QgsVectorLayer(source, layer_name, "WFS")
        if grid_lyr.isValid():
            QgsProject.instance().addMapLayer(grid_lyr)
        else:
            self.iface.messageBar().pushWarning(
                "MaRu ALS", "Kaardivõrgu WFS kihti ei õnnestunud serverist laadida."
            )

    def apply_symbology(self, style_type: str):
        """Applies symbology preset and custom parameters to all 2D ALS point cloud layers."""
        PointCloudSymbology.active_mode = style_type
        layers = [
            lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsPointCloudLayer)
        ]
        for lyr in layers:
            PointCloudSymbology.apply_current_style(lyr)

    def open_settings(self):
        """Opens settings dialog, retranslates UI on save, and updates 3D sky/horizon settings."""
        dlg = AlsSettingsDialog(self.iface.mainWindow())
        if dlg.exec():
            self.retranslate_ui()
            if self.panel_3d:
                self.panel_3d.apply_settings()

    def retranslate_ui(self):
        """Dynamically updates toolbar and 3D panel strings when language is toggled."""
        if self.toolbar:
            self.toolbar.setWindowTitle(tr("toolbar_title"))
        if self.action_arrow:
            self.action_arrow.setText(tr("plugin_name"))
            if getattr(self, "aoi_mode", "arrow") == MODE_RECTANGLE:
                self.action_arrow.setToolTip(tr("v3d_tb_rect_tip"))
            else:
                self.action_arrow.setToolTip(tr("tool_arrow_tooltip"))
        if hasattr(self, "act_main_arrow"):
            self.act_main_arrow.setText(tr("v3d_aoi_mode_arrow"))
        if hasattr(self, "act_main_rect"):
            self.act_main_rect.setText(tr("v3d_aoi_mode_rect"))
        if self.panel_3d:
            self.panel_3d.retranslate_ui()
