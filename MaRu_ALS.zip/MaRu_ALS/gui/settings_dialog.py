# -*- coding: utf-8 -*-
"""
Settings dialog for MaRu ALS QGIS Plugin.
Manages language (EST/ENG), flight preference, cache folder, and 3D view behavior.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QGroupBox,
    QComboBox,
    QLineEdit,
    QPushButton,
    QCheckBox,
    QLabel,
    QFileDialog,
    QMessageBox
)
from qgis.core import QgsSettings

from ..i18n import I18n, tr, LANG_ET, LANG_EN
from ..core.cache_manager import CacheManager
from ..core.geoportaal_api import PREF_LATEST_ANY, PREF_LATEST_TAVA, PREF_LATEST_METS


class AlsSettingsDialog(QDialog):
    """Configuration dialog for MaRu ALS plugin."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("settings_title"))
        self.setMinimumWidth(460)
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # Group 1: General Settings (Language & Flight Preference)
        grp_general = QGroupBox(tr("settings_group_general"))
        form_general = QFormLayout(grp_general)

        # Language dropdown
        self.combo_lang = QComboBox()
        self.combo_lang.addItem(tr("settings_lang_et"), LANG_ET)
        self.combo_lang.addItem(tr("settings_lang_en"), LANG_EN)
        form_general.addRow(tr("settings_language"), self.combo_lang)

        # Flight preference
        self.combo_pref = QComboBox()
        self.combo_pref.addItem(tr("settings_pref_latest_any"), PREF_LATEST_ANY)
        self.combo_pref.addItem(tr("settings_pref_latest_tava"), PREF_LATEST_TAVA)
        self.combo_pref.addItem(tr("settings_pref_latest_mets"), PREF_LATEST_METS)
        form_general.addRow(tr("settings_flight_pref"), self.combo_pref)

        layout.addWidget(grp_general)

        # Group 2: Cache & Downloads
        grp_cache = QGroupBox(tr("settings_group_cache"))
        layout_cache = QVBoxLayout(grp_cache)

        dir_h_layout = QHBoxLayout()
        self.edit_cache_dir = QLineEdit()
        self.btn_browse = QPushButton(tr("settings_cache_browse"))
        self.btn_browse.clicked.connect(self.browse_cache_dir)
        dir_h_layout.addWidget(self.edit_cache_dir)
        dir_h_layout.addWidget(self.btn_browse)
        layout_cache.addLayout(dir_h_layout)

        # Cache info & actions
        cache_action_layout = QHBoxLayout()
        self.lbl_cache_size = QLabel(tr("settings_cache_usage", size=CacheManager.get_cache_size_str()))
        self.btn_open_folder = QPushButton(tr("settings_cache_open"))
        self.btn_open_folder.clicked.connect(CacheManager.open_folder)
        self.btn_clear_cache = QPushButton(tr("settings_cache_clear"))
        self.btn_clear_cache.clicked.connect(self.clear_cache)

        cache_action_layout.addWidget(self.lbl_cache_size)
        cache_action_layout.addStretch()
        cache_action_layout.addWidget(self.btn_open_folder)
        cache_action_layout.addWidget(self.btn_clear_cache)
        layout_cache.addLayout(cache_action_layout)

        layout.addWidget(grp_cache)

        # Group 3: View & 3D options
        grp_view = QGroupBox(tr("settings_group_view"))
        layout_view = QVBoxLayout(grp_view)
        self.chk_auto_3d = QCheckBox(tr("settings_auto_3d"))
        self.chk_rotate_2d = QCheckBox(tr("settings_rotate_2d"))
        layout_view.addWidget(self.chk_auto_3d)
        layout_view.addWidget(self.chk_rotate_2d)

        lbl_engine = QLabel(tr("settings_render_engine", fallback="3D graafikamootor (Riistvaraline FBO / CPU ühilduvus):"))
        layout_view.addWidget(lbl_engine)
        self.combo_engine = QComboBox()
        self.combo_engine.addItem(
            tr("engine_auto", fallback="Automaatne (Riistvaraline OpenGL FBO kõigil GPU-del, sh Intel Arc; automaatne CPU varulahendus)"),
            "auto",
        )
        self.combo_engine.addItem(
            tr("engine_fbo", fallback="Riistvaraline — Offscreen OpenGL FBO (kuni 14M punkti, GPU riistvarakiirendus)"),
            "fbo",
        )
        self.combo_engine.addItem(
            tr("engine_software", fallback="Ühilduvusrežiim — Puhas NumPy CPU 3D (OpenGL-vaba varurežiim)"),
            "software",
        )
        layout_view.addWidget(self.combo_engine)
        layout.addWidget(grp_view)

        # Group 4: 3D Skybox & Horizon Mode (List dropdown, Default: Off)
        grp_sky = QGroupBox(tr("settings_group_sky", fallback="3D Taevas ja horisont (Skybox & Horizon)"))
        layout_sky = QVBoxLayout(grp_sky)
        layout_sky.setSpacing(6)

        lbl_sky = QLabel(tr("settings_sky_mode", fallback="Taeva ja horisondi režiim (Skybox):"))
        layout_sky.addWidget(lbl_sky)

        self.combo_sky = QComboBox()
        self.combo_sky.addItem(tr("sky_mode_off", fallback="Väljas (Tume kokpiti taust / Classic Dark)"), "off")
        self.combo_sky.addItem(tr("sky_mode_procedural", fallback="1. Protseduuriline atmosfääritaevas & hägu"), "procedural")
        self.combo_sky.addItem(tr("sky_mode_panorama", fallback="2. 360° Fotorealistlik panoraamtaevas (Läänemere pilved)"), "panorama")
        self.combo_sky.addItem(tr("sky_mode_fog", fallback="3. Horisondi kauguse udu (Distance Horizon Fog)"), "fog")
        self.combo_sky.addItem(tr("sky_mode_proc_fog", fallback="4. Protseduuriline taevas + Horisondi udu"), "procedural_fog")
        self.combo_sky.addItem(tr("sky_mode_pano_fog", fallback="5. Panoraamtaevas + Horisondi udu"), "panorama_fog")
        layout_sky.addWidget(self.combo_sky)

        lbl_sky_help = QLabel(
            tr(
                "settings_sky_help",
                fallback="Valitud taevas arvutatakse reaalajas vastavalt vaatenurgale. Kauguse udu hajutab punktipilve servad sujuvalt horisondihämusse."
            )
        )
        lbl_sky_help.setStyleSheet("color: #94a3b8; font-size: 11px;")
        lbl_sky_help.setWordWrap(True)
        layout_sky.addWidget(lbl_sky_help)

        layout.addWidget(grp_sky)

        # Bottom Buttons
        btn_box = QHBoxLayout()
        btn_box.addStretch()
        self.btn_save = QPushButton(tr("settings_btn_save"))
        self.btn_save.setDefault(True)
        self.btn_save.clicked.connect(self.save_settings)
        self.btn_cancel = QPushButton(tr("settings_btn_cancel"))
        self.btn_cancel.clicked.connect(self.reject)
        btn_box.addWidget(self.btn_save)
        btn_box.addWidget(self.btn_cancel)
        layout.addLayout(btn_box)

    def load_settings(self):
        settings = QgsSettings()
        # Language
        current_lang = I18n.get_language()
        idx_lang = self.combo_lang.findData(current_lang)
        if idx_lang >= 0:
            self.combo_lang.setCurrentIndex(idx_lang)

        # Flight preference
        pref = settings.value("maru_als/flight_preference", PREF_LATEST_ANY)
        idx_pref = self.combo_pref.findData(pref)
        if idx_pref >= 0:
            self.combo_pref.setCurrentIndex(idx_pref)

        # Cache dir
        self.edit_cache_dir.setText(CacheManager.get_cache_dir())

        # View settings
        self.chk_auto_3d.setChecked(settings.value("maru_als/auto_open_3d", False, type=bool))
        self.chk_rotate_2d.setChecked(settings.value("maru_als/rotate_2d", False, type=bool))
        eng = settings.value("maru_als/render_engine", "auto")
        idx_eng = self.combo_engine.findData(eng)
        self.combo_engine.setCurrentIndex(max(0, idx_eng))

        # Skybox & Horizon mode list (Off by default)
        sky_mode = settings.value("maru_als/sky_mode", None)
        if sky_mode is None:
            if settings.value("maru_als/sky_panorama", False, type=bool):
                sky_mode = "panorama_fog" if settings.value("maru_als/sky_fog", False, type=bool) else "panorama"
            elif settings.value("maru_als/sky_procedural", False, type=bool):
                sky_mode = "procedural_fog" if settings.value("maru_als/sky_fog", False, type=bool) else "procedural"
            elif settings.value("maru_als/sky_fog", False, type=bool):
                sky_mode = "fog"
            else:
                sky_mode = "off"

        idx = self.combo_sky.findData(sky_mode)
        self.combo_sky.setCurrentIndex(max(0, idx))

    def save_settings(self):
        settings = QgsSettings()

        # Language
        selected_lang = self.combo_lang.currentData()
        I18n.set_language(selected_lang)

        # Flight preference
        selected_pref = self.combo_pref.currentData()
        settings.setValue("maru_als/flight_preference", selected_pref)

        # Cache dir
        new_cache_dir = self.edit_cache_dir.text().strip()
        if new_cache_dir:
            CacheManager.set_cache_dir(new_cache_dir)

        # View settings
        settings.setValue("maru_als/auto_open_3d", self.chk_auto_3d.isChecked())
        settings.setValue("maru_als/rotate_2d", self.chk_rotate_2d.isChecked())
        settings.setValue("maru_als/render_engine", self.combo_engine.currentData() or "auto")

        # Skybox & Horizon mode setting
        chosen_sky = self.combo_sky.currentData() or "off"
        settings.setValue("maru_als/sky_mode", chosen_sky)
        # Compatibility keys
        settings.setValue("maru_als/sky_procedural", chosen_sky in ("procedural", "procedural_fog"))
        settings.setValue("maru_als/sky_panorama", chosen_sky in ("panorama", "panorama_fog"))
        settings.setValue("maru_als/sky_fog", chosen_sky in ("fog", "procedural_fog", "panorama_fog"))

        self.accept()

    def browse_cache_dir(self):
        current = self.edit_cache_dir.text().strip()
        folder = QFileDialog.getExistingDirectory(self, tr("settings_cache_dir"), current)
        if folder:
            self.edit_cache_dir.setText(folder)

    def clear_cache(self):
        reply = QMessageBox.question(
            self,
            tr("settings_cache_clear"),
            "Kas soovid kindlasti vahemälust kõik allalaaditud LAZ failid kustutada?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No if hasattr(QMessageBox, 'StandardButton') else QMessageBox.Yes | QMessageBox.No
        )
        yes_btn = QMessageBox.StandardButton.Yes if hasattr(QMessageBox, 'StandardButton') else QMessageBox.Yes
        if reply == yes_btn:
            CacheManager.clear_cache()
            self.lbl_cache_size.setText(tr("settings_cache_usage", size=CacheManager.get_cache_size_str()))
            QMessageBox.information(self, tr("settings_title"), tr("settings_cache_cleared"))
