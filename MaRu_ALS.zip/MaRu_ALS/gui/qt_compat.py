# -*- coding: utf-8 -*-
"""
Qt6 / QGIS 4+ UI Constants and Compatibility.
Strictly native to QGIS 4.x and PyQt6.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAbstractItemView

# Dock Widget Areas
LeftDockWidgetArea = Qt.DockWidgetArea.LeftDockWidgetArea
RightDockWidgetArea = Qt.DockWidgetArea.RightDockWidgetArea
TopDockWidgetArea = Qt.DockWidgetArea.TopDockWidgetArea
BottomDockWidgetArea = Qt.DockWidgetArea.BottomDockWidgetArea

# Alignment Flags
AlignCenter = Qt.AlignmentFlag.AlignCenter
AlignLeft = Qt.AlignmentFlag.AlignLeft
AlignRight = Qt.AlignmentFlag.AlignRight

# Selection Behavior
SelectRows = QAbstractItemView.SelectionBehavior.SelectRows

# Cursor Shapes
CursorCross = Qt.CursorShape.CrossCursor
CursorArrow = Qt.CursorShape.ArrowCursor

# Pen Styles
PenSolidLine = Qt.PenStyle.SolidLine
PenDashLine = Qt.PenStyle.DashLine

# Mouse Buttons
MouseButtonLeft = Qt.MouseButton.LeftButton
MouseButtonRight = Qt.MouseButton.RightButton

# Item Data Roles
UserRole = Qt.ItemDataRole.UserRole

# Window Types & Attributes
FramelessWindowHint = Qt.WindowType.FramelessWindowHint
WindowTool = Qt.WindowType.Tool
WindowStaysOnTopHint = Qt.WindowType.WindowStaysOnTopHint
WA_TranslucentBackground = Qt.WidgetAttribute.WA_TranslucentBackground
WA_TransparentForMouseEvents = Qt.WidgetAttribute.WA_TransparentForMouseEvents
WA_ShowWithoutActivating = Qt.WidgetAttribute.WA_ShowWithoutActivating
