# -*- coding: utf-8 -*-
"""
Dockable widget panel for managing flight years and layers for detected 1:2000 grid tiles.
Allows inspecting all flight history per tile and switching between years/types.
"""

from typing import Dict, List, Optional
from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTreeWidget,
    QTreeWidgetItem,
    QPushButton,
    QLabel,
    QHeaderView,
    QMessageBox
)
from qgis.core import QgsProject, QgsPointCloudLayer

from ..core.geoportaal_api import AlsFileInfo
from ..core.cache_manager import CacheManager
from ..core.downloader import load_pointcloud_layer
from ..i18n import tr
from .qt_compat import SelectRows, AlignCenter, LeftDockWidgetArea, RightDockWidgetArea, UserRole


class AlsLayerManagerDock(QDockWidget):
    """Dock widget listing all queried 1:2000 tiles and their multi-year flight versions."""

    # Signal requested when user wants to load/download a specific file
    load_file_requested = pyqtSignal(object)  # AlsFileInfo
    load_all_requested = pyqtSignal()         # Download all tiles along arrow

    def __init__(self, parent=None):
        super().__init__(tr("dock_title"), parent)
        self.setObjectName("AlsLayerManagerDock")
        self.setAllowedAreas(LeftDockWidgetArea | RightDockWidgetArea)

        # Store session data: tile_id -> List[AlsFileInfo]
        self.session_data: Dict[str, List[AlsFileInfo]] = {}

        self.init_ui()

    def init_ui(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        # Session summary header
        self.header_label = QLabel(tr("dock_section_session_tiles"))
        font = self.header_label.font()
        font.setBold(True)
        self.header_label.setFont(font)
        layout.addWidget(self.header_label)

        # Tree widget
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels([
            tr("dock_col_year"),
            tr("dock_col_type"),
            tr("dock_col_size"),
            tr("dock_col_status")
        ])
        if SelectRows:
            self.tree.setSelectionBehavior(SelectRows)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch if hasattr(QHeaderView, 'ResizeMode') else QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents if hasattr(QHeaderView, 'ResizeMode') else QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents if hasattr(QHeaderView, 'ResizeMode') else QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents if hasattr(QHeaderView, 'ResizeMode') else QHeaderView.ResizeToContents)
        self.tree.itemDoubleClicked.connect(self.on_item_double_clicked)
        layout.addWidget(self.tree)

        # Buttons
        btn_layout = QHBoxLayout()
        self.btn_load = QPushButton(tr("dock_btn_load_selected"))
        self.btn_load.clicked.connect(self.on_load_selected_clicked)
        btn_layout.addWidget(self.btn_load)

        self.btn_load_all = QPushButton("Lae alla kõik ruudud")
        self.btn_load_all.setToolTip("Lae alla ja ava kõigi valitud ruutude uusimad LAZ kihid")
        self.btn_load_all.clicked.connect(self.load_all_requested.emit)
        btn_layout.addWidget(self.btn_load_all)

        self.btn_clear = QPushButton(tr("dock_btn_clear_all"))
        self.btn_clear.clicked.connect(self.clear_all)
        btn_layout.addWidget(self.btn_clear)
        layout.addLayout(btn_layout)

        self.setWidget(container)

    def retranslate_ui(self):
        """Update strings on language change."""
        self.setWindowTitle(tr("dock_title"))
        self.header_label.setText(tr("dock_section_session_tiles"))
        self.tree.setHeaderLabels([
            tr("dock_col_year"),
            tr("dock_col_type"),
            tr("dock_col_size"),
            tr("dock_col_status")
        ])
        self.btn_load.setText(tr("dock_btn_load_selected"))
        self.btn_clear.setText(tr("dock_btn_clear_all"))
        self.refresh_tree_statuses()

    def add_tile_files(self, tile_id: str, files: List[AlsFileInfo]):
        """Adds or updates the list of available flights for a given 1:2000 tile."""
        self.session_data[tile_id] = files

        # Find or create root item for this tile
        root_item = None
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            if top.text(0).startswith(tile_id):
                root_item = top
                break

        if not root_item:
            root_item = QTreeWidgetItem(self.tree)
            self.tree.addTopLevelItem(root_item)

        root_item.setText(0, f"{tr('dock_col_tile')}: {tile_id} ({len(files)} lendu)")
        root_item.setExpanded(True)
        root_font = root_item.font(0)
        root_font.setBold(True)
        root_item.setFont(0, root_font)

        # Clear existing children and re-populate
        root_item.takeChildren()

        for f_info in files:
            child = QTreeWidgetItem(root_item)
            child.setText(0, f"{f_info.year} ({f_info.filename})")
            
            # Flight type
            type_text = tr("dock_type_tava") if f_info.flight_type == "tava" else (
                tr("dock_type_mets") if f_info.flight_type == "mets" else f_info.flight_type
            )
            child.setText(1, type_text)
            child.setText(2, f_info.size_str)
            child.setData(0, UserRole, f_info)

            # Determine status
            self._update_item_status(child, f_info)

    def _update_item_status(self, item: QTreeWidgetItem, f_info: AlsFileInfo):
        """Sets status text and color based on whether layer is on canvas or cached."""
        is_loaded = False
        target_name = f_info.filename.replace(".laz", "")
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsPointCloudLayer):
                if f_info.filename in lyr.source() or lyr.name() == target_name:
                    is_loaded = True
                    break

        if is_loaded:
            item.setText(3, tr("dock_status_loaded"))
            item.setForeground(3, QColor(34, 139, 34))  # Forest Green
            font = item.font(3)
            font.setBold(True)
            item.setFont(3, font)
        elif CacheManager.is_cached(f_info.filename):
            item.setText(3, tr("dock_status_cached"))
            item.setForeground(3, QColor(70, 130, 180))  # Steel Blue
        else:
            item.setText(3, tr("dock_status_available"))
            item.setForeground(3, QColor(100, 100, 100)) # Gray

    def refresh_tree_statuses(self):
        """Refreshes status labels across the tree."""
        user_role = UserRole
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            for j in range(top.childCount()):
                child = top.child(j)
                f_info = child.data(0, user_role)
                if isinstance(f_info, AlsFileInfo):
                    self._update_item_status(child, f_info)

    def on_load_selected_clicked(self):
        item = self.tree.currentItem()
        if not item:
            return
        user_role = UserRole
        f_info = item.data(0, user_role)
        if isinstance(f_info, AlsFileInfo):
            self.load_file_requested.emit(f_info)

    def on_item_double_clicked(self, item: QTreeWidgetItem, column: int):
        user_role = UserRole
        f_info = item.data(0, user_role)
        if isinstance(f_info, AlsFileInfo):
            self.load_file_requested.emit(f_info)

    def clear_all(self):
        self.session_data.clear()
        self.tree.clear()
