# -*- coding: utf-8 -*-
"""
Next-Gen 3D Drone Flight Controller, Cockpit Dock Panel, HUD Telemetry Overlay,
Mini-Map Radar, and 3D Measurement Mode for MaRu ALS QGIS Plugin.
"""

import math
import time
from typing import List, Tuple, Optional, Set, Dict

from qgis.PyQt.QtCore import Qt, QTimer, QPoint, QRectF, QPointF, pyqtSignal, QObject
from qgis.PyQt.QtGui import (
    QPainter,
    QColor,
    QFont,
    QPen,
    QBrush,
    QVector3D,
    QPolygonF,
    QMouseEvent,
    QKeyEvent
)
from qgis.PyQt.QtWidgets import (
    QWidget,
    QDockWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QGroupBox,
    QGridLayout,
    QCheckBox,
    QFrame,
    QButtonGroup,
    QRadioButton
)
from qgis.core import (
    QgsPointXY,
    QgsVector3D,
    QgsProject,
    QgsPointCloudLayer,
    QgsGeometry
)

from ..core.grid_engine import GridEngine
from ..i18n import tr
from .qt_compat import (
    LeftDockWidgetArea,
    RightDockWidgetArea,
    AlignCenter,
    AlignLeft,
    AlignRight,
    PenDashLine,
    PenSolidLine,
    MouseButtonLeft,
    MouseButtonRight,
    UserRole,
    FramelessWindowHint,
    WindowTool,
    WindowStaysOnTopHint,
    WA_TranslucentBackground,
    WA_TransparentForMouseEvents,
    WA_ShowWithoutActivating
)


# Integer key constants for universal Qt5 / Qt6 / Windows compatibility
KEY_W = 87
KEY_S = 83
KEY_A = 65
KEY_D = 68
KEY_SPACE = 32
KEY_CTRL = 16777249   # Qt.Key_Control
KEY_SHIFT = 16777248  # Qt.Key_Shift
KEY_ALT = 16777251    # Qt.Key_Alt
KEY_M = 77
KEY_C = 67


class DroneMeasurementTool:
    """Handles 3D distance, slope, area, and volume calculation on point cloud canvas."""

    MODE_NONE = "none"
    MODE_DISTANCE = "distance"
    MODE_AREA = "area"
    MODE_VOLUME = "volume"

    def __init__(self):
        self.mode = self.MODE_NONE
        self.points: List[Tuple[float, float, float]] = []

    def set_mode(self, mode: str):
        self.mode = mode
        self.points.clear()

    def add_point(self, x: float, y: float, z: float):
        self.points.append((x, y, z))

    def clear(self):
        self.points.clear()

    def get_stats(self) -> dict:
        """Computes metrics based on active mode."""
        if self.mode == self.MODE_DISTANCE and len(self.points) >= 2:
            p1 = self.points[-2]
            p2 = self.points[-1]
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            dz = p2[2] - p1[2]
            dist_horiz = math.hypot(dx, dy)
            dist_3d = math.sqrt(dx*dx + dy*dy + dz*dz)
            slope_pct = (abs(dz) / dist_horiz * 100.0) if dist_horiz > 0.001 else 0.0
            slope_deg = math.degrees(math.atan2(abs(dz), dist_horiz)) if dist_horiz > 0.001 else 90.0

            return {
                "type": "distance",
                "points_count": len(self.points),
                "dist_3d": dist_3d,
                "dist_horiz": dist_horiz,
                "dz": dz,
                "slope_pct": slope_pct,
                "slope_deg": slope_deg
            }

        elif self.mode in (self.MODE_AREA, self.MODE_VOLUME) and len(self.points) >= 3:
            # 2D projected polygon area
            n = len(self.points)
            area_2d = 0.0
            perimeter = 0.0
            z_vals = [p[2] for p in self.points]
            avg_z = sum(z_vals) / n
            min_z = min(z_vals)
            max_z = max(z_vals)

            for i in range(n):
                j = (i + 1) % n
                p1, p2 = self.points[i], self.points[j]
                area_2d += p1[0] * p2[1] - p2[0] * p1[1]
                perimeter += math.hypot(p2[0] - p1[0], p2[1] - p1[1])

            area_2d = abs(area_2d) * 0.5
            area_ha = area_2d / 10000.0
            volume = area_2d * max(0.5, (avg_z - min_z))

            return {
                "type": self.mode,
                "points_count": n,
                "area_m2": area_2d,
                "area_ha": area_ha,
                "perimeter": perimeter,
                "volume_m3": volume,
                "dz_range": max_z - min_z
            }

        return {"type": self.mode, "points_count": len(self.points)}


class DroneRadarWidget(QWidget):
    """
    Dedicated 2D Radar Widget showing 1:2000 grid tiles, drone flight path trail,
    and drone symbol in real time. Can be embedded in dock panels or dialogs.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(220, 200)

        self.cur_x = 0.0
        self.cur_y = 0.0
        self.heading = 0.0
        self.active_tile = ""
        self.known_tiles: Set[str] = set()
        self.flight_path: List[Tuple[float, float]] = []

    def update_state(self, x: float, y: float, heading: float, active_tile: str, known_tiles: Set[str], path: List[Tuple[float, float]]):
        self.cur_x = x
        self.cur_y = y
        self.heading = heading
        self.active_tile = active_tile
        self.known_tiles = known_tiles
        self.flight_path = path
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()

        # Background
        painter.setBrush(QBrush(QColor(15, 23, 42)))
        painter.setPen(QPen(QColor(51, 65, 85), 1))
        painter.drawRoundedRect(0, 0, w, h, 8, 8)

        cx = w / 2.0
        cy = h / 2.0
        view_radius = 1200.0  # 1.2 km view radius

        def to_radar_pt(world_x: float, world_y: float) -> QPointF:
            rx = cx + ((world_x - self.cur_x) / view_radius) * (cx - 15)
            ry = cy - ((world_y - self.cur_y) / view_radius) * (cy - 15)
            return QPointF(rx, ry)

        # Concentric radar distance rings
        painter.setPen(QPen(QColor(30, 41, 59), 1))
        for r_m in (500.0, 1000.0):
            r_px = (r_m / view_radius) * (cx - 15)
            painter.drawEllipse(QPointF(cx, cy), r_px, r_px)

        # 1:2000 Grid Tiles
        for tile in self.known_tiles:
            t_rect = GridEngine.tile_to_rect(tile)
            if t_rect:
                p_tl = to_radar_pt(t_rect.xMinimum(), t_rect.yMaximum())
                p_br = to_radar_pt(t_rect.xMaximum(), t_rect.yMinimum())
                q_rect = QRectF(p_tl, p_br)

                is_active = (tile == self.active_tile)
                if is_active:
                    painter.setPen(QPen(QColor(14, 165, 233, 200), 1.5))
                    painter.setBrush(QBrush(QColor(14, 165, 233, 35)))
                else:
                    painter.setPen(QPen(QColor(71, 85, 105, 140), 1, PenDashLine))
                    painter.setBrush(QBrush(QColor(30, 41, 59, 30)))

                painter.drawRect(q_rect)
                painter.setPen(QColor(148, 163, 184, 180))
                painter.setFont(QFont("Segoe UI", 7))
                painter.drawText(q_rect, AlignCenter, tile)

        # Flight Breadcrumb Path
        if len(self.flight_path) >= 2:
            painter.setPen(QPen(QColor(250, 204, 21), 1.8))
            for i in range(len(self.flight_path) - 1):
                pt1 = to_radar_pt(self.flight_path[i][0], self.flight_path[i][1])
                pt2 = to_radar_pt(self.flight_path[i + 1][0], self.flight_path[i + 1][1])
                painter.drawLine(pt1, pt2)

        # Drone Center Symbol & Viewing Direction Frustum
        center_pt = QPointF(cx, cy)
        heading_rad = math.radians(self.heading)
        cone_len = 22.0
        cone_angle = math.radians(30.0)

        tip_x = cx + cone_len * math.sin(heading_rad)
        tip_y = cy - cone_len * math.cos(heading_rad)

        c1_x = cx + cone_len * math.sin(heading_rad - cone_angle)
        c1_y = cy - cone_len * math.cos(heading_rad - cone_angle)
        c2_x = cx + cone_len * math.sin(heading_rad + cone_angle)
        c2_y = cy - cone_len * math.cos(heading_rad + cone_angle)

        # Viewing cone
        cone_poly = QPolygonF([center_pt, QPointF(c1_x, c1_y), QPointF(tip_x, tip_y), QPointF(c2_x, c2_y)])
        painter.setPen(QPen(QColor(239, 68, 68, 140), 1))
        painter.setBrush(QBrush(QColor(239, 68, 68, 60)))
        painter.drawPolygon(cone_poly)

        # Drone core dot
        painter.setPen(QPen(QColor(255, 255, 255), 1.5))
        painter.setBrush(QBrush(QColor(239, 68, 68)))
        painter.drawEllipse(center_pt, 4.0, 4.0)

        # Compass cardinal marks
        painter.setPen(QColor(100, 116, 139))
        painter.setFont(QFont("Segoe UI", 7))
        painter.drawText(int(cx - 3), 13, "N")
        painter.drawText(int(cx - 3), h - 4, "S")
        painter.drawText(w - 12, int(cy + 3), "E")
        painter.drawText(4, int(cy + 3), "W")

        painter.end()


class DroneHudOverlay(QWidget):
    """
    Transparent HUD rendering on-screen telemetry, date badge in upper corner,
    controls cheat-sheet, mini-map, and 3D measurement info directly over the 3D scene.
    """

    def __init__(self, controller: 'DroneFlightController', canvas_3d, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.canvas_3d = canvas_3d

        # Make overlay a floating transparent tool window staying on top
        self.setWindowFlags(
            FramelessWindowHint |
            WindowTool |
            WindowStaysOnTopHint
        )
        self.setAttribute(WA_TranslucentBackground, True)
        self.setAttribute(WA_TransparentForMouseEvents, True)
        self.setAttribute(WA_ShowWithoutActivating, True)

        self.sync_geometry_with_canvas()

    def sync_geometry_with_canvas(self):
        """Synchronizes overlay screen geometry with Qgs3DMapCanvas window."""
        if not self.canvas_3d:
            return
        try:
            # QWindow position & size in global coordinates
            pos = self.canvas_3d.position()
            sz = self.canvas_3d.size()
            if sz.width() > 50 and sz.height() > 50:
                self.setGeometry(pos.x(), pos.y(), sz.width(), sz.height())
        except Exception:
            pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        ctrl = self.controller
        w = self.width()
        h = self.height()

        # 1. Top-Left Box: Data Date & Active Tile (Upper corner requirement)
        self.draw_top_left_badge(painter, ctrl)

        # 2. Top-Center Bar: Controls Helper
        self.draw_controls_helper(painter, w)

        # 3. Bottom-Left Box: Flight Telemetry & Compass
        self.draw_telemetry_box(painter, ctrl, h)

        # 4. Center Measurement Overlay (if active)
        if ctrl.measure_tool.mode != DroneMeasurementTool.MODE_NONE:
            self.draw_measurement_overlay(painter, ctrl, w, h)

        painter.end()

    def draw_top_left_badge(self, p: QPainter, ctrl: 'DroneFlightController'):
        """Draws flight dataset date, title, and current 1:2000 tile code in upper corner."""
        rect = QRectF(14, 14, 260, 72)
        p.setPen(QPen(QColor(56, 189, 248, 180), 1.5))
        p.setBrush(QBrush(QColor(15, 23, 42, 215)))
        p.drawRoundedRect(rect, 8, 8)

        # Title
        p.setPen(QColor(248, 250, 252))
        f_title = QFont("Segoe UI", 9)
        f_title.setBold(True)
        p.setFont(f_title)
        p.drawText(26, 36, "MaRu ALS 3D Droonilend")

        # Flight info & Active tile
        p.setPen(QColor(56, 189, 248))
        f_info = QFont("Segoe UI", 8)
        p.setFont(f_info)
        p.drawText(26, 54, f"Lennuinfo: {ctrl.data_label}")
        p.setPen(QColor(148, 163, 184))
        p.drawText(26, 72, f"Kaardiruut: {ctrl.active_tile if ctrl.active_tile else '---'}")

    def draw_controls_helper(self, p: QPainter, w: int):
        """Draws top controls cheat-sheet."""
        bw = 560
        bh = 32
        rect = QRectF((w - bw) / 2.0, 14, bw, bh)
        p.setPen(QPen(QColor(100, 116, 139, 140), 1))
        p.setBrush(QBrush(QColor(15, 23, 42, 195)))
        p.drawRoundedRect(rect, 6, 6)

        p.setPen(QColor(226, 232, 240))
        p.setFont(QFont("Segoe UI", 8))
        text = "[W][A][S][D] Lend | [Tühik] Tõus | [Ctrl] Lasku | [Shift] Kiirendus | [M] Mõõda | [Hiir] Pööra"
        p.drawText(rect, AlignCenter, text)

    def draw_telemetry_box(self, p: QPainter, ctrl: 'DroneFlightController', h: int):
        """Draws altitude, speed, coordinates, and mini compass."""
        bw = 280
        bh = 135
        rect = QRectF(14, h - bh - 14, bw, bh)
        p.setPen(QPen(QColor(56, 189, 248, 180), 1.5))
        p.setBrush(QBrush(QColor(15, 23, 42, 215)))
        p.drawRoundedRect(rect, 8, 8)

        base_x = 24
        base_y = h - bh + 6

        # Header
        p.setPen(QColor(248, 250, 252))
        f_tele = QFont("Segoe UI", 9)
        f_tele.setBold(True)
        p.setFont(f_tele)
        p.drawText(base_x, base_y + 16, "TELEMEETRIA")

        p.setFont(QFont("Segoe UI", 8))
        p.setPen(QColor(226, 232, 240))
        p.drawText(base_x, base_y + 36, f"Kõrgus (H): {ctrl.altitude:.1f} m")
        p.drawText(base_x, base_y + 54, f"Kiirus: {ctrl.speed:.1f} km/h")

        dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
        dir_idx = int((ctrl.heading + 22.5) / 45.0) % 8
        dir_name = dirs[dir_idx]
        p.drawText(base_x, base_y + 72, f"Suund: {ctrl.heading:.1f}° ({dir_name})")
        p.drawText(base_x, base_y + 90, f"X: {ctrl.pos_x:.1f} m")
        p.drawText(base_x, base_y + 108, f"Y: {ctrl.pos_y:.1f} m")

        # Compass Rose
        cx = 14 + bw - 44
        cy = h - bh / 2.0 - 5
        r = 24.0
        p.setPen(QPen(QColor(100, 116, 139), 1))
        p.setBrush(QBrush(QColor(30, 41, 59)))
        p.drawEllipse(QPointF(cx, cy), r, r)

        needle_rad = math.radians(-ctrl.heading)
        nx = cx + (r - 4) * math.sin(needle_rad)
        ny = cy - (r - 4) * math.cos(needle_rad)
        p.setPen(QPen(QColor(239, 68, 68), 2.5))
        p.drawLine(QPointF(cx, cy), QPointF(nx, ny))
        p.setPen(QColor(239, 68, 68))
        p.setFont(QFont("Segoe UI", 6))
        p.drawText(int(nx - 3), int(ny - 3), "N")

    def draw_measurement_overlay(self, p: QPainter, ctrl: 'DroneFlightController', w: int, h: int):
        """Draws 3D measurement stats box."""
        stats = ctrl.measure_tool.get_stats()
        mode = ctrl.measure_tool.mode

        bw = 340
        bh = 110
        rect = QRectF((w - bw) / 2.0, h - bh - 14, bw, bh)
        p.setPen(QPen(QColor(34, 211, 238), 1.5))
        p.setBrush(QBrush(QColor(8, 51, 68, 235)))
        p.drawRoundedRect(rect, 8, 8)

        p.setPen(QColor(34, 211, 238))
        f_m = QFont("Segoe UI", 9)
        f_m.setBold(True)
        p.setFont(f_m)
        mode_str = "Kaugus & Kalle" if mode == DroneMeasurementTool.MODE_DISTANCE else (
            "Pindala" if mode == DroneMeasurementTool.MODE_AREA else "Maht"
        )
        p.drawText(int(rect.x() + 16), int(rect.y() + 24), f"3D MÕÕTMISREŽIIM: {mode_str}")

        p.setFont(QFont("Segoe UI", 8))
        p.setPen(QColor(224, 242, 254))
        pts_cnt = len(ctrl.measure_tool.points)
        p.drawText(int(rect.x() + 16), int(rect.y() + 44), f"Punktid: {pts_cnt} (Klõpsa lisamiseks, [C] tühjenda, [M] vaheta)")

        if stats.get("type") == "distance":
            p.drawText(int(rect.x() + 16), int(rect.y() + 64), f"3D Kaugus: {stats['dist_3d']:.2f} m | Horisontaalne: {stats['dist_horiz']:.2f} m")
            p.drawText(int(rect.x() + 16), int(rect.y() + 84), f"Kõrguste vahe (ΔZ): {stats['dz']:.2f} m | Kalle: {stats['slope_deg']:.1f}° ({stats['slope_pct']:.1f}%)")

        elif stats.get("type") in ("area", "volume"):
            p.drawText(int(rect.x() + 16), int(rect.y() + 64), f"Pindala: {stats['area_m2']:.1f} m² ({stats['area_ha']:.3f} ha) | Ümbermõõt: {stats['perimeter']:.1f} m")
            p.drawText(int(rect.x() + 16), int(rect.y() + 84), f"Hinnanguline maht: {stats['volume_m3']:.1f} m³ (ΔZ: {stats['dz_range']:.1f} m)")


class DroneFlightController(QObject):
    """
    Simulates real-time 6-DOF drone flight with WASD + Space (climb) + Left Ctrl (descend)
    and mouse gimbal movement on a QGIS 3D Canvas.
    """

    # Emitted when the drone flies into or near a new tile that needs streaming
    tile_stream_needed = pyqtSignal(str)
    # Emitted on each flight frame with telemetry info
    telemetry_updated = pyqtSignal(dict)
    # Emitted when measurement stats change
    measurement_updated = pyqtSignal(dict)

    BASE_SPEED = 28.0       # m/s (~100 km/h)
    TURBO_FACTOR = 3.0      # Shift key speed multiplier
    PRECISION_FACTOR = 0.35 # Alt key slow-motion
    MOUSE_SENSITIVITY = 0.22

    def __init__(self, canvas_3d, parent=None):
        super().__init__(parent)
        self.canvas_3d = canvas_3d
        self.camera_ctrl = canvas_3d.cameraController() if hasattr(canvas_3d, 'cameraController') else None

        self.keys_pressed: Set[int] = set()
        self.is_flying = False
        self.last_time = time.time()
        self.last_mouse_pos: Optional[QPoint] = None
        self.is_mouse_looking = False

        # Flight telemetry state
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.altitude = 60.0
        self.heading = 0.0
        self.pitch = 25.0
        self.speed = 0.0
        self.active_tile = ""
        self.data_label = "Maa-amet ALS 3D"

        # Traversed path breadcrumbs: List[(x, y)]
        self.flight_path: List[Tuple[float, float]] = []
        self.last_path_pos: Optional[Tuple[float, float]] = None

        # Known loaded or streaming tiles
        self.known_tiles: Set[str] = set()

        # Measurement tool
        self.measure_tool = DroneMeasurementTool()

        # 60 FPS flight update loop
        self.timer = QTimer(self)
        self.timer.setInterval(16)
        self.timer.timeout.connect(self.flight_loop)

        # Translucent HUD Overlay on top of 3D Scene
        self.overlay = DroneHudOverlay(self, canvas_3d)

        # Install event filter directly on canvas_3d (QWindow)
        if self.canvas_3d:
            try:
                self.canvas_3d.installEventFilter(self)
            except Exception:
                pass

    def start_flight(self):
        """Activates drone controls, timer, and HUD overlay."""
        self.is_flying = True
        self.last_time = time.time()
        self.read_camera_state()
        self.overlay.sync_geometry_with_canvas()
        self.overlay.show()
        self.overlay.raise_()
        self.timer.start()

    def stop_flight(self):
        """Stops the flight loop and hides HUD."""
        self.is_flying = False
        self.timer.stop()
        self.keys_pressed.clear()
        self.overlay.hide()

    def set_data_label(self, label: str):
        self.data_label = label
        if self.overlay:
            self.overlay.update()

    def add_known_tile(self, tile_id: str):
        self.known_tiles.add(tile_id)

    def read_camera_state(self):
        """Reads initial position and orientation from QGIS camera controller."""
        if not self.camera_ctrl:
            return
        try:
            pose = self.camera_ctrl.cameraPose()
            cp = pose.centerPoint()
            self.pos_x = cp.x()
            self.pos_y = cp.y()
            self.altitude = cp.z()
            self.heading = pose.headingAngle()
            self.pitch = pose.pitchAngle()
            self.active_tile = GridEngine.point_to_tile(self.pos_x, self.pos_y)
        except Exception:
            pass

    def eventFilter(self, watched, event) -> bool:
        """Intercepts keyboard and mouse events on Qgs3DMapCanvas for drone flight."""
        if not self.is_flying:
            return False

        t = event.type()
        t_val = t.value if hasattr(t, 'value') else int(t)

        # 6 = KeyPress, 7 = KeyRelease
        # 2 = MouseButtonPress, 3 = MouseButtonRelease, 5 = MouseMove
        if t_val == 6:
            return self.handle_key_press(event)
        elif t_val == 7:
            return self.handle_key_release(event)
        elif t_val == 2:
            return self.handle_mouse_press(event)
        elif t_val == 3:
            return self.handle_mouse_release(event)
        elif t_val == 5:
            return self.handle_mouse_move(event)

        return False

    def handle_key_press(self, event: QKeyEvent) -> bool:
        k = event.key()
        self.keys_pressed.add(k)

        # 'M' key: cycle measurement modes
        if k == KEY_M:
            curr_mode = self.measure_tool.mode
            if curr_mode == DroneMeasurementTool.MODE_NONE:
                self.measure_tool.set_mode(DroneMeasurementTool.MODE_DISTANCE)
            elif curr_mode == DroneMeasurementTool.MODE_DISTANCE:
                self.measure_tool.set_mode(DroneMeasurementTool.MODE_AREA)
            elif curr_mode == DroneMeasurementTool.MODE_AREA:
                self.measure_tool.set_mode(DroneMeasurementTool.MODE_VOLUME)
            else:
                self.measure_tool.set_mode(DroneMeasurementTool.MODE_NONE)

            self.measurement_updated.emit(self.measure_tool.get_stats())
            self.overlay.update()
            return True

        # 'C' key: clear measurement
        if k == KEY_C:
            self.measure_tool.clear()
            self.measurement_updated.emit(self.measure_tool.get_stats())
            self.overlay.update()
            return True

        flight_keys = (KEY_W, KEY_S, KEY_A, KEY_D, KEY_SPACE, KEY_CTRL, KEY_SHIFT, KEY_ALT)
        if k in flight_keys:
            return True

        return False

    def handle_key_release(self, event: QKeyEvent) -> bool:
        k = event.key()
        if k in self.keys_pressed:
            self.keys_pressed.remove(k)
            return True
        return False

    def handle_mouse_press(self, event: QMouseEvent) -> bool:
        btn = event.button()
        left_btn = MouseButtonLeft

        # Add 3D measurement point on left click if in measurement mode
        if btn == left_btn and self.measure_tool.mode != DroneMeasurementTool.MODE_NONE:
            self.measure_tool.add_point(self.pos_x, self.pos_y, self.altitude)
            self.measurement_updated.emit(self.measure_tool.get_stats())
            self.overlay.update()
            return True

        self.is_mouse_looking = True
        self.last_mouse_pos = event.pos()
        return True

    def handle_mouse_release(self, event: QMouseEvent) -> bool:
        self.is_mouse_looking = False
        self.last_mouse_pos = None
        return True

    def handle_mouse_move(self, event: QMouseEvent) -> bool:
        if not self.is_mouse_looking or not self.last_mouse_pos or not self.camera_ctrl:
            return False

        curr_pos = event.pos()
        dx = curr_pos.x() - self.last_mouse_pos.x()
        dy = curr_pos.y() - self.last_mouse_pos.y()
        self.last_mouse_pos = curr_pos

        diff_yaw = dx * self.MOUSE_SENSITIVITY
        diff_pitch = -dy * self.MOUSE_SENSITIVITY

        try:
            if hasattr(self.camera_ctrl, 'rotateCamera'):
                self.camera_ctrl.rotateCamera(diff_pitch, diff_yaw)
            self.heading = (self.heading + diff_yaw + 360.0) % 360.0
            self.pitch = max(-85.0, min(85.0, self.pitch + diff_pitch))
        except Exception:
            pass

        self.overlay.update()
        return True

    def flight_loop(self):
        """Continuous physical update tick for 60 FPS drone movement and auto-streaming."""
        now = time.time()
        dt = min(now - self.last_time, 0.1)
        self.last_time = now

        if not self.camera_ctrl or not self.is_flying:
            return

        # Keep overlay sized to canvas
        self.overlay.sync_geometry_with_canvas()

        # Speed modifiers
        speed = self.BASE_SPEED
        if KEY_SHIFT in self.keys_pressed:
            speed *= self.TURBO_FACTOR
        elif KEY_ALT in self.keys_pressed:
            speed *= self.PRECISION_FACTOR

        # Directional vectors based on current heading (yaw)
        rad = math.radians(self.heading)
        f_x = math.sin(rad)
        f_y = math.cos(rad)
        r_x = math.cos(rad)
        r_y = -math.sin(rad)

        move_x = 0.0
        move_y = 0.0
        move_z = 0.0

        if KEY_W in self.keys_pressed:
            move_x += f_x
            move_y += f_y
        if KEY_S in self.keys_pressed:
            move_x -= f_x
            move_y -= f_y
        if KEY_D in self.keys_pressed:
            move_x += r_x
            move_y += r_y
        if KEY_A in self.keys_pressed:
            move_x -= r_x
            move_y -= r_y
        if KEY_SPACE in self.keys_pressed:
            move_z += 1.0
        if KEY_CTRL in self.keys_pressed:
            move_z -= 1.0

        is_moving = (move_x != 0.0 or move_y != 0.0 or move_z != 0.0)

        if is_moving:
            mag = math.sqrt(move_x*move_x + move_y*move_y + move_z*move_z)
            if mag > 0:
                step = speed * dt
                dx = (move_x / mag) * step
                dy = (move_y / mag) * step
                dz = (move_z / mag) * step

                try:
                    if hasattr(self.camera_ctrl, 'moveCenterPoint'):
                        self.camera_ctrl.moveCenterPoint(QVector3D(dx, dy, dz))
                except Exception:
                    pass

                self.pos_x += dx
                self.pos_y += dy
                self.altitude += dz
                self.speed = speed * 3.6  # km/h

                # Record breadcrumbs for mini-map
                if not self.last_path_pos or math.hypot(self.pos_x - self.last_path_pos[0], self.pos_y - self.last_path_pos[1]) > 8.0:
                    self.flight_path.append((self.pos_x, self.pos_y))
                    self.last_path_pos = (self.pos_x, self.pos_y)
                    if len(self.flight_path) > 600:
                        self.flight_path.pop(0)

                # Check auto-streaming ahead
                self.check_auto_streaming()
        else:
            self.speed = 0.0

        # Read actual pose from camera
        try:
            pose = self.camera_ctrl.cameraPose()
            cp = pose.centerPoint()
            self.pos_x = cp.x()
            self.pos_y = cp.y()
            self.altitude = cp.z()
            self.heading = pose.headingAngle()
            self.pitch = pose.pitchAngle()
            self.active_tile = GridEngine.point_to_tile(self.pos_x, self.pos_y)
        except Exception:
            pass

        # Broadcast telemetry
        self.telemetry_updated.emit({
            "x": self.pos_x,
            "y": self.pos_y,
            "altitude": self.altitude,
            "heading": self.heading,
            "pitch": self.pitch,
            "speed": self.speed,
            "active_tile": self.active_tile,
            "known_tiles": self.known_tiles,
            "flight_path": self.flight_path
        })

        self.overlay.update()

    def check_auto_streaming(self):
        """Detects if drone is flying towards an adjacent 1:2000 tile and triggers streaming."""
        rad = math.radians(self.heading)
        look_ahead_x = self.pos_x + 350.0 * math.sin(rad)
        look_ahead_y = self.pos_y + 350.0 * math.cos(rad)

        ahead_tile = GridEngine.point_to_tile(look_ahead_x, look_ahead_y)
        if (GridEngine.is_valid_tile(ahead_tile) and
                ahead_tile not in self.known_tiles):
            self.known_tiles.add(ahead_tile)
            self.tile_stream_needed.emit(ahead_tile)


class AlsDroneFlightDock(QDockWidget):
    """
    Dedicated 3D Drone Flight Cockpit Panel for QGIS.
    Features Start/Stop toggle, live telemetry gauges, 3D measurement controls,
    embedded mini-map radar with breadcrumbs, and speed selector presets.
    """

    def __init__(self, parent=None, plugin=None):
        super().__init__(tr("drone_dock_title"), parent)
        self.plugin = plugin
        self.setObjectName("AlsDroneFlightDock")
        self.setAllowedAreas(LeftDockWidgetArea | RightDockWidgetArea)

        self.controller: Optional[DroneFlightController] = None
        self.init_ui()

    def init_ui(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        # 1. Main Action / Status Bar
        action_box = QHBoxLayout()
        self.btn_toggle_flight = QPushButton(tr("drone_btn_start"))
        self.btn_toggle_flight.setStyleSheet("""
            QPushButton {
                background-color: #0284c7;
                color: white;
                font-weight: bold;
                font-size: 11pt;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QPushButton:hover { background-color: #0369a1; }
        """)
        self.btn_toggle_flight.clicked.connect(self.on_toggle_flight_clicked)
        action_box.addWidget(self.btn_toggle_flight)

        self.lbl_status_badge = QLabel(tr("drone_status_idle"))
        self.lbl_status_badge.setAlignment(AlignCenter)
        self.lbl_status_badge.setStyleSheet("""
            QLabel {
                background-color: #334155;
                color: #94a3b8;
                font-weight: bold;
                padding: 6px 10px;
                border-radius: 4px;
            }
        """)
        action_box.addWidget(self.lbl_status_badge)
        layout.addLayout(action_box)

        # Speed presets
        speed_box = QHBoxLayout()
        self.btn_spd_walk = QPushButton("10 km/h (Jalgsi)")
        self.btn_spd_walk.clicked.connect(lambda: self.set_base_speed(3.0))
        speed_box.addWidget(self.btn_spd_walk)

        self.btn_spd_drone = QPushButton("50 km/h (Droon)")
        self.btn_spd_drone.clicked.connect(lambda: self.set_base_speed(14.0))
        speed_box.addWidget(self.btn_spd_drone)

        self.btn_spd_fast = QPushButton("100 km/h (Kiirlend)")
        self.btn_spd_fast.clicked.connect(lambda: self.set_base_speed(28.0))
        speed_box.addWidget(self.btn_spd_fast)
        layout.addLayout(speed_box)

        # 2. Live Telemetry GroupBox
        tele_group = QGroupBox(tr("drone_group_telemetry"))
        tele_layout = QGridLayout(tele_group)
        tele_layout.setContentsMargins(8, 8, 8, 8)
        tele_layout.setSpacing(4)

        # Large Altitude Readout
        self.lbl_val_alt = QLabel("--- m")
        self.lbl_val_alt.setStyleSheet("font-size: 14pt; font-weight: bold; color: #0284c7;")
        tele_layout.addWidget(QLabel(tr("drone_tele_altitude")), 0, 0)
        tele_layout.addWidget(self.lbl_val_alt, 0, 1)

        self.lbl_val_speed = QLabel("0.0 km/h")
        self.lbl_val_speed.setStyleSheet("font-weight: bold;")
        tele_layout.addWidget(QLabel(tr("drone_tele_speed")), 1, 0)
        tele_layout.addWidget(self.lbl_val_speed, 1, 1)

        self.lbl_val_heading = QLabel("0.0°")
        tele_layout.addWidget(QLabel(tr("drone_tele_heading")), 2, 0)
        tele_layout.addWidget(self.lbl_val_heading, 2, 1)

        self.lbl_val_pitch = QLabel("0.0°")
        tele_layout.addWidget(QLabel(tr("drone_tele_pitch")), 3, 0)
        tele_layout.addWidget(self.lbl_val_pitch, 3, 1)

        self.lbl_val_tile = QLabel("---")
        self.lbl_val_tile.setStyleSheet("font-weight: bold; color: #10b981;")
        tele_layout.addWidget(QLabel(tr("drone_tele_tile")), 4, 0)
        tele_layout.addWidget(self.lbl_val_tile, 4, 1)

        self.lbl_val_coords = QLabel("X: ---, Y: ---")
        tele_layout.addWidget(QLabel(tr("drone_tele_coords")), 5, 0)
        tele_layout.addWidget(self.lbl_val_coords, 5, 1)

        layout.addWidget(tele_group)

        # 3. 3D Measurement GroupBox
        measure_group = QGroupBox(tr("drone_group_measure"))
        measure_layout = QVBoxLayout(measure_group)
        measure_layout.setContentsMargins(8, 8, 8, 8)

        m_btn_layout = QHBoxLayout()
        self.rb_m_none = QRadioButton(tr("drone_measure_off"))
        self.rb_m_dist = QRadioButton(tr("drone_measure_dist"))
        self.rb_m_area = QRadioButton(tr("drone_measure_area"))
        self.rb_m_vol = QRadioButton(tr("drone_measure_vol"))
        self.rb_m_none.setChecked(True)

        self.btn_group_m = QButtonGroup(self)
        self.btn_group_m.addButton(self.rb_m_none, 0)
        self.btn_group_m.addButton(self.rb_m_dist, 1)
        self.btn_group_m.addButton(self.rb_m_area, 2)
        self.btn_group_m.addButton(self.rb_m_vol, 3)
        self.btn_group_m.idClicked.connect(self.on_measure_mode_changed)

        m_btn_layout.addWidget(self.rb_m_none)
        m_btn_layout.addWidget(self.rb_m_dist)
        m_btn_layout.addWidget(self.rb_m_area)
        m_btn_layout.addWidget(self.rb_m_vol)
        measure_layout.addLayout(m_btn_layout)

        # Measurement readout card
        self.lbl_measure_readout = QLabel("Mõõdistus väljas. Vali režiim ja klõpsa 3D vaates punktide lisamiseks.")
        self.lbl_measure_readout.setStyleSheet("background-color: #f1f5f9; padding: 6px; border-radius: 4px; color: #0f172a;")
        self.lbl_measure_readout.setWordWrap(True)
        measure_layout.addWidget(self.lbl_measure_readout)

        self.btn_clear_measure = QPushButton(tr("drone_measure_clear"))
        self.btn_clear_measure.clicked.connect(self.on_clear_measure_clicked)
        measure_layout.addWidget(self.btn_clear_measure)

        layout.addWidget(measure_group)

        # 4. Mini-Map Radar Widget
        radar_group = QGroupBox("Minikaart & Lennuteekond")
        radar_layout = QVBoxLayout(radar_group)
        radar_layout.setContentsMargins(6, 6, 6, 6)
        self.radar_widget = DroneRadarWidget(self)
        radar_layout.addWidget(self.radar_widget)
        layout.addWidget(radar_group)

        # 5. Auto-Streaming Checkbox
        self.cb_stream = QCheckBox(tr("drone_stream_checkbox"))
        self.cb_stream.setChecked(True)
        layout.addWidget(self.cb_stream)

        # 6. Controls reference cheat-sheet
        ctrl_label = QLabel(
            "<b>Spikker:</b> [W][S][A][D] lend | [Tühik] tõus | [Ctrl] lasku | [Hiir] pööra gimbalit | [Shift] turbo | [M] mõõda"
        )
        ctrl_label.setStyleSheet("color: #64748b; font-size: 8pt;")
        ctrl_label.setWordWrap(True)
        layout.addWidget(ctrl_label)

        layout.addStretch()
        self.setWidget(container)

    def attach_controller(self, controller: DroneFlightController):
        """Binds controller signals to cockpit widgets."""
        self.controller = controller
        controller.telemetry_updated.connect(self.on_telemetry_updated)
        controller.measurement_updated.connect(self.on_measurement_updated)
        self.update_flight_button_state()

    def set_base_speed(self, speed_mps: float):
        if self.controller:
            self.controller.BASE_SPEED = speed_mps

    def on_toggle_flight_clicked(self):
        if not self.controller and self.plugin:
            self.plugin.toggle_3d_view()

        if self.controller:
            if self.controller.is_flying:
                self.controller.stop_flight()
            else:
                self.controller.start_flight()
            self.update_flight_button_state()

    def update_flight_button_state(self):
        if self.controller and self.controller.is_flying:
            self.btn_toggle_flight.setText(tr("drone_btn_stop"))
            self.btn_toggle_flight.setStyleSheet("""
                QPushButton {
                    background-color: #dc2626;
                    color: white;
                    font-weight: bold;
                    font-size: 11pt;
                    padding: 6px 12px;
                    border-radius: 4px;
                }
                QPushButton:hover { background-color: #b91c1c; }
            """)
            self.lbl_status_badge.setText(tr("drone_status_flying"))
            self.lbl_status_badge.setStyleSheet("""
                QLabel {
                    background-color: #10b981;
                    color: white;
                    font-weight: bold;
                    padding: 6px 10px;
                    border-radius: 4px;
                }
            """)
        else:
            self.btn_toggle_flight.setText(tr("drone_btn_start"))
            self.btn_toggle_flight.setStyleSheet("""
                QPushButton {
                    background-color: #0284c7;
                    color: white;
                    font-weight: bold;
                    font-size: 11pt;
                    padding: 6px 12px;
                    border-radius: 4px;
                }
                QPushButton:hover { background-color: #0369a1; }
            """)
            self.lbl_status_badge.setText(tr("drone_status_idle"))
            self.lbl_status_badge.setStyleSheet("""
                QLabel {
                    background-color: #334155;
                    color: #94a3b8;
                    font-weight: bold;
                    padding: 6px 10px;
                    border-radius: 4px;
                }
            """)

    def on_telemetry_updated(self, data: dict):
        self.lbl_val_alt.setText(f"{data['altitude']:.1f} m")
        self.lbl_val_speed.setText(f"{data['speed']:.1f} km/h")
        self.lbl_val_heading.setText(f"{data['heading']:.1f}°")
        self.lbl_val_pitch.setText(f"{data['pitch']:.1f}°")
        self.lbl_val_tile.setText(data['active_tile'] if data['active_tile'] else "---")
        self.lbl_val_coords.setText(f"X: {data['x']:.0f}, Y: {data['y']:.0f}")

        # Update radar mini-map
        self.radar_widget.update_state(
            data['x'], data['y'], data['heading'], data['active_tile'],
            data['known_tiles'], data['flight_path']
        )

    def on_measure_mode_changed(self, btn_id: int):
        if not self.controller:
            return
        modes = {
            0: DroneMeasurementTool.MODE_NONE,
            1: DroneMeasurementTool.MODE_DISTANCE,
            2: DroneMeasurementTool.MODE_AREA,
            3: DroneMeasurementTool.MODE_VOLUME
        }
        self.controller.measure_tool.set_mode(modes.get(btn_id, DroneMeasurementTool.MODE_NONE))
        self.controller.overlay.update()
        self.on_measurement_updated(self.controller.measure_tool.get_stats())

    def on_clear_measure_clicked(self):
        if self.controller:
            self.controller.measure_tool.clear()
            self.controller.overlay.update()
            self.on_measurement_updated(self.controller.measure_tool.get_stats())

    def on_measurement_updated(self, stats: dict):
        m_type = stats.get("type", "none")
        pts = stats.get("points_count", 0)

        if m_type == DroneMeasurementTool.MODE_NONE:
            self.lbl_measure_readout.setText("Mõõdistus väljas. Vali režiim ja klõpsa 3D vaates punktide lisamiseks.")
        elif m_type == DroneMeasurementTool.MODE_DISTANCE:
            if pts < 2:
                self.lbl_measure_readout.setText(f"Kauguse mõõtmine: lisatud {pts}/2 punkti. Klõpsa 3D vaates teise punkti lisamiseks.")
            else:
                self.lbl_measure_readout.setText(
                    f"<b>3D Kaugus:</b> {stats['dist_3d']:.2f} m<br>"
                    f"<b>Horisontaalne:</b> {stats['dist_horiz']:.2f} m | <b>ΔZ:</b> {stats['dz']:.2f} m<br>"
                    f"<b>Kalle:</b> {stats['slope_deg']:.1f}° ({stats['slope_pct']:.1f}%)"
                )
        elif m_type in (DroneMeasurementTool.MODE_AREA, DroneMeasurementTool.MODE_VOLUME):
            if pts < 3:
                self.lbl_measure_readout.setText(f"Pindala/Mahumõõtmine: lisatud {pts}/3 punkti. Klõpsa hulknurga moodustamiseks.")
            else:
                self.lbl_measure_readout.setText(
                    f"<b>Pindala:</b> {stats['area_m2']:.1f} m² ({stats['area_ha']:.3f} ha)<br>"
                    f"<b>Ümbermõõt:</b> {stats['perimeter']:.1f} m | <b>ΔZ:</b> {stats['dz_range']:.1f} m<br>"
                    f"<b>Hinnanguline maht:</b> {stats['volume_m3']:.1f} m³"
                )
