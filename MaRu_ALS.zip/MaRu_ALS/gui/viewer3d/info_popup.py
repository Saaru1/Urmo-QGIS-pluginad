# -*- coding: utf-8 -*-
"""
Floating, fixed-size, scrollable Attribute Table Pop-up for 3D Info Mode.

Displays feature attribute key-value pairs top-to-bottom with live search filter,
draggable header bar, copyable text, and close action.
"""

import datetime
import re
from typing import Any, Dict, Optional, Tuple

from qgis.PyQt.QtCore import QDate, QDateTime, QPoint, Qt, QTime, QVariant, pyqtSignal
from qgis.PyQt.QtGui import QBrush, QColor, QFont, QMouseEvent, QPalette
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


def format_attr_val(raw_val: Any) -> Tuple[str, bool]:
    """Formats attribute value into clean display string and returns (str, is_null)."""
    if raw_val is None or raw_val == "":
        return "NULL", True
    if isinstance(raw_val, QVariant):
        if raw_val.isNull():
            return "NULL", True
        raw_val = raw_val.value()
        if raw_val is None or raw_val == "":
            return "NULL", True

    if isinstance(raw_val, QDate):
        if not raw_val.isValid():
            return "NULL", True
        return raw_val.toString(Qt.DateFormat.ISODate), False
    elif isinstance(raw_val, QDateTime):
        if not raw_val.isValid():
            return "NULL", True
        return raw_val.toString("yyyy-MM-dd HH:mm:ss"), False
    elif isinstance(raw_val, QTime):
        if not raw_val.isValid():
            return "NULL", True
        return raw_val.toString("HH:mm:ss"), False
    elif isinstance(raw_val, (datetime.datetime, datetime.date)):
        return raw_val.isoformat(), False

    val_str = str(raw_val).strip()
    if val_str.lower() in ("null", "none", "qvariant()", "pyqt6.qtcore.qvariant()"):
        return "NULL", True

    if "QDate(" in val_str or "QDateTime(" in val_str:
        nums = re.findall(r"\d+", val_str)
        if len(nums) >= 3:
            y, m, d = int(nums[0]), int(nums[1]), int(nums[2])
            if len(nums) >= 5:
                hh, mm = int(nums[3]), int(nums[4])
                ss = int(nums[5]) if len(nums) >= 6 else 0
                return f"{y:04d}-{m:02d}-{d:02d} {hh:02d}:{mm:02d}:{ss:02d}", False
            return f"{y:04d}-{m:02d}-{d:02d}", False

    return val_str, False


POPUP_QSS = """
QFrame#AlsFeatureInfoPopup {
    background-color: #0b1329;
    border: 1.5px solid #38bdf8;
    border-radius: 8px;
}
QFrame#AlsPopupHeader {
    background-color: #0f172a;
    border-bottom: 1px solid #1e293b;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
}
QLabel#AlsPopupTitle {
    color: #38bdf8;
    font-size: 11px;
    font-weight: bold;
}
QLabel#AlsPopupSubTitle {
    color: #94a3b8;
    font-size: 10px;
}
QPushButton#AlsPopupCloseBtn {
    background-color: transparent;
    color: #94a3b8;
    border: none;
    font-size: 13px;
    font-weight: bold;
    padding: 0px 4px;
    border-radius: 3px;
}
QPushButton#AlsPopupCloseBtn:hover {
    background-color: #ef4444;
    color: #ffffff;
}
QLineEdit#AlsPopupFilter {
    background-color: #1e293b;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 4px;
    padding: 3px 8px;
    font-size: 10px;
}
QLineEdit#AlsPopupFilter:focus {
    border-color: #38bdf8;
}
QTableWidget, QTableWidget QWidget, QTableWidget::viewport, QTableView, QTableView::viewport {
    background-color: #0b1329;
    color: #f8fafc;
    border: none;
    gridline-color: #1e293b;
    font-size: 10px;
    outline: none;
}
QTableWidget::item {
    background-color: #0b1329;
    color: #f8fafc;
    padding: 3px 6px;
    border-bottom: 1px solid #1e293b;
}
QTableWidget::item:selected {
    background-color: #0284c7;
    color: #ffffff;
}
QHeaderView::section {
    background-color: #0f172a;
    color: #cbd5e1;
    font-size: 10px;
    font-weight: bold;
    border: none;
    border-bottom: 1px solid #334155;
    padding: 3px 6px;
}
QScrollBar:vertical {
    width: 6px;
    background: #090e1a;
}
QScrollBar::handle:vertical {
    background: #334155;
    border-radius: 3px;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover {
    background: #38bdf8;
}
"""


class FeatureInfoPopup(QFrame):
    """
    Fixed-size, scrollable popup panel showing feature attributes top-to-bottom.
    Anchors visually to the picked 3D feature via a leader line drawn by the viewer.
    """

    popup_closed = pyqtSignal()
    popup_moved = pyqtSignal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("AlsFeatureInfoPopup")
        self.setStyleSheet(POPUP_QSS)
        self.setFixedSize(360, 420)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, False)

        self._drag_start_pos: Optional[QPoint] = None
        self._current_feature: Optional[dict] = None

        self._init_ui()
        self.hide()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 1. Header Bar (Draggable handle + Title + Close Button)
        self.header = QFrame(self)
        self.header.setObjectName("AlsPopupHeader")
        hl = QHBoxLayout(self.header)
        hl.setContentsMargins(10, 6, 8, 6)
        hl.setSpacing(6)

        title_vbox = QVBoxLayout()
        title_vbox.setContentsMargins(0, 0, 0, 0)
        title_vbox.setSpacing(1)

        self.lbl_title = QLabel("ℹ️ 2D Kihi Objekt", self.header)
        self.lbl_title.setObjectName("AlsPopupTitle")
        title_vbox.addWidget(self.lbl_title)

        self.lbl_subtitle = QLabel("Objekt ID: -", self.header)
        self.lbl_subtitle.setObjectName("AlsPopupSubTitle")
        title_vbox.addWidget(self.lbl_subtitle)
        hl.addLayout(title_vbox, stretch=1)

        self.btn_close = QPushButton("✕", self.header)
        self.btn_close.setObjectName("AlsPopupCloseBtn")
        self.btn_close.setToolTip("Sulge inforežiimi tabel [Esc]")
        self.btn_close.setFixedSize(20, 20)
        self.btn_close.clicked.connect(self.close_popup)
        hl.addWidget(self.btn_close)

        main_layout.addWidget(self.header)

        # 2. Search / Filter bar
        filter_box = QFrame(self)
        filter_layout = QHBoxLayout(filter_box)
        filter_layout.setContentsMargins(8, 6, 8, 4)
        filter_layout.setSpacing(4)

        self.edit_filter = QLineEdit(filter_box)
        self.edit_filter.setObjectName("AlsPopupFilter")
        self.edit_filter.setPlaceholderText("🔍 Filtreeri atribuute...")
        self.edit_filter.setClearButtonEnabled(True)
        self.edit_filter.textChanged.connect(self._apply_filter)
        filter_layout.addWidget(self.edit_filter)

        main_layout.addWidget(filter_box)

        # 3. Two-Column Table with Attributes Stacked Top-to-Bottom
        self.table = QTableWidget(self)
        self.table.setObjectName("AlsPopupTable")
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Väli / Atribuut", "Väärtus"])
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(22)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 130)

        # Force dark cockpit palette to avoid white QGIS background
        p = self.table.palette()
        p.setColor(QPalette.ColorRole.Base, QColor("#0b1329"))
        p.setColor(QPalette.ColorRole.AlternateBase, QColor("#0f172a"))
        p.setColor(QPalette.ColorRole.Text, QColor("#f8fafc"))
        p.setColor(QPalette.ColorRole.WindowText, QColor("#f8fafc"))
        p.setColor(QPalette.ColorRole.Window, QColor("#0b1329"))
        self.table.setPalette(p)
        if self.table.viewport():
            self.table.viewport().setPalette(p)
            self.table.viewport().setStyleSheet("background-color: #0b1329; color: #f8fafc;")

        main_layout.addWidget(self.table, stretch=1)

        # 4. Footer status / count
        self.footer = QFrame(self)
        fl = QHBoxLayout(self.footer)
        fl.setContentsMargins(10, 4, 10, 4)
        fl.setSpacing(4)
        self.lbl_count = QLabel("0 atribuuti", self.footer)
        self.lbl_count.setStyleSheet("color: #64748b; font-size: 9px;")
        fl.addWidget(self.lbl_count)
        fl.addStretch(1)
        main_layout.addWidget(self.footer)

    def show_feature(self, feat: dict, click_x: float, click_y: float, viewport_w: int, viewport_h: int):
        """Populates the popup with feature attributes and positions it conveniently near the click."""
        self._current_feature = feat
        layer_name = str(feat.get("layer_name", "Vektorkiht"))
        feat_id = feat.get("feat_id", "-")
        attrs = feat.get("attributes", {})

        self.lbl_title.setText(f"ℹ️ {layer_name}")
        self.lbl_subtitle.setText(f"Objekt ID: #{feat_id}  |  Kiht: {layer_name}")
        self.edit_filter.clear()

        # Populate rows top-to-bottom
        self.table.setRowCount(0)
        sorted_keys = sorted(attrs.keys())
        self.table.setRowCount(len(sorted_keys))

        f_bold = QFont("Segoe UI", 9, QFont.Weight.Bold)
        f_val = QFont("Segoe UI", 9)
        f_null = QFont("Segoe UI", 9, QFont.Weight.Normal)
        f_null.setItalic(True)

        for row, key in enumerate(sorted_keys):
            raw_val = attrs[key]
            val_str, is_null = format_attr_val(raw_val)

            bg_col = QColor("#0f172a" if row % 2 == 0 else "#0b1329")

            # Key item
            item_k = QTableWidgetItem(str(key))
            item_k.setFont(f_bold)
            item_k.setForeground(QBrush(QColor("#38bdf8")))
            item_k.setBackground(QBrush(bg_col))
            self.table.setItem(row, 0, item_k)

            # Value item
            item_v = QTableWidgetItem(val_str)
            if is_null:
                item_v.setFont(f_null)
                item_v.setForeground(QBrush(QColor("#64748b")))
            else:
                item_v.setFont(f_val)
                item_v.setForeground(QBrush(QColor("#f8fafc")))
            item_v.setBackground(QBrush(bg_col))
            self.table.setItem(row, 1, item_v)

        self.lbl_count.setText(f"Kokku {len(sorted_keys)} atribuuti")

        # Position smartly near click without clipping off screen edges
        pop_w, pop_h = self.width(), self.height()
        target_x = int(click_x + 35)
        target_y = int(click_y - 180)

        # Flip horizontally if overflowing right
        if target_x + pop_w > viewport_w - 15:
            target_x = int(click_x - pop_w - 35)

        # Clamp within viewport margins
        target_x = max(15, min(viewport_w - pop_w - 15, target_x))
        target_y = max(15, min(viewport_h - pop_h - 15, target_y))

        self.move(target_x, target_y)
        self.show()
        self.raise_()
        self.popup_moved.emit()

    def _apply_filter(self, text: str):
        query = text.strip().lower()
        visible_cnt = 0
        for row in range(self.table.rowCount()):
            k_item = self.table.item(row, 0)
            v_item = self.table.item(row, 1)
            k_txt = k_item.text().lower() if k_item else ""
            v_txt = v_item.text().lower() if v_item else ""
            matches = (not query) or (query in k_txt) or (query in v_txt)
            self.table.setRowHidden(row, not matches)
            if matches:
                visible_cnt += 1
        self.lbl_count.setText(f"Näitan {visible_cnt} / {self.table.rowCount()} atribuuti")

    def close_popup(self):
        self.hide()
        self._current_feature = None
        self.popup_closed.emit()

    # ------------------------------------------------------------------ #
    # Header Drag Handling
    # ------------------------------------------------------------------ #
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton and self.header.geometry().contains(event.pos()):
            self._drag_start_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._drag_start_pos is not None and (event.buttons() & Qt.MouseButton.LeftButton):
            new_pos = event.globalPosition().toPoint() - self._drag_start_pos
            if self.parentWidget():
                pw, ph = self.parentWidget().width(), self.parentWidget().height()
                nx = max(5, min(pw - self.width() - 5, new_pos.x()))
                ny = max(5, min(ph - self.height() - 5, new_pos.y()))
                self.move(nx, ny)
            else:
                self.move(new_pos)
            self.popup_moved.emit()
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        self._drag_start_pos = None
        super().mouseReleaseEvent(event)
