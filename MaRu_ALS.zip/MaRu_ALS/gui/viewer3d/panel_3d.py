# -*- coding: utf-8 -*-
"""
Unified MaRu ALS 3D Panel (`Als3DPanel`) & Style Customizer (`AlsStyleDialog`).

Hosts:
1. Top dark-cockpit control toolbar:
   - Arrow tool toggle
   - Natural RGB (default) / Elevation / Classification / Intensity selector
   - Customizable Style dialog button (`🎨 Stiil`) for 2D & 3D
   - Point size slider & ASPRS class filter menu
   - Vertical Wall & Void Interpolation toggle (`🧱 Seinad & tühimikud`)
   - 2D Canvas Layers in 3D toggle (OFF by default) + layer selector menu + LOS occlusion toggle
   - 3D measurement modes (Fly, Distance, Area, Volume)
   - Auto-streaming toggle, camera reset, CSV telemetry export
   - 1:2000 WFS grid toggle, Years/Layers drawer toggle, Settings
2. Central hardware-accelerated OpenGL 3D drone viewport (`AlsGLViewer`).
3. Modernized dark-cockpit right-side drawer (`Aastad / kihid`) with three tabs + live progress bar:
   - Tab 1 (`ALS (LAZ)`): Multi-year LAZ flights per 1:2000 grid tile + multi-overflight merger.
   - Tab 2 (`Lisakihid (DSM/Orto)`): Additional Maa- ja Ruumiamet open datasets
     (DSM 1m, DTM 1m, Orthophotos RGB/Low-alt/CIR/NGR, Shaded Basic Map) opened in 3D + 2D.
   - Tab 3 (`3D Kihid & Kaart`):
     * Top: 3D Scene Layer Browser (see all layers opened in 3D and toggle them ON/OFF).
     * Bottom: QGIS 2D Canvas Layers Browser (toggle open 2D layers ON/OFF for 3D view; OFF by default).
"""

import csv
import datetime
import math
import os
from typing import Dict, List, Optional, Set, Tuple

from qgis.PyQt.QtCore import Qt, pyqtSignal, QSize, QTimer, QVariant
try:
    from qgis.PyQt.QtGui import QAction, QActionGroup, QColor, QFont, QIcon, QLinearGradient, QPainter, QPixmap
except ImportError:
    from qgis.PyQt.QtWidgets import QAction, QActionGroup
    from qgis.PyQt.QtGui import QColor, QFont, QIcon, QLinearGradient, QPainter, QPixmap
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMenu,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)
try:
    from qgis.gui import QgsDockWidget
except ImportError:
    from qgis.PyQt.QtWidgets import QDockWidget as QgsDockWidget
from qgis.core import (
    Qgis,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsMessageLog,
    QgsPointCloudLayer,
    QgsPointXY,
    QgsProject,
    QgsRasterLayer,
    QgsRectangle,
    QgsSettings,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsWkbTypes,
)

from ...core.cache_manager import CacheManager
from ...core.geoportaal_api import AlsFileInfo, EXTRA_DATASETS
from ...core.grid_engine import GridEngine
from ...i18n import tr
from ..qt_compat import (
    BottomDockWidgetArea,
    LeftDockWidgetArea,
    RightDockWidgetArea,
    SelectRows,
    TopDockWidgetArea,
    UserRole,
)
from ..symbology import DEFAULT_CLASS_COLORS, ELEVATION_RAMPS, PointCloudSymbology
from . import measure as M
from .canvas_bridge import extract_canvas_features_for_3d, list_canvas_vector_layers
from .info_popup import FeatureInfoPopup
from .gl_viewer import (
    COLOR_CLASS,
    COLOR_ELEVATION,
    COLOR_INTENSITY,
    COLOR_RGB,
    STATE_FAILED,
    STATE_LOADING,
    STATE_QUEUED,
    AlsGLViewer,
    DronePhotoShot,
)
from .pointcloud_loader import PointCloudLoadWorker
from .drone_signal_dialog import DroneSignalDialog


# Shared dark cockpit stylesheet for the drawer and dialogs
DARK_COCKPIT_QSS = """
QWidget#MaruAlsDrawer, QDialog#MaruAlsStyleDialog {
    background-color: #0f172a;
    color: #e2e8f0;
    font-family: "Segoe UI", sans-serif;
    font-size: 11px;
}
QWidget#MaruAlsDrawer QLabel, QDialog#MaruAlsStyleDialog QLabel {
    color: #cbd5e1;
    font-size: 11px;
}
QTabWidget#MaruAlsDrawerTabs::pane {
    border: 1px solid #1e293b;
    background-color: #0f172a;
    border-radius: 4px;
}
QTabWidget#MaruAlsDrawerTabs QTabBar::tab {
    background-color: #1e293b;
    color: #94a3b8;
    border: 1px solid #334155;
    border-bottom: none;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 5px 9px;
    margin-right: 2px;
    font-weight: 600;
    font-size: 11px;
}
QTabWidget#MaruAlsDrawerTabs QTabBar::tab:selected {
    background-color: #0284c7;
    color: #ffffff;
    border-color: #38bdf8;
}
QTabWidget#MaruAlsDrawerTabs QTabBar::tab:hover:!selected {
    background-color: #334155;
    color: #f1f5f9;
}
QTreeWidget {
    background-color: #111c2d;
    alternate-background-color: #162238;
    color: #e2e8f0;
    border: 1px solid #1e293b;
    border-radius: 5px;
    outline: none;
    font-size: 11px;
}
QTreeWidget::item {
    padding: 3px 4px;
    border-bottom: 1px solid rgba(30, 41, 59, 0.55);
}
QTreeWidget::item:hover {
    background-color: #1e293b;
}
QTreeWidget::item:selected {
    background-color: rgba(2, 132, 199, 0.35);
    color: #ffffff;
}
QHeaderView::section {
    background-color: #1e293b;
    color: #38bdf8;
    border: none;
    border-right: 1px solid #334155;
    border-bottom: 1px solid #334155;
    padding: 4px 6px;
    font-weight: bold;
    font-size: 11px;
}
QPushButton {
    background-color: #1e293b;
    color: #f1f5f9;
    border: 1px solid #334155;
    border-radius: 5px;
    padding: 5px 10px;
    font-size: 11px;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #334155;
    border-color: #475569;
}
QPushButton#PrimaryCockpitBtn {
    background-color: #0284c7;
    color: #ffffff;
    border: 1px solid #38bdf8;
}
QPushButton#PrimaryCockpitBtn:hover {
    background-color: #0369a1;
}
QFrame#MaruAlsProgressFrame {
    background-color: #111c2d;
    border: 1px solid #1e293b;
    border-radius: 5px;
}
QProgressBar {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 4px;
    text-align: center;
    color: #f8fafc;
    font-weight: bold;
    font-size: 10px;
    min-height: 14px;
    max-height: 14px;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284c7, stop:1 #38bdf8);
    border-radius: 3px;
}
QGroupBox {
    border: 1px solid #1e293b;
    border-radius: 5px;
    margin-top: 8px;
    padding-top: 8px;
    color: #38bdf8;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
}
QCheckBox {
    color: #cbd5e1;
    font-size: 11px;
    spacing: 5px;
}
QCheckBox::indicator {
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid #475569;
    background-color: #1e293b;
}
QCheckBox::indicator:checked {
    background-color: #0284c7;
    border-color: #38bdf8;
}
QComboBox, QDoubleSpinBox {
    background-color: #1e293b;
    color: #f1f5f9;
    border: 1px solid #334155;
    border-radius: 4px;
    padding: 3px 6px;
    font-size: 11px;
}
QComboBox QAbstractItemView {
    background-color: #1e293b;
    color: #f1f5f9;
    selection-background-color: #0284c7;
    selection-color: #ffffff;
    border: 1px solid #334155;
    outline: none;
    padding: 2px;
}
QComboBox QAbstractItemView::item {
    background-color: #1e293b;
    color: #f1f5f9;
    padding: 4px 8px;
}
QComboBox QAbstractItemView::item:selected, QComboBox QAbstractItemView::item:hover {
    background-color: #0284c7;
    color: #ffffff;
}
QScrollBar:vertical {
    background: #0f172a;
    width: 8px;
    margin: 0px;
}
QScrollBar::handle:vertical {
    background: #334155;
    min-height: 20px;
    border-radius: 4px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
"""


class AlsStyleDialog(QDialog):
    """Dark-cockpit dialog for customizing 2D & 3D point cloud symbology."""

    style_applied = pyqtSignal()

    def __init__(self, viewer: AlsGLViewer, parent=None):
        super().__init__(parent)
        self.viewer = viewer
        self.setObjectName("MaruAlsStyleDialog")
        self.setWindowTitle(tr("v3d_style_title"))
        self.setMinimumWidth(420)
        self.setStyleSheet(DARK_COCKPIT_QSS)

        self._class_btns: Dict[int, QPushButton] = {}
        self._init_ui()

    def _ramp_icon(self, ramp_name: str) -> QIcon:
        stops = ELEVATION_RAMPS.get(ramp_name, ELEVATION_RAMPS["terrain"])
        pix = QPixmap(72, 14)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        grad = QLinearGradient(0, 0, 72, 0)
        for pos, rgb in stops:
            grad.setColorAt(pos, QColor(*rgb))
        p.fillRect(0, 1, 72, 12, grad)
        p.end()
        return QIcon(pix)

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # 1. Elevation Ramp & Z Range
        row_ramp = QHBoxLayout()
        row_ramp.addWidget(QLabel(tr("v3d_style_ramp"), self))
        self.cmb_ramp = QComboBox(self)
        self.cmb_ramp.setIconSize(QSize(72, 14))
        self.cmb_ramp.view().setStyleSheet(
            "QAbstractItemView { background-color: #1e293b; color: #f1f5f9; "
            "selection-background-color: #0284c7; selection-color: #ffffff; "
            "border: 1px solid #334155; outline: none; }"
            "QAbstractItemView::item { background-color: #1e293b; color: #f1f5f9; padding: 4px 8px; }"
            "QAbstractItemView::item:selected { background-color: #0284c7; color: #ffffff; }"
        )
        ramps = [
            ("terrain", tr("v3d_ramp_terrain")),
            ("viridis", tr("v3d_ramp_viridis")),
            ("turbo", tr("v3d_ramp_turbo")),
            ("forest", tr("v3d_ramp_forest")),
            ("arctic", tr("v3d_ramp_arctic")),
        ]
        for key, label in ramps:
            self.cmb_ramp.addItem(self._ramp_icon(key), label, key)
        cur_idx = next(
            (i for i, (k, _) in enumerate(ramps) if k == PointCloudSymbology.ramp_name),
            0,
        )
        self.cmb_ramp.setCurrentIndex(cur_idx)
        row_ramp.addWidget(self.cmb_ramp, 1)
        layout.addLayout(row_ramp)

        self.chk_z_auto = QCheckBox(tr("v3d_z_auto"), self)
        is_auto = PointCloudSymbology.custom_z_min is None
        self.chk_z_auto.setChecked(is_auto)
        self.chk_z_auto.toggled.connect(self._on_z_auto_toggled)
        layout.addWidget(self.chk_z_auto)

        def_zmin = (
            min(t.z_range[0] for t in self.viewer.tiles.values())
            if self.viewer.tiles
            else 0.0
        )
        def_zmax = (
            max(t.z_range[1] for t in self.viewer.tiles.values())
            if self.viewer.tiles
            else 80.0
        )

        z_row = QHBoxLayout()
        z_row.addWidget(QLabel(tr("v3d_z_min"), self))
        self.spn_z_min = QDoubleSpinBox(self)
        self.spn_z_min.setRange(-100.0, 500.0)
        self.spn_z_min.setDecimals(1)
        self.spn_z_min.setValue(
            PointCloudSymbology.custom_z_min
            if PointCloudSymbology.custom_z_min is not None
            else float(def_zmin)
        )
        z_row.addWidget(self.spn_z_min)

        z_row.addWidget(QLabel(tr("v3d_z_max"), self))
        self.spn_z_max = QDoubleSpinBox(self)
        self.spn_z_max.setRange(-100.0, 500.0)
        self.spn_z_max.setDecimals(1)
        self.spn_z_max.setValue(
            PointCloudSymbology.custom_z_max
            if PointCloudSymbology.custom_z_max is not None
            else float(def_zmax)
        )
        z_row.addWidget(self.spn_z_max)
        layout.addLayout(z_row)
        self._on_z_auto_toggled(is_auto)

        # 2. Natural RGB Brightness & Intensity Gamma
        rgb_row = QHBoxLayout()
        rgb_row.addWidget(QLabel(tr("v3d_rgb_bright"), self))
        self.sld_rgb = QSlider(Qt.Orientation.Horizontal, self)
        self.sld_rgb.setRange(50, 200)
        self.sld_rgb.setValue(int(round(self.viewer.rgb_brightness * 100)))
        self.lbl_rgb_val = QLabel(f"{self.sld_rgb.value()}%", self)
        self.sld_rgb.valueChanged.connect(lambda v: self.lbl_rgb_val.setText(f"{v}%"))
        rgb_row.addWidget(self.sld_rgb, 1)
        rgb_row.addWidget(self.lbl_rgb_val)
        layout.addLayout(rgb_row)

        inten_row = QHBoxLayout()
        inten_row.addWidget(QLabel(tr("v3d_inten_gamma"), self))
        self.sld_gamma = QSlider(Qt.Orientation.Horizontal, self)
        self.sld_gamma.setRange(30, 180)
        self.sld_gamma.setValue(int(round(self.viewer.intensity_gamma * 100)))
        self.lbl_gamma_val = QLabel(f"{self.sld_gamma.value() / 100.0:.2f}", self)
        self.sld_gamma.valueChanged.connect(
            lambda v: self.lbl_gamma_val.setText(f"{v / 100.0:.2f}")
        )
        inten_row.addWidget(self.sld_gamma, 1)
        inten_row.addWidget(self.lbl_gamma_val)
        layout.addLayout(inten_row)

        # 3. ASPRS Classification Color Pickers
        layout.addWidget(QLabel(tr("v3d_class_colors"), self))
        cls_grid = QGridLayout()
        cls_grid.setSpacing(6)
        cls_items = [
            (2, tr("v3d_cls_ground")),
            (3, tr("v3d_cls_low_veg")),
            (4, tr("v3d_cls_med_veg")),
            (5, tr("v3d_cls_high_veg")),
            (6, tr("v3d_cls_building")),
            (9, tr("v3d_cls_water")),
            (17, tr("v3d_cls_bridge")),
            (1, tr("v3d_cls_unclass")),
        ]
        for idx, (cid, name) in enumerate(cls_items):
            btn = QPushButton(name, self)
            cval = PointCloudSymbology.class_colors.get(cid, (180, 180, 180))
            col = cval if isinstance(cval, QColor) else QColor(*cval)
            self._style_color_btn(btn, col)
            btn.clicked.connect(lambda _, c=cid, b=btn: self._pick_class_color(c, b))
            self._class_btns[cid] = btn
            cls_grid.addWidget(btn, idx // 2, idx % 2)
        layout.addLayout(cls_grid)

        # 4. Action Buttons
        btn_row = QHBoxLayout()
        btn_reset = QPushButton(tr("v3d_style_reset"), self)
        btn_reset.clicked.connect(self._reset_defaults)
        btn_row.addWidget(btn_reset)

        btn_apply = QPushButton(tr("v3d_style_apply"), self)
        btn_apply.setObjectName("PrimaryCockpitBtn")
        btn_apply.clicked.connect(self._apply)
        btn_row.addWidget(btn_apply)
        layout.addLayout(btn_row)

    def _on_z_auto_toggled(self, checked: bool):
        self.spn_z_min.setEnabled(not checked)
        self.spn_z_max.setEnabled(not checked)

    @staticmethod
    def _style_color_btn(btn: QPushButton, col: QColor):
        lum = 0.299 * col.red() + 0.587 * col.green() + 0.114 * col.blue()
        fg = "#0f172a" if lum > 140 else "#f8fafc"
        btn.setStyleSheet(
            f"background-color: {col.name()}; color: {fg}; font-weight: bold; border: 1px solid #475569;"
        )
        btn.setProperty("picked_color", col)

    def _pick_class_color(self, class_id: int, btn: QPushButton):
        cur = btn.property("picked_color") or QColor(180, 180, 180)
        picked = QColorDialog.getColor(cur, self, tr("v3d_style_title"))
        if picked.isValid():
            self._style_color_btn(btn, picked)

    def _reset_defaults(self):
        PointCloudSymbology.reset_custom_styles()
        self.cmb_ramp.setCurrentIndex(0)
        self.chk_z_auto.setChecked(True)
        self.sld_rgb.setValue(105)
        self.sld_gamma.setValue(85)
        for cid, btn in self._class_btns.items():
            rgb = DEFAULT_CLASS_COLORS.get(cid, (180, 180, 180))
            self._style_color_btn(btn, QColor(*rgb))
        self._apply()

    def _apply(self):
        ramp_key = self.cmb_ramp.currentData() or "terrain"
        PointCloudSymbology.ramp_name = ramp_key
        self.viewer.set_elevation_ramp(PointCloudSymbology.get_ramp_stops_rgb(ramp_key))

        if self.chk_z_auto.isChecked():
            PointCloudSymbology.custom_z_min = None
            PointCloudSymbology.custom_z_max = None
            self.viewer.set_custom_z_range(None, None)
        else:
            z0 = float(self.spn_z_min.value())
            z1 = float(self.spn_z_max.value())
            if z1 <= z0:
                z1 = z0 + 1.0
            PointCloudSymbology.custom_z_min = z0
            PointCloudSymbology.custom_z_max = z1
            self.viewer.set_custom_z_range(z0, z1)

        bright = self.sld_rgb.value() / 100.0
        PointCloudSymbology.rgb_brightness = bright
        self.viewer.set_rgb_brightness(bright)

        gamma = self.sld_gamma.value() / 100.0
        PointCloudSymbology.intensity_gamma = gamma
        self.viewer.set_intensity_gamma(gamma)

        for cid, btn in self._class_btns.items():
            col = btn.property("picked_color")
            if isinstance(col, QColor) and col.isValid():
                rgb_tup = (col.red(), col.green(), col.blue())
                PointCloudSymbology.class_colors[cid] = rgb_tup
                self.viewer.set_custom_class_color(cid, rgb_tup)

        self.style_applied.emit()
        self.accept()


class DroneDataDialog(QDialog):
    """
    Independent Dark-Cockpit panel for importing and managing drone survey datasets
    (LAZ / LAS photogrammetry, GeoTIFF DSM/DTM, Orthophotos) with completely
    separate styling, point size, vertical Z-offset calibration, and color modes.
    """

    data_changed = pyqtSignal()

    def __init__(self, viewer: AlsGLViewer, panel_3d: "Als3DPanel", parent=None):
        super().__init__(parent)
        self.viewer = viewer
        self.panel_3d = panel_3d
        self.setObjectName("MaruAlsDroneDataDialog")
        self.setWindowTitle(tr("v3d_drone_dlg_title", fallback="🛸 Drooni andmete haldur ja stiil"))
        self.setMinimumWidth(500)
        self.setMinimumHeight(540)
        self.setStyleSheet(DARK_COCKPIT_QSS)
        self.setModal(False)

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # 1. Header & Quick Info
        hdr_row = QHBoxLayout()
        icon_lbl = QLabel("🛸", self)
        icon_lbl.setStyleSheet("font-size: 24px;")
        hdr_row.addWidget(icon_lbl)

        hdr_vbox = QVBoxLayout()
        title_lbl = QLabel(tr("v3d_drone_dlg_title", fallback="Drooni andmete haldur ja stiil"), self)
        title_lbl.setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 13px;")
        desc_lbl = QLabel(
            tr("v3d_drone_dlg_desc", fallback="Laadi kohalikke droonimõõdistuste faile (LAZ/LAS/DSM/Orto). Drooni andmetel on oma eraldiseisev stiil ja kõrguskalibreerimine sõltumatult ALS andmetest."),
            self
        )
        desc_lbl.setWordWrap(True)
        desc_lbl.setStyleSheet("color: #94a3b8; font-size: 10px;")
        hdr_vbox.addWidget(title_lbl)
        hdr_vbox.addWidget(desc_lbl)
        hdr_row.addLayout(hdr_vbox, 1)
        layout.addLayout(hdr_row)

        # 2. Import Button
        btn_import = QPushButton("➕ " + tr("v3d_drone_data_btn", fallback="Lisa drooni andmed (LAZ / DSM / Orto)..."), self)
        btn_import.setStyleSheet(
            "QPushButton { background: #0284c7; color: #ffffff; font-weight: bold; padding: 7px 14px; border-radius: 5px; border: 1px solid #38bdf8; }"
            "QPushButton:hover { background: #0369a1; }"
        )
        btn_import.clicked.connect(self._on_import_clicked)
        layout.addWidget(btn_import)

        # 3. Loaded Drone Layers GroupBox
        grp_layers = QGroupBox(tr("v3d_drone_layers_grp", fallback="Laaditud droonimõõdistused 3D vaates"), self)
        grp_layers.setStyleSheet("QGroupBox { font-weight: bold; color: #f1f5f9; border: 1px solid #334155; border-radius: 6px; margin-top: 10px; padding-top: 10px; }")
        lay_layers = QVBoxLayout(grp_layers)
        lay_layers.setSpacing(6)

        self.tree_drone_layers = QTreeWidget(grp_layers)
        self.tree_drone_layers.setHeaderLabels([
            tr("dock_col_name", fallback="Nimi / Fail"),
            tr("dock_col_type", fallback="Tüüp"),
            tr("dock_col_size", fallback="Suurus / Punktid"),
            tr("v3d_drone_action", fallback="Toiming"),
        ])
        self.tree_drone_layers.setColumnWidth(0, 190)
        self.tree_drone_layers.setColumnWidth(1, 95)
        self.tree_drone_layers.setColumnWidth(2, 95)
        self.tree_drone_layers.setRootIsDecorated(False)
        self.tree_drone_layers.setStyleSheet(
            "QTreeWidget { background-color: #0f172a; border: 1px solid #334155; border-radius: 4px; color: #f1f5f9; }"
            "QHeaderView::section { background-color: #1e293b; color: #94a3b8; font-weight: bold; padding: 4px; border: none; }"
            "QTreeWidget::item:selected { background-color: #0284c7; color: #ffffff; }"
        )
        self.tree_drone_layers.itemChanged.connect(self._on_layer_item_changed)
        lay_layers.addWidget(self.tree_drone_layers)

        # Toggle all drone layers visibility
        self.chk_all_drone_vis = QCheckBox(tr("v3d_drone_show_all", fallback="Näita kõiki droonikihte 3D vaates"), grp_layers)
        self.chk_all_drone_vis.setChecked(self.viewer.drone_visible)
        self.chk_all_drone_vis.toggled.connect(self._on_all_vis_toggled)
        lay_layers.addWidget(self.chk_all_drone_vis)

        layout.addWidget(grp_layers)

        # 4. Separate Drone Styling GroupBox
        grp_style = QGroupBox(tr("v3d_drone_style_grp", fallback="Eraldiseisev stiil drooni andmetele"), self)
        grp_style.setStyleSheet("QGroupBox { font-weight: bold; color: #f1f5f9; border: 1px solid #334155; border-radius: 6px; margin-top: 10px; padding-top: 10px; }")
        lay_style = QVBoxLayout(grp_style)
        lay_style.setSpacing(8)

        # 4a. Color Mode
        col_row = QHBoxLayout()
        col_lbl = QLabel(tr("v3d_tb_color", fallback="Värvirežiim:"), grp_style)
        col_lbl.setFixedWidth(130)
        self.cmb_drone_color = QComboBox(grp_style)
        self.cmb_drone_color.view().setStyleSheet(
            "QAbstractItemView { background-color: #1e293b; color: #f1f5f9; "
            "selection-background-color: #0284c7; selection-color: #ffffff; "
            "border: 1px solid #334155; outline: none; }"
            "QAbstractItemView::item { background-color: #1e293b; color: #f1f5f9; padding: 4px 8px; }"
            "QAbstractItemView::item:selected { background-color: #0284c7; color: #ffffff; }"
        )
        self.cmb_drone_color.addItem(tr("v3d_col_rgb", fallback="Loomulik RGB (Ortofoto)"), COLOR_RGB)
        self.cmb_drone_color.addItem(tr("v3d_col_elev", fallback="Kõrgusvärving (Elevation)"), COLOR_ELEVATION)
        self.cmb_drone_color.addItem(tr("v3d_col_class", fallback="Klassifikatsioon (ASPRS)"), COLOR_CLASS)
        self.cmb_drone_color.addItem(tr("v3d_col_inten", fallback="Intensiivsus (LiDAR)"), COLOR_INTENSITY)
        self.cmb_drone_color.addItem(tr("v3d_drone_highlight_amber", fallback="Esiletõst: Kuldne / Merevaik"), 4)
        self.cmb_drone_color.addItem(tr("v3d_drone_highlight_cyan", fallback="Esiletõst: Neoon Sinine"), 5)

        idx = self.cmb_drone_color.findData(self.viewer.drone_color_mode)
        if idx >= 0:
            self.cmb_drone_color.setCurrentIndex(idx)
        self.cmb_drone_color.currentIndexChanged.connect(self._on_drone_color_changed)
        col_row.addWidget(col_lbl)
        col_row.addWidget(self.cmb_drone_color, 1)
        lay_style.addLayout(col_row)

        # 4b. Separate Point Size
        psize_row = QHBoxLayout()
        psize_lbl = QLabel(tr("v3d_tb_psize", fallback="Punkti suurus:"), grp_style)
        psize_lbl.setFixedWidth(130)
        self.sld_drone_psize = QSlider(Qt.Orientation.Horizontal, grp_style)
        self.sld_drone_psize.setRange(5, 50)
        self.sld_drone_psize.setValue(int(round(self.viewer.drone_point_size * 10)))
        self.lbl_drone_psize_val = QLabel(f"{self.viewer.drone_point_size:.1f} px", grp_style)
        self.lbl_drone_psize_val.setFixedWidth(50)
        self.sld_drone_psize.valueChanged.connect(self._on_drone_psize_changed)
        psize_row.addWidget(psize_lbl)
        psize_row.addWidget(self.sld_drone_psize, 1)
        psize_row.addWidget(self.lbl_drone_psize_val)
        lay_style.addLayout(psize_row)

        # 4c. Vertical Altitude Offset / Calibration (Z-Offset)
        zoff_row = QHBoxLayout()
        zoff_lbl = QLabel(tr("v3d_drone_z_offset_lbl", fallback="Kõrgusnihe (Z-nihe):"), grp_style)
        zoff_lbl.setFixedWidth(130)
        zoff_lbl.setToolTip(tr("v3d_drone_z_offset_tip", fallback="Kalibreeri drooni kõrgust maapinna ja ALS EH2000 geoidi suhtes (±50m)"))

        self.spn_drone_z = QDoubleSpinBox(grp_style)
        self.spn_drone_z.setRange(-50.0, 50.0)
        self.spn_drone_z.setDecimals(1)
        self.spn_drone_z.setSingleStep(0.2)
        self.spn_drone_z.setSuffix(" m")
        self.spn_drone_z.setValue(self.viewer.drone_z_offset)
        self.spn_drone_z.valueChanged.connect(self._on_drone_z_spin_changed)

        btn_z_zero = QPushButton("0 m", grp_style)
        btn_z_zero.setFixedWidth(40)
        btn_z_zero.setToolTip("Taasta 0 m nihe")
        btn_z_zero.clicked.connect(lambda: self.spn_drone_z.setValue(0.0))

        zoff_row.addWidget(zoff_lbl)
        zoff_row.addWidget(self.spn_drone_z, 1)
        zoff_row.addWidget(btn_z_zero)
        lay_style.addLayout(zoff_row)

        # 4d. RGB Brightness
        rgb_row = QHBoxLayout()
        rgb_lbl = QLabel(tr("v3d_rgb_bright", fallback="RGB heledus:"), grp_style)
        rgb_lbl.setFixedWidth(130)
        self.sld_drone_bright = QSlider(Qt.Orientation.Horizontal, grp_style)
        self.sld_drone_bright.setRange(50, 250)
        self.sld_drone_bright.setValue(int(round(self.viewer.drone_rgb_brightness * 100)))
        self.lbl_drone_bright_val = QLabel(f"{self.sld_drone_bright.value()}%", grp_style)
        self.lbl_drone_bright_val.setFixedWidth(50)
        self.sld_drone_bright.valueChanged.connect(self._on_drone_bright_changed)
        rgb_row.addWidget(rgb_lbl)
        rgb_row.addWidget(self.sld_drone_bright, 1)
        rgb_row.addWidget(self.lbl_drone_bright_val)
        lay_style.addLayout(rgb_row)

        layout.addWidget(grp_style)

        # 5. Bottom Row
        bottom_row = QHBoxLayout()
        self.lbl_drone_status = QLabel("", self)
        self.lbl_drone_status.setStyleSheet("color: #64748b; font-size: 10px;")
        bottom_row.addWidget(self.lbl_drone_status, 1)

        btn_close = QPushButton(tr("v3d_drone_dlg_close", fallback="Sulge"), self)
        btn_close.setFixedWidth(80)
        btn_close.clicked.connect(self.hide)
        bottom_row.addWidget(btn_close)
        layout.addLayout(bottom_row)

        self.refresh_layer_list()

    def _on_import_clicked(self):
        self.panel_3d.open_drone_data_dialog()

    def refresh_layer_list(self):
        """Populates the tree widget with all currently loaded drone layers."""
        self.tree_drone_layers.blockSignals(True)
        self.tree_drone_layers.clear()

        drone_tiles = self.viewer.get_drone_tiles()
        total_pts = 0

        for t in drone_tiles:
            fname = getattr(t.file_info, "filename", "") or t.tile_id
            is_rast = getattr(t, "is_raster_3d", False)
            rcat = getattr(t, "raster_cat", "")

            if is_rast:
                type_str = "DSM kõrgus" if rcat == "droon_dsm" else "Ortofoto"
                sz_str = getattr(t.file_info, "size_str", "-") or "-"
            else:
                type_str = "LAZ punktipilv"
                sz_str = f"{t.n:,} p"
                total_pts += t.n

            item = QTreeWidgetItem(self.tree_drone_layers)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(0, Qt.CheckState.Checked if t.visible else Qt.CheckState.Unchecked)
            item.setText(0, fname)
            item.setToolTip(0, fname)
            item.setText(1, type_str)
            item.setText(2, sz_str)
            item.setData(0, Qt.ItemDataRole.UserRole, t.layer_key)

            btn_del = QPushButton("🗑️", self.tree_drone_layers)
            btn_del.setFixedSize(24, 20)
            btn_del.setToolTip(tr("v3d_scene_remove", fallback="Eemalda kiht"))
            btn_del.setStyleSheet("QPushButton { background: #334155; color: #f87171; border: none; border-radius: 3px; } QPushButton:hover { background: #dc2626; color: #fff; }")
            btn_del.clicked.connect(lambda _, lk=t.layer_key: self._on_delete_layer(lk))
            self.tree_drone_layers.setItemWidget(item, 3, btn_del)

        self.tree_drone_layers.blockSignals(False)

        if drone_tiles:
            self.lbl_drone_status.setText(f"3D-s laaditud: {len(drone_tiles)} droonikihti ({total_pts:,} punkti)")
        else:
            self.lbl_drone_status.setText("Ühtegi droonikihti pole veel laaditud.")

    def _on_layer_item_changed(self, item: QTreeWidgetItem, column: int):
        if column == 0:
            layer_key = item.data(0, Qt.ItemDataRole.UserRole)
            if layer_key:
                checked = item.checkState(0) == Qt.CheckState.Checked
                self.viewer.set_scene_layer_visible(layer_key, checked)

    def _on_delete_layer(self, layer_key: str):
        self.viewer.remove_scene_layer(layer_key)
        self.refresh_layer_list()

    def _on_all_vis_toggled(self, checked: bool):
        self.viewer.set_drone_visible(checked)

    def _on_drone_color_changed(self, idx: int):
        mode = self.cmb_drone_color.currentData()
        if mode is not None:
            self.viewer.set_drone_color_mode(mode)

    def _on_drone_psize_changed(self, val: int):
        sz = val / 10.0
        self.lbl_drone_psize_val.setText(f"{sz:.1f} px")
        self.viewer.set_drone_point_size(sz)

    def _on_drone_z_spin_changed(self, val: float):
        self.viewer.set_drone_z_offset(val)

    def _on_drone_bright_changed(self, val: int):
        bright = val / 100.0
        self.lbl_drone_bright_val.setText(f"{val}%")
        self.viewer.set_drone_rgb_brightness(bright)


class Als3DPanel(QgsDockWidget):
    """Unified 3D Drone View, Measurement, and Multi-Year / Extra / 3D+2D Layer Manager Panel."""

    # Signals to plugin orchestrator
    panel_closed = pyqtSignal()
    arrow_tool_toggled = pyqtSignal(bool)
    aoi_mode_changed = pyqtSignal(str)                # "arrow" | "rectangle"
    drone_2d_toggled = pyqtSignal(bool)
    drone_2d_cone_toggled = pyqtSignal(bool)
    drone_2d_path_toggled = pyqtSignal(bool)
    drone_2d_follow_toggled = pyqtSignal(bool)
    drone_2d_center_requested = pyqtSignal()
    load_file_requested = pyqtSignal(object)          # AlsFileInfo (LAZ or Extra raster)
    load_all_requested = pyqtSignal()
    tile_stream_requested = pyqtSignal(str)           # tile_id
    toggle_grid_requested = pyqtSignal()
    open_settings_requested = pyqtSignal()
    symbology_2d_requested = pyqtSignal(str)          # "rgb" | "elevation" | "classification" | "intensity"
    fetch_extra_requested = pyqtSignal(list)          # List[str] category keys
    clear_session_requested = pyqtSignal()

    def __init__(self, parent=None, plugin_dir: str = "", canvas=None):
        super().__init__(tr("v3d_panel_title"), parent)
        self.setObjectName("MaruAls3DPanel")
        self.setAllowedAreas(
            LeftDockWidgetArea | RightDockWidgetArea | TopDockWidgetArea | BottomDockWidgetArea
        )
        self.setMinimumWidth(320)
        try:
            self.closed.connect(self.panel_closed.emit)
        except Exception:
            pass
        self.plugin_dir = plugin_dir
        self.canvas = canvas
        if self.canvas is None:
            try:
                from qgis.utils import iface
                if iface and hasattr(iface, "mapCanvas"):
                    self.canvas = iface.mapCanvas()
            except Exception:
                self.canvas = None

        # Session tile -> List[AlsFileInfo]
        self.session_data: Dict[str, List[AlsFileInfo]] = {}
        # Extra MaRu datasets per tile -> List[AlsFileInfo]
        self.extra_session_data: Dict[str, List[AlsFileInfo]] = {}
        # Enabled 2D vector layer IDs for 3D draping (DEFAULT OFF = empty set)
        self.enabled_canvas_layer_ids: Set[str] = set()
        self._connected_vec_lids: Set[str] = set()
        self.canvas_buffer_m: float = 1000.0  # default 1000m AOI buffer radius
        self._last_draped_xy: Optional[Tuple[float, float]] = None
        self._photo_layer: Optional[QgsVectorLayer] = None

        # Background LAZ / 3D raster -> numpy decoder worker
        self.loader = PointCloudLoadWorker(self)
        self.loader.tile_ready.connect(self._on_tile_decoded)
        self.loader.tile_failed.connect(self._on_tile_decode_failed)
        self.loader.tile_progress.connect(self._on_loader_progress)
        self.loader.start()

        # Debounce timer for 2D layer style/geometry modifications
        self._canvas_layer_sync_timer = QTimer(self)
        self._canvas_layer_sync_timer.setSingleShot(True)
        self._canvas_layer_sync_timer.setInterval(250)
        self._canvas_layer_sync_timer.timeout.connect(lambda: self.refresh_canvas_layers_in_3d(force=True))

        self._init_ui()
        self.apply_settings()
        self.refresh_canvas_2d_tree()

    def closeEvent(self, event):
        self.panel_closed.emit()
        super().closeEvent(event)

    def _icon(self, filename: str) -> QIcon:
        if self.plugin_dir:
            p = os.path.join(self.plugin_dir, "resources", filename)
            if os.path.exists(p):
                return QIcon(p)
        return QIcon()

    def _init_ui(self):
        root = QWidget(self)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # ------------------------------------------------------------------ #
        # 1. Integrated Top Toolbar (Scrollable for smaller/laptop screens)
        # ------------------------------------------------------------------ #
        self.toolbar_scroll = QScrollArea(root)
        self.toolbar_scroll.setObjectName("MaruAls3DToolbarScroll")
        self.toolbar_scroll.setWidgetResizable(True)
        self.toolbar_scroll.setFixedHeight(68)
        self.toolbar_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.toolbar_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.toolbar_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.toolbar_scroll.setStyleSheet(
            "QScrollArea#MaruAls3DToolbarScroll { background-color: #0f172a; border-bottom: 1px solid #1e293b; }"
            "QScrollArea#MaruAls3DToolbarScroll QScrollBar:horizontal { height: 4px; background: #0f172a; }"
            "QScrollArea#MaruAls3DToolbarScroll QScrollBar::handle:horizontal { background: #334155; border-radius: 2px; min-width: 20px; }"
            "QScrollArea#MaruAls3DToolbarScroll QScrollBar::handle:horizontal:hover { background: #38bdf8; }"
        )

        bar = QFrame(self.toolbar_scroll)
        bar.setObjectName("MaruAls3DToolbar")
        bar.setStyleSheet(
            "QFrame#MaruAls3DToolbar {"
            "  background-color: #0f172a;"
            "  border-bottom: 1px solid #1e293b;"
            "}"
            "QFrame#MaruAls3DToolbar QLabel {"
            "  color: #cbd5e1;"
            "  font-size: 11px;"
            "}"
            "QFrame#MaruAls3DToolbar QToolButton, QFrame#MaruAls3DToolbar QPushButton {"
            "  background-color: #1e293b;"
            "  color: #f1f5f9;"
            "  border: 1px solid #334155;"
            "  border-radius: 4px;"
            "  padding: 3px 7px;"
            "  font-size: 11px;"
            "}"
            "QFrame#MaruAls3DToolbar QToolButton:hover, QFrame#MaruAls3DToolbar QPushButton:hover {"
            "  background-color: #334155;"
            "}"
            "QFrame#MaruAls3DToolbar QToolButton:checked {"
            "  background-color: #0284c7;"
            "  border-color: #38bdf8;"
            "  color: #ffffff;"
            "  font-weight: bold;"
            "}"
            "QFrame#MaruAls3DToolbar QComboBox {"
            "  background-color: #1e293b;"
            "  color: #f1f5f9;"
            "  border: 1px solid #334155;"
            "  border-radius: 4px;"
            "  padding: 2px 6px;"
            "  font-size: 11px;"
            "}"
            "QFrame#MaruAls3DToolbar QComboBox QAbstractItemView {"
            "  background-color: #1e293b;"
            "  color: #f1f5f9;"
            "  selection-background-color: #0284c7;"
            "  selection-color: #ffffff;"
            "  border: 1px solid #334155;"
            "  outline: none;"
            "}"
            "QFrame#MaruAls3DToolbar QComboBox QAbstractItemView::item {"
            "  background-color: #1e293b;"
            "  color: #f1f5f9;"
            "  padding: 4px 8px;"
            "}"
            "QFrame#MaruAls3DToolbar QComboBox QAbstractItemView::item:selected {"
            "  background-color: #0284c7;"
            "  color: #ffffff;"
            "}"
            "QFrame#MaruAls3DToolbar QCheckBox {"
            "  color: #e2e8f0;"
            "  font-size: 11px;"
            "}"
        )
        tb_layout = QVBoxLayout(bar)
        tb_layout.setContentsMargins(6, 3, 6, 3)
        tb_layout.setSpacing(3)

        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        row1.setSpacing(4)

        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        row2.setSpacing(4)

        # ------------------------------------------------------------------ #
        # ROW 1: AOI Tool, 2D Drone, Symbology, Classes, Infill, Grid, Drawer, Settings
        # ------------------------------------------------------------------ #
        self.aoi_mode = "arrow"
        self.btn_arrow = QToolButton(bar)
        self.btn_arrow.setIcon(self._icon("icon_arrow.svg"))
        self.btn_arrow.setIconSize(QSize(16, 16))
        self.btn_arrow.setText(tr("v3d_tb_arrow"))
        self.btn_arrow.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.btn_arrow.setCheckable(True)
        self.btn_arrow.setToolTip(tr("v3d_tb_arrow_tip"))
        self.btn_arrow.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.btn_arrow.toggled.connect(self.arrow_tool_toggled.emit)

        self.menu_aoi = QMenu(self.btn_arrow)
        self.act_aoi_arrow = QAction(self._icon("icon_arrow.svg"), tr("v3d_aoi_mode_arrow"), self)
        self.act_aoi_arrow.setCheckable(True)
        self.act_aoi_arrow.setChecked(True)
        self.act_aoi_arrow.triggered.connect(lambda: self.set_aoi_mode("arrow"))

        self.act_aoi_rect = QAction(self._icon("icon_rect.svg"), tr("v3d_aoi_mode_rect"), self)
        self.act_aoi_rect.setCheckable(True)
        self.act_aoi_rect.triggered.connect(lambda: self.set_aoi_mode("rectangle"))

        self.grp_aoi = QActionGroup(self)
        self.grp_aoi.addAction(self.act_aoi_arrow)
        self.grp_aoi.addAction(self.act_aoi_rect)

        self.menu_aoi.addAction(self.act_aoi_arrow)
        self.menu_aoi.addAction(self.act_aoi_rect)
        self.btn_arrow.setMenu(self.menu_aoi)
        row1.addWidget(self.btn_arrow)

        # 1a-2. 2D Drone Location, FOV Cone & Flight Path Overlay Toggle
        self.btn_drone_2d = QToolButton(bar)
        self.btn_drone_2d.setText(tr("v3d_tb_drone_2d"))
        self.btn_drone_2d.setToolTip(tr("v3d_tb_drone_2d_tip"))
        self.btn_drone_2d.setCheckable(True)
        self.btn_drone_2d.setChecked(True)
        self.btn_drone_2d.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.menu_drone_2d = QMenu(self.btn_drone_2d)

        self.act_drone_cone = QAction(tr("v3d_drone_2d_show_cone"), self.menu_drone_2d)
        self.act_drone_cone.setCheckable(True)
        self.act_drone_cone.setChecked(True)
        self.act_drone_cone.toggled.connect(self.drone_2d_cone_toggled.emit)
        self.menu_drone_2d.addAction(self.act_drone_cone)

        self.act_drone_path = QAction(tr("v3d_drone_2d_show_path"), self.menu_drone_2d)
        self.act_drone_path.setCheckable(True)
        self.act_drone_path.setChecked(True)
        self.act_drone_path.toggled.connect(self.drone_2d_path_toggled.emit)
        self.menu_drone_2d.addAction(self.act_drone_path)

        self.act_drone_follow = QAction(tr("v3d_drone_2d_follow"), self.menu_drone_2d)
        self.act_drone_follow.setCheckable(True)
        self.act_drone_follow.setChecked(False)
        self.act_drone_follow.toggled.connect(self.drone_2d_follow_toggled.emit)
        self.menu_drone_2d.addAction(self.act_drone_follow)

        self.menu_drone_2d.addSeparator()

        self.act_drone_center = QAction(tr("v3d_drone_2d_center"), self.menu_drone_2d)
        self.act_drone_center.triggered.connect(self.drone_2d_center_requested.emit)
        self.menu_drone_2d.addAction(self.act_drone_center)

        self.menu_drone_2d.addSeparator()

        mm_menu = self.menu_drone_2d.addMenu(tr("v3d_minimap") + " " + tr("dock_col_type"))
        for m_key, m_lbl_key in (
            ("hyb", "v3d_mm_hyb_full"),
            ("foto", "v3d_mm_foto_full"),
            ("hall", "v3d_mm_hall_full"),
            ("grid", "v3d_mm_grid_full"),
        ):
            act_m = QAction(tr(m_lbl_key), mm_menu)
            act_m.triggered.connect(lambda _, k=m_key: self.viewer.set_minimap_base_mode(k))
            mm_menu.addAction(act_m)

        self.btn_drone_2d.setMenu(self.menu_drone_2d)
        self.btn_drone_2d.toggled.connect(self.drone_2d_toggled.emit)
        row1.addWidget(self.btn_drone_2d)

        row1.addWidget(self._sep(bar))

        # 1b. Color / Symbology mode (Natural RGB is FIRST and DEFAULT)
        self.lbl_color = QLabel(tr("v3d_tb_color"), bar)
        row1.addWidget(self.lbl_color)

        self.cmb_color = QComboBox(bar)
        self.cmb_color.view().setStyleSheet(
            "QAbstractItemView { background-color: #1e293b; color: #f1f5f9; "
            "selection-background-color: #0284c7; selection-color: #ffffff; "
            "border: 1px solid #334155; outline: none; }"
            "QAbstractItemView::item { background-color: #1e293b; color: #f1f5f9; padding: 4px 8px; }"
            "QAbstractItemView::item:selected { background-color: #0284c7; color: #ffffff; }"
        )
        self.cmb_color.addItem(tr("v3d_col_rgb"), COLOR_RGB)
        self.cmb_color.addItem(tr("v3d_col_elev"), COLOR_ELEVATION)
        self.cmb_color.addItem(tr("v3d_col_class"), COLOR_CLASS)
        self.cmb_color.addItem(tr("v3d_col_inten"), COLOR_INTENSITY)
        self.cmb_color.setCurrentIndex(0)
        self.cmb_color.currentIndexChanged.connect(self._on_color_changed)
        row1.addWidget(self.cmb_color)

        # 1c. Customizable Style Button (2D & 3D)
        self.btn_style = QToolButton(bar)
        self.btn_style.setText(tr("v3d_style_btn"))
        self.btn_style.setToolTip(tr("v3d_style_tip"))
        self.btn_style.clicked.connect(self._open_style_dialog)
        row1.addWidget(self.btn_style)

        # 1d. Point size slider
        self.lbl_psize = QLabel(tr("v3d_tb_psize"), bar)
        row1.addWidget(self.lbl_psize)

        self.sld_psize = QSlider(Qt.Orientation.Horizontal, bar)
        self.sld_psize.setRange(5, 45)
        self.sld_psize.setValue(14)
        self.sld_psize.setFixedWidth(56)
        self.sld_psize.valueChanged.connect(self._on_psize_changed)
        row1.addWidget(self.sld_psize)

        # 1e. ASPRS Class visibility filter menu
        self.btn_classes = QToolButton(bar)
        self.btn_classes.setText(tr("v3d_tb_classes"))
        self.btn_classes.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu_classes = QMenu(self.btn_classes)
        self._class_actions: Dict[str, Tuple[QAction, Tuple[int, ...]]] = {}
        class_defs = [
            ("v3d_cls_ground", (2,), True),
            ("v3d_cls_low_veg", (3,), True),
            ("v3d_cls_med_veg", (4,), True),
            ("v3d_cls_high_veg", (5,), True),
            ("v3d_cls_building", (6,), True),
            ("v3d_cls_water", (9,), True),
            ("v3d_cls_bridge", (17,), True),
            ("v3d_cls_unclass", (0, 1, 8, 10, 11), True),
            ("v3d_cls_noise", (7, 18), False),
        ]
        for key, codes, default_checked in class_defs:
            act = QAction(tr(key), self.menu_classes)
            act.setCheckable(True)
            act.setChecked(default_checked)
            act.toggled.connect(lambda checked, c=codes: self._on_class_toggled(c, checked))
            self.menu_classes.addAction(act)
            self._class_actions[key] = (act, codes)
        self.btn_classes.setMenu(self.menu_classes)
        row1.addWidget(self.btn_classes)

        # 1e-2. Vertical Wall & Surface Void Interpolation Toggle (Kuressaare Castle / Steep Walls)
        self.btn_infill = QToolButton(bar)
        self.btn_infill.setText(tr("v3d_tb_infill"))
        self.btn_infill.setToolTip(tr("v3d_tb_infill_tip"))
        self.btn_infill.setCheckable(True)
        self.btn_infill.setChecked(True)
        self.btn_infill.toggled.connect(self._on_infill_toggled)
        row1.addWidget(self.btn_infill)

        # 1f. Dedicated Toolbar Button for Drone Data & Independent Styling
        self.btn_drone_data = QToolButton(bar)
        self.btn_drone_data.setText(tr("v3d_tb_drone_data"))
        self.btn_drone_data.setToolTip(tr("v3d_tb_drone_data_tip"))
        self.btn_drone_data.setStyleSheet(
            "QToolButton { background: #0284c7; color: #ffffff; font-weight: bold; padding: 3px 8px; border-radius: 4px; border: 1px solid #38bdf8; }"
            "QToolButton:hover { background: #0369a1; }"
        )
        self.btn_drone_data.clicked.connect(self.open_drone_data_panel)
        row1.addWidget(self.btn_drone_data)

        # 1g. Dedicated Toolbar Button for Drone Signal Strength Simulation
        self.btn_signal = QToolButton(bar)
        self.btn_signal.setText("📡 " + tr("v3d_tb_signal", fallback="Signaal"))
        self.btn_signal.setToolTip(tr("v3d_tb_signal_tip", fallback="Drooni juhtsignaali analüüs ja levi simulatsioon (Mavic 3E / Matrice 4T / jne)"))
        self.btn_signal.setStyleSheet(
            "QToolButton { background: #059669; color: #ffffff; font-weight: bold; padding: 3px 8px; border-radius: 4px; border: 1px solid #34d399; }"
            "QToolButton:hover { background: #047857; }"
        )
        self.btn_signal.clicked.connect(self.open_signal_panel)
        row1.addWidget(self.btn_signal)

        row1.addStretch(1)

        # 1j. 1:2000 WFS Grid toggle
        self.btn_grid = QToolButton(bar)
        self.btn_grid.setIcon(self._icon("icon_grid.svg"))
        self.btn_grid.setIconSize(QSize(16, 16))
        self.btn_grid.setText("1:2000")
        self.btn_grid.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.btn_grid.setToolTip(tr("btn_grid_tooltip"))
        self.btn_grid.clicked.connect(self.toggle_grid_requested.emit)
        row1.addWidget(self.btn_grid)

        # 1k. Flight Years & Layers Drawer toggle
        self.btn_layers = QToolButton(bar)
        self.btn_layers.setIcon(self._icon("icon_layers.svg"))
        self.btn_layers.setIconSize(QSize(16, 16))
        self.btn_layers.setText(tr("v3d_tb_layers"))
        self.btn_layers.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.btn_layers.setCheckable(True)
        self.btn_layers.setChecked(True)
        self.btn_layers.setToolTip(tr("v3d_tb_layers_tip"))
        self.btn_layers.toggled.connect(self._toggle_layers_drawer)
        row1.addWidget(self.btn_layers)

        # 1l. Settings button
        self.btn_settings = QToolButton(bar)
        self.btn_settings.setIcon(self._icon("icon_settings.svg"))
        self.btn_settings.setIconSize(QSize(16, 16))
        self.btn_settings.setToolTip(tr("btn_settings_tooltip"))
        self.btn_settings.clicked.connect(self.open_settings_requested.emit)
        row1.addWidget(self.btn_settings)

        # ------------------------------------------------------------------ #
        # ROW 2: 2D Canvas in 3D, LOS, Info, Measurement, Stream, Reset, Export, Photo
        # ------------------------------------------------------------------ #
        # 2a. 2D Canvas Layers in 3D (DEFAULT OFF) + Line-of-Sight (LOS) + Info mode
        self.btn_canvas_3d = QToolButton(bar)
        self.btn_canvas_3d.setText(tr("v3d_tb_canvas_lyrs"))
        self.btn_canvas_3d.setToolTip(tr("v3d_tb_canvas_lyrs_tip"))
        self.btn_canvas_3d.setCheckable(True)
        self.btn_canvas_3d.setChecked(False)
        self.btn_canvas_3d.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.menu_canvas_3d = QMenu(self.btn_canvas_3d)
        self.menu_canvas_3d.aboutToShow.connect(self._populate_canvas_layers_menu)
        self.btn_canvas_3d.setMenu(self.menu_canvas_3d)
        self.btn_canvas_3d.toggled.connect(self._on_canvas_3d_toggled)
        row2.addWidget(self.btn_canvas_3d)

        self.btn_los = QToolButton(bar)
        self.btn_los.setText(tr("v3d_tb_los"))
        self.btn_los.setToolTip(tr("v3d_tb_los_tip"))
        self.btn_los.setCheckable(True)
        self.btn_los.setChecked(True)
        self.btn_los.toggled.connect(self._on_los_toggled)
        row2.addWidget(self.btn_los)

        self.btn_info = QToolButton(bar)
        self.btn_info.setText("ℹ️ " + tr("v3d_info_btn", fallback="Info"))
        self.btn_info.setToolTip("ℹ️ Inforežiim [I] — klõpsa 2D kihil atribuutide vaatamiseks")
        self.btn_info.setCheckable(True)
        self.btn_info.setChecked(False)
        self.btn_info.toggled.connect(lambda checked: self.viewer.set_info_mode(checked) if hasattr(self, "viewer") and self.viewer else None)
        row2.addWidget(self.btn_info)

        row2.addWidget(self._sep(bar))

        # 2b. Measurement mode buttons
        self.measure_group = QButtonGroup(self)
        self.measure_group.setExclusive(True)

        self.btn_m_off = QToolButton(bar)
        self.btn_m_off.setText(tr("v3d_tb_measure_off"))
        self.btn_m_off.setCheckable(True)
        self.btn_m_off.setChecked(True)
        self.measure_group.addButton(self.btn_m_off, 0)
        row2.addWidget(self.btn_m_off)

        self.btn_m_dist = QToolButton(bar)
        self.btn_m_dist.setText(tr("v3d_tb_measure_dist"))
        self.btn_m_dist.setCheckable(True)
        self.measure_group.addButton(self.btn_m_dist, 1)
        row2.addWidget(self.btn_m_dist)

        self.btn_m_area = QToolButton(bar)
        self.btn_m_area.setText(tr("v3d_tb_measure_area"))
        self.btn_m_area.setCheckable(True)
        self.measure_group.addButton(self.btn_m_area, 2)
        row2.addWidget(self.btn_m_area)

        self.btn_m_vol = QToolButton(bar)
        self.btn_m_vol.setText(tr("v3d_tb_measure_vol"))
        self.btn_m_vol.setCheckable(True)
        self.measure_group.addButton(self.btn_m_vol, 3)
        row2.addWidget(self.btn_m_vol)

        self.measure_group.idClicked.connect(self._on_measure_btn_clicked)

        self.btn_m_clear = QToolButton(bar)
        self.btn_m_clear.setText(tr("v3d_tb_measure_clear"))
        self.btn_m_clear.setToolTip(tr("drone_measure_clear"))
        self.btn_m_clear.clicked.connect(lambda: self.viewer.clear_measure())
        row2.addWidget(self.btn_m_clear)

        row2.addWidget(self._sep(bar))

        # 2c. Auto-stream adjacent tiles checkbox
        self.chk_autostream = QCheckBox(tr("v3d_tb_autostream"), bar)
        self.chk_autostream.setChecked(True)
        self.chk_autostream.setToolTip(tr("v3d_tb_autostream_tip"))
        self.chk_autostream.toggled.connect(self._on_autostream_toggled)
        row2.addWidget(self.chk_autostream)

        # 2d. Reset view & Export flight log
        self.btn_reset = QToolButton(bar)
        self.btn_reset.setText(tr("v3d_tb_reset"))
        self.btn_reset.setToolTip(tr("v3d_tb_reset_tip"))
        self.btn_reset.clicked.connect(lambda: self.viewer.reset_view())
        row2.addWidget(self.btn_reset)

        self.btn_export = QToolButton(bar)
        self.btn_export.setText(tr("v3d_tb_export_log"))
        self.btn_export.setToolTip(tr("v3d_tb_export_tip"))
        self.btn_export.clicked.connect(self._export_flight_csv)
        row2.addWidget(self.btn_export)

        # 2e. Photo Mode Button (Drone photoshoot with UI on/off; default = UI on)
        self.btn_photo = QToolButton(bar)
        self.btn_photo.setText("📸 " + tr("v3d_photo_btn"))
        self.btn_photo.setToolTip(tr("v3d_photo_tip"))
        self.btn_photo.setCheckable(True)
        self.btn_photo.setChecked(False)
        self.btn_photo.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.menu_photo = QMenu(self.btn_photo)

        self.act_photo_mode = QAction("📸 " + tr("v3d_photo_btn"), self.menu_photo)
        self.act_photo_mode.setCheckable(True)
        self.act_photo_mode.setChecked(False)
        self.act_photo_mode.triggered.connect(lambda: self.viewer.set_photo_mode(not self.viewer.photo_mode))
        self.menu_photo.addAction(self.act_photo_mode)

        self.act_photo_ui = QAction("🖼️ " + tr("v3d_photo_include_ui") + " (U)", self.menu_photo)
        self.act_photo_ui.setCheckable(True)
        self.act_photo_ui.setChecked(True)  # DEFAULT = UI ON
        self.act_photo_ui.triggered.connect(lambda checked: self.viewer.set_photo_ui(checked))
        self.menu_photo.addAction(self.act_photo_ui)

        self.act_photo_snap = QAction("⚡ " + tr("v3d_photo_save_as"), self.menu_photo)
        self.act_photo_snap.triggered.connect(lambda: self.viewer.take_photo_shot())
        self.menu_photo.addAction(self.act_photo_snap)

        self.menu_photo.addSeparator()

        self.act_photo_batch = QAction("💾 " + tr("v3d_photo_export_batch", count=0), self.menu_photo)
        self.act_photo_batch.triggered.connect(self.export_session_photos_batch)
        self.menu_photo.addAction(self.act_photo_batch)

        self.act_photo_clear = QAction("🗑️ " + tr("v3d_photo_clear_session"), self.menu_photo)
        self.act_photo_clear.triggered.connect(self.clear_photos_session)
        self.menu_photo.addAction(self.act_photo_clear)

        self.act_photo_clip = QAction("📋 " + tr("v3d_photo_copy_clip"), self.menu_photo)
        self.act_photo_clip.triggered.connect(lambda: self.take_photo(to_clipboard=True))
        self.menu_photo.addAction(self.act_photo_clip)

        self.menu_photo.addSeparator()

        self.act_photo_folder = QAction("📂 " + tr("v3d_photo_open_folder"), self.menu_photo)
        self.act_photo_folder.triggered.connect(self.open_photos_folder)
        self.menu_photo.addAction(self.act_photo_folder)

        self.btn_photo.setMenu(self.menu_photo)
        self.btn_photo.clicked.connect(lambda: self.viewer.set_photo_mode(not self.viewer.photo_mode))
        row2.addWidget(self.btn_photo)

        row2.addStretch(1)

        tb_layout.addLayout(row1)
        tb_layout.addLayout(row2)

        self.toolbar_scroll.setWidget(bar)
        root_layout.addWidget(self.toolbar_scroll)

        # ------------------------------------------------------------------ #
        # 2. Central Splitter: 3D OpenGL Viewport + Modernized Dark Drawer
        # ------------------------------------------------------------------ #
        self.splitter = QSplitter(Qt.Orientation.Horizontal, root)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStyleSheet(
            "QSplitter::handle { background-color: #1e293b; width: 2px; }"
        )

        # 2a. OpenGL 3D Drone Viewport
        self.viewer = AlsGLViewer(self.splitter)
        self.viewer.tile_requested.connect(self.tile_stream_requested.emit)
        self.viewer.measurement_changed.connect(self._sync_measure_buttons)
        self.viewer.scene_layers_changed.connect(self.refresh_scene_3d_tree)
        self.viewer.camera_moved.connect(self._on_viewer_camera_moved)
        self.viewer.photo_requested.connect(lambda: self.take_photo(prompt_save=False))
        self.viewer.photo_mode_toggled.connect(self._on_photo_mode_toggled)
        self.viewer.photo_ui_toggled.connect(self._on_photo_ui_toggled)
        self.viewer.photo_captured.connect(self._on_photo_captured)
        self.viewer.info_mode_toggled.connect(self._on_viewer_info_mode_toggled)

        # 3D Feature Info Mode Popup
        self.info_popup = FeatureInfoPopup(parent=self.viewer)
        self.viewer.info_popup = self.info_popup
        self.viewer.feature_selected.connect(self._on_feature_selected)
        self.info_popup.popup_closed.connect(self.viewer.clear_feature_selection)
        self.info_popup.popup_moved.connect(self.viewer.update)
        self.splitter.addWidget(self.viewer)

        # Dedicated Independent Drone Data & Styling Dialog
        self.drone_panel = DroneDataDialog(self.viewer, self, parent=self)
        self.viewer.scene_layers_changed.connect(lambda: self.drone_panel.refresh_layer_list() if hasattr(self, "drone_panel") else None)
        self.loader.tile_ready.connect(lambda *args: self.drone_panel.refresh_layer_list() if hasattr(self, "drone_panel") else None)

        # Dedicated Independent Drone Signal Strength Simulation Dialog
        self.signal_dialog = DroneSignalDialog(self.viewer, self, parent=self)
        self.viewer.camera_moved.connect(self.signal_dialog.update_live_telemetry)

        # 2b. Modernized Dark-Cockpit Right-Side Drawer (`Aastad / kihid`)
        self.drawer = QWidget(self.splitter)
        self.drawer.setObjectName("MaruAlsDrawer")
        self.drawer.setStyleSheet(DARK_COCKPIT_QSS)
        self.drawer.setMinimumWidth(260)
        self.drawer.setMaximumWidth(480)
        dl = QVBoxLayout(self.drawer)
        dl.setContentsMargins(8, 8, 8, 8)
        dl.setSpacing(6)

        self.drawer_tabs = QTabWidget(self.drawer)
        self.drawer_tabs.setObjectName("MaruAlsDrawerTabs")

        # ================================================================== #
        # TAB 1: ALS (LAZ) Multi-Year Flights + Overflight Merging
        # ================================================================== #
        tab_als = QWidget()
        als_layout = QVBoxLayout(tab_als)
        als_layout.setContentsMargins(6, 6, 6, 6)
        als_layout.setSpacing(5)

        self.lbl_drawer_title = QLabel(tr("dock_section_session_tiles"), tab_als)
        self.lbl_drawer_title.setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 11px;")
        als_layout.addWidget(self.lbl_drawer_title)

        self.chk_merge_flights = QCheckBox(tr("v3d_chk_merge_flights"), tab_als)
        self.chk_merge_flights.setChecked(True)
        self.chk_merge_flights.setToolTip(tr("v3d_btn_merge_tile_tip"))
        self.chk_merge_flights.toggled.connect(self._on_merge_flights_toggled)
        als_layout.addWidget(self.chk_merge_flights)

        self.tree = QTreeWidget(tab_als)
        self.tree.setAlternatingRowColors(True)
        self.tree.setIndentation(14)
        self.tree.setHeaderLabels([
            tr("dock_col_year"),
            tr("dock_col_type"),
            tr("dock_col_size"),
            tr("dock_col_status"),
        ])
        if SelectRows:
            self.tree.setSelectionBehavior(SelectRows)
        hdr = self.tree.header()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.itemDoubleClicked.connect(self._on_tree_double_clicked)
        als_layout.addWidget(self.tree, 1)

        self.btn_load_sel = QPushButton(tr("dock_btn_load_selected"), tab_als)
        self.btn_load_sel.setObjectName("PrimaryCockpitBtn")
        self.btn_load_sel.clicked.connect(self._on_load_selected_clicked)
        als_layout.addWidget(self.btn_load_sel)

        self.btn_merge_tile = QPushButton(tr("v3d_btn_merge_tile"), tab_als)
        self.btn_merge_tile.setToolTip(tr("v3d_btn_merge_tile_tip"))
        self.btn_merge_tile.clicked.connect(self._on_merge_tile_overflights_clicked)
        als_layout.addWidget(self.btn_merge_tile)

        btn_row = QHBoxLayout()
        self.btn_load_all = QPushButton(tr("dock_btn_load_all"), tab_als)
        self.btn_load_all.setToolTip(tr("dock_btn_load_all_tip"))
        self.btn_load_all.clicked.connect(self.load_all_requested.emit)
        btn_row.addWidget(self.btn_load_all)

        self.btn_clear_list = QPushButton(tr("dock_btn_clear_all"), tab_als)
        self.btn_clear_list.clicked.connect(self.clear_all)
        btn_row.addWidget(self.btn_clear_list)
        als_layout.addLayout(btn_row)

        self.drawer_tabs.addTab(tab_als, tr("v3d_tab_als"))

        # ================================================================== #
        # TAB 2: Additional MaRu Layers (DSM, DTM, Orthophotos, Basic Map)
        # ================================================================== #
        tab_extra = QWidget()
        extra_layout = QVBoxLayout(tab_extra)
        extra_layout.setContentsMargins(6, 6, 6, 6)
        extra_layout.setSpacing(6)

        self.lbl_extra_title = QLabel(tr("v3d_extra_title"), tab_extra)
        self.lbl_extra_title.setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 11px;")
        extra_layout.addWidget(self.lbl_extra_title)

        # Category checkboxes grid
        cat_grid = QGridLayout()
        cat_grid.setContentsMargins(2, 2, 2, 2)
        cat_grid.setSpacing(4)
        self._extra_cat_checks: Dict[str, QCheckBox] = {}
        cat_items = [
            ("dsm_1m", "cat_dsm_1m", True),
            ("dtm_1m", "cat_dtm_1m", True),
            ("orto_rgb", "cat_orto_rgb", True),
            ("orto_madal", "cat_orto_madal", False),
            ("orto_cir", "cat_orto_cir", False),
            ("orto_ngr", "cat_orto_ngr", False),
            ("pk_varj", "cat_pk_varj", True),
        ]
        for idx, (cat_key, tr_key, def_chk) in enumerate(cat_items):
            chk = QCheckBox(tr(tr_key), tab_extra)
            chk.setChecked(def_chk)
            self._extra_cat_checks[cat_key] = chk
            cat_grid.addWidget(chk, idx // 2, idx % 2)
        extra_layout.addLayout(cat_grid)

        self.btn_fetch_extra = QPushButton(tr("v3d_extra_fetch"), tab_extra)
        self.btn_fetch_extra.setToolTip(tr("v3d_extra_fetch_tip"))
        self.btn_fetch_extra.clicked.connect(self.emit_fetch_extra_layers)
        extra_layout.addWidget(self.btn_fetch_extra)

        self.tree_extra = QTreeWidget(tab_extra)
        self.tree_extra.setAlternatingRowColors(True)
        self.tree_extra.setIndentation(14)
        self.tree_extra.setHeaderLabels([
            tr("v3d_extra_col_layer"),
            tr("v3d_extra_col_scale"),
            tr("dock_col_size"),
            tr("dock_col_status"),
        ])
        if SelectRows:
            self.tree_extra.setSelectionBehavior(SelectRows)
        ehdr = self.tree_extra.header()
        ehdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        ehdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        ehdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        ehdr.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tree_extra.itemDoubleClicked.connect(self._on_extra_tree_double_clicked)
        extra_layout.addWidget(self.tree_extra, 1)

        self.btn_load_extra = QPushButton(tr("v3d_extra_load"), tab_extra)
        self.btn_load_extra.setObjectName("PrimaryCockpitBtn")
        self.btn_load_extra.clicked.connect(self._on_load_extra_selected_clicked)
        extra_layout.addWidget(self.btn_load_extra)

        self.drawer_tabs.addTab(tab_extra, tr("v3d_tab_extra"))

        # ================================================================== #
        # TAB 3: 3D Scene Layer Browser + QGIS 2D Canvas Layers Toggle Panel
        # ================================================================== #
        tab_scene = QWidget()
        scene_layout = QVBoxLayout(tab_scene)
        scene_layout.setContentsMargins(6, 6, 6, 6)
        scene_layout.setSpacing(5)

        # --- Top Half: 3D Scene Layer Browser ---
        self.lbl_scene_3d_title = QLabel(tr("v3d_scene_3d_title"), tab_scene)
        self.lbl_scene_3d_title.setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 11px;")
        scene_layout.addWidget(self.lbl_scene_3d_title)

        self.chk_scene_infill = QCheckBox(tr("v3d_chk_infill"), tab_scene)
        self.chk_scene_infill.setChecked(True)
        self.chk_scene_infill.setToolTip(tr("v3d_tb_infill_tip"))
        self.chk_scene_infill.toggled.connect(self._on_infill_toggled)
        scene_layout.addWidget(self.chk_scene_infill)

        self.chk_scene_merge = QCheckBox(tr("v3d_chk_merge_flights"), tab_scene)
        self.chk_scene_merge.setChecked(True)
        self.chk_scene_merge.setToolTip(tr("v3d_btn_merge_tile_tip"))
        self.chk_scene_merge.toggled.connect(self._on_merge_flights_toggled)
        scene_layout.addWidget(self.chk_scene_merge)

        self.tree_scene_3d = QTreeWidget(tab_scene)
        self.tree_scene_3d.setAlternatingRowColors(True)
        self.tree_scene_3d.setRootIsDecorated(False)
        self.tree_scene_3d.setHeaderLabels([
            tr("v3d_scene_col_name"),
            tr("v3d_scene_col_type"),
            tr("v3d_scene_col_pts"),
        ])
        shdr = self.tree_scene_3d.header()
        shdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        shdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        shdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tree_scene_3d.itemChanged.connect(self._on_scene_3d_item_changed)
        scene_layout.addWidget(self.tree_scene_3d, 1)

        layer_btn_row = QHBoxLayout()
        layer_btn_row.setContentsMargins(0, 2, 0, 2)
        layer_btn_row.setSpacing(6)

        self.btn_import_drone = QPushButton("🛸 " + tr("v3d_tb_drone_data"), tab_scene)
        self.btn_import_drone.setStyleSheet(
            "QPushButton { background: #0284c7; color: #ffffff; font-weight: bold; padding: 5px 8px; border-radius: 4px; border: 1px solid #38bdf8; }"
            "QPushButton:hover { background: #0369a1; }"
        )
        self.btn_import_drone.setToolTip(tr("v3d_tb_drone_data_tip"))
        self.btn_import_drone.clicked.connect(self.open_drone_data_panel)
        layer_btn_row.addWidget(self.btn_import_drone, 1)

        self.btn_remove_3d_layer = QPushButton(tr("v3d_scene_remove"), tab_scene)
        self.btn_remove_3d_layer.clicked.connect(self._on_remove_selected_3d_layer)
        layer_btn_row.addWidget(self.btn_remove_3d_layer)
        scene_layout.addLayout(layer_btn_row)

        # --- Bottom Half: QGIS 2D Canvas Layers Toggle Panel (Default OFF) ---
        hdr_2d_row = QHBoxLayout()
        self.lbl_scene_2d_title = QLabel(tr("v3d_scene_2d_title"), tab_scene)
        self.lbl_scene_2d_title.setStyleSheet("color: #f472b6; font-weight: bold; font-size: 11px;")
        hdr_2d_row.addWidget(self.lbl_scene_2d_title, 1)

        self.btn_refresh_2d_tree = QPushButton("↻", tab_scene)
        self.btn_refresh_2d_tree.setFixedWidth(30)
        self.btn_refresh_2d_tree.setToolTip(tr("v3d_canvas_menu_refresh"))
        self.btn_refresh_2d_tree.clicked.connect(self.refresh_canvas_2d_tree)
        hdr_2d_row.addWidget(self.btn_refresh_2d_tree)
        scene_layout.addLayout(hdr_2d_row)

        self.chk_scene_los = QCheckBox(tr("v3d_tb_los") + " — " + tr("v3d_tb_los_tip")[:48] + "...", tab_scene)
        self.chk_scene_los.setChecked(True)
        self.chk_scene_los.setToolTip(tr("v3d_tb_los_tip"))
        self.chk_scene_los.toggled.connect(self._on_los_toggled)
        scene_layout.addWidget(self.chk_scene_los)

        # Buffer dial for 2D canvas layers in 3D (Default 1000m AOI buffer)
        buf_row = QHBoxLayout()
        buf_row.setContentsMargins(0, 2, 0, 2)
        buf_row.setSpacing(6)
        self.lbl_canvas_buffer = QLabel(tr("v3d_canvas_buffer"), tab_scene)
        self.lbl_canvas_buffer.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        buf_row.addWidget(self.lbl_canvas_buffer)

        self.spn_canvas_buffer = QSpinBox(tab_scene)
        self.spn_canvas_buffer.setRange(100, 10000)
        self.spn_canvas_buffer.setSingleStep(50)
        self.spn_canvas_buffer.setValue(1000)  # default 1000m AOI radius
        self.spn_canvas_buffer.setSuffix(" m")
        self.spn_canvas_buffer.setToolTip(tr("v3d_canvas_buffer_tip"))
        self.spn_canvas_buffer.valueChanged.connect(self._on_buffer_dial_changed)
        buf_row.addWidget(self.spn_canvas_buffer, 1)
        scene_layout.addLayout(buf_row)

        self.tree_canvas_2d = QTreeWidget(tab_scene)
        self.tree_canvas_2d.setAlternatingRowColors(True)
        self.tree_canvas_2d.setRootIsDecorated(False)
        self.tree_canvas_2d.setHeaderLabels([
            tr("v3d_scene_col_2d_name"),
            tr("v3d_scene_col_2d_geom"),
        ])
        chdr = self.tree_canvas_2d.header()
        chdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        chdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tree_canvas_2d.itemChanged.connect(self._on_canvas_2d_tree_item_changed)
        scene_layout.addWidget(self.tree_canvas_2d, 1)

        self.drawer_tabs.addTab(tab_scene, tr("v3d_tab_scene"))

        dl.addWidget(self.drawer_tabs, 1)

        # ================================================================== #
        # Drawer Bottom Live Loading Progress Bar (Downloads + Decoding)
        # ================================================================== #
        self.progress_frame = QFrame(self.drawer)
        self.progress_frame.setObjectName("MaruAlsProgressFrame")
        pfl = QVBoxLayout(self.progress_frame)
        pfl.setContentsMargins(8, 5, 8, 6)
        pfl.setSpacing(3)

        self.lbl_progress = QLabel(tr("v3d_progress_idle"), self.progress_frame)
        self.lbl_progress.setStyleSheet("color: #38bdf8; font-weight: 600; font-size: 10px;")
        self.lbl_progress.setWordWrap(True)
        pfl.addWidget(self.lbl_progress)

        self.progress_bar = QProgressBar(self.progress_frame)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p%")
        pfl.addWidget(self.progress_bar)

        self.progress_frame.setVisible(False)
        dl.addWidget(self.progress_frame)

        self.splitter.addWidget(self.drawer)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([920, 370])

        root_layout.addWidget(self.splitter, 1)
        self.setWidget(root)

    @staticmethod
    def _sep(parent: QWidget) -> QFrame:
        line = QFrame(parent)
        line.setFrameShape(QFrame.Shape.VLine)
        line.setStyleSheet("color: #334155;")
        return line

    # ------------------------------------------------------------------ #
    # Live Progress Bar (Drawer + 3D Viewer HUD Sync)
    # ------------------------------------------------------------------ #
    def set_progress(self, percent: int, text: str = "", visible: bool = True):
        """Updates live loading % in both the right-side drawer and the 3D viewport HUD."""
        pct = max(0, min(100, int(percent)))
        if visible and (pct < 100 or text):
            self.progress_frame.setVisible(True)
            self.progress_bar.setValue(pct)
            if text:
                self.lbl_progress.setText(text)
        self.viewer.set_loading_progress(pct, text)
        if pct >= 100 or not visible:
            QTimer.singleShot(1400, self._hide_progress_if_done)

    def _hide_progress_if_done(self):
        if self.progress_bar.value() >= 100 and self.viewer.pending_count() == 0:
            self.progress_frame.setVisible(False)
            self.viewer.set_loading_progress(100, "")

    def _on_loader_progress(self, tile_id: str, pct: int, text: str):
        self.set_progress(pct, text, visible=(pct < 100))

    # ------------------------------------------------------------------ #
    # Toolbar & Style Customizer callbacks
    # ------------------------------------------------------------------ #
    def set_arrow_checked(self, checked: bool):
        self.btn_arrow.blockSignals(True)
        self.btn_arrow.setChecked(checked)
        self.btn_arrow.blockSignals(False)

    def set_aoi_mode(self, mode: str, emit_signal: bool = True):
        """Switches AOI selection mode between 'arrow' and 'rectangle'."""
        self.aoi_mode = mode
        if mode == "rectangle":
            self.btn_arrow.setIcon(self._icon("icon_rect.svg"))
            self.btn_arrow.setText(tr("v3d_tb_rect"))
            self.btn_arrow.setToolTip(tr("v3d_tb_rect_tip"))
            if hasattr(self, "act_aoi_rect"):
                self.act_aoi_rect.blockSignals(True)
                self.act_aoi_rect.setChecked(True)
                self.act_aoi_rect.blockSignals(False)
        else:
            self.btn_arrow.setIcon(self._icon("icon_arrow.svg"))
            self.btn_arrow.setText(tr("v3d_tb_arrow"))
            self.btn_arrow.setToolTip(tr("v3d_tb_arrow_tip"))
            if hasattr(self, "act_aoi_arrow"):
                self.act_aoi_arrow.blockSignals(True)
                self.act_aoi_arrow.setChecked(True)
                self.act_aoi_arrow.blockSignals(False)

        if not self.btn_arrow.isChecked():
            self.btn_arrow.setChecked(True)
        elif emit_signal:
            self.arrow_tool_toggled.emit(True)

        if emit_signal:
            self.aoi_mode_changed.emit(mode)

    def _on_color_changed(self, idx: int):
        mode = self.cmb_color.itemData(idx)
        if mode is not None:
            self.viewer.set_color_mode(int(mode))
            style_map = {
                COLOR_RGB: "rgb",
                COLOR_ELEVATION: "elevation",
                COLOR_CLASS: "classification",
                COLOR_INTENSITY: "intensity",
            }
            if int(mode) in style_map:
                self.symbology_2d_requested.emit(style_map[int(mode)])
        self.viewer.setFocus()

    def _open_style_dialog(self):
        dlg = AlsStyleDialog(self.viewer, self)
        dlg.style_applied.connect(
            lambda: self.symbology_2d_requested.emit(PointCloudSymbology.active_mode)
        )
        dlg.exec()
        self.viewer.setFocus()

    def _on_psize_changed(self, val: int):
        self.viewer.set_point_size(val / 10.0)

    def _on_class_toggled(self, codes: Tuple[int, ...], checked: bool):
        for c in codes:
            self.viewer.set_class_visible(c, checked)

    def _on_infill_toggled(self, checked: bool):
        """Toggles vertical wall & surface void interpolation (Kuressaare Castle / walls)."""
        self.viewer.set_interpolate_verticals(checked)
        if self.btn_infill.isChecked() != checked:
            self.btn_infill.blockSignals(True)
            self.btn_infill.setChecked(checked)
            self.btn_infill.blockSignals(False)
        if self.chk_scene_infill.isChecked() != checked:
            self.chk_scene_infill.blockSignals(True)
            self.chk_scene_infill.setChecked(checked)
            self.chk_scene_infill.blockSignals(False)
        self.refresh_scene_3d_tree()
        self.viewer.setFocus()

    def _on_merge_flights_toggled(self, checked: bool):
        """Toggles whether opening another flight year for the same tile merges or replaces."""
        self.viewer.set_merge_overflights(checked)
        if self.chk_merge_flights.isChecked() != checked:
            self.chk_merge_flights.blockSignals(True)
            self.chk_merge_flights.setChecked(checked)
            self.chk_merge_flights.blockSignals(False)
        if self.chk_scene_merge.isChecked() != checked:
            self.chk_scene_merge.blockSignals(True)
            self.chk_scene_merge.setChecked(checked)
            self.chk_scene_merge.blockSignals(False)

    def _on_merge_tile_overflights_clicked(self):
        """
        Downloads and merges multiple overflights (e.g. Low-alt + Forest + Regular) for the
        selected tile (or all session tiles) into 3D to fill vertical/shadow gaps.
        """
        self._on_merge_flights_toggled(True)
        target_tiles: List[str] = []
        item = self.tree.currentItem()
        if item is not None:
            data = item.data(0, UserRole)
            if isinstance(data, str) and data in self.session_data:
                target_tiles = [data]
            elif isinstance(data, AlsFileInfo):
                target_tiles = [data.tile_id]
        if not target_tiles:
            target_tiles = list(self.session_data.keys())

        for tid in target_tiles:
            files = self.session_data.get(tid, [])
            if not files:
                continue
            # Pick up to 3 flights with diverse flight_types (madal, mets, tava) to maximize angular coverage
            chosen: List[AlsFileInfo] = []
            seen_types: Set[str] = set()
            for f in files:
                if f.flight_type not in seen_types:
                    chosen.append(f)
                    seen_types.add(f.flight_type)
                if len(chosen) >= 3:
                    break
            if len(chosen) < min(2, len(files)):
                for f in files:
                    if f not in chosen:
                        chosen.append(f)
                    if len(chosen) >= 2:
                        break
            for f in chosen:
                self.load_file_requested.emit(f)

    # ------------------------------------------------------------------ #
    # Tab 3 Top: 3D Scene Layer Browser (LAZ / Merged / 3D DSM / 3D Orto)
    # ------------------------------------------------------------------ #
    def refresh_scene_3d_tree(self):
        """Populates `self.tree_scene_3d` with all layers currently opened in the 3D viewport."""
        self.tree_scene_3d.blockSignals(True)
        self.tree_scene_3d.clear()

        cat_label_map = {
            "tava": "LAZ (Tavalend)",
            "mets": "LAZ (Metsalend)",
            "madal": "LAZ (Madallend)",
            "droon_laz": "Droon LAZ (Punktipilv)",
            "droon_dsm": "Droon DSM (Kõrgusmudel)",
            "droon_dtm": "Droon DTM (Maapind)",
            "droon_orto": "Droon Ortofoto (RGB)",
            "dsm_1m": "3D DSM 1m",
            "dtm_1m": "3D DTM 1m",
            "orto_rgb": "3D Orto RGB",
            "orto_madal": "3D Orto madal",
            "orto_cir": "3D Orto CIR",
            "orto_ngr": "3D Orto NGR",
            "pk_varj": "3D Põhikaart",
        }

        for vt in self.viewer.all_scene_layers():
            item = QTreeWidgetItem(self.tree_scene_3d)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                0,
                Qt.CheckState.Checked if vt.visible else Qt.CheckState.Unchecked,
            )
            fname = str(vt.file_info.filename) if vt.file_info else vt.tile_id
            ftype = str(vt.file_info.flight_type) if vt.file_info else "laz"
            type_str = cat_label_map.get(ftype, ftype.upper())
            pts_count = vt.n_points
            if self.viewer.interpolate_verticals and vt.n_infill > 0:
                pts_count += vt.n_infill
                type_str += " + Seinad"

            item.setText(0, f"{vt.tile_id} · {fname}")
            item.setToolTip(0, f"{fname} ({type_str})")
            item.setText(1, type_str)
            item.setText(2, f"{pts_count:,}".replace(",", " "))
            item.setData(0, UserRole, vt.layer_key)

            if ftype.startswith("droon_"):
                col = QColor(245, 158, 11)   # Vibrant amber for drone photogrammetry / LiDAR surveys
            elif vt.is_raster_3d:
                col = QColor(16, 185, 129)
            else:
                col = QColor(56, 189, 248)
            item.setForeground(1, col)

        self.tree_scene_3d.blockSignals(False)

    def _on_scene_3d_item_changed(self, item: QTreeWidgetItem, column: int):
        if column != 0:
            return
        layer_key = item.data(0, UserRole)
        if layer_key:
            checked = item.checkState(0) == Qt.CheckState.Checked
            self.viewer.set_scene_layer_visible(str(layer_key), checked)

    def _on_remove_selected_3d_layer(self):
        item = self.tree_scene_3d.currentItem()
        if not item:
            return
        layer_key = item.data(0, UserRole)
        if layer_key:
            self.viewer.remove_scene_layer(str(layer_key))
            self.refresh_tree_statuses()

    # ------------------------------------------------------------------ #
    # Custom Drone Photogrammetry & LiDAR Survey Import (Step 7)
    # ------------------------------------------------------------------ #
    def open_drone_data_panel(self):
        """Opens or brings forward the independent Drone Data Manager & Styling dialog."""
        if hasattr(self, "drone_panel"):
            self.drone_panel.refresh_layer_list()
            self.drone_panel.show()
            self.drone_panel.raise_()
            self.drone_panel.activateWindow()

    def open_signal_panel(self):
        """Opens or brings forward the independent Drone Signal Strength Simulation dialog."""
        if hasattr(self, "signal_dialog") and self.signal_dialog:
            self.signal_dialog.show()
            self.signal_dialog.raise_()
            self.signal_dialog.activateWindow()

    def open_drone_data_dialog(self):
        """Opens file dialog for user to select drone photogrammetry / LiDAR survey datasets (LAZ/LAS/DSM/Ortho GeoTIFF)."""
        files, _ = QFileDialog.getOpenFileNames(
            self,
            tr("v3d_drone_data_dlg_title"),
            "",
            tr("v3d_drone_data_dlg_filter"),
        )
        if not files:
            return
        for fpath in files:
            self.import_drone_file(fpath)
        self.open_drone_data_panel()

    def import_drone_file(self, fpath: str):
        """Imports a local drone survey file (.laz, .las, .tif, .tiff) into the 3D viewer."""
        if not os.path.exists(fpath):
            return
        stem = os.path.splitext(os.path.basename(fpath))[0]
        ext = os.path.splitext(fpath)[1].lower()
        size_mb = os.path.getsize(fpath) / (1024.0 * 1024.0)

        if ext in (".laz", ".las"):
            tile_id = f"droon_{stem}"
            file_info = AlsFileInfo(
                tile_id=tile_id,
                filename=os.path.basename(fpath),
                year=datetime.datetime.now().year,
                flight_type="droon_laz",
                size_str=f"{size_mb:.1f} MB",
                download_url="",
                downloaded=True,
                local_path=fpath,
                is_raster=False,
            )
            self.viewer.set_tile_state(tile_id, STATE_LOADING)
            self.loader.enqueue(tile_id, fpath, file_info)
            self.set_progress(10, f"Laadin drooni punktipilve: {os.path.basename(fpath)}...", visible=True)

        elif ext in (".tif", ".tiff"):
            tile_id = f"droon_{stem}"
            # Check whether elevation DSM/DTM or RGB Orthomosaic
            is_elev = False
            try:
                from osgeo import gdal
                ds_chk = gdal.Open(fpath, gdal.GA_ReadOnly)
                if ds_chk is not None:
                    if ds_chk.RasterCount == 1 and ds_chk.GetRasterBand(1).DataType >= gdal.GDT_Int16:
                        is_elev = True
                    ds_chk = None
            except Exception:
                pass

            ftype = "droon_dsm" if is_elev else "droon_orto"
            file_info = AlsFileInfo(
                tile_id=tile_id,
                filename=os.path.basename(fpath),
                year=datetime.datetime.now().year,
                flight_type=ftype,
                size_str=f"{size_mb:.1f} MB",
                download_url="",
                downloaded=True,
                local_path=fpath,
                is_raster=True,
            )
            self.viewer.set_tile_state(tile_id, STATE_LOADING)
            ref_ground = None
            for t in self.viewer.tiles.values():
                if t.ground is not None and t.ground.shape[0] > 10:
                    ref_ground = t.ground
                    break
            self.loader.enqueue(tile_id, fpath, file_info, ref_ground=ref_ground)
            self.set_progress(10, f"Laadin drooni rasterit: {os.path.basename(fpath)}...", visible=True)

    # ------------------------------------------------------------------ #
    # Tab 3 Bottom & Toolbar: 2D Canvas Layers in 3D (Default OFF) + LOS
    # ------------------------------------------------------------------ #
    def refresh_canvas_2d_tree(self):
        """
        Populates `self.tree_canvas_2d` in Tab 3 with all vector layers open on the
        QGIS 2D main canvas. By default all layers are UNCHECKED (OFF for 3D).
        """
        self.tree_canvas_2d.blockSignals(True)
        self.tree_canvas_2d.clear()

        proj = QgsProject.instance()
        vec_layers = list_canvas_vector_layers(include_wfs_grid=False)
        valid_ids = {lid for lid, _, _ in vec_layers}
        # Prune removed layer IDs
        self.enabled_canvas_layer_ids &= valid_ids

        geom_names = {
            QgsWkbTypes.GeometryType.PointGeometry: "Punkt (Point)",
            QgsWkbTypes.GeometryType.LineGeometry: "Joon (Line)",
            QgsWkbTypes.GeometryType.PolygonGeometry: "Polügoon (Piirid)",
        }

        for lid, name, vis_2d in vec_layers:
            lyr = proj.mapLayer(lid)
            gtype_str = "Vektor"
            if isinstance(lyr, QgsVectorLayer):
                gtype_str = geom_names.get(QgsWkbTypes.geometryType(lyr.wkbType()), "Vektor")
                if lid not in self._connected_vec_lids:
                    self._connected_vec_lids.add(lid)
                    try:
                        lyr.layerModified.connect(self._on_watched_vector_layer_modified)
                        lyr.featureAdded.connect(self._on_watched_vector_layer_modified)
                        lyr.geometryChanged.connect(self._on_watched_vector_layer_modified)
                        lyr.styleChanged.connect(self._on_watched_vector_layer_modified)
                    except Exception:
                        pass

            item = QTreeWidgetItem(self.tree_canvas_2d)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            is_on_3d = lid in self.enabled_canvas_layer_ids and self.viewer.show_canvas_layers
            item.setCheckState(
                0,
                Qt.CheckState.Checked if is_on_3d else Qt.CheckState.Unchecked,
            )
            suffix = "" if vis_2d else " (2D peidetud)"
            item.setText(0, f"{name}{suffix}")
            item.setToolTip(0, name)
            item.setText(1, gtype_str)
            item.setData(0, UserRole, lid)
            if is_on_3d:
                item.setForeground(0, QColor(244, 114, 182))

        self.tree_canvas_2d.blockSignals(False)

    def _on_watched_vector_layer_modified(self, *args):
        """Automatically re-drapes 2D vector layers in 3D when features or styles are edited (debounced)."""
        if self.viewer.show_canvas_layers and self.enabled_canvas_layer_ids:
            if hasattr(self, "_canvas_layer_sync_timer"):
                self._canvas_layer_sync_timer.start(250)
            else:
                self.refresh_canvas_layers_in_3d()

    def _on_canvas_2d_tree_item_changed(self, item: QTreeWidgetItem, column: int):
        if column != 0:
            return
        lid = item.data(0, UserRole)
        if not lid:
            return
        checked = item.checkState(0) == Qt.CheckState.Checked
        if checked:
            self.enabled_canvas_layer_ids.add(str(lid))
        else:
            self.enabled_canvas_layer_ids.discard(str(lid))

        has_any = len(self.enabled_canvas_layer_ids) > 0
        self.viewer.set_canvas_layers_visible(has_any)
        if self.btn_canvas_3d.isChecked() != has_any:
            self.btn_canvas_3d.blockSignals(True)
            self.btn_canvas_3d.setChecked(has_any)
            self.btn_canvas_3d.blockSignals(False)

        self.tree_canvas_2d.blockSignals(True)
        item.setForeground(
            0,
            QColor(244, 114, 182) if checked else QColor(226, 232, 240),
        )
        self.tree_canvas_2d.blockSignals(False)
        if has_any:
            self.refresh_canvas_layers_in_3d()
        else:
            self.viewer.set_canvas_raw_features([])

    def _on_canvas_3d_toggled(self, checked: bool):
        if checked and not self.enabled_canvas_layer_ids:
            # If user clicked the master toolbar toggle while no individual layers were checked,
            # enable all currently visible 2D vector layers
            vec_layers = list_canvas_vector_layers(include_wfs_grid=False)
            self.enabled_canvas_layer_ids = {lid for lid, name, vis in vec_layers if vis}
        self.viewer.set_canvas_layers_visible(checked)
        self.refresh_canvas_2d_tree()
        if checked:
            self.refresh_canvas_layers_in_3d()
        self.viewer.setFocus()

    def _on_los_toggled(self, checked: bool):
        self.viewer.set_los_occlusion(checked)
        if self.btn_los.isChecked() != checked:
            self.btn_los.blockSignals(True)
            self.btn_los.setChecked(checked)
            self.btn_los.blockSignals(False)
        if self.chk_scene_los.isChecked() != checked:
            self.chk_scene_los.blockSignals(True)
            self.chk_scene_los.setChecked(checked)
            self.chk_scene_los.blockSignals(False)
        self.viewer.setFocus()

    def _populate_canvas_layers_menu(self):
        self.menu_canvas_3d.clear()
        act_refresh = QAction(tr("v3d_canvas_menu_refresh"), self.menu_canvas_3d)
        act_refresh.triggered.connect(self._refresh_both_canvas_2d_and_3d)
        self.menu_canvas_3d.addAction(act_refresh)
        self.menu_canvas_3d.addSeparator()

        vec_layers = list_canvas_vector_layers(include_wfs_grid=False)
        for lid, name, _ in vec_layers:
            act = QAction(name, self.menu_canvas_3d)
            act.setCheckable(True)
            act.setChecked(lid in self.enabled_canvas_layer_ids and self.viewer.show_canvas_layers)
            act.toggled.connect(lambda chk, layer_id=lid: self._on_canvas_layer_item_toggled(layer_id, chk))
            self.menu_canvas_3d.addAction(act)

    def _refresh_both_canvas_2d_and_3d(self):
        self.refresh_canvas_2d_tree()
        self.refresh_canvas_layers_in_3d()

    def _on_canvas_layer_item_toggled(self, layer_id: str, checked: bool):
        if checked:
            self.enabled_canvas_layer_ids.add(layer_id)
        else:
            self.enabled_canvas_layer_ids.discard(layer_id)
        has_any = len(self.enabled_canvas_layer_ids) > 0
        self.viewer.set_canvas_layers_visible(has_any)
        if self.btn_canvas_3d.isChecked() != has_any:
            self.btn_canvas_3d.blockSignals(True)
            self.btn_canvas_3d.setChecked(has_any)
            self.btn_canvas_3d.blockSignals(False)
        self.refresh_canvas_2d_tree()
        if has_any:
            self.refresh_canvas_layers_in_3d()
        else:
            self.viewer.set_canvas_raw_features([])

    def _on_buffer_dial_changed(self, val: int):
        self.canvas_buffer_m = float(val)
        if self.viewer.show_canvas_layers and self.enabled_canvas_layer_ids:
            self.refresh_canvas_layers_in_3d(force=True)

    def _on_viewer_camera_moved(self, x_3301: float, y_3301: float, z: float, agl: float, yaw: float, pitch: float):
        if not self.viewer.show_canvas_layers or not self.enabled_canvas_layer_ids:
            return
        if self._last_draped_xy is None:
            self._last_draped_xy = (x_3301, y_3301)
            self.refresh_canvas_layers_in_3d(force=False)
            return
        # If drone has moved > 35% of buffer distance (e.g. >210m for 600m buffer), re-extract AOI window
        shift = math.hypot(x_3301 - self._last_draped_xy[0], y_3301 - self._last_draped_xy[1])
        if shift > (self.canvas_buffer_m * 0.35):
            self.refresh_canvas_layers_in_3d(force=False)

    def refresh_canvas_layers_in_3d(self, force: bool = False):
        """Extracts enabled 2D canvas vector layers within the AOI buffer around the drone and drapes them onto 3D."""
        if not self.viewer.show_canvas_layers or not self.enabled_canvas_layer_ids:
            self.viewer.set_canvas_raw_features([])
            self._last_draped_xy = None
            return

        buf = float(self.spn_canvas_buffer.value()) if hasattr(self, "spn_canvas_buffer") else self.canvas_buffer_m
        if self.viewer.scene_origin is not None:
            cx, cy = self.viewer.to_abs(self.viewer.cam[0], self.viewer.cam[1])
        else:
            all_tids = list(self.viewer.tiles.keys()) or list(self.session_data.keys())
            if all_tids:
                b = GridEngine.get_tile_bounds(all_tids[0])
                cx = (b[0] + b[2]) / 2.0 if b else 410000.0
                cy = (b[1] + b[3]) / 2.0 if b else 6457000.0
            else:
                cx, cy = 410000.0, 6457000.0

        self._last_draped_xy = (cx, cy)
        bbox_rect = QgsRectangle(cx - buf, cy - buf, cx + buf, cy + buf)

        features = extract_canvas_features_for_3d(
            bbox_3301=bbox_rect,
            enabled_layer_ids=self.enabled_canvas_layer_ids,
            densify_step=12.0,
            max_features_per_layer=1500,
        )
        self.viewer.set_canvas_raw_features(features)

    # ------------------------------------------------------------------ #
    # Measurement & Flight Log callbacks
    # ------------------------------------------------------------------ #
    def _on_measure_btn_clicked(self, btn_id: int):
        modes = {
            0: M.MODE_NONE,
            1: M.MODE_DISTANCE,
            2: M.MODE_AREA,
            3: M.MODE_VOLUME,
        }
        mode = modes.get(btn_id, M.MODE_NONE)
        if self.viewer.measure_mode != mode:
            self.viewer.set_measure_mode(mode)
        self.viewer.setFocus()

    def _sync_measure_buttons(self, info: dict):
        mode = info.get("mode", self.viewer.measure_mode)
        btn_map = {
            M.MODE_NONE: self.btn_m_off,
            M.MODE_DISTANCE: self.btn_m_dist,
            M.MODE_AREA: self.btn_m_area,
            M.MODE_VOLUME: self.btn_m_vol,
        }
        btn = btn_map.get(mode, self.btn_m_off)
        self.measure_group.blockSignals(True)
        btn.setChecked(True)
        self.measure_group.blockSignals(False)

    def _on_autostream_toggled(self, checked: bool):
        self.viewer.auto_stream = checked
        self.viewer.setFocus()

    def _toggle_layers_drawer(self, checked: bool):
        self.drawer.setVisible(checked)

    def _export_flight_csv(self):
        trail = self.viewer.trail_abs()
        if not trail:
            return
        default_name = f"maru_als_flight_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        path, _ = QFileDialog.getSaveFileName(
            self, tr("v3d_tb_export_tip"), default_name, "CSV (*.csv)"
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["timestamp_iso", "x_epsg3301", "y_epsg3301", "z_eh2000_m", "agl_m", "speed_ms"])
                for ts, x, y, z, agl, spd in trail:
                    iso = datetime.datetime.fromtimestamp(ts).isoformat(timespec="milliseconds")
                    w.writerow([iso, f"{x:.2f}", f"{y:.2f}", f"{z:.2f}", f"{agl:.2f}", f"{spd:.2f}"])
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Photo Mode: 3D High-Res Screenshot with UI ON / OFF
    # ------------------------------------------------------------------ #
    def take_photo(self, prompt_save: bool = False, to_clipboard: bool = False):
        """Captures a photo of the 3D viewport with UI either ON or OFF (default = UI ON)."""
        include_ui = self.act_photo_ui.isChecked() if hasattr(self, "act_photo_ui") else True
        img = self.viewer.capture_photo(include_ui=include_ui)
        if img is None or img.isNull():
            return

        # Always copy to system clipboard for immediate Ctrl+V paste into Word/Slack/Teams/PowerPoint
        from qgis.PyQt.QtGui import QGuiApplication
        QGuiApplication.clipboard().setImage(img)

        if to_clipboard and not prompt_save:
            self.set_progress(100, tr("v3d_photo_copied_msg"), visible=False)
            return

        pics_dir = os.path.join(os.path.expanduser("~"), "Pictures", "MaRu_ALS_Photos")
        os.makedirs(pics_dir, exist_ok=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        ui_tag = "_cockpit" if include_ui else "_scenic"
        default_path = os.path.join(pics_dir, f"MaRu_ALS_3D_{ts}{ui_tag}.png")

        save_path = default_path
        if prompt_save:
            save_path, _ = QFileDialog.getSaveFileName(
                self,
                tr("v3d_photo_save_as"),
                default_path,
                "PNG Image (*.png);;JPEG Image (*.jpg *.jpeg)",
            )
            if not save_path:
                return

        try:
            ok = img.save(save_path)
            if ok:
                fname = os.path.basename(save_path)
                self.set_progress(100, tr("v3d_photo_saved_msg", path=fname), visible=False)
                QgsMessageLog.logMessage(f"3D foto salvestatud: {save_path}", "MaRu ALS", Qgis.Info)
        except Exception as e:
            QgsMessageLog.logMessage(f"Foto salvestamise viga: {e}", "MaRu ALS", Qgis.Warning)

    def open_photos_folder(self):
        """Opens user's MaRu ALS Photos directory in the system file manager."""
        pics_dir = os.path.join(os.path.expanduser("~"), "Pictures", "MaRu_ALS_Photos")
        os.makedirs(pics_dir, exist_ok=True)
        from qgis.PyQt.QtGui import QDesktopServices
        from qgis.PyQt.QtCore import QUrl
        QDesktopServices.openUrl(QUrl.fromLocalFile(pics_dir))

    def _on_photo_mode_toggled(self, enabled: bool):
        """Syncs the toolbar button and menu when photo mode is toggled."""
        if hasattr(self, "btn_photo"):
            self.btn_photo.blockSignals(True)
            self.btn_photo.setChecked(enabled)
            self.btn_photo.blockSignals(False)
            if enabled:
                self.btn_photo.setStyleSheet(
                    "QToolButton { background-color: #d97706; color: #ffffff; font-weight: bold; "
                    "border: 1px solid #f59e0b; border-radius: 4px; padding: 3px 8px; }"
                )
            else:
                self.btn_photo.setStyleSheet("")
        if hasattr(self, "act_photo_mode"):
            self.act_photo_mode.blockSignals(True)
            self.act_photo_mode.setChecked(enabled)
            self.act_photo_mode.blockSignals(False)

    def _on_photo_ui_toggled(self, include_ui: bool):
        """Syncs menu action when UI visibility is toggled in photo mode."""
        if hasattr(self, "act_photo_ui"):
            self.act_photo_ui.blockSignals(True)
            self.act_photo_ui.setChecked(include_ui)
            self.act_photo_ui.blockSignals(False)

    def _on_viewer_info_mode_toggled(self, enabled: bool):
        """Syncs Info mode toolbar button state when toggled via keyboard [I] or code."""
        if hasattr(self, "btn_info"):
            self.btn_info.blockSignals(True)
            self.btn_info.setChecked(enabled)
            self.btn_info.blockSignals(False)
            if enabled:
                self.btn_info.setStyleSheet(
                    "QToolButton { background-color: #0284c7; color: #ffffff; font-weight: bold; "
                    "border: 1px solid #38bdf8; border-radius: 4px; padding: 3px 8px; }"
                )
            else:
                self.btn_info.setStyleSheet("")
        if not enabled and hasattr(self, "info_popup") and self.info_popup:
            self.info_popup.hide()

    def _on_feature_selected(self, feat: dict, click_x: float, click_y: float):
        """Called when a 2D feature is picked in 3D viewport during Info Mode."""
        if hasattr(self, "info_popup") and self.info_popup:
            self.info_popup.show_feature(feat, click_x, click_y, self.viewer.width(), self.viewer.height())
            self.viewer.update()

    def _on_photo_captured(self, shot: DronePhotoShot):
        """Called whenever a photo is captured in 3D photoshoot mode."""
        layer = self._get_or_create_photo_layer()
        if layer is not None:
            feat = QgsFeature(layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(shot.x_3301, shot.y_3301)))
            feat.setAttributes([
                shot.shot_id,
                shot.filename,
                shot.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                round(shot.z_eh2000, 1),
                round(shot.agl_m, 1),
                round(shot.yaw_deg, 1),
                round(shot.pitch_deg, 1),
            ])
            layer.dataProvider().addFeature(feat)
            layer.updateExtents()
            if getattr(self, "canvas", None) is not None:
                self.canvas.refresh()
            if self.viewer.show_canvas_layers and str(layer.id()) in self.enabled_canvas_layer_ids:
                self.refresh_canvas_layers_in_3d(force=True)

        if hasattr(self, "act_photo_batch"):
            cnt = len(self.viewer.session_photos)
            self.act_photo_batch.setText(f"💾 {tr('v3d_photo_export_batch', count=cnt)}")

    def _get_or_create_photo_layer(self) -> Optional[QgsVectorLayer]:
        """Retrieves or creates the temporary memory layer for photoshoot waypoints on the QGIS canvas."""
        layer_name = "MaRu ALS Droonifotod"
        proj = QgsProject.instance()
        for lyr in proj.mapLayers().values():
            if lyr.name() == layer_name and isinstance(lyr, QgsVectorLayer):
                self._photo_layer = lyr
                return lyr

        vl = QgsVectorLayer("Point?crs=EPSG:3301", layer_name, "memory")
        if not vl.isValid():
            return None

        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("ID", QVariant.Int),
            QgsField("Failinimi", QVariant.String),
            QgsField("Aeg", QVariant.String),
            QgsField("Korgus_EH2000", QVariant.Double),
            QgsField("Korgus_AGL", QVariant.Double),
            QgsField("Suund_Yaw", QVariant.Double),
            QgsField("Kalle_Pitch", QVariant.Double),
        ])
        vl.updateFields()
        self._style_photo_layer(vl)
        proj.addMapLayer(vl, True)
        self._photo_layer = vl
        return vl

    def _style_photo_layer(self, vl: QgsVectorLayer):
        """Styles the photoshoot waypoint layer with directional triangle arrows and label badges."""
        try:
            from qgis.core import (
                QgsMarkerSymbol,
                QgsProperty,
                QgsPalLayerSettings,
                QgsVectorLayerSimpleLabeling,
                QgsTextFormat,
                QgsTextBufferSettings,
            )
            sym = QgsMarkerSymbol.createSimple({
                "name": "triangle",
                "color": "#f59e0b",
                "color_border": "#0f172a",
                "size": "5.0",
                "angle": "0",
            })
            sym.setDataDefinedAngle(QgsProperty.fromField("Suund_Yaw"))
            vl.setRenderer(QgsSingleSymbolRenderer(sym))

            pal = QgsPalLayerSettings()
            pal.fieldName = "concat('#', ID)"
            pal.enabled = True

            tf = QgsTextFormat()
            tf.setSize(9)
            tf.setColor(QColor(254, 243, 199))

            tb = QgsTextBufferSettings()
            tb.setEnabled(True)
            tb.setSize(1.5)
            tb.setColor(QColor(15, 23, 42))
            tf.setBuffer(tb)

            pal.setFormat(tf)
            vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            vl.setLabelsEnabled(True)
        except Exception as e:
            QgsMessageLog.logMessage(f"Viga fotokihi stiilimisel: {e}", "MaRu ALS", Qgis.Warning)

    def clear_photos_session(self, remove_layer: bool = False):
        """Clears all session photos from viewer, minimap, and 2D canvas."""
        self.viewer.clear_session_photos()
        if self._photo_layer is not None:
            if remove_layer:
                try:
                    QgsProject.instance().removeMapLayer(self._photo_layer.id())
                except Exception:
                    pass
                self._photo_layer = None
            elif self._photo_layer.isValid():
                fids = [f.id() for f in self._photo_layer.getFeatures()]
                if fids:
                    self._photo_layer.dataProvider().deleteFeatures(fids)
                    self._photo_layer.updateExtents()
        if hasattr(self, "act_photo_batch"):
            self.act_photo_batch.setText(f"💾 {tr('v3d_photo_export_batch', count=0)}")
        if getattr(self, "canvas", None) is not None:
            self.canvas.refresh()

    def export_session_photos_batch(self):
        """Exports all photoshoot photos from current session + photogrammetry CSV metadata + GPKG."""
        photos = self.viewer.session_photos
        if not photos:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.information(
                self,
                tr("v3d_photo_btn"),
                "Sessioonis pole ühtegi fotot.\n\nLülita sisse fotorežiim (vajuta 'P') ja tee hiireklõpsuga fotosid enne eksportimist.",
            )
            return

        pics_dir = os.path.join(os.path.expanduser("~"), "Pictures", "MaRu_ALS_Photos")
        os.makedirs(pics_dir, exist_ok=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        default_dir = os.path.join(pics_dir, f"Sessioon_{ts}")

        target_dir = QFileDialog.getExistingDirectory(
            self,
            tr("v3d_photo_export_batch", count=len(photos)),
            pics_dir,
            QFileDialog.Option.ShowDirsOnly,
        )
        if not target_dir:
            return

        # If user selected root pictures dir, create a dedicated session folder
        if target_dir == pics_dir:
            target_dir = default_dir
        os.makedirs(target_dir, exist_ok=True)

        # 1. Save all captured images
        csv_rows = []
        for shot in photos:
            fname = shot.filename
            out_img_path = os.path.join(target_dir, fname)
            shot.image.save(out_img_path, "PNG")
            csv_rows.append([
                shot.shot_id,
                fname,
                shot.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                f"{shot.x_3301:.3f}",
                f"{shot.y_3301:.3f}",
                f"{shot.z_eh2000:.2f}",
                f"{shot.agl_m:.2f}",
                f"{shot.yaw_deg:.1f}",
                f"{shot.pitch_deg:.1f}",
            ])

        # 2. Save photogrammetry CSV metadata (Drone2Map, Pix4D, Metashape compatible)
        csv_path = os.path.join(target_dir, "photos_metadata.csv")
        try:
            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "PhotoID",
                    "Filename",
                    "Timestamp",
                    "Easting_X_EPSG3301",
                    "Northing_Y_EPSG3301",
                    "Altitude_EH2000_m",
                    "Height_AGL_m",
                    "Yaw_deg",
                    "Pitch_deg",
                ])
                writer.writerows(csv_rows)
        except Exception as e:
            QgsMessageLog.logMessage(f"Viga CSV salvestamisel: {e}", "MaRu ALS", Qgis.Warning)

        # 3. Save GeoPackage waypoints layer for GIS archiving
        try:
            from qgis.core import QgsVectorFileWriter
            if self._photo_layer is not None and self._photo_layer.isValid():
                gpkg_path = os.path.join(target_dir, "photos_waypoints.gpkg")
                options = QgsVectorFileWriter.SaveVectorOptions()
                options.driverName = "GPKG"
                options.layerName = "Droonifotod"
                QgsVectorFileWriter.writeAsVectorFormatV3(
                    self._photo_layer,
                    gpkg_path,
                    QgsProject.instance().transformContext(),
                    options,
                )
        except Exception as e:
            QgsMessageLog.logMessage(f"GPKG eksport ebaõnnestus (mittekriitiline): {e}", "MaRu ALS", Qgis.Info)

        msg = tr("v3d_photo_export_done", count=len(photos), folder=os.path.basename(target_dir))
        self.set_progress(100, msg, visible=False)
        QgsMessageLog.logMessage(f"Fotod eksporditud: {target_dir}", "MaRu ALS", Qgis.Info)

        # Open target folder in file manager
        from qgis.PyQt.QtGui import QDesktopServices
        from qgis.PyQt.QtCore import QUrl
        QDesktopServices.openUrl(QUrl.fromLocalFile(target_dir))

    # ------------------------------------------------------------------ #
    # Point cloud & 3D Raster decoding & streaming
    # ------------------------------------------------------------------ #
    def enqueue_laz_for_3d(self, file_info: AlsFileInfo):
        """Queues a downloaded/cached LAZ file for decoding into the 3D OpenGL viewer."""
        if not file_info or not file_info.local_path or not os.path.exists(file_info.local_path):
            return
        self.viewer.set_tile_state(file_info.tile_id, STATE_LOADING)
        self.set_progress(5, f"Dekodeerin LAZ: {file_info.filename}...", visible=True)
        self.loader.enqueue(file_info.tile_id, file_info.local_path, file_info)

    def enqueue_raster_for_3d(self, file_info: AlsFileInfo):
        """
        Queues a downloaded/cached Extra MaRu Raster (DSM 1m, DTM 1m, Orthophoto, Basic Map)
        for 3D decoding so it opens directly inside the 3D OpenGL viewer.
        """
        if not file_info or not file_info.local_path or not os.path.exists(file_info.local_path):
            return
        ref_ground = None
        vt = self.viewer.tiles.get(file_info.tile_id)
        if vt is not None and vt.ground is not None:
            ref_ground = vt.ground
        self.set_progress(6, f"Avan 3D vaates: {file_info.filename}...", visible=True)
        self.loader.enqueue(
            file_info.tile_id,
            file_info.local_path,
            file_info,
            ref_ground=ref_ground,
        )

    def mark_tile_queued(self, tile_id: str):
        if tile_id not in self.viewer.tiles:
            self.viewer.set_tile_state(tile_id, STATE_QUEUED)

    def _on_tile_decoded(self, tile_id: str, file_info: AlsFileInfo, data: dict):
        self.viewer.add_tile(tile_id, file_info, data)
        self.set_progress(100, f"Valmis: {file_info.filename}", visible=False)
        self.refresh_tree_statuses()
        self.refresh_scene_3d_tree()
        self.refresh_canvas_layers_in_3d()

        # If importing a custom drone survey, center the 3D camera over the survey
        if file_info and str(file_info.flight_type).startswith("droon_"):
            try:
                orig = data.get("origin")
                pos = data.get("pos")
                if orig is not None and pos is not None and len(pos) > 0:
                    c_lx = float(np.mean(pos[:min(len(pos), 2500), 0])) + float(orig[0]) - float(self.viewer.scene_origin[0])
                    c_ly = float(np.mean(pos[:min(len(pos), 2500), 1])) + float(orig[1]) - float(self.viewer.scene_origin[1])
                    c_lz = float(np.median(pos[:min(len(pos), 2500), 2]))
                    self.viewer.cam[0] = c_lx
                    self.viewer.cam[1] = c_ly
                    self.viewer.cam[2] = c_lz + 75.0
                    self.viewer.pitch = -30.0
                    self.viewer._emit_camera_moved()
                    self.viewer.update()
            except Exception as e:
                QgsMessageLog.logMessage(f"Drooni andmete fookustamise viga: {e}", "MaRu ALS", Qgis.Warning)

    def _on_tile_decode_failed(self, tile_id: str, err: str):
        self.viewer.set_tile_state(tile_id, STATE_FAILED)
        self.set_progress(100, "", visible=False)
        self.refresh_tree_statuses()

    # ------------------------------------------------------------------ #
    # Tab 1: Session Flight Years & LAZ Layers Tree
    # ------------------------------------------------------------------ #
    def add_tile_files(self, tile_id: str, files: List[AlsFileInfo]):
        """Adds or updates the list of available multi-year LAZ flights for a 1:2000 tile."""
        self.session_data[tile_id] = files

        root_item = None
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            if top.data(0, UserRole) == tile_id or top.text(0).startswith(f"{tr('dock_col_tile')}: {tile_id}"):
                root_item = top
                break

        if not root_item:
            root_item = QTreeWidgetItem(self.tree)
            root_item.setData(0, UserRole, tile_id)
            self.tree.addTopLevelItem(root_item)

        root_item.setText(0, f"{tr('dock_col_tile')}: {tile_id} ({len(files)})")
        root_item.setForeground(0, QColor(56, 189, 248))
        root_item.setExpanded(True)
        rf = root_item.font(0)
        rf.setBold(True)
        root_item.setFont(0, rf)

        root_item.takeChildren()
        for f_info in files:
            child = QTreeWidgetItem(root_item)
            child.setText(0, f"{f_info.year} · {f_info.filename}")
            child.setToolTip(0, f_info.filename)
            type_text = (
                tr("type_tava")
                if f_info.flight_type == "tava"
                else (tr("type_mets") if f_info.flight_type == "mets" else tr("type_madal") if f_info.flight_type == "madal" else f_info.flight_type)
            )
            child.setText(1, type_text)
            child.setText(2, f_info.size_str)
            child.setData(0, UserRole, f_info)
            self._update_item_status(child, f_info)

    # ------------------------------------------------------------------ #
    # Tab 2: Additional MaRu Datasets (DSM, DTM, Orthophoto, Basic Map)
    # ------------------------------------------------------------------ #
    def selected_extra_categories(self) -> List[str]:
        return [k for k, chk in self._extra_cat_checks.items() if chk.isChecked()]

    def emit_fetch_extra_layers(self):
        cats = self.selected_extra_categories()
        if cats:
            self.fetch_extra_requested.emit(cats)

    def add_extra_tile_files(self, tile_id: str, files: List[AlsFileInfo]):
        """Adds or updates additional MaRu open data layers (DSM, DTM, Ortho) for a tile."""
        self.extra_session_data[tile_id] = files

        root_item = None
        for i in range(self.tree_extra.topLevelItemCount()):
            top = self.tree_extra.topLevelItem(i)
            if top.data(0, UserRole) == tile_id:
                root_item = top
                break

        if not root_item:
            root_item = QTreeWidgetItem(self.tree_extra)
            root_item.setData(0, UserRole, tile_id)
            self.tree_extra.addTopLevelItem(root_item)

        t10k = GridEngine.tile_2000_to_10000(tile_id) or ""
        hdr_txt = f"1:2000 {tile_id}" + (f" / 1:10 000 {t10k}" if t10k else "") + f" ({len(files)})"
        root_item.setText(0, hdr_txt)
        root_item.setForeground(0, QColor(56, 189, 248))
        root_item.setExpanded(True)
        rf = root_item.font(0)
        rf.setBold(True)
        root_item.setFont(0, rf)

        cat_short_map = {
            "dsm_1m": "DSM 1m",
            "dtm_1m": "DTM 1m",
            "orto_rgb": "Orto RGB",
            "orto_madal": "Orto madal",
            "orto_cir": "Orto CIR",
            "orto_ngr": "Orto NGR",
            "pk_varj": "Põhikaart",
        }
        cat_tr_map = {
            "dsm_1m": tr("cat_dsm_1m"),
            "dtm_1m": tr("cat_dtm_1m"),
            "orto_rgb": tr("cat_orto_rgb"),
            "orto_madal": tr("cat_orto_madal"),
            "orto_cir": tr("cat_orto_cir"),
            "orto_ngr": tr("cat_orto_ngr"),
            "pk_varj": tr("cat_pk_varj"),
        }

        root_item.takeChildren()
        for f_info in files:
            child = QTreeWidgetItem(root_item)
            yr_prefix = f"{f_info.year} · " if f_info.year else ""
            child.setText(0, f"{yr_prefix}{f_info.filename}")
            child.setToolTip(0, f"{f_info.filename} — {cat_tr_map.get(f_info.flight_type, '')}")
            child.setText(1, cat_short_map.get(f_info.flight_type, f_info.flight_type))
            child.setToolTip(1, cat_tr_map.get(f_info.flight_type, f_info.flight_type))
            child.setText(2, f_info.size_str)
            child.setData(0, UserRole, f_info)
            self._update_item_status(child, f_info)

    def _update_item_status(self, item: QTreeWidgetItem, f_info: AlsFileInfo):
        in_3d = self.viewer.is_layer_loaded_in_3d(f_info.filename)
        is_loaded_2d = False
        stem = os.path.splitext(f_info.filename)[0]
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, (QgsPointCloudLayer, QgsRasterLayer)):
                if f_info.filename in lyr.source() or stem in lyr.source() or lyr.name().endswith(stem):
                    is_loaded_2d = True
                    break

        if in_3d or is_loaded_2d:
            if in_3d and is_loaded_2d:
                label = "3D + " + tr("dock_status_loaded")
            elif in_3d:
                label = "3D vaates"
            else:
                label = tr("dock_status_loaded")
            item.setText(3, label)
            item.setForeground(3, QColor(16, 185, 129))
            font = item.font(3)
            font.setBold(True)
            item.setFont(3, font)
        elif CacheManager.is_cached(f_info.filename):
            item.setText(3, tr("dock_status_cached"))
            item.setForeground(3, QColor(56, 189, 248))
        else:
            item.setText(3, tr("dock_status_available"))
            item.setForeground(3, QColor(148, 163, 184))

    def refresh_tree_statuses(self):
        for tree_w in (self.tree, self.tree_extra):
            for i in range(tree_w.topLevelItemCount()):
                top = tree_w.topLevelItem(i)
                for j in range(top.childCount()):
                    child = top.child(j)
                    f_info = child.data(0, UserRole)
                    if isinstance(f_info, AlsFileInfo):
                        self._update_item_status(child, f_info)
        self.refresh_scene_3d_tree()

    def _on_load_selected_clicked(self):
        item = self.tree.currentItem()
        if not item:
            return
        f_info = item.data(0, UserRole)
        if isinstance(f_info, AlsFileInfo):
            self.load_file_requested.emit(f_info)

    def _on_tree_double_clicked(self, item: QTreeWidgetItem, column: int):
        f_info = item.data(0, UserRole)
        if isinstance(f_info, AlsFileInfo):
            self.load_file_requested.emit(f_info)

    def _on_load_extra_selected_clicked(self):
        item = self.tree_extra.currentItem()
        if not item:
            return
        f_info = item.data(0, UserRole)
        if isinstance(f_info, AlsFileInfo):
            self.load_file_requested.emit(f_info)

    def _on_extra_tree_double_clicked(self, item: QTreeWidgetItem, column: int):
        f_info = item.data(0, UserRole)
        if isinstance(f_info, AlsFileInfo):
            self.load_file_requested.emit(f_info)

    def clear_all(self):
        self.clear_session()

    # ------------------------------------------------------------------ #
    # Lifecycle & i18n
    # ------------------------------------------------------------------ #
    def apply_settings(self):
        """Reads persistent settings (skybox, horizon fog) and applies to 3D OpenGL viewer."""
        settings = QgsSettings()
        sky_mode = settings.value("maru_als/sky_mode", None)
        if sky_mode is not None:
            proc = sky_mode in ("procedural", "procedural_fog")
            pano = sky_mode in ("panorama", "panorama_fog")
            fog = sky_mode in ("fog", "procedural_fog", "panorama_fog")
        else:
            proc = settings.value("maru_als/sky_procedural", False, type=bool)
            pano = settings.value("maru_als/sky_panorama", False, type=bool)
            fog = settings.value("maru_als/sky_fog", False, type=bool)

        if hasattr(self, "viewer") and self.viewer:
            self.viewer.set_skybox_options(proc, pano, fog)
            eng = str(settings.value("maru_als/render_engine", "auto") or "auto")
            if hasattr(self.viewer, "set_render_engine_preference"):
                self.viewer.set_render_engine_preference(eng)

    def retranslate_ui(self):
        self.setWindowTitle(tr("v3d_panel_title"))
        if getattr(self, "aoi_mode", "arrow") == "rectangle":
            self.btn_arrow.setText(tr("v3d_tb_rect"))
            self.btn_arrow.setToolTip(tr("v3d_tb_rect_tip"))
        else:
            self.btn_arrow.setText(tr("v3d_tb_arrow"))
            self.btn_arrow.setToolTip(tr("v3d_tb_arrow_tip"))
        if hasattr(self, "act_aoi_arrow"):
            self.act_aoi_arrow.setText(tr("v3d_aoi_mode_arrow"))
        if hasattr(self, "act_aoi_rect"):
            self.act_aoi_rect.setText(tr("v3d_aoi_mode_rect"))
        self.btn_drone_2d.setText(tr("v3d_tb_drone_2d"))
        self.btn_drone_2d.setToolTip(tr("v3d_tb_drone_2d_tip"))
        self.act_drone_cone.setText(tr("v3d_drone_2d_show_cone"))
        self.act_drone_path.setText(tr("v3d_drone_2d_show_path"))
        self.act_drone_follow.setText(tr("v3d_drone_2d_follow"))
        self.act_drone_center.setText(tr("v3d_drone_2d_center"))
        self.lbl_color.setText(tr("v3d_tb_color"))
        self.cmb_color.setItemText(0, tr("v3d_col_rgb"))
        self.cmb_color.setItemText(1, tr("v3d_col_elev"))
        self.cmb_color.setItemText(2, tr("v3d_col_class"))
        self.cmb_color.setItemText(3, tr("v3d_col_inten"))
        self.btn_style.setText(tr("v3d_style_btn"))
        self.btn_style.setToolTip(tr("v3d_style_tip"))
        self.lbl_psize.setText(tr("v3d_tb_psize"))
        self.btn_classes.setText(tr("v3d_tb_classes"))
        for key, (act, _) in self._class_actions.items():
            act.setText(tr(key))
        self.btn_infill.setText(tr("v3d_tb_infill"))
        self.btn_infill.setToolTip(tr("v3d_tb_infill_tip"))
        if hasattr(self, "btn_drone_data"):
            self.btn_drone_data.setText(tr("v3d_tb_drone_data"))
            self.btn_drone_data.setToolTip(tr("v3d_tb_drone_data_tip"))
        if hasattr(self, "btn_signal"):
            self.btn_signal.setText("📡 " + tr("v3d_tb_signal", fallback="Signaal"))
            self.btn_signal.setToolTip(tr("v3d_tb_signal_tip", fallback="Drooni juhtsignaali analüüs ja levi simulatsioon (Mavic 3E / Matrice 4T / jne)"))
        self.btn_canvas_3d.setText(tr("v3d_tb_canvas_lyrs"))
        self.btn_canvas_3d.setToolTip(tr("v3d_tb_canvas_lyrs_tip"))
        self.btn_los.setText(tr("v3d_tb_los"))
        self.btn_los.setToolTip(tr("v3d_tb_los_tip"))
        self.btn_m_off.setText(tr("v3d_tb_measure_off"))
        self.btn_m_dist.setText(tr("v3d_tb_measure_dist"))
        self.btn_m_area.setText(tr("v3d_tb_measure_area"))
        self.btn_m_vol.setText(tr("v3d_tb_measure_vol"))
        self.btn_m_clear.setToolTip(tr("drone_measure_clear"))
        self.chk_autostream.setText(tr("v3d_tb_autostream"))
        self.chk_autostream.setToolTip(tr("v3d_tb_autostream_tip"))
        self.btn_reset.setText(tr("v3d_tb_reset"))
        self.btn_reset.setToolTip(tr("v3d_tb_reset_tip"))
        self.btn_export.setText(tr("v3d_tb_export_log"))
        self.btn_export.setToolTip(tr("v3d_tb_export_tip"))
        self.btn_grid.setToolTip(tr("btn_grid_tooltip"))
        self.btn_layers.setText(tr("v3d_tb_layers"))
        self.btn_layers.setToolTip(tr("v3d_tb_layers_tip"))
        self.btn_settings.setToolTip(tr("btn_settings_tooltip"))

        self.drawer_tabs.setTabText(0, tr("v3d_tab_als"))
        self.drawer_tabs.setTabText(1, tr("v3d_tab_extra"))
        self.drawer_tabs.setTabText(2, tr("v3d_tab_scene"))
        self.lbl_drawer_title.setText(tr("dock_section_session_tiles"))
        self.chk_merge_flights.setText(tr("v3d_chk_merge_flights"))
        self.tree.setHeaderLabels([
            tr("dock_col_year"),
            tr("dock_col_type"),
            tr("dock_col_size"),
            tr("dock_col_status"),
        ])
        self.btn_load_sel.setText(tr("dock_btn_load_selected"))
        self.btn_merge_tile.setText(tr("v3d_btn_merge_tile"))
        self.btn_merge_tile.setToolTip(tr("v3d_btn_merge_tile_tip"))
        self.btn_load_all.setText(tr("dock_btn_load_all"))
        self.btn_load_all.setToolTip(tr("dock_btn_load_all_tip"))
        self.btn_clear_list.setText(tr("dock_btn_clear_all"))

        self.lbl_extra_title.setText(tr("v3d_extra_title"))
        self.btn_fetch_extra.setText(tr("v3d_extra_fetch"))
        self.btn_fetch_extra.setToolTip(tr("v3d_extra_fetch_tip"))
        self.tree_extra.setHeaderLabels([
            tr("v3d_extra_col_layer"),
            tr("v3d_extra_col_scale"),
            tr("dock_col_size"),
            tr("dock_col_status"),
        ])
        self.btn_load_extra.setText(tr("v3d_extra_load"))

        self.lbl_scene_3d_title.setText(tr("v3d_scene_3d_title"))
        self.chk_scene_infill.setText(tr("v3d_chk_infill"))
        self.chk_scene_merge.setText(tr("v3d_chk_merge_flights"))
        self.tree_scene_3d.setHeaderLabels([
            tr("v3d_scene_col_name"),
            tr("v3d_scene_col_type"),
            tr("v3d_scene_col_pts"),
        ])
        self.btn_remove_3d_layer.setText(tr("v3d_scene_remove"))
        self.lbl_scene_2d_title.setText(tr("v3d_scene_2d_title"))
        self.tree_canvas_2d.setHeaderLabels([
            tr("v3d_scene_col_2d_name"),
            tr("v3d_scene_col_2d_geom"),
        ])

        self.refresh_tree_statuses()
        self.refresh_canvas_2d_tree()
        self.viewer.update()

    def clear_session(self):
        """Completely clears active session data from memory, 3D viewer, and 2D canvas."""
        self.session_data.clear()
        self.extra_session_data.clear()
        self.tree.clear()
        self.tree_extra.clear()
        self.clear_photos_session(remove_layer=True)
        self.viewer.clear_tiles()
        self.viewer.clear_session_photos()
        if hasattr(self, "signal_dialog") and self.signal_dialog:
            self.signal_dialog.clear_session()
        self.refresh_tree_statuses()
        self.refresh_scene_3d_tree()
        self.clear_session_requested.emit()

    def hide_photo_layer_2d(self):
        if self._photo_layer is not None and self._photo_layer.isValid():
            try:
                node = QgsProject.instance().layerTreeRoot().findLayer(self._photo_layer.id())
                if node:
                    node.setItemVisibilityChecked(False)
            except Exception:
                pass

    def show_photo_layer_2d(self):
        if self._photo_layer is not None and self._photo_layer.isValid():
            try:
                node = QgsProject.instance().layerTreeRoot().findLayer(self._photo_layer.id())
                if node:
                    node.setItemVisibilityChecked(True)
            except Exception:
                pass

    def shutdown(self):
        """Cleanly stops background decoder thread, minimap fetcher, layer listeners, and releases GL resources."""
        for lid in list(self._connected_vec_lids):
            lyr = QgsProject.instance().mapLayer(lid)
            if lyr is not None:
                try:
                    lyr.layerModified.disconnect(self._on_watched_vector_layer_modified)
                    lyr.featureAdded.disconnect(self._on_watched_vector_layer_modified)
                    lyr.geometryChanged.disconnect(self._on_watched_vector_layer_modified)
                    lyr.styleChanged.disconnect(self._on_watched_vector_layer_modified)
                except Exception:
                    pass
        self._connected_vec_lids.clear()

        try:
            if hasattr(self, "loader") and self.loader:
                self.loader.stop()
        except Exception:
            pass

        try:
            if hasattr(self, "viewer") and self.viewer:
                self.viewer.shutdown()
        except Exception:
            pass

        try:
            if hasattr(self, "signal_dialog") and self.signal_dialog:
                if self.signal_dialog.overlay_2d:
                    self.signal_dialog.overlay_2d.hide()
                    from qgis.PyQt import sip
                    sip.delete(self.signal_dialog.overlay_2d)
                    self.signal_dialog.overlay_2d = None
                self.signal_dialog.close()
                self.signal_dialog = None
        except Exception:
            pass
