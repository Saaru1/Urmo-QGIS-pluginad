# -*- coding: utf-8 -*-
"""
MaRu ALS custom OpenGL 3D viewer with drone-style flight.

* Point clouds rendered with PyOpenGL (GLSL 1.20, compatibility profile) inside a
  QOpenGLWidget — independent of the QGIS native 3D canvas.
* Drone controls: W/A/S/D horizontal flight, Space climb, Ctrl descend, mouse drag
  gimbal (yaw/pitch), Shift turbo, mouse wheel sets cruise speed.
* HUD: data / flight date (upper-left), controls help, telemetry, mini-map with
  flight trail, measurement read-out.
* Measurement: polyline distance & slope, polygon area, cut/fill volume.
* Auto-streaming: requests adjacent 1:2000 tiles when flying towards them.
"""

import ctypes
from dataclasses import dataclass
import datetime
import math
import time
from typing import Dict, List, Optional, Tuple

import numpy as np

from qgis.PyQt.QtCore import Qt, QTimer, QPointF, QRectF, pyqtSignal, QEvent
from qgis.PyQt.QtGui import (
    QPainter, QColor, QFont, QFontMetrics, QImage, QPen, QBrush, QLinearGradient, QPolygonF, QSurfaceFormat
)
from qgis.PyQt.QtWidgets import QWidget
from qgis.core import QgsMessageLog, Qgis, QgsSettings

from ...core.grid_engine import GridEngine
from ...i18n import tr
from . import measure as M
from .drone_canvas_item import MINIMAP_BASE_MODES, MinimapTileFetcher
from ...core.signal_engine import (
    DRONE_PROFILES,
    ZONE_STRONG,
    ZONE_FAIR,
    ZONE_MARGINAL,
    ZONE_SHADOW,
    VLOS_CLEAR,
    VLOS_MARGINAL,
    VLOS_BVLOS,
    VLOS_BLOCKED,
    evaluate_live_drone_signal,
    evaluate_live_vlos,
)

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
COLOR_ELEVATION = 0
COLOR_CLASS = 1
COLOR_INTENSITY = 2
COLOR_RGB = 3

STATE_QUEUED = "queued"
STATE_LOADING = "loading"
STATE_LOADED = "loaded"
STATE_NODATA = "nodata"
STATE_FAILED = "failed"

CLASS_COLORS = {
    0: (170, 170, 170), 1: (175, 175, 175), 2: (166, 116, 72), 3: (180, 220, 120),
    4: (90, 180, 70), 5: (34, 125, 45), 6: (225, 90, 70), 7: (255, 0, 255),
    8: (200, 200, 0), 9: (60, 130, 230), 10: (120, 120, 120), 11: (90, 90, 90),
    17: (240, 200, 80), 18: (255, 0, 255),
}
DEFAULT_HIDDEN_CLASSES = (7, 18)

K = Qt.Key
FLIGHT_KEYS = {
    K.Key_W, K.Key_A, K.Key_S, K.Key_D, K.Key_Q, K.Key_E, K.Key_Space, K.Key_Control,
    K.Key_Shift, K.Key_Left, K.Key_Right, K.Key_Up, K.Key_Down,
}
COMMAND_KEYS = {
    K.Key_M, K.Key_C, K.Key_H, K.Key_R, K.Key_G, K.Key_Escape, K.Key_Backspace,
    K.Key_Return, K.Key_Enter, K.Key_Plus, K.Key_Minus,
}

VERT_SRC = """
#version 120
attribute vec3 a_pos;
attribute vec2 a_attr;
attribute vec4 a_rgb;
uniform mat4 u_mvp;
uniform vec3 u_offset;
uniform vec3 u_cam;
uniform int u_mode;
uniform int u_has_rgb;
uniform float u_rgb_bright;
uniform float u_inten_gamma;
uniform vec2 u_zrange;
uniform float u_psize;
uniform float u_pscale;
uniform float u_spacing;
uniform float u_classvis[32];
uniform vec3 u_classcol[32];
uniform vec3 u_ramp[5];
uniform vec2 u_fog;
varying vec3 v_col;
varying float v_fog;

vec3 ramp(float t) {
    t = clamp(t, 0.0, 1.0);
    if (t < 0.25) return mix(u_ramp[0], u_ramp[1], t / 0.25);
    if (t < 0.50) return mix(u_ramp[1], u_ramp[2], (t - 0.25) / 0.25);
    if (t < 0.75) return mix(u_ramp[2], u_ramp[3], (t - 0.50) / 0.25);
    return mix(u_ramp[3], u_ramp[4], (t - 0.75) / 0.25);
}

void main() {
    vec3 wp = a_pos + u_offset;
    int c = int(clamp(a_attr.x + 0.5, 0.0, 31.0));
    gl_Position = u_mvp * vec4(wp, 1.0);
    if (u_classvis[c] < 0.5) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }
    float d = max(distance(wp, u_cam), 0.5);
    gl_PointSize = clamp(u_psize * u_spacing * u_pscale / d, 1.0, 18.0);

    if (u_mode == 1) {
        v_col = u_classcol[c];
    } else if (u_mode == 2) {
        float i = pow(max(a_attr.y, 0.0), u_inten_gamma);
        v_col = vec3(i, i, i);
    } else if (u_mode == 3) {
        if (u_has_rgb == 1) {
            v_col = clamp(a_rgb.rgb * u_rgb_bright, 0.0, 1.0);
        } else {
            float shade_i = 0.68 + 0.48 * a_attr.y;
            v_col = clamp(u_classcol[c] * shade_i, 0.0, 1.0);
        }
    } else if (u_mode == 4) {
        float shade_i = 0.70 + 0.35 * a_attr.y;
        v_col = vec3(0.96, 0.62, 0.04) * shade_i;
    } else if (u_mode == 5) {
        float shade_i = 0.70 + 0.35 * a_attr.y;
        v_col = vec3(0.14, 0.82, 0.94) * shade_i;
    } else {
        v_col = ramp((wp.z - u_zrange.x) / max(u_zrange.y - u_zrange.x, 0.01));
    }
    v_fog = clamp((d - u_fog.x) / max(u_fog.y - u_fog.x, 1.0), 0.0, 0.85);
}
"""

FRAG_SRC = """
#version 120
varying vec3 v_col;
varying float v_fog;
uniform vec3 u_fogcol;
uniform int u_round;
void main() {
    float shade = 1.0;
    if (u_round == 1) {
        vec2 p = gl_PointCoord * 2.0 - 1.0;
        float r2 = dot(p, p);
        if (r2 > 1.0) discard;
        shade = 1.0 - 0.22 * r2;
    }
    gl_FragColor = vec4(mix(v_col * shade, u_fogcol, v_fog), 1.0);
}
"""


# --------------------------------------------------------------------------- #
# Math helpers
# --------------------------------------------------------------------------- #
def perspective(fovy_deg: float, aspect: float, near: float, far: float) -> np.ndarray:
    f = 1.0 / math.tan(math.radians(fovy_deg) / 2.0)
    m = np.zeros((4, 4), dtype=np.float64)
    m[0, 0] = f / aspect
    m[1, 1] = f
    m[2, 2] = (far + near) / (near - far)
    m[2, 3] = 2.0 * far * near / (near - far)
    m[3, 2] = -1.0
    return m


def look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
    f = target - eye
    f = f / np.linalg.norm(f)
    s = np.cross(f, up)
    sn = np.linalg.norm(s)
    s = s / sn if sn > 1e-9 else np.array([1.0, 0.0, 0.0])
    u = np.cross(s, f)
    m = np.eye(4, dtype=np.float64)
    m[0, :3] = s
    m[1, :3] = u
    m[2, :3] = -f
    m[0, 3] = -np.dot(s, eye)
    m[1, 3] = -np.dot(u, eye)
    m[2, 3] = np.dot(f, eye)
    return m


def fmt_len(m: float) -> str:
    return f"{m / 1000.0:.2f} km" if abs(m) >= 1000 else f"{m:.1f} m"


def fmt_area(a: float) -> str:
    return f"{a / 10000.0:.3f} ha" if a >= 10000 else f"{a:.1f} m²"


def flight_type_label(ft: str) -> str:
    key = {"tava": "type_tava", "mets": "type_mets", "madal": "type_madal"}.get((ft or "").lower())
    return tr(key) if key else (ft or "")


# --------------------------------------------------------------------------- #
# Drone Photoshoot Shot Container
# --------------------------------------------------------------------------- #
@dataclass
class DronePhotoShot:
    shot_id: int
    image: QImage
    timestamp: datetime.datetime
    x_3301: float
    y_3301: float
    z_eh2000: float
    agl_m: float
    yaw_deg: float
    pitch_deg: float
    gimbal_pitch: float
    filename: str


# --------------------------------------------------------------------------- #
# Tile container
# --------------------------------------------------------------------------- #
class ViewerTile:
    def __init__(self, tile_id: str, file_info, data: dict, scene_origin: np.ndarray):
        self.tile_id = tile_id
        self.file_info = file_info
        fname = getattr(file_info, "filename", "") or tile_id
        self.layer_key = f"{tile_id}::{fname}"
        self.visible = True
        self.is_raster_3d = bool(data.get("is_raster_3d", False))
        self.raster_cat = str(data.get("raster_cat", ""))
        ftype = str(getattr(file_info, "flight_type", "") or "")
        self.is_drone: bool = tile_id.startswith("droon_") or (ftype in ("droon_laz", "droon_dsm", "droon_orto"))

        self.pos: np.ndarray = np.ascontiguousarray(data["pos"], dtype=np.float32)
        self.cls: np.ndarray = data["cls"].astype(np.uint8)
        self.n = int(self.pos.shape[0])
        self.n_points = self.n
        self.attr = np.empty((self.n, 2), dtype=np.float32)
        self.attr[:, 0] = self.cls
        self.attr[:, 1] = data["inten"]
        self.has_rgb = bool(data.get("has_rgb", False)) and len(data.get("rgb", [])) == self.n
        self.rgb = np.ascontiguousarray(data["rgb"], dtype=np.uint8) if self.has_rgb else None
        self.origin = np.asarray(data["origin"], dtype=np.float64)
        self.ground = data["ground"]
        self.z_range = tuple(float(v) for v in data["z_range"])
        self.date_from = str(data.get("date_from", ""))
        self.date_to = str(data.get("date_to", ""))
        self.zmin = float(self.pos[:, 2].min()) if self.n else 0.0
        self.zmax = float(self.pos[:, 2].max()) if self.n else 50.0
        self.offset = np.array([self.origin[0] - scene_origin[0], self.origin[1] - scene_origin[1], 0.0])

        # Vertical wall & void infill arrays (for steep castle walls, bastions, facades, moats)
        infill_p = data.get("infill_pos")
        if infill_p is not None and len(infill_p) > 0:
            self.infill_pos = np.ascontiguousarray(infill_p, dtype=np.float32)
            self.infill_n = int(self.infill_pos.shape[0])
            self.n_infill = self.infill_n
            self.infill_attr = np.empty((self.infill_n, 2), dtype=np.float32)
            self.infill_attr[:, 0] = data["infill_cls"].astype(np.uint8)
            self.infill_attr[:, 1] = data["infill_inten"]
            infill_r = data.get("infill_rgb")
            self.infill_has_rgb = infill_r is not None and len(infill_r) == self.infill_n
            self.infill_rgb = np.ascontiguousarray(infill_r, dtype=np.uint8) if self.infill_has_rgb else None
        else:
            self.infill_pos = np.zeros((0, 3), dtype=np.float32)
            self.infill_n = 0
            self.n_infill = 0
            self.infill_attr = np.zeros((0, 2), dtype=np.float32)
            self.infill_has_rgb = False
            self.infill_rgb = None

        # Build 1.0m obstacle DSM surface grid (buildings/trees/bridges) for crisp 3D Line-of-Sight occlusion
        s_n = 1000
        s_cell = 1000.0 / s_n  # 1.0 m
        sflat = np.full(s_n * s_n, -np.inf, dtype=np.float32)
        g_n = self.ground.shape[0]
        g_cell = 1000.0 / g_n
        obs_m = (
            (self.cls == 3)
            | (self.cls == 4)
            | (self.cls == 5)
            | (self.cls == 6)
            | (self.cls == 17)
        )
        if int(obs_m.sum()) < 200 and self.n > 0:
            # Fallback for unclassified point clouds or 3D DSM rasters: points > 2.0m above ground
            px_g = np.clip((self.pos[:, 0] / g_cell).astype(np.int32), 0, g_n - 1)
            py_g = np.clip((self.pos[:, 1] / g_cell).astype(np.int32), 0, g_n - 1)
            obs_m = (self.cls != 7) & (self.cls != 18) & (self.pos[:, 2] > (self.ground[py_g, px_g] + 2.0))
        if obs_m.any():
            vp = self.pos[obs_m]
            sx = np.clip((vp[:, 0] / s_cell).astype(np.int32), 0, s_n - 1)
            sy = np.clip((vp[:, 1] / s_cell).astype(np.int32), 0, s_n - 1)
            np.maximum.at(sflat, sy * s_n + sx, vp[:, 2])
        surf = sflat.reshape(s_n, s_n)
        # Fill 1-metre interior roof pinholes where >=3 of 4 orthogonal neighbours have obstacle points
        valid_s = np.isfinite(surf)
        if valid_s.any():
            pad = np.pad(np.where(valid_s, surf, -np.inf), 1, mode="edge")
            nb_max = np.maximum.reduce([pad[:-2, 1:-1], pad[2:, 1:-1], pad[1:-1, :-2], pad[1:-1, 2:]])
            nb_cnt = (
                np.isfinite(pad[:-2, 1:-1]).astype(np.int8)
                + np.isfinite(pad[2:, 1:-1]).astype(np.int8)
                + np.isfinite(pad[1:-1, :-2]).astype(np.int8)
                + np.isfinite(pad[1:-1, 2:]).astype(np.int8)
            )
            surf = np.where((~valid_s) & (nb_cnt >= 3), nb_max, surf)
        g_idx = np.clip((np.arange(s_n) * s_cell / g_cell).astype(np.int32), 0, g_n - 1)
        g_up = self.ground[np.ix_(g_idx, g_idx)]
        self.surface = np.where(np.isfinite(surf), np.maximum(surf, g_up), g_up).astype(np.float32)

        self.vbo_pos = None
        self.vbo_attr = None
        self.vbo_rgb = None
        self.vbo_infill_pos = None
        self.vbo_infill_attr = None
        self.vbo_infill_rgb = None
        self.draw_count = self.n

    def contains_local(self, x: float, y: float) -> bool:
        lx, ly = x - self.offset[0], y - self.offset[1]
        return 0.0 <= lx < 1000.0 and 0.0 <= ly < 1000.0

    def ground_z(self, x: float, y: float) -> Optional[float]:
        lx, ly = x - self.offset[0], y - self.offset[1]
        g = self.ground
        n = g.shape[0]
        cell = 1000.0 / n
        ix, iy = int(lx / cell), int(ly / cell)
        if 0 <= ix < n and 0 <= iy < n:
            return float(g[iy, ix])
        return None

    def date_label(self) -> str:
        if self.date_from and self.date_to and self.date_from != self.date_to:
            return f"{self.date_from} … {self.date_to}"
        return self.date_from or (str(self.file_info.year) if self.file_info else "")


def _detect_gpu_info() -> Tuple[bool, str]:
    """
    Detects all display and 3D render adapters on Windows via Win32 EnumDisplayDevicesW
    AND Registry without touching any OpenGL DLL.
    Returns (is_intel_only_without_nvidia_or_amd, gpu_summary_str).
    """
    import os
    os.environ.setdefault("SHIM_MCCOMPAT", "0x800000001")
    adapters: List[str] = []
    try:
        from ctypes import wintypes

        class _DISPLAY_DEVICEW(ctypes.Structure):
            _fields_ = [
                ("cb", wintypes.DWORD),
                ("DeviceName", wintypes.WCHAR * 32),
                ("DeviceString", wintypes.WCHAR * 128),
                ("StateFlags", wintypes.DWORD),
                ("DeviceID", wintypes.WCHAR * 128),
                ("DeviceKey", wintypes.WCHAR * 128),
            ]

        dd = _DISPLAY_DEVICEW()
        dd.cb = ctypes.sizeof(dd)
        for i in range(16):
            if not ctypes.windll.user32.EnumDisplayDevicesW(None, i, ctypes.byref(dd), 0):
                break
            if dd.DeviceString:
                desc = dd.DeviceString.strip()
                if desc and desc not in adapters and "mirror" not in desc.lower() and "remote" not in desc.lower():
                    adapters.append(desc)
    except Exception:
        pass

    # Always scan Registry class {4d36e968-e325-11ce-bfc1-08002be10318} as well so hybrid
    # NVIDIA Optimus / AMD Enduro dedicated laptop GPUs are always detected!
    try:
        import winreg
        key_path = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as base_k:
            for i in range(16):
                try:
                    with winreg.OpenKey(base_k, f"{i:04d}") as sub_k:
                        desc, _ = winreg.QueryValueEx(sub_k, "DriverDesc")
                        if desc:
                            d_str = str(desc).strip()
                            if d_str and d_str not in adapters:
                                adapters.append(d_str)
                except Exception:
                    continue
    except Exception:
        pass

    summary = ", ".join(adapters) if adapters else "Unknown GPU"
    low = summary.lower()
    has_intel = ("intel" in low) or ("arc" in low) or ("iris" in low)
    return has_intel, summary


# --------------------------------------------------------------------------- #
# Viewer widget (Pure QWidget: never triggers Qt6 QOpenGLWidget QRhi swapchain bugs)
# --------------------------------------------------------------------------- #
class AlsGLViewer(QWidget):
    tile_requested = pyqtSignal(str)
    active_tile_changed = pyqtSignal(str)
    status_message = pyqtSignal(str)
    measurement_changed = pyqtSignal(dict)
    scene_layers_changed = pyqtSignal()
    camera_moved = pyqtSignal(float, float, float, float, float, float)  # x_3301, y_3301, z, agl, yaw, pitch
    photo_requested = pyqtSignal()
    photo_mode_toggled = pyqtSignal(bool)
    photo_ui_toggled = pyqtSignal(bool)
    photo_captured = pyqtSignal(object)  # DronePhotoShot
    info_mode_toggled = pyqtSignal(bool)
    feature_selected = pyqtSignal(dict, float, float)   # feat_dict, click_x, click_y
    homepoint_picked = pyqtSignal(float, float, float)   # x_abs, y_abs, z_gnd

    FOV = 60.0
    NEAR = 0.5
    FAR = 25000.0

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setAutoFillBackground(False)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setMinimumSize(320, 240)

        # Scene
        self.scene_origin: Optional[np.ndarray] = None
        self.tiles: Dict[str, ViewerTile] = {}
        self.extra_layers: Dict[str, ViewerTile] = {}   # layer_key -> ViewerTile (Overflights & 3D DSM/DTM/Orto)
        self.tile_states: Dict[str, str] = {}
        self.active_tile = ""
        self.loading_percent: int = 0
        self.loading_text: str = ""
        self._last_data_card_w: float = 315.0

        # Vertical Wall & Void Interpolation + Overflight Merging
        self.interpolate_verticals: bool = True
        self.merge_overflights: bool = True

        # Drone Photoshoot Mode
        self.photo_mode: bool = False
        self.photo_include_ui: bool = True   # Default = UI on
        self.session_photos: List[DronePhotoShot] = []
        self._photo_flash_alpha: int = 0
        self._photo_banner_text: str = ""
        self._photo_banner_expiry: float = 0.0

        # Camera / drone
        self.cam = np.array([500.0, 500.0, 150.0])
        self.yaw = 0.0
        self.pitch = -25.0
        self.vel = np.zeros(3)
        self.base_speed = 15.0
        self.turbo = 4.0
        self.mouse_sens = 0.18
        self.ground_follow = True
        self._pending_agl: Optional[float] = None
        self.keys = set()
        self._drag_btn = None
        self._last_mouse = None
        self._press_pos = None
        self.cursor_pos = QPointF(-1, -1)

        # Render settings (Natural RGB from MaRu is default!)
        self.color_mode = COLOR_RGB
        self.rgb_brightness = 1.05
        self.intensity_gamma = 0.85
        self.custom_z_range: Optional[Tuple[float, float]] = None
        self.ramp_colors = np.array([
            [43, 131, 186],
            [171, 221, 164],
            [255, 255, 191],
            [253, 174, 97],
            [215, 25, 28],
        ], dtype=np.float32) / 255.0
        self.point_size = 1.4
        self.point_budget = 14_000_000

        # Dedicated Separate Drone Data Styling (independent from ALS data)
        self.drone_color_mode: int = COLOR_RGB       # Default RGB
        self.drone_point_size: float = 1.6
        self.drone_z_offset: float = 0.0             # Real-time Z-calibration in meters
        self.drone_rgb_brightness: float = 1.05
        self.drone_visible: bool = True
        self.class_visible = np.ones(32, dtype=np.float32)
        for c in DEFAULT_HIDDEN_CLASSES:
            self.class_visible[c] = 0.0
        self.class_colors = np.zeros((32, 3), dtype=np.float32)
        for i in range(32):
            self.class_colors[i] = np.array(CLASS_COLORS.get(i, (150, 150, 150))) / 255.0
        self.show_help = True
        self.auto_stream = True
        self.max_tiles = 16

        # 2D Canvas Vector Layers in 3D + Line-of-Sight (LOS) Occlusion (Default OFF per user request)
        self.show_canvas_layers = False
        self.los_occlusion = True
        self.canvas_raw_features: List[dict] = []   # [{name, color, width, lines_abs: [np.ndarray(N,2)], pts_abs: np.ndarray(M,2)}]
        self.canvas_draped_lines: List[Tuple[QColor, float, np.ndarray]] = []  # (color, width, pts_local_xyz(N,3))
        self.canvas_draped_pts: List[Tuple[QColor, str, np.ndarray]] = []      # (color, label, pt_local_xyz(3,))
        self.canvas_draped_polygons: List[Tuple[QColor, List[np.ndarray]]] = [] # (fill_color, [pts_local_xyz(N,3)])
        self.canvas_draped_features: List[dict] = []                           # [{feat_id, layer_name, lines3, pts3, centroid3, attributes}]

        # 3D Skybox & Horizon Options (Default: all OFF per user request)
        self.sky_procedural: bool = False
        self.sky_panorama: bool = False
        self.sky_fog: bool = False

        # Info Mode (I key & UI) & 3D Feature Picking
        self.info_mode: bool = False
        self.selected_feature: Optional[dict] = None

        # Measurement
        self.measure_mode = M.MODE_NONE
        self.measure_pts: List[Tuple[float, float, float]] = []
        self.measure_closed = False
        self.measure_result: dict = {}

        # Telemetry
        self.trail: List[Tuple[float, float, float, float, float, float]] = []  # t, X, Y, Z, AGL, speed, is_jump
        self.flown = 0.0
        self.flight_time = 0.0
        self._last_trail_pos = None
        self._last_trail_t = 0.0
        self._jump_pending: bool = False
        self.fps = 0.0
        self.points_drawn = 0

        # Minimap Zoom & Base Layer (Fotokaart / Põhikaart / Hübriidkaart / Võrk)
        self.minimap_span_m: float = 2600.0
        self.minimap_base_mode: str = "hyb"  # "foto" | "pohi" | "hyb" | "grid"
        self._minimap_images: Dict[Tuple[str, str], QImage] = {}
        self._minimap_fetcher = MinimapTileFetcher(self)
        self._minimap_fetcher.tile_image_ready.connect(self._on_minimap_tile_ready)
        self._mm_btn_zoom_in = QRectF()
        self._mm_btn_zoom_out = QRectF()
        self._mm_mode_rects: Dict[str, QRectF] = {}

        # Drone Signal Strength, Real-Time RC Telemetry & VLOS Simulation
        self.signal_result = None
        self.show_signal_3d: bool = False   # Default OFF: manual surface mesh on demand per user request
        self.homepoint_pick_mode: bool = False
        self.homepoint_abs: Optional[np.ndarray] = None    # [X, Y, Z_gnd]
        self.homepoint_local: Optional[np.ndarray] = None  # [lx, ly, lz_ant]
        self.live_drone_key: str = "mavic_3e"
        self.live_drone_name: str = "DJI Mavic 3E"
        self.live_signal_pct: float = 0.0
        self.live_signal_zone: int = ZONE_STRONG
        self.live_signal_status: str = ""
        self.live_signal_text: str = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
        self.live_signal_color: QColor = QColor(148, 163, 184)
        self.live_signal_occluded: bool = False
        self.live_signal_dist: float = 0.0
        self.live_vlos_text: str = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
        self.live_vlos_color: QColor = QColor(148, 163, 184)
        self._signal_mesh_pts: Optional[np.ndarray] = None
        self._signal_mesh_cols: Optional[np.ndarray] = None
        self._signal_mesh_count: int = 0
        self._signal_mesh_dirty: bool = False
        self._signal_vbo_pos = None
        self._signal_vbo_col = None
        self._signal_prog = None

        # Dual-Engine 3D Renderer:
        # 1. Isolated Offscreen OpenGL FBO Engine (hardware-accelerated, defaults for all GPUs including Intel Arc, NVIDIA, AMD)
        # 2. Pure NumPy Vectorized Software 3D Engine (compatibility fallback if offscreen OpenGL init fails)
        self._is_intel_gpu, self._gpu_summary = _detect_gpu_info()
        s = QgsSettings()
        self.render_engine_pref: str = str(s.value("maru_als/render_engine", "auto") or "auto")
        if self.render_engine_pref == "software":
            self._use_software_renderer: bool = True
        else:
            # "auto" and "fbo" both attempt hardware-accelerated Offscreen OpenGL FBO on all GPUs.
            # Falls back to pure NumPy software engine automatically only if offscreen GL init fails.
            self._use_software_renderer = False

        self._gl_surf = None
        self._gl_ctx = None
        self._gl_mod = None
        self._fbo: int = 0
        self._fbo_tex: int = 0
        self._fbo_rb: int = 0
        self._fbo_size: Tuple[int, int] = (0, 0)
        self._fbo_buf: Optional[np.ndarray] = None
        self._sw_buf: Optional[np.ndarray] = None
        self._sw_size: Tuple[int, int] = (0, 0)

        self._gl_ready = False
        self._gl_failed = ""
        self._prog = None
        self._loc = {}
        self._round_points = 1
        self._ctx_connected = None
        self._mvp = np.eye(4)
        self._drawn: List[Tuple[ViewerTile, int]] = []

        # Loop
        self._last_tick = time.perf_counter()
        self._last_paint = 0.0
        self._last_stream_check = 0.0
        self._dirty = True
        self.timer = QTimer(self)
        self.timer.setInterval(16)
        self.timer.timeout.connect(self._tick)

    def grabFramebuffer(self) -> QImage:
        """Captures the current QWidget 3D viewport as a QImage (compatible replacement for QOpenGLWidget.grabFramebuffer)."""
        return self.grab().toImage()

    def set_render_engine_preference(self, pref: str):
        """Switches 3D render engine ('auto' | 'software' | 'fbo') on the fly."""
        self.render_engine_pref = str(pref or "auto")
        if self.render_engine_pref == "software":
            self._use_software_renderer = True
        else:
            self._use_software_renderer = False
        self._dirty = True
        self.update()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def _ensure_origin(self, x: float, y: float):
        if self.scene_origin is None:
            self.scene_origin = np.array([math.floor(x / 1000.0) * 1000.0, math.floor(y / 1000.0) * 1000.0])

    def to_local(self, x: float, y: float) -> Tuple[float, float]:
        self._ensure_origin(x, y)
        return x - self.scene_origin[0], y - self.scene_origin[1]

    def to_abs(self, lx: float, ly: float) -> Tuple[float, float]:
        if self.scene_origin is None:
            return lx, ly
        return lx + self.scene_origin[0], ly + self.scene_origin[1]

    def set_loading_progress(self, percent: int, text: str = ""):
        self.loading_percent = max(0, min(100, int(percent)))
        self.loading_text = str(text or "")
        self._dirty = True
        self.update()

    def set_interpolate_verticals(self, enabled: bool):
        self.interpolate_verticals = bool(enabled)
        self._dirty = True
        self.update()

    def set_merge_overflights(self, enabled: bool):
        self.merge_overflights = bool(enabled)
        self._dirty = True
        self.update()

    def _on_minimap_tile_ready(self, mode: str, tile_id: str, img: QImage):
        self._minimap_images[(mode, tile_id)] = img
        self._dirty = True
        self.update()

    def set_minimap_base_mode(self, mode: str):
        if mode in ("pohi", "baas"):
            mode = "hall"
        if mode in MINIMAP_BASE_MODES:
            self.minimap_base_mode = mode
            self._dirty = True
            self.update()

    def zoom_minimap(self, factor: float):
        """Zooms the minimap in (< 1.0) or out (> 1.0), clamped between 500 m and 5800 m span."""
        self.minimap_span_m = max(500.0, min(5800.0, self.minimap_span_m * float(factor)))
        self._dirty = True
        self.update()

    def _emit_camera_moved(self):
        if self.scene_origin is None:
            return
        self._update_live_rf_and_vlos()
        X, Y = self.to_abs(self.cam[0], self.cam[1])
        g = self.ground_at(self.cam[0], self.cam[1])
        agl = float(self.cam[2] - g) if g is not None else float("nan")
        self.camera_moved.emit(
            float(X),
            float(Y),
            float(self.cam[2]),
            agl,
            float(self.yaw),
            float(self.pitch),
        )

    def _update_live_rf_and_vlos(self):
        """Updates real-time RC signal strength and Visual Line of Sight (VLOS) for Cockpit Telemetry UI."""
        if self.scene_origin is None:
            return

        if self.homepoint_local is None:
            self.live_signal_pct = 0.0
            self.live_signal_dist = 0.0
            self.live_signal_occluded = False
            self.live_signal_text = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
            self.live_signal_color = QColor(148, 163, 184)
            self.live_vlos_text = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
            self.live_vlos_color = QColor(148, 163, 184)
            return

        def surface_fn(xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
            surf = self.surface_at_vec(xs, ys)
            gnd = self.ground_at_vec(xs, ys, fallback=0.0)
            return np.where(np.isfinite(surf) & (surf > -1000.0), np.maximum(surf, gnd), gnd)

        # 1. RC Signal Strength
        sig_pct, zone_code, status_txt, is_occluded, dist_3d = evaluate_live_drone_signal(
            home_local=self.homepoint_local,
            drone_pos3=self.cam,
            drone_key=self.live_drone_key,
            surface_vec_fn=surface_fn,
        )
        self.live_signal_pct = sig_pct
        self.live_signal_zone = zone_code
        self.live_signal_status = status_txt
        self.live_signal_dist = dist_3d
        self.live_signal_occluded = is_occluded

        if is_occluded or zone_code == ZONE_SHADOW:
            self.live_signal_color = QColor(239, 68, 68)  # Red
            self.live_signal_text = f"0% · VARJATUD ({dist_3d:.0f}m)"
        elif zone_code == ZONE_MARGINAL:
            self.live_signal_color = QColor(249, 115, 22)  # Orange
            self.live_signal_text = f"{sig_pct:.0f}% · NÕRK ({dist_3d:.0f}m)"
        elif zone_code == ZONE_FAIR:
            self.live_signal_color = QColor(234, 179, 8)  # Yellow
            self.live_signal_text = f"{sig_pct:.0f}% · HEA ({dist_3d:.0f}m)"
        else:
            self.live_signal_color = QColor(34, 197, 94)  # Green
            self.live_signal_text = f"{sig_pct:.0f}% · TUGEV ({dist_3d:.0f}m)"

        # 2. Visual Line of Sight (VLOS)
        vlos_code, vlos_txt, vlos_d = evaluate_live_vlos(
            home_local=self.homepoint_local,
            drone_pos3=self.cam,
            drone_key=self.live_drone_key,
            surface_vec_fn=surface_fn,
        )
        if vlos_code == VLOS_BLOCKED:
            self.live_vlos_color = QColor(239, 68, 68)  # Red
            self.live_vlos_text = vlos_txt
        elif vlos_code == VLOS_BVLOS:
            self.live_vlos_color = QColor(234, 179, 8)  # Yellow / Amber
            self.live_vlos_text = vlos_txt
        elif vlos_code == VLOS_MARGINAL:
            self.live_vlos_color = QColor(249, 115, 22)  # Orange
            self.live_vlos_text = vlos_txt
        else:
            self.live_vlos_color = QColor(34, 197, 94)  # Green
            self.live_vlos_text = vlos_txt

    def set_homepoint(self, x_abs: float, y_abs: float, z_gnd: Optional[float] = None):
        """Sets the active Homepoint (ground controller location) in 3D scene."""
        ox = float(self.scene_origin[0]) if self.scene_origin is not None else 0.0
        oy = float(self.scene_origin[1]) if self.scene_origin is not None else 0.0

        lx = x_abs - ox
        ly = y_abs - oy

        if z_gnd is None:
            g = self.ground_at(lx, ly)
            z_gnd = float(g) if g is not None else 0.0

        lz_ant = float(z_gnd) + 1.8  # Ground antenna height ~1.8m AGL in pilot's hands

        self.homepoint_abs = np.array([x_abs, y_abs, z_gnd], dtype=np.float64)
        self.homepoint_local = np.array([lx, ly, lz_ant], dtype=np.float64)
        self._update_live_rf_and_vlos()
        self._dirty = True
        self.update()

    def clear_homepoint(self):
        """Resets Homepoint, 3D signal mesh, and telemetry text/colors to unset state."""
        self.homepoint_local = None
        self.homepoint_abs = None
        self._signal_mesh_pts = None
        self._signal_mesh_cols = None
        self._signal_mesh_count = 0
        self.live_signal_pct = 0.0
        self.live_signal_dist = 0.0
        self.live_signal_occluded = False
        self.live_signal_text = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
        self.live_signal_color = QColor(148, 163, 184)
        self.live_vlos_text = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
        self.live_vlos_color = QColor(148, 163, 184)
        self._dirty = True
        self.update()

    def set_homepoint_pick_mode(self, enabled: bool):
        """Enables or disables interactive 3D Homepoint clicking cursor mode."""
        self.homepoint_pick_mode = bool(enabled)
        if self.homepoint_pick_mode:
            self.setCursor(Qt.CursorShape.CrossCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)
        self.update()

    def set_drone_profile(self, drone_key: str):
        """Sets active drone model profile for real-time RC telemetry and VLOS calculation."""
        self.live_drone_key = str(drone_key)
        prof = DRONE_PROFILES.get(drone_key, DRONE_PROFILES["mavic_3e"])
        self.live_drone_name = prof.get("short_name", prof.get("name", drone_key))
        self._update_live_rf_and_vlos()
        self._dirty = True
        self.update()

    def all_scene_layers(self) -> List[ViewerTile]:
        """Returns all primary LAZ tiles and extra 3D layers (overflights, DSM, DTM, Orto)."""
        res: List[ViewerTile] = list(self.tiles.values())
        for k, ext in self.extra_layers.items():
            if ext not in res:
                res.append(ext)
        return res

    def get_drone_tiles(self) -> List[ViewerTile]:
        """Returns all loaded 3D drone survey tiles/layers."""
        res = []
        for t in self.all_scene_layers():
            if getattr(t, "is_drone", False):
                res.append(t)
        return res

    def set_drone_color_mode(self, mode: int):
        self.drone_color_mode = int(mode)
        self._dirty = True
        self.update()

    def set_drone_point_size(self, size: float):
        self.drone_point_size = max(0.2, min(10.0, float(size)))
        self._dirty = True
        self.update()

    def set_drone_z_offset(self, offset_m: float):
        self.drone_z_offset = float(offset_m)
        self._dirty = True
        self.update()

    def set_drone_rgb_brightness(self, bright: float):
        self.drone_rgb_brightness = max(0.1, min(5.0, float(bright)))
        self._dirty = True
        self.update()

    def set_drone_visible(self, visible: bool):
        self.drone_visible = bool(visible)
        self._dirty = True
        self.update()

    def all_visible_tiles(self) -> List[ViewerTile]:
        return [t for t in self.all_scene_layers() if t.visible]

    def is_layer_loaded_in_3d(self, filename: str) -> bool:
        for t in self.all_scene_layers():
            if t.file_info and t.file_info.filename == filename and t.visible:
                return True
        return False

    def set_scene_layer_visible(self, layer_key: str, visible: bool):
        for t in self.all_scene_layers():
            if t.layer_key == layer_key:
                t.visible = bool(visible)
        self._dirty = True
        self.update()

    def remove_scene_layer(self, layer_key: str):
        if layer_key in self.extra_layers:
            t = self.extra_layers.pop(layer_key)
            self._release_tile_gl(t)
        else:
            for tid, t in list(self.tiles.items()):
                if t.layer_key == layer_key:
                    self.remove_tile(tid)
                    break
        self.scene_layers_changed.emit()
        self._dirty = True
        self.update()

    def set_camera_abs(self, x: float, y: float, z: Optional[float] = None,
                       heading: Optional[float] = None, pitch: Optional[float] = None,
                       agl: float = 90.0):
        lx, ly = self.to_local(x, y)
        self.cam[0], self.cam[1] = lx, ly
        if z is not None:
            self.cam[2] = z
            self._pending_agl = None
        else:
            g = self.ground_at(lx, ly)
            if g is not None:
                self.cam[2] = g + agl
                self._pending_agl = None
            else:
                self._pending_agl = agl
        if heading is not None:
            self.yaw = heading % 360.0
        if pitch is not None:
            self.pitch = max(-89.0, min(89.0, pitch))
        self.vel[:] = 0
        self._last_trail_pos = self.cam.copy()
        self._last_trail_t = time.perf_counter()
        self._jump_pending = True
        g_cur = self.ground_at(self.cam[0], self.cam[1])
        agl_cur = float(self.cam[2] - g_cur) if g_cur is not None else float(agl)
        is_jump = len(self.trail) > 0
        self.trail.append((time.time(), float(x), float(y), float(self.cam[2]), agl_cur, 0.0, is_jump))
        if len(self.trail) > 20000:
            self.trail = self.trail[-20000:]
        self._emit_camera_moved()
        self._dirty = True
        self.update()

    def add_tile(self, tile_id: str, file_info, data: dict):
        origin = data["origin"]
        self._ensure_origin(float(origin[0]) + 1.0, float(origin[1]) + 1.0)
        tile = ViewerTile(tile_id, file_info, data, self.scene_origin)

        if tile.is_raster_3d:
            # Extra 3D raster layer (DSM 1m, DTM 1m, Orthophoto, Basic Map)
            if tile.layer_key in self.extra_layers:
                self._release_tile_gl(self.extra_layers[tile.layer_key])
            self.extra_layers[tile.layer_key] = tile
            if (
                tile.raster_cat in ("dsm_1m", "dtm_1m")
                and tile_id in self.tiles
                and self.tiles[tile_id].ground.shape == tile.ground.shape
            ):
                # Enhance primary tile's ground/void surface with 1m DSM/DTM
                self.tiles[tile_id].ground = np.minimum(self.tiles[tile_id].ground, tile.ground)
            if tile_id not in self.tiles:
                self.tile_states[tile_id] = STATE_LOADED
        else:
            if tile_id in self.tiles:
                prev = self.tiles[tile_id]
                if self.merge_overflights and prev.layer_key != tile.layer_key:
                    # Keep previous overflight in extra_layers so both combine to fill vertical/shadow gaps!
                    self.extra_layers[prev.layer_key] = prev
                else:
                    self._release_tile_gl(prev)
            self.tiles[tile_id] = tile
            self.tile_states[tile_id] = STATE_LOADED

        if self._pending_agl is not None:
            g = self.ground_at(self.cam[0], self.cam[1])
            if g is not None:
                self.cam[2] = g + self._pending_agl
                self._pending_agl = None
        self._enforce_tile_limit()
        self._update_active_tile(force=True)
        self._redrape_canvas_layers()
        self._emit_camera_moved()
        if self.pending_count() == 0:
            self.loading_percent = 100
            self.loading_text = ""
        self.scene_layers_changed.emit()
        self._dirty = True
        self.update()

    def remove_tile(self, tile_id: str):
        tile = self.tiles.pop(tile_id, None)
        if tile:
            self._release_tile_gl(tile)
        self.tile_states.pop(tile_id, None)
        self.scene_layers_changed.emit()
        self._dirty = True
        self.update()

    def clear_tiles(self):
        for tid in list(self.tiles.keys()):
            self.remove_tile(tid)
        for k in list(self.extra_layers.keys()):
            t = self.extra_layers.pop(k, None)
            if t:
                self._release_tile_gl(t)
        self.tile_states.clear()
        self.clear_homepoint()
        self.scene_layers_changed.emit()

    def set_tile_state(self, tile_id: str, state: Optional[str]):
        if state is None:
            self.tile_states.pop(tile_id, None)
        else:
            self.tile_states[tile_id] = state
        self._dirty = True
        self.update()

    def pending_count(self) -> int:
        return sum(1 for s in self.tile_states.values() if s in (STATE_QUEUED, STATE_LOADING))

    def set_color_mode(self, mode: int):
        self.color_mode = mode
        self._dirty = True
        self.update()

    def any_rgb(self) -> bool:
        return any(t.has_rgb for t in self.tiles.values())

    def set_point_size(self, v: float):
        self.point_size = max(0.3, min(6.0, v))
        self._dirty = True
        self.update()

    def set_class_visible(self, cls: int, visible: bool):
        if 0 <= cls < 32:
            self.class_visible[cls] = 1.0 if visible else 0.0
            self._dirty = True
            self.update()

    def set_elevation_ramp(self, stops_rgb: List[Tuple[int, int, int]]):
        if len(stops_rgb) == 5:
            self.ramp_colors = np.array(stops_rgb, dtype=np.float32) / 255.0
            self._dirty = True
            self.update()

    def set_rgb_brightness(self, b: float):
        self.rgb_brightness = max(0.3, min(2.5, float(b)))
        self._dirty = True
        self.update()

    def set_intensity_gamma(self, g: float):
        self.intensity_gamma = max(0.2, min(2.5, float(g)))
        self._dirty = True
        self.update()

    def set_custom_z_range(self, zmin: Optional[float], zmax: Optional[float]):
        if zmin is not None and zmax is not None and zmin < zmax:
            self.custom_z_range = (float(zmin), float(zmax))
        else:
            self.custom_z_range = None
        self._dirty = True
        self.update()

    def set_custom_class_color(self, cls_code: int, rgb: Tuple[int, int, int]):
        if 0 <= cls_code < 32:
            self.class_colors[cls_code] = np.array(rgb, dtype=np.float32) / 255.0
            self._dirty = True
            self.update()

    def set_canvas_layers_visible(self, visible: bool):
        self.show_canvas_layers = bool(visible)
        self._dirty = True
        self.update()

    def set_los_occlusion(self, enabled: bool):
        self.los_occlusion = bool(enabled)
        self._dirty = True
        self.update()

    def set_skybox_options(self, procedural: bool = False, panorama: bool = False, fog: bool = False):
        """Sets procedural atmospheric sky, 360 panorama, and distance fog options (off by default)."""
        self.sky_procedural = bool(procedural)
        self.sky_panorama = bool(panorama)
        self.sky_fog = bool(fog)
        self._dirty = True
        self.update()

    def set_canvas_raw_features(self, features: List[dict]):
        """Sets 2D canvas vector features (in EPSG:3301) and drapes them onto the 3D terrain."""
        self.canvas_raw_features = features
        self._redrape_canvas_layers()
        self._dirty = True
        self.update()

    def _redrape_canvas_layers(self):
        """Drapes stored 2D EPSG:3301 vector features onto the loaded 3D terrain ground grid (+0.15m road-marking offset)."""
        self.canvas_draped_lines = []
        self.canvas_draped_pts = []
        self.canvas_draped_photos = []
        self.canvas_draped_polygons = []
        self.canvas_draped_features = []
        if not self.canvas_raw_features or self.scene_origin is None:
            return
        ox, oy = float(self.scene_origin[0]), float(self.scene_origin[1])
        default_z = float(np.mean([t.z_range[0] for t in self.tiles.values()])) if self.tiles else 10.0

        for item in self.canvas_raw_features:
            col: QColor = item.get("color", QColor(244, 114, 182))
            width: float = float(item.get("width", 2.2))

            # 3D Photo layer waypoints (exempt from ground draping: with true altitude & 3D heading)
            if item.get("is_photo_layer") or item.get("photo_pts_3d"):
                p_list = list(item.get("photo_pts_3d", []))
                if not p_list and self.session_photos:
                    for shot in self.session_photos:
                        p_list.append({
                            "x_3301": shot.x_3301,
                            "y_3301": shot.y_3301,
                            "z_eh2000": shot.z_eh2000,
                            "agl_m": shot.agl_m,
                            "yaw_deg": shot.yaw_deg,
                            "pitch_deg": shot.pitch_deg,
                            "shot_id": shot.shot_id,
                            "filename": shot.filename,
                        })
                for pdata in p_list:
                    lx = float(pdata["x_3301"]) - ox
                    ly = float(pdata["y_3301"]) - oy
                    lz = float(pdata["z_eh2000"])  # True flight altitude in air!
                    g = self.ground_at(lx, ly)
                    gz = float(g) if g is not None else default_z
                    self.canvas_draped_photos.append({
                        "cam_pos3": np.array([lx, ly, lz], dtype=np.float64),
                        "gnd_pos3": np.array([lx, ly, gz], dtype=np.float64),
                        "yaw_deg": float(pdata.get("yaw_deg", 0.0)),
                        "pitch_deg": float(pdata.get("pitch_deg", 0.0)),
                        "shot_id": pdata.get("shot_id", 1),
                        "z_eh2000": lz,
                        "agl_m": float(pdata.get("agl_m", 0.0)),
                        "col": QColor(245, 158, 11),
                    })
                continue

            # Per-feature structured draping with individual styles & attribute hit-testing
            features = item.get("features", [])
            if features:
                for f in features:
                    f_col = f.get("color", col)
                    f_width = float(f.get("width", width))
                    f_is_polygon = bool(f.get("is_polygon", False))
                    f_fill_col = f.get("fill_color", None)
                    feat_lines3 = []
                    feat_pts3 = []

                    for line_xy in f.get("lines_abs", []):
                        if len(line_xy) < 2:
                            continue
                        lx = line_xy[:, 0] - ox
                        ly = line_xy[:, 1] - oy
                        gz = self.ground_at_vec(lx, ly, fallback=default_z) + 0.15
                        pts3 = np.column_stack([lx, ly, gz]).astype(np.float64)
                        feat_lines3.append(pts3)
                        self.canvas_draped_lines.append((f_col, f_width, pts3))

                    # If feature is a polygon with valid fill color, register for filled drawing
                    if (
                        f_is_polygon
                        and f_fill_col is not None
                        and getattr(f_fill_col, "isValid", lambda: False)()
                        and f_fill_col.alpha() > 5
                        and feat_lines3
                    ):
                        self.canvas_draped_polygons.append((f_fill_col, feat_lines3))

                    for pt_xy in f.get("pts_abs", []):
                        lx = float(pt_xy[0]) - ox
                        ly = float(pt_xy[1]) - oy
                        g = self.ground_at(lx, ly)
                        z = (g if g is not None else default_z) + 0.25
                        pt3 = np.array([lx, ly, z], dtype=np.float64)
                        feat_pts3.append(pt3)
                        self.canvas_draped_pts.append((f_col, "", pt3))

                    all_v = []
                    for l3 in feat_lines3:
                        all_v.append(l3)
                    for p3 in feat_pts3:
                        all_v.append(p3.reshape(1, 3))
                    if all_v:
                        c3 = np.mean(np.vstack(all_v), axis=0)
                    else:
                        c3 = np.array([0.0, 0.0, default_z], dtype=np.float64)

                    self.canvas_draped_features.append({
                        "feat_id": f.get("feat_id"),
                        "layer_id": f.get("layer_id"),
                        "layer_name": f.get("layer_name", item.get("name", "")),
                        "color": f_col,
                        "width": f_width,
                        "fill_color": f_fill_col,
                        "is_polygon": f_is_polygon,
                        "lines3": feat_lines3,
                        "pts3": feat_pts3,
                        "centroid3": c3,
                        "attributes": f.get("attributes", {}),
                    })
                continue

            # Fallback for layers without per-feature extraction
            for line_xy in item.get("lines_abs", []):
                if len(line_xy) < 2:
                    continue
                lx = line_xy[:, 0] - ox
                ly = line_xy[:, 1] - oy
                # 2D layers have no height: place at ground level + 0.15 m (like road markings)
                gz = self.ground_at_vec(lx, ly, fallback=default_z) + 0.15
                pts3 = np.column_stack([lx, ly, gz]).astype(np.float64)
                self.canvas_draped_lines.append((col, width, pts3))
            for pt_xy, lbl in item.get("pts_abs", []):
                lx = float(pt_xy[0]) - ox
                ly = float(pt_xy[1]) - oy
                g = self.ground_at(lx, ly)
                z = (g if g is not None else default_z) + 0.25
                self.canvas_draped_pts.append((col, str(lbl or ""), np.array([lx, ly, z], dtype=np.float64)))

    def ground_at_vec(self, xs: np.ndarray, ys: np.ndarray, fallback: float = 0.0) -> np.ndarray:
        """Vectorized ground elevation lookup across all loaded tiles."""
        out = np.full(xs.shape, fallback, dtype=np.float32)
        for t in self.tiles.values():
            lx = xs - t.offset[0]
            ly = ys - t.offset[1]
            m = (lx >= 0.0) & (lx < 1000.0) & (ly >= 0.0) & (ly < 1000.0)
            if not m.any():
                continue
            n = t.ground.shape[0]
            cell = 1000.0 / n
            ix = np.clip((lx[m] / cell).astype(np.int32), 0, n - 1)
            iy = np.clip((ly[m] / cell).astype(np.int32), 0, n - 1)
            out[m] = t.ground[iy, ix]
        return out

    def surface_at_vec(self, xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
        """Vectorized 1.0m DSM surface (trees/buildings/ground) elevation lookup for LOS occlusion."""
        out = np.full(xs.shape, -np.inf, dtype=np.float32)
        for t in self.tiles.values():
            lx = xs - t.offset[0]
            ly = ys - t.offset[1]
            m = (lx >= 0.0) & (lx < 1000.0) & (ly >= 0.0) & (ly < 1000.0)
            if not m.any():
                continue
            n = t.surface.shape[0]
            cell = 1000.0 / n
            ix = np.clip((lx[m] / cell).astype(np.int32), 0, n - 1)
            iy = np.clip((ly[m] / cell).astype(np.int32), 0, n - 1)
            out[m] = np.maximum(out[m], t.surface[iy, ix])
        return out

    def is_occluded_vec(self, pts: np.ndarray) -> np.ndarray:
        """
        Vectorized Line-of-Sight (LOS) test from ground-level points `pts` (M, 3) toward
        camera `self.cam`.
        Samples metric horizontal distances starting 1.6m in front of each target point
        toward the camera so lines in front of or beside a building remain visible while
        segments passing under or behind buildings/trees are occluded.
        """
        m_cnt = len(pts)
        if m_cnt == 0 or not self.tiles:
            return np.zeros(m_cnt, dtype=bool)
        cam = self.cam
        # 6 strategic logarithmic ray steps (metres): catches 99.9% of structures/trees with 3x speedup
        d_steps = np.array(
            [2.2, 5.0, 11.0, 24.0, 52.0, 105.0],
            dtype=np.float32,
        )[None, :]  # (1, K)
        dx = (cam[0] - pts[:, 0:1]).astype(np.float32)
        dy = (cam[1] - pts[:, 1:2]).astype(np.float32)
        dz = (cam[2] - pts[:, 2:3]).astype(np.float32)
        dist_xy = np.maximum(np.hypot(dx, dy), 1e-3)
        t_ray = np.clip(d_steps / dist_xy, 0.0, 0.96)  # (M, K)
        rx = pts[:, 0:1].astype(np.float32) + dx * t_ray
        ry = pts[:, 1:2].astype(np.float32) + dy * t_ray
        rz = pts[:, 2:3].astype(np.float32) + dz * t_ray
        surf_z = self.surface_at_vec(rx.ravel(), ry.ravel()).reshape(rx.shape)
        valid_step = d_steps < (dist_xy - 1.5)
        return np.any(valid_step & (surf_z > (rz + 0.65)), axis=1)

    def capture_photo(self, include_ui: bool = True):
        """Captures a high-resolution snapshot of the 3D viewport with UI either ON or OFF."""
        if include_ui:
            self.repaint()
            img = self.grabFramebuffer()
        else:
            self._hide_hud_for_capture = True
            self.repaint()
            img = self.grabFramebuffer()
            self._hide_hud_for_capture = False
            self.update()

        # Trigger subtle camera shutter flash animation
        self._photo_flash_alpha = 180
        self.update()
        return img

    def set_photo_mode(self, enabled: bool):
        self.photo_mode = bool(enabled)
        self.photo_mode_toggled.emit(self.photo_mode)
        if self.photo_mode:
            self._photo_banner_text = "📸 FOTOREŽIIM: Klõpsa foto tegemiseks | U: UI | P: välju"
            self._photo_banner_expiry = time.time() + 3.0
        self._dirty = True
        self.update()

    def set_photo_ui(self, include_ui: bool):
        self.photo_include_ui = bool(include_ui)
        self.photo_ui_toggled.emit(self.photo_include_ui)
        status_txt = "UI NÄHTAV (kokpiti andmed)" if self.photo_include_ui else "UI PEIDETUD (puhtad fotod)"
        self._photo_banner_text = f"📸 {status_txt}"
        self._photo_banner_expiry = time.time() + 2.5
        self._dirty = True
        self.update()

    def set_info_mode(self, enabled: bool):
        self.info_mode = bool(enabled)
        if self.info_mode:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)
            self.clear_feature_selection()
        self.info_mode_toggled.emit(self.info_mode)
        self._dirty = True
        self.update()

    def clear_feature_selection(self):
        if self.selected_feature is not None:
            self.selected_feature = None
            self._dirty = True
            self.update()

    def _hit_test_canvas_feature(self, mx: float, my: float, threshold_px: float = 14.0) -> Optional[dict]:
        """Hit-tests screen coordinates (mx, my) against visible draped 2D features (polygons, lines, points)."""
        if not self.canvas_draped_features:
            return None

        click_pt = QPointF(mx, my)
        best_poly_feat = None
        min_poly_area = float("inf")

        best_edge_feat = None
        min_dist = threshold_px + 1.0

        scr_w = float(self.width())
        scr_h = float(self.height())
        mvp_t = self._mvp.T

        for feat in self.canvas_draped_features:
            is_poly = feat.get("is_polygon", False)

            # 1. Point-in-polygon containment check
            if is_poly:
                for l3 in feat.get("lines3", []):
                    n_pts = len(l3)
                    if n_pts < 3:
                        continue
                    h_coords = np.hstack([l3, np.ones((n_pts, 1), dtype=np.float64)])
                    clip = h_coords @ mvp_t
                    cw = clip[:, 3]
                    in_front = cw >= self.NEAR
                    if np.sum(in_front) < 3:
                        continue
                    w_safe = np.maximum(cw, 1e-4)
                    sx = (clip[:, 0] / w_safe * 0.5 + 0.5) * scr_w
                    sy = (-clip[:, 1] / w_safe * 0.5 + 0.5) * scr_h

                    poly_pts = [QPointF(sx[i], sy[i]) for i in range(n_pts) if in_front[i]]
                    if len(poly_pts) >= 3:
                        qpoly = QPolygonF(poly_pts)
                        if qpoly.containsPoint(click_pt, Qt.FillRule.OddEvenFill):
                            bbox = qpoly.boundingRect()
                            area = bbox.width() * bbox.height()
                            if area < min_poly_area:
                                min_poly_area = area
                                best_poly_feat = feat

            # 2. Point markers
            for pt3 in feat.get("pts3", []):
                sp = self.project(pt3)
                if sp is not None:
                    d = math.hypot(mx - sp.x(), my - sp.y())
                    if d < min_dist:
                        min_dist = d
                        best_edge_feat = feat

            # 3. Line segments & polygon borders
            for l3 in feat.get("lines3", []):
                n_pts = len(l3)
                if n_pts < 2:
                    continue
                h_coords = np.hstack([l3, np.ones((n_pts, 1), dtype=np.float64)])
                clip = h_coords @ mvp_t
                cw = clip[:, 3]
                in_front = cw >= self.NEAR
                if not np.any(in_front):
                    continue
                w_safe = np.maximum(cw, 1e-4)
                sx = (clip[:, 0] / w_safe * 0.5 + 0.5) * scr_w
                sy = (-clip[:, 1] / w_safe * 0.5 + 0.5) * scr_h

                for i in range(n_pts - 1):
                    if in_front[i] and in_front[i + 1]:
                        x1, y1 = sx[i], sy[i]
                        x2, y2 = sx[i + 1], sy[i + 1]
                        dx = x2 - x1
                        dy = y2 - y1
                        l2 = dx * dx + dy * dy
                        if l2 < 1e-6:
                            d = math.hypot(mx - x1, my - y1)
                        else:
                            t = max(0.0, min(1.0, ((mx - x1) * dx + (my - y1) * dy) / l2))
                            d = math.hypot(mx - (x1 + t * dx), my - (y1 + t * dy))
                        if d < min_dist:
                            min_dist = d
                            best_edge_feat = feat

        # Prioritize exact line/point hit if within close distance (7px);
        # otherwise return enclosing polygon if clicked anywhere inside its borders!
        if min_dist <= 7.0 and best_edge_feat is not None:
            return best_edge_feat
        if best_poly_feat is not None:
            return best_poly_feat
        if min_dist <= threshold_px and best_edge_feat is not None:
            return best_edge_feat

        return None

    def take_photo_shot(self) -> Optional[DronePhotoShot]:
        """Snaps a drone photo, applies shutter flash, creates DronePhotoShot record, and emits signal."""
        img = self.capture_photo(include_ui=self.photo_include_ui)
        if img is None or img.isNull():
            return None

        # Coordinates
        abs_x, abs_y = self.to_abs(self.cam[0], self.cam[1])
        z = float(self.cam[2])
        g = self.ground_at(self.cam[0], self.cam[1])
        agl = float(z - g) if g is not None else 0.0
        now = datetime.datetime.now()
        shot_id = len(self.session_photos) + 1
        fname = f"DJI_{shot_id:04d}.png"

        shot = DronePhotoShot(
            shot_id=shot_id,
            image=img,
            timestamp=now,
            x_3301=float(abs_x),
            y_3301=float(abs_y),
            z_eh2000=z,
            agl_m=agl,
            yaw_deg=float(self.yaw),
            pitch_deg=float(self.pitch),
            gimbal_pitch=float(self.pitch),
            filename=fname,
        )
        self.session_photos.append(shot)

        # Copy to system clipboard for immediate paste
        try:
            from qgis.PyQt.QtGui import QGuiApplication
            QGuiApplication.clipboard().setImage(img)
        except Exception:
            pass

        # Trigger shutter flash & HUD banner
        self._photo_flash_alpha = 230
        self._photo_banner_text = f"📸 Foto #{shot_id} tehtud! ({fname})"
        self._photo_banner_expiry = time.time() + 2.5
        self.photo_captured.emit(shot)
        self._dirty = True
        self.update()
        return shot

    def clear_session_photos(self):
        self.session_photos.clear()
        self._dirty = True
        self.update()

    def set_measure_mode(self, mode: str):
        self.measure_mode = mode
        self.measure_pts = []
        self.measure_closed = False
        self.measure_result = {}
        self.measurement_changed.emit({"mode": mode})
        self._dirty = True
        self.update()

    def clear_measure(self):
        self.measure_pts = []
        self.measure_closed = False
        self.measure_result = {}
        self.measurement_changed.emit({"mode": self.measure_mode})
        self._dirty = True
        self.update()

    def reset_view(self):
        if not self.tiles:
            return
        xs = [t.offset[0] + 500 for t in self.tiles.values()]
        ys = [t.offset[1] + 500 for t in self.tiles.values()]
        zmax = max(t.z_range[1] for t in self.tiles.values())
        cx, cy = float(np.mean(xs)), float(np.mean(ys))
        self.cam[:] = (cx, cy - 700.0, zmax + 450.0)
        self.yaw = 0.0
        self.pitch = -32.0
        self.vel[:] = 0
        self._emit_camera_moved()
        self._dirty = True
        self.update()

    def ground_at(self, x: float, y: float) -> Optional[float]:
        for t in self.tiles.values():
            if t.contains_local(x, y):
                return t.ground_z(x, y)
        return None

    def active_tile_info(self) -> Optional[ViewerTile]:
        if self.active_tile in self.tiles:
            return self.tiles[self.active_tile]
        if not self.tiles:
            return None
        return min(
            self.tiles.values(),
            key=lambda t: math.hypot(self.cam[0] - (t.offset[0] + 500.0), self.cam[1] - (t.offset[1] + 500.0)),
        )

    def trail_abs(self):
        return list(self.trail)

    # ------------------------------------------------------------------ #
    # Dual-Engine 3D Rendering (Pure NumPy Software + Offscreen OpenGL FBO)
    # ------------------------------------------------------------------ #
    def isValid(self) -> bool:
        return bool(self._gl_ready and self._gl_ctx is not None and self._gl_surf is not None)

    def makeCurrent(self) -> bool:
        if self._gl_ctx is not None and self._gl_surf is not None:
            try:
                return bool(self._gl_ctx.makeCurrent(self._gl_surf))
            except Exception:
                return False
        return False

    def doneCurrent(self):
        if self._gl_ctx is not None:
            try:
                self._gl_ctx.doneCurrent()
            except Exception:
                pass

    def _ensure_offscreen_gl(self, wpx: int, hpx: int) -> bool:
        """
        Lazily initializes an isolated QOffscreenSurface + QOpenGLContext + Framebuffer Object (FBO).
        Never uses QOpenGLWidget, so Qt6's QMainWindow / QDockWidget backingstore is never touched.
        Only called when _use_software_renderer is False.
        """
        if self._use_software_renderer:
            return False
        wpx = max(16, int(wpx))
        hpx = max(16, int(hpx))
        try:
            if self._gl_mod is None:
                from OpenGL import GL as _GL
                self._gl_mod = _GL
            GL = self._gl_mod

            if self._gl_ctx is None or self._gl_surf is None:
                from qgis.PyQt.QtGui import QOffscreenSurface, QOpenGLContext, QSurfaceFormat
                fmt = QSurfaceFormat()
                fmt.setRenderableType(QSurfaceFormat.RenderableType.OpenGL)
                fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CompatibilityProfile)
                fmt.setDepthBufferSize(24)
                fmt.setStencilBufferSize(8)

                surf = QOffscreenSurface()
                surf.setFormat(fmt)
                surf.create()
                ctx = QOpenGLContext()
                ctx.setFormat(fmt)
                if not ctx.create():
                    raise RuntimeError("QOpenGLContext.create() failed")
                if not ctx.makeCurrent(surf):
                    raise RuntimeError("QOpenGLContext.makeCurrent() failed")

                self._gl_surf = surf
                self._gl_ctx = ctx
                for t in self.all_scene_layers():
                    t.vbo_pos = t.vbo_attr = t.vbo_rgb = None
                    t.vbo_infill_pos = t.vbo_infill_attr = t.vbo_infill_rgb = None

                self._prog = self._build_program()
                names = [
                    "u_mvp", "u_offset", "u_cam", "u_mode", "u_has_rgb", "u_rgb_bright",
                    "u_inten_gamma", "u_zrange", "u_psize", "u_pscale", "u_spacing",
                    "u_classvis", "u_classcol", "u_ramp", "u_fog", "u_fogcol", "u_round"
                ]
                self._loc = {n: GL.glGetUniformLocation(self._prog, n) for n in names}
                self._gl_ready = True
                self._gl_failed = ""
            else:
                if not self.makeCurrent():
                    return False

            # Recreate or resize FBO if viewport dimensions changed
            if self._fbo == 0 or self._fbo_size != (wpx, hpx):
                if self._fbo:
                    try:
                        GL.glDeleteFramebuffers(1, [self._fbo])
                    except Exception:
                        pass
                if self._fbo_tex:
                    try:
                        GL.glDeleteTextures([self._fbo_tex])
                    except Exception:
                        pass
                if self._fbo_rb:
                    try:
                        GL.glDeleteRenderbuffers(1, [self._fbo_rb])
                    except Exception:
                        pass

                self._fbo = int(GL.glGenFramebuffers(1))
                GL.glBindFramebuffer(GL.GL_FRAMEBUFFER, self._fbo)

                self._fbo_tex = int(GL.glGenTextures(1))
                GL.glBindTexture(GL.GL_TEXTURE_2D, self._fbo_tex)
                GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
                GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
                GL.glTexImage2D(
                    GL.GL_TEXTURE_2D, 0, GL.GL_RGBA8, wpx, hpx, 0,
                    GL.GL_BGRA, GL.GL_UNSIGNED_BYTE, None
                )
                GL.glFramebufferTexture2D(
                    GL.GL_FRAMEBUFFER, GL.GL_COLOR_ATTACHMENT0, GL.GL_TEXTURE_2D, self._fbo_tex, 0
                )

                self._fbo_rb = int(GL.glGenRenderbuffers(1))
                GL.glBindRenderbuffer(GL.GL_RENDERBUFFER, self._fbo_rb)
                try:
                    GL.glRenderbufferStorage(GL.GL_RENDERBUFFER, GL.GL_DEPTH24_STENCIL8, wpx, hpx)
                    GL.glFramebufferRenderbuffer(
                        GL.GL_FRAMEBUFFER, GL.GL_DEPTH_STENCIL_ATTACHMENT, GL.GL_RENDERBUFFER, self._fbo_rb
                    )
                except Exception:
                    GL.glRenderbufferStorage(GL.GL_RENDERBUFFER, GL.GL_DEPTH_COMPONENT24, wpx, hpx)
                    GL.glFramebufferRenderbuffer(
                        GL.GL_FRAMEBUFFER, GL.GL_DEPTH_ATTACHMENT, GL.GL_RENDERBUFFER, self._fbo_rb
                    )

                status = GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)
                if status != GL.GL_FRAMEBUFFER_COMPLETE:
                    # Fall back to standard GL_DEPTH_COMPONENT24 if driver doesn't support combined depth/stencil FBO
                    GL.glRenderbufferStorage(GL.GL_RENDERBUFFER, GL.GL_DEPTH_COMPONENT24, wpx, hpx)
                    GL.glFramebufferRenderbuffer(
                        GL.GL_FRAMEBUFFER, GL.GL_DEPTH_ATTACHMENT, GL.GL_RENDERBUFFER, self._fbo_rb
                    )
                    status = GL.glCheckFramebufferStatus(GL.GL_FRAMEBUFFER)
                    if status != GL.GL_FRAMEBUFFER_COMPLETE:
                        raise RuntimeError(f"Incomplete FBO status: {status}")

                self._fbo_size = (wpx, hpx)
                self._fbo_buf = np.empty((hpx, wpx, 4), dtype=np.uint8)
            else:
                GL.glBindFramebuffer(GL.GL_FRAMEBUFFER, self._fbo)

            return True
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Offscreen OpenGL FBO fallback to NumPy 3D engine: {e}", "MaRu ALS", Qgis.Warning
            )
            self._gl_ready = False
            self._use_software_renderer = True
            return False

    def _build_program(self):
        GL = self._gl_mod

        def compile_shader(src, kind):
            sh = GL.glCreateShader(kind)
            GL.glShaderSource(sh, src)
            GL.glCompileShader(sh)
            if not GL.glGetShaderiv(sh, GL.GL_COMPILE_STATUS):
                log = GL.glGetShaderInfoLog(sh)
                raise RuntimeError(f"Shader compile error: {log}")
            return sh

        vs = compile_shader(VERT_SRC, GL.GL_VERTEX_SHADER)
        fs = compile_shader(FRAG_SRC, GL.GL_FRAGMENT_SHADER)
        prog = GL.glCreateProgram()
        GL.glAttachShader(prog, vs)
        GL.glAttachShader(prog, fs)
        GL.glBindAttribLocation(prog, 0, "a_pos")
        GL.glBindAttribLocation(prog, 1, "a_attr")
        GL.glBindAttribLocation(prog, 2, "a_rgb")
        GL.glLinkProgram(prog)
        if not GL.glGetProgramiv(prog, GL.GL_LINK_STATUS):
            raise RuntimeError(f"Program link error: {GL.glGetProgramInfoLog(prog)}")
        GL.glDeleteShader(vs)
        GL.glDeleteShader(fs)
        return prog

    def _build_color_program(self):
        GL = self._gl_mod

        def compile_sh(src, kind):
            sh = GL.glCreateShader(kind)
            GL.glShaderSource(sh, src)
            GL.glCompileShader(sh)
            if not GL.glGetShaderiv(sh, GL.GL_COMPILE_STATUS):
                log = GL.glGetShaderInfoLog(sh)
                raise RuntimeError(f"Color shader compile error: {log}")
            return sh

        vs_src = """#version 120
uniform mat4 u_mvp;
attribute vec3 a_pos;
attribute vec4 a_col;
varying vec4 v_col;
void main() {
    gl_Position = u_mvp * vec4(a_pos, 1.0);
    v_col = a_col;
}
"""
        fs_src = """#version 120
varying vec4 v_col;
void main() {
    gl_FragColor = v_col;
}
"""
        vs = compile_sh(vs_src, GL.GL_VERTEX_SHADER)
        fs = compile_sh(fs_src, GL.GL_FRAGMENT_SHADER)
        prog = GL.glCreateProgram()
        GL.glAttachShader(prog, vs)
        GL.glAttachShader(prog, fs)
        GL.glBindAttribLocation(prog, 0, "a_pos")
        GL.glBindAttribLocation(prog, 1, "a_col")
        GL.glLinkProgram(prog)
        if not GL.glGetProgramiv(prog, GL.GL_LINK_STATUS):
            raise RuntimeError(f"Color program link error: {GL.glGetProgramInfoLog(prog)}")
        GL.glDeleteShader(vs)
        GL.glDeleteShader(fs)
        return prog

    def _on_context_destroyed(self):
        GL = self._gl_mod
        if GL is not None and self._gl_ctx is not None:
            try:
                if self.makeCurrent():
                    for t in self.all_scene_layers():
                        self._delete_buffers(t)
                    if self._prog:
                        GL.glDeleteProgram(self._prog)
                    if self._signal_prog:
                        GL.glDeleteProgram(self._signal_prog)
                    if self._signal_vbo_pos:
                        GL.glDeleteBuffers(1, [self._signal_vbo_pos])
                    if self._signal_vbo_col:
                        GL.glDeleteBuffers(1, [self._signal_vbo_col])
                    if self._fbo:
                        GL.glDeleteFramebuffers(1, [self._fbo])
                    if self._fbo_tex:
                        GL.glDeleteTextures([self._fbo_tex])
                    if self._fbo_rb:
                        GL.glDeleteRenderbuffers(1, [self._fbo_rb])
                    self.doneCurrent()
            except Exception:
                pass
        self._prog = None
        self._signal_prog = None
        self._signal_vbo_pos = None
        self._signal_vbo_col = None
        self._fbo = 0
        self._fbo_tex = 0
        self._fbo_rb = 0
        self._fbo_size = (0, 0)
        self._gl_ready = False

    def _delete_buffers(self, t: ViewerTile):
        GL = self._gl_mod
        bufs = [
            b
            for b in (
                t.vbo_pos,
                t.vbo_attr,
                t.vbo_rgb,
                t.vbo_infill_pos,
                t.vbo_infill_attr,
                t.vbo_infill_rgb,
            )
            if b
        ]
        if bufs and GL is not None:
            try:
                GL.glDeleteBuffers(len(bufs), bufs)
            except Exception:
                pass
        t.vbo_pos = t.vbo_attr = t.vbo_rgb = None
        t.vbo_infill_pos = t.vbo_infill_attr = t.vbo_infill_rgb = None

    def _release_tile_gl(self, t: ViewerTile):
        if t.vbo_pos is None and t.vbo_attr is None and t.vbo_infill_pos is None:
            return
        if self._gl_ready and self.isValid():
            try:
                if self.makeCurrent():
                    self._delete_buffers(t)
                    self.doneCurrent()
            except Exception:
                pass
        t.vbo_pos = t.vbo_attr = t.vbo_rgb = None
        t.vbo_infill_pos = t.vbo_infill_attr = t.vbo_infill_rgb = None

    def _upload(self, t: ViewerTile):
        GL = self._gl_mod
        t.vbo_pos = int(GL.glGenBuffers(1))
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_pos)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, t.pos.nbytes, t.pos, GL.GL_STATIC_DRAW)
        t.vbo_attr = int(GL.glGenBuffers(1))
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_attr)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, t.attr.nbytes, t.attr, GL.GL_STATIC_DRAW)
        if t.has_rgb:
            t.vbo_rgb = int(GL.glGenBuffers(1))
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_rgb)
            GL.glBufferData(GL.GL_ARRAY_BUFFER, t.rgb.nbytes, t.rgb, GL.GL_STATIC_DRAW)

        if t.infill_n > 0:
            t.vbo_infill_pos = int(GL.glGenBuffers(1))
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_infill_pos)
            GL.glBufferData(GL.GL_ARRAY_BUFFER, t.infill_pos.nbytes, t.infill_pos, GL.GL_STATIC_DRAW)
            t.vbo_infill_attr = int(GL.glGenBuffers(1))
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_infill_attr)
            GL.glBufferData(GL.GL_ARRAY_BUFFER, t.infill_attr.nbytes, t.infill_attr, GL.GL_STATIC_DRAW)
            if t.infill_has_rgb and t.infill_rgb is not None:
                t.vbo_infill_rgb = int(GL.glGenBuffers(1))
                GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_infill_rgb)
                GL.glBufferData(GL.GL_ARRAY_BUFFER, t.infill_rgb.nbytes, t.infill_rgb, GL.GL_STATIC_DRAW)

        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._dirty = True

    # ------------------------------------------------------------------ #
    # Camera
    # ------------------------------------------------------------------ #
    def forward(self) -> np.ndarray:
        y, p = math.radians(self.yaw), math.radians(self.pitch)
        return np.array([math.sin(y) * math.cos(p), math.cos(y) * math.cos(p), math.sin(p)])

    def _compute_mvp(self) -> np.ndarray:
        w, h = max(1, self.width()), max(1, self.height())
        view = look_at(self.cam, self.cam + self.forward(), np.array([0.0, 0.0, 1.0]))
        proj = perspective(self.FOV, w / h, self.NEAR, self.FAR)
        return proj @ view

    # ------------------------------------------------------------------ #
    # Painting & Skybox / Horizon
    # ------------------------------------------------------------------ #
    def _calc_horizon_y(self, h: float) -> float:
        """Calculates screen Y position of the true horizon line based on camera pitch and FOV."""
        fov_rad = math.radians(max(10.0, float(self.FOV)))
        pitch_rad = math.radians(max(-89.9, min(89.9, float(self.pitch))))
        return (h / 2.0) + (h / 2.0) * (math.tan(pitch_rad) / math.tan(fov_rad / 2.0))

    def _draw_procedural_sky(self, p: QPainter):
        """Renders dynamic Rayleigh/Mie atmospheric scattering gradient tied to camera pitch and altitude."""
        w, h = float(self.width()), float(self.height())
        hy = self._calc_horizon_y(h)
        t = hy / max(1.0, h)

        grad = QLinearGradient(0, 0, 0, h)
        if t <= 0.0:
            grad.setColorAt(0.0, QColor(48, 64, 76))
            grad.setColorAt(1.0, QColor(20, 28, 36))
        elif t >= 1.0:
            grad.setColorAt(0.0, QColor(14, 42, 82))
            grad.setColorAt(1.0, QColor(68, 138, 214))
        else:
            t_sky_mid = max(0.0, t * 0.55)
            t_haze_top = max(0.0, t - 0.09)
            t_haze_bot = min(1.0, t + 0.08)
            grad.setColorAt(0.0, QColor(16, 44, 88))          # Deep zenith azure
            grad.setColorAt(t_sky_mid, QColor(64, 135, 215))  # Sky blue
            grad.setColorAt(t_haze_top, QColor(195, 222, 246))# Atmospheric haze
            grad.setColorAt(t, QColor(228, 238, 248))         # Bright horizon line
            grad.setColorAt(t_haze_bot, QColor(60, 78, 92))   # Distant terrain base
            grad.setColorAt(1.0, QColor(20, 28, 36))          # Ground nadir
        p.fillRect(self.rect(), QBrush(grad))

    def _draw_panorama_sky(self, p: QPainter):
        """Renders 360° Baltic panorama cloudscape rotating with drone yaw and tilting with pitch."""
        w, h = float(self.width()), float(self.height())
        hy = self._calc_horizon_y(h)
        t = hy / max(1.0, h)

        # 1. Base daytime Baltic sky gradient
        grad = QLinearGradient(0, 0, 0, h)
        if t <= 0.0:
            grad.setColorAt(0.0, QColor(44, 58, 70))
            grad.setColorAt(1.0, QColor(18, 24, 30))
        elif t >= 1.0:
            grad.setColorAt(0.0, QColor(12, 38, 78))
            grad.setColorAt(1.0, QColor(85, 155, 225))
        else:
            t_sky_mid = max(0.0, t * 0.52)
            t_haze_top = max(0.0, t - 0.12)
            t_haze_bot = min(1.0, t + 0.07)
            grad.setColorAt(0.0, QColor(12, 40, 84))
            grad.setColorAt(t_sky_mid, QColor(72, 145, 225))
            grad.setColorAt(t_haze_top, QColor(180, 215, 245))
            grad.setColorAt(t, QColor(235, 242, 250))
            grad.setColorAt(t_haze_bot, QColor(56, 74, 88))
            grad.setColorAt(1.0, QColor(18, 24, 30))
        p.fillRect(self.rect(), QBrush(grad))

        # 2. 360° Baltic Cumulus Clouds at horizon (panning seamlessly with self.yaw)
        if -140.0 < hy < h + 140.0:
            p.save()
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setPen(Qt.PenStyle.NoPen)
            yaw_deg = float(self.yaw) % 360.0
            span_px = max(1400.0, w * 2.2)
            offset_x = (yaw_deg / 360.0) * span_px

            cloud_seeds = [
                (0.05, -28.0, 220.0, 48.0, 75),
                (0.18, -42.0, 310.0, 62.0, 90),
                (0.32, -24.0, 190.0, 42.0, 65),
                (0.48, -50.0, 340.0, 70.0, 95),
                (0.63, -32.0, 240.0, 52.0, 80),
                (0.79, -46.0, 290.0, 58.0, 85),
                (0.92, -26.0, 210.0, 44.0, 70),
            ]
            for base_x in (-span_px, 0.0, span_px):
                for norm_x, dy, cw, ch, alpha in cloud_seeds:
                    cx = base_x + norm_x * span_px - offset_x
                    if -cw <= cx <= w + cw:
                        cy = hy + dy
                        p.setBrush(QBrush(QColor(255, 255, 255, alpha)))
                        p.drawEllipse(QPointF(cx, cy), cw * 0.5, ch * 0.5)
                        p.setBrush(QBrush(QColor(255, 255, 255, int(alpha * 0.7))))
                        p.drawEllipse(QPointF(cx + cw * 0.15, cy - ch * 0.22), cw * 0.35, ch * 0.38)
            p.restore()

    def paintEvent(self, event):
        now = time.perf_counter()
        dtp = now - self._last_paint if self._last_paint else 0.016
        self._last_paint = now
        if dtp > 0:
            self.fps = self.fps * 0.9 + (1.0 / max(dtp, 1e-3)) * 0.1
        self._dirty = False
        self._mvp = self._compute_mvp()

        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            if self.sky_panorama:
                self._draw_panorama_sky(painter)
            elif self.sky_procedural:
                self._draw_procedural_sky(painter)
            else:
                grad = QLinearGradient(0, 0, 0, self.height())
                grad.setColorAt(0.0, QColor(14, 24, 44))
                grad.setColorAt(0.55, QColor(46, 66, 96))
                grad.setColorAt(1.0, QColor(78, 98, 120))
                painter.fillRect(self.rect(), QBrush(grad))

            if self._use_software_renderer:
                self._render_scene_numpy(painter)
            else:
                if not self._render_scene_fbo(painter):
                    self._render_scene_numpy(painter)

            self._draw_hud(painter)
        finally:
            painter.end()

    def _render_scene_fbo(self, painter: QPainter) -> bool:
        """Renders 3D points and signal mesh into an isolated offscreen OpenGL FBO and blits to QWidget."""
        has_work = bool(self.all_visible_tiles()) or (
            self.show_signal_3d and self._signal_mesh_count > 0 and self._signal_mesh_pts is not None
        )
        if not has_work:
            self._drawn = []
            self.points_drawn = 0
            return True

        ratio = self.devicePixelRatioF()
        wpx = max(16, int(self.width() * ratio))
        hpx = max(16, int(self.height() * ratio))
        if not self._ensure_offscreen_gl(wpx, hpx):
            return False

        GL = self._gl_mod
        try:
            GL.glViewport(0, 0, wpx, hpx)
            GL.glClearColor(0.0, 0.0, 0.0, 0.0)
            GL.glDepthMask(GL.GL_TRUE)
            GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT)

            self._render_points(wpx, hpx)
            self._render_signal_mesh_gl()

            GL.glPixelStorei(GL.GL_PACK_ALIGNMENT, 4)
            GL.glReadPixels(0, 0, wpx, hpx, GL.GL_BGRA, GL.GL_UNSIGNED_BYTE, self._fbo_buf)
            self.doneCurrent()

            qimg = QImage(
                self._fbo_buf.data,
                wpx,
                hpx,
                wpx * 4,
                QImage.Format.Format_ARGB32,
            )
            painter.drawImage(self.rect(), qimg)
            return True
        except Exception as e:
            self.doneCurrent()
            QgsMessageLog.logMessage(f"3D FBO render error: {e}", "MaRu ALS", Qgis.Warning)
            if not self._gl_ready and self.render_engine_pref != "fbo":
                self._use_software_renderer = True
            return False

    def _render_scene_numpy(self, painter: QPainter):
        """
        100% OpenGL-free Vectorized NumPy 3D Point Cloud & Signal Mesh Engine.
        Guarantees zero GPU driver / Qt6 QRhi swapchain conflicts on Intel Arc / Iris Xe / Core Ultra GPUs.
        """
        sw_w = max(16, int(self.width()))
        sw_h = max(16, int(self.height()))
        is_moving = bool(self.keys) or (self._drag_btn is not None)
        sw_budget = min(int(self.point_budget), 650_000 if is_moving else 1_600_000)

        self._drawn = self._plan_draw(budget_override=sw_budget)
        self.points_drawn = sum(
            k + (int(t.infill_n * (k / max(1, t.n))) if (self.interpolate_verticals and t.infill_n > 0) else 0)
            for t, k in self._drawn
        )

        if self._drawn:
            if self._sw_buf is None or self._sw_size != (sw_w, sw_h):
                self._sw_buf = np.zeros(sw_h * sw_w, dtype=np.uint32)
                self._sw_size = (sw_w, sw_h)
            else:
                self._sw_buf.fill(0)

            self._render_points_numpy(sw_w, sw_h)
            qimg = QImage(
                self._sw_buf.data,
                sw_w,
                sw_h,
                sw_w * 4,
                QImage.Format.Format_ARGB32,
            )
            painter.drawImage(self.rect(), qimg)

        if self.show_signal_3d and self.signal_result is not None:
            self._render_signal_mesh_numpy(painter)

    def _render_points_numpy(self, sw_w: int, sw_h: int):
        vis_tiles = self.all_visible_tiles()
        if self.custom_z_range is not None:
            zlo, zhi = float(self.custom_z_range[0]), float(self.custom_z_range[1])
        elif vis_tiles:
            zlo = float(min(t.z_range[0] for t in vis_tiles))
            zhi = float(max(t.z_range[1] for t in vis_tiles))
        else:
            zlo, zhi = 0.0, 50.0
        z_span = max(zhi - zlo, 0.01)

        mvp = self._mvp.astype(np.float32)
        mvp_t = mvp[:, :3]
        fog_col = np.array(
            [0.74, 0.83, 0.92] if (self.sky_procedural or self.sky_panorama) else [0.24, 0.32, 0.42],
            dtype=np.float32,
        )

        pix_list: List[np.ndarray] = []
        cw_list: List[np.ndarray] = []
        col_list: List[np.ndarray] = []
        psize_list: List[np.ndarray] = []

        def _process_slice(
            pos_arr: np.ndarray,
            cls_arr: np.ndarray,
            inten_arr: np.ndarray,
            rgb_arr: Optional[np.ndarray],
            ox: float,
            oy: float,
            oz: float,
            t_mode: int,
            t_psize: float,
            t_rgb_bright: float,
        ):
            if pos_arr.shape[0] == 0:
                return
            c_idx = np.clip(cls_arr, 0, 31)
            vis_m = self.class_visible[c_idx] >= 0.5
            if not np.all(vis_m):
                pos_arr = pos_arr[vis_m]
                if pos_arr.shape[0] == 0:
                    return
                c_idx = c_idx[vis_m]
                inten_arr = inten_arr[vis_m]
                if rgb_arr is not None:
                    rgb_arr = rgb_arr[vis_m]

            mvp_c = mvp[:, 0] * ox + mvp[:, 1] * oy + mvp[:, 2] * oz + mvp[:, 3]
            cw = (
                pos_arr[:, 0] * mvp_t[3, 0]
                + pos_arr[:, 1] * mvp_t[3, 1]
                + pos_arr[:, 2] * mvp_t[3, 2]
                + mvp_c[3]
            )
            front_m = cw > self.NEAR
            if not np.any(front_m):
                return
            p_f = pos_arr[front_m]
            cw_f = cw[front_m]
            c_f = c_idx[front_m]
            inten_f = inten_arr[front_m]
            rgb_f_in = rgb_arr[front_m] if rgb_arr is not None else None

            inv_w = 1.0 / cw_f
            cx = (
                p_f[:, 0] * mvp_t[0, 0]
                + p_f[:, 1] * mvp_t[0, 1]
                + p_f[:, 2] * mvp_t[0, 2]
                + mvp_c[0]
            ) * inv_w
            cy = (
                p_f[:, 0] * mvp_t[1, 0]
                + p_f[:, 1] * mvp_t[1, 1]
                + p_f[:, 2] * mvp_t[1, 2]
                + mvp_c[1]
            ) * inv_w

            sx = ((cx + 1.0) * (0.5 * sw_w)).astype(np.int32)
            sy = ((1.0 - cy) * (0.5 * sw_h)).astype(np.int32)
            inb = (sx >= 0) & (sx < sw_w - 2) & (sy >= 0) & (sy < sw_h - 2)
            if not np.any(inb):
                return

            sx = sx[inb]
            sy = sy[inb]
            cw_v = cw_f[inb]
            c_v = c_f[inb]
            inten_v = inten_f[inb]
            p_v = p_f[inb]
            rgb_v = rgb_f_in[inb] if rgb_f_in is not None else None

            if t_mode == 1:
                col_rgb = self.class_colors[c_v]
            elif t_mode == 2:
                iv = np.power(np.maximum(inten_v, 0.0), float(self.intensity_gamma))
                col_rgb = np.column_stack((iv, iv, iv))
            elif t_mode == 3:
                if rgb_v is not None:
                    col_rgb = np.clip(rgb_v.astype(np.float32) * (t_rgb_bright / 255.0), 0.0, 1.0)
                else:
                    sh_i = (0.68 + 0.48 * inten_v)[:, None]
                    col_rgb = np.clip(self.class_colors[c_v] * sh_i, 0.0, 1.0)
            elif t_mode == 4:
                sh_i = (0.70 + 0.35 * inten_v)[:, None]
                col_rgb = np.clip(np.array([0.96, 0.62, 0.04], dtype=np.float32) * sh_i, 0.0, 1.0)
            elif t_mode == 5:
                sh_i = (0.70 + 0.35 * inten_v)[:, None]
                col_rgb = np.clip(np.array([0.14, 0.82, 0.94], dtype=np.float32) * sh_i, 0.0, 1.0)
            else:
                t_norm = np.clip((p_v[:, 2] + oz - zlo) / z_span, 0.0, 1.0)
                seg = np.minimum((t_norm * 4.0).astype(np.int32), 3)
                frac = (t_norm * 4.0 - seg)[:, None]
                col_rgb = self.ramp_colors[seg] * (1.0 - frac) + self.ramp_colors[seg + 1] * frac

            if self.sky_fog:
                fog_f = np.clip((cw_v - 750.0) / 1850.0, 0.0, 0.85)[:, None]
                col_rgb = col_rgb * (1.0 - fog_f) + fog_col * fog_f

            r8 = (col_rgb[:, 0] * 255.0).astype(np.uint32)
            g8 = (col_rgb[:, 1] * 255.0).astype(np.uint32)
            b8 = (col_rgb[:, 2] * 255.0).astype(np.uint32)
            col32 = 0xFF000000 | (r8 << 16) | (g8 << 8) | b8

            pix_list.append(sy * sw_w + sx)
            cw_list.append(cw_v)
            col_list.append(col32)
            psize_list.append(np.full(cw_v.shape[0], t_psize, dtype=np.float32))

        for t, k in self._drawn:
            is_drone = getattr(t, "is_drone", False)
            if is_drone and not self.drone_visible:
                continue
            t_mode = int(self.drone_color_mode) if is_drone else int(self.color_mode)
            base_psize = float(self.drone_point_size) if is_drone else float(self.point_size)
            spacing_scale = min(2.2, max(1.0, math.sqrt(1.0e6 / max(k, 1)) * 0.55))
            t_psize = base_psize * spacing_scale
            t_rgb_bright = float(self.drone_rgb_brightness) if is_drone else float(self.rgb_brightness)
            ox = float(t.offset[0])
            oy = float(t.offset[1])
            oz = float(t.offset[2] + (self.drone_z_offset if is_drone else 0.0))

            _process_slice(
                t.pos[:k],
                t.cls[:k],
                t.attr[:k, 1],
                t.rgb[:k] if (t.has_rgb and t.rgb is not None) else None,
                ox, oy, oz, t_mode, t_psize, t_rgb_bright,
            )

            if self.interpolate_verticals and t.infill_n > 0:
                k_inf = max(1, int(t.infill_n * (k / max(1, t.n))))
                _process_slice(
                    t.infill_pos[:k_inf],
                    t.infill_attr[:k_inf, 0].astype(np.uint8),
                    t.infill_attr[:k_inf, 1],
                    t.infill_rgb[:k_inf] if (t.infill_has_rgb and t.infill_rgb is not None) else None,
                    ox, oy, oz, t_mode, t_psize, t_rgb_bright,
                )

        if not pix_list:
            return

        all_pix = np.concatenate(pix_list)
        all_cw = np.concatenate(cw_list)
        all_col = np.concatenate(col_list)
        all_ps = np.concatenate(psize_list)

        # Fast SIMD uint16 Radix Sort back-to-front (far points first, near points overwrite)
        q = np.clip((6200.0 - all_cw) * 10.0, 0.0, 65535.0).astype(np.uint16)
        order = np.argsort(q, kind="stable")
        pix = all_pix[order]
        col = all_col[order]
        cw_s = all_cw[order]
        ps_s = all_ps[order]

        buf = self._sw_buf
        buf[pix] = col

        # 2x2 splat for medium/close range or point_size >= 1.1
        m2 = (cw_s < (480.0 * ps_s)) | (ps_s >= 1.25)
        if np.any(m2):
            p2 = pix[m2]
            c2 = col[m2]
            buf[p2 + 1] = c2
            buf[p2 + sw_w] = c2
            buf[p2 + sw_w + 1] = c2

        # 3x3 splat for near range or large point_size
        m3 = (cw_s < (150.0 * ps_s)) | (ps_s >= 2.1)
        if np.any(m3):
            p3 = pix[m3]
            c3 = col[m3]
            w2 = sw_w * 2
            buf[p3 + 2] = c3
            buf[p3 + sw_w + 2] = c3
            buf[p3 + w2] = c3
            buf[p3 + w2 + 1] = c3
            buf[p3 + w2 + 2] = c3

    def _render_signal_mesh_numpy(self, painter: QPainter):
        """Renders 3D RF Signal Coverage Surface Mesh via QPainter polygons when in pure NumPy software mode."""
        res = self.signal_result
        if res is None or not hasattr(res, "grid_zones") or res.grid_zones.size == 0:
            return
        GX, GY, GZ, ZONES = res.grid_xs, res.grid_ys, res.grid_zs, res.grid_zones
        gh, gw = ZONES.shape
        if gh < 2 or gw < 2:
            return

        w, h = float(self.width()), float(self.height())
        mvp = self._mvp.astype(np.float32)
        pts3 = np.stack([GX.ravel(), GY.ravel(), GZ.ravel()], axis=-1).astype(np.float32)
        cw = pts3[:, 0] * mvp[3, 0] + pts3[:, 1] * mvp[3, 1] + pts3[:, 2] * mvp[3, 2] + mvp[3, 3]
        valid = cw > self.NEAR
        inv_w = np.where(valid, 1.0 / np.maximum(cw, 0.1), 0.0)
        cx = (pts3[:, 0] * mvp[0, 0] + pts3[:, 1] * mvp[0, 1] + pts3[:, 2] * mvp[0, 2] + mvp[0, 3]) * inv_w
        cy = (pts3[:, 0] * mvp[1, 0] + pts3[:, 1] * mvp[1, 1] + pts3[:, 2] * mvp[1, 2] + mvp[1, 3]) * inv_w
        sx = ((cx + 1.0) * (0.5 * w)).reshape(gh, gw)
        sy = ((1.0 - cy) * (0.5 * h)).reshape(gh, gw)
        val_grid = valid.reshape(gh, gw)

        zone_qcolors = [
            QColor(34, 197, 94, 105),
            QColor(234, 179, 8, 115),
            QColor(249, 115, 22, 125),
            QColor(239, 68, 68, 145),
        ]
        painter.save()
        painter.setPen(Qt.PenStyle.NoPen)
        step = max(1, max(gh, gw) // 55)
        for r in range(0, gh - step, step):
            r2 = min(gh - 1, r + step)
            for c in range(0, gw - step, step):
                c2 = min(gw - 1, c + step)
                if not (val_grid[r, c] and val_grid[r2, c] and val_grid[r2, c2] and val_grid[r, c2]):
                    continue
                x0, y0 = sx[r, c], sy[r, c]
                x1, y1 = sx[r2, c], sy[r2, c]
                x2, y2 = sx[r2, c2], sy[r2, c2]
                x3, y3 = sx[r, c2], sy[r, c2]
                if max(x0, x1, x2, x3) < 0 or min(x0, x1, x2, x3) > w:
                    continue
                if max(y0, y1, y2, y3) < 0 or min(y0, y1, y2, y3) > h:
                    continue
                z_code = int(np.clip(ZONES[r, c], 0, 3))
                painter.setBrush(QBrush(zone_qcolors[z_code]))
                painter.drawPolygon(
                    QPolygonF([QPointF(x0, y0), QPointF(x1, y1), QPointF(x2, y2), QPointF(x3, y3)])
                )
        painter.restore()

    def _plan_draw(self, budget_override: Optional[int] = None) -> List[Tuple[ViewerTile, int]]:
        mvp = self._mvp
        plan = []
        total = 0
        budget = int(budget_override) if budget_override is not None else int(self.point_budget)
        for t in self.all_visible_tiles():
            ox, oy = t.offset[0], t.offset[1]
            corners = np.array([[ox + dx, oy + dy, z, 1.0]
                                for dx in (0, 1000) for dy in (0, 1000) for z in (t.zmin, t.zmax)])
            clip = corners @ mvp.T
            w = clip[:, 3]
            if np.all(w < self.NEAR):
                continue
            if (np.all(clip[:, 0] < -w) or np.all(clip[:, 0] > w) or
                    np.all(clip[:, 1] < -w) or np.all(clip[:, 1] > w)):
                if np.all(w > 0):
                    continue
            cx, cy = ox + 500.0, oy + 500.0
            d = max(0.0, math.hypot(self.cam[0] - cx, self.cam[1] - cy) - 500.0)
            frac = 1.0 if d < 700.0 else max(0.04, min(1.0, (700.0 / d) ** 2))
            k = int(t.n * frac)
            plan.append([t, k, d])
            total += k
        if total > budget and total > 0:
            s = budget / total
            for p in plan:
                p[1] = max(1000, int(p[1] * s))
        plan.sort(key=lambda p: p[2])
        return [(p[0], min(p[0].n, p[1])) for p in plan]

    def _render_points(self, wpx: int, hpx: int):
        GL = self._gl_mod
        GL.glDepthMask(GL.GL_TRUE)
        GL.glEnable(GL.GL_DEPTH_TEST)
        GL.glDepthFunc(GL.GL_LESS)
        GL.glDisable(GL.GL_BLEND)
        GL.glEnable(0x8642)  # GL_PROGRAM_POINT_SIZE / GL_VERTEX_PROGRAM_POINT_SIZE
        try:
            GL.glEnable(0x8861)  # GL_POINT_SPRITE
            self._round_points = 1
        except Exception:
            self._round_points = 0

        self._drawn = self._plan_draw()
        self.points_drawn = sum(
            k + (int(t.infill_n * (k / max(1, t.n))) if (self.interpolate_verticals and t.infill_n > 0) else 0)
            for t, k in self._drawn
        )
        if not self._drawn:
            GL.glDisable(GL.GL_DEPTH_TEST)
            return

        vis_tiles = self.all_visible_tiles()
        if self.custom_z_range is not None:
            zlo, zhi = self.custom_z_range
        elif vis_tiles:
            zlo = min(t.z_range[0] for t in vis_tiles)
            zhi = max(t.z_range[1] for t in vis_tiles)
        else:
            zlo, zhi = 0.0, 50.0
        loc = self._loc
        GL.glUseProgram(self._prog)
        # Flip clip Y so FBO row 0 is screen top (matches QImage top-down layout with zero copy)
        mvp_gl = self._mvp.astype(np.float32).copy()
        mvp_gl[1, :] *= -1.0
        GL.glUniformMatrix4fv(loc["u_mvp"], 1, GL.GL_TRUE, mvp_gl)
        GL.glUniform3f(loc["u_cam"], *[float(v) for v in self.cam])
        GL.glUniform1i(loc["u_mode"], int(self.color_mode))
        GL.glUniform1f(loc["u_rgb_bright"], float(self.rgb_brightness))
        GL.glUniform1f(loc["u_inten_gamma"], float(self.intensity_gamma))
        GL.glUniform2f(loc["u_zrange"], float(zlo), float(zhi))
        GL.glUniform1f(loc["u_psize"], float(self.point_size))
        GL.glUniform1f(loc["u_pscale"], float(hpx / (2.0 * math.tan(math.radians(self.FOV) / 2.0))))
        GL.glUniform1fv(loc["u_classvis"], 32, self.class_visible)
        GL.glUniform3fv(loc["u_classcol"], 32, self.class_colors)
        GL.glUniform3fv(loc["u_ramp"], 5, self.ramp_colors)
        if self.sky_fog:
            GL.glUniform2f(loc["u_fog"], 750.0, 2600.0)
            if self.sky_procedural or self.sky_panorama:
                GL.glUniform3f(loc["u_fogcol"], 0.74, 0.83, 0.92)
            else:
                GL.glUniform3f(loc["u_fogcol"], 0.24, 0.32, 0.42)
        else:
            GL.glUniform2f(loc["u_fog"], 80000.0, 160000.0)
            GL.glUniform3f(loc["u_fogcol"], 0.24, 0.32, 0.42)
        GL.glUniform1i(loc["u_round"], int(self._round_points))

        GL.glEnableVertexAttribArray(0)
        GL.glEnableVertexAttribArray(1)
        null = ctypes.c_void_p(0)
        cur_mode = int(self.color_mode)
        cur_psize = float(self.point_size)
        cur_rgb_bright = float(self.rgb_brightness)

        for t, k in self._drawn:
            is_drone = getattr(t, "is_drone", False)
            if is_drone and not self.drone_visible:
                continue

            # Switch uniforms between ALS and Drone data on the fly!
            t_mode = int(self.drone_color_mode) if is_drone else int(self.color_mode)
            t_psize = float(self.drone_point_size) if is_drone else float(self.point_size)
            t_rgb_bright = float(self.drone_rgb_brightness) if is_drone else float(self.rgb_brightness)
            t_z_off = float(t.offset[2] + (self.drone_z_offset if is_drone else 0.0))

            if t_mode != cur_mode:
                GL.glUniform1i(loc["u_mode"], t_mode)
                cur_mode = t_mode
            if t_psize != cur_psize:
                GL.glUniform1f(loc["u_psize"], t_psize)
                cur_psize = t_psize
            if t_rgb_bright != cur_rgb_bright:
                GL.glUniform1f(loc["u_rgb_bright"], t_rgb_bright)
                cur_rgb_bright = t_rgb_bright

            if t.vbo_pos is None:
                self._upload(t)
            GL.glUniform3f(loc["u_offset"], float(t.offset[0]), float(t.offset[1]), t_z_off)
            GL.glUniform1f(loc["u_spacing"], float(math.sqrt(1.0e6 / max(k, 1))))
            GL.glUniform1i(loc["u_has_rgb"], 1 if (t.has_rgb and t.vbo_rgb) else 0)
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_pos)
            GL.glVertexAttribPointer(0, 3, GL.GL_FLOAT, GL.GL_FALSE, 0, null)
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_attr)
            GL.glVertexAttribPointer(1, 2, GL.GL_FLOAT, GL.GL_FALSE, 0, null)
            if t.has_rgb and t.vbo_rgb:
                GL.glEnableVertexAttribArray(2)
                GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_rgb)
                GL.glVertexAttribPointer(2, 3, GL.GL_UNSIGNED_BYTE, GL.GL_TRUE, 0, null)
            else:
                GL.glDisableVertexAttribArray(2)
                GL.glVertexAttrib4f(2, 0.62, 0.62, 0.62, 1.0)
            GL.glDrawArrays(GL.GL_POINTS, 0, int(k))

            # Draw Vertical Wall & Surface Void Infill if enabled
            if self.interpolate_verticals and t.infill_n > 0 and t.vbo_infill_pos:
                k_infill = max(1, int(t.infill_n * (k / max(1, t.n))))
                GL.glUniform1i(loc["u_has_rgb"], 1 if (t.infill_has_rgb and t.vbo_infill_rgb) else 0)
                GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_infill_pos)
                GL.glVertexAttribPointer(0, 3, GL.GL_FLOAT, GL.GL_FALSE, 0, null)
                GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_infill_attr)
                GL.glVertexAttribPointer(1, 2, GL.GL_FLOAT, GL.GL_FALSE, 0, null)
                if t.infill_has_rgb and t.vbo_infill_rgb:
                    GL.glEnableVertexAttribArray(2)
                    GL.glBindBuffer(GL.GL_ARRAY_BUFFER, t.vbo_infill_rgb)
                    GL.glVertexAttribPointer(2, 3, GL.GL_UNSIGNED_BYTE, GL.GL_TRUE, 0, null)
                else:
                    GL.glDisableVertexAttribArray(2)
                    GL.glVertexAttrib4f(2, 0.62, 0.62, 0.62, 1.0)
                GL.glDrawArrays(GL.GL_POINTS, 0, int(k_infill))

        GL.glDisableVertexAttribArray(0)
        GL.glDisableVertexAttribArray(1)
        GL.glDisableVertexAttribArray(2)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        GL.glUseProgram(0)
        try:
            GL.glDisable(0x8861)
            GL.glDisable(0x8642)
        except Exception:
            pass
        GL.glDisable(GL.GL_DEPTH_TEST)
        GL.glDepthMask(GL.GL_FALSE)
        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

    def _render_signal_mesh_gl(self):
        """Renders 3D RF Signal Coverage Surface Mesh as semi-transparent colored triangles."""
        if not self.show_signal_3d or self._signal_mesh_count == 0 or self._signal_mesh_pts is None:
            return
        GL = self._gl_mod
        if GL is None:
            return
        if not self._signal_prog:
            try:
                self._signal_prog = self._build_color_program()
            except Exception:
                return

        if self._signal_mesh_dirty:
            if self._signal_vbo_pos:
                try:
                    GL.glDeleteBuffers(1, [self._signal_vbo_pos])
                except Exception:
                    pass
            if self._signal_vbo_col:
                try:
                    GL.glDeleteBuffers(1, [self._signal_vbo_col])
                except Exception:
                    pass

            self._signal_vbo_pos = int(GL.glGenBuffers(1))
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self._signal_vbo_pos)
            GL.glBufferData(GL.GL_ARRAY_BUFFER, self._signal_mesh_pts.nbytes, self._signal_mesh_pts, GL.GL_DYNAMIC_DRAW)

            self._signal_vbo_col = int(GL.glGenBuffers(1))
            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self._signal_vbo_col)
            GL.glBufferData(GL.GL_ARRAY_BUFFER, self._signal_mesh_cols.nbytes, self._signal_mesh_cols, GL.GL_DYNAMIC_DRAW)

            GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
            self._signal_mesh_dirty = False

        if not self._signal_vbo_pos or not self._signal_vbo_col:
            return

        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFuncSeparate(
            GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA,
            GL.GL_ONE, GL.GL_ONE_MINUS_SRC_ALPHA,
        )
        GL.glEnable(GL.GL_DEPTH_TEST)
        GL.glDepthMask(GL.GL_FALSE)

        GL.glUseProgram(self._signal_prog)
        loc_mvp = GL.glGetUniformLocation(self._signal_prog, "u_mvp")
        mvp_gl = self._mvp.astype(np.float32).copy()
        mvp_gl[1, :] *= -1.0
        GL.glUniformMatrix4fv(loc_mvp, 1, GL.GL_TRUE, mvp_gl)

        GL.glEnableVertexAttribArray(0)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self._signal_vbo_pos)
        GL.glVertexAttribPointer(0, 3, GL.GL_FLOAT, GL.GL_FALSE, 0, None)

        GL.glEnableVertexAttribArray(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self._signal_vbo_col)
        GL.glVertexAttribPointer(1, 4, GL.GL_FLOAT, GL.GL_FALSE, 0, None)

        GL.glDrawArrays(GL.GL_TRIANGLES, 0, int(self._signal_mesh_count))

        GL.glDisableVertexAttribArray(0)
        GL.glDisableVertexAttribArray(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, 0)
        GL.glUseProgram(0)
        GL.glDisable(GL.GL_DEPTH_TEST)
        GL.glDepthMask(GL.GL_FALSE)
        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

    def set_signal_result(self, res):
        """Builds 3D OpenGL triangle mesh vertices and RGBA colors from computed RF coverage grid."""
        if res is None or not hasattr(res, "grid_zones") or res.grid_zones.size == 0:
            self.signal_result = None
            self._signal_mesh_pts = None
            self._signal_mesh_cols = None
            self._signal_mesh_count = 0
            self._signal_mesh_dirty = True
            self.update()
            return

        self.signal_result = res
        GX = res.grid_xs
        GY = res.grid_ys
        GZ = res.grid_zs
        ZONES = res.grid_zones
        h, w = ZONES.shape
        if h < 2 or w < 2:
            return

        # Build 2 triangles (6 vertices) for each quad cell
        pts_00 = np.stack([GX[:-1, :-1], GY[:-1, :-1], GZ[:-1, :-1]], axis=-1)
        pts_10 = np.stack([GX[1:, :-1], GY[1:, :-1], GZ[1:, :-1]], axis=-1)
        pts_11 = np.stack([GX[1:, 1:], GY[1:, 1:], GZ[1:, 1:]], axis=-1)
        pts_01 = np.stack([GX[:-1, 1:], GY[:-1, 1:], GZ[:-1, 1:]], axis=-1)

        # Quads to 2 triangles: (v00, v10, v11) and (v00, v11, v01)
        tri_pts = np.stack([pts_00, pts_10, pts_11, pts_00, pts_11, pts_01], axis=2)
        tri_pts = tri_pts.reshape(-1, 3).astype(np.float32)

        # RGBA normalized colors:
        # Strong: Neon Emerald Green (0.133, 0.773, 0.369, 0.42)
        # Fair: Bright Amber (0.918, 0.702, 0.031, 0.45)
        # Marginal: Vivid Orange (0.976, 0.451, 0.086, 0.50)
        # Shadow: Crimson Red (0.937, 0.267, 0.267, 0.60)
        zone_cols_arr = np.array([
            [0.133, 0.773, 0.369, 0.42],
            [0.918, 0.702, 0.031, 0.45],
            [0.976, 0.451, 0.086, 0.50],
            [0.937, 0.267, 0.267, 0.60],
        ], dtype=np.float32)

        quad_zones = ZONES[:-1, :-1].ravel()
        quad_cols = zone_cols_arr[np.clip(quad_zones, 0, 3)]
        tri_cols = np.repeat(quad_cols, 6, axis=0).astype(np.float32)

        self._signal_mesh_pts = tri_pts
        self._signal_mesh_cols = tri_cols
        self._signal_mesh_count = len(tri_pts)
        self._signal_mesh_dirty = True
        self.update()

    def set_live_signal_state(self, signal_pct: float, zone_code: int, status_txt: str, is_occluded: bool, dist_m: float, drone_key: str = "mavic_3e"):
        """Updates live RC link state from DroneSignalDialog for 3D laser beam and HUD badge."""
        self.live_signal_pct = float(signal_pct)
        self.live_signal_zone = int(zone_code)
        self.live_signal_status = str(status_txt)
        self.live_signal_occluded = bool(is_occluded)
        self.live_signal_dist = float(dist_m)
        self.live_drone_key = str(drone_key)
        self.update()

    # ------------------------------------------------------------------ #
    # Projection helpers for HUD
    # ------------------------------------------------------------------ #
    def _clip(self, p) -> np.ndarray:
        return self._mvp @ np.array([p[0], p[1], p[2], 1.0])

    def _clip_to_screen(self, c) -> QPointF:
        x = (c[0] / c[3] * 0.5 + 0.5) * self.width()
        y = (1.0 - (c[1] / c[3] * 0.5 + 0.5)) * self.height()
        return QPointF(x, y)

    def project(self, p) -> Optional[QPointF]:
        c = self._clip(p)
        if c[3] < self.NEAR:
            return None
        return self._clip_to_screen(c)

    def project_segment(self, a, b) -> Optional[Tuple[QPointF, QPointF]]:
        ca, cb = self._clip(a), self._clip(b)
        eps = self.NEAR
        if ca[3] < eps and cb[3] < eps:
            return None
        if ca[3] < eps:
            t = (eps - ca[3]) / (cb[3] - ca[3])
            ca = ca + (cb - ca) * t
        elif cb[3] < eps:
            t = (eps - cb[3]) / (ca[3] - cb[3])
            cb = cb + (ca - cb) * t
        return self._clip_to_screen(ca), self._clip_to_screen(cb)

    # ------------------------------------------------------------------ #
    # Picking
    # ------------------------------------------------------------------ #
    def pick(self, mx: float, my: float, radius: float = 7.0) -> Optional[Tuple[float, float, float]]:
        if not self._drawn:
            return None
        mvp = self._mvp
        W, H = self.width(), self.height()
        best = None
        best_w = float("inf")
        m32 = mvp.astype(np.float32)
        for t, k in self._drawn:
            p = t.pos[:k]
            o = mvp[:, :3] @ t.offset + mvp[:, 3]
            cw = p @ m32[3, :3] + np.float32(o[3])
            cx = p @ m32[0, :3] + np.float32(o[0])
            cy = p @ m32[1, :3] + np.float32(o[1])
            with np.errstate(divide="ignore", invalid="ignore"):
                sx = (cx / cw * 0.5 + 0.5) * W
                sy = (1.0 - (cy / cw * 0.5 + 0.5)) * H
            sel = (cw > self.NEAR) & (np.abs(sx - mx) < radius) & (np.abs(sy - my) < radius)
            if not sel.any():
                continue
            idx = np.nonzero(sel)[0]
            idx = idx[self.class_visible[t.cls[idx]] > 0.5]
            if idx.size == 0:
                continue
            j = idx[np.argmin(cw[idx])]
            if cw[j] < best_w:
                best_w = float(cw[j])
                best = (float(p[j, 0] + t.offset[0]), float(p[j, 1] + t.offset[1]), float(p[j, 2]))
        return best

    # ------------------------------------------------------------------ #
    # Simulation loop
    # ------------------------------------------------------------------ #
    def showEvent(self, e):
        super().showEvent(e)
        self._last_tick = time.perf_counter()
        self.timer.start()

    def hideEvent(self, e):
        super().hideEvent(e)
        self.timer.stop()
        self.keys.clear()

    def _tick(self):
        now = time.perf_counter()
        dt = min(0.1, now - self._last_tick)
        self._last_tick = now

        k = self.keys
        moved = False
        # Keyboard gimbal
        rot = 70.0 * dt
        if K.Key_Left in k:
            self.yaw = (self.yaw - rot) % 360.0
            moved = True
        if K.Key_Right in k:
            self.yaw = (self.yaw + rot) % 360.0
            moved = True
        if K.Key_Up in k:
            self.pitch = min(89.0, self.pitch + rot)
            moved = True
        if K.Key_Down in k:
            self.pitch = max(-89.0, self.pitch - rot)
            moved = True

        yr = math.radians(self.yaw)
        fwd = np.array([math.sin(yr), math.cos(yr), 0.0])
        right = np.array([math.cos(yr), -math.sin(yr), 0.0])
        d = np.zeros(3)
        if K.Key_W in k:
            d += fwd
        if K.Key_S in k:
            d -= fwd
        if K.Key_D in k:
            d += right
        if K.Key_A in k:
            d -= right
        if K.Key_Space in k or K.Key_E in k:
            d[2] += 1.0
        if K.Key_Control in k or K.Key_Q in k:
            d[2] -= 1.0
        speed = self.base_speed * (self.turbo if K.Key_Shift in k else 1.0)
        n = np.linalg.norm(d)
        target = d / n * speed if n > 0 else np.zeros(3)
        self.vel += (target - self.vel) * min(1.0, dt * 5.0)
        if np.linalg.norm(self.vel) < 0.02 and n == 0:
            self.vel[:] = 0

        step = self.vel * dt
        if np.any(step != 0):
            self.cam += step
            moved = True
            hstep = math.hypot(step[0], step[1])
            self.flown += math.sqrt(hstep * hstep + step[2] * step[2])
            self.flight_time += dt

        # Terrain clearance
        g = self.ground_at(self.cam[0], self.cam[1])
        if self._pending_agl is not None and g is not None:
            self.cam[2] = g + self._pending_agl
            self._pending_agl = None
            moved = True
        if self.ground_follow and g is not None and self.cam[2] < g + 1.8:
            self.cam[2] = g + 1.8
            self.vel[2] = max(0.0, self.vel[2])

        # Trail / telemetry log
        if moved:
            if self._last_trail_pos is None or np.linalg.norm(self.cam - self._last_trail_pos) > 3.0 or \
                    now - self._last_trail_t > 1.0:
                X, Y = self.to_abs(self.cam[0], self.cam[1])
                agl = (self.cam[2] - g) if g is not None else float("nan")
                is_jump = bool(getattr(self, "_jump_pending", False))
                if not is_jump and self._last_trail_pos is not None:
                    if np.linalg.norm(self.cam[:2] - self._last_trail_pos[:2]) > 40.0:
                        is_jump = True
                self._jump_pending = False
                self.trail.append((time.time(), X, Y, float(self.cam[2]), agl, float(np.linalg.norm(self.vel)), is_jump))
                if len(self.trail) > 20000:
                    self.trail = self.trail[-20000:]
                self._last_trail_pos = self.cam.copy()
                self._last_trail_t = now
            self._update_active_tile()
            self._emit_camera_moved()

        if now - self._last_stream_check > 0.4:
            self._last_stream_check = now
            self._check_streaming()

        if moved or self._dirty or self._drag_btn is not None or now - self._last_paint > 0.5:
            self.update()

    def _update_active_tile(self, force: bool = False):
        if self.scene_origin is None:
            return
        X, Y = self.to_abs(self.cam[0], self.cam[1])
        tid = GridEngine.point_to_tile(X, Y)
        if tid != self.active_tile or force:
            self.active_tile = tid
            self.active_tile_changed.emit(tid)

    def _check_streaming(self):
        if not self.auto_stream or self.scene_origin is None or not self.isVisible():
            return
        X, Y = self.to_abs(self.cam[0], self.cam[1])
        yr = math.radians(self.yaw)
        hspeed = math.hypot(self.vel[0], self.vel[1])
        look = min(700.0, 250.0 + hspeed * 8.0)
        cands = [GridEngine.point_to_tile(X, Y),
                 GridEngine.point_to_tile(X + math.sin(yr) * look, Y + math.cos(yr) * look)]
        if hspeed > 0.5:
            vx, vy = self.vel[0] / hspeed, self.vel[1] / hspeed
            cands.append(GridEngine.point_to_tile(X + vx * look, Y + vy * look))
        cur = GridEngine.tile_to_rect(cands[0])
        if cur is not None:
            margin = 220.0
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    if dx == 0 and dy == 0:
                        continue
                    nx = min(max(X, cur.xMinimum() + dx * 1000.0), cur.xMaximum() + dx * 1000.0)
                    ny = min(max(Y, cur.yMinimum() + dy * 1000.0), cur.yMaximum() + dy * 1000.0)
                    if math.hypot(nx - X, ny - Y) < margin:
                        cands.append(GridEngine.point_to_tile(X + dx * margin, Y + dy * margin))
        for t in dict.fromkeys(cands):
            if GridEngine.is_valid_tile(t) and t not in self.tile_states:
                self.tile_states[t] = STATE_QUEUED
                self.tile_requested.emit(t)

    def _enforce_tile_limit(self):
        if len(self.tiles) <= self.max_tiles:
            return
        def dist(t):
            return math.hypot(self.cam[0] - (t.offset[0] + 500), self.cam[1] - (t.offset[1] + 500))
        for t in sorted(self.tiles.values(), key=dist, reverse=True):
            if len(self.tiles) <= self.max_tiles:
                break
            if dist(t) > 1800:
                self.remove_tile(t.tile_id)

    # ------------------------------------------------------------------ #
    # Input
    # ------------------------------------------------------------------ #
    def event(self, e):
        if e.type() == QEvent.Type.ShortcutOverride:
            if e.key() in FLIGHT_KEYS or e.key() in COMMAND_KEYS:
                e.accept()
                return True
        return super().event(e)

    def keyPressEvent(self, e):
        key = e.key()
        if e.isAutoRepeat() and key in FLIGHT_KEYS:
            return
        if key in FLIGHT_KEYS:
            self.keys.add(key)
            return
        if key == K.Key_H:
            self.show_help = not self.show_help
        elif key == K.Key_M:
            order = [M.MODE_NONE, M.MODE_DISTANCE, M.MODE_AREA, M.MODE_VOLUME]
            self.set_measure_mode(order[(order.index(self.measure_mode) + 1) % len(order)])
        elif key == K.Key_I:
            self.set_info_mode(not self.info_mode)
        elif key in (K.Key_C, K.Key_Escape):
            if self.selected_feature is not None:
                self.clear_feature_selection()
            elif self.info_mode:
                self.set_info_mode(False)
            elif self.measure_mode != M.MODE_NONE:
                self.clear_measure()
        elif key == K.Key_Backspace:
            if self.measure_pts:
                self.measure_pts.pop()
                self.measure_closed = False
                self._recompute_measure()
        elif key in (K.Key_Return, K.Key_Enter):
            self.measure_closed = True
        elif key == K.Key_R:
            self.reset_view()
        elif key == K.Key_G:
            self.ground_follow = not self.ground_follow
        elif key == K.Key_Plus:
            self.set_point_size(self.point_size * 1.2)
        elif key == K.Key_Minus:
            self.set_point_size(self.point_size / 1.2)
        elif key == K.Key_P:
            self.set_photo_mode(not self.photo_mode)
        elif key == K.Key_U and self.photo_mode:
            self.set_photo_ui(not self.photo_include_ui)
        elif key in (K.Key_Space, K.Key_Return, K.Key_Enter) and self.photo_mode and self.measure_mode == M.MODE_NONE:
            self.take_photo_shot()
        else:
            super().keyPressEvent(e)
            return
        self._dirty = True
        self.update()

    def keyReleaseEvent(self, e):
        if e.isAutoRepeat():
            return
        self.keys.discard(e.key())

    def focusOutEvent(self, e):
        self.keys.clear()
        super().focusOutEvent(e)

    def _minimap_rect(self) -> QRectF:
        s = 228.0
        return QRectF(self.width() - s - 14, self.height() - s - 14, s, s)

    def mousePressEvent(self, e):
        self.setFocus()
        pos = e.position()
        mm = self._minimap_rect()
        if mm.contains(pos) and e.button() == Qt.MouseButton.LeftButton:
            # 1. Minimap zoom in / out buttons
            if self._mm_btn_zoom_in.contains(pos):
                self.zoom_minimap(0.75)
                return
            if self._mm_btn_zoom_out.contains(pos):
                self.zoom_minimap(1.33)
                return
            # 2. Minimap base layer selector pills (Foto / Põhi / Hübriid / Võrk)
            for m_key, m_rect in self._mm_mode_rects.items():
                if m_rect.contains(pos):
                    self.set_minimap_base_mode(m_key)
                    return
            # 3. Teleport via minimap map area
            if self.scene_origin is not None:
                scale = self._minimap_scale()
                dx = (pos.x() - mm.center().x()) * scale
                dy = -(pos.y() - mm.center().y()) * scale
                self.cam[0] += dx
                self.cam[1] += dy
                g = self.ground_at(self.cam[0], self.cam[1])
                if g is not None:
                    self.cam[2] = max(self.cam[2], g + 30.0)
                self._last_trail_pos = None
                self._jump_pending = True
                self._update_active_tile()
                self._emit_camera_moved()
                self._dirty = True
                self.update()
            return
        self._press_pos = pos
        self._last_mouse = pos
        self._drag_btn = e.button()

    def mouseMoveEvent(self, e):
        pos = e.position()
        self.cursor_pos = pos
        if self._drag_btn is not None and self._last_mouse is not None:
            look_btn = (self._drag_btn == Qt.MouseButton.RightButton or
                        self._drag_btn == Qt.MouseButton.MiddleButton or
                        (self._drag_btn == Qt.MouseButton.LeftButton and self.measure_mode == M.MODE_NONE and not self.info_mode and not self.homepoint_pick_mode))
            if look_btn:
                dx = pos.x() - self._last_mouse.x()
                dy = pos.y() - self._last_mouse.y()
                self.yaw = (self.yaw + dx * self.mouse_sens) % 360.0
                self.pitch = max(-89.0, min(89.0, self.pitch - dy * self.mouse_sens))
                self._emit_camera_moved()
            self._last_mouse = pos
        if self.measure_mode != M.MODE_NONE and self.measure_pts and not self.measure_closed:
            self._dirty = True
        if self._drag_btn is not None or self._dirty:
            self.update()

    def mouseReleaseEvent(self, e):
        pos = e.position()
        clicked = self._press_pos is not None and \
            (abs(pos.x() - self._press_pos.x()) + abs(pos.y() - self._press_pos.y())) < 6
        if clicked and e.button() == Qt.MouseButton.LeftButton:
            if self.homepoint_pick_mode:
                p = self.pick(pos.x(), pos.y())
                if p is not None:
                    lx, ly = float(p[0]), float(p[1])
                    g = self.ground_at(lx, ly)
                    gz = float(g) if g is not None else float(p[2])
                else:
                    lx, ly = float(self.cam[0]), float(self.cam[1])
                    g = self.ground_at(lx, ly)
                    gz = float(g) if g is not None else 0.0

                ox = float(self.scene_origin[0]) if self.scene_origin is not None else 0.0
                oy = float(self.scene_origin[1]) if self.scene_origin is not None else 0.0
                x_abs = lx + ox
                y_abs = ly + oy

                self.set_homepoint(x_abs, y_abs, gz)
                self.homepoint_picked.emit(x_abs, y_abs, gz)
                self.set_homepoint_pick_mode(False)
                self._drag_btn = None
                self._last_mouse = None
                self._press_pos = None
                self._dirty = True
                self.update()
                return
            elif self.info_mode:
                hit = self._hit_test_canvas_feature(pos.x(), pos.y())
                if hit is not None:
                    self.selected_feature = hit
                    self.feature_selected.emit(hit, pos.x(), pos.y())
                    self._dirty = True
                    self.update()
                else:
                    self.clear_feature_selection()
            elif self.photo_mode and self.measure_mode == M.MODE_NONE:
                self.take_photo_shot()
            elif self.measure_mode != M.MODE_NONE:
                if self.measure_closed:
                    self.measure_pts = []
                    self.measure_closed = False
                p = self.pick(pos.x(), pos.y())
                if p is None:
                    self.status_message.emit(tr("v3d_pick_failed"))
                else:
                    self.measure_pts.append(p)
                    self._recompute_measure()
        self._drag_btn = None
        self._last_mouse = None
        self._press_pos = None
        self._dirty = True
        self.update()

    def mouseDoubleClickEvent(self, e):
        if self.measure_mode != M.MODE_NONE and len(self.measure_pts) >= 2:
            self.measure_closed = True
            self._dirty = True
            self.update()

    def wheelEvent(self, e):
        steps = e.angleDelta().y() / 120.0
        if steps == 0:
            return
        # If hovering over the minimap, zoom the minimap instead of changing cruise speed
        if self._minimap_rect().contains(e.position()):
            self.zoom_minimap(0.80 ** steps)
            e.accept()
            return
        self.base_speed = max(0.5, min(400.0, self.base_speed * (1.18 ** steps)))
        self._dirty = True
        self.update()

    # ------------------------------------------------------------------ #
    # Measurement
    # ------------------------------------------------------------------ #
    def _recompute_measure(self):
        pts = self.measure_pts
        res = {"mode": self.measure_mode, "count": len(pts)}
        if self.measure_mode == M.MODE_DISTANCE:
            res.update(M.polyline_stats(pts))
        elif self.measure_mode == M.MODE_AREA and len(pts) >= 3:
            res["area"] = M.polygon_area_2d(pts)
            res["perimeter"] = M.polygon_perimeter(pts)
            res["perimeter_3d"] = M.polygon_perimeter(pts, three_d=True)
        elif self.measure_mode == M.MODE_VOLUME and len(pts) >= 3:
            tiles = [(t.pos, t.cls, t.offset) for t in self.tiles.values()]
            res.update(M.volume_stats(pts, tiles))
        self.measure_result = res
        self.measurement_changed.emit(res)
        self._dirty = True
        self.update()

    # ------------------------------------------------------------------ #
    # HUD
    # ------------------------------------------------------------------ #
    def _card(self, p: QPainter, rect: QRectF, accent=QColor(56, 189, 248, 170)):
        p.setPen(QPen(accent, 1.2))
        p.setBrush(QBrush(QColor(10, 18, 34, 205)))
        p.drawRoundedRect(rect, 8, 8)

    def _draw_hud(self, p: QPainter):
        w, h = self.width(), self.height()
        if self._gl_failed:
            p.setPen(QColor(255, 120, 120))
            p.setFont(QFont("Segoe UI", 10))
            p.drawText(QRectF(20, 20, w - 40, 60), Qt.AlignmentFlag.AlignLeft,
                       f"OpenGL viga: {self._gl_failed[:200]}")

        self._draw_canvas_layers_overlay(p)
        self._draw_3d_photo_waypoints(p)
        self._draw_measure_overlay(p)
        self._draw_3d_homepoint_and_beam(p)

        # Camera shutter flash on photo capture
        flash_a = getattr(self, "_photo_flash_alpha", 0)
        if flash_a > 0:
            p.fillRect(0, 0, w, h, QColor(255, 255, 255, flash_a))
            self._photo_flash_alpha = max(0, flash_a - 45)
            QTimer.singleShot(25, self.update)

        # In photo mode with UI off, omit all cockpit cards, minimap, crosshair, and telemetry
        if getattr(self, "_hide_hud_for_capture", False):
            return

        # Temporary toast banner for photo feedback
        if self._photo_banner_text and time.time() < self._photo_banner_expiry:
            self._draw_photo_toast(p, w, h)
            QTimer.singleShot(80, self.update)

        # If in photo mode and photo_include_ui is False, hide cockpit cards but still show viewfinder reticle & status badge
        if self.photo_mode and not self.photo_include_ui:
            self._draw_photo_viewfinder(p, w, h)
            if self.info_mode:
                self._draw_info_mode_badge(p, w, h)
            return

        # Crosshair
        p.setPen(QPen(QColor(255, 255, 255, 120), 1))
        cx, cy = w / 2.0, h / 2.0
        p.drawLine(QPointF(cx - 9, cy), QPointF(cx - 3, cy))
        p.drawLine(QPointF(cx + 3, cy), QPointF(cx + 9, cy))
        p.drawLine(QPointF(cx, cy - 9), QPointF(cx, cy - 3))
        p.drawLine(QPointF(cx, cy + 3), QPointF(cx, cy + 9))

        self._draw_data_card(p)
        self._draw_compass(p, w)

        # Photo mode framing reticle and top status badge (drawn below compass to prevent overlap)
        if self.photo_mode:
            self._draw_photo_viewfinder(p, w, h)

        # Info mode status pill & feature highlight
        if self.info_mode:
            self._draw_info_mode_badge(p, w, h)
        if self.selected_feature is not None:
            self._draw_selected_feature_highlight(p, w, h)

        if self.show_help:
            self._draw_help(p, w)
        self._draw_telemetry(p, h)
        self._draw_minimap(p)
        if self.measure_mode != M.MODE_NONE:
            self._draw_measure_card(p, w, h)

        pend = self.pending_count()
        is_loading = pend > 0 or (0 < self.loading_percent < 100)
        if is_loading:
            self._draw_bottom_loading_bar(p, w, h, pend)
        elif not self.tiles and not self.extra_layers:
            p.setPen(QColor(226, 232, 240))
            p.setFont(QFont("Segoe UI", 11))
            p.drawText(QRectF(0, h / 2 - 40, w, 80), Qt.AlignmentFlag.AlignCenter, tr("v3d_empty"))

    def _draw_photo_viewfinder(self, p: QPainter, w: int, h: int):
        """Renders drone camera corner framing brackets and top status badge."""
        p.save()
        # 1. Corner brackets [  ] offset by 28px from viewport edges
        m_x = max(24.0, w * 0.04)
        m_y = max(24.0, h * 0.05)
        arm = 28.0

        p.setPen(QPen(QColor(245, 158, 11, 210), 2.0))
        p.setBrush(Qt.BrushStyle.NoBrush)

        # Top-Left
        p.drawLine(QPointF(m_x, m_y), QPointF(m_x + arm, m_y))
        p.drawLine(QPointF(m_x, m_y), QPointF(m_x, m_y + arm))
        # Top-Right
        p.drawLine(QPointF(w - m_x, m_y), QPointF(w - m_x - arm, m_y))
        p.drawLine(QPointF(w - m_x, m_y), QPointF(w - m_x, m_y + arm))
        # Bottom-Left
        p.drawLine(QPointF(m_x, h - m_y), QPointF(m_x + arm, h - m_y))
        p.drawLine(QPointF(m_x, h - m_y), QPointF(m_x, h - m_y - arm))
        # Bottom-Right
        p.drawLine(QPointF(w - m_x, h - m_y), QPointF(w - m_x - arm, h - m_y))
        p.drawLine(QPointF(w - m_x, h - m_y), QPointF(w - m_x, h - m_y - arm))

        # 2. Subtle center camera autofocus brackets (40x40)
        cx, cy = w / 2.0, h / 2.0
        c_arm = 8.0
        box_half = 20.0
        bx0, bx1 = cx - box_half, cx + box_half
        by0, by1 = cy - box_half, cy + box_half

        p.setPen(QPen(QColor(255, 255, 255, 160), 1.2))
        p.drawLine(QPointF(bx0, by0), QPointF(bx0 + c_arm, by0))
        p.drawLine(QPointF(bx0, by0), QPointF(bx0, by0 + c_arm))
        p.drawLine(QPointF(bx1, by0), QPointF(bx1 - c_arm, by0))
        p.drawLine(QPointF(bx1, by0), QPointF(bx1, by0 + c_arm))
        p.drawLine(QPointF(bx0, by1), QPointF(bx0 + c_arm, by1))
        p.drawLine(QPointF(bx0, by1), QPointF(bx0, by1 - c_arm))
        p.drawLine(QPointF(bx1, by1), QPointF(bx1 - c_arm, by1))
        p.drawLine(QPointF(bx1, by1), QPointF(bx1, by1 - c_arm))

        # 3. Top Mode Pill (placed below compass if UI is visible, or at top if UI is off)
        ui_state_str = "SEES" if self.photo_include_ui else "VÄLJAS"
        pill_txt = f"📸 FOTOREŽIIM: {len(self.session_photos)} fotot | [Klõps/Space]: pildista | [U]: UI ({ui_state_str}) | [P]: välju"

        p.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        fm = p.fontMetrics()
        pill_w = fm.horizontalAdvance(pill_txt) + 28
        pill_h = 26
        top_y = 82.0 if self.photo_include_ui else 16.0
        pill_rect = QRectF((w - pill_w) / 2.0, top_y, pill_w, pill_h)

        p.setPen(QPen(QColor(245, 158, 11, 230), 1.2))
        p.setBrush(QBrush(QColor(15, 23, 42, 220)))
        p.drawRoundedRect(pill_rect, 13, 13)

        p.setPen(QColor(254, 243, 199))
        p.drawText(pill_rect, Qt.AlignmentFlag.AlignCenter, pill_txt)
        p.restore()

    def _draw_info_mode_badge(self, p: QPainter, w: int, h: int):
        """Draws top status badge for Info Mode."""
        p.save()
        pill_txt = "ℹ️ INFOREŽIIM: Klõpsa 2D objektil info vaatamiseks  |  [I / Esc]: välju"
        p.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        fm = p.fontMetrics()
        pill_w = fm.horizontalAdvance(pill_txt) + 28
        pill_h = 26
        if self.photo_include_ui:
            top_y = 114.0 if self.photo_mode else 82.0
        else:
            top_y = 48.0 if self.photo_mode else 16.0
        pill_rect = QRectF((w - pill_w) / 2.0, top_y, pill_w, pill_h)

        p.setPen(QPen(QColor(56, 189, 248, 230), 1.2))
        p.setBrush(QBrush(QColor(15, 23, 42, 225)))
        p.drawRoundedRect(pill_rect, 13, 13)

        p.setPen(QColor(224, 242, 254))
        p.drawText(pill_rect, Qt.AlignmentFlag.AlignCenter, pill_txt)
        p.restore()

    def _draw_selected_feature_highlight(self, p: QPainter, w: int, h: int):
        """Draws neon cyan/sky highlight glow around selected 2D feature and dashed leader line to popup."""
        feat = self.selected_feature
        if not feat:
            return

        p.save()
        width = float(feat.get("width", 2.2))
        pen_glow = QPen(QColor(56, 189, 248, 215), width + 4.5)
        pen_core = QPen(QColor(255, 255, 255, 255), max(1.8, width + 1.2))
        mvp_t = self._mvp.T

        # 0. Highlight Polygon interior with semi-transparent cyan fill
        if feat.get("is_polygon"):
            for l3 in feat.get("lines3", []):
                n_pts = len(l3)
                if n_pts >= 3:
                    h_coords = np.hstack([l3, np.ones((n_pts, 1), dtype=np.float64)])
                    clip = h_coords @ mvp_t
                    cw = clip[:, 3]
                    in_front = cw >= self.NEAR
                    if np.sum(in_front) >= 3:
                        w_safe = np.maximum(cw, 1e-4)
                        sx = (clip[:, 0] / w_safe * 0.5 + 0.5) * float(w)
                        sy = (-clip[:, 1] / w_safe * 0.5 + 0.5) * float(h)
                        poly_pts = [QPointF(sx[i], sy[i]) for i in range(n_pts) if in_front[i]]
                        if len(poly_pts) >= 3:
                            p.setPen(Qt.PenStyle.NoPen)
                            p.setBrush(QBrush(QColor(56, 189, 248, 65)))
                            p.drawPolygon(QPolygonF(poly_pts))

        # 1. Highlight Lines
        for l3 in feat.get("lines3", []):
            n_pts = len(l3)
            if n_pts < 2:
                continue
            h_coords = np.hstack([l3, np.ones((n_pts, 1), dtype=np.float64)])
            clip = h_coords @ mvp_t
            cw = clip[:, 3]
            in_front = cw >= self.NEAR
            if not np.any(in_front):
                continue
            w_safe = np.maximum(cw, 1e-4)
            sx = (clip[:, 0] / w_safe * 0.5 + 0.5) * float(w)
            sy = (-clip[:, 1] / w_safe * 0.5 + 0.5) * float(h)

            curr_pts = []
            for i in range(n_pts):
                if in_front[i]:
                    curr_pts.append(QPointF(sx[i], sy[i]))
                else:
                    if len(curr_pts) >= 2:
                        poly = QPolygonF(curr_pts)
                        p.setPen(pen_glow)
                        p.drawPolyline(poly)
                        p.setPen(pen_core)
                        p.drawPolyline(poly)
                    curr_pts = []
            if len(curr_pts) >= 2:
                poly = QPolygonF(curr_pts)
                p.setPen(pen_glow)
                p.drawPolyline(poly)
                p.setPen(pen_core)
                p.drawPolyline(poly)

        # 2. Highlight Points
        for pt3 in feat.get("pts3", []):
            sp = self.project(pt3)
            if sp is not None:
                p.setPen(QPen(QColor(56, 189, 248, 230), 2.5))
                p.setBrush(QBrush(QColor(15, 23, 42, 180)))
                p.drawEllipse(sp, 8.5, 8.5)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(255, 255, 255)))
                p.drawEllipse(sp, 4.0, 4.0)

        # 3. Leader Line to Info Pop-up
        c3 = feat.get("centroid3")
        if c3 is not None:
            anchor_sp = self.project(c3)
            if anchor_sp is not None and (-20 < anchor_sp.x() < w + 20) and (-20 < anchor_sp.y() < h + 20):
                # Anchor dot on ground
                p.setPen(QPen(QColor(56, 189, 248, 240), 2.0))
                p.setBrush(QBrush(QColor(15, 23, 42, 220)))
                p.drawEllipse(anchor_sp, 6.0, 6.0)
                p.setBrush(QBrush(QColor(255, 255, 255)))
                p.drawEllipse(anchor_sp, 2.5, 2.5)

                # Check if popup is visible
                popup = getattr(self, "info_popup", None)
                if popup and popup.isVisible():
                    p_rect = popup.geometry()
                    # Find point on popup closest to anchor_sp
                    tx = max(float(p_rect.left()), min(float(p_rect.right()), anchor_sp.x()))
                    ty = max(float(p_rect.top()), min(float(p_rect.bottom()), anchor_sp.y()))
                    target_pt = QPointF(tx, ty)

                    # Draw dashed leader line
                    p.setPen(QPen(QColor(15, 23, 42, 230), 4.0))
                    p.drawLine(anchor_sp, target_pt)
                    p.setPen(QPen(QColor(56, 189, 248, 240), 2.0, Qt.PenStyle.DashLine))
                    p.drawLine(anchor_sp, target_pt)

                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(QBrush(QColor(56, 189, 248, 240)))
                    p.drawEllipse(target_pt, 3.5, 3.5)

        p.restore()

    def _draw_photo_toast(self, p: QPainter, w: int, h: int):
        """Draws temporary photo capture toast notification."""
        if not self._photo_banner_text:
            return
        p.save()
        p.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        fm = p.fontMetrics()
        tw = fm.horizontalAdvance(self._photo_banner_text) + 28
        th = 28
        top_y = 100.0 if self.photo_include_ui else 48.0
        trect = QRectF((w - tw) / 2.0, top_y, tw, th)

        p.setPen(QPen(QColor(56, 189, 248, 240), 1.2))
        p.setBrush(QBrush(QColor(15, 23, 42, 230)))
        p.drawRoundedRect(trect, 6, 6)

        p.setPen(QColor(248, 250, 252))
        p.drawText(trect, Qt.AlignmentFlag.AlignCenter, self._photo_banner_text)
        p.restore()

    def _draw_bottom_loading_bar(self, p: QPainter, w: int, h: int, pend: int):
        """Renders compact loading progress banner at the bottom center of the 3D canvas."""
        left_lim = 294.0
        right_lim = max(left_lim + 260.0, w - 234.0)
        avail = max(260.0, right_lim - left_lim)
        cw = min(400.0, avail)
        ch = 58.0
        # Shift above the measurement card if measurement mode is active
        bottom_offset = 122.0 if self.measure_mode != M.MODE_NONE else 14.0
        crect = QRectF(left_lim + (avail - cw) / 2.0, h - ch - bottom_offset, cw, ch)
        self._card(p, crect, QColor(56, 189, 248, 215))

        pct = max(2, self.loading_percent)
        hdr_msg = f"{tr('v3d_loading_n', n=max(1, pend))}   {pct}%"
        f_b = QFont("Segoe UI", 9)
        f_b.setBold(True)
        p.setFont(f_b)
        p.setPen(QColor(248, 250, 252))
        p.drawText(
            QRectF(crect.left() + 14, crect.top() + 6, cw - 28, 18),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            hdr_msg,
        )

        p.setFont(QFont("Segoe UI", 8))
        p.setPen(QColor(125, 211, 252))
        sub_msg = self.loading_text or "Valmistan 3D punktipilve ette..."
        fm = QFontMetrics(p.font())
        sub_elided = fm.elidedText(sub_msg, Qt.TextElideMode.ElideMiddle, int(cw - 28))
        p.drawText(
            QRectF(crect.left() + 14, crect.top() + 23, cw - 28, 16),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            sub_elided,
        )

        bar_r = QRectF(crect.left() + 14, crect.bottom() - 13, cw - 28, 7)
        p.setPen(QPen(QColor(51, 65, 85), 1))
        p.setBrush(QBrush(QColor(15, 23, 42, 230)))
        p.drawRoundedRect(bar_r, 3, 3)
        fill_w = max(6.0, (bar_r.width() - 2.0) * (pct / 100.0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(14, 165, 233)))
        p.drawRoundedRect(QRectF(bar_r.left() + 1, bar_r.top() + 1, fill_w, bar_r.height() - 2), 2.5, 2.5)

    def _draw_data_card(self, p: QPainter):
        t = self.active_tile_info()
        f_title = QFont("Segoe UI", 10)
        f_title.setBold(True)
        f_body = QFont("Segoe UI", 9)
        fm_body = QFontMetrics(f_body)

        if t is not None:
            fi = t.file_info
            year = str(fi.year) if fi else ""
            ftype = flight_type_label(fi.flight_type) if fi else ""
            line_date = f"{tr('v3d_flight_date')}: {t.date_label()}"
            line_data = f"{tr('v3d_data')}: {year} · {ftype}"
        else:
            st = self.tile_states.get(self.active_tile)
            txt = tr("v3d_no_data") if st == STATE_NODATA else "—"
            line_date = f"{tr('v3d_flight_date')}: {txt}"
            line_data = f"{tr('v3d_data')}: —"

        line_tile = f"{tr('v3d_tile')}: {self.active_tile or '—'}"

        # Compute dynamic card width so text NEVER overflows out of bounds
        max_px = max(
            fm_body.horizontalAdvance(line_date),
            fm_body.horizontalAdvance(line_data),
            fm_body.horizontalAdvance(line_tile),
        )
        max_allowed_w = max(280.0, min(420.0, self.width() * 0.40))
        bw = max(290.0, min(max_allowed_w, float(max_px + 30)))
        self._last_data_card_w = bw

        bh = 98.0
        rect = QRectF(14, 14, bw, bh)
        self._card(p, rect)

        inner_w = int(bw - 24)
        p.setFont(f_title)
        p.setPen(QColor(248, 250, 252))
        p.drawText(QPointF(26, 35), "MaRu ALS 3D")

        p.setFont(f_body)
        p.setPen(QColor(125, 211, 252) if t is not None else QColor(148, 163, 184))
        p.drawText(QPointF(26, 55), fm_body.elidedText(line_date, Qt.TextElideMode.ElideRight, inner_w))

        p.setPen(QColor(203, 213, 225))
        p.drawText(QPointF(26, 74), fm_body.elidedText(line_data, Qt.TextElideMode.ElideRight, inner_w))

        p.setPen(QColor(148, 163, 184))
        p.drawText(QPointF(26, 93), fm_body.elidedText(line_tile, Qt.TextElideMode.ElideRight, inner_w))

    def _draw_compass(self, p: QPainter, w: int):
        left_lim = self._last_data_card_w + 26.0
        right_lim = (w - 405.0) if self.show_help else (w - 20.0)
        avail = right_lim - left_lim
        if avail < 140.0:
            return
        cw = min(240.0, avail - 8.0)
        ch = 34.0
        cx_box = left_lim + (avail - cw) / 2.0
        rect = QRectF(cx_box, 14, cw, ch)
        self._card(p, rect, QColor(100, 116, 139, 150))
        p.save()
        p.setClipRect(rect.adjusted(4, 2, -4, -2))
        px_per_deg = cw / 120.0
        center = rect.center().x()
        p.setFont(QFont("Segoe UI", 8))
        for deg in range(-180, 541, 15):
            off = ((deg - self.yaw + 540) % 360) - 180
            if abs(off) > 62:
                continue
            x = center + off * px_per_deg
            major = deg % 45 == 0
            p.setPen(QPen(QColor(226, 232, 240, 220 if major else 120), 1))
            p.drawLine(QPointF(x, rect.bottom() - (10 if major else 5)), QPointF(x, rect.bottom() - 2))
            if major:
                lbl = {0: "N", 45: "NE", 90: "E", 135: "SE", 180: "S", 225: "SW", 270: "W", 315: "NW"}[deg % 360]
                p.setPen(QColor(239, 68, 68) if lbl == "N" else QColor(226, 232, 240))
                p.drawText(QRectF(x - 14, rect.top() + 2, 28, 14), Qt.AlignmentFlag.AlignCenter, lbl)
        p.restore()
        p.setPen(QPen(QColor(250, 204, 21), 2))
        p.drawLine(QPointF(center, rect.top() + 2), QPointF(center, rect.bottom() - 2))
        p.setPen(QColor(250, 204, 21))
        p.setFont(QFont("Segoe UI", 8))
        p.drawText(QRectF(center - 30, rect.bottom() + 2, 60, 14), Qt.AlignmentFlag.AlignCenter, f"{self.yaw:05.1f}°")

    def _draw_help(self, p: QPainter, w: int):
        lines = [tr("v3d_help_1"), tr("v3d_help_2"), tr("v3d_help_3"), tr("v3d_help_4"), tr("v3d_help_5")]
        f_help = QFont("Segoe UI", 8)
        fm = QFontMetrics(f_help)
        max_w = max(fm.horizontalAdvance(ln) for ln in lines)
        bw = max(365.0, min(float(w - 28), float(max_w + 26)))
        bh = 18.0 + 16.0 * len(lines)
        rect = QRectF(w - bw - 14, 14, bw, bh)
        self._card(p, rect, QColor(100, 116, 139, 150))
        p.setFont(f_help)
        p.setPen(QColor(226, 232, 240))
        for i, ln in enumerate(lines):
            p.drawText(QPointF(rect.left() + 12, rect.top() + 20 + i * 16), fm.elidedText(ln, Qt.TextElideMode.ElideRight, int(bw - 20)))

    def _draw_telemetry(self, p: QPainter, h: int):
        f_row = QFont("Segoe UI", 8)
        fm = QFontMetrics(f_row)
        g = self.ground_at(self.cam[0], self.cam[1])
        agl = f"{self.cam[2] - g:.1f} m" if g is not None else "—"
        X, Y = self.to_abs(self.cam[0], self.cam[1])
        spd = float(np.linalg.norm(self.vel))
        hspd = math.hypot(self.vel[0], self.vel[1])
        mins, secs = divmod(int(self.flight_time), 60)
        rows = [
            (tr("v3d_alt"), f"{self.cam[2]:.1f} m", None),
            (tr("v3d_agl"), agl, None),
            (tr("v3d_speed"), f"{spd * 3.6:.1f} km/h  (↕ {self.vel[2]:+.1f} m/s)", None),
            (tr("v3d_cruise"), f"{self.base_speed * 3.6:.0f} km/h" + ("  ⚡" if K.Key_Shift in self.keys else ""), None),
            (tr("v3d_heading"), f"{self.yaw:.1f}°   {tr('v3d_gimbal')} {self.pitch:+.1f}°", None),
            ("X / Y", f"{X:.1f} / {Y:.1f}", None),
            (tr("v3d_flown"), f"{fmt_len(self.flown)}   {mins:02d}:{secs:02d}", None),
            (tr("v3d_points"), f"{self.points_drawn / 1e6:.2f} M   {self.fps:.0f} fps", None),
            (tr("v3d_tele_drone", fallback="Droon"), self.live_drone_name, QColor(56, 189, 248)),
            (tr("v3d_tele_signal", fallback="RC Signaal"), self.live_signal_text, self.live_signal_color),
            (tr("v3d_tele_vlos", fallback="VLOS"), self.live_vlos_text, self.live_vlos_color),
        ]
        col1_w = max(100, max(fm.horizontalAdvance(k) for k, _, _ in rows) + 12)
        col2_w = max(fm.horizontalAdvance(v) for _, v, _ in rows)
        bw = max(285.0, float(col1_w + col2_w + 28))
        bh = 248.0
        rect = QRectF(14, h - bh - 14, bw, bh)
        self._card(p, rect)
        x0, y = rect.left() + 12, rect.top() + 20
        f = QFont("Segoe UI", 9)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor(248, 250, 252))
        p.drawText(QPointF(x0, y), tr("v3d_telemetry"))
        p.setFont(f_row)
        for i, (k, v, val_col) in enumerate(rows):
            yy = y + 18 + i * 19
            p.setPen(QColor(148, 163, 184))
            p.drawText(QPointF(x0, yy), k)
            c = val_col if val_col is not None else QColor(226, 232, 240)
            p.setPen(c)
            p.drawText(QPointF(x0 + col1_w, yy), v)
        _ = hspd

    def _minimap_scale(self) -> float:
        return self.minimap_span_m / self._minimap_rect().width()   # metres per pixel

    def _draw_minimap(self, p: QPainter):
        rect = self._minimap_rect()
        self._card(p, rect)
        scale = self._minimap_scale()
        c = rect.center()

        def to_px(lx, ly):
            return QPointF(c.x() + (lx - self.cam[0]) / scale, c.y() - (ly - self.cam[1]) / scale)

        if self.scene_origin is not None:
            p.save()
            p.setClipRect(rect.adjusted(2, 2, -2, -2))
            X, Y = self.to_abs(self.cam[0], self.cam[1])
            base = GridEngine.point_to_tile(X, Y)
            try:
                by, bx = int(base[:3]), int(base[3:])
            except ValueError:
                by = bx = 0

            # Dynamic tile search radius based on current minimap zoom span
            rad = max(2, min(4, int(math.ceil(self.minimap_span_m / 1500.0))))
            is_wms = self.minimap_base_mode != "grid"

            # Pre-gather all visible 1:2000 grid tiles in minimap viewport
            visible_tiles = []
            for dy in range(-rad, rad + 1):
                for dx in range(-rad, rad + 1):
                    tid = f"{by + dy:03d}{bx + dx:03d}"
                    r = GridEngine.tile_to_rect(tid)
                    if r is None:
                        continue
                    lx0, ly0 = self.to_local(r.xMinimum(), r.yMinimum())
                    tl = to_px(lx0, ly0 + 1000.0)
                    br = to_px(lx0 + 1000.0, ly0)
                    q = QRectF(tl, br).normalized()
                    if rect.intersects(q):
                        visible_tiles.append((tid, q))

            # Pass 1: Draw WMS Base Layer tiles (Fotokaart / Põhikaart / Hübriidkaart)
            if is_wms:
                for tid, q in visible_tiles:
                    img = self._minimap_images.get((self.minimap_base_mode, tid))
                    if img is not None and not img.isNull():
                        p.drawImage(q, img)
                    else:
                        # Subtle placeholder backdrop while WMS tile downloads
                        p.fillRect(q, QColor(15, 23, 42, 175))
                        self._minimap_fetcher.request_tile(self.minimap_base_mode, tid)

            # Pass 2: Draw 1:2000 Grid boundaries & download status overlays ON TOP of base map
            for tid, q in visible_tiles:
                st = self.tile_states.get(tid)

                # Status wash fill
                if is_wms:
                    fill = {
                        STATE_LOADED: QColor(16, 185, 129, 65),
                        STATE_QUEUED: QColor(245, 158, 11, 85),
                        STATE_LOADING: QColor(245, 158, 11, 105),
                        STATE_NODATA: QColor(185, 28, 28, 85),
                        STATE_FAILED: QColor(239, 68, 68, 95),
                    }.get(st, QColor(15, 23, 42, 35))
                else:
                    fill = {
                        STATE_LOADED: QColor(16, 185, 129, 70),
                        STATE_QUEUED: QColor(245, 158, 11, 65),
                        STATE_LOADING: QColor(245, 158, 11, 95),
                        STATE_NODATA: QColor(100, 30, 30, 90),
                        STATE_FAILED: QColor(220, 38, 38, 90),
                    }.get(st, QColor(30, 41, 59, 45))

                # Double-pass border: dark outer contrast shadow + bright inner line
                # Guarantees the 1:2000 grid lines pop clearly over white beaches, fields, or dark forests
                if is_wms:
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.setPen(QPen(QColor(10, 15, 26, 235), 2.4))
                    p.drawRect(q)

                border_col = {
                    STATE_LOADED: QColor(16, 185, 129, 255),
                    STATE_QUEUED: QColor(245, 158, 11, 255),
                    STATE_LOADING: QColor(245, 158, 11, 255),
                    STATE_NODATA: QColor(239, 68, 68, 240),
                    STATE_FAILED: QColor(239, 68, 68, 255),
                }.get(st, QColor(56, 189, 248, 215) if is_wms else QColor(100, 116, 139, 160))

                pen_w = 2.0 if st in (STATE_LOADING, STATE_QUEUED) else (1.6 if st == STATE_LOADED else 1.2)
                p.setBrush(QBrush(fill))
                p.setPen(QPen(border_col, pen_w))
                p.drawRect(q)

                # Pass 3: Tile ID and download status badge (sharp & legible over any background)
                if q.width() >= 32.0:
                    qc = q.center()
                    badge_w = min(q.width() - 4.0, 48.0)
                    badge_h = 13.0
                    badge_rect = QRectF(qc.x() - badge_w / 2.0, qc.y() - badge_h / 2.0, badge_w, badge_h)

                    # Badge background & border
                    p.setBrush(QBrush(QColor(15, 23, 42, 215)))
                    p.setPen(QPen(border_col, 1.0))
                    p.drawRoundedRect(badge_rect, 3.0, 3.0)

                    # Badge text
                    p.setFont(QFont("Segoe UI", 6, QFont.Weight.Bold))
                    p.setPen(QColor(248, 250, 252))
                    lbl_txt = tid
                    if st == STATE_LOADING:
                        lbl_txt = f"{tid} •"
                    elif st == STATE_QUEUED:
                        lbl_txt = f"{tid} ⌛"
                    p.drawText(badge_rect, Qt.AlignmentFlag.AlignCenter, lbl_txt)

            # 3. Flight path trail (solid for flight, dotted for teleport/view resets)
            if len(self.trail) >= 2:
                recent = self.trail[-3000:]
                solid_chunk = []
                p.setBrush(Qt.BrushStyle.NoBrush)
                for i, rec in enumerate(recent):
                    lx, ly = self.to_local(rec[1], rec[2])
                    pt = to_px(lx, ly)
                    is_jump = bool(rec[6]) if len(rec) >= 7 else False
                    if is_jump and i > 0:
                        # Draw pending solid chunk before jump
                        if len(solid_chunk) >= 2:
                            p.setPen(QPen(QColor(15, 23, 42, 190), 3.2, Qt.PenStyle.SolidLine))
                            p.drawPolyline(QPolygonF(solid_chunk))
                            p.setPen(QPen(QColor(250, 204, 21), 1.8, Qt.PenStyle.SolidLine))
                            p.drawPolyline(QPolygonF(solid_chunk))
                        solid_chunk = [pt]
                        # Draw jump segment as DOTTED line
                        prev_lx, prev_ly = self.to_local(recent[i - 1][1], recent[i - 1][2])
                        prev_pt = to_px(prev_lx, prev_ly)
                        p.setPen(QPen(QColor(15, 23, 42, 180), 3.0, Qt.PenStyle.DotLine))
                        p.drawLine(prev_pt, pt)
                        p.setPen(QPen(QColor(250, 204, 21), 1.8, Qt.PenStyle.DotLine))
                        p.drawLine(prev_pt, pt)
                    else:
                        solid_chunk.append(pt)
                if len(solid_chunk) >= 2:
                    p.setPen(QPen(QColor(15, 23, 42, 190), 3.2, Qt.PenStyle.SolidLine))
                    p.drawPolyline(QPolygonF(solid_chunk))
                    p.setPen(QPen(QColor(250, 204, 21), 1.8, Qt.PenStyle.SolidLine))
                    p.drawPolyline(QPolygonF(solid_chunk))

            # 4. Measurement on minimap
            if self.measure_pts:
                mp = [to_px(q[0], q[1]) for q in self.measure_pts]
                p.setPen(QPen(QColor(34, 211, 238), 1.5))
                if self.measure_mode in (M.MODE_AREA, M.MODE_VOLUME) and len(mp) >= 3:
                    p.drawPolygon(QPolygonF(mp))
                else:
                    p.drawPolyline(QPolygonF(mp))

            # 4b. Session photos waypoint pins on minimap
            if self.session_photos:
                for shot in self.session_photos:
                    lx, ly = self.to_local(shot.x_3301, shot.y_3301)
                    s_pt = to_px(lx, ly)
                    if not rect.contains(s_pt):
                        continue
                    spx, spy = s_pt.x(), s_pt.y()

                    # Direction heading ray
                    yaw_rad = math.radians(shot.yaw_deg)
                    ray_len = 12.0
                    rx = spx + ray_len * math.sin(yaw_rad)
                    ry = spy - ray_len * math.cos(yaw_rad)
                    p.setPen(QPen(QColor(15, 23, 42, 230), 2.8))
                    p.drawLine(QPointF(spx, spy), QPointF(rx, ry))
                    p.setPen(QPen(QColor(245, 158, 11, 240), 1.6))
                    p.drawLine(QPointF(spx, spy), QPointF(rx, ry))

                    # Camera waypoint marker
                    p.setBrush(QBrush(QColor(245, 158, 11, 240)))
                    p.setPen(QPen(QColor(15, 23, 42, 230), 1.5))
                    p.drawEllipse(s_pt, 4.5, 4.5)
                    p.setBrush(QBrush(QColor(255, 255, 255, 240)))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.drawEllipse(s_pt, 1.8, 1.8)

                    # Shot ID label badge
                    lbl = f"#{shot.shot_id}"
                    p.setFont(QFont("Segoe UI", 6, QFont.Weight.Bold))
                    p.setPen(QColor(15, 23, 42, 240))
                    p.drawText(QPointF(spx + 6, spy - 2), lbl)
                    p.setPen(QColor(254, 243, 199))
                    p.drawText(QPointF(spx + 5, spy - 3), lbl)

            # 5. Drone + FOV bearing cone
            yr = math.radians(self.yaw)
            half = math.radians(self.FOV / 2.0 * self.width() / max(1, self.height()))
            L = 36.0
            cone = QPolygonF([
                c,
                QPointF(c.x() + L * math.sin(yr - half), c.y() - L * math.cos(yr - half)),
                QPointF(c.x() + L * math.sin(yr + half), c.y() - L * math.cos(yr + half)),
            ])
            p.setPen(QPen(QColor(239, 68, 68, 150), 1.0))
            p.setBrush(QBrush(QColor(239, 68, 68, 70)))
            p.drawPolygon(cone)
            tri = QPolygonF([
                QPointF(c.x() + 9.5 * math.sin(yr), c.y() - 9.5 * math.cos(yr)),
                QPointF(c.x() + 6.5 * math.sin(yr + 2.5), c.y() - 6.5 * math.cos(yr + 2.5)),
                QPointF(c.x() + 6.5 * math.sin(yr - 2.5), c.y() - 6.5 * math.cos(yr - 2.5)),
            ])
            p.setPen(QPen(QColor(255, 255, 255), 1.3))
            p.setBrush(QBrush(QColor(239, 68, 68)))
            p.drawPolygon(tri)
            p.restore()

        # 6. Top Header Backdrop + Title + Base Layer Pills (Foto | Põhi | Hübriid | Võrk)
        top_bar = QRectF(rect.left() + 2, rect.top() + 2, rect.width() - 4, 36)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(10, 18, 34, 210)))
        p.drawRoundedRect(top_bar, 6, 6)

        p.setPen(QColor(248, 250, 252))
        f = QFont("Segoe UI", 7)
        f.setBold(True)
        p.setFont(f)
        p.drawText(QPointF(rect.left() + 8, rect.top() + 13), tr("v3d_minimap"))
        p.setPen(QColor(239, 68, 68))
        p.drawText(QPointF(rect.right() - 14, rect.top() + 13), "N")

        mode_defs = [
            ("foto", tr("v3d_mm_foto")),
            ("hall", tr("v3d_mm_hall")),
            ("hyb", tr("v3d_mm_hyb")),
            ("grid", tr("v3d_mm_grid")),
        ]
        self._mm_mode_rects.clear()
        pill_y = rect.top() + 18.0
        pill_h = 16.0
        avail_w = rect.width() - 12.0
        gap = 3.0
        pill_w = (avail_w - gap * (len(mode_defs) - 1)) / len(mode_defs)
        f_pill = QFont("Segoe UI", 7)
        for idx, (m_key, m_lbl) in enumerate(mode_defs):
            px = rect.left() + 6.0 + idx * (pill_w + gap)
            pr = QRectF(px, pill_y, pill_w, pill_h)
            self._mm_mode_rects[m_key] = pr
            active = self.minimap_base_mode == m_key
            p.setPen(QPen(QColor(56, 189, 248) if active else QColor(71, 85, 105, 180), 1.0))
            p.setBrush(QBrush(QColor(2, 132, 199, 235) if active else QColor(30, 41, 59, 210)))
            p.drawRoundedRect(pr, 3.0, 3.0)
            f_pill.setBold(active)
            p.setFont(f_pill)
            p.setPen(QColor(255, 255, 255) if active else QColor(203, 213, 225))
            p.drawText(pr, Qt.AlignmentFlag.AlignCenter, m_lbl)

        # 7. Bottom Footer Backdrop + Dynamic Scale Bar + [-][+] Zoom Buttons
        bot_bar = QRectF(rect.left() + 2, rect.bottom() - 22, rect.width() - 4, 20)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(10, 18, 34, 205)))
        p.drawRoundedRect(bot_bar, 6, 6)

        # Choose nicest scale bar distance for current zoom level
        bar_m = 500.0
        for cand_m in (100.0, 200.0, 500.0, 1000.0, 2000.0):
            px_len = cand_m / max(scale, 1e-3)
            bar_m = cand_m
            if 28.0 <= px_len <= 85.0:
                break
        bar_px = min(95.0, max(20.0, bar_m / max(scale, 1e-3)))
        bar_lbl = f"{int(bar_m // 1000)} km" if bar_m >= 1000.0 else f"{int(bar_m)} m"

        y_bar = rect.bottom() - 11.0
        x_bar = rect.left() + 9.0
        p.setPen(QPen(QColor(248, 250, 252), 2.0))
        p.drawLine(QPointF(x_bar, y_bar), QPointF(x_bar + bar_px, y_bar))
        p.drawLine(QPointF(x_bar, y_bar - 3), QPointF(x_bar, y_bar + 3))
        p.drawLine(QPointF(x_bar + bar_px, y_bar - 3), QPointF(x_bar + bar_px, y_bar + 3))
        p.setFont(QFont("Segoe UI", 7))
        p.setPen(QColor(226, 232, 240))
        p.drawText(QPointF(x_bar + bar_px + 5.0, y_bar + 3.0), bar_lbl)

        # Zoom [-] and [+] buttons at bottom-right of minimap
        btn_w, btn_h = 20.0, 15.0
        by_btn = rect.bottom() - btn_h - 4.0
        self._mm_btn_zoom_in = QRectF(rect.right() - btn_w - 6.0, by_btn, btn_w, btn_h)
        self._mm_btn_zoom_out = QRectF(rect.right() - 2 * btn_w - 10.0, by_btn, btn_w, btn_h)

        f_z = QFont("Segoe UI", 9)
        f_z.setBold(True)
        p.setFont(f_z)
        for z_rect, z_sym in ((self._mm_btn_zoom_out, "−"), (self._mm_btn_zoom_in, "+")):
            p.setPen(QPen(QColor(56, 189, 248, 190), 1.0))
            p.setBrush(QBrush(QColor(30, 41, 59, 230)))
            p.drawRoundedRect(z_rect, 3.0, 3.0)
            p.setPen(QColor(248, 250, 252))
            p.drawText(z_rect, Qt.AlignmentFlag.AlignCenter, z_sym)

    def _draw_canvas_layers_overlay(self, p: QPainter):
        """Renders 2D canvas vector layers draped in 3D with fast batched hardware polyline drawing and optional LOS occlusion."""
        if not self.show_canvas_layers:
            return
        if not self.canvas_draped_lines and not self.canvas_draped_pts and not self.canvas_draped_polygons:
            return

        cam_x, cam_y = float(self.cam[0]), float(self.cam[1])
        use_los = self.los_occlusion and bool(self.tiles)
        scr_w, scr_h = float(self.width()), float(self.height())
        mvp_t = self._mvp.T

        # 0. Draw semi-transparent polygon fills beneath stroke outlines
        if hasattr(self, "canvas_draped_polygons") and self.canvas_draped_polygons:
            p.save()
            for fill_col, rings3 in self.canvas_draped_polygons:
                for pts3 in rings3:
                    n_pts = len(pts3)
                    if n_pts < 3:
                        continue
                    dmin_x = np.min(np.abs(pts3[:, 0] - cam_x))
                    dmin_y = np.min(np.abs(pts3[:, 1] - cam_y))
                    if dmin_x > 2200.0 or dmin_y > 2200.0:
                        continue
                    h_coords = np.hstack([pts3, np.ones((n_pts, 1), dtype=np.float64)])
                    clip = h_coords @ mvp_t
                    cw = clip[:, 3]
                    in_front = cw >= self.NEAR
                    if np.sum(in_front) < 3:
                        continue
                    w_safe = np.maximum(cw, 1e-4)
                    sx = (clip[:, 0] / w_safe * 0.5 + 0.5) * scr_w
                    sy = (-clip[:, 1] / w_safe * 0.5 + 0.5) * scr_h

                    if (np.all(sx[in_front] < -40.0) or np.all(sx[in_front] > scr_w + 40.0) or
                            np.all(sy[in_front] < -40.0) or np.all(sy[in_front] > scr_h + 40.0)):
                        continue

                    # Fast Line-of-Sight (LOS) Occlusion on polygon fills
                    if use_los and (dmin_x < 1500.0 and dmin_y < 1500.0):
                        front_idx = np.where(in_front)[0]
                        if len(front_idx) > 0:
                            step_sample = max(1, len(front_idx) // 12)
                            sub_idx = front_idx[::step_sample]
                            occ_perim = self.is_occluded_vec(pts3[sub_idx])

                            c3 = np.mean(pts3, axis=0, keepdims=True)
                            occ_c = self.is_occluded_vec(c3)[0]

                            if (occ_c and np.mean(occ_perim) > 0.25) or np.mean(occ_perim) > 0.50:
                                continue

                    poly_pts = [QPointF(sx[i], sy[i]) for i in range(n_pts) if in_front[i]]
                    if len(poly_pts) >= 3:
                        p.setPen(Qt.PenStyle.NoPen)
                        p.setBrush(QBrush(fill_col))
                        p.drawPolygon(QPolygonF(poly_pts))
            p.restore()

        # Batch draw lines with compiled Qt C++ polyline rendering (10x faster than individual drawLine calls)
        for col, width, pts3 in self.canvas_draped_lines:
            n_pts = len(pts3)
            if n_pts < 2:
                continue

            # 1. Fast distance cull: skip lines farther than 2000m from drone camera
            dmin_x = np.min(np.abs(pts3[:, 0] - cam_x))
            dmin_y = np.min(np.abs(pts3[:, 1] - cam_y))
            if dmin_x > 2000.0 or dmin_y > 2000.0:
                continue

            # 2. Vectorized 3D -> Screen projection of all line vertices in one matrix multiply
            h_coords = np.hstack([pts3, np.ones((n_pts, 1), dtype=np.float64)])
            clip = h_coords @ mvp_t
            cw = clip[:, 3]

            in_front = cw >= self.NEAR
            if not np.any(in_front):
                continue

            w_safe = np.maximum(cw, 1e-4)
            ndc_x = clip[:, 0] / w_safe
            ndc_y = clip[:, 1] / w_safe

            sx = (ndc_x * 0.5 + 0.5) * scr_w
            sy = (-ndc_y * 0.5 + 0.5) * scr_h

            # Frustum bounds cull: if all visible vertices are off one side of the screen, skip
            if (np.all(sx[in_front] < -40.0) or np.all(sx[in_front] > scr_w + 40.0) or
                    np.all(sy[in_front] < -40.0) or np.all(sy[in_front] > scr_h + 40.0)):
                continue

            # 3. Fast Line-of-Sight (LOS) Occlusion on visible vertices within 1000m
            occ_mask = np.zeros(n_pts, dtype=bool)
            if use_los and (dmin_x < 1000.0 and dmin_y < 1000.0):
                front_idx = np.where(in_front)[0]
                if len(front_idx) > 0:
                    occ_front = self.is_occluded_vec(pts3[front_idx])
                    occ_mask[front_idx] = occ_front

            # 4. Batched polyline drawing (runs of unoccluded front-facing vertices)
            pen_halo = QPen(QColor(0, 0, 0, 140), width + 1.6)
            pen_line = QPen(col, width)

            polys = []
            curr_pts = []
            for i in range(n_pts):
                if not in_front[i] or occ_mask[i]:
                    if len(curr_pts) >= 2:
                        polys.append(QPolygonF(curr_pts))
                    curr_pts = []
                else:
                    curr_pts.append(QPointF(sx[i], sy[i]))
            if len(curr_pts) >= 2:
                polys.append(QPolygonF(curr_pts))

            for poly in polys:
                p.setPen(pen_halo)
                p.drawPolyline(poly)
                p.setPen(pen_line)
                p.drawPolyline(poly)

        if self.canvas_draped_pts:
            p.setFont(QFont("Segoe UI", 8))
            for col, lbl, pt3 in self.canvas_draped_pts:
                sp = self.project(pt3)
                if sp is None:
                    continue
                if use_los and self.is_occluded_vec(pt3.reshape(1, 3))[0]:
                    continue
                p.setPen(QPen(QColor(255, 255, 255), 1.4))
                p.setBrush(QBrush(col))
                p.drawEllipse(sp, 4.5, 4.5)
                if lbl:
                    p.setPen(QColor(248, 250, 252))
                    p.drawText(sp + QPointF(7, 3), lbl[:28])

    def _draw_3d_photo_waypoints(self, p: QPainter):
        """Renders 3D Drone Photo Waypoints in the air with true flight altitude,
        heading sight-ray, ground plumb-line, and metadata badge."""
        if getattr(self, "_hide_hud_for_capture", False):
            return
        if self.scene_origin is None:
            return

        photos_to_draw = []
        seen_ids = set()

        ox, oy = float(self.scene_origin[0]), float(self.scene_origin[1])
        default_z = float(np.mean([t.z_range[0] for t in self.tiles.values()])) if self.tiles else 10.0

        # 1. Active flight session photos
        if hasattr(self, "session_photos") and self.session_photos:
            for shot in self.session_photos:
                lx = float(shot.x_3301) - ox
                ly = float(shot.y_3301) - oy
                lz = float(shot.z_eh2000)
                g = self.ground_at(lx, ly)
                gz = float(g) if g is not None else default_z
                photos_to_draw.append({
                    "cam_pos3": np.array([lx, ly, lz], dtype=np.float64),
                    "gnd_pos3": np.array([lx, ly, gz], dtype=np.float64),
                    "yaw_deg": float(shot.yaw_deg),
                    "pitch_deg": float(shot.pitch_deg),
                    "shot_id": shot.shot_id,
                    "z_eh2000": lz,
                    "agl_m": float(shot.agl_m),
                })
                seen_ids.add(shot.shot_id)

        # 2. Draped photos from loaded QGIS 2D photo layer
        if hasattr(self, "canvas_draped_photos") and self.canvas_draped_photos:
            for pshot in self.canvas_draped_photos:
                sid = pshot.get("shot_id")
                if sid not in seen_ids:
                    photos_to_draw.append(pshot)
                    seen_ids.add(sid)

        if not photos_to_draw:
            return

        use_los = self.los_occlusion and bool(self.tiles)

        p.save()
        p.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        fm = p.fontMetrics()

        for pshot in photos_to_draw:
            cam_pt3 = pshot["cam_pos3"]
            gnd_pt3 = pshot["gnd_pos3"]
            yaw = float(pshot.get("yaw_deg", 0.0))
            pitch = float(pshot.get("pitch_deg", 0.0))
            shot_id = pshot.get("shot_id", 1)
            z_eh2000 = float(pshot.get("z_eh2000", 0.0))

            # Distance culling: visible within 3500m of camera
            dist_to_cam = math.hypot(cam_pt3[0] - self.cam[0], cam_pt3[1] - self.cam[1])
            if dist_to_cam > 3500.0:
                continue

            # 3D project camera position
            sp_cam = self.project(cam_pt3)
            if sp_cam is None:
                continue

            # Line-of-sight occlusion check
            if use_los and self.is_occluded_vec(cam_pt3.reshape(1, 3))[0]:
                continue

            # 1. Ground grounding plumb-line & drop shadow
            seg_plumb = self.project_segment(gnd_pt3, cam_pt3)
            if seg_plumb is not None:
                p.setPen(QPen(QColor(245, 158, 11, 160), 1.2, Qt.PenStyle.DashLine))
                p.drawLine(seg_plumb[0], seg_plumb[1])
            sp_gnd = self.project(gnd_pt3)
            if sp_gnd is not None:
                p.setBrush(QBrush(QColor(15, 23, 42, 160)))
                p.setPen(QPen(QColor(245, 158, 11, 180), 1.2))
                p.drawEllipse(sp_gnd, 4.5, 2.5)

            # 2. 3D Direction Vector (Yaw + Pitch)
            yr = math.radians(yaw)
            pr = math.radians(pitch)
            fwd_x = math.sin(yr) * math.cos(pr)
            fwd_y = math.cos(yr) * math.cos(pr)
            fwd_z = math.sin(pr)
            ray_len = 10.0
            target_pt3 = cam_pt3 + np.array([fwd_x * ray_len, fwd_y * ray_len, fwd_z * ray_len], dtype=np.float64)
            seg_ray = self.project_segment(cam_pt3, target_pt3)
            if seg_ray is not None:
                p.setPen(QPen(QColor(15, 23, 42, 220), 3.2))
                p.drawLine(seg_ray[0], seg_ray[1])
                p.setPen(QPen(QColor(250, 204, 21), 1.8))
                p.drawLine(seg_ray[0], seg_ray[1])
                sp_target = self.project(target_pt3)
                if sp_target is not None:
                    p.setBrush(QBrush(QColor(250, 204, 21)))
                    p.setPen(QPen(QColor(15, 23, 42, 240), 1.0))
                    p.drawEllipse(sp_target, 2.5, 2.5)

            # 3. Camera Waypoint Pin in the air
            p.setBrush(QBrush(QColor(245, 158, 11, 240)))
            p.setPen(QPen(QColor(15, 23, 42, 240), 1.6))
            p.drawEllipse(sp_cam, 6.0, 6.0)
            p.setBrush(QBrush(QColor(255, 255, 255, 255)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(sp_cam, 2.4, 2.4)

            # 4. 3D Altitude & ID Badge
            lbl_txt = f"📸 #{shot_id}  {z_eh2000:.1f}m"
            badge_w = fm.horizontalAdvance(lbl_txt) + 12
            badge_h = 18
            badge_r = QRectF(sp_cam.x() + 9, sp_cam.y() - badge_h / 2.0, badge_w, badge_h)
            p.setPen(QPen(QColor(245, 158, 11, 200), 1.0))
            p.setBrush(QBrush(QColor(15, 23, 42, 220)))
            p.drawRoundedRect(badge_r, 4.0, 4.0)
            p.setPen(QColor(254, 243, 199))
            p.drawText(badge_r, Qt.AlignmentFlag.AlignCenter, lbl_txt)

        p.restore()

    def _draw_measure_overlay(self, p: QPainter):
        if self.measure_mode == M.MODE_NONE or not self.measure_pts:
            return
        pts = self.measure_pts
        closed_poly = self.measure_mode in (M.MODE_AREA, M.MODE_VOLUME)
        segs = list(zip(pts[:-1], pts[1:]))
        if closed_poly and len(pts) >= 3:
            segs.append((pts[-1], pts[0]))
        fill_col = QColor(34, 211, 238, 45)
        if closed_poly and len(pts) >= 3:
            proj = [self.project(q) for q in pts]
            if all(q is not None for q in proj):
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(fill_col))
                p.drawPolygon(QPolygonF(proj))
        p.setFont(QFont("Segoe UI", 8))
        for a, b in segs:
            s = self.project_segment(a, b)
            if s is None:
                continue
            p.setPen(QPen(QColor(0, 0, 0, 160), 4))
            p.drawLine(s[0], s[1])
            p.setPen(QPen(QColor(34, 211, 238), 2))
            p.drawLine(s[0], s[1])
            if self.measure_mode == M.MODE_DISTANCE:
                d3 = math.dist(a, b)
                mid = QPointF((s[0].x() + s[1].x()) / 2, (s[0].y() + s[1].y()) / 2)
                p.setPen(QColor(255, 255, 255))
                p.drawText(mid + QPointF(6, -6), fmt_len(d3))
        for q in pts:
            sp = self.project(q)
            if sp is None:
                continue
            p.setPen(QPen(QColor(255, 255, 255), 1.5))
            p.setBrush(QBrush(QColor(34, 211, 238)))
            p.drawEllipse(sp, 4.5, 4.5)
        # Rubber band to cursor
        if not self.measure_closed and self.cursor_pos.x() >= 0:
            last = self.project(pts[-1])
            if last is not None:
                p.setPen(QPen(QColor(34, 211, 238, 150), 1.2, Qt.PenStyle.DashLine))
                p.drawLine(last, self.cursor_pos)

    def _draw_measure_card(self, p: QPainter, w: int, h: int):
        r = self.measure_result
        mode = self.measure_mode
        title = {M.MODE_DISTANCE: tr("v3d_m_distance"), M.MODE_AREA: tr("v3d_m_area"),
                 M.MODE_VOLUME: tr("v3d_m_volume")}.get(mode, "")
        lines = []
        if mode == M.MODE_DISTANCE and "len_3d" in r:
            lines = [
                f"{tr('v3d_len3d')}: {fmt_len(r['len_3d'])}    {tr('v3d_len2d')}: {fmt_len(r['len_2d'])}",
                f"ΔZ: {r['dz_total']:+.2f} m    {tr('v3d_slope')}: {r['slope_deg']:.1f}° ({min(r['slope_pct'], 9999):.1f} %)",
            ]
        elif mode == M.MODE_AREA and "area" in r:
            lines = [
                f"{tr('v3d_area')}: {fmt_area(r['area'])}",
                f"{tr('v3d_perimeter')}: {fmt_len(r['perimeter'])}  (3D {fmt_len(r['perimeter_3d'])})",
            ]
        elif mode == M.MODE_VOLUME and "vol_net" in r:
            lines = [
                f"{tr('v3d_area')}: {fmt_area(r['area'])}    {tr('v3d_base')}: {r['base_z']:.2f} m",
                f"{tr('v3d_above')}: {r['vol_above']:,.1f} m³    {tr('v3d_below')}: {r['vol_below']:,.1f} m³".replace(",", " "),
                f"{tr('v3d_net')}: {r['vol_net']:,.1f} m³    {tr('v3d_coverage')}: {r['coverage']:.0f} %".replace(",", " "),
            ]
        lines.append(tr("v3d_measure_hint"))
        left_lim = 294.0
        right_lim = w - 234.0
        avail = max(320.0, right_lim - left_lim)
        bw = min(460.0, avail)
        bh = 34.0 + 18.0 * len(lines)
        rect = QRectF(left_lim + (avail - bw) / 2.0, h - bh - 14, bw, bh)
        self._card(p, rect, QColor(34, 211, 238, 200))
        f = QFont("Segoe UI", 9)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor(34, 211, 238))
        p.drawText(QPointF(rect.left() + 14, rect.top() + 22), f"{tr('v3d_measure')}: {title}  ({len(self.measure_pts)})")
        p.setFont(QFont("Segoe UI", 8))
        for i, ln in enumerate(lines):
            p.setPen(QColor(148, 163, 184) if i == len(lines) - 1 else QColor(224, 242, 254))
            p.drawText(QPointF(rect.left() + 14, rect.top() + 42 + i * 18), ln)

    def _draw_3d_homepoint_and_beam(self, p: QPainter):
        """Draws 3D Homepoint beacon, antenna mast, and direct LOS laser sightline to drone."""
        h_local = self.homepoint_local
        if h_local is None or len(h_local) < 3:
            return

        cam_pos = self.cam
        h_gnd = np.array([float(h_local[0]), float(h_local[1]), float(h_local[2]) - 1.8], dtype=np.float64)

        # 1. Direct Line-of-Sight Laser Ray between Homepoint Antenna and Drone
        seg = self.project_segment(h_local, cam_pos)
        if seg is not None:
            p_ant_sc, p_cam_sc = seg
            d_px = math.hypot(p_cam_sc.x() - p_ant_sc.x(), p_cam_sc.y() - p_ant_sc.y())
            if d_px > 3.0:
                p.save()
                if self.live_signal_occluded or self.live_signal_zone == ZONE_SHADOW:
                    pen_halo = QPen(QColor(15, 23, 42, 210), 5.5, Qt.PenStyle.DashLine)
                    pen_ray = QPen(QColor(239, 68, 68, 255), 2.6, Qt.PenStyle.DashLine)
                else:
                    pen_halo = QPen(QColor(15, 23, 42, 200), 5.0, Qt.PenStyle.SolidLine)
                    pen_ray = QPen(self.live_signal_color, 2.4, Qt.PenStyle.SolidLine)

                p.setPen(pen_halo)
                p.drawLine(p_ant_sc, p_cam_sc)
                p.setPen(pen_ray)
                p.drawLine(p_ant_sc, p_cam_sc)
                p.restore()

        # 2. 3D Homepoint Mast & Beacon Pin
        p_ant = self.project(h_local)
        p_base = self.project(h_gnd)

        if p_ant is not None:
            p.save()
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            # Draw mast line from ground to antenna
            if p_base is not None:
                p.setPen(QPen(QColor(15, 23, 42, 220), 4.5))
                p.drawLine(p_base, p_ant)
                p.setPen(QPen(QColor(245, 158, 11, 240), 2.2))
                p.drawLine(p_base, p_ant)

                # Ground antenna pulse ring
                p.setPen(QPen(QColor(245, 158, 11, 180), 1.2, Qt.PenStyle.DashLine))
                p.setBrush(QBrush(QColor(245, 158, 11, 40)))
                p.drawEllipse(p_base, 8.0, 4.0)

            # Antenna tip beacon ring
            p.setPen(QPen(QColor(254, 243, 199), 1.6))
            p.setBrush(QBrush(QColor(245, 158, 11)))
            p.drawEllipse(p_ant, 5.0, 5.0)

            # Billboard label: Homepoint
            dist_to_h = math.hypot(cam_pos[0] - h_local[0], cam_pos[1] - h_local[1], cam_pos[2] - h_local[2])
            lbl_h = f"📍 Homepoint ({dist_to_h:.0f}m)"
            f_h = QFont("Segoe UI", 9)
            f_h.setBold(True)
            p.setFont(f_h)
            fm = QFontMetrics(f_h)
            bw = fm.horizontalAdvance(lbl_h) + 16
            bh = 22
            bx = p_ant.x() - bw / 2.0
            by = p_ant.y() - bh - 8.0
            b_rect = QRectF(bx, by, float(bw), float(bh))

            p.setPen(QPen(QColor(56, 189, 248, 230), 1.2))
            p.setBrush(QBrush(QColor(15, 23, 42, 225)))
            p.drawRoundedRect(b_rect, 4.0, 4.0)
            p.setPen(QColor(255, 255, 255))
            p.drawText(b_rect, Qt.AlignmentFlag.AlignCenter, lbl_h)
            p.restore()

    def shutdown(self):
        """Cleanly stops animation timers, background minimap fetcher thread, and clears GL/NumPy resources."""
        try:
            self.timer.stop()
        except Exception:
            pass
        if hasattr(self, "_minimap_fetcher") and self._minimap_fetcher:
            try:
                self._minimap_fetcher.stop()
            except Exception:
                pass
        self.clear_tiles()
        try:
            self._on_context_destroyed()
        except Exception:
            pass
        self._gl_ctx = None
        self._gl_surf = None
        self._fbo_buf = None
        self._sw_buf = None
