# -*- coding: utf-8 -*-
"""
Bridge for extracting 2D QGIS Canvas Vector Layers (`QgsVectorLayer`) into the
custom 3D OpenGL viewer with automatic EPSG:3301 reprojection, 6m segment
densification for terrain draping, and Line-of-Sight (LOS) tree/building occlusion.
"""

import math
from typing import Dict, List, Optional, Set, Tuple

import numpy as np
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMapLayer,
    QgsProject,
    QgsRectangle,
    QgsRenderContext,
    QgsVectorLayer,
    QgsWkbTypes,
)

CRS_3301 = QgsCoordinateReferenceSystem("EPSG:3301")


def _extract_layer_color_and_width(layer: QgsVectorLayer) -> Tuple[QColor, float]:
    """Reads representative stroke/fill color and line width from a QgsVectorLayer's renderer."""
    default_col = QColor(244, 114, 182, 230)
    width = 2.2
    try:
        r = layer.renderer()
        if r is not None:
            syms = []
            if hasattr(r, "symbol") and callable(r.symbol):
                s = r.symbol()
                if s is not None:
                    syms.append(s)
            if not syms and hasattr(r, "symbols") and callable(r.symbols):
                syms = list(r.symbols(QgsRenderContext()))
            if syms:
                sym = syms[0]
                col = sym.color()
                if sym.symbolLayerCount() > 0:
                    sl = sym.symbolLayer(0)
                    if hasattr(sl, "strokeColor") and callable(sl.strokeColor):
                        sc = sl.strokeColor()
                        if sc.isValid() and sc.alpha() > 10:
                            col = sc
                        elif hasattr(sl, "color") and callable(sl.color):
                            col = sl.color()
                    elif hasattr(sl, "color") and callable(sl.color):
                        col = sl.color()
                    if hasattr(sl, "width") and callable(sl.width):
                        w = float(sl.width())
                        if 0.1 <= w <= 8.0:
                            width = max(1.5, min(6.0, w * 3.5))
                if col.isValid():
                    op = float(getattr(layer, "opacity", lambda: 1.0)())
                    final_a = int(col.alpha() * op)
                    final_a = max(40, min(255, final_a))
                    return QColor(col.red(), col.green(), col.blue(), final_a), width
    except Exception:
        pass
    return default_col, width


def _extract_feature_style(
    feat: QgsFeature,
    renderer,
    render_ctx: QgsRenderContext,
    default_col: QColor,
    default_width: float,
    layer_opacity: float = 1.0,
) -> Tuple[QColor, float, Optional[QColor]]:
    """Extracts exact stroke/fill color and line width for a specific feature according to QGIS symbology."""
    if renderer is None:
        return default_col, default_width, None
    stroke_col = default_col
    width = default_width
    fill_col = None
    try:
        sym = renderer.symbolForFeature(feat, render_ctx)
        if sym is None:
            return default_col, default_width, None
        col = sym.color()
        sym_op = float(getattr(sym, "opacity", lambda: 1.0)())

        n_layers = sym.symbolLayerCount()
        if n_layers > 0:
            for i in range(n_layers):
                sl = sym.symbolLayer(i)
                # 1. Stroke / border color
                if hasattr(sl, "strokeColor") and callable(sl.strokeColor):
                    sc = sl.strokeColor()
                    if sc.isValid() and sc.alpha() > 10:
                        stroke_col = sc
                elif hasattr(sl, "color") and callable(sl.color) and stroke_col == default_col:
                    sc = sl.color()
                    if sc.isValid() and sc.alpha() > 10:
                        stroke_col = sc

                # Stroke width
                if hasattr(sl, "width") and callable(sl.width):
                    w = float(sl.width())
                    if 0.1 <= w <= 8.0:
                        width = max(1.5, min(6.0, w * 3.5))
                elif hasattr(sl, "strokeWidth") and callable(sl.strokeWidth):
                    w = float(sl.strokeWidth())
                    if 0.1 <= w <= 8.0:
                        width = max(1.5, min(6.0, w * 3.5))

                # Check if stroke style is NoPen
                if hasattr(sl, "strokeStyle") and callable(sl.strokeStyle):
                    try:
                        st = sl.strokeStyle()
                        if st == Qt.PenStyle.NoPen or int(st) == 0:
                            stroke_col = QColor(0, 0, 0, 0)
                    except Exception:
                        pass

                # 2. Fill color extraction
                # Crucial: Check if fill style is explicitly set to NoBrush (transparent / no fill)
                is_no_brush = False
                if hasattr(sl, "brushStyle") and callable(sl.brushStyle):
                    try:
                        bs = sl.brushStyle()
                        if bs == Qt.BrushStyle.NoBrush or int(bs) == 0:
                            is_no_brush = True
                    except Exception:
                        pass

                ltype = getattr(sl, "layerType", lambda: "")()
                if "Line" in ltype and "Fill" not in ltype:
                    is_no_brush = True

                if not is_no_brush and fill_col is None:
                    if hasattr(sl, "fillColor") and callable(sl.fillColor):
                        fc = sl.fillColor()
                        if fc.isValid() and fc.alpha() > 10:
                            final_fa = int(fc.alpha() * layer_opacity * sym_op)
                            # Semi-transparent fill so terrain point cloud remains visible beneath
                            final_fa = max(20, min(140, final_fa))
                            fill_col = QColor(fc.red(), fc.green(), fc.blue(), final_fa)
                    elif hasattr(sl, "color") and callable(sl.color) and "Fill" in ltype:
                        fc = sl.color()
                        if fc.isValid() and fc.alpha() > 10:
                            final_fa = int(fc.alpha() * layer_opacity * sym_op)
                            final_fa = max(20, min(140, final_fa))
                            fill_col = QColor(fc.red(), fc.green(), fc.blue(), final_fa)
        else:
            if col.isValid():
                stroke_col = col

        if stroke_col.isValid() and stroke_col.alpha() > 0:
            final_a = int(stroke_col.alpha() * layer_opacity * sym_op)
            final_a = max(40, min(255, final_a))
            stroke_col = QColor(stroke_col.red(), stroke_col.green(), stroke_col.blue(), final_a)
    except Exception:
        pass
    return stroke_col, width, fill_col


def _densify_ring(coords: np.ndarray, step: float = 2.0) -> np.ndarray:
    """Densifies a 2D polyline (N, 2) so no segment is longer than `step` metres."""
    if len(coords) < 2:
        return coords
    out = [coords[0]]
    for i in range(len(coords) - 1):
        p0 = coords[i]
        p1 = coords[i + 1]
        dist = float(math.hypot(p1[0] - p0[0], p1[1] - p0[1]))
        if dist > step:
            n_seg = min(300, int(math.ceil(dist / step)))
            t = np.linspace(0.0, 1.0, n_seg + 1)[1:]
            seg_pts = p0[None, :] + (p1 - p0)[None, :] * t[:, None]
            out.extend(seg_pts)
        else:
            out.append(p1)
    return np.asarray(out, dtype=np.float64)


def list_canvas_vector_layers(include_wfs_grid: bool = False) -> List[Tuple[str, str, bool]]:
    """
    Returns list of `(layer_id, layer_name, is_visible_in_tree)` for all valid vector layers
    in the current QGIS project.
    """
    proj = QgsProject.instance()
    root = proj.layerTreeRoot()
    result = []
    for lyr_id, lyr in proj.mapLayers().items():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        if not include_wfs_grid and ("epk_2T" in lyr.source() or "1:2000" in lyr.name()):
            continue
        node = root.findLayer(lyr_id)
        vis = bool(node.isVisible()) if node is not None else True
        result.append((lyr_id, lyr.name(), vis))
    return result


def extract_canvas_features_for_3d(
    bbox_3301: QgsRectangle,
    enabled_layer_ids: Optional[Set[str]] = None,
    max_features_per_layer: int = 2500,
    densify_step: float = 12.0,
) -> List[dict]:
    """
    Extracts vector geometries within `bbox_3301` from visible (or explicitly selected)
    QgsVectorLayers, transforms to EPSG:3301, and densifies for 3D terrain draping & LOS.
    """
    proj = QgsProject.instance()
    root = proj.layerTreeRoot()
    extracted: List[dict] = []

    for lyr_id, lyr in proj.mapLayers().items():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue

        if enabled_layer_ids is not None:
            if lyr_id not in enabled_layer_ids:
                continue
        else:
            # Default: include all visible vector layers except the WFS 1:2000 index grid
            if "epk_2T" in lyr.source() or "Kaardilehed 1:2000" in lyr.name() or "Map Sheets 1:2000" in lyr.name():
                continue
            node = root.findLayer(lyr_id)
            if node is not None and not node.isVisible():
                continue

        col, width = _extract_layer_color_and_width(lyr)
        lyr_op = float(getattr(lyr, "opacity", lambda: 1.0)())
        r = lyr.renderer()
        render_ctx = QgsRenderContext()
        if r is not None and hasattr(r, "startRender"):
            try:
                r.startRender(render_ctx, lyr.fields())
            except Exception:
                pass

        src_crs = lyr.crs()
        need_xform = src_crs.isValid() and src_crs.authid() != "EPSG:3301"
        xform_to_3301 = QgsCoordinateTransform(src_crs, CRS_3301, proj) if need_xform else None
        xform_from_3301 = QgsCoordinateTransform(CRS_3301, src_crs, proj) if need_xform else None

        try:
            filter_rect = xform_from_3301.transformBoundingBox(bbox_3301) if xform_from_3301 else bbox_3301
        except Exception:
            filter_rect = bbox_3301

        req = QgsFeatureRequest().setFilterRect(filter_rect).setLimit(max_features_per_layer)
        lines_abs: List[np.ndarray] = []
        pts_abs: List[Tuple[Tuple[float, float], str]] = []
        features_list: List[dict] = []
        photo_pts_3d: List[dict] = []
        fld_names = [f.name() for f in lyr.fields()]
        is_photo_layer = (
            lyr.name() == "MaRu ALS Droonifotod"
            or ("Korgus_EH2000" in fld_names and "Suund_Yaw" in fld_names)
        )

        # Pick display field if available
        disp_idx = 0 if lyr.fields().count() > 0 else -1

        try:
            for feat in lyr.getFeatures(req):
                geom: QgsGeometry = feat.geometry()
                if geom is None or geom.isEmpty():
                    continue
                g = QgsGeometry(geom)
                if xform_to_3301 is not None:
                    try:
                        g.transform(xform_to_3301)
                    except Exception:
                        continue

                # Clip to expanded scene bbox so giant regional polygons don't add 50km of distant lines
                clipped = g.clipped(bbox_3301)
                if clipped is not None and not clipped.isEmpty():
                    g = clipped

                if is_photo_layer:
                    try:
                        shot_id = feat.attribute("ID")
                        fname = str(feat.attribute("Failinimi") or "")
                        z_val = float(feat.attribute("Korgus_EH2000") or 0.0)
                        agl_val = float(feat.attribute("Korgus_AGL") or 0.0)
                        yaw_val = float(feat.attribute("Suund_Yaw") or 0.0)
                        pitch_val = float(feat.attribute("Kalle_Pitch") or 0.0)
                        pt = g.asPoint() if not g.isMultipart() else g.asMultiPoint()[0]
                        photo_pts_3d.append({
                            "x_3301": float(pt.x()),
                            "y_3301": float(pt.y()),
                            "z_eh2000": z_val,
                            "agl_m": agl_val,
                            "yaw_deg": yaw_val,
                            "pitch_deg": pitch_val,
                            "shot_id": shot_id,
                            "filename": fname,
                        })
                    except Exception:
                        pass
                    continue

                feat_col, feat_width, feat_fill_col = _extract_feature_style(
                    feat, r, render_ctx, default_col=col, default_width=width, layer_opacity=lyr_op
                )
                feat_lines: List[np.ndarray] = []
                feat_pts: List[Tuple[float, float]] = []

                gtype = QgsWkbTypes.geometryType(g.wkbType())
                is_polygon = (gtype == QgsWkbTypes.GeometryType.PolygonGeometry)

                if gtype == QgsWkbTypes.GeometryType.PointGeometry:
                    lbl = str(feat.attribute(disp_idx)) if disp_idx >= 0 else ""
                    for pt in g.asMultiPoint() if g.isMultipart() else [g.asPoint()]:
                        p_xy = (float(pt.x()), float(pt.y()))
                        pts_abs.append((p_xy, lbl))
                        feat_pts.append(p_xy)

                elif gtype == QgsWkbTypes.GeometryType.LineGeometry:
                    parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
                    for part in parts:
                        if len(part) >= 2:
                            arr = np.array([[p.x(), p.y()] for p in part], dtype=np.float64)
                            dens = _densify_ring(arr, step=densify_step)
                            lines_abs.append(dens)
                            feat_lines.append(dens)

                elif gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
                    polys = g.asMultiPolygon() if g.isMultipart() else [g.asPolygon()]
                    for poly in polys:
                        for ring in poly:
                            if len(ring) >= 3:
                                arr = np.array([[p.x(), p.y()] for p in ring], dtype=np.float64)
                                dens = _densify_ring(arr, step=densify_step)
                                lines_abs.append(dens)
                                feat_lines.append(dens)

                if feat_lines or feat_pts:
                    features_list.append({
                        "feat_id": feat.id(),
                        "layer_id": lyr_id,
                        "layer_name": lyr.name(),
                        "color": feat_col,
                        "width": feat_width,
                        "fill_color": feat_fill_col,
                        "is_polygon": is_polygon,
                        "lines_abs": feat_lines,
                        "pts_abs": feat_pts,
                        "attributes": {f.name(): feat.attribute(f.name()) for f in lyr.fields()},
                    })
        except Exception:
            pass
        finally:
            if r is not None and hasattr(r, "stopRender"):
                try:
                    r.stopRender(render_ctx)
                except Exception:
                    pass

        if lines_abs or pts_abs or photo_pts_3d:
            extracted.append({
                "layer_id": lyr_id,
                "name": lyr.name(),
                "color": col,
                "width": width,
                "lines_abs": lines_abs,
                "pts_abs": pts_abs,
                "features": features_list,
                "is_photo_layer": is_photo_layer,
                "photo_pts_3d": photo_pts_3d,
            })

    return extracted
