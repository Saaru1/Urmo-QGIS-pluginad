# -*- coding: utf-8 -*-
"""
Drone Signal Strength Simulation Dialog (`DroneSignalDialog`) and 2D Canvas Overlay (`DroneSignalCanvas2DOverlay`).

Simulates Line-of-Sight (LOS) occlusion, 1st Fresnel zone clearance, Free Space Path Loss (FSPL),
and Visual Line of Sight (VLOS) between a ground controller (Homepoint) and UAVs (DJI Mavic 3E,
DJI Matrice 4T, etc.) across ALS terrain and 3D obstacle surfaces in both the 3D OpenGL viewport
and the 2D QGIS Map Canvas.
"""

import math
from typing import Optional, Tuple
import numpy as np

from qgis.PyQt.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QImage,
    QPainter,
    QPen,
    QRadialGradient,
)
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QSlider,
    QComboBox,
    QCheckBox,
    QGroupBox,
    QFrame,
    QProgressBar,
)
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
)
from qgis.gui import QgsMapCanvas, QgsMapCanvasItem, QgsMapToolEmitPoint

from ...core.signal_engine import (
    DroneSignalResult,
    compute_signal_coverage_grid,
    evaluate_live_drone_signal,
    evaluate_live_vlos,
    DRONE_PROFILES,
    ZONE_STRONG,
    ZONE_FAIR,
    ZONE_MARGINAL,
    ZONE_SHADOW,
    ZONE_COLORS,
    VLOS_CLEAR,
    VLOS_MARGINAL,
    VLOS_BVLOS,
    VLOS_BLOCKED,
)
from ...i18n import tr


# --------------------------------------------------------------------------- #
# 1. 2D Map Canvas Signal Coverage Overlay
# --------------------------------------------------------------------------- #
class DroneSignalCanvas2DOverlay(QgsMapCanvasItem):
    """
    Renders signal strength heat zones, Homepoint beacon, distance range rings,
    and the direct LOS link beam between Homepoint and drone on the main 2D QGIS canvas.
    """

    def __init__(self, canvas: QgsMapCanvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.setZValue(140.0)  # Render right below the drone chevron (150.0)

        self.enabled: bool = False  # Default OFF per user request (on-demand)
        self.signal_res: Optional[DroneSignalResult] = None
        self._heatmap_img: Optional[QImage] = None
        self._heatmap_bounds: Optional[Tuple[float, float, float, float]] = None  # (xmin, ymin, xmax, ymax) EPSG:3301
        self.home_abs: Optional[np.ndarray] = None

        # Live drone link telemetry
        self.drone_x_3301: Optional[float] = None
        self.drone_y_3301: Optional[float] = None
        self.drone_z_3301: Optional[float] = None
        self.live_signal_pct: float = 0.0
        self.live_zone_code: int = ZONE_STRONG
        self.live_is_occluded: bool = False
        self.live_dist_m: float = 0.0

        self._crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
        self.setVisible(False)

    def _update_visibility(self):
        """Visible if heatmap is enabled with data OR if live homepoint is active."""
        has_heatmap = self.enabled and (self._heatmap_img is not None)
        has_live_link = (self.home_abs is not None) or (self.signal_res is not None and self.signal_res.home_abs is not None)
        self.setVisible(bool(has_heatmap or has_live_link))

    def set_enabled(self, enabled: bool):
        self.enabled = bool(enabled)
        self._update_visibility()
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def set_homepoint(self, home_abs: Optional[np.ndarray]):
        """Sets or updates Homepoint coordinates for 2D beacon and live beam."""
        self.home_abs = np.array(home_abs, dtype=np.float64) if home_abs is not None else None
        self._update_visibility()
        self.prepareGeometryChange()
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def clear(self):
        """Completely clears all 2D signal data, heatmap, link line, and homepoint beacon."""
        self.signal_res = None
        self._heatmap_img = None
        self._heatmap_bounds = None
        self.home_abs = None
        self.drone_x_3301 = None
        self.drone_y_3301 = None
        self.drone_z_3301 = None
        self.live_signal_pct = 0.0
        self.live_zone_code = ZONE_STRONG
        self.live_is_occluded = False
        self.live_dist_m = 0.0
        self.setVisible(False)
        self.prepareGeometryChange()
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def set_signal_result(self, res: Optional[DroneSignalResult]):
        """Builds a cached ARGB heatmap raster from computed signal coverage grid."""
        self.signal_res = res
        if res is None or res.grid_zones.size == 0:
            self._heatmap_img = None
            self._heatmap_bounds = None
            self._update_visibility()
            self.update()
            return

        h, w = res.grid_zones.shape
        img = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(0)

        # Map grid zones to raster pixels
        zones = res.grid_zones
        for r in range(h):
            for c in range(w):
                z_code = int(zones[r, c])
                rgba = ZONE_COLORS.get(z_code, (0, 0, 0, 0))
                # OpenCV/Image row 0 is top (ymax), grid row 0 is ymin: invert row index
                img_row = (h - 1) - r
                img.setPixelColor(c, img_row, QColor(rgba[0], rgba[1], rgba[2], rgba[3]))

        self._heatmap_img = img
        self._heatmap_bounds = (
            float(res.grid_xs.min()),
            float(res.grid_ys.min()),
            float(res.grid_xs.max()),
            float(res.grid_ys.max()),
        )
        if res.home_abs is not None:
            self.home_abs = np.array(res.home_abs, dtype=np.float64)
        self._update_visibility()
        self.prepareGeometryChange()
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def update_live_link(
        self,
        drone_x_3301: float,
        drone_y_3301: float,
        drone_z_3301: float,
        signal_pct: float,
        zone_code: int = ZONE_STRONG,
        is_occluded: bool = False,
        dist_m: float = 0.0,
    ):
        """Updates live drone position and link status for drawing the direct LOS beam."""
        self.drone_x_3301 = float(drone_x_3301)
        self.drone_y_3301 = float(drone_y_3301)
        self.drone_z_3301 = float(drone_z_3301)
        self.live_signal_pct = float(signal_pct)
        self.live_zone_code = int(zone_code)
        self.live_is_occluded = bool(is_occluded)
        self.live_dist_m = float(dist_m)

        self._update_visibility()
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    # ------------------------------------------------------------------ #
    # Coordinate Transforms
    # ------------------------------------------------------------------ #
    def _to_canvas_crs(self, x_3301: float, y_3301: float) -> QgsPointXY:
        pt = QgsPointXY(x_3301, y_3301)
        if not self.canvas:
            return pt
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        if canvas_crs.isValid() and canvas_crs != self._crs_3301:
            try:
                xf = QgsCoordinateTransform(self._crs_3301, canvas_crs, QgsProject.instance())
                return xf.transform(pt)
            except Exception:
                pass
        return pt

    def _to_canvas_px(self, x_3301: float, y_3301: float) -> QPointF:
        map_pt = self._to_canvas_crs(x_3301, y_3301)
        return self.toCanvasCoordinates(map_pt)

    def boundingRect(self) -> QRectF:
        if not self.canvas:
            return QRectF()
        return QRectF(0.0, 0.0, float(self.canvas.width()), float(self.canvas.height()))

    # ------------------------------------------------------------------ #
    # Painting
    # ------------------------------------------------------------------ #
    def paint(self, painter: QPainter, option=None, widget=None):
        if not self.canvas:
            return

        painter.save()
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

            # Get Homepoint coordinates
            if self.home_abs is not None:
                hx_3301 = float(self.home_abs[0])
                hy_3301 = float(self.home_abs[1])
            elif self.signal_res is not None and self.signal_res.home_abs is not None:
                hx_3301 = float(self.signal_res.home_abs[0])
                hy_3301 = float(self.signal_res.home_abs[1])
            else:
                return

            home_px = self._to_canvas_px(hx_3301, hy_3301)
            mupp = max(0.05, float(self.canvas.mapUnitsPerPixel()))

            # 1. Draw Heatmap Raster (if enabled)
            if self.enabled and self._heatmap_img and self._heatmap_bounds:
                xmin, ymin, xmax, ymax = self._heatmap_bounds
                tl_px = self._to_canvas_px(xmin, ymax)
                br_px = self._to_canvas_px(xmax, ymin)
                target_rect = QRectF(tl_px, br_px).normalized()
                painter.drawImage(target_rect, self._heatmap_img)

                # Distance Range Rings
                max_sim_dist = float(self.signal_res.max_dist_m)
                ring_steps = [500.0, 1000.0, 2000.0, 3500.0, 5000.0, 8000.0, 12000.0]
                painter.setBrush(Qt.BrushStyle.NoBrush)

                f_ring = QFont("Segoe UI", 8)
                f_ring.setBold(True)
                painter.setFont(f_ring)

                for r_dist in ring_steps:
                    if r_dist > max_sim_dist * 1.05:
                        continue
                    r_px = r_dist / mupp
                    is_max = abs(r_dist - max_sim_dist) < 50.0

                    if is_max:
                        p_ring = QPen(QColor(239, 68, 68, 220), 1.8, Qt.PenStyle.DashLine)
                    else:
                        p_ring = QPen(QColor(56, 189, 248, 140), 1.0, Qt.PenStyle.DotLine)

                    painter.setPen(p_ring)
                    painter.drawEllipse(home_px, r_px, r_px)

                    # Ring distance tag on east axis
                    tag_x = home_px.x() + r_px + 4.0
                    tag_y = home_px.y() + 4.0
                    tag_txt = f"{r_dist / 1000.0:.1f} km" if r_dist >= 1000.0 else f"{r_dist:.0f} m"
                    painter.setPen(QColor(15, 23, 42, 220))
                    painter.drawText(QPointF(tag_x + 1, tag_y + 1), tag_txt)
                    painter.setPen(QColor(241, 245, 249) if not is_max else QColor(254, 202, 202))
                    painter.drawText(QPointF(tag_x, tag_y), tag_txt)

            # 2. Draw Direct Line-of-Sight Beam from Homepoint to Live Drone
            if self.drone_x_3301 is not None and self.drone_y_3301 is not None:
                drone_px = self._to_canvas_px(self.drone_x_3301, self.drone_y_3301)
                dist_px = math.hypot(drone_px.x() - home_px.x(), drone_px.y() - home_px.y())

                if dist_px > 3.0:
                    if self.live_is_occluded or self.live_zone_code == ZONE_SHADOW:
                        c_beam = QColor(239, 68, 68, 245)      # Red (Varjus / Katkenud)
                        p_halo = QPen(QColor(15, 23, 42, 200), 5.0, Qt.PenStyle.DashLine)
                        p_beam = QPen(c_beam, 2.4, Qt.PenStyle.DashLine)
                        c_badge = QColor(248, 113, 113)
                    elif self.live_zone_code == ZONE_MARGINAL or self.live_signal_pct < 40.0:
                        c_beam = QColor(249, 115, 22, 245)     # Orange (Nõrk)
                        p_halo = QPen(QColor(15, 23, 42, 190), 4.5, Qt.PenStyle.SolidLine)
                        p_beam = QPen(c_beam, 2.2, Qt.PenStyle.SolidLine)
                        c_badge = QColor(251, 146, 60)
                    elif self.live_zone_code == ZONE_FAIR or self.live_signal_pct < 75.0:
                        c_beam = QColor(234, 179, 8, 245)      # Yellow (Hea)
                        p_halo = QPen(QColor(15, 23, 42, 190), 4.5, Qt.PenStyle.SolidLine)
                        p_beam = QPen(c_beam, 2.2, Qt.PenStyle.SolidLine)
                        c_badge = QColor(253, 224, 71)
                    else:
                        c_beam = QColor(34, 197, 94, 245)      # Green (Tugev)
                        p_halo = QPen(QColor(15, 23, 42, 190), 4.5, Qt.PenStyle.SolidLine)
                        p_beam = QPen(c_beam, 2.2, Qt.PenStyle.SolidLine)
                        c_badge = QColor(52, 211, 153)

                    painter.setPen(p_halo)
                    painter.drawLine(home_px, drone_px)
                    painter.setPen(p_beam)
                    painter.drawLine(home_px, drone_px)

                    # Midpoint distance badge
                    mid_x = (home_px.x() + drone_px.x()) * 0.5
                    mid_y = (home_px.y() + drone_px.y()) * 0.5
                    lbl_txt = f"{self.live_dist_m:.0f}m"
                    f_mid = QFont("Segoe UI", 8)
                    f_mid.setBold(True)
                    painter.setFont(f_mid)
                    fm = QFontMetrics(f_mid)
                    bw = fm.horizontalAdvance(lbl_txt) + 8
                    bh = 16
                    b_rect = QRectF(mid_x - bw / 2, mid_y - bh / 2, float(bw), float(bh))
                    painter.setPen(QPen(QColor(15, 23, 42, 220), 1.0))
                    painter.setBrush(QBrush(QColor(15, 23, 42, 210)))
                    painter.drawRoundedRect(b_rect, 3.0, 3.0)
                    painter.setPen(c_badge)
                    painter.drawText(b_rect, Qt.AlignmentFlag.AlignCenter, lbl_txt)

            # 3. Draw Homepoint Beacon Marker
            rad_grad = QRadialGradient(home_px, 18.0)
            rad_grad.setColorAt(0.0, QColor(56, 189, 248, 230))
            rad_grad.setColorAt(0.65, QColor(56, 189, 248, 80))
            rad_grad.setColorAt(1.0, QColor(56, 189, 248, 0))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(rad_grad))
            painter.drawEllipse(home_px, 18.0, 18.0)

            # Outer ring
            painter.setPen(QPen(QColor(15, 23, 42, 220), 2.2))
            painter.setBrush(QBrush(QColor(56, 189, 248, 240)))
            painter.drawEllipse(home_px, 7.5, 7.5)

            # Inner beacon pin badge: Homepoint
            f_h = QFont("Segoe UI", 9)
            f_h.setBold(True)
            painter.setFont(f_h)
            h_badge_txt = "📍 Homepoint"
            fm_h = QFontMetrics(f_h)
            hw = fm_h.horizontalAdvance(h_badge_txt) + 12
            hh = 18
            h_rect = QRectF(home_px.x() - hw / 2, home_px.y() - 25.0, float(hw), float(hh))
            painter.setPen(QPen(QColor(56, 189, 248, 240), 1.2))
            painter.setBrush(QBrush(QColor(15, 23, 42, 230)))
            painter.drawRoundedRect(h_rect, 4.0, 4.0)
            painter.setPen(QColor(255, 255, 255))
            painter.drawText(h_rect, Qt.AlignmentFlag.AlignCenter, h_badge_txt)

        finally:
            painter.restore()


# --------------------------------------------------------------------------- #
# 2. Canvas Map Tool for Picking Homepoint
# --------------------------------------------------------------------------- #
class SignalHomepointTool(QgsMapToolEmitPoint):
    """Interactive 2D map tool for clicking anywhere on canvas to set Homepoint."""

    def __init__(self, canvas: QgsMapCanvas, on_point_picked):
        super().__init__(canvas)
        self.canvas = canvas
        self.on_point_picked = on_point_picked
        self.setCursor(Qt.CursorShape.CrossCursor)

    def canvasReleaseEvent(self, e):
        pt = self.toMapCoordinates(e.pos())
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")
        if canvas_crs.isValid() and canvas_crs != crs_3301:
            try:
                xf = QgsCoordinateTransform(canvas_crs, crs_3301, QgsProject.instance())
                pt = xf.transform(pt)
            except Exception:
                pass
        self.on_point_picked(float(pt.x()), float(pt.y()))


# --------------------------------------------------------------------------- #
# 3. Main Modeless Drone Signal Dialog
# --------------------------------------------------------------------------- #
class DroneSignalDialog(QDialog):
    """
    Independent Dark-Cockpit panel for Drone Controller Signal Strength Simulation.
    Simulates real-time RC link and VLOS by default, with optional on-demand 3D/2D coverage maps.
    """

    homepoint_changed = pyqtSignal(float, float, float)  # x, y, z_ground

    def __init__(self, viewer, panel_3d, parent=None):
        super().__init__(parent)
        self.viewer = viewer
        self.panel_3d = panel_3d
        self.canvas: Optional[QgsMapCanvas] = getattr(panel_3d, "canvas", None)

        self.setObjectName("MaruAlsDroneSignalDialog")
        self.setWindowTitle(tr("v3d_sig_title", fallback="📡 Drooni juhtsignaali simulatsioon (RC Link & LOS)"))
        self.resize(440, 710)
        self.setMinimumSize(380, 580)

        # Homepoint coordinates (EPSG:3301)
        self.home_abs: Optional[np.ndarray] = None
        self.home_local: Optional[np.ndarray] = None
        self.has_homepoint: bool = False

        # Simulation map parameters (manual display)
        self.flight_height_agl: float = 80.0
        self.max_dist_m: float = 3500.0
        self.drone_key: str = "mavic_3e"
        self.show_3d_mesh: bool = False   # Default OFF per user request (uncluttered 3D)
        self.show_2d_mesh: bool = False   # Default OFF

        # Latest result
        self.latest_result: Optional[DroneSignalResult] = None

        # 2D Overlay on Main Canvas
        self.overlay_2d: Optional[DroneSignalCanvas2DOverlay] = None
        if self.canvas:
            self.overlay_2d = DroneSignalCanvas2DOverlay(self.canvas)

        # Connect 3D viewer homepoint picking signal
        if hasattr(self.viewer, "homepoint_picked"):
            self.viewer.homepoint_picked.connect(self._on_3d_homepoint_picked)

        # Debounce timer for smooth slider responsiveness
        self._debounce_timer = QTimer(self)
        self._debounce_timer.setSingleShot(True)
        self._debounce_timer.setInterval(220)
        self._debounce_timer.timeout.connect(self._recompute_signal)

        self._active_map_tool = None
        self._prev_map_tool = None

        self._init_ui()

    # ------------------------------------------------------------------ #
    # UI Initialization
    # ------------------------------------------------------------------ #
    def _init_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0f172a;
                color: #f8fafc;
                font-family: 'Segoe UI', sans-serif;
            }
            QGroupBox {
                font-weight: bold;
                color: #38bdf8;
                border: 1px solid #334155;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 12px;
                background-color: #1e293b;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }
            QLabel {
                color: #cbd5e1;
                font-size: 11px;
            }
            QPushButton {
                background: #1e293b;
                color: #f1f5f9;
                border: 1px solid #475569;
                padding: 6px 12px;
                border-radius: 4px;
                font-weight: 500;
            }
            QPushButton:hover {
                background: #334155;
                border-color: #38bdf8;
            }
            QComboBox {
                background: #0f172a;
                color: #f8fafc;
                border: 1px solid #475569;
                padding: 5px 8px;
                border-radius: 4px;
            }
            QComboBox QAbstractItemView {
                background-color: #1e293b;
                color: #f8fafc;
                selection-background-color: #0284c7;
                selection-color: #ffffff;
                border: 1px solid #334155;
            }
            QComboBox QAbstractItemView::item {
                color: #f8fafc;
                background-color: #1e293b;
                min-height: 24px;
            }
            QComboBox QAbstractItemView::item:hover {
                background-color: #334155;
                color: #38bdf8;
            }
            QComboBox QAbstractItemView::item:selected {
                background-color: #0284c7;
                color: #ffffff;
            }
            QSlider::groove:horizontal {
                height: 5px;
                background: #334155;
                border-radius: 2px;
            }
            QSlider::sub-page:horizontal {
                background: #38bdf8;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                background: #f8fafc;
                border: 1px solid #0284c7;
                width: 14px;
                margin-top: -5px;
                margin-bottom: -5px;
                border-radius: 7px;
            }
            QCheckBox {
                color: #e2e8f0;
                font-size: 11px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # 1. Header Card
        hdr_row = QHBoxLayout()
        title_lbl = QLabel(tr("v3d_sig_title", fallback="📡 Drooni juhtsignaali simulatsioon (RC Link & VLOS)"), self)
        title_lbl.setStyleSheet("font-size: 14px; font-weight: bold; color: #38bdf8;")
        hdr_row.addWidget(title_lbl, 1)

        btn_close = QPushButton("✕", self)
        btn_close.setFixedSize(26, 26)
        btn_close.setStyleSheet("QPushButton { border-radius: 13px; padding: 0px; font-weight: bold; }")
        btn_close.clicked.connect(self.hide)
        hdr_row.addWidget(btn_close)
        layout.addLayout(hdr_row)

        desc_lbl = QLabel(
            tr("v3d_sig_desc", fallback="Reaalajas RC juhtsignaali tugevus ja visuaalne nähtavus (VLOS) arvutatakse automaatselt drooni aktiivselt lennukõrguselt ja distantsilt."),
            self,
        )
        desc_lbl.setWordWrap(True)
        desc_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
        layout.addWidget(desc_lbl)

        # 2. Section 1: Drone Model & Hardware Profile
        grp_drone = QGroupBox(tr("v3d_sig_drone_grp", fallback="1. Drooni mudel ja edastustehnoloogia"), self)
        lay_drone = QVBoxLayout(grp_drone)
        lay_drone.setSpacing(6)

        self.cmb_drone = QComboBox(grp_drone)
        self.cmb_drone.view().setStyleSheet("""
            QAbstractItemView {
                background-color: #1e293b;
                color: #f8fafc;
                selection-background-color: #0284c7;
                selection-color: #ffffff;
                border: 1px solid #334155;
                padding: 4px;
            }
            QAbstractItemView::item {
                min-height: 24px;
                color: #f8fafc;
            }
            QAbstractItemView::item:hover {
                background-color: #334155;
                color: #38bdf8;
            }
            QAbstractItemView::item:selected {
                background-color: #0284c7;
                color: #ffffff;
            }
        """)
        for key, prof in DRONE_PROFILES.items():
            max_km = prof["max_range_ce_m"] / 1000.0
            self.cmb_drone.addItem(f"{prof['name']} — {prof['tech']} (max {max_km:.0f} km CE)", key)
        self.cmb_drone.currentIndexChanged.connect(self._on_drone_model_changed)
        lay_drone.addWidget(self.cmb_drone)

        self.lbl_drone_specs = QLabel(grp_drone)
        self.lbl_drone_specs.setStyleSheet("color: #38bdf8; font-size: 10px; font-style: italic;")
        lay_drone.addWidget(self.lbl_drone_specs)
        layout.addWidget(grp_drone)

        # 3. Section 2: Homepoint Location (Ground Controller Antenna)
        grp_home = QGroupBox(tr("v3d_sig_home_grp", fallback="2. Kodupunkti (Homepoint / RC antenn) asukoht"), self)
        lay_home = QVBoxLayout(grp_home)
        lay_home.setSpacing(6)

        self.lbl_home_coords = QLabel(tr("v3d_sig_home_unset", fallback="Kodupunkt määramata. Klõpsa 'Vali kaardilt' või 'Sea drooni alla'."), grp_home)
        self.lbl_home_coords.setStyleSheet("font-family: Consolas, monospace; font-size: 10px; color: #f1f5f9; background: #0f172a; padding: 4px; border-radius: 4px; border: 1px solid #334155;")
        lay_home.addWidget(self.lbl_home_coords)

        home_btn_row = QHBoxLayout()
        self.btn_pick_home = QPushButton("📍 " + tr("v3d_sig_pick_map", fallback="Vali kaardilt / 3D vaatest"), grp_home)
        self.btn_pick_home.setStyleSheet("QPushButton { background: #0284c7; color: #ffffff; font-weight: bold; border-color: #38bdf8; } QPushButton:hover { background: #0369a1; }")
        self.btn_pick_home.clicked.connect(self._start_pick_homepoint)
        home_btn_row.addWidget(self.btn_pick_home, 1)

        self.btn_home_to_drone = QPushButton("🎯 " + tr("v3d_sig_home_drone", fallback="Sea drooni alla"), grp_home)
        self.btn_home_to_drone.clicked.connect(self._set_home_to_drone_pos)
        home_btn_row.addWidget(self.btn_home_to_drone, 1)
        lay_home.addLayout(home_btn_row)
        layout.addWidget(grp_home)

        # 4. Section 3: REAL-TIME FLIGHT TELEMETRY & LINK STATUS (DEFAULT PRIMARY MODE)
        grp_telemetry = QGroupBox(tr("v3d_sig_live_grp", fallback="3. Reaalajas RC link ja nähtavus (VLOS)"), self)
        lay_tele = QVBoxLayout(grp_telemetry)
        lay_tele.setSpacing(6)

        self.bar_signal = QProgressBar(grp_telemetry)
        self.bar_signal.setRange(0, 100)
        self.bar_signal.setValue(0)
        self.bar_signal.setStyleSheet("""
            QProgressBar {
                background: #0f172a;
                border: 1px solid #334155;
                border-radius: 4px;
                text-align: center;
                color: #94a3b8;
                font-weight: bold;
                height: 18px;
            }
            QProgressBar::chunk {
                background-color: #334155;
                border-radius: 3px;
            }
        """)
        lay_tele.addWidget(self.bar_signal)

        unset_msg = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
        self.lbl_live_status = QLabel(unset_msg, grp_telemetry)
        self.lbl_live_status.setStyleSheet("font-weight: bold; font-size: 11px; color: #94a3b8;")
        lay_tele.addWidget(self.lbl_live_status)

        self.lbl_live_vlos = QLabel(unset_msg, grp_telemetry)
        self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #94a3b8;")
        lay_tele.addWidget(self.lbl_live_vlos)

        self.lbl_live_dist = QLabel("", grp_telemetry)
        lay_tele.addWidget(self.lbl_live_dist)
        layout.addWidget(grp_telemetry)

        # 5. Section 4: SIMULATION COVERAGE MAP (3D MESH & 2D HEATMAP FOR MANUAL PLANNING)
        grp_params = QGroupBox(tr("v3d_sig_map_planning_grp", fallback="4. Simulatsiooni katvuskaart (3D pind & 2D kaart)"), self)
        lay_params = QVBoxLayout(grp_params)
        lay_params.setSpacing(8)

        # Map display checkboxes (Default OFF per user request)
        toggles_row = QHBoxLayout()
        self.chk_show_3d = QCheckBox(tr("v3d_sig_show_3d", fallback="Kuva 3D levisisu (pind)"), grp_params)
        self.chk_show_3d.setChecked(False)
        self.chk_show_3d.toggled.connect(self._on_3d_vis_toggled)
        toggles_row.addWidget(self.chk_show_3d)

        self.chk_show_2d = QCheckBox(tr("v3d_sig_show_2d", fallback="Kuva 2D soojuskaart"), grp_params)
        self.chk_show_2d.setChecked(False)
        self.chk_show_2d.toggled.connect(self._on_2d_vis_toggled)
        toggles_row.addWidget(self.chk_show_2d)
        lay_params.addLayout(toggles_row)

        # Flight Height Slider
        h_lbl_row = QHBoxLayout()
        lbl_h_title = QLabel(tr("v3d_sig_flight_h", fallback="Kavandatav lennukõrgus (AGL):"), grp_params)
        self.lbl_h_val = QLabel("80 m", grp_params)
        self.lbl_h_val.setStyleSheet("font-weight: bold; color: #38bdf8;")
        h_lbl_row.addWidget(lbl_h_title, 1)
        h_lbl_row.addWidget(self.lbl_h_val)
        lay_params.addLayout(h_lbl_row)

        self.sld_height = QSlider(Qt.Orientation.Horizontal, grp_params)
        self.sld_height.setRange(10, 500)
        self.sld_height.setValue(80)
        self.sld_height.setSingleStep(5)
        self.sld_height.valueChanged.connect(self._on_height_slider_changed)
        lay_params.addWidget(self.sld_height)

        h_quick_row = QHBoxLayout()
        for q_h in (30, 60, 120, 250):
            lbl = f"{q_h}m" if q_h != 120 else "120m (EU)"
            btn_qh = QPushButton(lbl, grp_params)
            btn_qh.setStyleSheet("font-size: 10px; padding: 2px 4px;")
            btn_qh.clicked.connect(lambda _, h=q_h: self.sld_height.setValue(h))
            h_quick_row.addWidget(btn_qh)
        lay_params.addLayout(h_quick_row)

        # Operational Distance Slider
        d_lbl_row = QHBoxLayout()
        lbl_d_title = QLabel(tr("v3d_sig_dist", fallback="Katvuskaardi raadius:"), grp_params)
        self.lbl_d_val = QLabel("3.5 km", grp_params)
        self.lbl_d_val.setStyleSheet("font-weight: bold; color: #38bdf8;")
        d_lbl_row.addWidget(lbl_d_title, 1)
        d_lbl_row.addWidget(self.lbl_d_val)
        lay_params.addLayout(d_lbl_row)

        self.sld_dist = QSlider(Qt.Orientation.Horizontal, grp_params)
        self.sld_dist.setRange(500, 12000)
        self.sld_dist.setValue(3500)
        self.sld_dist.setSingleStep(100)
        self.sld_dist.valueChanged.connect(self._on_dist_slider_changed)
        lay_params.addWidget(self.sld_dist)

        d_quick_row = QHBoxLayout()
        for q_d in (1000, 2500, 5000, 8000):
            lbl = f"{q_d / 1000.0:.1f} km"
            btn_qd = QPushButton(lbl, grp_params)
            btn_qd.setStyleSheet("font-size: 10px; padding: 2px 4px;")
            btn_qd.clicked.connect(lambda _, d=q_d: self.sld_dist.setValue(d))
            d_quick_row.addWidget(btn_qd)
        lay_params.addLayout(d_quick_row)

        self.btn_recompute = QPushButton("🔄 " + tr("v3d_sig_recalc_map", fallback="Arvuta katvuskaart"), grp_params)
        self.btn_recompute.clicked.connect(self._recompute_signal)
        lay_params.addWidget(self.btn_recompute)

        self.lbl_stats = QLabel("Tugev levi: — % · Varjutsoon (RTH): — %", grp_params)
        self.lbl_stats.setStyleSheet("color: #94a3b8; font-size: 10px;")
        lay_params.addWidget(self.lbl_stats)
        layout.addWidget(grp_params)

        # 6. Legend Strip
        legend_frame = QFrame(self)
        legend_frame.setStyleSheet("background: #1e293b; border-radius: 6px; padding: 6px;")
        lay_leg = QGridLayout(legend_frame)
        lay_leg.setContentsMargins(6, 6, 6, 6)
        lay_leg.setSpacing(6)

        def make_badge(col_hex, txt):
            lbl = QLabel(f"■ {txt}", legend_frame)
            lbl.setStyleSheet(f"color: {col_hex}; font-size: 10px; font-weight: bold;")
            return lbl

        lay_leg.addWidget(make_badge("#22c55e", tr("v3d_sig_leg_strong", fallback="Tugev (75–100%)")), 0, 0)
        lay_leg.addWidget(make_badge("#eab308", tr("v3d_sig_leg_fair", fallback="Hea (40–74%)")), 0, 1)
        lay_leg.addWidget(make_badge("#f97316", tr("v3d_sig_leg_marg", fallback="Piiripealne (10–39%)")), 1, 0)
        lay_leg.addWidget(make_badge("#ef4444", tr("v3d_sig_leg_shadow", fallback="Varjus / Katkenud (0%)")), 1, 1)
        layout.addWidget(legend_frame)

        self._update_drone_specs_display()

    # ------------------------------------------------------------------ #
    # Default Homepoint & Coordinate Initialization
    # ------------------------------------------------------------------ #
    def _init_default_homepoint(self):
        """Initializes Homepoint to scene origin on ground level or active drone location."""
        if hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None:
            ox = float(self.viewer.scene_origin[0])
            oy = float(self.viewer.scene_origin[1])
            gnd = self.viewer.ground_at(0.0, 0.0)
            g_z = float(gnd) if gnd is not None else 20.0
            self.set_homepoint_coords(ox, oy, g_z)
        else:
            self.set_homepoint_coords(658000.0, 6475000.0, 20.0)

    def set_homepoint_coords(self, x_abs: float, y_abs: float, z_gnd: Optional[float] = None):
        """Sets the Homepoint absolute EPSG:3301 coordinates and triggers simulation."""
        ox = float(self.viewer.scene_origin[0]) if (hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None) else 0.0
        oy = float(self.viewer.scene_origin[1]) if (hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None) else 0.0

        lx = x_abs - ox
        ly = y_abs - oy

        if z_gnd is None:
            g = self.viewer.ground_at(lx, ly)
            z_gnd = float(g) if g is not None else 20.0

        lz = z_gnd
        lz_ant = lz + 1.8  # Ground controller antenna in pilot's hands (+1.8m AGL)

        self.home_abs = np.array([x_abs, y_abs, z_gnd], dtype=np.float64)
        self.home_local = np.array([lx, ly, lz_ant], dtype=np.float64)
        self.has_homepoint = True

        self.lbl_home_coords.setText(
            f"X: {x_abs:.1f}  Y: {y_abs:.1f}\nZ_pind: {z_gnd:.1f}m  (Antenn: {z_gnd + 1.8:.1f}m / +1.8m AGL)"
        )

        if hasattr(self.viewer, "set_homepoint"):
            self.viewer.set_homepoint(x_abs, y_abs, z_gnd)

        if self.overlay_2d:
            self.overlay_2d.set_homepoint(self.home_abs)

        self.homepoint_changed.emit(x_abs, y_abs, z_gnd)

        # Only recompute coverage mesh if 3D or 2D coverage map is turned on
        if self.show_3d_mesh or self.show_2d_mesh:
            self._trigger_recompute()
        else:
            self.update_live_telemetry()

    def _set_home_to_drone_pos(self):
        """Copies the current 3D drone position (X, Y) and sets Homepoint at ground level."""
        if not hasattr(self.viewer, "cam") or self.viewer.cam is None:
            return
        ox = float(self.viewer.scene_origin[0]) if (hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None) else 0.0
        oy = float(self.viewer.scene_origin[1]) if (hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None) else 0.0

        dx_local = float(self.viewer.cam[0])
        dy_local = float(self.viewer.cam[1])
        x_abs = dx_local + ox
        y_abs = dy_local + oy

        g = self.viewer.ground_at(dx_local, dy_local)
        z_gnd = float(g) if g is not None else float(self.viewer.cam[2]) - 10.0
        self.set_homepoint_coords(x_abs, y_abs, z_gnd)

    # ------------------------------------------------------------------ #
    # Interactive 2D Map & 3D View Homepoint Picking
    # ------------------------------------------------------------------ #
    def _start_pick_homepoint(self):
        self.btn_pick_home.setText("🎯 " + tr("v3d_sig_picking", fallback="Klõpsa 2D kaardil või 3D vaates..."))
        if self.canvas:
            self._prev_map_tool = self.canvas.mapTool()
            self._active_map_tool = SignalHomepointTool(self.canvas, self._on_canvas_point_picked)
            self.canvas.setMapTool(self._active_map_tool)
        if hasattr(self.viewer, "set_homepoint_pick_mode"):
            self.viewer.set_homepoint_pick_mode(True)

    def _on_canvas_point_picked(self, x_3301: float, y_3301: float):
        if self._prev_map_tool and self.canvas:
            self.canvas.setMapTool(self._prev_map_tool)
        self._active_map_tool = None
        if hasattr(self.viewer, "set_homepoint_pick_mode"):
            self.viewer.set_homepoint_pick_mode(False)
        self.btn_pick_home.setText("📍 " + tr("v3d_sig_pick_map", fallback="Vali kaardilt / 3D vaatest"))
        self.set_homepoint_coords(x_3301, y_3301)

    def _on_3d_homepoint_picked(self, x_3301: float, y_3301: float, z_gnd: float):
        if self._prev_map_tool and self.canvas:
            self.canvas.setMapTool(self._prev_map_tool)
        self._active_map_tool = None
        if hasattr(self.viewer, "set_homepoint_pick_mode"):
            self.viewer.set_homepoint_pick_mode(False)
        self.btn_pick_home.setText("📍 " + tr("v3d_sig_pick_map", fallback="Vali kaardilt / 3D vaatest"))
        self.set_homepoint_coords(x_3301, y_3301, z_gnd)

    # ------------------------------------------------------------------ #
    # Sliders & Value Changes
    # ------------------------------------------------------------------ #
    def _on_drone_model_changed(self):
        key = str(self.cmb_drone.currentData())
        self.drone_key = key
        self._update_drone_specs_display()

        if hasattr(self.viewer, "set_drone_profile"):
            self.viewer.set_drone_profile(key)

        # Adjust maximum range slider limit if drone has longer reach
        prof = DRONE_PROFILES.get(self.drone_key, DRONE_PROFILES["mavic_3e"])
        max_ce = int(prof["max_range_ce_m"])
        self.sld_dist.setMaximum(max_ce)
        if self.sld_dist.value() > max_ce:
            self.sld_dist.setValue(max_ce)

        if self.show_3d_mesh or self.show_2d_mesh:
            self._trigger_recompute()
        else:
            self.update_live_telemetry()

    def _update_drone_specs_display(self):
        prof = DRONE_PROFILES.get(self.drone_key, DRONE_PROFILES["mavic_3e"])
        max_km = prof["max_range_ce_m"] / 1000.0
        vlos_m = prof.get("vlos_max_m", 500.0)
        self.lbl_drone_specs.setText(
            f"Pult: {prof['controller']} · Max CE: {max_km:.1f} km · VLOS piir: ~{vlos_m:.0f}m"
        )

    def _on_height_slider_changed(self, val: int):
        self.flight_height_agl = float(val)
        self.lbl_h_val.setText(f"{val} m")
        if self.show_3d_mesh or self.show_2d_mesh:
            self._trigger_recompute()

    def _on_dist_slider_changed(self, val: int):
        self.max_dist_m = float(val)
        self.lbl_d_val.setText(f"{val / 1000.0:.1f} km" if val >= 1000 else f"{val} m")
        if self.show_3d_mesh or self.show_2d_mesh:
            self._trigger_recompute()

    def _on_3d_vis_toggled(self, checked: bool):
        self.show_3d_mesh = bool(checked)
        if hasattr(self.viewer, "show_signal_3d"):
            self.viewer.show_signal_3d = self.show_3d_mesh
            if self.show_3d_mesh and self.latest_result is None:
                self._recompute_signal()
            else:
                self.viewer.update()

    def _on_2d_vis_toggled(self, checked: bool):
        self.show_2d_mesh = bool(checked)
        if self.overlay_2d:
            self.overlay_2d.set_enabled(self.show_2d_mesh)
            if self.show_2d_mesh and self.latest_result is None:
                self._recompute_signal()

    def _trigger_recompute(self):
        """Starts debounced recomputation timer."""
        self._debounce_timer.start()

    # ------------------------------------------------------------------ #
    # Core Signal Simulation Engine Invocation
    # ------------------------------------------------------------------ #
    def _recompute_signal(self):
        if not self.has_homepoint:
            return

        def ground_fn(xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
            return self.viewer.ground_at_vec(xs, ys, fallback=float(self.home_local[2] - 1.8))

        def surface_fn(xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
            surf = self.viewer.surface_at_vec(xs, ys)
            gnd = ground_fn(xs, ys)
            return np.where(np.isfinite(surf) & (surf > -1000.0), np.maximum(surf, gnd), gnd)

        # Compute signal coverage grid (vectorized 44x44 raymarching)
        res = compute_signal_coverage_grid(
            home_local=self.home_local,
            flight_height_agl=self.flight_height_agl,
            max_dist_m=self.max_dist_m,
            drone_key=self.drone_key,
            ground_vec_fn=ground_fn,
            surface_vec_fn=surface_fn,
            grid_steps=44,
        )
        res.home_abs = self.home_abs.copy()
        self.latest_result = res

        # 1. Update 3D OpenGL Viewport
        if hasattr(self.viewer, "set_signal_result"):
            self.viewer.set_signal_result(res)

        # 2. Update 2D Main Canvas Overlay
        if self.overlay_2d:
            self.overlay_2d.set_signal_result(res)

        # 3. Update Statistics in Dialog
        self.lbl_stats.setText(
            f"Tugev levi (LOS): {res.strong_pct:.1f}% · Varjutsoon (RTH): {res.shadow_pct:.1f}%"
        )

        self.update_live_telemetry()

    # ------------------------------------------------------------------ #
    # Real-Time Telemetry Updates (Triggered on 3D Drone Flight)
    # ------------------------------------------------------------------ #
    def update_live_telemetry(self):
        """Evaluates live signal strength and VLOS between Homepoint and live drone camera."""
        if not self.has_homepoint or self.home_local is None or not hasattr(self.viewer, "cam") or self.viewer.cam is None:
            unset_msg = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
            if hasattr(self, "lbl_live_status"):
                self.lbl_live_status.setText(unset_msg)
                self.lbl_live_status.setStyleSheet("font-weight: bold; font-size: 11px; color: #94a3b8;")
            if hasattr(self, "lbl_live_vlos"):
                self.lbl_live_vlos.setText(unset_msg)
                self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #94a3b8;")
            if hasattr(self, "bar_signal"):
                self.bar_signal.setValue(0)
            if hasattr(self, "lbl_live_dist"):
                self.lbl_live_dist.setText("")
            return

        drone_local = self.viewer.cam
        ox = float(self.viewer.scene_origin[0]) if (hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None) else 0.0
        oy = float(self.viewer.scene_origin[1]) if (hasattr(self.viewer, "scene_origin") and self.viewer.scene_origin is not None) else 0.0

        drone_x_3301 = float(drone_local[0]) + ox
        drone_y_3301 = float(drone_local[1]) + oy
        drone_z_3301 = float(drone_local[2])

        def surface_fn(xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
            surf = self.viewer.surface_at_vec(xs, ys)
            gnd = self.viewer.ground_at_vec(xs, ys, fallback=0.0)
            return np.where(np.isfinite(surf) & (surf > -1000.0), np.maximum(surf, gnd), gnd)

        # 1. Evaluate RC link
        sig_pct, zone_code, status_txt, is_occluded, dist_3d = evaluate_live_drone_signal(
            home_local=self.home_local,
            drone_pos3=drone_local,
            drone_key=self.drone_key,
            surface_vec_fn=surface_fn,
        )

        # 2. Evaluate VLOS (Visual Line of Sight)
        vlos_code, vlos_txt, vlos_dist = evaluate_live_vlos(
            home_local=self.home_local,
            drone_pos3=drone_local,
            drone_key=self.drone_key,
            surface_vec_fn=surface_fn,
        )

        # Update Progress Bar & Status Text
        self.bar_signal.setValue(int(sig_pct))
        if is_occluded or zone_code == ZONE_SHADOW:
            col_bar = "#ef4444"
            status_prefix = "🔴"
            status_color = "#f87171"
        elif zone_code == ZONE_MARGINAL:
            col_bar = "#f97316"
            status_prefix = "🟠"
            status_color = "#fb923c"
        elif zone_code == ZONE_FAIR:
            col_bar = "#eab308"
            status_prefix = "🟡"
            status_color = "#fde047"
        else:
            col_bar = "#10b981"
            status_prefix = "🟢"
            status_color = "#34d399"

        self.bar_signal.setStyleSheet(f"""
            QProgressBar {{
                background: #0f172a;
                border: 1px solid #334155;
                border-radius: 4px;
                text-align: center;
                color: #ffffff;
                font-weight: bold;
                height: 18px;
            }}
            QProgressBar::chunk {{
                background: {col_bar};
                border-radius: 3px;
            }}
        """)

        self.lbl_live_status.setText(f"{status_prefix} {sig_pct:.0f}% — {status_txt}")
        self.lbl_live_status.setStyleSheet(f"font-weight: bold; font-size: 11px; color: {status_color};")

        # VLOS status display
        if vlos_code == VLOS_BLOCKED:
            self.lbl_live_vlos.setText(f"🔴 VLOS: {vlos_txt} (Takistus varjab vaate!)")
            self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #f87171;")
        elif vlos_code == VLOS_BVLOS:
            self.lbl_live_vlos.setText(f"🟡 VLOS: {vlos_txt} (Inimsilma eralduspiir ületatud)")
            self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #fde047;")
        elif vlos_code == VLOS_MARGINAL:
            self.lbl_live_vlos.setText(f"🟠 VLOS: {vlos_txt} (Piiripealne visuaalne kontakt)")
            self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #fb923c;")
        else:
            self.lbl_live_vlos.setText(f"🟢 VLOS: {vlos_txt} (Otsenähtavus selge)")
            self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #34d399;")

        dist_2d = math.hypot(drone_x_3301 - self.home_abs[0], drone_y_3301 - self.home_abs[1])
        dz = drone_z_3301 - self.home_abs[2]
        self.lbl_live_dist.setText(
            f"Kaugus kodust: {dist_2d:.0f} m (3D: {dist_3d:.0f} m, ΔZ: {dz:+.1f} m)"
        )

        # Push to 2D Canvas Overlay
        if self.overlay_2d:
            self.overlay_2d.update_live_link(
                drone_x_3301=drone_x_3301,
                drone_y_3301=drone_y_3301,
                drone_z_3301=drone_z_3301,
                signal_pct=sig_pct,
                zone_code=zone_code,
                is_occluded=is_occluded,
                dist_m=dist_3d,
            )

    def closeEvent(self, event):
        """Clean up map tools when closing dialog."""
        if self._active_map_tool and self.canvas:
            if self._prev_map_tool:
                self.canvas.setMapTool(self._prev_map_tool)
            self._active_map_tool = None
        if hasattr(self.viewer, "set_homepoint_pick_mode"):
            self.viewer.set_homepoint_pick_mode(False)
        super().closeEvent(event)

    def clear_session(self):
        """Completely resets Homepoint, simulation results, and 2D canvas overlay."""
        self.has_homepoint = False
        self.home_abs = None
        self.home_local = None
        self.latest_result = None
        self.show_3d_mesh = False
        self.show_2d_mesh = False

        if hasattr(self, "chk_show_3d"):
            self.chk_show_3d.blockSignals(True)
            self.chk_show_3d.setChecked(False)
            self.chk_show_3d.blockSignals(False)

        if hasattr(self, "chk_show_2d"):
            self.chk_show_2d.blockSignals(True)
            self.chk_show_2d.setChecked(False)
            self.chk_show_2d.blockSignals(False)

        if hasattr(self, "btn_pick_home"):
            self.btn_pick_home.setText("📍 " + tr("v3d_sig_pick_map", fallback="Vali kaardilt / 3D vaatest"))

        if hasattr(self, "lbl_home_coords"):
            self.lbl_home_coords.setText(
                tr("v3d_sig_home_unset", fallback="Kodupunkt määramata. Klõpsa 'Vali kaardilt' või 'Sea drooni alla'.")
            )

        if hasattr(self, "bar_signal"):
            self.bar_signal.setValue(0)
            self.bar_signal.setStyleSheet("""
                QProgressBar {
                    background: #0f172a;
                    border: 1px solid #334155;
                    border-radius: 4px;
                    text-align: center;
                    color: #94a3b8;
                    font-weight: bold;
                    height: 18px;
                }
                QProgressBar::chunk {
                    background-color: #334155;
                    border-radius: 3px;
                }
            """)

        unset_msg = tr("v3d_tele_no_homepoint", fallback="Kodupunkt määramata")
        if hasattr(self, "lbl_live_status"):
            self.lbl_live_status.setText(unset_msg)
            self.lbl_live_status.setStyleSheet("font-weight: bold; font-size: 11px; color: #94a3b8;")

        if hasattr(self, "lbl_live_vlos"):
            self.lbl_live_vlos.setText(unset_msg)
            self.lbl_live_vlos.setStyleSheet("font-weight: bold; font-size: 11px; color: #94a3b8;")

        if hasattr(self, "lbl_live_dist"):
            self.lbl_live_dist.setText("")

        if hasattr(self, "lbl_stats"):
            self.lbl_stats.setText("Tugev levi: — % · Varjutsoon (RTH): — %")

        # Clear 2D overlay on canvas
        if self.overlay_2d:
            self.overlay_2d.clear()

        # Clear 3D viewer homepoint and signal mesh
        if hasattr(self.viewer, "clear_homepoint"):
            self.viewer.clear_homepoint()
