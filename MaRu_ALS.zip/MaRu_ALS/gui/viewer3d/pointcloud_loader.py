# -*- coding: utf-8 -*-
"""
LAZ & Raster (DSM/DTM/Orthophoto) -> numpy loader for the custom 3D viewer,
including live percentage progress reporting and Vertical Wall & Void Infill synthesis.
"""

import datetime
import math
import os
import queue
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from typing import Callable, Optional

import numpy as np
from qgis.PyQt.QtCore import QThread, pyqtSignal
from qgis.core import Qgis, QgsApplication, QgsMessageLog

from ...core.cache_manager import CacheManager
from ...core.downloader import resolve_raster_path
from ...core.grid_engine import GridEngine

CACHE_VERSION = 2
MAX_POINTS_PER_TILE = 6_000_000
GROUND_CELL = 5.0            # m, ground (DTM-like) grid resolution used for AGL
GPS_EPOCH = datetime.datetime(1980, 1, 6)


def find_pdal() -> Optional[str]:
    """Locate pdal.exe shipped with QGIS."""
    candidates = []
    try:
        prefix = QgsApplication.prefixPath()
        candidates.append(os.path.normpath(os.path.join(prefix, "..", "..", "bin", "pdal.exe")))
    except Exception:
        pass
    candidates.append(os.path.join(os.path.dirname(sys.executable), "pdal.exe"))
    candidates.append(os.path.normpath(os.path.join(os.path.dirname(sys.executable), "..", "..", "bin", "pdal.exe")))
    which = shutil.which("pdal")
    if which:
        candidates.append(which)
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def npz_cache_path(laz_path: str) -> str:
    folder = os.path.join(CacheManager.get_cache_dir(), "3d")
    os.makedirs(folder, exist_ok=True)
    base = os.path.splitext(os.path.basename(laz_path))[0]
    p3 = os.path.join(folder, f"{base}_v3.npz")
    if os.path.exists(p3):
        return p3
    return os.path.join(folder, f"{base}_v{CACHE_VERSION}.npz")


def _read_global_encoding(laz_path: str) -> int:
    try:
        with open(laz_path, "rb") as f:
            hdr = f.read(8)
        return struct.unpack_from("<H", hdr, 6)[0]
    except Exception:
        return 0


def _fill_nan_grid(grid: np.ndarray, iterations: int = 40) -> np.ndarray:
    """Fills NaN cells by iterative neighbour averaging (fast inpainting)."""
    g = grid.copy()
    for _ in range(iterations):
        mask = np.isnan(g)
        if not mask.any():
            break
        padded = np.pad(g, 1, mode="edge")
        stack = np.stack([
            padded[:-2, 1:-1], padded[2:, 1:-1], padded[1:-1, :-2], padded[1:-1, 2:]
        ])
        with np.errstate(invalid="ignore"):
            cnt = np.sum(~np.isnan(stack), axis=0)
            sm = np.nansum(stack, axis=0)
            mean = np.where(cnt > 0, sm / np.maximum(cnt, 1), np.nan)
        g[mask] = mean[mask]
    if np.isnan(g).any():
        valid = g[~np.isnan(g)]
        g[np.isnan(g)] = float(np.median(valid)) if valid.size else 0.0
    return g


def synthesize_vertical_infill(data: dict, dsm_grid: Optional[np.ndarray] = None) -> dict:
    """
    Synthesizes 3D infill points for:
    1. Steep vertical walls, castle bastions, building facades, and embankments where
       airborne LiDAR beams missed the vertical wall face between ground and roof/parapet.
    2. Unscanned surface voids (such as castle moats, water channels, and steep wall shadows).
    """
    pos_all = data["pos"]
    cls_all = data["cls"]
    inten_all = data["inten"]
    has_rgb = bool(data.get("has_rgb", False))
    rgb_all = data["rgb"] if has_rgb and len(data.get("rgb", [])) == len(pos_all) else None
    ground = data["ground"]  # (200, 200) at 5m cell

    # Since `pos` is already randomly shuffled, use up to 850,000 points for fast (<0.1s) wall/void analysis
    s_lim = min(len(pos_all), 850_000)
    pos = pos_all[:s_lim]
    cls = cls_all[:s_lim]
    inten = inten_all[:s_lim]
    rgb = rgb_all[:s_lim] if rgb_all is not None else None

    # 1. Build a 1.25 m resolution grid (800 x 800) over the 1000m x 1000m tile
    gn = 800
    cell = 1000.0 / gn  # 1.25 m

    # Filter out atmospheric noise (7, 18), water (9), and high vegetation (5) for structural wall detection,
    # but keep buildings (6), ground/walls (2), unclassified structures (1), bridges (17), low/med veg (3,4)
    struct_mask = (cls != 7) & (cls != 18) & (cls != 9) & (cls != 5)
    if np.sum(struct_mask) < 200:
        # Not enough structural land points in tile (e.g. open sea) to form vertical walls
        return {
            "infill_pos": np.zeros((0, 3), dtype=np.float32),
            "infill_cls": np.zeros(0, dtype=np.uint8),
            "infill_inten": np.zeros(0, dtype=np.float32),
            "infill_rgb": np.zeros((0, 3), dtype=np.uint8),
            "infill_n": 0,
        }

    sp = pos[struct_mask]
    sc = cls[struct_mask]
    si = inten[struct_mask]
    sr = rgb[struct_mask] if rgb is not None else None

    ix = np.clip((sp[:, 0] / cell).astype(np.int32), 0, gn - 1)
    iy = np.clip((sp[:, 1] / cell).astype(np.int32), 0, gn - 1)
    flat_idx = iy * gn + ix

    # Top structural Z per 1.25m cell
    z_top_flat = np.full(gn * gn, -np.inf, dtype=np.float32)
    np.maximum.at(z_top_flat, flat_idx, sp[:, 2])
    z_top = z_top_flat.reshape(gn, gn)

    # Filter out isolated 1-cell noise spikes (e.g. sea spray, birds, waves, isolated artifacts):
    # A genuine building wall or castle bastion has multiple continuous structural cells.
    valid_struct = np.isfinite(z_top)
    pad_s = np.pad(valid_struct.astype(np.int8), 1, mode="constant", constant_values=0)
    nb_struct_cnt = (
        pad_s[:-2, :-2] + pad_s[:-2, 1:-1] + pad_s[:-2, 2:] +
        pad_s[1:-1, :-2]                   + pad_s[1:-1, 2:] +
        pad_s[2:, :-2]  + pad_s[2:, 1:-1]  + pad_s[2:, 2:]
    )
    # Require at least 2 structural neighbours to prevent single-pixel columns / glitch pillars
    is_spike = valid_struct & (nb_struct_cnt < 2)
    z_top = np.where(is_spike, -np.inf, z_top)

    # Also capture representative index of highest point per cell for RGB/class lookup
    order = np.argsort(sp[:, 2])
    rep_idx_flat = np.full(gn * gn, -1, dtype=np.int32)
    rep_idx_flat[flat_idx[order]] = order
    rep_idx = rep_idx_flat.reshape(gn, gn)
    rep_idx = np.where(is_spike, -1, rep_idx)

    # Upsample 5m ground grid to 800x800
    g_n = ground.shape[0]
    g_map = np.clip((np.arange(gn) * cell / (1000.0 / g_n)).astype(np.int32), 0, g_n - 1)
    z_ground = ground[np.ix_(g_map, g_map)].astype(np.float32)

    if dsm_grid is not None and dsm_grid.shape[0] >= 200:
        dn = dsm_grid.shape[0]
        d_map = np.clip((np.arange(gn) * cell / (1000.0 / dn)).astype(np.int32), 0, dn - 1)
        dsm_up = dsm_grid[np.ix_(d_map, d_map)].astype(np.float32)
        valid_dsm = np.isfinite(dsm_up) & (dsm_up > -100.0)
        z_top = np.where(np.isfinite(z_top), np.maximum(z_top, np.where(valid_dsm, dsm_up, z_top)), np.where(valid_dsm, dsm_up, z_ground))
    else:
        # Close tiny 1-cell gaps inside roofs/walls by 3x3 max dilation on valid structural cells
        valid_top = np.isfinite(z_top)
        padded = np.pad(np.where(valid_top, z_top, -np.inf), 1, mode="edge")
        nb_max = np.maximum.reduce([
            padded[:-2, 1:-1], padded[2:, 1:-1], padded[1:-1, :-2], padded[1:-1, 2:]
        ])
        nb_cnt = (
            np.isfinite(padded[:-2, 1:-1]).astype(np.int8)
            + np.isfinite(padded[2:, 1:-1]).astype(np.int8)
            + np.isfinite(padded[1:-1, :-2]).astype(np.int8)
            + np.isfinite(padded[1:-1, 2:]).astype(np.int8)
        )
        fill_hole = (~valid_top) & (nb_cnt >= 3) & np.isfinite(nb_max)
        z_top = np.where(fill_hole, nb_max, z_top)
        z_top = np.where(np.isfinite(z_top), z_top, z_ground)

    # Propagate rep_idx into 1-cell dilated holes
    for shift_y, shift_x in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        missing = rep_idx < 0
        if not missing.any():
            break
        rolled = np.roll(rep_idx, (shift_y, shift_x), axis=(0, 1))
        rep_idx = np.where(missing & (rolled >= 0), rolled, rep_idx)

    # 2. Detect vertical wall edges (4-connected neighbours with height jump 1.6m .. 42.0m)
    wall_pts_list = []
    wall_cls_list = []
    wall_inten_list = []
    wall_rgb_list = []

    rng = np.random.default_rng(777)

    for dy, dx in ((0, 1), (1, 0)):
        if dy == 0:
            z_a, z_b = z_top[:, :-1], z_top[:, 1:]
            idx_a, idx_b = rep_idx[:, :-1], rep_idx[:, 1:]
            iy_grid, ix_grid = np.meshgrid(np.arange(gn), np.arange(gn - 1), indexing="ij")
            wx = (ix_grid + 1.0) * cell
            wy = (iy_grid + 0.5) * cell
        else:
            z_a, z_b = z_top[:-1, :], z_top[1:, :]
            idx_a, idx_b = rep_idx[:-1, :], rep_idx[1:, :]
            iy_grid, ix_grid = np.meshgrid(np.arange(gn - 1), np.arange(gn), indexing="ij")
            wx = (ix_grid + 0.5) * cell
            wy = (iy_grid + 1.0) * cell

        dz = np.abs(z_a - z_b)
        has_struct_a = idx_a >= 0
        has_struct_b = idx_b >= 0
        # A wall requires a steep jump (1.6m..45m) AND at least one side must be a verified structural surface
        is_wall = (dz >= 1.6) & (dz <= 45.0) & (has_struct_a | has_struct_b)
        if not is_wall.any():
            continue

        wy_m = wy[is_wall]
        wx_m = wx[is_wall]
        z_hi = np.maximum(z_a[is_wall], z_b[is_wall])
        z_lo = np.minimum(z_a[is_wall], z_b[is_wall])
        a_higher = z_a[is_wall] >= z_b[is_wall]
        hi_idx = np.where(a_higher, idx_a[is_wall], idx_b[is_wall])
        lo_idx = np.where(a_higher, idx_b[is_wall], idx_a[is_wall])

        # Ensure higher side has a valid structural point
        valid_hi = hi_idx >= 0
        if not valid_hi.any():
            continue
        wy_m = wy_m[valid_hi]
        wx_m = wx_m[valid_hi]
        z_hi = z_hi[valid_hi]
        z_lo = z_lo[valid_hi]
        hi_idx = hi_idx[valid_hi]
        lo_idx = lo_idx[valid_hi]

        # Number of vertical steps (every 0.45 m)
        dz_m = z_hi - z_lo
        n_steps = np.clip(np.ceil(dz_m / 0.45).astype(np.int32), 2, 70)
        max_s = int(n_steps.max()) if n_steps.size else 0

        for s in range(1, max_s):
            active = n_steps > s
            if not active.any():
                break
            frac = (s / n_steps[active]).astype(np.float32)
            pz = z_lo[active] + frac * dz_m[active]
            # Slight tangent jitter so wall looks like natural stone/facade point cloud
            jx = rng.uniform(-0.35, 0.35, size=pz.shape[0]).astype(np.float32)
            jy = rng.uniform(-0.35, 0.35, size=pz.shape[0]).astype(np.float32)
            px = wx_m[active] + (jx if dy == 1 else jx * 0.18)
            py = wy_m[active] + (jy if dx == 1 else jy * 0.18)
            wall_pts_list.append(np.column_stack([px, py, pz]).astype(np.float32))

            h_i = np.clip(hi_idx[active], 0, len(sp) - 1)
            l_i = np.clip(lo_idx[active], 0, len(sp) - 1)
            w_cls = sc[h_i]
            w_int = (0.35 * si[l_i] + 0.65 * si[h_i]) * 0.9
            wall_cls_list.append(w_cls)
            wall_inten_list.append(w_int.astype(np.float32))

            if sr is not None:
                # Blend top and bottom RGB and shade slightly (0.86x) for vertical surface relief
                c_hi = sr[h_i].astype(np.float32)
                c_lo = sr[l_i].astype(np.float32)
                c_mix = (c_lo * (1.0 - frac[:, None]) + c_hi * frac[:, None]) * 0.88
                wall_rgb_list.append(np.clip(c_mix, 0, 255).astype(np.uint8))

    # 3. Unscanned Void / Moat Surface Infill (2.5m grid where point count == 0)
    # Only infill enclosed castle moats, courtyards and shadow gaps near scanned land (<30m);
    # do NOT fill open sea or ocean expanses.
    vn = 400
    vcell = 1000.0 / vn  # 2.5 m
    all_ix = np.clip((pos[:, 0] / vcell).astype(np.int32), 0, vn - 1)
    all_iy = np.clip((pos[:, 1] / vcell).astype(np.int32), 0, vn - 1)
    counts = np.zeros((vn, vn), dtype=np.int32)
    np.add.at(counts, (all_iy, all_ix), 1)

    has_scanned = counts > 0
    if has_scanned.sum() >= 600:
        try:
            from scipy.ndimage import binary_dilation
            near_land = binary_dilation(has_scanned, iterations=12)
        except Exception:
            near_land = True
        void_mask = (counts == 0) & near_land
    else:
        void_mask = np.zeros((vn, vn), dtype=bool)

    if void_mask.any():
        vy_idx, vx_idx = np.nonzero(void_mask)
        vx = (vx_idx + 0.5) * vcell + rng.uniform(-0.6, 0.6, size=vx_idx.size).astype(np.float32)
        vy = (vy_idx + 0.5) * vcell + rng.uniform(-0.6, 0.6, size=vy_idx.size).astype(np.float32)
        g_ix = np.clip((vx / GROUND_CELL).astype(np.int32), 0, g_n - 1)
        g_iy = np.clip((vy / GROUND_CELL).astype(np.int32), 0, g_n - 1)
        vz = ground[g_iy, g_ix].astype(np.float32)

        wall_pts_list.append(np.column_stack([vx, vy, vz]).astype(np.float32))
        wall_cls_list.append(np.full(vx.size, 9, dtype=np.uint8))  # Class 9 (Water / Void surface)
        wall_inten_list.append(np.full(vx.size, 0.25, dtype=np.float32))
        if sr is not None:
            # Dark slate-water / shadow tone matching natural orthophoto water bodies
            water_rgb = np.empty((vx.size, 3), dtype=np.uint8)
            water_rgb[:, 0] = 38
            water_rgb[:, 1] = 58
            water_rgb[:, 2] = 74
            wall_rgb_list.append(water_rgb)

    if not wall_pts_list:
        return {
            "infill_pos": np.zeros((0, 3), dtype=np.float32),
            "infill_cls": np.zeros(0, dtype=np.uint8),
            "infill_inten": np.zeros(0, dtype=np.float32),
            "infill_rgb": np.zeros((0, 3), dtype=np.uint8),
            "infill_n": 0,
        }

    infill_pos = np.vstack(wall_pts_list)
    infill_cls = np.concatenate(wall_cls_list)
    infill_inten = np.concatenate(wall_inten_list)
    infill_rgb = np.vstack(wall_rgb_list) if wall_rgb_list else np.zeros((0, 3), dtype=np.uint8)

    # Cap at 450k infill points per tile and shuffle for LOD
    if len(infill_pos) > 450_000:
        sel = rng.choice(len(infill_pos), size=450_000, replace=False)
        infill_pos = infill_pos[sel]
        infill_cls = infill_cls[sel]
        infill_inten = infill_inten[sel]
        if len(infill_rgb) > 0:
            infill_rgb = infill_rgb[sel]

    return {
        "infill_pos": np.ascontiguousarray(infill_pos, dtype=np.float32),
        "infill_cls": np.ascontiguousarray(infill_cls, dtype=np.uint8),
        "infill_inten": np.ascontiguousarray(infill_inten, dtype=np.float32),
        "infill_rgb": np.ascontiguousarray(infill_rgb, dtype=np.uint8),
        "infill_n": int(len(infill_pos)),
    }


def decode_laz(
    laz_path: str,
    tile_id: str,
    progress_cb: Optional[Callable[[int, str], None]] = None,
) -> dict:
    """Decodes a LAZ tile into numpy arrays with live progress callback and zero pipe deadlock."""
    pdal = find_pdal()
    if not pdal:
        raise RuntimeError("pdal.exe ei leitud QGIS-i paigalduskaustast.")

    fname = os.path.basename(laz_path)
    size_mb = os.path.getsize(laz_path) / (1024.0 * 1024.0) if os.path.exists(laz_path) else 5.0
    if progress_cb:
        progress_cb(8, f"Käivitan PDAL dekodeerija: {fname} ({size_mb:.1f} MB)...")

    uid = f"{os.getpid()}_{tile_id}_{np.random.randint(1e9)}"
    tmp_las = os.path.join(tempfile.gettempdir(), f"maru_als_{uid}.las")
    tmp_err = os.path.join(tempfile.gettempdir(), f"maru_als_{uid}.err")
    flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
    try:
        # Uncompressed LAS is typically ~3.4x the compressed LAZ size
        expected_las_mb = max(1.0, size_mb * 3.4)
        with open(tmp_err, "w", encoding="utf-8") as err_f:
            proc = subprocess.Popen(
                [
                    pdal,
                    "translate",
                    laz_path,
                    tmp_las,
                    "--stream",
                    "--readers.las.nosrs=true",
                    "--writers.las.minor_version=2",
                    "--writers.las.dataformat_id=3",
                ],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=err_f,
                creationflags=flags,
            )
            t_start = time.perf_counter()
            est_sec = max(0.8, size_mb * 0.14)
            while proc.poll() is None:
                elapsed = time.perf_counter() - t_start
                written_mb = 0.0
                if os.path.exists(tmp_las):
                    try:
                        written_mb = os.path.getsize(tmp_las) / (1024.0 * 1024.0)
                    except Exception:
                        pass
                if written_mb > 0.5:
                    ratio = min(0.98, written_mb / expected_las_mb)
                else:
                    ratio = min(0.96, elapsed / max(est_sec, elapsed + 2.0))
                pct = int(10 + ratio * 52)  # 10% -> 62%
                if progress_cb:
                    mb_str = f" — {written_mb:.0f} MB" if written_mb >= 1.0 else ""
                    progress_cb(pct, f"Dekodeerin LAZ: {fname}{mb_str} ({pct}%)...")
                if elapsed > 240.0:
                    proc.kill()
                    raise RuntimeError(f"PDAL dekodeerimise ajapiirang ületatud: {fname}")
                time.sleep(0.12)

        if proc.returncode != 0 or not os.path.exists(tmp_las):
            stderr_txt = ""
            if os.path.exists(tmp_err):
                try:
                    with open(tmp_err, "r", encoding="utf-8", errors="replace") as ef:
                        stderr_txt = ef.read()
                except Exception:
                    pass
            raise RuntimeError(f"PDAL viga: {(stderr_txt or '').strip()[-400:]}")

        if progress_cb:
            progress_cb(64, f"Loen 3D punkte mällu: {fname}...")

        with open(tmp_las, "rb") as f:
            hdr = f.read(227)
        off_pts = struct.unpack_from("<I", hdr, 96)[0]
        rec_len = struct.unpack_from("<H", hdr, 105)[0]
        n_total = struct.unpack_from("<I", hdr, 107)[0]
        sx, sy, sz, ox, oy, oz = struct.unpack_from("<6d", hdr, 131)
        if n_total == 0:
            raise RuntimeError("Tühi punktipilv.")

        mm = np.memmap(tmp_las, dtype=np.uint8, mode="r", offset=off_pts, shape=(n_total, rec_len))
        if n_total > MAX_POINTS_PER_TILE:
            step = max(1, int(math.ceil(n_total / MAX_POINTS_PER_TILE)))
            raw = np.array(mm[::step], copy=True)
        else:
            raw = np.array(mm, copy=True)
        del mm
        n = len(raw)

        ixyz = np.ascontiguousarray(raw[:, 0:12]).view("<i4").reshape(n, 3)
        intensity = np.ascontiguousarray(raw[:, 12:14]).view("<u2").ravel()
        cls = (raw[:, 15] & 0x1F).astype(np.uint8)
        gps = np.ascontiguousarray(raw[:, 20:28]).view("<f8").ravel()
        rgb16 = np.ascontiguousarray(raw[:, 28:34]).view("<u2").reshape(n, 3)
        del raw
    finally:
        for p_rm in (tmp_las, tmp_err):
            try:
                if os.path.exists(p_rm):
                    os.remove(p_rm)
            except Exception:
                pass

    if progress_cb:
        progress_cb(72, f"Teisendan {n:,} punkti ja RGB värvid ({tile_id})...")

    rect = GridEngine.tile_to_rect(tile_id)
    if rect is not None:
        x0, y0 = rect.xMinimum(), rect.yMinimum()
    else:
        x0 = float(np.floor((ixyz[:, 0].min() * sx + ox) / 1000.0) * 1000.0)
        y0 = float(np.floor((ixyz[:, 1].min() * sy + oy) / 1000.0) * 1000.0)

    pos = np.empty((n, 3), dtype=np.float32)
    pos[:, 0] = (ixyz[:, 0] * sx + (ox - x0)).astype(np.float32)
    pos[:, 1] = (ixyz[:, 1] * sy + (oy - y0)).astype(np.float32)
    pos[:, 2] = (ixyz[:, 2] * sz + oz).astype(np.float32)

    perm = np.random.default_rng(12345).permutation(n)
    pos = pos[perm]
    cls = cls[perm]
    intensity = intensity[perm]
    rgb16 = rgb16[perm]

    has_rgb = bool(rgb16.max() > 0)
    if has_rgb:
        shift = 8 if rgb16.max() > 255 else 0
        rgb = (rgb16 >> shift).astype(np.uint8)
    else:
        rgb = np.zeros((0, 3), dtype=np.uint8)

    i_lo, i_hi = np.percentile(intensity, [2, 98]) if n > 10 else (0, 1)
    if i_hi <= i_lo:
        i_hi = i_lo + 1
    inten01 = np.clip((intensity.astype(np.float32) - i_lo) / (i_hi - i_lo), 0, 1).astype(np.float32)

    if progress_cb:
        progress_cb(82, f"Arvutan maapinna mudeli ({tile_id})...")

    if rect is not None:
        gsize = int(1000 / GROUND_CELL)
        ground = np.full((gsize, gsize), np.nan, dtype=np.float32)
        gmask = cls == 2
        if not gmask.any():
            gmask = np.ones(n, dtype=bool)
        gx = np.clip((pos[gmask, 0] / GROUND_CELL).astype(np.int32), 0, gsize - 1)
        gy = np.clip((pos[gmask, 1] / GROUND_CELL).astype(np.int32), 0, gsize - 1)
        flat = gy * gsize + gx
        gflat = np.full(gsize * gsize, np.inf, dtype=np.float32)
        np.minimum.at(gflat, flat, pos[gmask, 2])
        gflat[np.isinf(gflat)] = np.nan
        ground = _fill_nan_grid(gflat.reshape(gsize, gsize))
    else:
        # Dynamic extent ground model for drone surveys
        gsize = 200
        ground = np.full((gsize, gsize), np.nan, dtype=np.float32)
        gmask = cls == 2
        if not gmask.any():
            gmask = np.ones(n, dtype=bool)
        min_lx, max_lx = float(pos[:, 0].min()), float(pos[:, 0].max())
        min_ly, max_ly = float(pos[:, 1].min()), float(pos[:, 1].max())
        span_x = max(10.0, max_lx - min_lx)
        span_y = max(10.0, max_ly - min_ly)
        gx = np.clip(((pos[gmask, 0] - min_lx) / (span_x / (gsize - 1))).astype(np.int32), 0, gsize - 1)
        gy = np.clip(((pos[gmask, 1] - min_ly) / (span_y / (gsize - 1))).astype(np.int32), 0, gsize - 1)
        flat = gy * gsize + gx
        gflat = np.full(gsize * gsize, np.inf, dtype=np.float32)
        np.minimum.at(gflat, flat, pos[gmask, 2])
        gflat[np.isinf(gflat)] = np.nan
        ground = _fill_nan_grid(gflat.reshape(gsize, gsize))

    date_from = date_to = ""
    if _read_global_encoding(laz_path) & 1:
        try:
            valid = gps[gps != 0]
            if valid.size:
                t0 = GPS_EPOCH + datetime.timedelta(seconds=float(valid.min()) + 1e9)
                t1 = GPS_EPOCH + datetime.timedelta(seconds=float(valid.max()) + 1e9)
                date_from = t0.strftime("%Y-%m-%d")
                date_to = t1.strftime("%Y-%m-%d")
        except Exception:
            pass

    z_lo, z_hi = np.percentile(pos[:, 2], [1, 99])
    res = {
        "pos": pos,
        "cls": cls,
        "inten": inten01,
        "rgb": rgb,
        "has_rgb": has_rgb,
        "origin": np.array([x0, y0], dtype=np.float64),
        "ground": ground.astype(np.float32),
        "z_range": np.array([z_lo, z_hi], dtype=np.float32),
        "date_from": date_from,
        "date_to": date_to,
    }

    if progress_cb:
        progress_cb(90, f"Genereerin vertikaalseinte ja tühimike täite ({tile_id})...")
    infill = synthesize_vertical_infill(res)
    res.update(infill)
    return res


def load_tile_arrays(
    laz_path: str,
    tile_id: str,
    progress_cb: Optional[Callable[[int, str], None]] = None,
) -> dict:
    """Returns cached arrays or decodes the LAZ (and writes cache) with live progress."""
    cache = npz_cache_path(laz_path)
    fname = os.path.basename(laz_path)
    if os.path.exists(cache) and os.path.getmtime(cache) >= os.path.getmtime(laz_path):
        try:
            if progress_cb:
                progress_cb(35, f"Loen 3D kiirvahemälust: {fname}...")
            with np.load(cache, allow_pickle=False) as z:
                d = {k: z[k] for k in z.files}
            d["has_rgb"] = bool(d["has_rgb"])
            d["date_from"] = str(d["date_from"])
            d["date_to"] = str(d["date_to"])
            if len(d["pos"]) > MAX_POINTS_PER_TILE:
                d["pos"] = np.ascontiguousarray(d["pos"][:MAX_POINTS_PER_TILE])
                d["cls"] = np.ascontiguousarray(d["cls"][:MAX_POINTS_PER_TILE])
                d["inten"] = np.ascontiguousarray(d["inten"][:MAX_POINTS_PER_TILE])
                if d["has_rgb"] and len(d.get("rgb", [])) >= MAX_POINTS_PER_TILE:
                    d["rgb"] = np.ascontiguousarray(d["rgb"][:MAX_POINTS_PER_TILE])
            if "infill_pos" not in d:
                if progress_cb:
                    progress_cb(75, f"Arvutan vertikaalseinte täite: {fname}...")
                d.update(synthesize_vertical_infill(d))
            if progress_cb:
                progress_cb(100, f"Avatud 3D vaates: {fname}")
            return d
        except Exception:
            pass

    d = decode_laz(laz_path, tile_id, progress_cb=progress_cb)
    try:
        if progress_cb:
            progress_cb(96, f"Salvestan 3D vahemällu: {fname}...")
        tmp = cache + ".tmp.npz"
        np.savez(tmp, **d)
        os.replace(tmp, cache)
    except Exception as e:
        QgsMessageLog.logMessage(f"3D vahemälu kirjutamine ebaõnnestus: {e}", "MaRu ALS", Qgis.Warning)
    if progress_cb:
        progress_cb(100, f"Avatud 3D vaates: {fname}")
    return d


def decode_raster_for_3d(
    local_path: str,
    tile_id: str,
    file_info,
    ref_ground: Optional[np.ndarray] = None,
    progress_cb: Optional[Callable[[int, str], None]] = None,
) -> dict:
    """
    Decodes an extra MaRu raster dataset (DSM 1m, DTM 1m, Orthophoto RGB/CIR/NGR, or
    Shaded Basic Map) over the 1:2000 tile `tile_id` into a 3D surface point cloud layer
    so it renders directly inside `AlsGLViewer`!
    """
    from osgeo import gdal

    fname = os.path.basename(local_path)
    if progress_cb:
        progress_cb(15, f"Valmistan 3D rasterkihti ette: {fname}...")

    tif_path = resolve_raster_path(local_path)
    if not tif_path or not os.path.exists(tif_path):
        raise RuntimeError(f"Rasterfaili ei leitud: {local_path}")

    ds = gdal.Open(tif_path, gdal.GA_ReadOnly)
    if ds is None:
        raise RuntimeError(f"GDAL ei suutnud avada faili: {tif_path}")

    # Inspect and automatically reproject drone datasets (e.g. UTM 35N / WGS84) to EPSG:3301
    proj = ds.GetProjection()
    if proj:
        try:
            from osgeo import osr
            srs = osr.SpatialReference()
            srs.ImportFromWkt(proj)
            auth = srs.GetAuthorityCode(None)
            if auth and auth != "3301":
                if progress_cb:
                    progress_cb(20, f"Teisendan koordinaadistikku (EPSG:{auth} -> EPSG:3301)...")
                warped = gdal.Warp("", ds, format="VRT", dstSRS="EPSG:3301")
                if warped is not None:
                    ds = warped
        except Exception as e:
            QgsMessageLog.logMessage(f"Drooni rasteri reprojektsiooni viga: {e}", "MaRu ALS", Qgis.Warning)

    gt = ds.GetGeoTransform()
    cols = ds.RasterXSize
    rows = ds.RasterYSize
    bands = ds.RasterCount

    rect = GridEngine.tile_to_rect(tile_id)
    if rect is not None:
        x0, y0 = rect.xMinimum(), rect.yMinimum()
        x1, y1 = rect.xMaximum(), rect.yMaximum()
        origin_x, origin_y = x0, y0
        # Map tile bounds (x0..x1, y0..y1) to pixel window in raster
        px0 = int(max(0, math.floor((x0 - gt[0]) / gt[1])))
        px1 = int(min(cols, math.ceil((x1 - gt[0]) / gt[1])))
        py0 = int(max(0, math.floor((y1 - gt[3]) / gt[5])))
        py1 = int(min(rows, math.ceil((y0 - gt[3]) / gt[5])))

        win_w = px1 - px0
        win_h = py1 - py0
        if win_w <= 2 or win_h <= 2:
            px0, py0, win_w, win_h = 0, 0, cols, rows
            x0 = gt[0]
            y1 = gt[3]
            x1 = x0 + cols * gt[1]
            y0 = y1 + rows * gt[5]
            origin_x = float(math.floor(x0 / 1000.0) * 1000.0)
            origin_y = float(math.floor(min(y0, y1) / 1000.0) * 1000.0)
    else:
        # Full survey extent for drone photogrammetry / LiDAR (Mavic 3E / Drone2Map / Pix4D)
        px0, py0, win_w, win_h = 0, 0, cols, rows
        x0 = float(gt[0])
        x1 = float(x0 + cols * gt[1])
        y1 = float(gt[3])
        y0 = float(y1 + rows * gt[5])
        if y0 > y1:
            y0, y1 = y1, y0
        if x0 > x1:
            x0, x1 = x1, x0
        origin_x = float(math.floor(x0 / 1000.0) * 1000.0)
        origin_y = float(math.floor(y0 / 1000.0) * 1000.0)

    # Resolution: 650x650 default for 1km tiles, up to 800x800 for high-detail drone surveys
    grid_n = min(800, max(500, int(max(win_w, win_h) / 2))) if rect is None else 650
    if progress_cb:
        progress_cb(45, f"Loen 3D piksleid ({grid_n}×{grid_n}): {fname}...")

    cat = (getattr(file_info, "flight_type", "") or "").lower()
    is_elev = cat in ("dsm_1m", "dtm_1m", "droon_dsm", "droon_dtm") or (bands == 1 and ds.GetRasterBand(1).DataType >= gdal.GDT_Int16)

    xs_1d = np.linspace((x0 - origin_x) + 0.5 * (x1 - x0) / grid_n, (x1 - origin_x) - 0.5 * (x1 - x0) / grid_n, grid_n, dtype=np.float32)
    ys_1d = np.linspace((y1 - origin_y) - 0.5 * (y1 - y0) / grid_n, (y0 - origin_y) + 0.5 * (y1 - y0) / grid_n, grid_n, dtype=np.float32)
    xx, yy = np.meshgrid(xs_1d, ys_1d)

    if is_elev:
        band1 = ds.GetRasterBand(1)
        nodata = band1.GetNoDataValue()
        arr = band1.ReadAsArray(px0, py0, win_w, win_h, buf_xsize=grid_n, buf_ysize=grid_n).astype(np.float32)
        valid = np.isfinite(arr) & (arr > -100.0) & (arr < 1000.0)
        if nodata is not None:
            valid &= np.abs(arr - float(nodata)) > 1e-3
        if not valid.any():
            raise RuntimeError("Kõrgusmudeli failis puuduvad kehtivad kõrgusväärtused.")

        z_grid = np.where(valid, arr, np.nan)
        z_filled = _fill_nan_grid(z_grid, iterations=25)

        if progress_cb:
            progress_cb(75, f"Arvutan 3D varjutuse ja värvid: {fname}...")

        # Compute hillshade so DSM/DTM has rich 3D relief in RGB and Intensity modes
        dz_dy, dz_dx = np.gradient(z_filled, 1000.0 / grid_n)
        slope = np.arctan(np.hypot(dz_dx, dz_dy))
        aspect = np.arctan2(-dz_dy, dz_dx)
        az = math.radians(315.0)
        alt = math.radians(45.0)
        hs = np.clip(
            np.sin(alt) * np.cos(slope) + np.cos(alt) * np.sin(slope) * np.cos(az - aspect),
            0.15,
            1.0,
        ).astype(np.float32)

        z_lo, z_hi = np.percentile(z_filled[valid], [2, 98])
        zn = np.clip((z_filled - z_lo) / max(1.0, z_hi - z_lo), 0.0, 1.0)

        # Natural hypsometric + hillshade RGB for DSM/DTM
        r_ch = np.clip((75.0 + 145.0 * zn) * hs, 0, 255).astype(np.uint8)
        g_ch = np.clip((125.0 + 95.0 * (1.0 - np.abs(zn - 0.45))) * hs, 0, 255).astype(np.uint8)
        b_ch = np.clip((70.0 + 60.0 * (1.0 - zn)) * hs, 0, 255).astype(np.uint8)

        pos = np.column_stack([xx[valid], yy[valid], z_filled[valid]]).astype(np.float32)
        rgb = np.column_stack([r_ch[valid], g_ch[valid], b_ch[valid]]).astype(np.uint8)
        inten = hs[valid].ravel().astype(np.float32)
        cls_code = 6 if cat == "dsm_1m" else 2
        cls = np.full(len(pos), cls_code, dtype=np.uint8)

        # Downsample to 200x200 for 5m ground grid
        g_idx = np.linspace(0, grid_n - 1, 200).astype(np.int32)
        ground = z_filled[::-1, :][np.ix_(g_idx, g_idx)].astype(np.float32)
    else:
        # Orthophoto RGB / CIR / NGR or Shaded Basic Map
        if bands >= 3:
            r_b = ds.GetRasterBand(1).ReadAsArray(px0, py0, win_w, win_h, buf_xsize=grid_n, buf_ysize=grid_n)
            g_b = ds.GetRasterBand(2).ReadAsArray(px0, py0, win_w, win_h, buf_xsize=grid_n, buf_ysize=grid_n)
            b_b = ds.GetRasterBand(3).ReadAsArray(px0, py0, win_w, win_h, buf_xsize=grid_n, buf_ysize=grid_n)
        else:
             band1 = ds.GetRasterBand(1)
             ct = band1.GetColorTable()
             idx_arr = band1.ReadAsArray(px0, py0, win_w, win_h, buf_xsize=grid_n, buf_ysize=grid_n)
             if ct is not None:
                 lut = np.array([ct.GetColorEntry(i)[:3] for i in range(min(256, ct.GetCount()))], dtype=np.uint8)
                 idx_clamped = np.clip(idx_arr, 0, len(lut) - 1)
                 rgb_img = lut[idx_clamped]
                 r_b, g_b, b_b = rgb_img[:, :, 0], rgb_img[:, :, 1], rgb_img[:, :, 2]
             else:
                 r_b = g_b = b_b = idx_arr

        if r_b.dtype != np.uint8:
            rmax = float(max(r_b.max(), g_b.max(), b_b.max(), 1))
            scale = 255.0 / (65535.0 if rmax > 255 else rmax)
            r_b = np.clip(r_b * scale, 0, 255).astype(np.uint8)
            g_b = np.clip(g_b * scale, 0, 255).astype(np.uint8)
            b_b = np.clip(b_b * scale, 0, 255).astype(np.uint8)

        # Drape onto ref_ground if available, otherwise flat Z=10m
        if ref_ground is not None and ref_ground.shape[0] > 10:
            gn = ref_ground.shape[0]
            gx = np.clip(((xx - (x0 - origin_x)) / (max(1.0, x1 - x0) / gn)).astype(np.int32), 0, gn - 1)
            gy = np.clip(((yy - (y0 - origin_y)) / (max(1.0, y1 - y0) / gn)).astype(np.int32), 0, gn - 1)
            zz = ref_ground[gy, gx].astype(np.float32) + 0.15
            ground = ref_ground.astype(np.float32)
        else:
            zz = np.full_like(xx, 10.0, dtype=np.float32)
            ground = np.full((200, 200), 10.0, dtype=np.float32)

        pos = np.column_stack([xx.ravel(), yy.ravel(), zz.ravel()]).astype(np.float32)
        rgb = np.column_stack([r_b.ravel(), g_b.ravel(), b_b.ravel()]).astype(np.uint8)
        inten = ((0.299 * r_b + 0.587 * g_b + 0.114 * b_b).ravel() / 255.0).astype(np.float32)
        cls = np.full(len(pos), 2, dtype=np.uint8)
        z_lo, z_hi = float(zz.min()), float(zz.max() + 1.0)

    ds = None

    # Shuffle for uniform LOD subsampling
    perm = np.random.default_rng(12345).permutation(len(pos))
    pos = pos[perm]
    rgb = rgb[perm]
    inten = inten[perm]
    cls = cls[perm]

    if progress_cb:
        progress_cb(100, f"Avatud 3D vaates: {fname}")

    return {
        "pos": pos,
        "cls": cls,
        "inten": inten,
        "rgb": rgb,
        "has_rgb": True,
        "origin": np.array([origin_x, origin_y], dtype=np.float64),
        "ground": ground,
        "z_range": np.array([z_lo, z_hi], dtype=np.float32),
        "date_from": str(getattr(file_info, "year", "") or ""),
        "date_to": "",
        "is_raster_3d": True,
        "raster_cat": cat,
        "infill_pos": np.zeros((0, 3), dtype=np.float32),
        "infill_cls": np.zeros(0, dtype=np.uint8),
        "infill_inten": np.zeros(0, dtype=np.float32),
        "infill_rgb": np.zeros((0, 3), dtype=np.uint8),
    }


class PointCloudLoadWorker(QThread):
    """Persistent background worker decoding LAZ tiles and 3D Rasters sequentially with live progress."""

    tile_ready = pyqtSignal(str, object, object)        # tile_id, AlsFileInfo, data dict
    tile_failed = pyqtSignal(str, str)                  # tile_id, message
    tile_progress = pyqtSignal(str, int, str)           # tile_id, percent, status_text

    def __init__(self, parent=None):
        super().__init__(parent)
        self._queue: "queue.Queue" = queue.Queue()
        self._running = True

    def enqueue(self, tile_id: str, local_path: str, file_info, ref_ground: Optional[np.ndarray] = None):
        self._queue.put((tile_id, local_path, file_info, ref_ground))

    def stop(self):
        self._running = False
        try:
            self.tile_ready.disconnect()
            self.tile_failed.disconnect()
            self.tile_progress.disconnect()
        except Exception:
            pass
        self._queue.put(None)
        if not self.wait(1500):
            try:
                self.terminate()
                self.wait(500)
            except Exception:
                pass

    def run(self):
        while self._running:
            job = self._queue.get()
            if job is None:
                break
            tile_id, local_path, file_info, ref_ground = job
            try:
                cb = lambda pct, msg, tid=tile_id: self.tile_progress.emit(tid, pct, msg)
                if getattr(file_info, "is_raster", False):
                    data = decode_raster_for_3d(
                        local_path, tile_id, file_info, ref_ground=ref_ground, progress_cb=cb
                    )
                else:
                    data = load_tile_arrays(local_path, tile_id, progress_cb=cb)
                self.tile_ready.emit(tile_id, file_info, data)
            except Exception as e:
                self.tile_failed.emit(tile_id, str(e))
