# -*- coding: utf-8 -*-
"""
2D Map Canvas Drone Overlay (`DroneCanvas2DOverlay`) and Minimap Base Layer Tile Fetcher (`MinimapTileFetcher`).

1. `DroneCanvas2DOverlay(QgsMapCanvasItem)`:
   Renders the 3D drone's live location, directional bearing/FOV cone, and flight path
   trail directly on the QGIS main 2D canvas (`iface.mapCanvas()`).
2. `MinimapTileFetcher(QThread)`:
   Fetches and caches Maa- ja Ruumiamet WMS base map tiles (`Fotokaart`, `Põhikaart`,
   `Hübriidkaart`) aligned to 1:2000 (1000 m × 1000 m) EPSG:3301 grid squares for the
   3D viewer's interactive minimap.
"""

import math
import os
import queue
import urllib.request
from typing import Dict, List, Optional, Set, Tuple

from qgis.PyQt.QtCore import QPointF, QRectF, Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QImage,
    QPainter,
    QPen,
    QPolygonF,
    QRadialGradient,
)
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
)
from qgis.gui import QgsMapCanvas, QgsMapCanvasItem

from ...core.cache_manager import CacheManager
from ...core.grid_engine import GridEngine


# --------------------------------------------------------------------------- #
# 1. Minimap WMS Base Layer Tile Fetcher (Fotokaart / Hallkaart / Hübriidkaart)
# --------------------------------------------------------------------------- #
MINIMAP_BASE_MODES = ("hyb", "foto", "hall", "grid")

WMS_TEMPLATES: Dict[str, str] = {
    "foto": (
        "https://kaart.maaamet.ee/wms/fotokaart?"
        "SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
        "&LAYERS=EESTIFOTO&STYLES=&SRS=EPSG:3301"
        "&BBOX={xmin:.1f},{ymin:.1f},{xmax:.1f},{ymax:.1f}"
        "&WIDTH=384&HEIGHT=384&FORMAT=image/jpeg"
    ),
    "hall": (
        "https://kaart.maaamet.ee/wms/hallkaart?"
        "SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
        "&LAYERS=kaart_ht&STYLES=&SRS=EPSG:3301"
        "&BBOX={xmin:.1f},{ymin:.1f},{xmax:.1f},{ymax:.1f}"
        "&WIDTH=384&HEIGHT=384&FORMAT=image/png"
    ),
    "baas": (
        "https://kaart.maaamet.ee/wms/hallkaart?"
        "SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
        "&LAYERS=kaart_ht&STYLES=&SRS=EPSG:3301"
        "&BBOX={xmin:.1f},{ymin:.1f},{xmax:.1f},{ymax:.1f}"
        "&WIDTH=384&HEIGHT=384&FORMAT=image/png"
    ),
    "pohi": (
        "https://kaart.maaamet.ee/wms/hallkaart?"
        "SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
        "&LAYERS=kaart_ht&STYLES=&SRS=EPSG:3301"
        "&BBOX={xmin:.1f},{ymin:.1f},{xmax:.1f},{ymax:.1f}"
        "&WIDTH=384&HEIGHT=384&FORMAT=image/png"
    ),
    "hyb": (
        "https://kaart.maaamet.ee/wms/fotokaart?"
        "SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap"
        "&LAYERS=EESTIFOTO,HYBRID&STYLES=&SRS=EPSG:3301"
        "&BBOX={xmin:.1f},{ymin:.1f},{xmax:.1f},{ymax:.1f}"
        "&WIDTH=384&HEIGHT=384&FORMAT=image/jpeg"
    ),
}


class MinimapTileFetcher(QThread):
    """
    Background worker thread that fetches 1:2000 (1000 m × 1000 m) EPSG:3301 WMS base
    map tiles from Maa- ja Ruumiamet for the 3D minimap (`foto`, `pohi`, `hyb`).
    """

    tile_image_ready = pyqtSignal(str, str, QImage)  # mode, tile_id, QImage

    def __init__(self, parent=None):
        super().__init__(parent)
        self._q: "queue.Queue[Optional[Tuple[str, str]]]" = queue.Queue()
        self._in_flight: Set[Tuple[str, str]] = set()
        self._failed: Set[Tuple[str, str]] = set()
        self._stop = False

    def request_tile(self, mode: str, tile_id: str):
        if mode not in WMS_TEMPLATES or not GridEngine.is_valid_tile(tile_id):
            return
        key = (mode, tile_id)
        if key in self._in_flight or key in self._failed:
            return
        self._in_flight.add(key)
        self._q.put(key)
        if not self.isRunning():
            self.start()

    def stop(self):
        self._stop = True
        try:
            self.tile_image_ready.disconnect()
        except Exception:
            pass
        self._q.put(None)
        if not self.wait(1500):
            try:
                self.terminate()
                self.wait(500)
            except Exception:
                pass

    @staticmethod
    def _cache_path(mode: str, tile_id: str) -> str:
        base_dir = os.path.join(CacheManager.get_cache_dir(), "minimap")
        os.makedirs(base_dir, exist_ok=True)
        return os.path.join(base_dir, f"mm_{mode}_{tile_id}.jpg")

    def run(self):
        while not self._stop:
            try:
                item = self._q.get(timeout=0.4)
            except queue.Empty:
                continue
            if item is None or self._stop:
                break

            mode, tile_id = item
            try:
                cpath = self._cache_path(mode, tile_id)
                if os.path.exists(cpath) and os.path.getsize(cpath) > 800:
                    img = QImage(cpath)
                    if not img.isNull():
                        self.tile_image_ready.emit(mode, tile_id, img)
                        continue

                bounds = GridEngine.get_tile_bounds(tile_id)
                if not bounds:
                    self._failed.add(item)
                    continue
                xmin, ymin, xmax, ymax = bounds
                url = WMS_TEMPLATES[mode].format(xmin=xmin, ymin=ymin, xmax=xmax, ymax=ymax)
                req = urllib.request.Request(url, headers={"User-Agent": "MaRu-ALS-QGIS-Plugin/2.0"})
                with urllib.request.urlopen(req, timeout=8) as resp:
                    ctype = (resp.headers.get("Content-Type") or "").lower()
                    raw = resp.read()
                if "image" in ctype and len(raw) > 800:
                    img = QImage.fromData(raw)
                    if not img.isNull():
                        try:
                            with open(cpath, "wb") as f:
                                f.write(raw)
                        except Exception:
                            pass
                        self.tile_image_ready.emit(mode, tile_id, img)
                        continue
                self._failed.add(item)
            except Exception:
                self._failed.add(item)
            finally:
                self._in_flight.discard(item)


# --------------------------------------------------------------------------- #
# 2. 2D QGIS Main Canvas Drone Location, Bearing Cone & Flight Path Overlay
# --------------------------------------------------------------------------- #
class DroneCanvas2DOverlay(QgsMapCanvasItem):
    """
    Custom `QgsMapCanvasItem` that renders the 3D drone's live position, directional
    bearing/FOV cone, and flight trail directly on the QGIS main 2D map canvas.
    """

    def __init__(self, canvas: QgsMapCanvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.setZValue(150.0)

        self.enabled: bool = True
        self.has_fix: bool = False
        self.show_cone: bool = True
        self.show_path: bool = True
        self.auto_follow: bool = False

        # Drone telemetry in EPSG:3301
        self.drone_x: float = 0.0
        self.drone_y: float = 0.0
        self.drone_z: float = 150.0
        self.agl: float = 90.0
        self.yaw: float = 0.0
        self.pitch: float = -25.0
        self.fov_deg: float = 68.0

        # Flight path trail in EPSG:3301: [(x, y), ...]
        self.trail_3301: List[Tuple[float, float]] = []
        self._crs_3301 = QgsCoordinateReferenceSystem("EPSG:3301")

    # ------------------------------------------------------------------ #
    # State & Telemetry Updates
    # ------------------------------------------------------------------ #
    def set_enabled(self, enabled: bool):
        self.enabled = bool(enabled)
        self.setVisible(self.enabled and self.has_fix)
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def set_show_cone(self, show: bool):
        self.show_cone = bool(show)
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def set_show_path(self, show: bool):
        self.show_path = bool(show)
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def set_auto_follow(self, follow: bool):
        self.auto_follow = bool(follow)
        if self.auto_follow and self.has_fix:
            self.center_on_drone()

    def clear_fix(self):
        self.has_fix = False
        self.trail_3301 = []
        self.setVisible(False)
        self.update()

    def update_telemetry(
        self,
        x_3301: float,
        y_3301: float,
        z: float,
        agl: float,
        yaw: float,
        pitch: float,
        trail_3301: Optional[List[Tuple[float, float]]] = None,
    ):
        self.drone_x = float(x_3301)
        self.drone_y = float(y_3301)
        self.drone_z = float(z)
        self.agl = float(agl)
        self.yaw = float(yaw) % 360.0
        self.pitch = float(pitch)

        if trail_3301 is not None:
            self.trail_3301 = trail_3301
        else:
            if not self.trail_3301:
                self.trail_3301.append((self.drone_x, self.drone_y, False))
            else:
                last_rec = self.trail_3301[-1]
                lx, ly = last_rec[0], last_rec[1]
                d = math.hypot(self.drone_x - lx, self.drone_y - ly)
                if d > 2.5:
                    is_jump = (d > 40.0)
                    self.trail_3301.append((self.drone_x, self.drone_y, is_jump))
                    if len(self.trail_3301) > 4000:
                        self.trail_3301 = self.trail_3301[-4000:]

        self.has_fix = True
        self.setVisible(self.enabled)

        if self.enabled and self.auto_follow and self.canvas:
            map_pt = self._to_canvas_crs(self.drone_x, self.drone_y)
            ext = self.canvas.extent()
            if not ext.isEmpty():
                mx = ext.width() * 0.22
                my = ext.height() * 0.22
                inner = ext.buffered(-min(mx, my))
                if not inner.contains(map_pt):
                    self.canvas.setCenter(map_pt)
                    self.canvas.refresh()

        self.prepareGeometryChange()
        self.update()
        if self.canvas and self.canvas.scene():
            self.canvas.scene().update()

    def center_on_drone(self):
        """Centers the 2D QGIS map canvas on the current 3D drone position."""
        if not self.has_fix or not self.canvas:
            return
        map_pt = self._to_canvas_crs(self.drone_x, self.drone_y)
        self.canvas.setCenter(map_pt)
        self.canvas.refresh()

    # ------------------------------------------------------------------ #
    # Coordinate Helpers & QGraphicsItem Interface
    # ------------------------------------------------------------------ #
    def _to_canvas_crs(self, x_3301: float, y_3301: float) -> QgsPointXY:
        pt = QgsPointXY(x_3301, y_3301)
        if not self.canvas:
            return pt
        dest_crs = self.canvas.mapSettings().destinationCrs()
        if dest_crs.isValid() and dest_crs.authid() != "EPSG:3301":
            try:
                xform = QgsCoordinateTransform(self._crs_3301, dest_crs, QgsProject.instance())
                return xform.transform(pt)
            except Exception:
                return pt
        return pt

    def _to_canvas_px(self, x_3301: float, y_3301: float) -> QPointF:
        map_pt = self._to_canvas_crs(x_3301, y_3301)
        return self.toCanvasCoordinates(map_pt)

    def boundingRect(self) -> QRectF:
        if not self.canvas:
            return QRectF(0.0, 0.0, 100.0, 100.0)
        return QRectF(
            0.0,
            0.0,
            max(1.0, float(self.canvas.width())),
            max(1.0, float(self.canvas.height())),
        )

    def updatePosition(self):
        self.prepareGeometryChange()
        self.update()

    # ------------------------------------------------------------------ #
    # Painting on 2D Canvas
    # ------------------------------------------------------------------ #
    def paint(self, painter: QPainter, option=None, widget=None):
        if not self.enabled or not self.has_fix or painter is None:
            return
        if not self.show_cone and not self.show_path:
            return

        painter.save()
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            # 1. Draw Flight Path Trail (Solid for flight, Dotted for teleport/view resets)
            if self.show_path and len(self.trail_3301) >= 1:
                cur_px = self._to_canvas_px(self.drone_x, self.drone_y)
                recent = self.trail_3301[-2500:]
                solid_chunk: List[QPointF] = []
                painter.setBrush(Qt.BrushStyle.NoBrush)

                for i, rec in enumerate(recent):
                    pt = self._to_canvas_px(rec[0], rec[1])
                    is_jump = bool(rec[2]) if len(rec) >= 3 else False
                    if is_jump and i > 0:
                        if len(solid_chunk) >= 2:
                            poly_path = QPolygonF(solid_chunk)
                            pen_halo = QPen(
                                QColor(15, 23, 42, 185),
                                4.5,
                                Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin,
                            )
                            painter.setPen(pen_halo)
                            painter.drawPolyline(poly_path)
                            pen_trail = QPen(
                                QColor(250, 204, 21, 235),
                                2.3,
                                Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin,
                            )
                            painter.setPen(pen_trail)
                            painter.drawPolyline(poly_path)
                        solid_chunk = [pt]
                        # Draw DOTTED jump connection
                        prev_pt = self._to_canvas_px(recent[i - 1][0], recent[i - 1][1])
                        p_halo_dot = QPen(
                            QColor(15, 23, 42, 180),
                            3.8,
                            Qt.PenStyle.DotLine,
                            Qt.PenCapStyle.RoundCap,
                            Qt.PenJoinStyle.RoundJoin,
                        )
                        painter.setPen(p_halo_dot)
                        painter.drawLine(prev_pt, pt)
                        p_trail_dot = QPen(
                            QColor(250, 204, 21, 235),
                            2.0,
                            Qt.PenStyle.DotLine,
                            Qt.PenCapStyle.RoundCap,
                            Qt.PenJoinStyle.RoundJoin,
                        )
                        painter.setPen(p_trail_dot)
                        painter.drawLine(prev_pt, pt)
                    else:
                        solid_chunk.append(pt)

                if solid_chunk and math.hypot(cur_px.x() - solid_chunk[-1].x(), cur_px.y() - solid_chunk[-1].y()) > 1.0:
                    solid_chunk.append(cur_px)

                if len(solid_chunk) >= 2:
                    poly_path = QPolygonF(solid_chunk)
                    pen_halo = QPen(
                        QColor(15, 23, 42, 185),
                        4.5,
                        Qt.PenStyle.SolidLine,
                        Qt.PenCapStyle.RoundCap,
                        Qt.PenJoinStyle.RoundJoin,
                    )
                    painter.setPen(pen_halo)
                    painter.drawPolyline(poly_path)
                    pen_trail = QPen(
                        QColor(250, 204, 21, 235),
                        2.3,
                        Qt.PenStyle.SolidLine,
                        Qt.PenCapStyle.RoundCap,
                        Qt.PenJoinStyle.RoundJoin,
                    )
                    painter.setPen(pen_trail)
                    painter.drawPolyline(poly_path)

                # Start waypoint marker
                if recent:
                    p0 = self._to_canvas_px(recent[0][0], recent[0][1])
                    painter.setPen(QPen(QColor(15, 23, 42, 220), 1.5))
                    painter.setBrush(QBrush(QColor(250, 204, 21)))
                    painter.drawEllipse(p0, 3.8, 3.8)

            # 2. Draw Bearing Cone + Drone Chevron + Telemetry Badge
            if self.show_cone:
                c = self._to_canvas_px(self.drone_x, self.drone_y)
                mupp = max(0.05, float(self.canvas.mapUnitsPerPixel())) if self.canvas else 1.0
                # Scale cone length dynamically with map zoom (clamped to 62..145 px so it's always crisp)
                cone_px = min(145.0, max(62.0, 125.0 / mupp))

                # Adjust yaw for canvas rotation if any
                rot_deg = float(self.canvas.rotation()) if self.canvas else 0.0
                yr = math.radians(self.yaw + rot_deg)
                half = math.radians(self.fov_deg * 0.5)

                # Build smooth sector polygon (20 arc segments)
                sector_pts = [c]
                steps = 20
                for i in range(steps + 1):
                    ang = (yr - half) + (2.0 * half) * (i / steps)
                    sector_pts.append(
                        QPointF(c.x() + cone_px * math.sin(ang), c.y() - cone_px * math.cos(ang))
                    )
                sector_poly = QPolygonF(sector_pts)

                grad = QRadialGradient(c, cone_px)
                grad.setColorAt(0.0, QColor(239, 68, 68, 135))
                grad.setColorAt(0.45, QColor(56, 189, 248, 95))
                grad.setColorAt(1.0, QColor(56, 189, 248, 8))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QBrush(grad))
                painter.drawPolygon(sector_poly)

                # Left & right FOV boundary rays
                p_left = sector_pts[1]
                p_right = sector_pts[-1]
                painter.setPen(QPen(QColor(15, 23, 42, 150), 3.0))
                painter.drawLine(c, p_left)
                painter.drawLine(c, p_right)

                painter.setPen(QPen(QColor(56, 189, 248, 225), 1.6, Qt.PenStyle.DashLine))
                painter.drawLine(c, p_left)
                painter.drawLine(c, p_right)

                # Outer arc rim
                painter.setPen(QPen(QColor(56, 189, 248, 150), 1.3))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawPolyline(QPolygonF(sector_pts[1:]))

                # Center heading ray
                p_hdg = QPointF(
                    c.x() + (cone_px * 0.88) * math.sin(yr),
                    c.y() - (cone_px * 0.88) * math.cos(yr),
                )
                painter.setPen(QPen(QColor(250, 204, 21, 220), 1.6, Qt.PenStyle.DotLine))
                painter.drawLine(c, p_hdg)

                # Outer contrast halo around drone position
                painter.setPen(QPen(QColor(15, 23, 42, 210), 2.2))
                painter.setBrush(QBrush(QColor(15, 23, 42, 130)))
                painter.drawEllipse(c, 12.0, 12.0)

                # Directional drone chevron arrow
                tip = QPointF(c.x() + 11.5 * math.sin(yr), c.y() - 11.5 * math.cos(yr))
                wing_l = QPointF(
                    c.x() + 8.5 * math.sin(yr + 2.45),
                    c.y() - 8.5 * math.cos(yr + 2.45),
                )
                tail = QPointF(
                    c.x() - 3.5 * math.sin(yr),
                    c.y() + 3.5 * math.cos(yr),
                )
                wing_r = QPointF(
                    c.x() + 8.5 * math.sin(yr - 2.45),
                    c.y() - 8.5 * math.cos(yr - 2.45),
                )
                chevron = QPolygonF([tip, wing_l, tail, wing_r])
                painter.setPen(QPen(QColor(255, 255, 255), 1.6))
                painter.setBrush(QBrush(QColor(239, 68, 68)))
                painter.drawPolygon(chevron)

                # Compact dark telemetry badge beside the drone
                agl_txt = (
                    f"AGL {self.agl:.0f}m"
                    if math.isfinite(self.agl)
                    else f"Z {self.drone_z:.0f}m"
                )
                badge_txt = f"3D · {agl_txt} · {self.yaw:03.0f}°"
                f_badge = QFont("Segoe UI", 8)
                f_badge.setBold(True)
                painter.setFont(f_badge)
                fm = QFontMetrics(f_badge)
                tw = fm.horizontalAdvance(badge_txt) + 12
                th = 18
                bx = c.x() + 15.0
                by = c.y() - th - 6.0
                brect = QRectF(bx, by, float(tw), float(th))
                painter.setPen(QPen(QColor(56, 189, 248, 200), 1.1))
                painter.setBrush(QBrush(QColor(15, 23, 42, 220)))
                painter.drawRoundedRect(brect, 4.0, 4.0)
                painter.setPen(QColor(248, 250, 252))
                painter.drawText(brect, Qt.AlignmentFlag.AlignCenter, badge_txt)
        finally:
            painter.restore()
