# -*- coding: utf-8 -*-
"""Measurement math for the 3D viewer: polyline distance, polygon area, cut/fill volume."""

import math
from typing import List, Tuple

import numpy as np

MODE_NONE = "none"
MODE_DISTANCE = "distance"
MODE_AREA = "area"
MODE_VOLUME = "volume"

NOISE_CLASSES = (7, 18)


def polyline_stats(pts: List[Tuple[float, float, float]]) -> dict:
    if len(pts) < 2:
        return {}
    p = np.asarray(pts, dtype=np.float64)
    d = np.diff(p, axis=0)
    l2d = float(np.sum(np.hypot(d[:, 0], d[:, 1])))
    l3d = float(np.sum(np.linalg.norm(d, axis=1)))
    last = d[-1]
    h = math.hypot(last[0], last[1])
    slope_deg = math.degrees(math.atan2(abs(last[2]), h)) if h > 1e-6 else 90.0
    slope_pct = abs(last[2]) / h * 100.0 if h > 1e-6 else float("inf")
    return {
        "len_2d": l2d,
        "len_3d": l3d,
        "dz_total": float(p[-1, 2] - p[0, 2]),
        "seg_dz": float(last[2]),
        "slope_deg": slope_deg,
        "slope_pct": slope_pct,
    }


def polygon_area_2d(pts: List[Tuple[float, float, float]]) -> float:
    if len(pts) < 3:
        return 0.0
    p = np.asarray(pts, dtype=np.float64)
    x, y = p[:, 0], p[:, 1]
    return float(abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))) * 0.5)


def polygon_perimeter(pts, three_d: bool = False) -> float:
    if len(pts) < 2:
        return 0.0
    p = np.asarray(pts + [pts[0]], dtype=np.float64)
    d = np.diff(p, axis=0)
    if three_d:
        return float(np.sum(np.linalg.norm(d, axis=1)))
    return float(np.sum(np.hypot(d[:, 0], d[:, 1])))


def points_in_polygon(x: np.ndarray, y: np.ndarray, poly: np.ndarray) -> np.ndarray:
    """Vectorised even-odd point in polygon test."""
    inside = np.zeros(x.shape, dtype=bool)
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        cond = (yi > y) != (yj > y)
        with np.errstate(divide="ignore", invalid="ignore"):
            xcross = (xj - xi) * (y - yi) / (yj - yi + 1e-12) + xi
        inside ^= cond & (x < xcross)
        j = i
    return inside


def volume_stats(poly_pts, tiles, cell: float = 1.0) -> dict:
    """
    Cut/fill volume between the top surface of the point cloud (max Z per cell)
    and a horizontal base plane at the mean height of the polygon vertices.

    `tiles` is an iterable of (pos_local_float32[n,3], cls_uint8[n], offset_xyz) where
    offset converts tile-local positions into scene-local coordinates.
    """
    if len(poly_pts) < 3:
        return {}
    poly = np.asarray(poly_pts, dtype=np.float64)
    base = float(np.mean(poly[:, 2]))
    xmin, ymin = poly[:, 0].min(), poly[:, 1].min()
    xmax, ymax = poly[:, 0].max(), poly[:, 1].max()

    nx = max(1, int(math.ceil((xmax - xmin) / cell)))
    ny = max(1, int(math.ceil((ymax - ymin) / cell)))
    if nx * ny > 25_000_000:
        cell = math.sqrt((xmax - xmin) * (ymax - ymin) / 25_000_000)
        nx = max(1, int(math.ceil((xmax - xmin) / cell)))
        ny = max(1, int(math.ceil((ymax - ymin) / cell)))

    top = np.full(nx * ny, -np.inf, dtype=np.float32)
    used = 0
    for pos, cls, off in tiles:
        x = pos[:, 0] + off[0]
        y = pos[:, 1] + off[1]
        m = (x >= xmin) & (x <= xmax) & (y >= ymin) & (y <= ymax)
        if not m.any():
            continue
        m &= ~np.isin(cls, NOISE_CLASSES)
        idx = np.nonzero(m)[0]
        if idx.size == 0:
            continue
        inside = points_in_polygon(x[idx], y[idx], poly[:, :2])
        idx = idx[inside]
        if idx.size == 0:
            continue
        used += idx.size
        cx = np.clip(((x[idx] - xmin) / cell).astype(np.int64), 0, nx - 1)
        cy = np.clip(((y[idx] - ymin) / cell).astype(np.int64), 0, ny - 1)
        np.maximum.at(top, cy * nx + cx, pos[idx, 2] + off[2])

    # Cells whose centre lies inside the polygon
    gx = xmin + (np.arange(nx) + 0.5) * cell
    gy = ymin + (np.arange(ny) + 0.5) * cell
    GX, GY = np.meshgrid(gx, gy)
    cell_in = points_in_polygon(GX.ravel(), GY.ravel(), poly[:, :2])
    has = np.isfinite(top) & cell_in
    a = cell * cell
    diff = top[has] - base
    cut = float(np.sum(diff[diff > 0]) * a)
    fill = float(-np.sum(diff[diff < 0]) * a)
    coverage = float(has.sum() / max(1, cell_in.sum()) * 100.0)
    return {
        "base_z": base,
        "vol_above": cut,
        "vol_below": fill,
        "vol_net": cut - fill,
        "coverage": coverage,
        "points": used,
        "cell": cell,
        "area": polygon_area_2d(poly_pts),
        "max_h": float(diff.max()) if diff.size else 0.0,
    }
