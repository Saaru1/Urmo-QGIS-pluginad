# -*- coding: utf-8 -*-
"""
Symbology and rendering presets for MaRu ALS QgsPointCloudLayer (2D Canvas)
and shared color palettes with the 3D OpenGL viewer.

Default mode is Natural RGB (`apply_rgb_style`), matching the original MaRu
orthophoto-colorized point cloud appearance. Elevation, Classification, and
Intensity styles are fully customizable.
"""

import math
from typing import Dict, List, Optional, Tuple

from qgis.PyQt.QtGui import QColor
from qgis.core import (
    Qgis,
    QgsColorRampShader,
    QgsContrastEnhancement,
    QgsGradientColorRamp,
    QgsGradientStop,
    QgsPointCloudAttributeByRampRenderer,
    QgsPointCloudCategory,
    QgsPointCloudClassifiedRenderer,
    QgsPointCloudLayer,
    QgsPointCloudRgbRenderer,
)

# Shared Elevation Color Palettes: name -> list of (t, (R, G, B))
ELEVATION_RAMPS: Dict[str, List[Tuple[float, Tuple[int, int, int]]]] = {
    "terrain": [
        (0.00, (43, 131, 186)),
        (0.25, (171, 221, 164)),
        (0.50, (255, 255, 191)),
        (0.75, (253, 174, 97)),
        (1.00, (215, 25, 28)),
    ],
    "viridis": [
        (0.00, (68, 1, 84)),
        (0.25, (59, 82, 139)),
        (0.50, (33, 145, 140)),
        (0.75, (94, 201, 98)),
        (1.00, (253, 231, 37)),
    ],
    "turbo": [
        (0.00, (48, 18, 59)),
        (0.25, (40, 188, 235)),
        (0.50, (164, 252, 60)),
        (0.75, (251, 126, 33)),
        (1.00, (122, 4, 3)),
    ],
    "forest": [
        (0.00, (28, 78, 128)),
        (0.25, (194, 178, 128)),
        (0.50, (118, 180, 88)),
        (0.75, (45, 130, 50)),
        (1.00, (16, 68, 24)),
    ],
    "arctic": [
        (0.00, (12, 44, 132)),
        (0.25, (34, 94, 168)),
        (0.50, (65, 182, 196)),
        (0.75, (199, 233, 180)),
        (1.00, (255, 255, 255)),
    ],
}

DEFAULT_CLASS_COLORS: Dict[int, Tuple[int, int, int]] = {
    0: (170, 170, 170),
    1: (175, 175, 175),
    2: (166, 116, 72),
    3: (180, 220, 120),
    4: (90, 180, 70),
    5: (34, 125, 45),
    6: (225, 90, 70),
    7: (255, 0, 255),
    8: (200, 200, 0),
    9: (60, 130, 230),
    10: (120, 120, 120),
    11: (90, 90, 90),
    17: (240, 200, 80),
    18: (255, 0, 255),
}


class PointCloudSymbology:
    """Provides customizable 2D symbology presets for LiDAR point cloud layers."""

    # Current shared style configuration across 2D & 3D
    active_mode: str = "rgb"  # "rgb", "elevation", "classification", "intensity"
    ramp_name: str = "terrain"
    custom_z_min: Optional[float] = None
    custom_z_max: Optional[float] = None
    rgb_brightness: float = 1.05
    intensity_gamma: float = 0.85
    class_colors: Dict[int, Tuple[int, int, int]] = dict(DEFAULT_CLASS_COLORS)

    @classmethod
    def get_ramp_stops_rgb(cls, ramp_name: str) -> List[Tuple[int, int, int]]:
        stops = ELEVATION_RAMPS.get(ramp_name, ELEVATION_RAMPS["terrain"])
        return [rgb for _, rgb in stops]

    @classmethod
    def reset_custom_styles(cls):
        cls.ramp_name = "terrain"
        cls.custom_z_min = None
        cls.custom_z_max = None
        cls.rgb_brightness = 1.05
        cls.intensity_gamma = 0.85
        cls.class_colors = dict(DEFAULT_CLASS_COLORS)

    @classmethod
    def apply_current_style(cls, layer: QgsPointCloudLayer):
        """Applies the currently selected style mode to a 2D point cloud layer."""
        if cls.active_mode == "rgb":
            cls.apply_rgb_style(layer, brightness=cls.rgb_brightness)
        elif cls.active_mode == "elevation":
            cls.apply_elevation_style(
                layer,
                min_z=cls.custom_z_min,
                max_z=cls.custom_z_max,
                ramp_name=cls.ramp_name,
            )
        elif cls.active_mode == "classification":
            cls.apply_classification_style(layer, custom_colors=cls.class_colors)
        elif cls.active_mode == "intensity":
            cls.apply_intensity_style(layer)
        else:
            cls.apply_rgb_style(layer, brightness=cls.rgb_brightness)

    @classmethod
    def apply_rgb_style(cls, layer: QgsPointCloudLayer, brightness: float = 1.05):
        """
        Applies natural MaRu RGB styling (as it looks in nature) using Red, Green, Blue
        attributes. Falls back to classification if the LAZ lacks RGB channels.
        """
        if not layer or not layer.isValid():
            return

        try:
            attr_names = {a.name() for a in layer.attributes().attributes()}
        except Exception:
            attr_names = {"Red", "Green", "Blue"}

        if not {"Red", "Green", "Blue"}.issubset(attr_names):
            cls.apply_classification_style(layer, custom_colors=cls.class_colors)
            return

        # Determine if 16-bit (0..65535) or 8-bit (0..255)
        max_val = 65535.0
        try:
            stats = layer.statistics()
            if stats:
                rmax = stats.maximum("Red")
                if not math.isnan(rmax) and 0 < rmax <= 255.0:
                    max_val = 255.0
                elif not math.isnan(rmax) and rmax == 0.0:
                    # RGB channels exist in header but are all zero (older flight)
                    cls.apply_classification_style(layer, custom_colors=cls.class_colors)
                    return
        except Exception:
            pass

        adj_max = max(1.0, max_val / max(0.25, float(brightness)))
        renderer = QgsPointCloudRgbRenderer()
        renderer.setRedAttribute("Red")
        renderer.setGreenAttribute("Green")
        renderer.setBlueAttribute("Blue")

        for setter in (
            renderer.setRedContrastEnhancement,
            renderer.setGreenContrastEnhancement,
            renderer.setBlueContrastEnhancement,
        ):
            ce = QgsContrastEnhancement(Qgis.DataType.UnknownDataType)
            ce.setMinimumValue(0.0)
            ce.setMaximumValue(adj_max)
            ce.setContrastEnhancementAlgorithm(
                QgsContrastEnhancement.ContrastEnhancementAlgorithm.StretchToMinimumMaximum
            )
            setter(ce)

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    @classmethod
    def apply_elevation_style(
        cls,
        layer: QgsPointCloudLayer,
        min_z: Optional[float] = None,
        max_z: Optional[float] = None,
        ramp_name: str = "terrain",
    ):
        """Applies a customizable elevation color ramp to Z attribute."""
        if not layer or not layer.isValid():
            return

        z0 = 0.0 if min_z is None else float(min_z)
        z1 = 80.0 if max_z is None else float(max_z)

        if min_z is None or max_z is None:
            try:
                stats = layer.statistics()
                if stats:
                    s_min = stats.minimum("Z")
                    s_max = stats.maximum("Z")
                    if not math.isnan(s_min) and not math.isnan(s_max) and s_min < s_max:
                        if min_z is None:
                            z0 = float(s_min)
                        if max_z is None:
                            z1 = float(s_max)
            except Exception:
                pass

        if z1 <= z0:
            z1 = z0 + 10.0

        stops_def = ELEVATION_RAMPS.get(ramp_name, ELEVATION_RAMPS["terrain"])
        c_start = QColor(*stops_def[0][1])
        c_end = QColor(*stops_def[-1][1])
        mid_stops = [
            QgsGradientStop(t, QColor(*rgb))
            for t, rgb in stops_def[1:-1]
        ]

        ramp = QgsGradientColorRamp(c_start, c_end, False, mid_stops)
        shader = QgsColorRampShader(z0, z1, ramp, QgsColorRampShader.Interpolated)
        shader.classifyColorRamp(len(stops_def))

        renderer = QgsPointCloudAttributeByRampRenderer()
        renderer.setAttribute("Z")
        renderer.setColorRampShader(shader)

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    @classmethod
    def apply_classification_style(
        cls,
        layer: QgsPointCloudLayer,
        custom_colors: Optional[Dict[int, Tuple[int, int, int]]] = None,
    ):
        """Applies ASPRS standard or user-customized LAS classification colors."""
        if not layer or not layer.isValid():
            return

        cmap = custom_colors or cls.class_colors
        c = lambda code: QColor(*cmap.get(code, DEFAULT_CLASS_COLORS.get(code, (160, 160, 160))))

        categories = [
            QgsPointCloudCategory(1, c(1), "1: Klassifitseerimata", True),
            QgsPointCloudCategory(2, c(2), "2: Maapind (Ground)", True),
            QgsPointCloudCategory(3, c(3), "3: Madal taimestik", True),
            QgsPointCloudCategory(4, c(4), "4: Keskmine taimestik", True),
            QgsPointCloudCategory(5, c(5), "5: Kõrge taimestik (Mets)", True),
            QgsPointCloudCategory(6, c(6), "6: Hooned (Buildings)", True),
            QgsPointCloudCategory(7, c(7), "7: Müra (Low Noise)", False),
            QgsPointCloudCategory(9, c(9), "9: Vesi (Water)", True),
            QgsPointCloudCategory(17, c(17), "17: Sillad (Bridge)", True),
            QgsPointCloudCategory(18, c(18), "18: Kõrgmüra (High Noise)", False),
        ]

        renderer = QgsPointCloudClassifiedRenderer("Classification", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

    @classmethod
    def apply_intensity_style(
        cls,
        layer: QgsPointCloudLayer,
        min_val: float = 0.0,
        max_val: float = 2500.0,
    ):
        """Applies a high-contrast grayscale ramp based on LiDAR return intensity."""
        if not layer or not layer.isValid():
            return

        try:
            stats = layer.statistics()
            if stats:
                s_min = stats.minimum("Intensity")
                s_max = stats.maximum("Intensity")
                if not math.isnan(s_min) and not math.isnan(s_max) and s_min < s_max:
                    min_val = float(s_min)
                    max_val = float(s_max) * 0.75
        except Exception:
            pass

        ramp = QgsGradientColorRamp(
            QColor(15, 20, 28),
            QColor(250, 252, 255),
            False,
            [QgsGradientStop(0.5, QColor(145, 155, 168))],
        )
        shader = QgsColorRampShader(min_val, max(min_val + 1.0, max_val), ramp, QgsColorRampShader.Interpolated)
        shader.classifyColorRamp(3)

        renderer = QgsPointCloudAttributeByRampRenderer()
        renderer.setAttribute("Intensity")
        renderer.setColorRampShader(shader)

        layer.setRenderer(renderer)
        layer.triggerRepaint()
