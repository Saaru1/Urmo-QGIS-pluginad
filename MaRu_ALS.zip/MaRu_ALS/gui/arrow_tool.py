# -*- coding: utf-8 -*-
"""
Interactive Map Tool for dragging an arrow or rectangle across 1:2000 grid tiles on the QGIS canvas.
Provides live visual rubberbands (arrow / rectangle), tile polygon highlights, and area calculation.
"""

import math
from typing import List, Optional
from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.PyQt.QtGui import QColor, QCursor
from qgis.gui import QgsMapTool, QgsRubberBand, QgisInterface
from qgis.core import (
    QgsPointXY,
    QgsRectangle,
    QgsGeometry,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsProject,
)

from ..core.grid_engine import GridEngine, CRS_EPSG_3301
from ..i18n import tr
from .qt_compat import CursorCross, MouseButtonLeft, MouseButtonRight

MODE_ARROW = "arrow"
MODE_RECTANGLE = "rectangle"


class AlsArrowMapTool(QgsMapTool):
    """Map tool that captures click-and-drag directional arrows or rectangles and detects 1:2000 tiles."""

    MODE_ARROW = MODE_ARROW
    MODE_RECTANGLE = MODE_RECTANGLE

    # Emits: (tiles: List[str], azimuth: float, distance: float, p1_3301: QgsPointXY, p2_3301: QgsPointXY)
    tiles_selected = pyqtSignal(list, float, float, object, object)
    mode_changed = pyqtSignal(str)

    def __init__(self, canvas, iface: QgisInterface):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        self.mode = MODE_ARROW
        self.is_dragging = False
        self.start_point: Optional[QgsPointXY] = None
        self.current_point: Optional[QgsPointXY] = None

        # Arrow rubberband (line)
        self.arrow_rubber = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.arrow_rubber.setColor(QColor(235, 60, 40, 230))
        self.arrow_rubber.setWidth(3)

        # Rectangle rubberband (box outline & fill)
        self.rect_rubber = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rect_rubber.setColor(QColor(14, 165, 233, 230))
        self.rect_rubber.setFillColor(QColor(56, 189, 248, 50))
        self.rect_rubber.setWidth(2)

        # Grid tile rubberband (polygon highlight)
        self.grid_rubber = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.grid_rubber.setColor(QColor(30, 140, 240, 200))
        self.grid_rubber.setFillColor(QColor(40, 160, 255, 60))
        self.grid_rubber.setWidth(2)

        # Set crosshair cursor
        if CursorCross:
            self.setCursor(QCursor(CursorCross))

    def set_mode(self, mode: str):
        """Switches between arrow (directional) and rectangle (area AOI) selection modes."""
        if mode in (MODE_ARROW, MODE_RECTANGLE) and mode != self.mode:
            self.mode = mode
            self.reset_rubberbands()
            self.mode_changed.emit(mode)
            if self.isActive():
                prompt = (
                    tr("tool_prompt_start_rect")
                    if self.mode == MODE_RECTANGLE
                    else tr("tool_prompt_start")
                )
                self.iface.mainWindow().statusBar().showMessage(prompt, 5000)

    def activate(self):
        super().activate()
        prompt = (
            tr("tool_prompt_start_rect")
            if self.mode == MODE_RECTANGLE
            else tr("tool_prompt_start")
        )
        self.iface.mainWindow().statusBar().showMessage(prompt, 5000)

    def deactivate(self):
        self.reset_rubberbands()
        self.is_dragging = False
        super().deactivate()

    def reset_rubberbands(self):
        """Clears all dynamic visual preview shapes."""
        if self.arrow_rubber:
            self.arrow_rubber.reset(QgsWkbTypes.LineGeometry)
        if self.rect_rubber:
            self.rect_rubber.reset(QgsWkbTypes.PolygonGeometry)
        if self.grid_rubber:
            self.grid_rubber.reset(QgsWkbTypes.PolygonGeometry)

    def canvasPressEvent(self, event):
        if event.button() == MouseButtonLeft:
            self.is_dragging = True
            self.start_point = event.mapPoint()
            self.current_point = event.mapPoint()
            self.reset_rubberbands()
        elif event.button() == MouseButtonRight:
            # Cancel current drag
            self.is_dragging = False
            self.reset_rubberbands()
            self.iface.mainWindow().statusBar().clearMessage()

    def canvasMoveEvent(self, event):
        if not self.is_dragging or not self.start_point:
            return

        self.current_point = event.mapPoint()
        dest_crs = self.canvas.mapSettings().destinationCrs()

        # Transform to EPSG:3301 for deterministic grid math
        p1_3301 = GridEngine.transform_point_to_3301(self.start_point, dest_crs)
        p2_3301 = GridEngine.transform_point_to_3301(self.current_point, dest_crs)

        if self.mode == MODE_ARROW:
            tiles = GridEngine.trace_tiles_along_segment(p1_3301, p2_3301)
            azimuth = GridEngine.calculate_azimuth(p1_3301, p2_3301)
            dist = GridEngine.calculate_distance(p1_3301, p2_3301)

            # 1. Update Arrow Rubberband (in canvas CRS coordinates)
            self.update_arrow_rubberband(self.start_point, self.current_point)

            # 2. Update Grid Highlight Rubberband
            self.update_grid_rubberband(tiles, dest_crs)

            # 3. Update Status Bar
            tile_preview = ", ".join(tiles[:5])
            if len(tiles) > 5:
                tile_preview += f" ... (+{len(tiles) - 5})"
            msg = tr("tool_dragging_info", deg=azimuth, dist=dist, count=len(tiles), tiles=tile_preview)
            self.iface.mainWindow().statusBar().showMessage(msg, 2000)

        elif self.mode == MODE_RECTANGLE:
            rect_3301 = QgsRectangle(
                min(p1_3301.x(), p2_3301.x()),
                min(p1_3301.y(), p2_3301.y()),
                max(p1_3301.x(), p2_3301.x()),
                max(p1_3301.y(), p2_3301.y()),
            )
            tiles = GridEngine.get_tiles_in_rect(rect_3301)

            # 1. Update Rectangle Rubberband
            self.update_rect_rubberband(self.start_point, self.current_point)

            # 2. Update Grid Highlight Rubberband
            self.update_grid_rubberband(tiles, dest_crs)

            # 3. Update Status Bar
            w = rect_3301.width()
            h = rect_3301.height()
            tile_preview = ", ".join(tiles[:6])
            if len(tiles) > 6:
                tile_preview += f" ... (+{len(tiles) - 6})"
            msg = tr(
                "tool_dragging_rect_info",
                w=w,
                h=h,
                km_w=w / 1000.0,
                km_h=h / 1000.0,
                count=len(tiles),
                tiles=tile_preview,
            )
            self.iface.mainWindow().statusBar().showMessage(msg, 2000)

    def canvasReleaseEvent(self, event):
        if not self.is_dragging or event.button() != MouseButtonLeft:
            return

        self.is_dragging = False
        end_point = event.mapPoint()
        dest_crs = self.canvas.mapSettings().destinationCrs()

        p1_3301 = GridEngine.transform_point_to_3301(self.start_point, dest_crs)
        p2_3301 = GridEngine.transform_point_to_3301(end_point, dest_crs)
        self.reset_rubberbands()

        if self.mode == MODE_ARROW:
            tiles = GridEngine.trace_tiles_along_segment(p1_3301, p2_3301)
            azimuth = GridEngine.calculate_azimuth(p1_3301, p2_3301)
            dist = GridEngine.calculate_distance(p1_3301, p2_3301)

            if not tiles:
                # Check if clicked on a single tile without dragging
                single_tile = GridEngine.point_to_tile(p1_3301.x(), p1_3301.y())
                if GridEngine.is_valid_tile(single_tile):
                    tiles = [single_tile]

            if tiles:
                self.iface.mainWindow().statusBar().showMessage(
                    tr("tool_tiles_found_count", count=len(tiles), tiles=", ".join(tiles)),
                    5000
                )
                self.tiles_selected.emit(tiles, azimuth, dist, p1_3301, p2_3301)
            else:
                self.iface.mainWindow().statusBar().showMessage(tr("tool_no_tiles_detected"), 4000)

        elif self.mode == MODE_RECTANGLE:
            rect_3301 = QgsRectangle(
                min(p1_3301.x(), p2_3301.x()),
                min(p1_3301.y(), p2_3301.y()),
                max(p1_3301.x(), p2_3301.x()),
                max(p1_3301.y(), p2_3301.y()),
            )
            tiles = GridEngine.get_tiles_in_rect(rect_3301)
            if not tiles:
                single_tile = GridEngine.point_to_tile(p1_3301.x(), p1_3301.y())
                if GridEngine.is_valid_tile(single_tile):
                    tiles = [single_tile]

            if not tiles:
                self.iface.mainWindow().statusBar().showMessage(tr("tool_no_tiles_detected"), 4000)
                return

            cx = (rect_3301.xMinimum() + rect_3301.xMaximum()) / 2.0
            cy = (rect_3301.yMinimum() + rect_3301.yMaximum()) / 2.0

            # Sort tiles concentric outward from the center point of the rectangle
            def _dist_sq(tid: str) -> float:
                b = GridEngine.get_tile_bounds(tid)
                if not b:
                    return 1e12
                return ((b[0] + b[2]) / 2.0 - cx) ** 2 + ((b[1] + b[3]) / 2.0 - cy) ** 2

            tiles.sort(key=_dist_sq)

            # Safety check if user selected a huge area (e.g. > 36 tiles / 36 km²)
            if len(tiles) > 36:
                from qgis.PyQt.QtWidgets import QMessageBox
                km2 = float(len(tiles))
                reply = QMessageBox.question(
                    self.iface.mainWindow(),
                    tr("tool_rect_confirm_title"),
                    tr("tool_rect_confirm_msg", count=len(tiles), km2=km2),
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes,
                )
                if reply != QMessageBox.StandardButton.Yes:
                    return

            w = rect_3301.width()
            h = rect_3301.height()
            dist = max(w, h)
            center_3301 = QgsPointXY(cx, cy)
            azimuth = GridEngine.calculate_azimuth(p1_3301, p2_3301) if dist > 20.0 else 0.0

            self.iface.mainWindow().statusBar().showMessage(
                tr("tool_tiles_found_count", count=len(tiles), tiles=", ".join(tiles[:8])),
                5000,
            )
            self.tiles_selected.emit(tiles, azimuth, dist, center_3301, p2_3301)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.is_dragging = False
            self.reset_rubberbands()
            self.iface.mainWindow().statusBar().clearMessage()

    def update_rect_rubberband(self, p1: QgsPointXY, p2: QgsPointXY):
        """Draws the dynamic rectangular selection box."""
        self.rect_rubber.reset(QgsWkbTypes.PolygonGeometry)
        min_x = min(p1.x(), p2.x())
        max_x = max(p1.x(), p2.x())
        min_y = min(p1.y(), p2.y())
        max_y = max(p1.y(), p2.y())
        if (max_x - min_x) < 1.0 and (max_y - min_y) < 1.0:
            return

        rect = QgsRectangle(min_x, min_y, max_x, max_y)
        geom = QgsGeometry.fromRect(rect)
        self.rect_rubber.addGeometry(geom, None)

    def update_arrow_rubberband(self, p1: QgsPointXY, p2: QgsPointXY):
        """Draws the arrow shaft and triangular wing tips at the head."""
        self.arrow_rubber.reset(QgsWkbTypes.LineGeometry)

        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        length = math.hypot(dx, dy)
        if length < 1.0:
            return

        phi = math.atan2(dy, dx)
        # Scaled wing length based on pixels on screen
        mupp = self.canvas.mapUnitsPerPixel()
        head_len = min(length * 0.35, max(mupp * 22.0, 10.0))
        wing_angle = math.radians(28.0)

        # Wings
        w1_x = p2.x() - head_len * math.cos(phi - wing_angle)
        w1_y = p2.y() - head_len * math.sin(phi - wing_angle)
        w2_x = p2.x() - head_len * math.cos(phi + wing_angle)
        w2_y = p2.y() - head_len * math.sin(phi + wing_angle)

        self.arrow_rubber.addPoint(p1, False)
        self.arrow_rubber.addPoint(p2, False)
        self.arrow_rubber.addPoint(QgsPointXY(w1_x, w1_y), False)
        self.arrow_rubber.addPoint(p2, False)
        self.arrow_rubber.addPoint(QgsPointXY(w2_x, w2_y), True)

    def update_grid_rubberband(self, tiles: List[str], dest_crs):
        """Highlights the polygon footprint of each intersected 1:2000 grid tile."""
        self.grid_rubber.reset(QgsWkbTypes.PolygonGeometry)
        if not tiles:
            return

        needs_reproject = (dest_crs.isValid() and dest_crs.authid() != "EPSG:3301")
        xform = QgsCoordinateTransform(GridEngine.CRS_EPSG_3301, dest_crs, QgsProject.instance()) if needs_reproject else None

        for tile_id in tiles:
            geom = GridEngine.tile_to_polygon(tile_id)
            if not geom:
                continue
            if xform:
                geom.transform(xform)
            self.grid_rubber.addGeometry(geom, None)

            self.iface.mainWindow().statusBar().clearMessage()

    def update_arrow_rubberband(self, p1: QgsPointXY, p2: QgsPointXY):
        """Draws the arrow shaft and triangular wing tips at the head."""
        self.arrow_rubber.reset(QgsWkbTypes.LineGeometry)

        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        length = math.hypot(dx, dy)
        if length < 1.0:
            return

        phi = math.atan2(dy, dx)
        # Scaled wing length based on pixels on screen
        mupp = self.canvas.mapUnitsPerPixel()
        head_len = min(length * 0.35, max(mupp * 22.0, 10.0))
        wing_angle = math.radians(28.0)

        # Wings
        w1_x = p2.x() - head_len * math.cos(phi - wing_angle)
        w1_y = p2.y() - head_len * math.sin(phi - wing_angle)
        w2_x = p2.x() - head_len * math.cos(phi + wing_angle)
        w2_y = p2.y() - head_len * math.sin(phi + wing_angle)

        self.arrow_rubber.addPoint(p1, False)
        self.arrow_rubber.addPoint(p2, False)
        self.arrow_rubber.addPoint(QgsPointXY(w1_x, w1_y), False)
        self.arrow_rubber.addPoint(p2, False)
        self.arrow_rubber.addPoint(QgsPointXY(w2_x, w2_y), True)

    def update_grid_rubberband(self, tiles: List[str], dest_crs):
        """Highlights the polygon footprint of each intersected 1:2000 grid tile."""
        self.grid_rubber.reset(QgsWkbTypes.PolygonGeometry)
        if not tiles:
            return

        needs_reproject = (dest_crs.isValid() and dest_crs.authid() != "EPSG:3301")
        xform = QgsCoordinateTransform(GridEngine.CRS_EPSG_3301, dest_crs, QgsProject.instance()) if needs_reproject else None

        for tile_id in tiles:
            geom = GridEngine.tile_to_polygon(tile_id)
            if not geom:
                continue
            if xform:
                geom.transform(xform)
            self.grid_rubber.addGeometry(geom, None)
