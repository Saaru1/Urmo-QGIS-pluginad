# MaRu ALS 3D — QGIS Pistikprogramm

**Maa- ja Ruumiameti (MaRu) 3D aerolaserskaneerimise (ALS) kõrguspunktide allalaadimine, droonilend ja 3D mõõdistus.**

See pistikprogramm võimaldab QGIS-is lohistada kaardil noole üle huviala, tuvastada automaatselt läbitavad 1:2000 kaardiruudud, laadida taustal alla vastavad LAZ punktipilved ning lennata andmetes vabalt ringi nagu drooniga (WASD + hiir) koos reaalajas telemeetria ja 3D mõõtmisrežiimiga.

---

## Peamised funktsioonid

### 1. Interaktiivne noole tööriist (Nupp 1)
- Klõpsa ja lohista kaardil nool üle ala.
- Kuvatakse reaalajas nool, asimut ja läbitavate 1:2000 ruutude piirjooned.
- Pistikprogramm tuvastab ruudud matemaatiliselt EPSG:3301 koordinaatide põhjal ja laeb taustal alla vastavad LAZ punktipilved.

### 2. Droonilennu 3D juhtimine (Nupp 2)
Ava 3D vaade ja lenda punktipilves ringi nagu drooniga:
- **`[W]` / `[S]`**: Lend otse ette / taha piki vaatesuunda
- **`[A]` / `[D]`**: Külgsuunaline lend vasakule / paremale (strafe)
- **`[Tühik]` (Space)**: Tõus (kõrguse suurendamine / Climb)
- **`[Left Ctrl]`**: Laskumine (kõrguse vähendamine / Descend)
- **`[Shift]`**: Kiirendus / Turbo režiim ($3\times$ kiirus)
- **`[Alt]`**: Aeglane täppislend
- **`[Hiir]` (paremklõps või lohistamine)**: Gimbal kaamera pööramine (pitch & yaw)

### 3. Reaalajas HUD ja Telemeetria
3D vaate kohale kuvatakse interaktiivne ekraaninäit (HUD):
- **Ülanurk**: Lennuandmete aasta ja tüüp (nt `2023 mets` / `2021 tava`) ja aktiivne 1:2000 ruut.
- **Juhtimise spikker**: Kiirklahvide meeldetuletus ekraani ülaosas.
- **Telemeetria (all vasakul)**:
  - Kõrgus ($H$ meetrites merepinnast)
  - Kiirus ($km/h$)
  - Suund / Kompass (kraadid $0-360^\circ$ ja ilmakaar koos kompassiroosiga)
  - Maailmakoordinaadid $X, Y$ (EPSG:3301 L-EST97)
- **Minikaart (all paremal)**:
  - Kuvab laaditud 1:2000 ruudud ja nende numbrid.
  - Kuvab drooni läbitud lennuteekonna joone (*breadcrumbs*).
  - Kuvab drooni asukohapunkti ja vaatekoonuse.

### 4. 3D Mõõtmisrežiim (`[M]` klahv)
Võimaldab mõõta vahemaid, pindalasid ja mahtusid otse 3D punktipilves:
- **Kauguse / Joone mõõtmine**:
  - Klõpsa kaht punkti punktipilves.
  - Kuvab: 3D kaugus ($D$), horisontaalne kaugus ($\Delta H$), kõrguste vahe ($\Delta Z$), kaldenurk kraadides ja tõusuprotsent (%).
- **Pindala ja Mahu mõõtmine**:
  - Klõpsa 3 või enam punkti hulknurga moodustamiseks.
  - Kuvab: Pindala ($m^2$ ja $ha$), ümbermõõt ($m$) ja hinnanguline maht ($m^3$) võrdlustasapinna suhtes.
- **`[C]` klahv**: Tühjendab mõõtmispunktid.

### 5. Dünaamiline ruutude automaatne laadimine (Infinite Flight)
Kui droon lendab laaditud ruutude piirile lähemale kui 350 m, tuvastab pistikprogramm lennusuunas oleva järgmise 1:2000 ruudu ja laeb selle Geoportaalist taustal automaatselt juurde, tagades katkematu lennukogemuse.

### 6. Lennuaastate ja kihtide haldur (Nupp 3)
Dokitav paneel kogub Geoportaalist kõik antud ruudu lennud läbi aastate:
- `tava` (kevadine lehtedeta lend — parim maapinna / DTM jaoks)
- `mets` (suvine lehes puudega lend — parim metsanduse ja võrastiku jaoks)
- Võimaldab ühe klõpsuga vahetada aktiivset aastat või laadida mitu kihti kõrvuti.

### 7. Keelte tugi EST / ENG
Vaikimisi eesti keeles (EST). Seadete nupu kaudu vahetatav inglise keelele (ENG).

---

## Kuidas uuendust rakendada

Kuna pistikprogramm on seotud kaustaga:
`C:\Users\Gamer\AppData\Roaming\QGIS\QGIS4\profiles\default\python\plugins\MaRu ALS`

Lihtsalt taaskäivita QGIS või laadi pistikprogramm uuesti (nt Plugin Reloader abil).
Valmis `.zip` arhiiv asub samuti failis [`A:\Maru als\MaRu ALS.zip`](file:///A:/Maru%20als/MaRu%20ALS.zip).
