# -*- coding: utf-8 -*-
"""
MaRu ALS 3D QGIS Plugin.
"""


def classFactory(iface):
    """Factory function called by QGIS to instantiate the plugin."""
    from .plugin import MaruAlsPlugin
    return MaruAlsPlugin(iface)
