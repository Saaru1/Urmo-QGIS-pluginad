# -*- coding: utf-8 -*-
"""
Internationalization (i18n) module for MaRu ALS QGIS Plugin.
Supports Estonian (EST - default) and English (ENG).
"""

from qgis.core import QgsSettings

LANG_ET = "et"
LANG_EN = "en"

STRINGS = {
    # Plugin & Toolbar
    "plugin_name": {
        "et": "MaRu ALS 3D",
        "en": "MaRu ALS 3D"
    },
    "toolbar_title": {
        "et": "MaRu ALS 3D tööriistariba",
        "en": "MaRu ALS 3D Toolbar"
    },
    "tool_arrow_name": {
        "et": "Vali kaardiruudud noolega",
        "en": "Select Grid Tiles by Arrow"
    },
    "tool_arrow_tooltip": {
        "et": "Lohista kaardil nool: tuvastab 1:2000 kaardiruudud ja laeb alla ALS 3D punktipilve andmed.",
        "en": "Drag an arrow on map: detects 1:2000 grid tiles and downloads ALS 3D point cloud data."
    },
    "btn_3d_name": {
        "et": "Lülita 3D vaade",
        "en": "Toggle 3D View"
    },
    "btn_3d_tooltip": {
        "et": "Ava või fokuseeri 3D vaade ja joonda vaatenurk noole suunale.",
        "en": "Open or focus 3D view and orient camera angle in arrow direction."
    },
    "btn_layers_name": {
        "et": "Lennuaastad ja andmekihid",
        "en": "Flight Years & Data Layers"
    },
    "btn_layers_tooltip": {
        "et": "Ava lennuaastate ja kihtide halduspaneel (vali tava- ja metsalendude vahel).",
        "en": "Open flight years and layer management panel (select between regular and forest flights)."
    },
    "btn_grid_name": {
        "et": "1:2000 kaardivõrgu kiht",
        "en": "1:2000 Grid Layer"
    },
    "btn_grid_tooltip": {
        "et": "Lülita Maa- ja Ruumiameti 1:2000 kaardilehtede võrgu kuvamine sisse/välja.",
        "en": "Toggle Maa- ja Ruumiamet 1:2000 map grid overlay on/off."
    },
    "btn_symbology_name": {
        "et": "Punktipilve värving",
        "en": "Point Cloud Symbology"
    },
    "btn_symbology_tooltip": {
        "et": "Muuda punktipilve kuvamist: kõrguse, klassifikatsiooni või peegeldustugevuse järgi.",
        "en": "Change point cloud display: by elevation, classification, or intensity."
    },
    "btn_settings_name": {
        "et": "Seaded",
        "en": "Settings"
    },
    "btn_settings_tooltip": {
        "et": "Ava MaRu ALS seadete aken (keel, allalaadimiskaust, lennueelistus).",
        "en": "Open MaRu ALS settings dialog (language, cache directory, flight preference)."
    },

    # Interactive Arrow Tool
    "tool_prompt_start": {
        "et": "Klõpsa ja lohista nool üle 1:2000 kaardiruutude...",
        "en": "Click and drag an arrow across 1:2000 grid tiles..."
    },
    "tool_dragging_info": {
        "et": "Suund: {deg:.1f}° | Pikkus: {dist:.0f} m | Ruudud ({count}): {tiles}",
        "en": "Heading: {deg:.1f}° | Length: {dist:.0f} m | Tiles ({count}): {tiles}"
    },
    "tool_no_tiles_detected": {
        "et": "Noole trajektooril ei leitud ühtegi 1:2000 kaardiruutu.",
        "en": "No 1:2000 grid tiles detected along arrow trajectory."
    },
    "tool_tiles_found_count": {
        "et": "Tuvastatud {count} kaardiruutu: {tiles}",
        "en": "Detected {count} grid tile(s): {tiles}"
    },
    "tool_prompt_start_rect": {
        "et": "Klõpsa ja lohista ristkülik üle soovitud piirkonna (AOI)...",
        "en": "Click and drag a rectangle over the desired area of interest (AOI)..."
    },
    "tool_dragging_rect_info": {
        "et": "AOI: {w:.0f} m × {h:.0f} m ({km_w:.1f} × {km_h:.1f} km) | Ruudud ({count}): {tiles}",
        "en": "AOI: {w:.0f} m × {h:.0f} m ({km_w:.1f} × {km_h:.1f} km) | Tiles ({count}): {tiles}"
    },
    "tool_rect_confirm_title": {
        "et": "Suur valikuala (AOI)",
        "en": "Large Selection Area (AOI)"
    },
    "tool_rect_confirm_msg": {
        "et": "Valitud ristkülik katab {count} kaardiruutu ({km2:.1f} km²).\nNii suure ala allalaadimine võib võtta aega ja kettaruumi.\n\nKas soovid jätkata?",
        "en": "Selected rectangle covers {count} grid tiles ({km2:.1f} km²).\nDownloading such a large area may take significant time and disk space.\n\nDo you want to proceed?"
    },

    # Downloader & Data Processing
    "downloading_tile": {
        "et": "Laadin alla ruutu {tile}: {filename} ({size})...",
        "en": "Downloading tile {tile}: {filename} ({size})..."
    },
    "download_progress": {
        "et": "Laadimine: {done}/{total} faili valmis ({percent}%)",
        "en": "Download: {done}/{total} files done ({percent}%)"
    },
    "download_complete": {
        "et": "Kõik {count} LAZ faili edukalt alla laaditud ja avatud!",
        "en": "All {count} LAZ file(s) successfully downloaded and opened!"
    },
    "download_failed": {
        "et": "Ruudu {tile} faili allalaadimine ebaõnnestus: {error}",
        "en": "Failed to download tile {tile}: {error}"
    },
    "fetching_metadata": {
        "et": "Pärin Maa- ja Ruumiameti serverist ruudu {tile} lennuandmeid...",
        "en": "Querying flight data for tile {tile} from Maa- ja Ruumiamet..."
    },
    "no_als_data_tile": {
        "et": "Kaardiruudule {tile} ei leitud Geoportaalist LAZ kõrgusandmeid.",
        "en": "No LAZ elevation data found on Geoportaal for tile {tile}."
    },

    # Dock Panel (Layer & Year Manager)
    "dock_title": {
        "et": "MaRu ALS: Lennuaastad ja andmekihid",
        "en": "MaRu ALS: Flight Years & Data Layers"
    },
    "dock_section_session_tiles": {
        "et": "Sessioonis valitud ruudud",
        "en": "Selected Tiles in Session"
    },
    "dock_col_tile": {
        "et": "Kaardiruut",
        "en": "Grid Tile"
    },
    "dock_col_year": {
        "et": "Lennuaasta",
        "en": "Flight Year"
    },
    "dock_col_type": {
        "et": "Lennutüüp",
        "en": "Flight Type"
    },
    "dock_col_size": {
        "et": "Maht",
        "en": "Size"
    },
    "dock_col_status": {
        "et": "Olek",
        "en": "Status"
    },
    "dock_status_loaded": {
        "et": "Kaardil",
        "en": "On Canvas"
    },
    "dock_status_cached": {
        "et": "Kettal (vahemälus)",
        "en": "Cached (on disk)"
    },
    "dock_status_available": {
        "et": "Allalaaditav",
        "en": "Available"
    },
    "dock_btn_load_selected": {
        "et": "Ava valitud kiht (3D + 2D)",
        "en": "Open Selected Layer (3D + 2D)"
    },
    "dock_btn_remove_tile": {
        "et": "Eemalda nimekirjast",
        "en": "Remove from List"
    },
    "dock_btn_clear_all": {
        "et": "Tühjenda nimekiri",
        "en": "Clear List"
    },
    "dock_type_tava": {
        "et": "Tavalend (kevadine/raagus)",
        "en": "Regular flight (spring/leaf-off)"
    },
    "dock_type_mets": {
        "et": "Metsalend (suvine/lehes)",
        "en": "Forest flight (summer/leaf-on)"
    },
    "dock_type_madal": {
        "et": "Madallend (tiheasustus)",
        "en": "Low-altitude flight (urban)"
    },
    "dock_type_keypoint": {
        "et": "Võtmepunktid",
        "en": "Keypoints"
    },

    # Symbology Menu
    "symbology_elevation": {
        "et": "Värvi kõrguse (Z) järgi",
        "en": "Color by Elevation (Z)"
    },
    "symbology_classification": {
        "et": "Värvi klassifikatsiooni järgi",
        "en": "Color by Classification"
    },
    "symbology_intensity": {
        "et": "Värvi peegeldustugevuse järgi",
        "en": "Color by Intensity"
    },
    "symbology_rgb": {
        "et": "Värvi RGB ortofoto järgi",
        "en": "Color by RGB"
    },

    # Settings Dialog
    "settings_title": {
        "et": "MaRu ALS seaded",
        "en": "MaRu ALS Settings"
    },
    "settings_group_general": {
        "et": "Üldised seaded",
        "en": "General Settings"
    },
    "settings_language": {
        "et": "Keel / Language:",
        "en": "Language / Keel:"
    },
    "settings_lang_et": {
        "et": "Eesti keel (EST)",
        "en": "Estonian (EST)"
    },
    "settings_lang_en": {
        "et": "Inglise keel (ENG)",
        "en": "English (ENG)"
    },
    "settings_flight_pref": {
        "et": "Vaikimisi lennueelistus:",
        "en": "Default Flight Preference:"
    },
    "settings_pref_latest_any": {
        "et": "Kõige uuem lend (ükskõik kumb)",
        "en": "Latest Flight (Any type)"
    },
    "settings_pref_latest_tava": {
        "et": "Uusim tavalend (kevad/maapind)",
        "en": "Latest Regular Flight (Spring/Ground)"
    },
    "settings_pref_latest_mets": {
        "et": "Uusim metsalend (suvi/taimestik)",
        "en": "Latest Forest Flight (Summer/Canopy)"
    },
    "settings_group_cache": {
        "et": "Vahemälu ja allalaadimine",
        "en": "Cache & Downloads"
    },
    "settings_cache_dir": {
        "et": "Allalaadimiskaust:",
        "en": "Download Directory:"
    },
    "settings_cache_browse": {
        "et": "Sirvi...",
        "en": "Browse..."
    },
    "settings_cache_usage": {
        "et": "Vahemälu maht kettal: {size}",
        "en": "Disk cache usage: {size}"
    },
    "settings_cache_open": {
        "et": "Ava kaust...",
        "en": "Open Folder..."
    },
    "settings_cache_clear": {
        "et": "Tühjenda vahemälu...",
        "en": "Clear Cache..."
    },
    "settings_cache_cleared": {
        "et": "Vahemälu on tühjendatud.",
        "en": "Cache has been cleared."
    },
    "settings_group_view": {
        "et": "Vaate ja 3D seaded",
        "en": "View & 3D Settings"
    },
    "settings_auto_3d": {
        "et": "Ava pärast allalaadimist automaatselt 3D vaade",
        "en": "Automatically open 3D view after download"
    },
    "settings_rotate_2d": {
        "et": "Pööra 2D kaart noole suunale",
        "en": "Rotate 2D map canvas in arrow direction"
    },
    "settings_render_engine": {
        "et": "3D graafikamootor (Riistvaraline FBO / CPU ühilduvus):",
        "en": "3D Render Engine (Hardware FBO / CPU Compatibility):"
    },
    "engine_auto": {
        "et": "Automaatne (Riistvaraline OpenGL FBO kõigil GPU-del, sh Intel Arc; automaatne CPU varulahendus)",
        "en": "Automatic (Hardware OpenGL FBO on all GPUs including Intel Arc; automatic CPU fallback)"
    },
    "engine_fbo": {
        "et": "Riistvaraline — Offscreen OpenGL FBO (kuni 14M punkti, GPU riistvarakiirendus)",
        "en": "Hardware — Offscreen OpenGL FBO (up to 14M points, GPU hardware accelerated)"
    },
    "engine_software": {
        "et": "Ühilduvusrežiim — Puhas NumPy CPU 3D (OpenGL-vaba varurežiim)",
        "en": "Compatibility Mode — Pure NumPy CPU 3D (OpenGL-free fallback)"
    },
    "settings_group_sky": {
        "et": "3D Taevas ja horisont",
        "en": "3D Skybox & Horizon"
    },
    "settings_sky_mode": {
        "et": "Taeva ja horisondi režiim (Skybox):",
        "en": "Skybox & Horizon Mode:"
    },
    "sky_mode_off": {
        "et": "Väljas (Tume kokpiti taust / Classic Dark)",
        "en": "Off (Classic Dark Cockpit)"
    },
    "sky_mode_procedural": {
        "et": "1. Protseduuriline atmosfääritaevas & horisondi hägu",
        "en": "1. Procedural Atmospheric Sky & Horizon Haze"
    },
    "sky_mode_panorama": {
        "et": "2. 360° Fotorealistlik panoraamtaevas (Läänemere pilved)",
        "en": "2. 360° Photorealistic Panorama (Baltic Clouds)"
    },
    "sky_mode_fog": {
        "et": "3. Horisondi kauguse udu (Distance Horizon Fog)",
        "en": "3. Distance Horizon Fog (Dark Cockpit)"
    },
    "sky_mode_proc_fog": {
        "et": "4. Protseduuriline taevas + Horisondi udu",
        "en": "4. Procedural Sky + Horizon Fog"
    },
    "sky_mode_pano_fog": {
        "et": "5. Panoraamtaevas + Horisondi udu",
        "en": "5. Panorama Sky + Horizon Fog"
    },
    "settings_sky_help": {
        "et": "Valitud taevas arvutatakse reaalajas vastavalt vaatenurgale. Kauguse udu hajutab punktipilve servad sujuvalt horisondihämusse.",
        "en": "Selected sky is calculated in real time matching camera tilt. Distance fog blends point cloud edges smoothly into horizon haze."
    },
    "settings_sky_procedural": {
        "et": "1. Protseduuriline atmosfääritaevas & horisondi hägu",
        "en": "1. Procedural Atmospheric Sky & Horizon Haze"
    },
    "settings_sky_panorama": {
        "et": "2. 360° Fotorealistlik panoraamtaevas (Päevane Läänemere taevas)",
        "en": "2. 360° Photorealistic Panorama Skybox (Baltic Day)"
    },
    "settings_sky_fog": {
        "et": "3. Horisondi kauguse udu (Distance Horizon Fog)",
        "en": "3. Distance Horizon Fog"
    },
    "settings_btn_save": {
        "et": "Salvesta",
        "en": "Save"
    },
    "settings_btn_cancel": {
        "et": "Loobu",
        "en": "Cancel"
    },

    # Messages & Notifications
    "notify_crs_warn_title": {
        "et": "Koordinaatsüsteemi hoiatus",
        "en": "Coordinate System Warning"
    },
    "notify_crs_warn_text": {
        "et": "Projekti koordinaatsüsteem ei ole EPSG:3301 (L-EST97). Tööriist teisendab koordinaadid automaatselt, kuid parima täpsuse huvides on soovitatav kasutada EPSG:3301.",
        "en": "Project CRS is not EPSG:3301 (L-EST97). Coordinates will be reprojected automatically, but EPSG:3301 is recommended for best precision."
    },
    # 3D Drone Flight Panel & Cockpit
    "drone_dock_title": {
        "et": "MaRu ALS: 3D Droonijuhtimine",
        "en": "MaRu ALS: 3D Drone Cockpit"
    },
    "drone_btn_start": {
        "et": "▶ Alusta droonilendu",
        "en": "▶ Start Drone Flight"
    },
    "drone_btn_stop": {
        "et": "■ Peata lend",
        "en": "■ Stop Flight"
    },
    "drone_status_flying": {
        "et": "LENDAB",
        "en": "FLYING"
    },
    "drone_status_idle": {
        "et": "OOTEL",
        "en": "IDLE"
    },
    "drone_group_telemetry": {
        "et": "Reaalajas telemeetria",
        "en": "Live Telemetry"
    },
    "drone_tele_altitude": {
        "et": "Kõrgus (Z):",
        "en": "Altitude (Z):"
    },
    "drone_tele_speed": {
        "et": "Kiirus:",
        "en": "Speed:"
    },
    "drone_tele_heading": {
        "et": "Lennusuund:",
        "en": "Heading:"
    },
    "drone_tele_pitch": {
        "et": "Gimbal (kalle):",
        "en": "Gimbal (Pitch):"
    },
    "drone_tele_coords": {
        "et": "EPSG:3301:",
        "en": "EPSG:3301:"
    },
    "drone_tele_tile": {
        "et": "Kaardiruut:",
        "en": "Grid Tile:"
    },
    "drone_group_measure": {
        "et": "3D Mõõdistusrežiim",
        "en": "3D Measurement Mode"
    },
    "drone_measure_off": {
        "et": "Väljas",
        "en": "Off"
    },
    "drone_measure_dist": {
        "et": "📏 Kaugus & kalle",
        "en": "📏 Distance & Slope"
    },
    "drone_measure_area": {
        "et": "📐 Pindala",
        "en": "📐 Area"
    },
    "drone_measure_vol": {
        "et": "🧊 Maht",
        "en": "🧊 Volume"
    },
    "drone_measure_clear": {
        "et": "Tühjenda mõõtmised",
        "en": "Clear Measurements"
    },
    "drone_group_stream": {
        "et": "Automaatne ruutude voogedastus",
        "en": "Auto-Streaming Adjacent Tiles"
    },
    "drone_stream_checkbox": {
        "et": "Laadi automaatselt uued ruudud lennusuunas (350m ette)",
        "en": "Auto-download new tiles ahead in flight (350m)"
    },
    "drone_group_controls": {
        "et": "Juhtnupud",
        "en": "Controls Guide"
    },
    "grid_layer_name": {
        "et": "Maa-amet Kaardilehed 1:2000",
        "en": "Maa-amet Map Sheets 1:2000"
    },
    "dock_btn_load_all": {
        "et": "Lae alla kõik ruudud",
        "en": "Download All Tiles"
    },
    "dock_btn_load_all_tip": {
        "et": "Lae alla ja ava kõigi sessioonis valitud ruutude uusimad LAZ kihid",
        "en": "Download and open latest LAZ layers for all tiles in session"
    },

    # Custom OpenGL 3D Viewer & Unified 3D Panel
    "type_tava": {
        "et": "Tavalend (kevad)",
        "en": "Regular (spring)"
    },
    "type_mets": {
        "et": "Metsalend (suvi)",
        "en": "Forest (summer)"
    },
    "type_madal": {
        "et": "Madallend",
        "en": "Low-altitude"
    },
    "v3d_panel_title": {
        "et": "MaRu ALS 3D — Droonivaade ja mõõdistus",
        "en": "MaRu ALS 3D — Drone View & Measurement"
    },
    "v3d_pick_failed": {
        "et": "Punkti ei leitud kursori alt — klõpsa otse punktipilve punktile.",
        "en": "No point found under cursor — click directly on a point cloud point."
    },
    "v3d_loading_n": {
        "et": "Laadin ja dekodeerin {n} ruutu...",
        "en": "Loading & decoding {n} tile(s)..."
    },
    "v3d_empty": {
        "et": "Punktipilve pole veel avatud.\nKlõpsa tööriistaribal 'Vali noolega' ja lohista kaardil nool üle soovitud ala.",
        "en": "No point cloud loaded yet.\nClick 'Select by Arrow' on the toolbar and drag an arrow across the map."
    },
    "v3d_flight_date": {
        "et": "Lennukuupäev",
        "en": "Flight Date"
    },
    "v3d_data": {
        "et": "Andmestik",
        "en": "Dataset"
    },
    "v3d_no_data": {
        "et": "Andmed puuduvad",
        "en": "No data"
    },
    "v3d_tile": {
        "et": "Kaardiruut (1:2000)",
        "en": "Grid Tile (1:2000)"
    },
    "v3d_help_1": {
        "et": "[W][A][S][D] lend  |  [Space] tõus  |  [Ctrl] lasku",
        "en": "[W][A][S][D] fly  |  [Space] climb  |  [Ctrl] descend"
    },
    "v3d_help_2": {
        "et": "[Hiire lohistamine] gimbal  |  [Rullik] püsikiirus  |  [Shift] turbo",
        "en": "[Mouse drag] gimbal  |  [Wheel] cruise speed  |  [Shift] turbo"
    },
    "v3d_help_3": {
        "et": "[M] mõõdistusrežiim  |  [Enter/Topeltklõps] lõpeta  |  [C/Esc] tühjenda",
        "en": "[M] measure mode  |  [Enter/DblClick] finish  |  [C/Esc] clear"
    },
    "v3d_help_4": {
        "et": "[P] foto  |  [I] info  |  [G] maapind  |  [R] algvaade  |  [+/-] suurus",
        "en": "[P] photo  |  [I] info  |  [G] ground  |  [R] reset view  |  [+/-] size"
    },
    "v3d_info_btn": {
        "et": "Info",
        "en": "Info"
    },
    "v3d_info_tip": {
        "et": "Inforežiim [I] — klõpsa 2D kihil atribuutide vaatamiseks",
        "en": "Info Mode [I] — click 2D feature to inspect attributes"
    },
    "v3d_help_5": {
        "et": "[H] abi  |  [Minikaardi klõps] teleporteeru  |  [Minikaardi rullik / +/-] suurendus",
        "en": "[H] help  |  [Minimap click] teleport  |  [Minimap wheel / +/-] zoom"
    },
    "v3d_telemetry": {
        "et": "LENNUTELEMEETRIA",
        "en": "FLIGHT TELEMETRY"
    },
    "v3d_alt": {
        "et": "Kõrgus (EH2000):",
        "en": "Altitude (EH2000):"
    },
    "v3d_agl": {
        "et": "Kõrgus maapinnast:",
        "en": "Height (AGL):"
    },
    "v3d_speed": {
        "et": "Lennukiirus:",
        "en": "Flight Speed:"
    },
    "v3d_cruise": {
        "et": "Püsikiirus:",
        "en": "Cruise Speed:"
    },
    "v3d_heading": {
        "et": "Suund:",
        "en": "Heading:"
    },
    "v3d_gimbal": {
        "et": "Gimbal:",
        "en": "Gimbal:"
    },
    "v3d_flown": {
        "et": "Läbitud teekond:",
        "en": "Distance Flown:"
    },
    "v3d_points": {
        "et": "Punkte vaates:",
        "en": "Points in View:"
    },
    "v3d_minimap": {
        "et": "MINIKAART & LENNUTEEKOND",
        "en": "MINIMAP & FLIGHT TRAIL"
    },
    "v3d_measure": {
        "et": "MÕÕDISTUS",
        "en": "MEASUREMENT"
    },
    "v3d_m_distance": {
        "et": "Kaugus ja kalle",
        "en": "Distance & Slope"
    },
    "v3d_m_area": {
        "et": "Pindala ja ümbermõõt",
        "en": "Area & Perimeter"
    },
    "v3d_m_volume": {
        "et": "Maht (kaeve / täide)",
        "en": "Volume (Cut / Fill)"
    },
    "v3d_len3d": {
        "et": "3D pikkus",
        "en": "3D Length"
    },
    "v3d_len2d": {
        "et": "2D pikkus",
        "en": "2D Length"
    },
    "v3d_slope": {
        "et": "Viimase lõigu kalle",
        "en": "Last Segment Slope"
    },
    "v3d_area": {
        "et": "2D pindala",
        "en": "2D Area"
    },
    "v3d_perimeter": {
        "et": "Ümbermõõt",
        "en": "Perimeter"
    },
    "v3d_base": {
        "et": "Baastasapind (Z)",
        "en": "Base Plane (Z)"
    },
    "v3d_above": {
        "et": "Maht üle baasi (kaeve)",
        "en": "Above Base (Cut)"
    },
    "v3d_below": {
        "et": "Maht alla baasi (täide)",
        "en": "Below Base (Fill)"
    },
    "v3d_net": {
        "et": "Netomaht",
        "en": "Net Volume"
    },
    "v3d_coverage": {
        "et": "Punktide katvus",
        "en": "Point Coverage"
    },
    "v3d_measure_hint": {
        "et": "Vasakklõps: punkt  |  Paremklõps+lohista: vaade  |  Backspace: tagasi  |  Enter: lõpeta",
        "en": "Left-click: point  |  Right-drag: look  |  Backspace: undo  |  Enter: finish"
    },
    "v3d_tb_arrow": {
        "et": "Vali noolega",
        "en": "Select by Arrow"
    },
    "v3d_tb_arrow_tip": {
        "et": "Lohista 2D kaardil nool: tuvastab 1:2000 ruudud, laeb LAZ punktipilve ja suunab 3D droonikaamera",
        "en": "Drag an arrow on 2D map: detects 1:2000 tiles, loads LAZ point cloud, and aligns 3D drone camera"
    },
    "v3d_tb_rect": {
        "et": "Vali ristkülikuga",
        "en": "Select by Rectangle"
    },
    "v3d_tb_rect_tip": {
        "et": "Lohista 2D kaardil ristkülik: valib suurema ala (AOI) ja laeb kõik selle sees olevad ruudud",
        "en": "Drag a rectangle on 2D map: selects a larger AOI and loads all enclosed tiles"
    },
    "v3d_aoi_mode_arrow": {
        "et": "Noolega valik (asimuut + algpunkt)",
        "en": "Arrow selection (azimuth + start point)"
    },
    "v3d_aoi_mode_rect": {
        "et": "Ristkülikuga valik (suurem ala / AOI)",
        "en": "Rectangle selection (larger AOI)"
    },
    "v3d_tb_color": {
        "et": "Värving:",
        "en": "Color:"
    },
    "v3d_col_elev": {
        "et": "Kõrgus (Z)",
        "en": "Elevation (Z)"
    },
    "v3d_col_class": {
        "et": "Klassifikatsioon",
        "en": "Classification"
    },
    "v3d_col_inten": {
        "et": "Intensiivsus",
        "en": "Intensity"
    },
    "v3d_col_rgb": {
        "et": "Loomulik RGB",
        "en": "Natural RGB"
    },
    "v3d_style_btn": {
        "et": "🎨 Stiil",
        "en": "🎨 Style"
    },
    "v3d_style_tip": {
        "et": "Kohanda punktipilve värvigammat, RGB heledust, Z-vahemikku ja klasside värve (2D + 3D)",
        "en": "Customize point cloud color ramp, RGB brightness, Z range, and class colors (2D + 3D)"
    },
    "v3d_style_title": {
        "et": "Punktipilve stiili kohandamine (2D & 3D)",
        "en": "Point Cloud Style Customizer (2D & 3D)"
    },
    "v3d_style_ramp": {
        "et": "Kõrguse värvigamma:",
        "en": "Elevation Color Ramp:"
    },
    "v3d_ramp_terrain": {
        "et": "Maastik (Terrain)",
        "en": "Terrain"
    },
    "v3d_ramp_viridis": {
        "et": "Viridis",
        "en": "Viridis"
    },
    "v3d_ramp_turbo": {
        "et": "Turbo (kõrge kontrast)",
        "en": "Turbo (High Contrast)"
    },
    "v3d_ramp_forest": {
        "et": "Mets (Forest)",
        "en": "Forest"
    },
    "v3d_ramp_arctic": {
        "et": "Arktiline (Arctic)",
        "en": "Arctic"
    },
    "v3d_z_auto": {
        "et": "Automaatne Z-vahemik (vastavalt laetud ruutudele)",
        "en": "Automatic Z range (from loaded tiles)"
    },
    "v3d_z_min": {
        "et": "Min Z (m):",
        "en": "Min Z (m):"
    },
    "v3d_z_max": {
        "et": "Max Z (m):",
        "en": "Max Z (m):"
    },
    "v3d_rgb_bright": {
        "et": "Loomuliku RGB heledus:",
        "en": "Natural RGB Brightness:"
    },
    "v3d_inten_gamma": {
        "et": "Intensiivsuse kontrast (gamma):",
        "en": "Intensity Contrast (Gamma):"
    },
    "v3d_class_colors": {
        "et": "ASPRS klasside värvid (klõpsa muutmiseks):",
        "en": "ASPRS Classification Colors (click to change):"
    },
    "v3d_style_reset": {
        "et": "Taasta algseaded",
        "en": "Reset Defaults"
    },
    "v3d_style_apply": {
        "et": "Rakenda 2D ja 3D vaates",
        "en": "Apply to 2D & 3D"
    },
    "v3d_tb_canvas_lyrs": {
        "et": "Kaardikihid 3D",
        "en": "Canvas Layers 3D"
    },
    "v3d_tb_canvas_lyrs_tip": {
        "et": "Kuva 2D kaardi vektorkihid (nt katastripiirid, PRIA põllud, teed) 3D vaates maapinnale projitseerituna",
        "en": "Display 2D canvas vector layers (parcels, borders, roads) draped onto terrain in 3D view"
    },
    "v3d_tb_los": {
        "et": "LOS varjamine",
        "en": "LOS Occlusion"
    },
    "v3d_tb_los_tip": {
        "et": "Vaatevälja (Line-of-Sight) analüüs: peida piirid ja jooned, mis jäävad puude, hoonete või künka taha",
        "en": "Line-of-Sight occlusion: hide borders and lines occluded behind trees, buildings, or terrain"
    },
    "v3d_canvas_menu_refresh": {
        "et": "↻ Värskenda kaardikihid 2D vaatest",
        "en": "↻ Refresh Layers from 2D Canvas"
    },
    "v3d_canvas_menu_all": {
        "et": "Näita kõiki vektorkihte",
        "en": "Show All Vector Layers"
    },
    "v3d_tab_als": {
        "et": "ALS (LAZ)",
        "en": "ALS (LAZ)"
    },
    "v3d_tab_extra": {
        "et": "Lisakihid (DSM/Orto)",
        "en": "Extra Layers (DSM/Ortho)"
    },
    "v3d_extra_title": {
        "et": "Maa- ja Ruumiameti avaandmete lisakihid",
        "en": "Maa- ja Ruumiamet Open Data Layers"
    },
    "v3d_extra_fetch": {
        "et": "🔍 Päri lisakihid valitud ruutudele",
        "en": "🔍 Query Extra Layers for Session Tiles"
    },
    "v3d_extra_fetch_tip": {
        "et": "Otsi Geoportaalist DSM, DTM, ortofotode ja põhikaardi faile sessiooni ruutudele (1:2000 & 1:10 000)",
        "en": "Search Geoportaal for DSM, DTM, orthophoto, and basic map files for session tiles (1:2000 & 1:10,000)"
    },
    "v3d_extra_load": {
        "et": "⬇ Lae ja ava valitud lisakiht (3D + 2D)",
        "en": "⬇ Download & Open Selected Extra Layer (3D + 2D)"
    },
    "v3d_extra_col_layer": {
        "et": "Andmekiht / Fail",
        "en": "Dataset / File"
    },
    "v3d_extra_col_scale": {
        "et": "Tüüp",
        "en": "Type"
    },
    "cat_dsm_1m": {
        "et": "DSM 1m (maakatte kõrgusmudel)",
        "en": "DSM 1m (Surface Model)"
    },
    "cat_dtm_1m": {
        "et": "DTM 1m (maapinna kõrgusmudel)",
        "en": "DTM 1m (Terrain Model)"
    },
    "cat_orto_rgb": {
        "et": "Ortofoto RGB (1:10 000)",
        "en": "Orthophoto RGB (1:10,000)"
    },
    "cat_orto_madal": {
        "et": "Madallennu ortofoto (tiheasustus)",
        "en": "Urban Orthophoto (Low-alt)"
    },
    "cat_orto_cir": {
        "et": "Ortofoto CIR (valevärvi/mets)",
        "en": "Orthophoto CIR (False-color/Forest)"
    },
    "cat_orto_ngr": {
        "et": "Ortofoto NGR (metsanduslik)",
        "en": "Orthophoto NGR (Forestry)"
    },
    "cat_pk_varj": {
        "et": "Põhikaart varjutusega",
        "en": "Basic Map (Shaded Relief)"
    },
    "v3d_tb_psize": {
        "et": "Punkt:",
        "en": "Point:"
    },
    "v3d_tb_classes": {
        "et": "Klassid",
        "en": "Classes"
    },
    "v3d_cls_ground": {
        "et": "2 - Maapind",
        "en": "2 - Ground"
    },
    "v3d_cls_low_veg": {
        "et": "3 - Madal taimestik",
        "en": "3 - Low Vegetation"
    },
    "v3d_cls_med_veg": {
        "et": "4 - Keskmine taimestik",
        "en": "4 - Medium Vegetation"
    },
    "v3d_cls_high_veg": {
        "et": "5 - Kõrge taimestik (mets)",
        "en": "5 - High Vegetation (Forest)"
    },
    "v3d_cls_building": {
        "et": "6 - Hooned",
        "en": "6 - Buildings"
    },
    "v3d_cls_water": {
        "et": "9 - Vesi",
        "en": "9 - Water"
    },
    "v3d_cls_bridge": {
        "et": "17 - Sillad / rajatised",
        "en": "17 - Bridges"
    },
    "v3d_cls_unclass": {
        "et": "1 - Klassifitseerimata",
        "en": "1 - Unclassified"
    },
    "v3d_cls_noise": {
        "et": "7/18 - Müra",
        "en": "7/18 - Noise"
    },
    "v3d_tb_measure_off": {
        "et": "Lend",
        "en": "Fly"
    },
    "v3d_tb_measure_dist": {
        "et": "📏 Kaugus",
        "en": "📏 Distance"
    },
    "v3d_tb_measure_area": {
        "et": "📐 Pindala",
        "en": "📐 Area"
    },
    "v3d_tb_measure_vol": {
        "et": "🧊 Maht",
        "en": "🧊 Volume"
    },
    "v3d_tb_measure_clear": {
        "et": "✕",
        "en": "✕"
    },
    "v3d_tb_autostream": {
        "et": "Auto-laadimine",
        "en": "Auto-Stream"
    },
    "v3d_tb_autostream_tip": {
        "et": "Lae lennu ajal automaatselt alla ja ava uued 1:2000 kaardiruudud, kui lendad laetud alast välja",
        "en": "Automatically detect, download, and stream adjacent 1:2000 grid tiles when flying outside loaded area"
    },
    "v3d_tb_reset": {
        "et": "Algvaade",
        "en": "Reset View"
    },
    "v3d_tb_reset_tip": {
        "et": "Taasta kaamera üldvaade laetud ruutude kohale (klahv R)",
        "en": "Reset camera overview above loaded tiles (key R)"
    },
    "v3d_tb_export_log": {
        "et": "Logi CSV",
        "en": "Log CSV"
    },
    "v3d_tb_export_tip": {
        "et": "Salvesta lennuteekond ja telemeetria CSV-faili",
        "en": "Export flight path and telemetry to CSV file"
    },
    "v3d_tb_layers": {
        "et": "Aastad / kihid",
        "en": "Years / Layers"
    },
    "v3d_tb_layers_tip": {
        "et": "Näita/peida sessiooni kaardiruutude, lisakihtide ja 3D/2D kihtide halduspaneel",
        "en": "Show/hide session grid tiles, extra layers, and 3D/2D layer manager drawer"
    },
    "v3d_tb_infill": {
        "et": "Vertikaalsed pinnad",
        "en": "Vertical Surfaces"
    },
    "v3d_tb_infill_tip": {
        "et": "Interpoleeri vertikaalsed pinnad (nt linnusemüürid, hoonete seinad) ja täida skaneerimata tühimikud",
        "en": "Interpolate vertical surfaces (e.g. castle walls, building facades) and fill unscanned voids"
    },
    "v3d_chk_infill": {
        "et": "Interpoleeri vertikaalsed pinnad ja täida tühimikud",
        "en": "Interpolate vertical surfaces & fill surface voids"
    },
    "v3d_chk_merge_flights": {
        "et": "Liida sama ruudu ülelennud (täida tühimikud teiste lendudega)",
        "en": "Merge multiple overflights per tile to fill gaps"
    },
    "v3d_btn_merge_tile": {
        "et": "➕ Liida ruudu ülelennud 3D-s",
        "en": "➕ Merge Tile Overflights in 3D"
    },
    "v3d_btn_merge_tile_tip": {
        "et": "Laeb alla ja ühendab valitud ruudu erinevad ülelennud (nt Madallend + Metsalend + Tavalend) vertikaalseinte ja varjualade tihendamiseks",
        "en": "Downloads and merges multiple overflights of the selected tile (e.g. Low-alt + Forest + Regular) to densify vertical walls and shadowed areas"
    },
    "v3d_tab_scene": {
        "et": "3D Kihid & Kaart",
        "en": "3D & Canvas"
    },
    "v3d_scene_3d_title": {
        "et": "3D vaates avatud kihid (lülita sisse/välja)",
        "en": "Layers Open in 3D View (toggle on/off)"
    },
    "v3d_scene_2d_title": {
        "et": "QGIS 2D kaardikihid — lülita 3D vaatesse (vaikimisi väljas)",
        "en": "QGIS 2D Canvas Layers — Toggle for 3D View (default OFF)"
    },
    "v3d_scene_col_name": {
        "et": "3D Kiht / Fail",
        "en": "3D Layer / File"
    },
    "v3d_scene_col_type": {
        "et": "Tüüp",
        "en": "Type"
    },
    "v3d_scene_col_pts": {
        "et": "Punkte",
        "en": "Points"
    },
    "v3d_scene_col_2d_name": {
        "et": "QGIS 2D kaardikiht",
        "en": "QGIS 2D Canvas Layer"
    },
    "v3d_scene_col_2d_geom": {
        "et": "Tüüp",
        "en": "Type"
    },
    "v3d_scene_remove": {
        "et": "🗑 Eemalda valitud kiht 3D vaatest",
        "en": "🗑 Remove Selected Layer from 3D View"
    },
    "v3d_progress_idle": {
        "et": "Valmis",
        "en": "Ready"
    },
    "v3d_tb_drone_2d": {
        "et": "Droon 2D",
        "en": "Drone 2D"
    },
    "v3d_tb_drone_2d_tip": {
        "et": "Kuva drooni reaalajas asukoht, vaatesuuna koonus ja lennuteekond QGIS-i 2D põhikaardil",
        "en": "Show live drone location, bearing cone, and flight path on the QGIS 2D main canvas"
    },
    "v3d_drone_2d_show_cone": {
        "et": "Näita drooni asukohta ja vaatesuuna koonust 2D kaardil",
        "en": "Show drone location & bearing cone on 2D map"
    },
    "v3d_drone_2d_show_path": {
        "et": "Näita lennuteekonda 2D kaardil",
        "en": "Show flight path on 2D map"
    },
    "v3d_drone_2d_follow": {
        "et": "Jälgi drooni 2D kaardil automaatselt",
        "en": "Auto-follow drone on 2D map"
    },
    "v3d_drone_2d_center": {
        "et": "🎯 Tsenteeri 2D kaart droonile kohe",
        "en": "🎯 Center 2D map on drone now"
    },
    "v3d_mm_foto": {
        "et": "Foto",
        "en": "Photo"
    },
    "v3d_mm_hall": {
        "et": "Hall",
        "en": "Gray"
    },
    "v3d_mm_baas": {
        "et": "Hall",
        "en": "Gray"
    },
    "v3d_mm_pohi": {
        "et": "Hall",
        "en": "Gray"
    },
    "v3d_mm_hyb": {
        "et": "Hübriid",
        "en": "Hybrid"
    },
    "v3d_mm_grid": {
        "et": "Võrk",
        "en": "Grid"
    },
    "v3d_mm_foto_full": {
        "et": "Minikaardi aluskaart: Fotokaart (Ortofoto)",
        "en": "Minimap Base Layer: Orthophoto (Fotokaart)"
    },
    "v3d_mm_hall_full": {
        "et": "Minikaardi aluskaart: Halltoonides kaart",
        "en": "Minimap Base Layer: Grayscale Map (Halltoonides kaart)"
    },
    "v3d_mm_baas_full": {
        "et": "Minikaardi aluskaart: Halltoonides kaart",
        "en": "Minimap Base Layer: Grayscale Map (Halltoonides kaart)"
    },
    "v3d_mm_pohi_full": {
        "et": "Minikaardi aluskaart: Halltoonides kaart",
        "en": "Minimap Base Layer: Grayscale Map (Halltoonides kaart)"
    },
    "v3d_mm_hyb_full": {
        "et": "Minikaardi aluskaart: Hübriidkaart (Orto + teed/nimed)",
        "en": "Minimap Base Layer: Hybrid Map (Ortho + roads/labels)"
    },
    "v3d_mm_grid_full": {
        "et": "Minikaardi aluskaart: Tume võrgustik (ilma aluskaardita)",
        "en": "Minimap Base Layer: Dark Grid (no base map)"
    },
    "v3d_canvas_buffer": {
        "et": "AOI puhver:",
        "en": "AOI buffer:"
    },
    "v3d_canvas_buffer_tip": {
        "et": "Ala raadius drooni/keskme ümber (m), kust 2D kaardikihid 3D vaatesse laaditakse",
        "en": "Radius around drone/center (m) for extracting 2D canvas layers into 3D"
    },
    "v3d_tb_drone_data": {
        "et": "🛸 Drooni andmed",
        "en": "🛸 Drone Data"
    },
    "v3d_tb_drone_data_tip": {
        "et": "Ava drooni andmete haldur ja eraldiseisvad stiilivalikud",
        "en": "Open Drone Data Manager & independent styling controls"
    },
    "v3d_drone_dlg_title": {
        "et": "🛸 Drooni andmete haldur ja stiil",
        "en": "🛸 Drone Data Manager & Styling"
    },
    "v3d_drone_dlg_desc": {
        "et": "Laadi kohalikke droonimõõdistuste faile (LAZ/LAS/DSM/Orto). Drooni andmetel on oma eraldiseisev stiil ja kõrguskalibreerimine sõltumatult ALS andmetest.",
        "en": "Import local drone photogrammetry and survey datasets (LAZ/LAS/DSM/Ortho). Drone data has independent styling, point sizing, and altitude calibration separate from ALS."
    },
    "v3d_drone_layers_grp": {
        "et": "Laaditud droonimõõdistused 3D vaates",
        "en": "Loaded Drone Surveys in 3D Scene"
    },
    "v3d_drone_style_grp": {
        "et": "Eraldiseisev stiil drooni andmetele",
        "en": "Independent Styling for Drone Data"
    },
    "v3d_drone_show_all": {
        "et": "Näita kõiki droonikihte 3D vaates",
        "en": "Show all drone layers in 3D scene"
    },
    "v3d_drone_z_offset_lbl": {
        "et": "Kõrgusnihe / Kalibreerimine:",
        "en": "Elevation Offset / Calibration:"
    },
    "v3d_drone_z_offset_tip": {
        "et": "Kalibreeri drooni kõrgust maapinna ja ALS EH2000 geoidi suhtes (±50m)",
        "en": "Calibrate drone elevation relative to ground and ALS EH2000 geoid (±50m)"
    },
    "v3d_drone_highlight_amber": {
        "et": "Esiletõst: Kuldne / Merevaik",
        "en": "Highlight: Golden Amber"
    },
    "v3d_drone_highlight_cyan": {
        "et": "Esiletõst: Neoon Sinine",
        "en": "Highlight: Neon Cyan"
    },
    "v3d_drone_dlg_close": {
        "et": "Sulge",
        "en": "Close"
    },
    "v3d_drone_action": {
        "et": "Kustuta",
        "en": "Remove"
    },
    "v3d_drone_data_btn": {
        "et": "🚁 Lisa drooni andmed (LAZ / DSM / Orto)...",
        "en": "🚁 Add Drone Data (LAZ / DSM / Ortho)..."
    },
    "v3d_drone_data_tip": {
        "et": "Laadi 3D vaatesse kohalik drooni fotogrammeetria punktipilv (LAZ/LAS) või GeoTIFF DSM/Ortofofod (Mavic 3E / Drone2Map)",
        "en": "Load local drone photogrammetry point cloud (LAZ/LAS) or GeoTIFF DSM/Ortho into 3D view (Mavic 3E / Drone2Map)"
    },
    "v3d_drone_data_dlg_title": {
        "et": "Vali drooni lennuandmete fail (LAZ / LAS / GeoTIFF)",
        "en": "Select Drone Survey Data File (LAZ / LAS / GeoTIFF)"
    },
    "v3d_drone_data_dlg_filter": {
        "et": "Kõik toetatud drooniandmed (*.laz *.las *.tif *.tiff);;Punktipilved (*.laz *.las);;GeoTIFF DSM / Ortofoto (*.tif *.tiff)",
        "en": "All Supported Drone Data (*.laz *.las *.tif *.tiff);;Point Clouds (*.laz *.las);;GeoTIFF DSM / Ortho (*.tif *.tiff)"
    },
    "v3d_photo_btn": {
        "et": "Fotorežiim (P)",
        "en": "Photo Mode (P)"
    },
    "v3d_photo_tip": {
        "et": "Drooni fotorežiim (P) — hiireklõps pildistab, U: peida/näita UI, fotosessiooni eksport",
        "en": "Drone Photo Mode (P) — mouse click to shoot, U: toggle UI, export photoshoot"
    },
    "v3d_photo_mode_hud": {
        "et": "📸 FOTOREŽIIM: {count} fotot | [Klõps/Space]: pildista | [U]: UI ({ui}) | [P]: välju",
        "en": "📸 PHOTO MODE: {count} photos | [Click/Space]: shoot | [U]: UI ({ui}) | [P]: exit"
    },
    "v3d_photo_include_ui": {
        "et": "Kaasa kasutajaliides (UI)",
        "en": "Include User Interface (UI)"
    },
    "v3d_photo_save_as": {
        "et": "Pildista ja salvesta failina...",
        "en": "Shoot & Save As..."
    },
    "v3d_photo_copy_clip": {
        "et": "Kopeeri viimane foto lõikelauale",
        "en": "Copy Last Photo to Clipboard"
    },
    "v3d_photo_export_batch": {
        "et": "💾 Ekspordi fotosessioon ({count} tk + CSV)...",
        "en": "💾 Export Photoshoot ({count} + CSV)..."
    },
    "v3d_photo_clear_session": {
        "et": "Tühjenda fotosessioon",
        "en": "Clear Photoshoot Session"
    },
    "v3d_photo_open_folder": {
        "et": "Ava fotode kaust",
        "en": "Open Photos Folder"
    },
    "v3d_photo_saved_msg": {
        "et": "📸 Foto salvestatud: {path}",
        "en": "📸 Photo saved: {path}"
    },
    "v3d_photo_copied_msg": {
        "et": "📸 Foto kopeeritud lõikelauale!",
        "en": "📸 Photo copied to clipboard!"
    },
    "v3d_photo_export_done": {
        "et": "📸 Sessiooni {count} fotot ja CSV eksporditud kausta: {folder}",
        "en": "📸 Exported {count} photoshoot photos and CSV to: {folder}"
    },
    "v3d_tb_signal": {
        "et": "Signaal",
        "en": "Signal"
    },
    "v3d_tb_signal_tip": {
        "et": "Drooni juhtsignaali analüüs ja levi simulatsioon (Mavic 3E / Matrice 4T / jne)",
        "en": "Drone RC Link Signal Simulation & Fresnel Analysis (Mavic 3E / Matrice 4T)"
    },
    "v3d_sig_title": {
        "et": "📡 Drooni juhtsignaali simulatsioon (RC Link & LOS)",
        "en": "📡 Drone Signal Strength Simulation (RC Link & LOS)"
    },
    "v3d_sig_desc": {
        "et": "Arvutab RC juhtsignaali levi, 1. Fresneli tsooni ning takistused (maapind, metsad, hooned) maapealse puldi ja drooni vahel.",
        "en": "Calculates RC link coverage, 1st Fresnel zone clearance, and obstacle shadow zones (terrain, forests, buildings) between ground controller and UAV."
    },
    "v3d_sig_drone_grp": {
        "et": "1. Drooni mudel ja edastustehnoloogia",
        "en": "1. Drone Model & Transmission Technology"
    },
    "v3d_sig_home_grp": {
        "et": "2. Kodupunkti (Homepoint / RC antenn) asukoht",
        "en": "2. Homepoint (RC Controller Antenna) Location"
    },
    "v3d_sig_home_loading": {
        "et": "Koordinaadid: arvutamisel...",
        "en": "Coordinates: calculating..."
    },
    "v3d_sig_home_unset": {
        "et": "Kodupunkt määramata. Klõpsa 'Vali kaardilt' või 'Sea drooni alla'.",
        "en": "No homepoint set. Click 'Pick from Map' or 'Set to Drone Position'."
    },
    "v3d_tele_no_homepoint": {
        "et": "Kodupunkt määramata",
        "en": "No homepoint set"
    },
    "v3d_tele_drone": {
        "et": "Droon",
        "en": "Drone"
    },
    "v3d_tele_signal": {
        "et": "RC Signaal",
        "en": "RC Signal"
    },
    "v3d_tele_vlos": {
        "et": "VLOS",
        "en": "VLOS"
    },
    "v3d_sig_pick_map": {
        "et": "Vali kaardilt / 3D vaatest",
        "en": "Pick from Map / 3D View"
    },
    "v3d_sig_picking": {
        "et": "Klõpsa kaardil...",
        "en": "Click on map..."
    },
    "v3d_sig_home_drone": {
        "et": "Sea drooni alla",
        "en": "Set to Drone Position"
    },
    "v3d_sig_params_grp": {
        "et": "3. Lennukõrgus ja simulatsiooni raadius",
        "en": "3. Flight Altitude & Simulation Radius"
    },
    "v3d_sig_flight_h": {
        "et": "Lennukõrgus maapinnast (AGL):",
        "en": "Flight Height (AGL):"
    },
    "v3d_sig_dist": {
        "et": "Simulatsiooni raadius:",
        "en": "Simulation Radius:"
    },
    "v3d_sig_vis_grp": {
        "et": "4. Kuvatavad kihid ja vaated",
        "en": "4. Visualization & Views"
    },
    "v3d_sig_show_3d": {
        "et": "Kuva 3D vaates",
        "en": "Show in 3D View"
    },
    "v3d_sig_show_2d": {
        "et": "Kuva 2D kaardil",
        "en": "Show on 2D Map Canvas"
    },
    "v3d_sig_recalc": {
        "et": "Arvuta uuesti",
        "en": "Recalculate"
    },
    "v3d_sig_live_grp": {
        "et": "5. Reaalajas RC link ja telemeetria",
        "en": "5. Real-Time RC Link & Telemetry"
    },
    "v3d_sig_status_init": {
        "et": "🟢 100% — TUGEV (100% otsenähtavus)",
        "en": "🟢 100% — STRONG (100% Line of Sight)"
    },
    "v3d_sig_leg_strong": {
        "et": "Tugev (75–100%)",
        "en": "Strong (75–100%)"
    },
    "v3d_sig_leg_fair": {
        "et": "Hea (40–74%)",
        "en": "Fair (40–74%)"
    },
    "v3d_sig_leg_marg": {
        "et": "Piiripealne (10–39%)",
        "en": "Marginal (10–39%)"
    },
    "v3d_sig_leg_shadow": {
        "et": "Varjus / Katkenud (0%)",
        "en": "Shadow / Lost Link (0%)"
    }
}


class I18n:
    """Manages translation lookup and active language setting."""
    _current_lang = None

    @classmethod
    def get_language(cls) -> str:
        if cls._current_lang is None:
            settings = QgsSettings()
            cls._current_lang = settings.value("maru_als/language", LANG_ET)
        return cls._current_lang

    @classmethod
    def set_language(cls, lang: str):
        if lang in (LANG_ET, LANG_EN):
            cls._current_lang = lang
            settings = QgsSettings()
            settings.setValue("maru_als/language", lang)

    @classmethod
    def tr(cls, key: str, **kwargs) -> str:
        """Translate a key into the active language with optional format kwargs."""
        lang = cls.get_language()
        entry = STRINGS.get(key)
        if entry is None:
            return key
        text = entry.get(lang, entry.get(LANG_ET, key))
        if kwargs:
            try:
                return text.format(**kwargs)
            except Exception:
                return text
        return text


def tr(key: str, **kwargs) -> str:
    """Shorthand translation helper."""
    return I18n.tr(key, **kwargs)
