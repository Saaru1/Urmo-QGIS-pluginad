"""
Core RF Transmission & Drone Controller Signal Strength Simulation Engine.

Simulates OcuSync 3 Enterprise (O3E) and OcuSync 4 Enterprise (O4E) radio
transmission links between a ground controller (Homepoint) and UAVs (Mavic 3E,
Matrice 4T, Matrice 30T) over 3D LiDAR terrain and DSM obstacles.
"""

import math
from typing import Callable, Dict, Optional, Tuple
import numpy as np


# --------------------------------------------------------------------------- #
# 1. Drone Transmission Specifications (European CE Standard)
# --------------------------------------------------------------------------- #
DRONE_PROFILES: Dict[str, dict] = {
    "mavic_3e": {
        "key": "mavic_3e",
        "name": "DJI Mavic 3 Enterprise (O3E)",
        "short_name": "Mavic 3E",
        "tech": "O3 Enterprise (OcuSync 3.0)",
        "controller": "DJI RC Pro Enterprise",
        "max_range_ce_m": 8000.0,      # CE legal max range: 8 km
        "recommended_radius_m": 3500.0,
        "default_height_m": 80.0,
        "vlos_max_m": 500.0,          # Human eye visual orientation limit (sub-1kg UAV)
        "freq_ghz": 2.4,
        "antennas": "4T4R MIMO",
    },
    "matrice_4t": {
        "key": "matrice_4t",
        "name": "DJI Matrice 4T (O4E)",
        "short_name": "Matrice 4T",
        "tech": "O4 Enterprise (OcuSync 4.0)",
        "controller": "DJI RC Plus 2 Enterprise",
        "max_range_ce_m": 12000.0,     # CE legal max range: 12 km
        "recommended_radius_m": 5000.0,
        "default_height_m": 100.0,
        "vlos_max_m": 800.0,          # Larger UAV frame allows up to ~800m naked-eye VLOS
        "freq_ghz": 2.4,
        "antennas": "8-antenna high-gain array",
    },
    "matrice_30t": {
        "key": "matrice_30t",
        "name": "DJI Matrice 30T (O3E)",
        "short_name": "Matrice 30T",
        "tech": "O3 Enterprise (OcuSync 3.0)",
        "controller": "DJI RC Plus Enterprise",
        "max_range_ce_m": 8000.0,      # CE legal max range: 8 km
        "recommended_radius_m": 3500.0,
        "default_height_m": 80.0,
        "vlos_max_m": 750.0,
        "freq_ghz": 2.4,
        "antennas": "4T4R MIMO",
    },
    "custom_uav": {
        "key": "custom_uav",
        "name": "Kohandatud droon (Custom UAV)",
        "short_name": "Custom UAV",
        "tech": "Universal ISM 2.4 GHz",
        "controller": "Standard Controller",
        "max_range_ce_m": 5000.0,
        "recommended_radius_m": 2500.0,
        "default_height_m": 60.0,
        "vlos_max_m": 500.0,
        "freq_ghz": 2.4,
        "antennas": "Omnidirectional Dipole",
    },
}

# Signal Zones: 0 = Strong (Green), 1 = Fair (Yellow), 2 = Marginal (Orange), 3 = Blocked / Shadow (Red)
ZONE_STRONG = 0
ZONE_FAIR = 1
ZONE_MARGINAL = 2
ZONE_SHADOW = 3

# Visual Line of Sight (VLOS) Status Codes
VLOS_CLEAR = 0     # 🟢 Otsenähtavus selge (distance <= vlos_max and unobstructed)
VLOS_MARGINAL = 1  # 🟠 Piiripealne (vlos_max < distance <= 1.25 * vlos_max)
VLOS_BVLOS = 2     # 🟡 BVLOS (distance > 1.25 * vlos_max, inimsilma piir ületatud)
VLOS_BLOCKED = 3   # 🔴 Takistatud (maapind, mets või hoone varjab vaatejoone)
ZONE_FAIR = 1
ZONE_MARGINAL = 2
ZONE_SHADOW = 3

ZONE_COLORS = {
    ZONE_STRONG: (34, 197, 94, 110),     # Neon Emerald Green
    ZONE_FAIR: (234, 179, 8, 120),       # Bright Amber Yellow
    ZONE_MARGINAL: (249, 115, 22, 140),  # Orange Warning
    ZONE_SHADOW: (239, 68, 68, 170),     # Crimson Red - No Signal / RTH
}


class DroneSignalResult:
    """Holds computed 2D/3D signal coverage grid and telemetry."""

    def __init__(self):
        self.drone_key: str = "mavic_3e"
        self.home_abs: np.ndarray = np.zeros(3)      # (X, Y, Z_ground) EPSG:3301
        self.home_local: np.ndarray = np.zeros(3)    # (lx, ly, lz_ant) relative to scene origin
        self.flight_height_agl: float = 80.0
        self.max_dist_m: float = 3000.0
        self.grid_xs: np.ndarray = np.array([])      # (N, M) local x
        self.grid_ys: np.ndarray = np.array([])      # (N, M) local y
        self.grid_zs: np.ndarray = np.array([])      # (N, M) flight altitude at (x, y)
        self.grid_zones: np.ndarray = np.array([])   # (N, M) zone codes (0, 1, 2, 3)
        self.grid_pcts: np.ndarray = np.array([])    # (N, M) signal % (0 to 100)
        self.total_cells: int = 0
        self.strong_pct: float = 0.0
        self.shadow_pct: float = 0.0


def compute_signal_coverage_grid(
    home_local: np.ndarray,
    flight_height_agl: float,
    max_dist_m: float,
    drone_key: str,
    ground_vec_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
    surface_vec_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
    grid_steps: int = 44,
) -> DroneSignalResult:
    """
    Computes a 2D/3D RF Line-of-Sight and Free Space Path Loss (FSPL) coverage
    grid around `home_local` up to `max_dist_m`.

    Uses vectorized NumPy ray sampling against ALS terrain and DSM obstacle surfaces.
    """
    res = DroneSignalResult()
    res.drone_key = drone_key
    res.home_local = np.asarray(home_local, dtype=np.float64).copy()
    res.flight_height_agl = float(flight_height_agl)
    res.max_dist_m = float(max_dist_m)

    profile = DRONE_PROFILES.get(drone_key, DRONE_PROFILES["mavic_3e"])
    drone_max_ce = profile["max_range_ce_m"]
    sim_radius = min(max_dist_m, drone_max_ce)

    hx, hy = float(home_local[0]), float(home_local[1])
    hz_ant = float(home_local[2])  # Controller antenna height (~1.8m AGL)

    # 1. Generate regular 2D inspection grid around Homepoint
    xs = np.linspace(hx - sim_radius, hx + sim_radius, grid_steps, dtype=np.float32)
    ys = np.linspace(hy - sim_radius, hy + sim_radius, grid_steps, dtype=np.float32)
    GX, GY = np.meshgrid(xs, ys)

    dist_2d = np.hypot(GX - hx, GY - hy)
    in_radius = dist_2d <= sim_radius

    # Ground elevation at target points
    flat_gx = GX.ravel()
    flat_gy = GY.ravel()
    flat_gnd = ground_vec_fn(flat_gx, flat_gy)
    GND_Z = flat_gnd.reshape(GX.shape)

    # Flight altitude at each point: target ground elevation + flight_height_agl
    DRONE_Z = GND_Z + flight_height_agl
    res.grid_xs = GX
    res.grid_ys = GY
    res.grid_zs = DRONE_Z

    # 2. Vectorized Raymarching Line-of-Sight Test (10 strategic steps along ray)
    n_pts = GX.size
    t_steps = np.linspace(0.10, 0.92, 10, dtype=np.float32)[None, :]  # (1, 10)

    # Vector from Home antenna to drone target (N, 1)
    dx = (flat_gx - hx).astype(np.float32)[:, None]
    dy = (flat_gy - hy).astype(np.float32)[:, None]
    dz = (DRONE_Z.ravel() - hz_ant).astype(np.float32)[:, None]

    # Sample points along rays (N, 10)
    rx = hx + dx * t_steps
    ry = hy + dy * t_steps
    rz = hz_ant + dz * t_steps

    # Query DSM surface (vegetation, buildings, hill peaks)
    surf_z = surface_vec_fn(rx.ravel(), ry.ravel()).reshape(rx.shape)

    # 1st Fresnel zone radius calculation at 2.4 GHz (lambda = 0.125 m)
    # F1 = sqrt(lambda * d1 * d2 / d)
    flat_d = dist_2d.ravel()[:, None]
    d1 = flat_d * t_steps
    d2 = flat_d * (1.0 - t_steps)
    fresnel_r = np.sqrt(np.maximum(0.01, (0.125 * d1 * d2) / np.maximum(flat_d, 1.0)))

    # Direct LOS occlusion: surface exceeds ray altitude
    direct_blocked = np.any(surf_z > (rz + 0.35), axis=1)

    # Fresnel zone degradation: obstacle penetrates into 50% of the 1st Fresnel zone
    fresnel_impinged = np.any(surf_z > (rz - 0.50 * fresnel_r), axis=1)

    # 3. RF Link Budget & Distance Attenuation (OcuSync model)
    dist_ratio = flat_d.ravel() / drone_max_ce
    raw_signal = np.clip(1.0 - (dist_ratio ** 0.82), 0.0, 1.0) * 100.0

    # Apply degradation penalties
    signal_pct = np.where(direct_blocked, 0.0, raw_signal)
    signal_pct = np.where((~direct_blocked) & fresnel_impinged, signal_pct * 0.65, signal_pct)
    signal_pct = np.where(~in_radius.ravel(), 0.0, signal_pct)

    # Determine Signal Zones
    zones = np.full(n_pts, ZONE_SHADOW, dtype=np.uint8)
    # Outside radius or direct blocked => Shadow (Red)
    # Otherwise:
    m_clear = in_radius.ravel() & (~direct_blocked)
    zones[m_clear & (signal_pct >= 75.0)] = ZONE_STRONG    # Green
    zones[m_clear & (signal_pct >= 40.0) & (signal_pct < 75.0)] = ZONE_FAIR      # Yellow
    zones[m_clear & (signal_pct > 0.0) & (signal_pct < 40.0)] = ZONE_MARGINAL    # Orange
    zones[~m_clear] = ZONE_SHADOW                        # Red

    res.grid_zones = zones.reshape(GX.shape)
    res.grid_pcts = signal_pct.reshape(GX.shape)
    res.total_cells = int(np.sum(in_radius))

    if res.total_cells > 0:
        in_zones = res.grid_zones[in_radius]
        res.strong_pct = float(np.sum(in_zones == ZONE_STRONG) / res.total_cells * 100.0)
        res.shadow_pct = float(np.sum(in_zones == ZONE_SHADOW) / res.total_cells * 100.0)

    return res


def evaluate_live_drone_signal(
    home_local: np.ndarray,
    drone_pos3: np.ndarray,
    drone_key: str,
    surface_vec_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
) -> Tuple[float, int, str, bool, float]:
    """
    Evaluates real-time RC signal strength between Homepoint and live drone camera.

    Returns:
        (signal_pct, zone_code, status_str, is_occluded, distance_m)
    """
    hx, hy, hz = float(home_local[0]), float(home_local[1]), float(home_local[2])
    dx, dy, dz = float(drone_pos3[0]), float(drone_pos3[1]), float(drone_pos3[2])

    dist_3d = math.hypot(dx - hx, dy - hy, dz - hz)
    dist_2d = math.hypot(dx - hx, dy - hy)

    profile = DRONE_PROFILES.get(drone_key, DRONE_PROFILES["mavic_3e"])
    max_ce = profile["max_range_ce_m"]

    if dist_2d > max_ce:
        return 0.0, ZONE_SHADOW, "LEVI ALA ÜLESTATUD (> max CE) — RTH!", True, dist_3d

    # Sample 14 points along sight-ray between Home antenna and Drone
    t_vals = np.linspace(0.05, 0.95, 14, dtype=np.float32)
    rx = hx + (dx - hx) * t_vals
    ry = hy + (dy - hy) * t_vals
    rz = hz + (dz - hz) * t_vals

    surf_z = surface_vec_fn(rx, ry)
    occluded = bool(np.any(surf_z > (rz + 0.35)))

    if occluded:
        return 0.0, ZONE_SHADOW, "SIGNAAL KATKENUD: MAAPIND / HOONE VARJAB! (RTH)", True, dist_3d

    # Check Fresnel clearance
    d1 = dist_2d * t_vals
    d2 = dist_2d * (1.0 - t_vals)
    fresnel = np.sqrt(np.maximum(0.01, (0.125 * d1 * d2) / max(1.0, dist_2d)))
    fresnel_warn = bool(np.any(surf_z > (rz - 0.50 * fresnel)))

    dist_ratio = dist_2d / max_ce
    raw_pct = max(5.0, min(100.0, (1.0 - (dist_ratio ** 0.85)) * 100.0))

    if fresnel_warn:
        raw_pct *= 0.65

    if raw_pct >= 75.0:
        return raw_pct, ZONE_STRONG, "SIGNAAL TUGEV (100% LOS)", False, dist_3d
    elif raw_pct >= 40.0:
        return raw_pct, ZONE_FAIR, "SIGNAAL HEA (stabiilne ühendus)", False, dist_3d
    else:
        return raw_pct, ZONE_MARGINAL, "SIGNAAL NÕRK (lähedal levi piirile)", False, dist_3d


def evaluate_live_vlos(
    home_local: np.ndarray,
    drone_pos3: np.ndarray,
    drone_key: str,
    surface_vec_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
) -> Tuple[int, str, float]:
    """
    Evaluates Visual Line of Sight (VLOS) between pilot eyes (Homepoint + 1.7m)
    and UAV based on normal human eye visual acuity and ALS terrain/obstacle occlusion.

    Returns:
        (vlos_code, vlos_status_text, distance_3d)
    """
    hx, hy = float(home_local[0]), float(home_local[1])
    hz_eyes = float(home_local[2]) - 0.1  # Eye level ~1.7m (antenna is ~1.8m)
    dx, dy, dz = float(drone_pos3[0]), float(drone_pos3[1]), float(drone_pos3[2])

    dist_3d = math.hypot(dx - hx, dy - hy, dz - hz_eyes)
    dist_2d = math.hypot(dx - hx, dy - hy)

    # 1. Sample sight-ray against DSM surface (vegetation, terrain, buildings)
    t_vals = np.linspace(0.04, 0.96, 14, dtype=np.float32)
    rx = hx + (dx - hx) * t_vals
    ry = hy + (dy - hy) * t_vals
    rz = hz_eyes + (dz - hz_eyes) * t_vals

    surf_z = surface_vec_fn(rx, ry)
    # Direct optical sightline blocked by terrain/trees
    if np.any(surf_z > (rz + 0.30)):
        return VLOS_BLOCKED, f"VARJATUD ({dist_3d:.0f}m)", dist_3d

    # 2. Check human eye resolving capacity for drone size
    profile = DRONE_PROFILES.get(drone_key, DRONE_PROFILES["mavic_3e"])
    vlos_max = profile.get("vlos_max_m", 500.0)

    if dist_3d <= vlos_max:
        return VLOS_CLEAR, f"SELGE ({dist_3d:.0f}m)", dist_3d
    elif dist_3d <= vlos_max * 1.30:
        return VLOS_MARGINAL, f"PIIRIPEALNE ({dist_3d:.0f}m)", dist_3d
    else:
        return VLOS_BVLOS, f"BVLOS (>{vlos_max:.0f}m)", dist_3d

