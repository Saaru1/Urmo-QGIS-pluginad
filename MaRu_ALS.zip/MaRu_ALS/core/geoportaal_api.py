# -*- coding: utf-8 -*-
"""
API client and HTML parser for Maa- ja Ruumiamet (MaRu) Geoportaal ALS LiDAR data
and additional open elevation/imagery datasets (DSM 1m, DTM 1m, Orthophotos, Basic Map).
Query page: https://geoportaal.maaruum.ee/est/Ruumiandmed/Korgusandmed/Laadi-korgusandmed-alla-p614.html
Batch reference: https://geoportaal.maaruum.ee/docs/Avaandmed/tomba_etak_avaandmed.xlsx
"""

import html
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import List, Optional

from .grid_engine import GridEngine

PREF_LATEST_ANY = "latest_any"
PREF_LATEST_TAVA = "latest_tava"
PREF_LATEST_METS = "latest_mets"

# Additional MaRu dataset definitions (from tomba_etak_avaandmed.xlsx)
EXTRA_DATASETS = [
    # (category_key, page_id, andmetyyp, scale_mode)
    ("dsm_1m", "614", "ndsm_abs_1m_geotiff", "2000"),
    ("dtm_1m", "614", "dem_1m_geotiff", "10000"),
    ("orto_rgb", "610", "ortofoto_eesti_rgb", "10000"),
    ("orto_madal", "610", "ortofoto_asulad_rgb", "2000"),
    ("orto_cir", "610", "ortofoto_eesti_cir", "10000"),
    ("orto_ngr", "610", "ortofoto_eesti_ngr", "10000"),
    ("pk_varj", "612", "pk_varjutusega", "10000"),
]


@dataclass
class AlsFileInfo:
    tile_id: str
    filename: str
    year: int
    flight_type: str        # 'tava', 'mets', 'madal', or extra category key ('dsm_1m', 'dtm_1m', etc.)
    size_str: str           # e.g. "7.3 MB"
    download_url: str
    downloaded: bool = False
    local_path: Optional[str] = None
    is_raster: bool = False

    @property
    def label(self) -> str:
        """Formatted human-readable label."""
        type_name = "Tava (kevad)" if self.flight_type == "tava" else (
            "Mets (suvi)" if self.flight_type == "mets" else self.flight_type
        )
        yr = f"{self.year} - " if self.year else ""
        return f"{yr}{type_name} ({self.size_str})"


class GeoportaalClient:
    """Queries Geoportaal and parses ALS flight layers and extra raster layers for grid tiles."""

    BASE_URL = "https://geoportaal.maaruum.ee/index.php"
    USER_AGENT = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )

    @classmethod
    def _query_html(cls, page_id: str, sheet_id: str, andmetyyp: str, timeout: int = 12) -> str:
        params = {
            "lang_id": "1",
            "plugin_act": "otsing",
            "page_id": str(page_id),
            "kaardiruut": str(sheet_id),
            "andmetyyp": str(andmetyyp),
        }
        url = f"{cls.BASE_URL}?{urllib.parse.urlencode(params)}"
        headers = {
            "User-Agent": cls.USER_AGENT,
            "Accept": "text/html, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "https://geoportaal.maaruum.ee/est/Ruumiandmed/Korgusandmed/Laadi-korgusandmed-alla-p614.html",
        }
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8", errors="ignore")
        except Exception as e:
            print(f"[MaRu ALS] Error querying {sheet_id} ({andmetyyp}): {e}")
            return ""

    @classmethod
    def fetch_tile_files(cls, tile_id: str, timeout: int = 12) -> List[AlsFileInfo]:
        """Queries Geoportaal for the given 1:2000 tile_id and returns all available ALS LAZ files."""
        content = cls._query_html("614", tile_id, "lidar_laz_tava", timeout=timeout)
        if not content:
            return []
        return cls.parse_html_results(tile_id, content)

    @classmethod
    def parse_html_results(cls, tile_id: str, html_content: str) -> List[AlsFileInfo]:
        """Parses HTML returned by Geoportaal search endpoint for LAZ files."""
        results: List[AlsFileInfo] = []
        li_pattern = re.compile(
            r'<li[^>]*>\s*<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>.*?\(\s*([^)]+)\s*\)',
            re.IGNORECASE | re.DOTALL,
        )

        for match in li_pattern.finditer(html_content):
            raw_href, raw_name, raw_size = match.groups()
            clean_href = html.unescape(raw_href).strip()
            clean_name = re.sub(r"<[^>]+>", "", raw_name).strip()
            clean_size = raw_size.strip()

            if not clean_name.lower().endswith(".laz"):
                continue

            if not clean_href.startswith("http"):
                download_url = f"https://geoportaal.maaruum.ee/{clean_href}"
            else:
                download_url = clean_href

            year = 0
            flight_type = "tava"
            parts = clean_name.replace(".laz", "").split("_")
            if len(parts) >= 2 and parts[1].isdigit():
                year = int(parts[1])
            if len(parts) >= 3:
                flight_type = parts[2].lower()

            results.append(
                AlsFileInfo(
                    tile_id=tile_id,
                    filename=clean_name,
                    year=year,
                    flight_type=flight_type,
                    size_str=clean_size,
                    download_url=download_url,
                    is_raster=False,
                )
            )

        results.sort(key=lambda x: x.year, reverse=True)
        return results

    @classmethod
    def fetch_extra_layers(
        cls,
        tile_id: str,
        categories: Optional[List[str]] = None,
        timeout: int = 12,
    ) -> List[AlsFileInfo]:
        """
        Queries Geoportaal for additional MaRu raster/elevation datasets (DSM 1m, DTM 1m,
        Orthophotos RGB/Madallend/CIR/NGR, Shaded Basic Map) for the given 1:2000 tile_id
        and its parent 1:10 000 map sheet.
        """
        sheet_10k = GridEngine.tile_2000_to_10000(tile_id)
        results: List[AlsFileInfo] = []
        seen_names = set()

        li_pattern = re.compile(
            r'<li[^>]*>\s*<a\s+[^>]*href=["\']([^"\']*dl=1[^"\']*)["\'][^>]*>(.*?)</a>(?:.*?\(\s*([^)]+)\s*\))?',
            re.IGNORECASE | re.DOTALL,
        )

        for cat_key, page_id, andmetyyp, scale_mode in EXTRA_DATASETS:
            if categories and cat_key not in categories:
                continue
            target_sheet = tile_id if scale_mode == "2000" else sheet_10k
            if not target_sheet:
                continue

            content = cls._query_html(page_id, target_sheet, andmetyyp, timeout=timeout)
            if not content:
                continue

            for match in li_pattern.finditer(content):
                raw_href, raw_name, raw_size = match.groups()
                clean_href = html.unescape(raw_href).strip()
                clean_name = re.sub(r"<[^>]+>", "", raw_name).strip()
                clean_size = (raw_size or "").strip() or "GeoTIFF"

                # Prefer GeoTIFF (.tif / .zip with GeoTIFF) over ECW where both exist
                if "_ECW_" in clean_name.upper():
                    continue
                if clean_name in seen_names:
                    continue
                seen_names.add(clean_name)

                if not clean_href.startswith("http"):
                    download_url = f"https://geoportaal.maaruum.ee/{clean_href}"
                else:
                    download_url = clean_href

                year = 0
                yr_match = re.search(r"(20\d{2}|19\d{2})", clean_name)
                if yr_match:
                    year = int(yr_match.group(1))

                results.append(
                    AlsFileInfo(
                        tile_id=target_sheet,
                        filename=clean_name,
                        year=year,
                        flight_type=cat_key,
                        size_str=clean_size,
                        download_url=download_url,
                        is_raster=True,
                    )
                )

        return results

    @classmethod
    def select_preferred_file(
        cls,
        files: List[AlsFileInfo],
        preference: str = PREF_LATEST_ANY,
    ) -> Optional[AlsFileInfo]:
        """Picks the best matching LAZ file according to user preference."""
        if not files:
            return None

        if preference == PREF_LATEST_TAVA:
            for f in files:
                if f.flight_type == "tava":
                    return f

        elif preference == PREF_LATEST_METS:
            for f in files:
                if f.flight_type == "mets":
                    return f

        return files[0]
