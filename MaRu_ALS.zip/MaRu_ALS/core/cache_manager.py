# -*- coding: utf-8 -*-
"""
Local disk cache manager for downloaded MaRu ALS LAZ files.
"""

import os
import shutil
import subprocess
from qgis.core import QgsSettings


class CacheManager:
    """Manages local storage and retrieval of downloaded LAZ point clouds."""

    DEFAULT_FOLDER_NAME = "MaRu_ALS_Data"

    @classmethod
    def get_cache_dir(cls) -> str:
        """Returns the configured or default cache directory path."""
        settings = QgsSettings()
        custom_dir = settings.value("maru_als/cache_dir", "").strip()
        if custom_dir and os.path.exists(custom_dir):
            return custom_dir

        default_dir = os.path.join(os.path.expanduser("~"), "Documents", cls.DEFAULT_FOLDER_NAME)
        os.makedirs(default_dir, exist_ok=True)
        return default_dir

    @classmethod
    def set_cache_dir(cls, path: str):
        """Sets a new cache directory path in settings."""
        if path:
            os.makedirs(path, exist_ok=True)
            settings = QgsSettings()
            settings.setValue("maru_als/cache_dir", path)

    @classmethod
    def get_file_path(cls, filename: str) -> str:
        """Returns the full local destination path for a given filename."""
        return os.path.join(cls.get_cache_dir(), filename)

    @classmethod
    def is_cached(cls, filename: str) -> bool:
        """Checks whether the file exists in cache and has non-zero size."""
        path = cls.get_file_path(filename)
        return os.path.isfile(path) and os.path.getsize(path) > 1024

    @classmethod
    def get_cache_size_bytes(cls) -> int:
        """Calculates total size of cached files in bytes."""
        cache_dir = cls.get_cache_dir()
        total = 0
        if os.path.exists(cache_dir):
            for entry in os.scandir(cache_dir):
                if entry.is_file() and entry.name.lower().endswith(".laz"):
                    total += entry.stat().st_size
        return total

    @classmethod
    def get_cache_size_str(cls) -> str:
        """Returns formatted string of cache size (e.g. 142.5 MB)."""
        bytes_val = cls.get_cache_size_bytes()
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if bytes_val < 1024.0:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024.0
        return f"{bytes_val:.1f} PB"

    @classmethod
    def clear_cache(cls):
        """Removes all cached LAZ files from the cache directory."""
        cache_dir = cls.get_cache_dir()
        if os.path.exists(cache_dir):
            for entry in os.scandir(cache_dir):
                if entry.is_file() and (entry.name.lower().endswith(".laz") or entry.name.endswith(".copc.laz")):
                    try:
                        os.remove(entry.path)
                    except Exception as e:
                        print(f"[MaRu ALS] Could not remove {entry.path}: {e}")

    @classmethod
    def open_folder(cls):
        """Opens the cache directory in Windows Explorer."""
        cache_dir = cls.get_cache_dir()
        if os.path.exists(cache_dir):
            try:
                os.startfile(cache_dir)
            except Exception:
                subprocess.Popen(["explorer", cache_dir])
