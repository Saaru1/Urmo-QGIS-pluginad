# -*- coding: utf-8 -*-
"""
Mathematical calculation engine for the Estonian Basic Map 1:2000 grid (EPK 1:2000).
Coordinate Reference System: EPSG:3301 (L-EST97).
"""

import math
from typing import List, Tuple, Optional
from qgis.core import (
    QgsPointXY,
    QgsRectangle,
    QgsGeometry,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject
)

CRS_EPSG_3301 = QgsCoordinateReferenceSystem("EPSG:3301")


class GridEngine:
    """Provides high-performance spatial math for the Estonian 1:2000 tile grid."""

    CRS_EPSG_3301 = CRS_EPSG_3301

    Y_BASE = 6000000.0  # Northing base offset (meters)
    CELL_SIZE = 1000.0  # 1 km x 1 km sheet size

    # Valid range for Estonian 1:2000 map sheets
    MIN_Y_CODE = 370
    MAX_Y_CODE = 645
    MIN_X_CODE = 360
    MAX_X_CODE = 745

    @classmethod
    def point_to_tile(cls, x: float, y: float) -> str:
        """
        Convert EPSG:3301 coordinates to 6-digit tile ID (YYYXXX).
        """
        y_code = int(math.floor((y - cls.Y_BASE) / cls.CELL_SIZE))
        x_code = int(math.floor(x / cls.CELL_SIZE))
        return f"{y_code:03d}{x_code:03d}"

    @classmethod
    def is_valid_tile(cls, tile_id: str) -> bool:
        """Check if 6-digit tile ID falls within Estonian geographic extent."""
        if not tile_id or len(tile_id) != 6 or not tile_id.isdigit():
            return False
        y_code = int(tile_id[:3])
        x_code = int(tile_id[3:])
        return (cls.MIN_Y_CODE <= y_code <= cls.MAX_Y_CODE and
                cls.MIN_X_CODE <= x_code <= cls.MAX_X_CODE)

    @classmethod
    def tile_2000_to_10000(cls, tile_id: str) -> Optional[str]:
        """
        Convert a 6-digit 1:2000 tile ID (YYYXXX) into the official 5-digit
        Estonian 1:10 000 map sheet number (epk_10T: D1 D2 D3 D4 Q).
        """
        if not cls.is_valid_tile(tile_id):
            return None
        y_code = int(tile_id[:3])
        x_code = int(tile_id[3:])
        d1 = (y_code // 100) + 1
        d2 = (x_code // 100) - 2
        d3 = (y_code // 10) % 10
        d4 = (x_code // 10) % 10
        q = 1 + (2 if (y_code % 10) >= 5 else 0) + (1 if (x_code % 10) >= 5 else 0)
        return f"{d1}{d2}{d3}{d4}{q}"

    @classmethod
    def tile_to_rect(cls, tile_id: str) -> Optional[QgsRectangle]:
        """Convert a 6-digit tile ID into an EPSG:3301 bounding box rectangle."""
        if not cls.is_valid_tile(tile_id):
            return None
        y_code = int(tile_id[:3])
        x_code = int(tile_id[3:])
        x_min = x_code * cls.CELL_SIZE
        x_max = x_min + cls.CELL_SIZE
        y_min = cls.Y_BASE + y_code * cls.CELL_SIZE
        y_max = y_min + cls.CELL_SIZE
        return QgsRectangle(x_min, y_min, x_max, y_max)

    @classmethod
    def get_tile_bounds(cls, tile_id: str) -> Optional[Tuple[float, float, float, float]]:
        """Return (x_min, y_min, x_max, y_max) in EPSG:3301 for a 6-digit tile ID."""
        r = cls.tile_to_rect(tile_id)
        if not r:
            return None
        return (r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum())

    @classmethod
    def tile_to_polygon(cls, tile_id: str) -> Optional[QgsGeometry]:
        """Convert a 6-digit tile ID into a QgsGeometry polygon in EPSG:3301."""
        rect = cls.tile_to_rect(tile_id)
        if not rect:
            return None
        return QgsGeometry.fromRect(rect)

    @classmethod
    def get_tiles_in_rect(cls, rect: QgsRectangle) -> List[str]:
        """
        Returns all valid 1:2000 tile IDs intersecting the given EPSG:3301 rectangle.
        Order is row-by-row (North to South, West to East).
        """
        min_x = min(rect.xMinimum(), rect.xMaximum())
        max_x = max(rect.xMinimum(), rect.xMaximum())
        min_y = min(rect.yMinimum(), rect.yMaximum())
        max_y = max(rect.yMinimum(), rect.yMaximum())

        min_xc = int(math.floor(min_x / cls.CELL_SIZE))
        max_xc = int(math.floor((max_x - 1e-4) / cls.CELL_SIZE))
        min_yc = int(math.floor((min_y - cls.Y_BASE) / cls.CELL_SIZE))
        max_yc = int(math.floor((max_y - 1e-4 - cls.Y_BASE) / cls.CELL_SIZE))

        # Clamp within Estonia extent to prevent runaway iterations
        min_xc = max(cls.MIN_X_CODE, min_xc)
        max_xc = min(cls.MAX_X_CODE, max_xc)
        min_yc = max(cls.MIN_Y_CODE, min_yc)
        max_yc = min(cls.MAX_Y_CODE, max_yc)

        if min_xc > max_xc or min_yc > max_yc:
            return []

        tiles: List[str] = []
        for yc in range(max_yc, min_yc - 1, -1):
            for xc in range(min_xc, max_xc + 1):
                tid = f"{yc:03d}{xc:03d}"
                if cls.is_valid_tile(tid):
                    tiles.append(tid)
        return tiles

    @classmethod
    def trace_tiles_along_segment(cls, p1: QgsPointXY, p2: QgsPointXY) -> List[str]:
        """
        Calculates the ordered list of 1:2000 tiles intersected by a directed segment
        from p1 to p2 using fast Amanatides-Woo 2D ray traversal.
        """
        x1, y1 = p1.x(), p1.y()
        x2, y2 = p2.x(), p2.y()

        gx1 = int(math.floor(x1 / cls.CELL_SIZE))
        gy1 = int(math.floor((y1 - cls.Y_BASE) / cls.CELL_SIZE))
        gx2 = int(math.floor(x2 / cls.CELL_SIZE))
        gy2 = int(math.floor((y2 - cls.Y_BASE) / cls.CELL_SIZE))

        # Single tile case
        if gx1 == gx2 and gy1 == gy2:
            t = f"{gy1:03d}{gx1:03d}"
            return [t] if cls.is_valid_tile(t) else []

        dx = x2 - x1
        dy = y2 - y1

        step_x = 1 if dx > 0 else (-1 if dx < 0 else 0)
        step_y = 1 if dy > 0 else (-1 if dy < 0 else 0)

        curr_gx = gx1
        curr_gy = gy1
        cells: List[Tuple[int, int]] = [(curr_gy, curr_gx)]

        if dx != 0:
            next_x = (curr_gx + 1) * cls.CELL_SIZE if step_x > 0 else curr_gx * cls.CELL_SIZE
            t_max_x = (next_x - x1) / dx
            t_delta_x = abs(cls.CELL_SIZE / dx)
        else:
            t_max_x = float('inf')
            t_delta_x = float('inf')

        if dy != 0:
            next_y = cls.Y_BASE + ((curr_gy + 1) * cls.CELL_SIZE if step_y > 0 else curr_gy * cls.CELL_SIZE)
            t_max_y = (next_y - y1) / dy
            t_delta_y = abs(cls.CELL_SIZE / dy)
        else:
            t_max_y = float('inf')
            t_delta_y = float('inf')

        max_steps = 300
        steps = 0
        while (curr_gx != gx2 or curr_gy != gy2) and steps < max_steps:
            steps += 1
            if t_max_x < t_max_y:
                t_max_x += t_delta_x
                curr_gx += step_x
            elif t_max_y < t_max_x:
                t_max_y += t_delta_y
                curr_gy += step_y
            else:
                t_max_x += t_delta_x
                t_max_y += t_delta_y
                curr_gx += step_x
                curr_gy += step_y
            cells.append((curr_gy, curr_gx))

        # Format and filter valid Estonian tiles while preserving order
        res = []
        for gy, gx in cells:
            tile_code = f"{gy:03d}{gx:03d}"
            if cls.is_valid_tile(tile_code) and tile_code not in res:
                res.append(tile_code)
        return res

    @classmethod
    def calculate_azimuth(cls, p1: QgsPointXY, p2: QgsPointXY) -> float:
        """
        Calculate compass azimuth (0 deg = North, 90 deg = East) of vector p1 -> p2.
        """
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        rad = math.atan2(dx, dy)
        deg = math.degrees(rad)
        return (deg + 360.0) % 360.0

    @classmethod
    def calculate_distance(cls, p1: QgsPointXY, p2: QgsPointXY) -> float:
        """Calculate Euclidean distance in meters."""
        return math.hypot(p2.x() - p1.x(), p2.y() - p1.y())

    @classmethod
    def transform_point_to_3301(cls, pt: QgsPointXY, src_crs: QgsCoordinateReferenceSystem) -> QgsPointXY:
        """Transform a point from any source CRS to EPSG:3301."""
        if not src_crs.isValid() or src_crs.authid() == "EPSG:3301":
            return pt
        xform = QgsCoordinateTransform(src_crs, cls.CRS_EPSG_3301, QgsProject.instance())
        return xform.transform(pt)

    @classmethod
    def transform_point_from_3301(cls, pt: QgsPointXY, dest_crs: QgsCoordinateReferenceSystem) -> QgsPointXY:
        """Transform a point from EPSG:3301 to destination CRS."""
        if not dest_crs.isValid() or dest_crs.authid() == "EPSG:3301":
            return pt
        xform = QgsCoordinateTransform(cls.CRS_EPSG_3301, dest_crs, QgsProject.instance())
        return xform.transform(pt)
