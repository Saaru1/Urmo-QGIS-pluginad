# -*- coding: utf-8 -*-
"""
Asynchronous background downloader using QThread for MaRu ALS LAZ and GeoTIFF/ZIP files.
Includes silent EPSG:3301 CRS assignment, synchronous QgsMessageBar CRS-banner suppression,
smooth 1% progress reporting, and automatic ZIP extraction for raster layers.
"""

import os
import time
import urllib.request
import zipfile
from typing import List, Optional

from qgis.PyQt.QtCore import QThread, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QWidget
from qgis.core import (
    Qgis,
    QgsColorRampShader,
    QgsCoordinateReferenceSystem,
    QgsGradientColorRamp,
    QgsGradientStop,
    QgsMessageLog,
    QgsPointCloudLayer,
    QgsProject,
    QgsRasterLayer,
    QgsRasterShader,
    QgsSettings,
    QgsSingleBandPseudoColorRenderer,
)
from qgis.utils import iface as qgis_iface

from ..i18n import tr
from .cache_manager import CacheManager
from .geoportaal_api import AlsFileInfo, GeoportaalClient

CRS_3301 = QgsCoordinateReferenceSystem("EPSG:3301")

_CRS_FILTER_REFS = []


def install_crs_banner_filter(iface_obj=None):
    """
    Connects to `iface.messageBar().widgetAdded` so any 'CRS was undefined' banner pushed
    by synchronous layer loading OR asynchronous background PDAL indexing threads is
    popped immediately before Qt paints it.
    """
    bar = None
    if iface_obj is not None and hasattr(iface_obj, "messageBar"):
        bar = iface_obj.messageBar()
    elif qgis_iface is not None and hasattr(qgis_iface, "messageBar"):
        bar = qgis_iface.messageBar()
    if bar is None:
        return
    for b_ref, _ in _CRS_FILTER_REFS:
        if b_ref is bar:
            return

    def _on_widget_added(item):
        try:
            if _is_crs_undefined_widget(item):
                cur = bar.currentItem()
                if cur is not None and _is_crs_undefined_widget(cur):
                    bar.popWidget(cur)
            QTimer.singleShot(0, lambda: dismiss_crs_undefined_banners(iface_obj))
        except Exception:
            pass

    try:
        _CRS_FILTER_REFS.append((bar, _on_widget_added))
        bar.widgetAdded.connect(_on_widget_added)
    except Exception:
        pass


def uninstall_crs_banner_filter():
    """Disconnects all messageBar listeners when the plugin is unloaded/uninstalled."""
    global _CRS_FILTER_REFS
    for bar, callback in list(_CRS_FILTER_REFS):
        try:
            bar.widgetAdded.disconnect(callback)
        except Exception:
            pass
    _CRS_FILTER_REFS.clear()


def ensure_default_crs_3301(touch_project: bool = True):
    """Configures QGIS settings so new layers default silently to EPSG:3301 without prompts."""
    s = QgsSettings()
    for prefix in ("/Projections", "Projections", "/projections", "projections"):
        s.setValue(f"{prefix}/defaultBehavior", "useGlobal")
        s.setValue(f"{prefix}/layerDefaultCrs", "EPSG:3301")
        s.setValue(f"{prefix}/projectDefaultCrs", "EPSG:3301")
    if touch_project:
        proj = QgsProject.instance()
        if not proj.crs().isValid():
            was_dirty = proj.isDirty()
            proj.setCrs(CRS_3301)
            if not was_dirty and len(proj.mapLayers()) == 0:
                proj.setDirty(False)


def _is_crs_undefined_widget(widget: QWidget) -> bool:
    """Checks if a QgsMessageBarItem widget contains the 'CRS was undefined' message."""
    if widget is None:
        return False
    try:
        texts = []
        for child in widget.findChildren(QWidget):
            for attr in ("toPlainText", "text"):
                fn = getattr(child, attr, None)
                if callable(fn):
                    try:
                        val = fn()
                        if val:
                            texts.append(str(val))
                    except Exception:
                        pass
        full_txt = " ".join(texts).lower()
        return (
            "crs was undefined" in full_txt
            or "defaulting to crs" in full_txt
            or "määratlemata" in full_txt
            or ("koordinaatsüsteem" in full_txt and "3301" in full_txt)
        )
    except Exception:
        return False


def dismiss_crs_undefined_banners(iface_obj=None):
    """Removes any 'CRS was undefined' message bar items pushed by QGIS C++ providers."""
    bar = None
    if iface_obj is not None and hasattr(iface_obj, "messageBar"):
        bar = iface_obj.messageBar()
    elif qgis_iface is not None and hasattr(qgis_iface, "messageBar"):
        bar = qgis_iface.messageBar()
    if bar is None:
        return
    try:
        item = bar.currentItem()
        safety = 0
        while item is not None and safety < 10:
            safety += 1
            if _is_crs_undefined_widget(item):
                bar.popWidget(item)
                item = bar.currentItem()
            else:
                break
    except Exception:
        pass


def _write_crs_sidecars(file_path: str):
    """Writes .prj and .aux.xml sidecars with EPSG:3301 so GDAL/PDAL recognizes the CRS."""
    try:
        wkt = CRS_3301.toWkt()
        base = os.path.splitext(file_path)[0]
        prj_path = base + ".prj"
        if not os.path.exists(prj_path) and wkt:
            with open(prj_path, "w", encoding="utf-8") as f:
                f.write(wkt)
        aux_path = file_path + ".aux.xml"
        if not os.path.exists(aux_path) and wkt:
            with open(aux_path, "w", encoding="utf-8") as f:
                f.write(f"<PAMDataset><SRS>{wkt}</SRS></PAMDataset>")
    except Exception:
        pass


class DownloadWorker(QThread):
    """
    QThread worker that downloads one or more LAZ / GeoTIFF / ZIP files with real-time 1% progress.
    """

    file_completed = pyqtSignal(object)                 # AlsFileInfo
    all_completed = pyqtSignal(list)                    # List[AlsFileInfo]
    progress_updated = pyqtSignal(int, str)             # (percent, status text)
    file_progress = pyqtSignal(object, int, str)        # (AlsFileInfo, percent, status text)
    failed = pyqtSignal(str)                            # Error message

    CHUNK_SIZE = 64 * 1024

    def __init__(self, files: List[AlsFileInfo], parent=None):
        super().__init__(parent)
        self.files = files
        self.downloaded_files: List[AlsFileInfo] = []
        self._is_canceled = False

    def cancel(self):
        self._is_canceled = True

    def run(self):
        total = len(self.files)
        if total == 0:
            self.all_completed.emit([])
            return

        for idx, file_info in enumerate(self.files):
            if self._is_canceled:
                return

            local_path = CacheManager.get_file_path(file_info.filename)
            file_info.local_path = local_path

            # 1. Check if already in local cache
            if CacheManager.is_cached(file_info.filename):
                file_info.downloaded = True
                self.downloaded_files.append(file_info)
                self.file_progress.emit(file_info, 100, f"Vahemälus: {file_info.filename}")
                self.file_completed.emit(file_info)
                pct = int(((idx + 1) / total) * 100)
                self.progress_updated.emit(pct, f"Vahemälus: {file_info.filename}")
                continue

            # 2. Download from Geoportaal
            status_text = (
                f"Laadin alla ({file_info.tile_id}): "
                f"{file_info.filename} ({file_info.size_str})..."
            )
            self.progress_updated.emit(max(1, int((idx / total) * 100)), status_text)
            self.file_progress.emit(file_info, 1, status_text)

            temp_path = local_path + ".tmp"
            headers = {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko)"
                ),
                "Referer": "https://geoportaal.maaruum.ee/est/Ruumiandmed/Korgusandmed/Laadi-korgusandmed-alla-p614.html",
            }
            req = urllib.request.Request(file_info.download_url, headers=headers)

            try:
                with urllib.request.urlopen(req, timeout=90) as resp, open(temp_path, "wb") as out_f:
                    content_length = resp.headers.get("Content-Length")
                    total_bytes = (
                        int(content_length)
                        if content_length and content_length.isdigit()
                        else 0
                    )
                    downloaded_bytes = 0
                    last_emit_pct = -1
                    last_emit_t = 0.0

                    while True:
                        if self._is_canceled:
                            out_f.close()
                            if os.path.exists(temp_path):
                                os.remove(temp_path)
                            return

                        chunk = resp.read(self.CHUNK_SIZE)
                        if not chunk:
                            break
                        out_f.write(chunk)
                        downloaded_bytes += len(chunk)

                        now = time.perf_counter()
                        if total_bytes > 0:
                            pct_file = min(99, int((downloaded_bytes / total_bytes) * 100))
                            if pct_file > last_emit_pct and (now - last_emit_t >= 0.08 or pct_file == 99):
                                last_emit_pct = pct_file
                                last_emit_t = now
                                mb_done = downloaded_bytes / (1024.0 * 1024.0)
                                mb_tot = total_bytes / (1024.0 * 1024.0)
                                msg = f"Laadin alla: {file_info.filename} — {mb_done:.1f} / {mb_tot:.1f} MB ({pct_file}%)"
                                self.progress_updated.emit(pct_file, msg)
                                self.file_progress.emit(file_info, pct_file, msg)
                        elif now - last_emit_t >= 0.15:
                            last_emit_t = now
                            mb_done = downloaded_bytes / (1024.0 * 1024.0)
                            # Estimate from size_str if Content-Length header was omitted
                            pct_est = min(95, int(mb_done * 5))
                            msg = f"Laadin alla: {file_info.filename} — {mb_done:.1f} MB..."
                            self.progress_updated.emit(pct_est, msg)
                            self.file_progress.emit(file_info, pct_est, msg)

                if os.path.exists(local_path):
                    os.remove(local_path)
                os.rename(temp_path, local_path)

                file_info.downloaded = True
                self.downloaded_files.append(file_info)
                self.file_progress.emit(file_info, 100, f"Allalaaditud: {file_info.filename}")
                self.file_completed.emit(file_info)

            except Exception as e:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except Exception:
                        pass
                err_msg = f"Viga ruudu {file_info.tile_id} allalaadimisel: {e}"
                QgsMessageLog.logMessage(err_msg, "MaRu ALS", Qgis.Warning)
                self.failed.emit(err_msg)

            pct = int(((idx + 1) / total) * 100)
            self.progress_updated.emit(pct, f"Valmis: {file_info.filename}")

        if not self._is_canceled:
            self.all_completed.emit(self.downloaded_files)


class MetadataWorker(QThread):
    """QThread worker to query Geoportaal LAZ metadata for a list of tiles in the background."""

    tile_metadata_ready = pyqtSignal(str, list)  # (tile_id, List[AlsFileInfo])

    def __init__(self, tiles: List[str], parent=None):
        super().__init__(parent)
        self.tiles = tiles

    def run(self):
        for tile in self.tiles:
            files = GeoportaalClient.fetch_tile_files(tile)
            self.tile_metadata_ready.emit(tile, files)


class ExtraLayersMetadataWorker(QThread):
    """QThread worker to query Geoportaal extra raster layers (DSM, DTM, Orto, Basic Map)."""

    extra_metadata_ready = pyqtSignal(str, list)  # (tile_id, List[AlsFileInfo])
    progress_updated = pyqtSignal(int, str)

    def __init__(self, tiles: List[str], categories: Optional[List[str]] = None, parent=None):
        super().__init__(parent)
        self.tiles = tiles
        self.categories = categories

    def run(self):
        total = max(1, len(self.tiles))
        for i, tile in enumerate(self.tiles):
            pct = int((i / total) * 100)
            self.progress_updated.emit(pct, f"Pärin Geoportaalist lisakihte ruudule {tile}...")
            files = GeoportaalClient.fetch_extra_layers(tile, categories=self.categories)
            if files:
                self.extra_metadata_ready.emit(tile, files)
        self.progress_updated.emit(100, "Lisakihtide päring valmis.")


def load_pointcloud_layer(
    file_path: str,
    layer_name: Optional[str] = None,
    iface_obj=None,
) -> Optional[QgsPointCloudLayer]:
    """
    Safely creates and adds a QgsPointCloudLayer to the active QGIS project.
    Sets CRS to EPSG:3301 and suppresses the 'CRS was undefined' warning banner.
    """
    if not os.path.exists(file_path):
        return None

    ensure_default_crs_3301()
    install_crs_banner_filter(iface_obj)
    _write_crs_sidecars(file_path)

    if not layer_name:
        layer_name = os.path.splitext(os.path.basename(file_path))[0]

    for lyr in QgsProject.instance().mapLayers().values():
        if isinstance(lyr, QgsPointCloudLayer) and (
            file_path in lyr.source() or lyr.name() == layer_name
        ):
            dismiss_crs_undefined_banners(iface_obj)
            return lyr

    opts = QgsPointCloudLayer.LayerOptions()
    opts.skipCrsValidation = True

    layer = QgsPointCloudLayer(file_path, layer_name, "pdal", opts)
    if not layer.isValid():
        layer = QgsPointCloudLayer(file_path, layer_name, "copc", opts)

    if layer.isValid():
        layer.setCrs(CRS_3301)
        QgsProject.instance().addMapLayer(layer)
        dismiss_crs_undefined_banners(iface_obj)
        QTimer.singleShot(50, lambda: dismiss_crs_undefined_banners(iface_obj))
        QTimer.singleShot(300, lambda: dismiss_crs_undefined_banners(iface_obj))
        return layer
    else:
        QgsMessageLog.logMessage(
            f"Punktipilve kihi laadimine ebaõnnestus failist: {file_path}",
            "MaRu ALS",
            Qgis.Critical,
        )
        return None


def resolve_raster_path(local_path: str) -> Optional[str]:
    """If local_path is a .zip archive, extracts it and returns the inner .tif/.jpg path."""
    if not os.path.exists(local_path):
        return None
    if local_path.lower().endswith(".zip"):
        extract_dir = os.path.splitext(local_path)[0] + "_extracted"
        os.makedirs(extract_dir, exist_ok=True)
        try:
            with zipfile.ZipFile(local_path, "r") as z:
                for member in z.namelist():
                    dest = os.path.join(extract_dir, os.path.basename(member))
                    if not os.path.exists(dest) and not member.endswith("/"):
                        with z.open(member) as src, open(dest, "wb") as dst:
                            dst.write(src.read())
        except Exception as e:
            QgsMessageLog.logMessage(f"ZIP lahtipakkimise viga: {e}", "MaRu ALS", Qgis.Warning)
            return None

        for root, _, files in os.walk(extract_dir):
            for fn in files:
                if fn.lower().endswith((".tif", ".tiff", ".jp2", ".png", ".jpg")):
                    return os.path.join(root, fn)
        return None
    return local_path


def load_raster_layer(
    local_path: str,
    layer_name: Optional[str] = None,
    category: str = "",
    file_info: Optional[AlsFileInfo] = None,
    iface_obj=None,
) -> Optional[QgsRasterLayer]:
    """
    Loads a downloaded MaRu GeoTIFF (or ZIP containing GeoTIFF) into the QGIS Layers panel
    with EPSG:3301 CRS and automatic elevation styling for DSM/DTM.
    """
    tif_path = resolve_raster_path(local_path)
    if not tif_path or not os.path.exists(tif_path):
        return None

    ensure_default_crs_3301()
    install_crs_banner_filter(iface_obj)
    _write_crs_sidecars(tif_path)

    if not layer_name:
        layer_name = os.path.splitext(os.path.basename(tif_path))[0]

    for lyr in QgsProject.instance().mapLayers().values():
        if isinstance(lyr, QgsRasterLayer) and (
            tif_path in lyr.source() or lyr.name() == layer_name
        ):
            dismiss_crs_undefined_banners(iface_obj)
            return lyr

    opts = QgsRasterLayer.LayerOptions()
    opts.skipCrsValidation = True
    layer = QgsRasterLayer(tif_path, layer_name, "gdal", opts)
    if not layer.isValid():
        return None

    layer.setCrs(CRS_3301)

    # Apply terrain pseudocolor styling if DSM 1m or DTM 1m single-band elevation raster
    cat = (category or (file_info.flight_type if file_info else "")).lower()
    if (
        cat in ("dsm_1m", "dtm_1m")
        or "_dsm_" in layer_name.lower()
        or "_dtm_" in layer_name.lower()
        or "_dem_" in layer_name.lower()
    ):
        try:
            provider = layer.dataProvider()
            stats = provider.bandStatistics(1)
            zmin = float(stats.minimumValue) if stats else 0.0
            zmax = float(stats.maximumValue) if stats else 60.0
            if zmax <= zmin or zmin < -500:
                zmin, zmax = 0.0, 60.0
            ramp = QgsGradientColorRamp(
                QColor(43, 131, 186),
                QColor(215, 25, 28),
                False,
                [
                    QgsGradientStop(0.25, QColor(171, 221, 164)),
                    QgsGradientStop(0.50, QColor(255, 255, 191)),
                    QgsGradientStop(0.75, QColor(253, 174, 97)),
                ],
            )
            fcn = QgsColorRampShader(zmin, zmax, ramp, QgsColorRampShader.Interpolated)
            fcn.classifyColorRamp(5)
            shader = QgsRasterShader()
            shader.setRasterShaderFunction(fcn)
            renderer = QgsSingleBandPseudoColorRenderer(provider, 1, shader)
            layer.setRenderer(renderer)
        except Exception:
            pass

    QgsProject.instance().addMapLayer(layer)
    dismiss_crs_undefined_banners(iface_obj)
    QTimer.singleShot(50, lambda: dismiss_crs_undefined_banners(iface_obj))
    QTimer.singleShot(250, lambda: dismiss_crs_undefined_banners(iface_obj))
    return layer
