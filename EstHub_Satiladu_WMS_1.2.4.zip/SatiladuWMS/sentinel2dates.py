# -*- coding: utf-8 -*-
"""
SentinelWMS – QGIS plugin main script
Modular Architecture with Async GIF Processing
"""
import os
import datetime
from qgis.core import Qgis, QgsMessageLog, QgsRasterLayer, QgsProject
from qgis.PyQt.QtCore import Qt, QDate
from qgis.PyQt.QtGui import QIcon, QTextCharFormat, QColor, QFont
from qgis.PyQt.QtWidgets import QAction, QComboBox, QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QCalendarWidget

# Import our modules
from .satiladu_api import SatiladuAPI
from .layer_manager import LayerManager
from .gif_dialog import GifGeneratorDialog

# ============================================================================
# Calendar Selection Dialog
# ============================================================================
class CalendarSelectDialog(QDialog):
    def __init__(self, parent_plugin):
        super().__init__(parent_plugin.iface.mainWindow())
        self.plugin = parent_plugin
        self.setWindowTitle("Select Date")
        self.resize(400, 350)

        layout = QVBoxLayout(self)
        self.calendar = QCalendarWidget()
        self.calendar.setMaximumDate(QDate.currentDate())
        self.calendar.setGridVisible(True)
        self.calendar.selectionChanged.connect(self._validate_selection)
        layout.addWidget(self.calendar)

        btn_layout = QHBoxLayout()
        self.btn_ok = QPushButton("Jump to Date")
        self.btn_cancel = QPushButton("Cancel")
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)

        self._highlight_dates()

        if self.plugin.api.url_list and 0 <= self.plugin._list_pos < len(self.plugin.api.url_list):
            dt = datetime.date.fromisoformat(self.plugin.api.url_list[self.plugin._list_pos][0])
            self.calendar.setSelectedDate(QDate(dt.year, dt.month, dt.day))
            
        self._validate_selection() 

    def _highlight_dates(self):
        if not self.plugin.api.url_list: return
        fmt = QTextCharFormat()
        
        # PyQt5 / PyQt6 Dual Compatibility for Font Weight
        try:
            bold_weight = QFont.Weight.Bold # PyQt6
        except AttributeError:
            bold_weight = QFont.Bold        # PyQt5

        if self.plugin.action_sun.isChecked():
            fmt.setBackground(QColor("yellow"))
            fmt.setFontWeight(bold_weight)
        else:
            fmt.setBackground(QColor("#E0E0E0")) 
            fmt.setFontWeight(bold_weight)

        for dstr, _ in self.plugin.api.url_list:
            dt = datetime.date.fromisoformat(dstr)
            self.calendar.setDateTextFormat(QDate(dt.year, dt.month, dt.day), fmt)

    def _validate_selection(self):
        if self.plugin.action_sun.isChecked():
            date_str = self.calendar.selectedDate().toPyDate().isoformat()
            is_valid = any(d[0] == date_str for d in self.plugin.api.url_list)
            self.btn_ok.setEnabled(is_valid)
        else:
            self.btn_ok.setEnabled(True)

    def get_selected_date(self):
        return self.calendar.selectedDate().toPyDate()

# ============================================================================
# Main Plugin Class
# ============================================================================
class Sentinel2Dates:
    def __init__(self, iface):
        self.iface = iface
        self.api = SatiladuAPI()
        self.layers = LayerManager(iface)

        self.action_today = None
        self.action_sun = None
        self.action_calendar = None
        self.action_snapshot = None
        self.action_prev = None
        self.action_next = None
        self.action_prev_10 = None
        self.action_next_10 = None
        self.action_gif = None
        
        self.combo_sensor = None
        self.combo_filter = None
        self.toolbar = None
        self._list_pos = 0

        self._filter_data = [
            ("RGB", 1, "harilik värvifoto"),
            ("NRG", 3, "valevärvipilt \"Lähi-infrapuna Punane Roheline\""),
            ("NDVI", 5, "normaliseeritud taimkatte indeks (NDVI)"),
            ("NGR", 7, "valevärvipilt \"Lähi-infrapuna Roheline Punane\""),
            ("NDPI", 9, "normaliseeritud veekogude indeks (NDPI)"),
            ("PNB", 11, "valevärvipilt \"NDPI Lähi-infrapuna Sinine\""),
            ("NGP", 13, "valevärvipilt \"Lähi-infrapuna Roheline NDPI\""),
            ("NDR", 15, "valevärvipilt \"Lähi-infrapuna NDVI Punane\""),
            ("PDB", 17, "valevärvipilt \"NDPI NDVI Sinine\""),
            ("NDN", 19, "valevärvipilt \"Lähi-infrapuna NDVI Lähi-infrapuna\""),
            ("PDN", 21, "valevärvipilt \"NDPI NDVI Lähi-infrapuna\""),
            ("NNR", 23, "valevärvipilt \"Lähi-infrapuna Lähi-Infrapuna Punane\""),
            ("DNP", 25, "valevärvipilt \"NDVI Lähi-infrapuna NDPI\"")
        ]

    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        def get_icon(filename):
            return QIcon(os.path.join(plugin_dir, filename))

        self.combo_sensor = QComboBox()
        self.combo_sensor.addItems(["Sentinel-2", "Landsat-8"])
        self.combo_sensor.currentIndexChanged.connect(self._on_settings_changed)

        # PyQt5 / PyQt6 Dual Compatibility for ToolTipRole
        try:
            tooltip_role = Qt.ItemDataRole.ToolTipRole
        except AttributeError:
            tooltip_role = Qt.ToolTipRole

        self.combo_filter = QComboBox()
        for idx, (code, toode_id, desc) in enumerate(self._filter_data):
            self.combo_filter.addItem(code, toode_id)
            self.combo_filter.setItemData(idx, desc, tooltip_role)
        self.combo_filter.currentIndexChanged.connect(self._on_settings_changed)

        self.action_today = QAction(get_icon("icon.png"), "Toggle WMS Layer", self.iface.mainWindow())
        self.action_today.setCheckable(True)
        self.action_today.toggled.connect(self._on_main_toggled)

        self.action_sun = QAction(get_icon("icon_sun.png"), "Pilvitu (Cloudless) filter", self.iface.mainWindow())
        self.action_sun.setCheckable(True)
        self.action_sun.toggled.connect(self._on_sun_toggled)

        self.action_calendar = QAction(get_icon("calendar.png"), "Select Date from Calendar", self.iface.mainWindow())
        self.action_calendar.triggered.connect(self._open_calendar_dialog)

        self.action_snapshot = QAction(get_icon("icon_snapshot.png"), "Snapshot current layer", self.iface.mainWindow())
        self.action_snapshot.triggered.connect(self._take_snapshot)

        self.action_prev = QAction(get_icon("icon_left.png"), "Prev", self.iface.mainWindow())
        self.action_prev.triggered.connect(lambda: self._open_relative_exact(-1))
        self.action_next = QAction(get_icon("icon_right.png"), "Next", self.iface.mainWindow())
        self.action_next.triggered.connect(lambda: self._open_relative_exact(1))
        self.action_prev_10 = QAction(get_icon("icon_left_10.png"), "Prev 10", self.iface.mainWindow())
        self.action_prev_10.triggered.connect(lambda: self._open_relative_exact(-10))
        self.action_next_10 = QAction(get_icon("icon_right_10.png"), "Next 10", self.iface.mainWindow())
        self.action_next_10.triggered.connect(lambda: self._open_relative_exact(10))

        self.action_gif = QAction("GIF", self.iface.mainWindow())
        self.action_gif.triggered.connect(self._open_gif_dialog)

        self.toolbar = self.iface.addToolBar("Satiladu Navigation")
        self.toolbar.setObjectName("Sentinel2DatesToolbar")
        self.toolbar.addWidget(self.combo_sensor)
        self.toolbar.addWidget(self.combo_filter)
        
        ordered_actions = [
            self.action_prev_10, self.action_prev, self.action_sun, self.action_calendar,
            self.action_today, self.action_snapshot, self.action_next, self.action_next_10, self.action_gif
        ]

        for act in ordered_actions:
            self.toolbar.addAction(act)
            self.iface.addPluginToMenu("&Sentinel WMS", act)

        self._update_ui_state()

    def unload(self):
        self.layers.remove_layer()
        if self.toolbar: self.iface.mainWindow().removeToolBar(self.toolbar)

    def _sync_api_call(self):
        bbox = self.layers.get_canvas_bbox_latlon_str()
        sensor = self.combo_sensor.currentText()
        toode = self.combo_filter.currentData()
        pilvitu = self.action_sun.isChecked()
        return self.api.refresh_urls_list(bbox, sensor, toode, pilvitu)

    def _on_main_toggled(self, checked: bool):
        if checked:
            if not self.api.url_list: 
                self._sync_api_call()
            self._load_current_index()
        else:
            self.layers.remove_layer()
            
        self._update_ui_state()

    def _on_sun_toggled(self, checked: bool):
        target_date_str = None
        if self.api.url_list and 0 <= self._list_pos < len(self.api.url_list):
            target_date_str = self.api.url_list[self._list_pos][0]

        if checked and not self.action_today.isChecked():
            self.action_today.blockSignals(True)
            self.action_today.setChecked(True)
            self.action_today.blockSignals(False)

        if self._sync_api_call():
            if target_date_str:
                target_dt = datetime.date.fromisoformat(target_date_str)
                best_idx, min_diff = 0, float('inf')
                for idx, (d_str, _) in enumerate(self.api.url_list):
                    diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
                    if diff == 0: best_idx = idx; break 
                    if diff < min_diff: min_diff = diff; best_idx = idx
                self._list_pos = best_idx
            else:
                self._list_pos = 0 

            if self.action_today.isChecked():
                self._load_current_index()
                
        self._update_ui_state()

    def _on_settings_changed(self):
        if not self.action_today.isChecked(): return
        
        target_date_str = self.api.url_list[self._list_pos][0] if self.api.url_list and 0 <= self._list_pos < len(self.api.url_list) else None

        if self._sync_api_call():
            if target_date_str:
                target_dt = datetime.date.fromisoformat(target_date_str)
                best_idx, min_diff = 0, float('inf')
                for idx, (d_str, _) in enumerate(self.api.url_list):
                    diff = abs((datetime.date.fromisoformat(d_str) - target_dt).days)
                    if diff == 0: best_idx = idx; break 
                    if diff < min_diff: min_diff = diff; best_idx = idx
                self._list_pos = best_idx
            self._load_current_index()
        self._update_ui_state()

    def _load_current_index(self):
        if not self.api.url_list:
            self.action_today.setChecked(False)
            return
            
        self._list_pos = max(0, min(self._list_pos, len(self.api.url_list) - 1))
        date_str, url = self.api.url_list[self._list_pos]
        
        lyr = self.layers.make_layer(date_str, url, self.combo_sensor.currentText(), self.combo_filter.currentText())
        if lyr:
            self.layers.replace_layer(lyr)
        else:
            self.action_today.setChecked(False)

    def _open_relative_exact(self, delta: int):
        if not self.action_today.isChecked() or not self.api.url_list: return
        new_pos = max(0, min(self._list_pos - delta, len(self.api.url_list) - 1))
        if new_pos != self._list_pos:
            self._list_pos = new_pos
            self._load_current_index()

    def _open_calendar_dialog(self):
        if not self.api.url_list and self.action_today.isChecked(): self._sync_api_call()
        dialog = CalendarSelectDialog(self)
        
        # PyQt5 / PyQt6 compatibility for exec()
        accepted = dialog.exec() if hasattr(dialog, 'exec') else dialog.exec_()
        
        if accepted:
            target_pydate = dialog.get_selected_date()
            if not self.action_today.isChecked(): self.action_today.setChecked(True)
            if not self.api.url_list:
                if not self._sync_api_call(): return
                
            best_idx, min_diff = 0, float('inf')
            for idx, (d_str, _) in enumerate(self.api.url_list):
                diff = abs((datetime.date.fromisoformat(d_str) - target_pydate).days)
                if diff == 0: best_idx = idx; break
                if diff < min_diff: min_diff = diff; best_idx = idx
                    
            self._list_pos = best_idx
            self._load_current_index()

    def _open_gif_dialog(self):
        dialog = GifGeneratorDialog(self)
        # PyQt5 / PyQt6 compatibility for exec()
        if hasattr(dialog, 'exec'):
            dialog.exec()
        else:
            dialog.exec_()

    def _take_snapshot(self):
        if self.layers.current_layer and self.api.url_list:
            date_str = self.api.url_list[self._list_pos][0]
            snap = QgsRasterLayer(self.layers.current_layer.source(), f"Snap-Satiladu_{self.combo_sensor.currentText()}_{self.combo_filter.currentText()}_{date_str}", "wms")
            if snap.isValid(): self.layers.add_layer_at_top(snap)

    def _set_secondary_actions_enabled(self, enabled: bool):
        # NOTE: self.action_calendar has been REMOVED from this list so it doesn't get toggled off
        for a in (self.action_prev, self.action_next, self.action_prev_10, self.action_next_10):
            if a: a.setEnabled(enabled)

    def _update_ui_state(self):
        # Calendar is explicitly always enabled from the get-go
        if self.action_calendar: self.action_calendar.setEnabled(True)

        is_active = bool(self.action_today.isChecked() and self.api.url_list)
        self._set_secondary_actions_enabled(is_active)
        
        try:
            layer_exists = bool(self.layers.current_layer and QgsProject.instance().mapLayer(self.layers.current_layer.id()))
        except RuntimeError:
            layer_exists = False

        can_snap = bool(layer_exists and self.action_today.isChecked())
        if self.action_snapshot: self.action_snapshot.setEnabled(can_snap)
            
        can_gif = bool(is_active and self.action_sun.isChecked())
        if self.action_gif: self.action_gif.setEnabled(can_gif)