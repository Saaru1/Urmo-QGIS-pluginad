# -*- coding: utf-8 -*-
import datetime
import shutil
import os
from qgis.PyQt.QtCore import Qt, QDate
from qgis.PyQt.QtGui import QTextCharFormat, QColor, QFont, QMovie
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QDateEdit, QComboBox, QCheckBox, QSlider, QFileDialog
)
from qgis.core import QgsApplication

from .gif_task import GifGeneratorTask

class GifGeneratorDialog(QDialog):
    def __init__(self, parent_plugin):
        super().__init__(parent_plugin.iface.mainWindow())
        self.plugin = parent_plugin
        self.api = parent_plugin.api
        self.layers = parent_plugin.layers
        self.setWindowTitle("Generate Timelapse GIF")
        self.resize(900, 750) 

        # PyQt5 / PyQt6 Dual Compatibility for Enums
        try:
            align_center = Qt.AlignmentFlag.AlignCenter
            orient_horizontal = Qt.Orientation.Horizontal
        except AttributeError:
            align_center = Qt.AlignCenter
            orient_horizontal = Qt.Horizontal

        layout = QVBoxLayout(self)

        controls_layout = QHBoxLayout()
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(10) 
        
        # Start
        controls_layout.addWidget(QLabel("Start:"))
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDisplayFormat("dd.MM.yyyy") 
        self.start_date.setMaximumDate(QDate.currentDate())
        self.start_date.dateChanged.connect(self._on_start_date_changed)
        controls_layout.addWidget(self.start_date)

        # End
        controls_layout.addWidget(QLabel("End:"))
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDisplayFormat("dd.MM.yyyy") 
        self.end_date.setMaximumDate(QDate.currentDate())
        controls_layout.addWidget(self.end_date)

        # Speed
        controls_layout.addWidget(QLabel("Speed:"))
        self.combo_speed = QComboBox()
        self.combo_speed.addItem("Slow", 1000)
        self.combo_speed.addItem("Normal", 500)
        self.combo_speed.addItem("Fast", 200)
        self.combo_speed.setCurrentIndex(1) 
        controls_layout.addWidget(self.combo_speed)

        # Smooth
        self.chk_smooth = QCheckBox("Smooth transitions")
        controls_layout.addWidget(self.chk_smooth)

        # Buttons
        self.btn_generate = QPushButton("Generate")
        self.btn_generate.clicked.connect(self._generate_gif_async)
        controls_layout.addWidget(self.btn_generate)
        
        self.btn_save = QPushButton("Save to PC")
        self.btn_save.setEnabled(False)
        self.btn_save.clicked.connect(self._save_gif)
        controls_layout.addWidget(self.btn_save)

        layout.addLayout(controls_layout)

        # GIF Display Area
        self.lbl_gif = QLabel("Select dates and click Generate.\n(GIF generates in background, no freezing!)")
        self.lbl_gif.setAlignment(align_center) # Using dynamic enum
        self.lbl_gif.setMinimumHeight(500)
        layout.addWidget(self.lbl_gif, 1) 

        # Playback Controls 
        playback_layout = QHBoxLayout()
        self.btn_play_pause = QPushButton("Pause")
        self.btn_play_pause.setEnabled(False)
        self.btn_play_pause.clicked.connect(self._toggle_playback)
        playback_layout.addWidget(self.btn_play_pause)

        self.slider_frames = QSlider(orient_horizontal) # Using dynamic enum
        self.slider_frames.setEnabled(False)
        self.slider_frames.valueChanged.connect(self._on_slider_moved)
        playback_layout.addWidget(self.slider_frames)
        
        layout.addLayout(playback_layout)

        # State Variables
        self.movie = None
        self.final_gif_disk_path = None
        self._is_user_sliding = False
        self.active_task = None

        self.start_date.dateChanged.connect(self._validate_date_range)
        self.end_date.dateChanged.connect(self._validate_date_range)

        # Smart defaults
        if self.api.url_list:
            newest_dt = datetime.date.fromisoformat(self.api.url_list[0][0])
            qnewest = QDate(newest_dt.year, newest_dt.month, newest_dt.day)
            self.start_date.blockSignals(True)
            self.end_date.blockSignals(True)
            self.start_date.setDate(qnewest.addMonths(-3))
            self.end_date.setDate(qnewest)
            self.start_date.blockSignals(False)
            self.end_date.blockSignals(False)

        self._validate_date_range()
        self._highlight_dates()

    def _highlight_dates(self):
        if not self.api.url_list: return
        fmt = QTextCharFormat()

        # PyQt5 / PyQt6 Dual Compatibility for Font Weight
        try:
            bold_weight = QFont.Weight.Bold # PyQt6
        except AttributeError:
            bold_weight = QFont.Bold        # PyQt5

        fmt.setBackground(QColor("yellow"))
        fmt.setFontWeight(bold_weight)

        for dstr, _ in self.api.url_list:
            dt = datetime.date.fromisoformat(dstr)
            qdate = QDate(dt.year, dt.month, dt.day)
            self.start_date.calendarWidget().setDateTextFormat(qdate, fmt)
            self.end_date.calendarWidget().setDateTextFormat(qdate, fmt)

    def _validate_date_range(self):
        self.start_date.setMaximumDate(self.end_date.date())
        self.end_date.setMinimumDate(self.start_date.date())

    def _on_start_date_changed(self, startDate):
        if not self.start_date.hasFocus(): return 
        proposed = startDate.addDays(30)
        if proposed > QDate.currentDate(): proposed = QDate.currentDate()
        self.end_date.blockSignals(True)
        self.end_date.setDate(proposed)
        self.end_date.blockSignals(False)
        self._validate_date_range()

    def _toggle_playback(self):
        if not self.movie: return
        if self.movie.state() == 2: 
            self.movie.setPaused(True)
            self.btn_play_pause.setText("Play")
        else:
            self.movie.setPaused(False)
            self.btn_play_pause.setText("Pause")

    def _sync_slider(self, frame_num):
        if not self._is_user_sliding:
            self.slider_frames.blockSignals(True)
            self.slider_frames.setValue(frame_num)
            self.slider_frames.blockSignals(False)

    def _on_slider_moved(self, value):
        if not self.movie: return
        self._is_user_sliding = True
        self.movie.setPaused(True)
        self.btn_play_pause.setText("Play")
        self.movie.jumpToFrame(value)
        self._is_user_sliding = False

    def _generate_gif_async(self):
        start_pydate = datetime.date(self.start_date.date().year(), self.start_date.date().month(), self.start_date.date().day())
        end_pydate = datetime.date(self.end_date.date().year(), self.end_date.date().month(), self.end_date.date().day())
        
        valid_frames = [(d, u) for d, u in self.api.url_list if start_pydate <= datetime.date.fromisoformat(d) <= end_pydate]

        if not valid_frames:
            self.lbl_gif.setText("No cloudless dates found in this range.")
            return

        valid_frames.reverse()
        
        self.lbl_gif.setText("Generating GIF in background...\nYou can keep using QGIS while it builds!")
        self.btn_generate.setEnabled(False)
        self.btn_save.setEnabled(False)

        canvas = self.plugin.iface.mapCanvas()
        bbox_3301 = self.layers.get_canvas_bbox_3301_str()
        
        aspect = canvas.height() / canvas.width()
        width = max(400, min(1200, self.lbl_gif.width()))
        height = int(width * aspect)
        if height > self.lbl_gif.height():
            height = self.lbl_gif.height()
            width = int(height / aspect)

        self.active_task = GifGeneratorTask(
            valid_frames, bbox_3301, width, height, 
            self.plugin.combo_sensor.currentText(), self.plugin.combo_filter.currentText(),
            self.combo_speed.currentData(), self.chk_smooth.isChecked(),
            self._on_task_finished 
        )
        QgsApplication.taskManager().addTask(self.active_task)

    def _on_task_finished(self, final_gif_path):
        self.btn_generate.setEnabled(True)
        
        if not final_gif_path:
            self.lbl_gif.setText("Failed to generate GIF or process was cancelled.")
            return
            
        self.final_gif_disk_path = final_gif_path

        self.movie = QMovie(self.final_gif_disk_path)
        self.lbl_gif.setMovie(self.movie)
        self.movie.start()
        
        self.btn_save.setEnabled(True)
        self.btn_play_pause.setEnabled(True)
        self.btn_play_pause.setText("Pause")
        
        self.slider_frames.setEnabled(True)
        self.slider_frames.setMinimum(0)
        self.slider_frames.setMaximum(self.movie.frameCount() - 1)
        self.movie.frameChanged.connect(self._sync_slider)

    def _save_gif(self):
        if self.final_gif_disk_path and os.path.exists(self.final_gif_disk_path):
            sensor = self.plugin.combo_sensor.currentText()
            filt = self.plugin.combo_filter.currentText()
            default_name = f"Satiladu_{sensor}_{filt}_timelapse.gif"
            
            path, _ = QFileDialog.getSaveFileName(self, "Save Timelapse", default_name, "GIF Files (*.gif)")
            if path:
                shutil.copy(self.final_gif_disk_path, path)
                self.plugin.log(f"Saved GIF to: {path}")