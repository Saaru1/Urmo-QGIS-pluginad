# -*- coding: utf-8 -*-
import re
import datetime
from urllib.parse import quote
from urllib.request import urlopen
from qgis.core import QgsMessageLog, Qgis

class SatiladuAPI:
    def __init__(self):
        self.url_list = []
        
    def log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, "SentinelWMS", level)

    def refresh_urls_list(self, bbox_str, sensor_name, toode_id, pilvitu_bool):
        if not bbox_str:
            return False

        satelliit = "L8" if sensor_name == "Landsat-8" else "S2"
        pilvitu = 1 if pilvitu_bool else 0
        
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=2*365) 

        url = (f"https://esthub.maaruum.ee/index.php?lang_id=1&page_id=1"
               f"&kuupaev_algus={start_date.isoformat()}&kuupaev_lopp={end_date.isoformat()}"
               f"&toode={toode_id}&pilvitu={pilvitu}&satelliit={satelliit}&bbox={quote(bbox_str, safe='')}")
        
        self.log(f"Scraping ESTHub index:\n{url}")

        try:
            with urlopen(url, timeout=15) as resp:
                html = resp.read().decode("utf-8", errors="replace")
                url_re = re.compile(r"(https://teenus\.maaamet\.ee/ows/wms-[\w\-]+\?date=(\d{4}-\d{2}-\d{2}))")
                matches = url_re.findall(html)
                
                if not matches:
                    self.url_list = []
                    return False
                
                unique_urls = {date_str: full_url for full_url, date_str in matches}
                sorted_dates = sorted(unique_urls.keys(), reverse=True)
                
                self.url_list = [(d, unique_urls[d]) for d in sorted_dates]
                return True
        except Exception as e:
            self.log(f"ESTHub scrape failed: {str(e)}", Qgis.Critical)
            return False