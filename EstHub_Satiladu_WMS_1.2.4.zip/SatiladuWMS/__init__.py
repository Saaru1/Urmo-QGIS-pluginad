# -*- coding: utf-8 -*-
"""
QGIS Plugin entry point for Sentinel WMS (Sentinel-2 RGB date navigation)
"""

def classFactory(iface):
    """
    Load Sentinel2Dates class from sentinel2dates.py
    :param iface: A QGIS interface instance.
    :return: Sentinel2Dates plugin instance.
    """
    from .sentinel2dates import Sentinel2Dates
    return Sentinel2Dates(iface)

