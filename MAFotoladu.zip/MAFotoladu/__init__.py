# -*- coding: utf-8 -*-

def classFactory(iface):
    from .MAFotoladu import MAFotoladu
    return MAFotoladu(iface)