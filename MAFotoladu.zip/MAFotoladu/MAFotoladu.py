# -*- coding: utf-8 -*-
import os
import math
import webbrowser

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QIcon, QDesktopServices, QCursor
try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction

from qgis.core import (
    QgsProject,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform
)
from qgis.gui import QgsMapToolEmitPoint


class FotoladuMapTool(QgsMapToolEmitPoint):
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas

        # Safe cross-version cursor (Qt5 & Qt6 enum scoping)
        if hasattr(Qt, 'CursorShape'):
            self.setCursor(QCursor(Qt.CursorShape.CrossCursor))
        else:
            self.setCursor(QCursor(Qt.CrossCursor))

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        wgs84_crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # Transform to WGS84 (lon, lat)
        transform = QgsCoordinateTransform(canvas_crs, wgs84_crs, QgsProject.instance())
        wgs_pt = transform.transform(point)
        lon = wgs_pt.x()
        lat = wgs_pt.y()

        # Approximate web map zoom level from canvas scale
        scale = self.canvas.scale()
        if scale > 0:
            zlevel = int(round(math.log2(559082264.0 / scale)))
            zlevel = max(10, min(16, zlevel))
        else:
            zlevel = 13

        url_str = f"https://fotoladu.maaamet.ee/?basemap=hybriidk&zlevel={zlevel},{lon:.6f},{lat:.6f}"
        qurl = QUrl(url_str)

        if not QDesktopServices.openUrl(qurl):
            webbrowser.open(url_str)


class MAFotoladu:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.map_tool = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Ava Fotoladus", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setStatusTip("Klõpsa kaardil, et avada asukoht Maa-ameti Fotolaos")
        self.action.triggered.connect(self.toggle_tool)

        self.map_tool = FotoladuMapTool(self.canvas)
        self.map_tool.deactivated.connect(self.tool_deactivated)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToWebMenu("MAFotoladu", self.action)

    def unload(self):
        if self.canvas.mapTool() == self.map_tool:
            self.canvas.unsetMapTool(self.map_tool)

        self.iface.removePluginWebMenu("MAFotoladu", self.action)
        self.iface.removeToolBarIcon(self.action)
        del self.action
        del self.map_tool

    def toggle_tool(self, checked):
        if checked:
            self.canvas.setMapTool(self.map_tool)
        else:
            self.canvas.unsetMapTool(self.map_tool)

    def tool_deactivated(self):
        if self.action:
            self.action.setChecked(False)