# Natura Topo Kontroll

QGIS plugin Natura elupaikade (või muude sarnaste andmestike) topoloogia kontrollimiseks.
Plugin matkib MapInfo Professional "Check Regions" käitumist (Sõlmed, Augud, Ülekatted) ja lisab EELIS WFS andmestikuga sünkroniseerimise.

## Funktsionaalsus
1. **ID-kontroll:** Võrdleb vektorkihi ja Exceli (.xlsx) tabeli ID-sid.
2. **Töökiht & WFS:** Laeb automaatselt alla naaberalad EELIS WFS-ist. Kasutab ruumilist plokk-päringut (chunking) ning toetab osalisi võrgutõrkeid.
3. **Topoloogia (Sammud 3-7):**
   - **Samm 3:** Augud (< 0.01 ha)
   - **Samm 4:** Ülekatted
   - **Samm 5:** Sõlmed (Eneselõikumised)
   - **Samm 6:** Lühikesed lõigud (< 20 mm)
   - **Samm 7:** Teravad nurgad (< 5 kraadi)

## Arendus ja Testimine
Seadete (⚙) all on võimalik genereerida sünteetilised MapInfo testandmed kalibreerimiseks.
