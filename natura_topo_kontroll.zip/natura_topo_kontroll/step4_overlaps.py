# -*- coding: utf-8 -*-
"""
Step 4 Module: Ülekatted (Overlaps matching MapInfo Check Regions).
Uses snapped coordinate grid + minimum average sliver width (W = 2*A/P) to filter
out sub-millimeter IEEE-754 floating-point boundary drift.
"""

from qgis.core import (
    QgsFeature, QgsFields, QgsWkbTypes, QgsMemoryProviderUtils
)
from .qt_compat import make_field, extract_polygon_parts


import re
import json
import copy
from qgis.PyQt.QtCore import QSettings

PLK_BASES = {"1630", "5130", "6210", "6270", "6280", "6410", "6430", "6450", "6510", "6530", "7230", "9070"}

DEFAULT_PROFILE2_RULES = [
    {"source": "3260", "allowed": "Kõik", "description": "jõed ja ojad"},
    {"source": "1620*", "allowed": "Kõik (v.a 4030)", "description": "väikesaared ja laiud"},
    {"source": "1630*", "allowed": "1110, 1130, 1140, 1150*, 1160, 1170, 1210, 1220, 1230, 1310, 1640", "description": "rannaniidud"},
    {"source": "1130, 1160", "allowed": "1110, 1140", "description": "lehtersuudmed ja lahed"},
    {"source": "1640", "allowed": "1210", "description": "liivarannad"},
    {"source": "7150", "allowed": "7110", "description": "nokkheinakooslused"},
    {"source": "8240*", "allowed": "6280*, 5130", "description": "plaatlood"},
    {"source": "5130", "allowed": "8240*, 8210", "description": "kadastikud"},
    {"source": "2130*", "allowed": "1210, 1220", "description": "hallid luited"},
    {"source": "3180*", "allowed": "Kõik PLK (v.a 6270*)", "description": "karstijärvikud"},
    {"source": "7160", "allowed": "Kõik PLK", "description": "allikad ja allikasood"},
]


def get_profile2_rules() -> list:
    """Returns currently saved Profile 2 rules from QSettings, falling back to defaults."""
    val = QSettings().value("NaturaTopoKontroll/Profile2Rules", None)
    if val:
        try:
            rules = json.loads(val)
            if isinstance(rules, list) and len(rules) > 0:
                return rules
        except Exception:
            pass
    return copy.deepcopy(DEFAULT_PROFILE2_RULES)


def save_profile2_rules(rules: list):
    """Saves user-configured Profile 2 rules to QSettings."""
    QSettings().setValue("NaturaTopoKontroll/Profile2Rules", json.dumps(rules, ensure_ascii=False))


def reset_profile2_rules():
    """Resets Profile 2 rules in QSettings back to default."""
    QSettings().remove("NaturaTopoKontroll/Profile2Rules")


def normalize_habitat_code(raw_val) -> str:
    if raw_val is None:
        return ""
    return str(raw_val).strip()


def base_code(c: str) -> str:
    return str(c).rstrip("*").strip() if c else ""


def match_pattern(code: str, pattern: str) -> bool:
    """
    Checks if habitat code matches pattern (supports 'kõik', 'PLK', exceptions 'v.a XXX', or code lists).
    """
    b = base_code(code)
    if not b:
        return False
    patt_lower = str(pattern).lower().strip()

    # Parse exceptions, e.g. '(v.a 4030)', 'va 6270*', 'except 4030'
    m_va = re.search(r'(?:v\.a\.?|va|except)\s+([^\)]+)', patt_lower)
    if m_va:
        ex_text = m_va.group(1)
        exceptions = {base_code(x) for x in re.split(r'[,;\s]+', ex_text) if x.strip()}
        if b in exceptions:
            return False

    if "kõik" in patt_lower or "all" in patt_lower or patt_lower == "*":
        return True

    if "plk" in patt_lower:
        return b in PLK_BASES

    allowed_codes = {base_code(x) for x in re.split(r'[,;\s]+', str(pattern)) if x.strip()}
    return b in allowed_codes


def is_overlap_allowed(t1: str, t2: str, rules: list = None) -> bool:
    """
    Evaluates whether two Natura habitat types (põhitüüp) are permitted to overlap
    under Profile 2 ruleset. Overlap relationship is symmetric.
    """
    if not t1 or not t2:
        return False

    c1, c2 = normalize_habitat_code(t1), normalize_habitat_code(t2)
    b1, b2 = base_code(c1), base_code(c2)

    if not b1 or not b2 or b1 == b2:
        return False

    active_rules = rules if rules is not None else get_profile2_rules()

    for r in active_rules:
        src = r.get("source", "")
        alwd = r.get("allowed", "")
        sources = {base_code(x) for x in re.split(r'[,;\s]+', str(src)) if x.strip()}

        # Check b1 in sources -> b2 in allowed
        if b1 in sources and match_pattern(b2, alwd):
            return True
        # Check b2 in sources -> b1 in allowed
        if b2 in sources and match_pattern(b1, alwd):
            return True

    return False


def run_step4_overlaps(
    snapped_geoms_dict: dict,
    obj_ids: dict,
    obj_sources: dict,
    spatial_index,
    crs,
    settings,
    obj_pohityyp: dict = None
):
    """
    Finds polygon overlaps between features and returns the 'Ülekatted' memory layer
    and count of detected overlaps.
    """
    ylekatted_fields = QgsFields()
    ylekatted_fields.append(make_field("id_loend", "string"))
    ylekatted_fields.append(make_field("pindala_m2", "double"))
    ylekatted_fields.append(make_field("pindala_ha", "double"))
    ylekatted_fields.append(make_field("keskm_laius_mm", "double"))
    ylekatted_fields.append(make_field("seotud_sisendiga", "string"))
    ylekatted_fields.append(make_field("tyybid", "string"))

    ylekatted_layer = QgsMemoryProviderUtils.createMemoryLayer(
        "Ülekatted", ylekatted_fields, QgsWkbTypes.Polygon, crs
    )
    ylekatted_pr = ylekatted_layer.dataProvider()
    ylekatted_feats = []

    fids_sorted = sorted(snapped_geoms_dict.keys())
    for fid1 in fids_sorted:
        g1 = snapped_geoms_dict[fid1]
        cands = spatial_index.intersects(g1.boundingBox())
        for fid2 in cands:
            if fid2 <= fid1:
                continue
            src1 = obj_sources[fid1]
            src2 = obj_sources[fid2]
            has_input = (src1 in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER") or 
                         src2 in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER"))

            if hasattr(settings, 'are_sources_reported'):
                if not settings.are_sources_reported([src1, src2]):
                    continue
            elif settings.only_input_related and not has_input:
                continue

            pt1 = obj_pohityyp.get(fid1, "") if obj_pohityyp else ""
            pt2 = obj_pohityyp.get(fid2, "") if obj_pohityyp else ""

            # Profile 2 filter: ignore allowed habitat overlaps
            if getattr(settings, 'active_profile', 1) == 2:
                rules = getattr(settings, 'profile2_rules', None)
                if is_overlap_allowed(pt1, pt2, rules=rules):
                    continue

            g2 = snapped_geoms_dict[fid2]
            if not g1.intersects(g2):
                continue

            inter = g1.intersection(g2)
            for poly_part in extract_polygon_parts(inter):
                area_m2 = poly_part.area()
                if area_m2 < settings.min_overlap_area_m2:
                    continue
                perim_m = poly_part.length()
                avg_width_m = (2.0 * area_m2 / perim_m) if perim_m > 0 else 0.0
                if avg_width_m < settings.min_overlap_width_m:
                    continue

                of = QgsFeature(ylekatted_fields)
                of.setGeometry(poly_part)
                of["id_loend"] = f"{obj_ids[fid1]} / {obj_ids[fid2]}"
                of["pindala_m2"] = round(area_m2, 4)
                of["pindala_ha"] = round(area_m2 / 10000.0, 4)
                of["keskm_laius_mm"] = round(avg_width_m * 1000.0, 2)
                of["seotud_sisendiga"] = "Jah" if has_input else "Ei"
                of["tyybid"] = f"{pt1} / {pt2}" if (pt1 or pt2) else ""
                ylekatted_feats.append(of)

    ylekatted_pr.addFeatures(ylekatted_feats)
    ylekatted_layer.updateExtents()
    return ylekatted_layer, len(ylekatted_feats)
