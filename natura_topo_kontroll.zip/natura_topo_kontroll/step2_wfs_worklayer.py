# -*- coding: utf-8 -*-
"""
Step 2 Module:
- Downloads features from EELIS WFS (eelis:natura_elupaik) that intersect with input layer
- Deduplicates downloaded WFS features by ID
- Deletes WFS features that match input layer IDs
- Copies input layer features onto the WFS download to create 'Töökiht' (Work Layer)
- Styles 'Töökiht' with two categories:
    * 'Naabrid' (WFS intersecting polygons): Yellow, opacity 60%
    * 'Paranduste kiht' (Replaced/input layer polygons): Light blue, opacity 50%
"""

import os
import tempfile
import requests
from urllib.parse import urlparse, parse_qs, urlunparse

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsFields,
    QgsWkbTypes, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsMemoryProviderUtils, QgsSymbol, QgsRendererCategory,
    QgsCategorizedSymbolRenderer, QgsFeatureRequest
)
from qgis.PyQt.QtGui import QColor

from .qt_compat import make_field
from .step1_id_check import normalize_id_value, COMMON_ID_NAMES

DEFAULT_WFS_URL = (
    "https://gsavalik.envir.ee/geoserver/eelis/ows?"
    "service=WFS&version=2.0.0&request=GetFeature&"
    "typeName=eelis:natura_elupaik&outputFormat=application/json&SRSNAME=EPSG:3301"
)


def split_wfs_url(full_url: str):
    parsed = urlparse(full_url)
    base_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
    query = parse_qs(parsed.query)
    type_name = query.get("typeName", query.get("typename", [None]))[0]
    srs = query.get("SRSNAME", query.get("srsname", ["EPSG:3301"]))[0]
    output_format = query.get("outputFormat", ["application/json"])[0]
    return base_url, type_name, srs, output_format


def style_work_layer(work_layer, is_repaired: bool = None):
    """
    Styles 'Töökiht' using QgsCategorizedSymbolRenderer on '_allikas'.
    Dynamically adds categories according to features present in the layer.
    Before fixes: 'Naabrid', 'Sisendkiht'.
    After fixes: 'Naabrid (muutmata)', 'Sisendkiht (muutmata / ei vajanud parandust)', plus repaired categories.
    """
    try:
        existing_sources = set()
        for f in work_layer.getFeatures():
            try:
                val = f["_allikas"]
                if val is not None:
                    existing_sources.add(str(val))
            except Exception:
                pass

        if is_repaired is None:
            has_fixes = bool(existing_sources & {"PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER"})
        else:
            has_fixes = is_repaired

        wfs_label = "Naabrid (muutmata)" if has_fixes else "Naabrid"
        sisend_label = "Sisendkiht (muutmata / ei vajanud parandust)" if has_fixes else "Sisendkiht"

        categories = []
        
        # 1. WFS -> Naabrid (Kollane)
        if "WFS" in existing_sources or not existing_sources:
            sym_neighbors = QgsSymbol.defaultSymbol(work_layer.geometryType())
            sym_neighbors.setColor(QColor(255, 235, 59))
            sym_neighbors.setOpacity(0.60)
            cat_neighbors = QgsRendererCategory("WFS", sym_neighbors, wfs_label)
            categories.append(cat_neighbors)

        # 2. SISEND -> Sisendkiht (Helesinine)
        if "SISEND" in existing_sources or not existing_sources:
            sym_input = QgsSymbol.defaultSymbol(work_layer.geometryType())
            sym_input.setColor(QColor(100, 181, 246))
            sym_input.setOpacity(0.50)
            cat_input = QgsRendererCategory("SISEND", sym_input, sisend_label)
            categories.append(cat_input)

        # 3. PARANDATUD_SISEND -> Parandatud sisendkiht (Oranž)
        if "PARANDATUD_SISEND" in existing_sources:
            sym_fixed_in = QgsSymbol.defaultSymbol(work_layer.geometryType())
            sym_fixed_in.setColor(QColor(249, 115, 22))
            sym_fixed_in.setOpacity(0.60)
            if sym_fixed_in.symbolLayerCount() > 0:
                sym_fixed_in.symbolLayer(0).setStrokeColor(QColor(194, 65, 12))
                sym_fixed_in.symbolLayer(0).setStrokeWidth(0.45)
            cat_fixed_in = QgsRendererCategory("PARANDATUD_SISEND", sym_fixed_in, "Parandatud sisendkiht (piirid ja ülekatted)")
            categories.append(cat_fixed_in)

        # 4. PARANDATUD_GEOM -> Parandatud sisendkiht (augutäide) (Roheline)
        if "PARANDATUD_GEOM" in existing_sources:
            sym_fixed_geom = QgsSymbol.defaultSymbol(work_layer.geometryType())
            sym_fixed_geom.setColor(QColor(34, 197, 94))   # green — gap-filled
            sym_fixed_geom.setOpacity(0.60)
            if sym_fixed_geom.symbolLayerCount() > 0:
                sym_fixed_geom.symbolLayer(0).setStrokeColor(QColor(21, 128, 61))
                sym_fixed_geom.symbolLayer(0).setStrokeWidth(0.45)
            cat_fixed_geom = QgsRendererCategory("PARANDATUD_GEOM", sym_fixed_geom, "Parandatud sisendkiht (augutäide)")
            categories.append(cat_fixed_geom)

        # 5. PARANDATUD_NAABER -> Parandatud naabrid (WFS) (Lilla)
        if "PARANDATUD_NAABER" in existing_sources:
            sym_fixed_wfs = QgsSymbol.defaultSymbol(work_layer.geometryType())
            sym_fixed_wfs.setColor(QColor(156, 39, 176))
            sym_fixed_wfs.setOpacity(0.60)
            if sym_fixed_wfs.symbolLayerCount() > 0:
                sym_fixed_wfs.symbolLayer(0).setStrokeColor(QColor(106, 27, 154))
                sym_fixed_wfs.symbolLayer(0).setStrokeWidth(0.45)
            cat_fixed_wfs = QgsRendererCategory("PARANDATUD_NAABER", sym_fixed_wfs, "Parandatud naabrid (WFS)")
            categories.append(cat_fixed_wfs)

        renderer = QgsCategorizedSymbolRenderer("_allikas", categories)
        work_layer.setRenderer(renderer)
        work_layer.triggerRepaint()
    except Exception:
        pass


def run_step2_build_work_layer(
    input_layer,
    input_id_field: str,
    wfs_url: str = DEFAULT_WFS_URL,
    wfs_id_field_override: str = "",
    neighbor_buffer_m: float = 5.0,
    offline_wfs_layer=None,
    progress_callback=None,
    added_wfs_ids=None,
    xlsx_rows=None,
    xlsx_id_field=None
) -> dict:
    """
    Downloads intersecting WFS features (no duplicates by ID), removes WFS features
    matching input layer IDs, inserts input layer features into 'Töökiht',
    and applies categorized styling ('Naabrid' & 'Paranduste kiht').
    """
    def _report(pct, msg=""):
        if progress_callback:
            try:
                progress_callback(pct, msg)
            except TypeError:
                progress_callback(pct)

    _report(5, "Sisendkihi geomeetriate ettevalmistamine...")
    target_crs = QgsCoordinateReferenceSystem("EPSG:3301")
    source_crs = input_layer.crs()
    transform_to_3301 = None
    if source_crs.isValid() and source_crs != target_crs:
        transform_to_3301 = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())

    input_features_3301 = []
    input_ids_set = set()
    input_ids_stripped_num = set()
    input_union_geoms = []

    for feat in input_layer.getFeatures():
        geom = QgsGeometry(feat.geometry())
        if geom.isNull() or geom.isEmpty():
            continue
        if transform_to_3301:
            geom.transform(transform_to_3301)
        norm_id = normalize_id_value(feat[input_id_field])
        if norm_id:
            input_ids_set.add(norm_id)
            if norm_id.isdigit():
                input_ids_stripped_num.add(norm_id.lstrip("0") or "0")
        input_features_3301.append((norm_id, geom, feat))
        search_geom = geom.buffer(neighbor_buffer_m, 5) if neighbor_buffer_m > 0 else geom
        input_union_geoms.append(search_geom)

    if not input_features_3301:
        raise RuntimeError("Sisendkihil puuduvad kehtivad geomeetriad.")

    search_mask_geom = QgsGeometry.unaryUnion(input_union_geoms)
    search_engine = QgsGeometry.createGeometryEngine(search_mask_geom.constGet())
    search_engine.prepareGeometry()

    raw_wfs_features = []
    wfs_fields = QgsFields()

    if offline_wfs_layer and offline_wfs_layer.isValid():
        _report(15, "Naabrite lugemine kohalikust (offline) WFS kihist...")
        wfs_fields = offline_wfs_layer.fields()
        wfs_crs = offline_wfs_layer.crs()
        tf_wfs = None
        filter_box = search_mask_geom.boundingBox()
        if wfs_crs.isValid() and wfs_crs != target_crs:
            tf_wfs = QgsCoordinateTransform(wfs_crs, target_crs, QgsProject.instance())
            tf_inv = QgsCoordinateTransform(target_crs, wfs_crs, QgsProject.instance())
            filter_box = tf_inv.transformBoundingBox(filter_box)

        # High-performance spatial filtering on the offline layer
        req = QgsFeatureRequest().setFilterRect(filter_box)
        for feat in offline_wfs_layer.getFeatures(req):
            g = QgsGeometry(feat.geometry())
            if tf_wfs:
                g.transform(tf_wfs)
            f_copy = QgsFeature(feat)
            f_copy.setGeometry(g)
            raw_wfs_features.append(f_copy)
        _report(55, f"Offline kihist leitud {len(raw_wfs_features)} potentsiaalset naabrit.")
    else:
        base_url, type_name, srs, output_format = split_wfs_url(wfs_url)
        
        # CHUNKING: Calculate total bounds and divide into 2x2 km blocks
        ext = search_mask_geom.boundingBox()
        grid_size = 2000.0
        x_min, x_max = ext.xMinimum(), ext.xMaximum()
        y_min, y_max = ext.yMinimum(), ext.yMaximum()
        
        x_coords = []
        cx = x_min
        while cx < x_max:
            x_coords.append(cx)
            cx += grid_size
        x_coords.append(x_max)
        
        y_coords = []
        cy = y_min
        while cy < y_max:
            y_coords.append(cy)
            cy += grid_size
        y_coords.append(y_max)
        
        blocks = []
        from qgis.core import QgsRectangle
        for i in range(len(x_coords)-1):
            for j in range(len(y_coords)-1):
                rect = QgsRectangle(x_coords[i], y_coords[j], x_coords[i+1], y_coords[j+1])
                rect_geom = QgsGeometry.fromRect(rect)
                if search_engine.intersects(rect_geom.constGet()):
                    blocks.append(rect)
        
        total_blocks = len(blocks)
        failed_requests = []
        successful_requests = 0

        for idx, block_rect in enumerate(blocks):
            pct = int(10 + (idx / max(1, total_blocks)) * 50)
            _report(pct, f"WFS päringud ({idx + 1}/{total_blocks})...")
            
            # Grow slightly to ensure overlaps at borders
            block_rect.grow(max(neighbor_buffer_m, 2.0))
            bbox_str = f"{block_rect.xMinimum()},{block_rect.yMinimum()},{block_rect.xMaximum()},{block_rect.yMaximum()}"
            query_params = {
                "service": "WFS",
                "version": "2.0.0",
                "request": "GetFeature",
                "typeName": type_name,
                "outputFormat": output_format,
                "SRSNAME": srs,
                "bbox": f"{bbox_str},{srs}",
            }
            try:
                resp = requests.get(base_url, params=query_params, timeout=(10, 60))
                resp.raise_for_status()
                successful_requests += 1
            except requests.RequestException as exc:
                failed_requests.append({"bbox": bbox_str, "error": str(exc)})
                continue
                
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".geojson")
            tmp_path = tmp.name
            tmp.close()
            try:
                with open(tmp_path, "w", encoding="utf-8") as f:
                    f.write(resp.text)
                tmp_lyr = QgsVectorLayer(tmp_path, f"wfs_part_{idx}", "ogr")
                if tmp_lyr.isValid():
                    if wfs_fields.count() == 0:
                        wfs_fields = tmp_lyr.fields()
                    for wf in tmp_lyr.getFeatures():
                        raw_wfs_features.append(QgsFeature(wf))
            finally:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        
        if failed_requests and successful_requests == 0:
            raise RuntimeError("Kõik WFS päringud ebaõnnestusid. Kontrolli võrguühendust või EELIS teenust.")

    wfs_field_names = [f.name() for f in wfs_fields]
    wfs_field_map = {f.name().lower(): f.name() for f in wfs_fields}
    wfs_id_field = None

    # 1. Explicit override from caller
    if wfs_id_field_override and wfs_id_field_override.lower() in wfs_field_map:
        wfs_id_field = wfs_field_map[wfs_id_field_override.lower()]

    # 2. Case-insensitive match with input_id_field (e.g. MapInfo 'ID' vs WFS 'id')
    elif input_id_field and input_id_field.lower() in wfs_field_map:
        wfs_id_field = wfs_field_map[input_id_field.lower()]

    # 3. Known primary WFS ID fields (natura_elupaik has 'id', 'sys_id', 'gml_id', 'kr_kood', 'fid')
    if not wfs_id_field:
        for cand in ("id", "sys_id", "gml_id", "fid", "kr_kood"):
            if cand in wfs_field_map:
                wfs_id_field = wfs_field_map[cand]
                break

    # 4. Common ID names (e.g. 'obj_id', 'tunnus', 'kood')
    if not wfs_id_field:
        for cand in COMMON_ID_NAMES:
            if cand.lower() in wfs_field_map:
                wfs_id_field = wfs_field_map[cand.lower()]
                break

    # 5. Fallback: only if still not found, evaluate overlap on candidate fields
    # Exclude percentage (_p), dates (_kpv, date), and text fields
    if not wfs_id_field:
        best_wf_col = None
        best_wf_hits = 0
        for wf_name in wfs_field_names:
            wf_lower = wf_name.lower()
            if (
                wf_lower.endswith("_p")
                or wf_lower.endswith("_kpv")
                or wf_lower.endswith("_date")
                or any(k in wf_lower for k in ("markus", "kirjeldus", "selgitus", "isik", "kpv", "pindala", "pikkus"))
            ):
                continue
            sample_vals = [normalize_id_value(wf[wf_name]) for wf in raw_wfs_features[:100]]
            sample_set = set([v for v in sample_vals if v])
            if len(sample_set) < 5 or (len(sample_set) / max(1, len(sample_vals))) < 0.25:
                continue

            hits = 0
            for v in sample_set:
                if v in input_ids_set or (v.isdigit() and (v.lstrip("0") or "0") in input_ids_stripped_num):
                    hits += 1
            if hits > best_wf_hits:
                best_wf_hits = hits
                best_wf_col = wf_name

        if best_wf_col:
            wfs_id_field = best_wf_col
        elif wfs_field_names:
            wfs_id_field = wfs_field_names[0]

    _report(65, "Naabrite ruumiline lõikumine ja filtreerimine...")
    dedup_wfs = []
    seen_wfs_keys = set()
    replaced_wfs_ids = []
    wfs_cache = {}

    total_raw = len(raw_wfs_features)
    for idx, wf in enumerate(raw_wfs_features):
        if total_raw > 100 and idx % 50 == 0:
            sub_pct = int(65 + (idx / total_raw) * 15)
            _report(sub_pct, f"Ruumiline analüüs ({idx}/{total_raw})...")
        g = wf.geometry()
        if g.isNull() or g.isEmpty():
            continue
        if not search_engine.intersects(g.constGet()):
            continue

        wf_id_val = ""
        if wfs_id_field and wfs_id_field in wfs_field_names:
            wf_id_val = normalize_id_value(wf[wfs_id_field])
        if not wf_id_val and "gml_id" in wfs_field_names:
            wf_id_val = normalize_id_value(wf["gml_id"])
        if not wf_id_val:
            wf_id_val = f"wfs_geom_{hash(g.asWkt(3))}"

        # Cache WFS attributes before dedup/replacement
        wf_pt = ""
        for w_cand in ("pohityyp", "POHITYYP", "elupaigatyyp"):
            if w_cand in wfs_field_names and wf[w_cand] is not None:
                val = str(wf[w_cand]).strip()
                if val and val.lower() != "none":
                    wf_pt = val
                    break
        wf_kr = ""
        for w_cand in ("kr_kood", "KR_KOOD"):
            if w_cand in wfs_field_names and wf[w_cand] is not None:
                val = str(wf[w_cand]).strip()
                if val and val.lower() != "none":
                    wf_kr = val
                    break
        if wf_id_val:
            wfs_cache[wf_id_val] = {"pohityyp": wf_pt, "kr_kood": wf_kr}

        if wf_id_val in seen_wfs_keys:
            continue
        seen_wfs_keys.add(wf_id_val)

        is_matching_input = (
            wf_id_val in input_ids_set
            or (wf_id_val.isdigit() and (wf_id_val.lstrip("0") or "0") in input_ids_stripped_num)
        )
        if is_matching_input:
            replaced_wfs_ids.append(wf_id_val)
            continue

        dedup_wfs.append((wf_id_val, g, wf))

    _report(82, "Töökihi objektide genereerimine...")
    # Parse pohityyp and kr_kood lookup from Excel if rows were provided
    xlsx_lookup = {}
    if xlsx_rows:
        pt_col = None
        kr_col = None
        if len(xlsx_rows) > 0:
            first_row = xlsx_rows[0]
            for col_name in first_row.keys():
                col_l = str(col_name).lower()
                if not pt_col and any(k in col_l for k in ("elupaigatüüp", "elupaigatyyp", "natura kood", "põhitüüp", "pohityyp")):
                    pt_col = col_name
                if not kr_col and any(k in col_l for k in ("pän", "pan", "kr_kood", "pärandniit")):
                    kr_col = col_name

        for r in xlsx_rows:
            id_val = None
            if xlsx_id_field and xlsx_id_field in r:
                id_val = normalize_id_value(r[xlsx_id_field])
            else:
                for k in r.keys():
                    if any(sub in str(k).lower() for sub in ("id", "kood", "number")):
                        id_val = normalize_id_value(r[k])
                        if id_val:
                            break
            if not id_val:
                continue

            pt_val = str(r.get(pt_col)).strip() if pt_col and r.get(pt_col) is not None else ""
            kr_val = str(r.get(kr_col)).strip() if kr_col and r.get(kr_col) is not None else ""
            if pt_val.lower() == "none":
                pt_val = ""
            if kr_val.lower() == "none":
                kr_val = ""

            xlsx_lookup[id_val] = {
                "pohityyp": pt_val,
                "kr_kood": kr_val
            }

    work_fields = QgsFields()
    work_fields.append(make_field("_kontroll_id", "string"))
    work_fields.append(make_field("_allikas", "string"))

    # Map fields by name only if types are compatible; convert incompatible types to safe values
    existing_names = {"_kontroll_id", "_allikas"}
    field_defs = {}
    for f in input_layer.fields():
        if f.name() not in existing_names:
            work_fields.append(f)
            existing_names.add(f.name())
            field_defs[f.name()] = f
    for f in wfs_fields:
        if f.name() not in existing_names:
            work_fields.append(f)
            existing_names.add(f.name())
            field_defs[f.name()] = f

    # Ensure pohityyp and kr_kood fields are always present in Töökiht
    if "pohityyp" not in existing_names:
        work_fields.append(make_field("pohityyp", "string"))
        existing_names.add("pohityyp")
    if "kr_kood" not in existing_names:
        work_fields.append(make_field("kr_kood", "string"))
        existing_names.add("kr_kood")

    work_layer = QgsMemoryProviderUtils.createMemoryLayer(
        "Töökiht", work_fields, QgsWkbTypes.MultiPolygon, target_crs
    )
    pr = work_layer.dataProvider()
    new_features = []

    for wf_id_val, g, wf in dedup_wfs:
        nf = QgsFeature(work_fields)
        g_multi = QgsGeometry(g)
        g_multi.convertToMultiType()
        nf.setGeometry(g_multi)
        nf["_kontroll_id"] = wf_id_val
        nf["_allikas"] = "WFS"
        for f in wfs_fields:
            fname = f.name()
            if fname in existing_names:
                try:
                    val = wf[fname]
                    if val is not None and str(val).strip() != "":
                        nf[fname] = val
                except Exception:
                    pass

        # Explicitly ensure pohityyp and kr_kood are populated from WFS
        for w_cand in ("pohityyp", "POHITYYP", "elupaigatyyp"):
            if w_cand in wf.fields().names() and wf[w_cand] is not None:
                val = str(wf[w_cand]).strip()
                if val and val.lower() != "none":
                    nf["pohityyp"] = val
                    break
        for w_cand in ("kr_kood", "KR_KOOD"):
            if w_cand in wf.fields().names() and wf[w_cand] is not None:
                val = str(wf[w_cand]).strip()
                if val and val.lower() != "none":
                    nf["kr_kood"] = val
                    break

        # Check if Excel has pohityyp or kr_kood for this WFS id (prefer Excel if provided)
        x_info = xlsx_lookup.get(wf_id_val, {})
        if x_info.get("pohityyp"):
            nf["pohityyp"] = x_info["pohityyp"]
        if x_info.get("kr_kood"):
            nf["kr_kood"] = x_info["kr_kood"]

        new_features.append(nf)

    for norm_id, g, inf in input_features_3301:
        nf = QgsFeature(work_fields)
        g_multi = QgsGeometry(g)
        g_multi.convertToMultiType()
        nf.setGeometry(g_multi)
        nf["_kontroll_id"] = norm_id if norm_id else f"sisend_{inf.id()}"
        
        # Säilitame olemasoleva allika, kui see on juba parandatud Töökiht
        existing_allikas = "SISEND"
        try:
            val = inf.attribute("_allikas")
            if val in ("PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER"):
                existing_allikas = val
        except (KeyError, Exception):
            pass
        if added_wfs_ids and norm_id in [str(x) for x in added_wfs_ids]:
            existing_allikas = "PARANDATUD_NAABER"
        nf["_allikas"] = existing_allikas
        
        for f in input_layer.fields():
            fname = f.name()
            if fname in existing_names and fname not in ("_kontroll_id", "_allikas"):
                try:
                    val = inf[fname]
                    if val is not None and str(val).strip() != "":
                        nf[fname] = val
                except Exception:
                    pass

        # Merge in pohityyp and kr_kood (Priority: Excel -> Input layer -> WFS cache)
        x_info = xlsx_lookup.get(norm_id, {})
        if x_info.get("pohityyp"):
            nf["pohityyp"] = x_info["pohityyp"]
        elif not nf["pohityyp"] and norm_id in wfs_cache and wfs_cache[norm_id].get("pohityyp"):
            nf["pohityyp"] = wfs_cache[norm_id]["pohityyp"]

        # If pohityyp still empty, inspect input layer attributes directly
        if not nf["pohityyp"]:
            for cand_fld in input_layer.fields():
                cf_l = cand_fld.name().lower()
                if any(k in cf_l for k in ("elupaigatüüp", "elupaigatyyp", "natura_koo", "natura_kood", "põhitüüp", "pohityyp")):
                    try:
                        val = inf[cand_fld.name()]
                        if val is not None and str(val).strip() != "":
                            nf["pohityyp"] = str(val).strip()
                            break
                    except Exception:
                        pass

        if x_info.get("kr_kood"):
            nf["kr_kood"] = x_info["kr_kood"]
        elif not nf["kr_kood"] and norm_id in wfs_cache and wfs_cache[norm_id].get("kr_kood"):
            nf["kr_kood"] = wfs_cache[norm_id]["kr_kood"]

        new_features.append(nf)

    pr.addFeatures(new_features)
    work_layer.updateExtents()

    # Apply requested Categorized symbology ('Naabrid' yellow 60%, 'Paranduste kiht' light blue 50%)
    _report(95, "Töökihi sümboloogia rakendamine...")
    style_work_layer(work_layer, is_repaired=False)

    _report(100, "Töökiht valmis!")

    return {
        "work_layer": work_layer,
        "wfs_downloaded_count": len(seen_wfs_keys),
        "wfs_replaced_count": len(replaced_wfs_ids),
        "wfs_replaced_ids": sorted(replaced_wfs_ids),
        "wfs_kept_count": len(dedup_wfs),
        "input_inserted_count": len(input_features_3301),
        "total_work_features": work_layer.featureCount(),
        "wfs_id_field_used": wfs_id_field or "(automaatne)",
        "failed_requests": failed_requests if not (offline_wfs_layer and offline_wfs_layer.isValid()) else [],
    }
