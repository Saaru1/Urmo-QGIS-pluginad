# -*- coding: utf-8 -*-
"""
Topology Coordinator Module (Steps 3 to 7):
- Holds MapInfoTopologySettings
- Builds spatial index and snapped geometry caches
- Invokes step3_gaps, step4_overlaps, step5_intersections, step6_7_segments_angles
- Applies cartographic styling to the 5 output layers
"""

from qgis.core import (
    QgsGeometry, QgsSpatialIndex, QgsSymbol, QgsSingleSymbolRenderer
)
from qgis.PyQt.QtGui import QColor

from .step1_id_check import normalize_id_value
from .step3_gaps import run_step3_gaps
from .step4_overlaps import run_step4_overlaps
from .step5_intersections import run_step5_intersections
from .step6_7_segments_angles import run_step6_and_7_segments_angles


class MapInfoTopologySettings:
    """
    Tunable parameters to calibrate QGIS (GEOS 64-bit float) to match
    MapInfo Professional 'Objects -> Check Regions' (integer snap grid).
    """
    def __init__(
        self,
        snap_grid_m: float = 0.001,          # 1.0 mm MapInfo coordinate grid emulation
        max_gap_area_ha: float = 0.01,       # Step 3: 0.01 ha = 100.0 m2
        min_gap_area_m2: float = 0.0005,     # Ignore sub-0.5 cm2 float noise
        min_overlap_area_m2: float = 0.0001, # Step 4: 1 cm2 minimum area
        min_overlap_width_m: float = 0.001,  # Step 4: 1.0 mm minimum average sliver thickness (2*A/P)
        short_segment_mm: float = 20.0,      # Step 6: < 20.0 mm
        small_angle_deg: float = 5.0,        # Step 7: < 5.0 degrees
        only_input_related: bool = True,     # Backwards compatibility
        error_reporting_mode: int = 2,       # 1: Täisaruanne, 2: Töödeldud kiht (sisend+L2 naabrid, Vaikimisi), 3: Ainult algne sisend
        active_profile: int = 1              # 1: Tavaline (kõik vead), 2: Lubatud kattuvused (PLK reeglid)
    ):
        self.snap_grid_m = snap_grid_m
        self.max_gap_area_ha = max_gap_area_ha
        self.min_gap_area_m2 = min_gap_area_m2
        self.min_overlap_area_m2 = min_overlap_area_m2
        self.min_overlap_width_m = min_overlap_width_m
        self.short_segment_mm = short_segment_mm
        self.small_angle_deg = small_angle_deg
        self.error_reporting_mode = error_reporting_mode
        self.only_input_related = (error_reporting_mode in (2, 3)) if only_input_related else False
        self.active_profile = active_profile

    def is_source_reported(self, source: str) -> bool:
        """
        Determines if single-feature error (knots, short segment, sharp angle) should be reported.
        Mode 1: All features (even unedited WFS).
        Mode 2 (Default): Processed layer features (SISEND, PARANDATUD_SISEND, PARANDATUD_GEOM, PARANDATUD_NAABER).
        Mode 3: Strictly original input features (SISEND, PARANDATUD_SISEND, PARANDATUD_GEOM).
        """
        if self.error_reporting_mode == 1 or not self.only_input_related:
            return True
        if self.error_reporting_mode == 2:
            return source in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER")
        return source in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM")

    def are_sources_reported(self, sources_list) -> bool:
        """
        Determines if relational error (gap or overlap between features) should be reported.
        Mode 1: All relationships.
        Mode 2 (Default): At least one feature is in processed layer (SISEND, PARANDATUD_SISEND, PARANDATUD_GEOM, PARANDATUD_NAABER).
        Mode 3: At least one feature is strictly an ORIGINAL input feature (SISEND, PARANDATUD_SISEND, PARANDATUD_GEOM).
        """
        if self.error_reporting_mode == 1 or not self.only_input_related:
            return True
        if self.error_reporting_mode == 2:
            return any(s in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER") for s in sources_list)
        return any(s in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM") for s in sources_list)


def style_result_layers(augud_lyr, ylekatted_lyr, solmed_lyr, loigud_lyr, nurgad_lyr):
    """Applies high-contrast styles to the 5 topology result layers."""
    try:
        s_augud = QgsSymbol.defaultSymbol(augud_lyr.geometryType())
        s_augud.setColor(QColor(217, 70, 239, 130))
        if s_augud.symbolLayerCount() > 0:
            s_augud.symbolLayer(0).setStrokeColor(QColor(162, 28, 175))
            s_augud.symbolLayer(0).setStrokeWidth(0.8)
        augud_lyr.setRenderer(QgsSingleSymbolRenderer(s_augud))

        s_yle = QgsSymbol.defaultSymbol(ylekatted_lyr.geometryType())
        s_yle.setColor(QColor(239, 68, 68, 140))
        if s_yle.symbolLayerCount() > 0:
            s_yle.symbolLayer(0).setStrokeColor(QColor(185, 28, 28))
            s_yle.symbolLayer(0).setStrokeWidth(0.8)
        ylekatted_lyr.setRenderer(QgsSingleSymbolRenderer(s_yle))

        s_solm = QgsSymbol.defaultSymbol(solmed_lyr.geometryType())
        s_solm.setColor(QColor(220, 38, 38))
        s_solm.setSize(3.6)
        solmed_lyr.setRenderer(QgsSingleSymbolRenderer(s_solm))

        s_loik = QgsSymbol.defaultSymbol(loigud_lyr.geometryType())
        s_loik.setColor(QColor(249, 115, 22))
        s_loik.setWidth(1.4)
        loigud_lyr.setRenderer(QgsSingleSymbolRenderer(s_loik))

        s_nurk = QgsSymbol.defaultSymbol(nurgad_lyr.geometryType())
        s_nurk.setColor(QColor(234, 179, 8))
        s_nurk.setSize(3.4)
        nurgad_lyr.setRenderer(QgsSingleSymbolRenderer(s_nurk))
    except Exception:
        pass


def run_steps_3_to_7_topology(work_layer, id_field_name: str = "_kontroll_id", settings=None, progress_callback=None) -> dict:
    """
    Executes Steps 3, 4, 5, 6, and 7 on work_layer and returns memory layers + counts.
    """
    def _report(pct, msg=""):
        if progress_callback:
            try:
                progress_callback(pct, msg)
            except TypeError:
                progress_callback(pct)

    _report(10, "Ettevalmistus ja ruumiindeksi loomine...")
    if settings is None:
        settings = MapInfoTopologySettings()

    crs = work_layer.crs()
    field_names = [f.name() for f in work_layer.fields()]
    use_id_field = id_field_name if id_field_name in field_names else (field_names[0] if field_names else "")
    has_source_field = "_allikas" in field_names

    geoms_dict = {}
    snapped_geoms_dict = {}
    obj_ids = {}
    obj_sources = {}
    obj_pohityyp = {}
    spatial_index = QgsSpatialIndex()

    for feat in work_layer.getFeatures():
        g = feat.geometry()
        if g is None or g.isNull() or g.isEmpty():
            continue
        fid = feat.id()
        geoms_dict[fid] = QgsGeometry(g)
        if settings.snap_grid_m > 0:
            sg = g.snappedToGrid(settings.snap_grid_m, settings.snap_grid_m)
            snapped_geoms_dict[fid] = sg if not sg.isNull() and not sg.isEmpty() else QgsGeometry(g)
        else:
            snapped_geoms_dict[fid] = QgsGeometry(g)

        oid = normalize_id_value(feat[use_id_field]) if use_id_field else str(fid)
        obj_ids[fid] = oid if oid else f"FID_{fid}"
        obj_sources[fid] = str(feat["_allikas"]) if has_source_field else "SISEND"

        pt = ""
        for pt_name in ("pohityyp", "POHITYYP", "elupaigatyyp"):
            if pt_name in field_names and feat[pt_name] is not None:
                v = str(feat[pt_name]).strip()
                if v and v.lower() != "none":
                    pt = v
                    break
        obj_pohityyp[fid] = pt

        spatial_index.addFeature(feat)

    _report(25, "Samm 3: Aukude analüüs...")
    augud_layer, augud_cnt = run_step3_gaps(
        snapped_geoms_dict, obj_ids, obj_sources, spatial_index, crs, settings
    )

    _report(50, "Samm 4: Ülekatete analüüs...")
    ylekatted_layer, ylekatted_cnt = run_step4_overlaps(
        snapped_geoms_dict, obj_ids, obj_sources, spatial_index, crs, settings, obj_pohityyp=obj_pohityyp
    )

    _report(70, "Samm 5: Sõlmede ja eneselõikumiste kontroll...")
    solmed_layer, solmed_cnt = run_step5_intersections(
        geoms_dict, obj_ids, obj_sources, crs, settings
    )

    _report(85, "Sammud 6 ja 7: Lühikeste lõikude ja nurkade kontroll...")
    loigud_layer, loigud_cnt, nurgad_layer, nurgad_cnt = run_step6_and_7_segments_angles(
        geoms_dict, obj_ids, obj_sources, crs, settings
    )

    _report(95, "Tulemuste kihtide kujundamine...")
    style_result_layers(augud_layer, ylekatted_layer, solmed_layer, loigud_layer, nurgad_layer)

    _report(100, "Topoloogiakontroll edukalt sooritatud!")

    return {
        "layers": {
            "Augud": augud_layer,
            "Ülekatted": ylekatted_layer,
            "Sõlmed": solmed_layer,
            "Lühikesed lõigud": loigud_layer,
            "Teravad nurgad": nurgad_layer,
        },
        "counts": {
            "Augud": augud_cnt,
            "Ülekatted": ylekatted_cnt,
            "Sõlmed": solmed_cnt,
            "Lühikesed lõigud": loigud_cnt,
            "Teravad nurgad": nurgad_cnt,
        }
    }
