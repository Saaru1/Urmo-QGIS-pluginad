# -*- coding: utf-8 -*-
"""
Step 1 Module:
- Multi-sheet Excel (.xlsx) workbook reader (openpyxl, pandas, or QGIS OGR provider)
- Smart header detection for formatted Excel Tables
- Robust ID normalization for non-text values (int, float, Decimal, QVariant, trailing .00)
- Smart Sheet + ID column auto-detection across all worksheets
- Bidirectional ID validation (ignoring blank/empty ID rows in formatted Excel tables)
"""

import re
import math
from decimal import Decimal
from qgis.core import QgsVectorLayer

COMMON_ID_NAMES = [
    "id", "sys_id", "obj_id", "objekti_id", "elupaik_id", "natura_id", "kood",
    "code", "nr", "number", "tunnus", "fid", "gid", "uuid", "globalid",
    "orig_id", "kirje_id", "järjekorranumber", "jrknr", "jrk_nr", "jrk",
    "ala_id", "polygon_id", "loendur"
]

def get_field_id_name_score(name: str) -> float:
    if not name:
        return 0.0
    n = str(name).lower().strip()
    if n in ("id", "sys_id", "fid", "gid"):
        return 0.50
    if n in COMMON_ID_NAMES:
        return 0.40
    tokens = [t for t in re.split(r'[/_ \-():;,.]+', n) if t]
    if tokens:
        if tokens[0] in ("id", "sys_id", "fid", "gid"):
            return 0.45
        if any(t in ("id", "sys_id", "fid", "gid", "järjekorranumber", "jrknr", "jrk") for t in tokens):
            return 0.38
        if any(t in COMMON_ID_NAMES for t in tokens):
            return 0.30
    if any(k in n for k in ("id", "kood", "tunnus", "nr")):
        return 0.20
    return 0.0

TABLE_SUMMARY_KEYWORDS = {
    "kokku", "total", "totals", "summa", "keskmine", "average", "count", "loendus"
}

_INT_DECIMAL_RE = re.compile(r"^[+-]?\d+[.,]0+$")
_FLOAT_TRAILING_ZERO_RE = re.compile(r"^[+-]?\d+\.\d+0+$")


def normalize_id_value(val) -> str:
    """
    Normalizes an ID from either a QGIS feature attribute (including QVariant,
    int, float, Decimal, or text) or an Excel cell.
    Handles:
      - QVariant unwrapping and NULL checks (Qt5 & Qt6)
      - Integers and floats (e.g. 10452.0, 10452.000 -> '10452')
      - Non-breaking spaces (\xa0) and whitespace
      - Excel formula errors (#N/A, etc.) and null markers
    Returns empty string '' if null/blank.
    """
    if val is None:
        return ""

    # Unwrap QVariant if present (PyQt5 / PyQt6)
    if hasattr(val, "isNull") and callable(val.isNull):
        if val.isNull():
            return ""
        if hasattr(val, "value") and callable(val.value):
            try:
                val = val.value()
            except Exception:
                pass

    if val is None or isinstance(val, bool):
        return ""

    if isinstance(val, int):
        return str(val)

    if isinstance(val, (float, Decimal)):
        try:
            fval = float(val)
            if math.isnan(fval) or math.isinf(fval):
                return ""
            if fval.is_integer():
                return str(int(round(fval)))
            s_float = f"{fval:.10f}".rstrip("0").rstrip(".")
            return s_float
        except Exception:
            return ""

    s = str(val)
    # Clean non-breaking spaces, zero-width spaces, tabs, newlines
    s = s.replace("\xa0", " ").replace("\u200b", "").replace("\ufeff", "").strip()
    if not s:
        return ""

    s_lower = s.lower()
    if s_lower in (
        "none", "null", "<null>", "nan", "nat", "undefined",
        "#n/a", "#value!", "#ref!", "#div/0!", "#name?", "#num!", "-"
    ):
        return ""

    # Handle numeric strings with .0, .00, ,00 etc. (e.g. '1045.00' -> '1045')
    if _INT_DECIMAL_RE.match(s):
        int_part = re.split(r"[.,]", s)[0].lstrip("+")
        if int_part in ("-0", "0"):
            return "0"
        return int_part

    # Handle decimal strings with trailing zeros (e.g. '12.500' -> '12.5')
    if _FLOAT_TRAILING_ZERO_RE.match(s):
        return s.rstrip("0").rstrip(".").lstrip("+")

    return s


def _parse_raw_sheet_rows(raw_rows: list):
    """
    Given a list of row tuples from an Excel sheet, finds the actual header row
    (handling formatted Excel tables that may have empty/title rows at top)
    and returns (headers_list, data_rows_as_dicts).
    """
    if not raw_rows:
        return [], []

    header_row_idx = None
    best_non_empty = 0
    max_cells = 0

    # Scan first 20 rows to locate the table header row
    scan_limit = min(len(raw_rows), 20)
    for idx in range(scan_limit):
        row = raw_rows[idx]
        if not row:
            continue
        non_empty_cells = [
            c for c in row
            if normalize_id_value(c) != ""
        ]
        if len(non_empty_cells) > max_cells:
            max_cells = len(non_empty_cells)
            header_row_idx = idx

    if header_row_idx is None:
        return [], []

    headers_raw = raw_rows[header_row_idx]
    # Trim trailing completely empty columns from the right side of the sheet
    last_valid_col = len(headers_raw) - 1
    while last_valid_col >= 0 and normalize_id_value(headers_raw[last_valid_col]) == "":
        # Check if any data row has values in this column
        has_data_in_col = any(
            r is not None and last_valid_col < len(r) and normalize_id_value(r[last_valid_col]) != ""
            for r in raw_rows[header_row_idx + 1 : header_row_idx + 100]
        )
        if has_data_in_col:
            break
        last_valid_col -= 1

    if last_valid_col < 0:
        return [], []

    headers = []
    seen_headers = {}
    for i in range(last_valid_col + 1):
        h_val = headers_raw[i] if i < len(headers_raw) else None
        h_clean = normalize_id_value(h_val)
        if not h_clean:
            h_clean = f"Veerg_{i+1}"
        if h_clean in seen_headers:
            seen_headers[h_clean] += 1
            h_clean = f"{h_clean}_{seen_headers[h_clean]}"
        else:
            seen_headers[h_clean] = 1
        headers.append(h_clean)

    data = []
    for r_idx in range(header_row_idx + 1, len(raw_rows)):
        row = raw_rows[r_idx]
        if row is None:
            continue
        row_dict = {"_excel_row_num": r_idx + 1}
        has_any_val = False
        for i, h in enumerate(headers):
            cell_val = row[i] if i < len(row) else None
            if normalize_id_value(cell_val) != "":
                has_any_val = True
            row_dict[h] = cell_val
        if has_any_val:
            data.append(row_dict)

    return headers, data


def read_excel_workbook(xlsx_path: str) -> dict:
    """
    Reads ALL worksheets from an .xlsx file and returns an ordered dict:
    {
        sheet_name: {
            "headers": [col1, col2, ...],
            "rows": [row_dict1, row_dict2, ...]
        },
        ...
    }
    Tries openpyxl first, then pandas, then QGIS OGR provider sublayers as fallback.
    """
    workbook_data = {}

    # 1. Try openpyxl
    try:
        import openpyxl
        wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            raw_rows = list(ws.iter_rows(values_only=True))
            headers, data = _parse_raw_sheet_rows(raw_rows)
            if headers:
                workbook_data[sheet_name] = {"headers": headers, "rows": data}
        wb.close()
        if workbook_data:
            return workbook_data
    except ImportError:
        pass
    except Exception:
        pass

    # 2. Try pandas
    try:
        import pandas as pd
        xls = pd.ExcelFile(xlsx_path)
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name, header=None)
            raw_rows = [tuple(x) for x in df.to_numpy()]
            headers, data = _parse_raw_sheet_rows(raw_rows)
            if headers:
                workbook_data[str(sheet_name)] = {"headers": headers, "rows": data}
        if workbook_data:
            return workbook_data
    except ImportError:
        pass
    except Exception:
        pass

    # 3. Fallback: QGIS OGR provider (supports multi-sheet .xlsx via subLayers)
    base_lyr = QgsVectorLayer(xlsx_path, "xlsx_probe", "ogr")
    if not base_lyr.isValid():
        raise RuntimeError(f"Ei õnnestunud avada Exceli faili: {xlsx_path}")

    sublayers = base_lyr.dataProvider().subLayers()
    if sublayers:
        for sub in sublayers:
            # OGR sublayer string format: index!!::!!name!!::!!count!!::!!geom_type...
            parts = sub.split("!!::!!")
            sh_name = parts[1] if len(parts) > 1 else sub
            uri = f"{xlsx_path}|layername={sh_name}"
            s_lyr = QgsVectorLayer(uri, sh_name, "ogr")
            if s_lyr.isValid():
                headers = [f.name() for f in s_lyr.fields()]
                rows = []
                for idx, feat in enumerate(s_lyr.getFeatures(), start=2):
                    r_dict = {"_excel_row_num": idx}
                    has_v = False
                    for h in headers:
                        val = feat[h]
                        if normalize_id_value(val) != "":
                            has_v = True
                        r_dict[h] = val
                    if has_v:
                        rows.append(r_dict)
                if headers:
                    workbook_data[sh_name] = {"headers": headers, "rows": rows}
    else:
        headers = [f.name() for f in base_lyr.fields()]
        rows = []
        for idx, feat in enumerate(base_lyr.getFeatures(), start=2):
            r_dict = {"_excel_row_num": idx}
            for h in headers:
                r_dict[h] = feat[h]
            rows.append(r_dict)
        workbook_data["Leht1"] = {"headers": headers, "rows": rows}

    return workbook_data


def read_excel_columns_and_rows(xlsx_path: str, sheet_name: str = ""):
    """
    Compatibility helper returning (headers, rows) for a specific sheet or the first sheet.
    """
    wb = read_excel_workbook(xlsx_path)
    if not wb:
        return [], []
    if sheet_name and sheet_name in wb:
        return wb[sheet_name]["headers"], wb[sheet_name]["rows"]
    first_sheet = next(iter(wb.values()))
    return first_sheet["headers"], first_sheet["rows"]


def auto_detect_id_fields(layer, xlsx_headers: list, xlsx_rows: list, return_raw_score: bool = False):
    """
    Automatically detects the best matching ID field pair between the vector layer
    and a single Excel worksheet using column name heuristics, cardinality checks,
    and value overlap scoring.
    Returns (best_layer_field, best_xlsx_field, confidence_score) or with raw_score if requested.
    """
    if not layer or not layer.isValid() or not xlsx_headers:
        return (None, None, 0.0, 0.0) if return_raw_score else (None, None, 0.0)

    layer_fields = [f.name() for f in layer.fields()]
    if not layer_fields:
        return (None, None, 0.0, 0.0) if return_raw_score else (None, None, 0.0)

    # 1. Pre-sample layer fields once
    layer_samples = {f: [] for f in layer_fields}
    for i, feat in enumerate(layer.getFeatures()):
        if i >= 400:
            break
        for f in layer_fields:
            v = normalize_id_value(feat[f])
            if v:
                layer_samples[f].append(v)

    layer_sets = {f: set(layer_samples[f]) for f in layer_fields}
    layer_sets_stripped = {
        f: {x.lstrip("0") or "0" for x in layer_sets[f] if x.isdigit()}
        for f in layer_fields
    }

    # 2. Pre-sample sheet headers once
    xlsx_samples = {h: [] for h in xlsx_headers}
    for row in xlsx_rows[:400]:
        for h in xlsx_headers:
            v = normalize_id_value(row.get(h))
            if v and v.lower() not in TABLE_SUMMARY_KEYWORDS:
                xlsx_samples[h].append(v)

    xlsx_sets = {h: set(xlsx_samples[h]) for h in xlsx_headers}
    xlsx_sets_stripped = {
        h: {x.lstrip("0") or "0" for x in xlsx_sets[h] if x.isdigit()}
        for h in xlsx_headers
    }

    best_pair = (layer_fields[0], xlsx_headers[0])
    best_raw_score = -999.0

    for lf in layer_fields:
        l_vals = layer_samples[lf]
        l_set = layer_sets[lf]
        if not l_set:
            continue

        # Cardinality check on layer field:
        # A field with 3 values across 50 features is a category/status, not an ID!
        l_cardinality = len(l_set) / max(1, len(l_vals))
        if len(l_set) < 8 and len(l_vals) > 15 and l_cardinality < 0.25:
            continue

        lf_score = get_field_id_name_score(lf)

        for xh in xlsx_headers:
            x_vals = xlsx_samples[xh]
            x_set = xlsx_sets[xh]
            if not x_set:
                continue

            x_cardinality = len(x_set) / max(1, len(x_vals))
            if len(x_set) < 8 and len(x_vals) > 15 and x_cardinality < 0.25:
                continue

            inter = len(l_set.intersection(x_set))
            union = len(l_set.union(x_set))

            # Numeric check (e.g. leading zeros 001 vs 1)
            l_num = layer_sets_stripped[lf]
            x_num = xlsx_sets_stripped[xh]
            if l_num and x_num:
                i_num = len(l_num.intersection(x_num))
                u_num = len(l_num.union(x_num))
                if u_num > 0 and (i_num / u_num) > (inter / union if union else 0):
                    inter = i_num
                    union = u_num

            if inter == 0:
                continue

            jaccard = inter / union if union > 0 else 0.0
            recall = inter / len(l_set) if l_set else 0.0
            xh_score = get_field_id_name_score(xh)

            # Bonus if exact same field name
            same_name_bonus = 0.25 if lf.lower().strip() == xh.lower().strip() else 0.0

            # Penalty if neither field looks remotely like an ID
            non_id_penalty = -0.40 if (lf_score == 0 and xh_score == 0) else 0.0

            # Absolute count bonus (matching 50, 100, 300 real features is vastly more significant than 2 or 3 items)
            count_bonus = min(0.60, (inter / 100.0) * 0.30)

            total = lf_score + xh_score + same_name_bonus + (jaccard * 0.8) + (recall * 0.6) + count_bonus + non_id_penalty
            if total > best_raw_score:
                best_raw_score = total
                best_pair = (lf, xh)

    # Fallback to field names if no values overlapped
    if best_raw_score < 0:
        for lf in layer_fields:
            lf_score = get_field_id_name_score(lf)
            for xh in xlsx_headers:
                xh_score = get_field_id_name_score(xh)
                same = 0.25 if lf.lower().strip() == xh.lower().strip() else 0.0
                score = lf_score + xh_score + same
                if score > best_raw_score:
                    best_raw_score = score
                    best_pair = (lf, xh)

    confidence = min(1.0, max(0.0, best_raw_score / 2.0))
    if return_raw_score:
        return best_pair[0], best_pair[1], confidence, best_raw_score
    return best_pair[0], best_pair[1], confidence


def auto_detect_sheet_and_id_fields(layer, workbook_dict: dict):
    """
    Scans ALL sheets in a multi-sheet .xlsx workbook and returns:
    (best_sheet_name, best_layer_field, best_xlsx_field, best_confidence)
    """
    if not workbook_dict:
        return "", None, None, 0.0

    best_sheet = next(iter(workbook_dict.keys()))
    best_lf = None
    best_xf = None
    best_conf = 0.0
    best_raw = -999.0

    for sh_name, sh_content in workbook_dict.items():
        headers = sh_content.get("headers", [])
        rows = sh_content.get("rows", [])
        if not headers:
            continue
        lf, xf, conf, raw = auto_detect_id_fields(layer, headers, rows, return_raw_score=True)
        if raw > best_raw:
            best_raw = raw
            best_conf = conf
            best_sheet = sh_name
            best_lf = lf
            best_xf = xf

    return best_sheet, best_lf, best_xf, best_conf


def run_step1_id_check(layer, layer_id_field: str, xlsx_rows: list, xlsx_id_field: str) -> dict:
    """
    Step 1: Bidirectional ID validation between Vector Layer and Excel sheet.
    - Handles non-text IDs (integers, floats, Decimals, QVariants, leading zeros).
    - Ignores blank/empty ID cells in formatted Excel Tables (so trailing empty table rows
      or summary rows do NOT cause false 'ID lahknevus' alerts).
    """
    layer_ids = []
    layer_null_fids = []
    layer_counts = {}

    for feat in layer.getFeatures():
        val = normalize_id_value(feat[layer_id_field])
        if not val:
            layer_null_fids.append(feat.id())
        else:
            layer_ids.append(val)
            layer_counts[val] = layer_counts.get(val, 0) + 1

    layer_set = set(layer_ids)

    xlsx_ids = []
    skipped_blank_xlsx_rows = 0
    xlsx_counts = {}

    for idx, row in enumerate(xlsx_rows, start=2):
        val = normalize_id_value(row.get(xlsx_id_field))
        
        # FIX: Ignore row if the value exactly matches the column header name
        # (happens if formatting pushes the header down into the OGR data rows)
        if val.lower() == str(xlsx_id_field).strip().lower():
            continue
        # Also ignore obvious header leakages in the first few rows
        if idx < 10 and val.lower() in ("id/ järjekorranumber", "id/järjekorranumber", "id", "kood"):
            continue

        if not val:
            # Blank ID cell in a formatted Excel table -> ignore cleanly!
            skipped_blank_xlsx_rows += 1
            continue
        if val.lower() in TABLE_SUMMARY_KEYWORDS and val not in layer_set:
            # Excel Table Totals/Summary row ('Kokku', 'Total', etc.) -> ignore cleanly!
            skipped_blank_xlsx_rows += 1
            continue

        xlsx_ids.append(val)
        xlsx_counts[val] = xlsx_counts.get(val, 0) + 1

    xlsx_set = set(xlsx_ids)

    # Secondary check: what if one side has pure digits with leading zeros ('0045')
    # and the other side has integer '45' (because Excel formatted the column as Number)?
    raw_missing_in_xlsx = layer_set - xlsx_set
    raw_missing_in_layer = xlsx_set - layer_set

    leading_zero_matched = []
    if raw_missing_in_xlsx and raw_missing_in_layer:
        xlsx_by_stripped = {}
        for xid in raw_missing_in_layer:
            if xid.isdigit():
                xlsx_by_stripped.setdefault(xid.lstrip("0") or "0", []).append(xid)

        for lid in list(raw_missing_in_xlsx):
            if lid.isdigit():
                stripped = lid.lstrip("0") or "0"
                cands = xlsx_by_stripped.get(stripped, [])
                if len(cands) == 1:
                    x_equiv = cands[0]
                    raw_missing_in_xlsx.discard(lid)
                    raw_missing_in_layer.discard(x_equiv)
                    leading_zero_matched.append((lid, x_equiv))

    missing_in_xlsx = sorted(list(raw_missing_in_xlsx))
    missing_in_layer = sorted(list(raw_missing_in_layer))
    dup_in_layer = sorted([k for k, v in layer_counts.items() if v > 1])
    dup_in_xlsx = sorted([k for k, v in xlsx_counts.items() if v > 1])

    matched_unique_count = len(layer_set.intersection(xlsx_set)) + len(leading_zero_matched)

    # Note: skipped_blank_xlsx_rows does NOT fail the check!
    is_ok = (
        len(missing_in_xlsx) == 0
        and len(missing_in_layer) == 0
        and len(dup_in_layer) == 0
        and len(dup_in_xlsx) == 0
        and len(layer_null_fids) == 0
        and matched_unique_count > 0
    )

    return {
        "ok": is_ok,
        "layer_total": len(layer_ids),
        "xlsx_total": len(xlsx_ids),
        "matched_unique": matched_unique_count,
        "missing_in_xlsx": missing_in_xlsx,
        "missing_in_layer": missing_in_layer,
        "dup_in_layer": dup_in_layer,
        "dup_in_xlsx": dup_in_xlsx,
        "layer_null_fids": layer_null_fids,
        "skipped_blank_xlsx_rows": skipped_blank_xlsx_rows,
        "leading_zero_matched": leading_zero_matched,
    }
