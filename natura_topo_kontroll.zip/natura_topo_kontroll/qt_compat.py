# -*- coding: utf-8 -*-
"""
Qt5 / Qt6 and QGIS 3 / QGIS 4 compatibility helpers.
Tested for QGIS 4.2+ (Python 3.12 / Qt6) and QGIS 3.22+ (Qt5).
"""

from qgis.core import QgsField, QgsWkbTypes
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtWidgets import QDialog, QMenu, QMessageBox, QHeaderView

try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction

try:
    from qgis.PyQt.QtCore import QMetaType
    HAS_QMETATYPE = True
except ImportError:
    HAS_QMETATYPE = False

STRONG_FOCUS = getattr(Qt, "StrongFocus", None) or Qt.FocusPolicy.StrongFocus
KEY_DELETE = getattr(Qt, "Key_Delete", None) or Qt.Key.Key_Delete
KEY_BACKSPACE = getattr(Qt, "Key_Backspace", None) or Qt.Key.Key_Backspace
VERTICAL_ORIENTATION = getattr(Qt, "Vertical", None) or Qt.Orientation.Vertical
USER_ROLE = getattr(Qt, "UserRole", None) or Qt.ItemDataRole.UserRole
RIGHT_DOCK_AREA = getattr(Qt, "RightDockWidgetArea", None) or Qt.DockWidgetArea.RightDockWidgetArea
DIALOG_ACCEPTED = getattr(QDialog, "Accepted", None) or QDialog.DialogCode.Accepted
CUSTOM_CONTEXT_MENU = getattr(Qt, "CustomContextMenu", None) or getattr(getattr(Qt, "ContextMenuPolicy", None), "CustomContextMenu", 3)
ASCENDING_ORDER = getattr(Qt, "AscendingOrder", None) or getattr(getattr(Qt, "SortOrder", None), "AscendingOrder", 0)
DESCENDING_ORDER = getattr(Qt, "DescendingOrder", None) or getattr(getattr(Qt, "SortOrder", None), "DescendingOrder", 1)

HEADER_RESIZEMODE = getattr(QHeaderView, "ResizeMode", None)
HEADER_INTERACTIVE = getattr(QHeaderView, "Interactive", None) or getattr(HEADER_RESIZEMODE, "Interactive", 0)
HEADER_STRETCH = getattr(QHeaderView, "Stretch", None) or getattr(HEADER_RESIZEMODE, "Stretch", 1)
HEADER_FIXED = getattr(QHeaderView, "Fixed", None) or getattr(HEADER_RESIZEMODE, "Fixed", 2)

ALIGN_CENTER = getattr(Qt, "AlignCenter", None) or getattr(getattr(Qt, "AlignmentFlag", None), "AlignCenter", 0x0084)
ITEM_ENABLED = getattr(Qt, "ItemIsEnabled", None) or getattr(getattr(Qt, "ItemFlag", None), "ItemIsEnabled", 1)
ITEM_SELECTABLE = getattr(Qt, "ItemIsSelectable", None) or getattr(getattr(Qt, "ItemFlag", None), "ItemIsSelectable", 1)
NO_ITEM_FLAGS = getattr(Qt, "NoItemFlags", None) or getattr(getattr(Qt, "ItemFlag", None), "NoItemFlags", 0)


def make_field(name: str, kind: str = "string") -> QgsField:
    """
    Creates a QgsField compatible with both QGIS 4 (QMetaType.Type) and QGIS 3 (QVariant).
    kind: 'string', 'double', or 'int'
    """
    if HAS_QMETATYPE and hasattr(QMetaType, "Type"):
        try:
            if kind == "double":
                return QgsField(name, QMetaType.Type.Double)
            if kind == "int":
                return QgsField(name, QMetaType.Type.Int)
            return QgsField(name, QMetaType.Type.QString)
        except Exception:
            pass

    if kind == "double":
        return QgsField(name, QVariant.Double)
    if kind == "int":
        return QgsField(name, QVariant.Int)
    return QgsField(name, QVariant.String)


def exec_dialog(dlg: QDialog) -> int:
    """Safely executes a QDialog on both Qt5 and Qt6."""
    if hasattr(dlg, "exec"):
        return dlg.exec()
    return dlg.exec_()


def extract_polygon_parts(geom):
    """
    Extracts all 2D Polygon single-part QgsGeometry objects from any QgsGeometry
    (Polygon, MultiPolygon, PolygonZ, MultiPolygonZ, CurvePolygon, GeometryCollection).
    Avoids calling .numGeometries() directly on QgsGeometry (which only exists on QgsAbstractGeometry).
    """
    from qgis.core import QgsGeometry
    parts = []
    if geom is None or geom.isNull() or geom.isEmpty():
        return parts

    try:
        if QgsWkbTypes.isCurvedType(geom.wkbType()):
            abs_curved = geom.constGet()
            if abs_curved is not None and hasattr(abs_curved, "segmentize"):
                geom = QgsGeometry(abs_curved.segmentize())
    except Exception:
        pass

    # asGeometryCollection() safely decomposes MultiPolygon & GeometryCollection into single-part QgsGeometry list
    for part in geom.asGeometryCollection():
        if part is None or part.isNull() or part.isEmpty():
            continue
        flat_type = QgsWkbTypes.flatType(part.wkbType())
        if flat_type == QgsWkbTypes.Polygon:
            if part.area() > 0:
                parts.append(part)
        elif flat_type in (QgsWkbTypes.MultiPolygon, QgsWkbTypes.GeometryCollection):
            abs_g = part.constGet()
            if abs_g is not None and hasattr(abs_g, "numGeometries"):
                for i in range(abs_g.numGeometries()):
                    sub_abs = abs_g.geometryN(i)
                    if sub_abs is not None:
                        sub = QgsGeometry(sub_abs.clone())
                        if QgsWkbTypes.flatType(sub.wkbType()) == QgsWkbTypes.Polygon and sub.area() > 0:
                            parts.append(sub)
    return parts


def extract_rings_as_point_lists(geom):
    """
    Returns a list of closed 2D rings (each ring is a list of QgsPointXY)
    for any Polygon or MultiPolygon geometry.
    """
    rings = []
    for poly_part in extract_polygon_parts(geom):
        try:
            poly = poly_part.asPolygon()
            for ring in poly:
                if len(ring) >= 4:
                    rings.append(ring)
        except Exception:
            pass
    return rings


def exec_menu(menu, pos):
    if hasattr(menu, 'exec'):
        return menu.exec(pos)
    return menu.exec_(pos)


try:
    COPY_ACTION = Qt.CopyAction
except AttributeError:
    COPY_ACTION = Qt.DropAction.CopyAction

try:
    MB_YES = QMessageBox.Yes
    MB_NO = QMessageBox.No
except AttributeError:
    MB_YES = QMessageBox.StandardButton.Yes
    MB_NO = QMessageBox.StandardButton.No

def is_layer_valid(lyr):
    if lyr is None:
        return False
    try:
        return lyr.isValid()
    except RuntimeError:
        return False
