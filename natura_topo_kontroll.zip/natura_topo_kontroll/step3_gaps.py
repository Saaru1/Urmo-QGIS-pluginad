# -*- coding: utf-8 -*-
"""
Step 3 Module: Augud (Gaps < 0.01 ha Cartesian within and between features).
Distinguishes:
- 'Kuju sees (sisendkiht)' — ID
- 'Kuju sees (WFS)' — ID
- 'Kujude vahel' — ID/ID/...
"""

from qgis.core import (
    QgsFeature, QgsGeometry, QgsFields, QgsWkbTypes, QgsMemoryProviderUtils
)
from .qt_compat import make_field, extract_polygon_parts


def run_step3_gaps(
    snapped_geoms_dict: dict,
    obj_ids: dict,
    obj_sources: dict,
    spatial_index,
    crs,
    settings
):
    """
    Finds gaps < settings.max_gap_area_ha (default 0.01 ha = 100 m2) both within
    polygons and between adjacent polygons, returning the 'Augud' memory layer
    and count of detected gaps.
    """
    augud_fields = QgsFields()
    augud_fields.append(make_field("vea_tyyp", "string"))
    augud_fields.append(make_field("id_loend", "string"))
    augud_fields.append(make_field("pindala_ha", "double"))
    augud_fields.append(make_field("pindala_m2", "double"))
    augud_fields.append(make_field("seotud_sisendiga", "string"))

    augud_layer = QgsMemoryProviderUtils.createMemoryLayer(
        "Augud", augud_fields, QgsWkbTypes.Polygon, crs
    )
    augud_pr = augud_layer.dataProvider()
    augud_feats = []

    max_gap_m2 = settings.max_gap_area_ha * 10000.0  # 0.01 ha = 100 m2
    seen_gap_sigs = set()

    # 3A: Union all snapped geometries to extract all enclosed voids (internal & between polygons)
    all_snapped_geoms = list(snapped_geoms_dict.values())
    if all_snapped_geoms:
        unioned = QgsGeometry.unaryUnion(all_snapped_geoms)
        union_polys = extract_polygon_parts(unioned)

        for upoly in union_polys:
            poly_rings = upoly.asPolygon()
            if len(poly_rings) <= 1:
                continue
            for hole_ring in poly_rings[1:]:
                hole_geom = QgsGeometry.fromPolygonXY([hole_ring])
                area_m2 = hole_geom.area()
                if area_m2 < settings.min_gap_area_m2 or area_m2 >= max_gap_m2:
                    continue

                search_box = hole_geom.boundingBox()
                search_box.grow(max(settings.snap_grid_m * 5.0, 0.01))
                cand_fids = spatial_index.intersects(search_box)

                hole_buffered = hole_geom.buffer(max(settings.snap_grid_m * 2.5, 0.003), 5)
                touching_fids = [
                    cfid for cfid in cand_fids
                    if snapped_geoms_dict[cfid].intersects(hole_buffered)
                ]
                if not touching_fids:
                    continue

                touching_ids = sorted(list(set(obj_ids[cfid] for cfid in touching_fids)))
                touching_sources = [obj_sources[cfid] for cfid in touching_fids]
                has_input = any(s in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER") for s in touching_sources)

                if hasattr(settings, 'are_sources_reported'):
                    if not settings.are_sources_reported(touching_sources):
                        continue
                elif settings.only_input_related and not has_input:
                    continue

                if len(touching_fids) == 1:
                    only_fid = touching_fids[0]
                    gap_type = (
                        "Kuju sees (sisendkiht)"
                        if obj_sources[only_fid] in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM")
                        else "Kuju sees (WFS)"
                    )
                    id_str = obj_ids[only_fid]
                else:
                    gap_type = "Kujude vahel"
                    id_str = "/".join(touching_ids)

                c_pt = hole_geom.centroid().asPoint()
                sig = f"{round(c_pt.x(), 2)}_{round(c_pt.y(), 2)}_{round(area_m2, 2)}"
                if sig in seen_gap_sigs:
                    continue
                seen_gap_sigs.add(sig)

                gf = QgsFeature(augud_fields)
                gf.setGeometry(hole_geom)
                gf["vea_tyyp"] = gap_type
                gf["id_loend"] = id_str
                gf["pindala_ha"] = round(area_m2 / 10000.0, 2)
                gf["pindala_m2"] = round(area_m2, 2)
                gf["seotud_sisendiga"] = "Jah" if has_input else "Ei"
                augud_feats.append(gf)

    # 3B: Inspect individual polygon interior rings directly (in case an overlap masked a hole)
    for fid, g in snapped_geoms_dict.items():
        for part in extract_polygon_parts(g):
            rings = part.asPolygon()
            if len(rings) <= 1:
                continue
            for hole_ring in rings[1:]:
                hole_geom = QgsGeometry.fromPolygonXY([hole_ring])
                area_m2 = hole_geom.area()
                if area_m2 < settings.min_gap_area_m2 or area_m2 >= max_gap_m2:
                    continue

                c_box = hole_geom.boundingBox()
                other_geoms = [
                    snapped_geoms_dict[ofid]
                    for ofid in spatial_index.intersects(c_box)
                    if ofid != fid and snapped_geoms_dict[ofid].intersects(hole_geom)
                ]
                rem_geom = QgsGeometry(hole_geom)
                for og in other_geoms:
                    rem_geom = rem_geom.difference(og)
                if rem_geom.isNull() or rem_geom.isEmpty():
                    continue

                for rem_part in extract_polygon_parts(rem_geom):
                    rem_area = rem_part.area()
                    if rem_area < settings.min_gap_area_m2 or rem_area >= max_gap_m2:
                        continue

                    c_pt = rem_part.centroid().asPoint()
                    sig = f"{round(c_pt.x(), 2)}_{round(c_pt.y(), 2)}_{round(rem_area, 2)}"
                    if sig in seen_gap_sigs:
                        continue
                    seen_gap_sigs.add(sig)

                    src = obj_sources[fid]
                    has_input = (src in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER"))
                    if hasattr(settings, 'is_source_reported'):
                        if not settings.is_source_reported(src):
                            continue
                    elif settings.only_input_related and not has_input:
                        continue

                    gap_type = "Kuju sees (sisendkiht)" if has_input else "Kuju sees (WFS)"
                    gf = QgsFeature(augud_fields)
                    gf.setGeometry(rem_part)
                    gf["vea_tyyp"] = gap_type
                    gf["id_loend"] = obj_ids[fid]
                    gf["pindala_ha"] = round(rem_area / 10000.0, 2)
                    gf["pindala_m2"] = round(rem_area, 2)
                    gf["seotud_sisendiga"] = "Jah" if has_input else "Ei"
                    augud_feats.append(gf)

    augud_pr.addFeatures(augud_feats)
    augud_layer.updateExtents()
    return augud_layer, len(augud_feats)
