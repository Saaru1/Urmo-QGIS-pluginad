# -*- coding: utf-8 -*-
"""
Reusable UI Components Module:
- MODERN_STYLESHEET
- SingleItemDropZone (drag & drop card with hover 'x' and Delete key support)
- IdFieldSelectDialog (Step 1 worksheet + column selection with live preview)
- CalibrationSettingsDialog (MapInfo tolerance tuning & test dataset generator)
"""

import os
from qgis.core import QgsProject, QgsVectorLayer, QgsMimeDataUtils
from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog,
    QDialog, QFormLayout, QComboBox, QCheckBox, QDoubleSpinBox, QLineEdit,
    QMessageBox, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QWidget
)

from .qt_compat import (
    STRONG_FOCUS, KEY_DELETE, KEY_BACKSPACE, COPY_ACTION,
    HEADER_INTERACTIVE, HEADER_STRETCH, HEADER_FIXED,
    ALIGN_CENTER, ITEM_ENABLED, ITEM_SELECTABLE, NO_ITEM_FLAGS
)
from .step1_id_check import (
    auto_detect_id_fields, run_step1_id_check
)
from .topology_runner import MapInfoTopologySettings
from .test_data_generator import generate_calibration_dataset
from .step4_overlaps import (
    DEFAULT_PROFILE2_RULES, get_profile2_rules, save_profile2_rules, reset_profile2_rules
)


MODERN_STYLESHEET = """
QWidget#MainPanel {
    background-color: #F8FAFC;
    color: #1E293B;
    font-family: "Segoe UI", "Inter", sans-serif;
    font-size: 12px;
}
QFrame#ToolbarCard {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
}
QPushButton.ToolbarBtn {
    background-color: #0F766E;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 7px 12px;
    font-weight: 600;
    font-size: 12px;
}
QPushButton.ToolbarBtn:hover {
    background-color: #0D9488;
}
QPushButton.ToolbarBtn:disabled {
    background-color: #CBD5E1;
    color: #64748B;
}
QPushButton#StartBtn {
    background-color: #2563EB;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 7px 14px;
    font-weight: 600;
}
QPushButton#StartBtn:hover {
    background-color: #1D4ED8;
}
QPushButton#StartBtn:disabled {
    background-color: #CBD5E1;
    color: #64748B;
}
QPushButton#SecondaryBtn {
    background-color: #F1F5F9;
    color: #334155;
    border: 1px solid #CBD5E1;
    border-radius: 5px;
    padding: 4px 10px;
    font-weight: 500;
}
QPushButton#SecondaryBtn:hover {
    background-color: #E2E8F0;
}
QPushButton#ToggleMapBtn {
    background-color: #0F172A;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 7px 14px;
    font-weight: 600;
}
QPushButton#ToggleMapBtn:checked {
    background-color: #10B981;
    color: #FFFFFF;
}
QFrame.DropZoneEmpty {
    background-color: #FFFFFF;
    border: 2px dashed #94A3B8;
    border-radius: 8px;
}
QFrame.DropZoneHover {
    background-color: #F0FDFA;
    border: 2px dashed #0D9488;
    border-radius: 8px;
}
QFrame.DropZoneLoaded {
    background-color: #FFFFFF;
    border: 1.5px solid #0D9488;
    border-radius: 8px;
}
QPushButton#RemoveItemBtn {
    background-color: #FEE2E2;
    color: #DC2626;
    border: 1px solid #FCA5A5;
    border-radius: 10px;
    font-weight: bold;
    font-size: 13px;
    min-width: 20px;
    max-width: 20px;
    min-height: 20px;
    max-height: 20px;
    padding: 0px;
}
QPushButton#RemoveItemBtn:hover {
    background-color: #EF4444;
    color: #FFFFFF;
}
QTreeWidget, QTextBrowser {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 6px;
    padding: 4px;
}
"""


class SingleItemDropZone(QFrame):
    """
    A drag-and-drop card that holds at most 1 item (Vector layer or .xlsx file).
    Supports OS file drops, QGIS Layer Tree drops, hover 'x' button, and Delete key.
    """
    itemChanged = pyqtSignal()

    def __init__(self, title: str, subtitle_hint: str, mode: str = "layer", iface=None, parent=None):
        super().__init__(parent)
        self.mode = mode  # "layer" or "xlsx"
        self.iface = iface
        self.loaded_layer = None
        self.loaded_path = ""
        self.loaded_name = ""

        self.setAcceptDrops(True)
        self.setFocusPolicy(STRONG_FOCUS)
        self.setProperty("class", "DropZoneEmpty")
        self._build_ui(title, subtitle_hint)

    def _build_ui(self, title: str, subtitle_hint: str):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        header_row = QHBoxLayout()
        self.title_lbl = QLabel(f"<b>{title}</b>")
        self.title_lbl.setStyleSheet("color: #0F172A; font-size: 12px;")
        header_row.addWidget(self.title_lbl)

        self.status_badge = QLabel("Ootel")
        self.status_badge.setStyleSheet(
            "background-color: #F1F5F9; color: #64748B; border-radius: 4px; "
            "padding: 2px 6px; font-size: 11px; font-weight: 600;"
        )
        header_row.addWidget(self.status_badge)
        header_row.addStretch()

        if self.mode == "layer":
            self.active_lyr_btn = QPushButton("Aktiivne kiht")
            self.active_lyr_btn.setObjectName("SecondaryBtn")
            self.active_lyr_btn.setToolTip("Võta QGISis hetkel valitud aktiivne vektorkiht")
            self.active_lyr_btn.clicked.connect(self._use_active_layer)
            header_row.addWidget(self.active_lyr_btn)

        self.browse_btn = QPushButton("Vali fail...")
        self.browse_btn.setObjectName("SecondaryBtn")
        self.browse_btn.clicked.connect(self._browse_file)
        header_row.addWidget(self.browse_btn)

        layout.addLayout(header_row)

        body_row = QHBoxLayout()
        body_row.setContentsMargins(4, 4, 4, 4)

        self.info_lbl = QLabel(subtitle_hint)
        self.info_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
        self.info_lbl.setWordWrap(True)
        body_row.addWidget(self.info_lbl, 1)

        self.remove_btn = QPushButton("×")
        self.remove_btn.setObjectName("RemoveItemBtn")
        self.remove_btn.setToolTip("Eemalda (või vajuta Delete klahvi)")
        self.remove_btn.hide()
        self.remove_btn.clicked.connect(self.clear_item)
        body_row.addWidget(self.remove_btn)

        layout.addLayout(body_row)
        self.default_hint = subtitle_hint

    def has_item(self) -> bool:
        if self.mode == "layer":
            if self.loaded_layer is None:
                return False
            try:
                return self.loaded_layer.isValid()
            except RuntimeError:
                # The underlying C++ object of QgsVectorLayer has been deleted by QGIS
                return False
        return bool(self.loaded_path and os.path.exists(self.loaded_path))

    def set_step1_status(self, state: str, text: str):
        if state == "ok":
            self.status_badge.setText(f"✓ {text}")
            self.status_badge.setStyleSheet(
                "background-color: #DCFCE7; color: #15803D; border: 1px solid #86EFAC; "
                "border-radius: 4px; padding: 2px 6px; font-size: 11px; font-weight: 600;"
            )
        elif state == "error":
            self.status_badge.setText(f"⚠ {text}")
            self.status_badge.setStyleSheet(
                "background-color: #FEE2E2; color: #B91C1C; border: 1px solid #FCA5A5; "
                "border-radius: 4px; padding: 2px 6px; font-size: 11px; font-weight: 600;"
            )
        elif state == "ready":
            self.status_badge.setText(text)
            self.status_badge.setStyleSheet(
                "background-color: #E0F2FE; color: #0369A1; border-radius: 4px; "
                "padding: 2px 6px; font-size: 11px; font-weight: 600;"
            )
        else:
            self.status_badge.setText(text)
            self.status_badge.setStyleSheet(
                "background-color: #F1F5F9; color: #64748B; border-radius: 4px; "
                "padding: 2px 6px; font-size: 11px; font-weight: 600;"
            )

    def clear_item(self):
        self.loaded_layer = None
        self.loaded_path = ""
        self.loaded_name = ""
        self.info_lbl.setText(self.default_hint)
        self.info_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
        self.remove_btn.hide()
        self.set_step1_status("wait", "Ootel")
        self._apply_frame_class("DropZoneEmpty")
        self.itemChanged.emit()

    def _apply_frame_class(self, cls_name: str):
        self.setProperty("class", cls_name)
        self.style().unpolish(self)
        self.style().polish(self)

    def enterEvent(self, event):
        if self.mode == "layer" and self.loaded_layer is not None and not self.has_item():
            self.clear_item()
        elif self.has_item():
            self.remove_btn.show()
        super().enterEvent(event)
        
    def mousePressEvent(self, event):
        if self.mode == "layer" and self.loaded_layer is not None and not self.has_item():
            self.clear_item()
        self.setFocus()
        super().mousePressEvent(event)

    def leaveEvent(self, event):
        if self.has_item():
            self.remove_btn.hide()
        super().leaveEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (KEY_DELETE, KEY_BACKSPACE) and self.has_item():
            self.clear_item()
            event.accept()
            return
        super().keyPressEvent(event)



    def dragEnterEvent(self, event):
        md = event.mimeData()
        if md.hasUrls() or md.hasFormat("application/x-vnd.qgis.qgis.uri"):
            event.setDropAction(COPY_ACTION)
            event.accept()
            self._apply_frame_class("DropZoneHover")
        else:
            event.ignore()
            
    def dragMoveEvent(self, event):
        md = event.mimeData()
        if md.hasUrls() or md.hasFormat("application/x-vnd.qgis.qgis.uri"):
            event.setDropAction(COPY_ACTION)
            event.accept()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self._apply_frame_class("DropZoneLoaded" if self.has_item() else "DropZoneEmpty")
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        md = event.mimeData()
        if md.hasFormat("application/x-vnd.qgis.qgis.uri"):
            uri_list = QgsMimeDataUtils.decodeUriList(md)
            for u in uri_list:
                if self.mode == "layer" and u.layerType == "vector":
                    lyr = None
                    if hasattr(u, 'layerId') and u.layerId:
                        lyr = QgsProject.instance().mapLayer(u.layerId)
                    
                    is_valid = False
                    if lyr is not None:
                        try:
                            is_valid = lyr.isValid()
                        except RuntimeError:
                            is_valid = False
                            
                    if not is_valid:
                        lyr = QgsVectorLayer(u.uri, u.name, u.providerKey or "ogr")
                        try:
                            if lyr.isValid():
                                # Prevent layer from being deleted by garbage collector
                                QgsProject.instance().addMapLayer(lyr)
                                is_valid = True
                        except RuntimeError:
                            pass
                            
                    if is_valid:
                        self.load_vector_layer(lyr, u.name)
                        event.setDropAction(COPY_ACTION)
                        event.accept()
                        return
                elif self.mode == "xlsx":
                    path = u.uri.split("|")[0]
                    if self._try_load_file_path(path):
                        event.setDropAction(COPY_ACTION)
                        event.accept()
                        return

        if md.hasUrls():
            for url in md.urls():
                local_path = url.toLocalFile()
                if local_path and os.path.isfile(local_path):
                    if self._try_load_file_path(local_path):
                        event.setDropAction(COPY_ACTION)
                        event.accept()
                        return

        self._apply_frame_class("DropZoneLoaded" if self.has_item() else "DropZoneEmpty")

    def _use_active_layer(self):
        if not self.iface:
            return
        lyr = self.iface.activeLayer()
        try:
            if isinstance(lyr, QgsVectorLayer) and lyr.isValid():
                self.load_vector_layer(lyr, lyr.name())
                return
        except RuntimeError:
            pass
            
        QMessageBox.information(
            self, "Aktiivne kiht", "Palun vali QGISi kihiloendis sobiv vektorkiht."
        )

    def _browse_file(self):
        if self.mode == "layer":
            path, _ = QFileDialog.getOpenFileName(
                self,
                "Vali sisendkiht",
                "",
                "Vektorkihid (*.gpkg *.tab *.shp *.geojson);;Kõik failid (*.*)"
            )
        else:
            path, _ = QFileDialog.getOpenFileName(
                self,
                "Vali Exceli tabel",
                "",
                "Exceli failid (*.xlsx *.xls)"
            )
        if path:
            self._try_load_file_path(path)

    def _try_load_file_path(self, path: str) -> bool:
        ext = os.path.splitext(path)[1].lower()
        if self.mode == "layer":
            if ext not in (".tab", ".shp", ".gpkg", ".geojson", ".json", ".mif"):
                QMessageBox.warning(
                    self, "Vale failitüüp",
                    "Siia aknasse saab lisada ainult vektorkihi (.tab, .shp, .gpkg, .geojson)."
                )
                return False
            name = os.path.splitext(os.path.basename(path))[0]
            lyr = QgsVectorLayer(path, name, "ogr")
            if not lyr.isValid():
                QMessageBox.warning(self, "Viga", f"Kihti ei õnnestunud avada:\n{path}")
                return False
            QgsProject.instance().addMapLayer(lyr)
            self.load_vector_layer(lyr, name, path)
            return True
        else:
            if ext not in (".xlsx", ".xls"):
                QMessageBox.warning(
                    self, "Vale failitüüp",
                    "Siia aknasse saab lisada ainult Exceli tabeli (.xlsx)."
                )
                return False
            self.load_xlsx_file(path)
            return True

    def load_vector_layer(self, layer, display_name: str = "", file_path: str = ""):
        self.loaded_layer = layer
        self.loaded_name = display_name or layer.name()
        self.loaded_path = file_path or layer.source()
        feat_count = layer.featureCount()
        crs_auth = layer.crs().authid() or "CRS puudub"
        self.info_lbl.setText(
            f"🗺️ <b>{self.loaded_name}</b> ({feat_count} objekti, {crs_auth})"
            f"<br><span style='color:#64748B;font-size:10px;'>[Del klahv või × eemaldamiseks]</span>"
        )
        self.info_lbl.setStyleSheet("color: #0F172A; font-size: 12px;")
        self._apply_frame_class("DropZoneLoaded")
        self.set_step1_status("ready", "Valmis")
        self.itemChanged.emit()

    def load_xlsx_file(self, path: str):
        self.loaded_path = path
        self.loaded_name = os.path.basename(path)
        self.info_lbl.setText(
            f"📊 <b>{self.loaded_name}</b>"
            f"<br><span style='color:#64748B;font-size:10px;'>{path} [Del või × eemaldamiseks]</span>"
        )
        self.info_lbl.setStyleSheet("color: #0F172A; font-size: 12px;")
        self._apply_frame_class("DropZoneLoaded")
        self.set_step1_status("ready", "Valmis")
        self.itemChanged.emit()


class IdFieldSelectDialog(QDialog):
    """
    Dialog opened when '1. ID-kontroll' is pressed.
    Supports multi-sheet Excel workbooks, auto-detection of sheet & ID columns,
    and shows a live preview of valid ID counts (ignoring blank Excel table rows).
    """
    def __init__(
        self,
        layer,
        workbook_dict: dict,
        best_sheet: str,
        best_layer_f: str,
        best_xlsx_f: str,
        confidence: float,
        auto_skip_enabled: bool = False,
        parent=None
    ):
        super().__init__(parent)
        self.setWindowTitle("Samm 1: Töölehe ja ID veergude valik")
        self.setMinimumWidth(460)

        self.layer = layer
        self.workbook_dict = workbook_dict
        self.layer_fields = [f.name() for f in layer.fields()] if layer else []
        self.sheet_names = list(workbook_dict.keys())

        layout = QVBoxLayout(self)

        conf_pct = int(round(confidence * 100))
        sheet_info = f"leht <code>{best_sheet}</code> → " if len(self.sheet_names) > 1 else ""
        self.banner = QLabel(
            f"🤖 <b>Automaattuvastus ({conf_pct}% kindlus):</b> "
            f"Kiht <code>{best_layer_f}</code> ↔ Excel {sheet_info}<code>{best_xlsx_f}</code>"
        )
        self.banner.setWordWrap(True)
        self.banner.setStyleSheet(
            "background-color: #F0FDFA; color: #0F766E; border: 1px solid #99F6E4; "
            "border-radius: 6px; padding: 8px;"
        )
        layout.addWidget(self.banner)

        form = QFormLayout()

        self.layer_combo = QComboBox()
        self.layer_combo.addItems(self.layer_fields)
        if best_layer_f in self.layer_fields:
            self.layer_combo.setCurrentText(best_layer_f)
        form.addRow("Vektorkihi ID veerg:", self.layer_combo)

        self.sheet_combo = QComboBox()
        self.sheet_combo.addItems(self.sheet_names)
        if best_sheet in self.sheet_names:
            self.sheet_combo.setCurrentText(best_sheet)
        form.addRow("Exceli tööleht (Sheet):", self.sheet_combo)

        self.xlsx_combo = QComboBox()
        cur_headers = self.workbook_dict.get(self.sheet_combo.currentText(), {}).get("headers", [])
        self.xlsx_combo.addItems(cur_headers)
        if best_xlsx_f in cur_headers:
            self.xlsx_combo.setCurrentText(best_xlsx_f)
        form.addRow("Exceli (.xlsx) ID veerg:", self.xlsx_combo)

        layout.addLayout(form)

        # Live preview box showing matched counts and ignored blank table rows
        self.preview_lbl = QLabel("")
        self.preview_lbl.setWordWrap(True)
        self.preview_lbl.setStyleSheet(
            "background-color: #F8FAFC; color: #334155; border: 1px solid #E2E8F0; "
            "border-radius: 6px; padding: 7px; font-size: 11px;"
        )
        layout.addWidget(self.preview_lbl)

        self.auto_skip_cb = QCheckBox(
            "Ära ava edaspidi seda akent, kui ID veerud tuvastatakse automaatselt"
        )
        self.auto_skip_cb.setChecked(auto_skip_enabled)
        layout.addWidget(self.auto_skip_cb)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton("Loobu")
        cancel_btn.clicked.connect(self.reject)
        ok_btn = QPushButton("Kinnita ja kontrolli ID-sid")
        ok_btn.setDefault(True)
        ok_btn.setStyleSheet(
            "background-color: #0F766E; color: white; font-weight: bold; "
            "padding: 6px 14px; border-radius: 5px;"
        )
        ok_btn.clicked.connect(self.accept)
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(ok_btn)
        layout.addLayout(btn_row)

        self.sheet_combo.currentTextChanged.connect(self._on_sheet_changed)
        self.layer_combo.currentTextChanged.connect(self._update_live_preview)
        self.xlsx_combo.currentTextChanged.connect(self._update_live_preview)
        self._update_live_preview()

    def _on_sheet_changed(self, new_sheet: str):
        sh_data = self.workbook_dict.get(new_sheet, {})
        headers = sh_data.get("headers", [])
        rows = sh_data.get("rows", [])

        self.xlsx_combo.blockSignals(True)
        self.xlsx_combo.clear()
        self.xlsx_combo.addItems(headers)
        if self.layer and headers:
            _, best_xf, _ = auto_detect_id_fields(self.layer, headers, rows)
            if best_xf and best_xf in headers:
                self.xlsx_combo.setCurrentText(best_xf)
        self.xlsx_combo.blockSignals(False)
        self._update_live_preview()

    def _update_live_preview(self):
        if not self.layer:
            return
        lf = self.layer_combo.currentText()
        sh = self.sheet_combo.currentText()
        xf = self.xlsx_combo.currentText()
        if not lf or not sh or not xf:
            return
        rows = self.workbook_dict.get(sh, {}).get("rows", [])
        res = run_step1_id_check(self.layer, lf, rows, xf)

        blank_note = (
            f" <i>(ignoreeriti {res['skipped_blank_xlsx_rows']} tühja tabelirida)</i>"
            if res["skipped_blank_xlsx_rows"] > 0
            else ""
        )
        if res["ok"]:
            self.preview_lbl.setText(
                f"✅ <b>Eelvaade: KORRAS!</b> Kihil <b>{res['layer_total']}</b> ID-d, "
                f"Excelis <b>{res['xlsx_total']}</b> ID-d — klapib <b>{res['matched_unique']}</b> unikaalset ID-d.{blank_note}"
            )
            self.preview_lbl.setStyleSheet(
                "background-color: #F0FDF4; color: #166534; border: 1px solid #86EFAC; "
                "border-radius: 6px; padding: 7px; font-size: 11px;"
            )
        else:
            self.preview_lbl.setText(
                f"⚠️ <b>Eelvaade:</b> Kihil <b>{res['layer_total']}</b> ID-d, "
                f"Excelis <b>{res['xlsx_total']}</b> ID-d (ühiseid: <b>{res['matched_unique']}</b>). "
                f"Puudub Excelis: {len(res['missing_in_xlsx'])} tk, "
                f"puudub kihil: {len(res['missing_in_layer'])} tk.{blank_note}"
            )
            self.preview_lbl.setStyleSheet(
                "background-color: #FEF2F2; color: #991B1B; border: 1px solid #FCA5A5; "
                "border-radius: 6px; padding: 7px; font-size: 11px;"
            )

    def get_selection(self):
        return (
            self.sheet_combo.currentText(),
            self.layer_combo.currentText(),
            self.xlsx_combo.currentText(),
            self.auto_skip_cb.isChecked()
        )


class CalibrationSettingsDialog(QDialog):
    """
    Allows fine-tuning MapInfo 'Check Regions' emulation tolerances, editing Profile 2
    permitted overlap rules, and generating synthetic calibration test data.
    """
    testDataGenerated = pyqtSignal(dict)

    def __init__(self, settings: MapInfoTopologySettings, wfs_url: str, use_offline_wfs: bool, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Seaded (MapInfo kalibreerimine & Profiili reeglid)")
        self.setMinimumWidth(680)
        self.setMinimumHeight(560)
        self.settings = settings

        main_layout = QVBoxLayout(self)

        self.tab_widget = QTabWidget(self)

        # -------------------------------------------------------------
        # Tab 1: MapInfo & EELIS tolerances
        # -------------------------------------------------------------
        tab1 = QWidget()
        tab1_layout = QVBoxLayout(tab1)

        info = QLabel(
            "<b>MapInfo 'Check Regions' täpsusvõrgu seadistamine:</b><br>"
            "MapInfo kasutab täisarvulist koordinaatvõrku (~1 mm), samas kui QGIS/GEOS "
            "kasutab 64-bitiseid ujukomaarve. Siin saad täpsustada parameetreid, et "
            "sammude 3–7 tulemused kattuksid 1:1 MapInfo kontrolliga."
        )
        info.setWordWrap(True)
        info.setStyleSheet(
            "background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 8px; border-radius: 6px;"
        )
        tab1_layout.addWidget(info)

        form = QFormLayout()

        self.snap_spin = QDoubleSpinBox()
        self.snap_spin.setDecimals(4)
        self.snap_spin.setRange(0.0, 0.1)
        self.snap_spin.setSingleStep(0.0005)
        self.snap_spin.setValue(settings.snap_grid_m)
        self.snap_spin.setSuffix(" m (soovituslik 0.0010 m = 1 mm)")
        form.addRow("MapInfo koordinaatvõrgu snap:", self.snap_spin)

        self.max_gap_spin = QDoubleSpinBox()
        self.max_gap_spin.setDecimals(4)
        self.max_gap_spin.setRange(0.0001, 10.0)
        self.max_gap_spin.setSingleStep(0.005)
        self.max_gap_spin.setValue(settings.max_gap_area_ha)
        self.max_gap_spin.setSuffix(" ha (0.01 ha = 100 m²)")
        form.addRow("Samm 3 – Max augu pindala:", self.max_gap_spin)

        self.min_ov_area_spin = QDoubleSpinBox()
        self.min_ov_area_spin.setDecimals(5)
        self.min_ov_area_spin.setRange(0.0, 10.0)
        self.min_ov_area_spin.setSingleStep(0.0001)
        self.min_ov_area_spin.setValue(settings.min_overlap_area_m2)
        self.min_ov_area_spin.setSuffix(" m² (0.0001 m² = 1 cm²)")
        form.addRow("Samm 4 – Min ülekatte pindala:", self.min_ov_area_spin)

        self.min_ov_width_spin = QDoubleSpinBox()
        self.min_ov_width_spin.setDecimals(4)
        self.min_ov_width_spin.setRange(0.0, 1.0)
        self.min_ov_width_spin.setSingleStep(0.0005)
        self.min_ov_width_spin.setValue(settings.min_overlap_width_m)
        self.min_ov_width_spin.setSuffix(" m (välistab < 1 mm ujukoma piirinihked)")
        form.addRow("Samm 4 – Min ülekatte keskm. laius (2A/P):", self.min_ov_width_spin)

        self.short_seg_spin = QDoubleSpinBox()
        self.short_seg_spin.setDecimals(1)
        self.short_seg_spin.setRange(0.1, 1000.0)
        self.short_seg_spin.setValue(settings.short_segment_mm)
        self.short_seg_spin.setSuffix(" mm")
        form.addRow("Samm 6 – Lühikese lõigu piir:", self.short_seg_spin)

        self.angle_spin = QDoubleSpinBox()
        self.angle_spin.setDecimals(1)
        self.angle_spin.setRange(0.1, 90.0)
        self.angle_spin.setValue(settings.small_angle_deg)
        self.angle_spin.setSuffix(" °")
        form.addRow("Samm 7 – Terava nurga piir:", self.angle_spin)

        self.report_mode_combo = QComboBox()
        self.report_mode_combo.addItem(
            "Valik 1 – Täisaruanne (kõik vead, sh WFS-naabrite omavahelised)", 1
        )
        self.report_mode_combo.addItem(
            "Valik 2 – Töödeldud kiht (algne sisend + Tase 2 lisatud naabrid) [Vaikimisi]", 2
        )
        self.report_mode_combo.addItem(
            "Valik 3 – Ainult algne sisendkiht (välista lisatud naabrite välisvead)", 3
        )
        curr_mode = getattr(settings, "error_reporting_mode", 2)
        if not getattr(settings, "only_input_related", True):
            curr_mode = 1
        idx = self.report_mode_combo.findData(curr_mode)
        if idx >= 0:
            self.report_mode_combo.setCurrentIndex(idx)
        else:
            self.report_mode_combo.setCurrentIndex(1)
        form.addRow("Vigade raporteerimise ulatus:", self.report_mode_combo)

        self.wfs_edit = QLineEdit(wfs_url)
        form.addRow("EELIS WFS URL:", self.wfs_edit)

        self.offline_wfs_cb = QCheckBox(
            "Kasuta Sammus 2 kohalikku test-WFS kihti (test_wfs_naabrid)"
        )
        self.offline_wfs_cb.setChecked(use_offline_wfs)
        form.addRow("", self.offline_wfs_cb)

        tab1_layout.addLayout(form)

        gen_btn = QPushButton("🧪 Genereeri ja lae MapInfo kalibreerimise testandmed (Sammud 1–7)...")
        gen_btn.setStyleSheet(
            "background-color: #F0FDF4; color: #166534; border: 1px solid #86EFAC; "
            "border-radius: 6px; padding: 7px; font-weight: 600;"
        )
        gen_btn.clicked.connect(self._on_generate_test_data)
        tab1_layout.addWidget(gen_btn)

        self.tab_widget.addTab(tab1, "⚙ MapInfo & EELIS tolerantsid")

        # -------------------------------------------------------------
        # Tab 2: Profile 2 Allowed Overlaps
        # -------------------------------------------------------------
        tab2 = QWidget()
        tab2_layout = QVBoxLayout(tab2)

        rules_info = QLabel(
            "<b>Profiil 2 elupaigatüüpide lubatud kattuvuste seadistamine:</b><br>"
            "Määra Natura elupaigatüübid (põhitüübid), mille omavahelist kattumist Profiil 2 ei raporteeri veana.<br>"
            "<i>Väärtuste muutmiseks tee lahtril topeltklõps. Uue reegli lisamiseks klõpsa viimasel real või alloleval nupul.</i>"
        )
        rules_info.setWordWrap(True)
        rules_info.setStyleSheet(
            "background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 8px; border-radius: 6px; font-size: 11px;"
        )
        tab2_layout.addWidget(rules_info)

        self.rules_table = QTableWidget()
        self.rules_table.setColumnCount(4)
        self.rules_table.setHorizontalHeaderLabels([
            "Elupaigatüüp", "Lubatud kattuvused", "Kirjeldus", "Toiming"
        ])
        self.rules_table.horizontalHeader().setSectionResizeMode(0, HEADER_INTERACTIVE)
        self.rules_table.horizontalHeader().setSectionResizeMode(1, HEADER_STRETCH)
        self.rules_table.horizontalHeader().setSectionResizeMode(2, HEADER_INTERACTIVE)
        self.rules_table.horizontalHeader().setSectionResizeMode(3, HEADER_FIXED)
        self.rules_table.setColumnWidth(0, 110)
        self.rules_table.setColumnWidth(2, 140)
        self.rules_table.setColumnWidth(3, 80)
        self.rules_table.verticalHeader().setDefaultSectionSize(32)

        self._populate_rules_table(get_profile2_rules())
        self.rules_table.cellClicked.connect(self._on_table_cell_clicked)
        tab2_layout.addWidget(self.rules_table)

        rules_btn_row = QHBoxLayout()
        add_btn = QPushButton("➕ Lisa reegel")
        add_btn.setStyleSheet("font-weight: 600; padding: 5px 12px;")
        add_btn.clicked.connect(self._add_rule_row)
        rules_btn_row.addWidget(add_btn)

        reset_btn = QPushButton("↺ Taasta vaikeväärtused")
        reset_btn.setToolTip("Taasta algsed Natura 2000 elupaikade lubatud kattuvuste reeglid")
        reset_btn.clicked.connect(self._on_reset_rules)
        rules_btn_row.addWidget(reset_btn)
        rules_btn_row.addStretch()

        tab2_layout.addLayout(rules_btn_row)

        self.tab_widget.addTab(tab2, "🌿 Profiil 2 lubatud kattuvused")

        main_layout.addWidget(self.tab_widget)

        # -------------------------------------------------------------
        # Dialog Action Buttons (Cancel / Save)
        # -------------------------------------------------------------
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton("Loobu")
        cancel_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Salvesta seaded")
        save_btn.setStyleSheet(
            "background-color: #0F766E; color: white; font-weight: bold; padding: 6px 14px; border-radius: 5px;"
        )
        save_btn.clicked.connect(self.accept)
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        main_layout.addLayout(btn_row)

    def _populate_rules_table(self, rules: list):
        self.rules_table.setRowCount(0)
        for r_idx, rule in enumerate(rules):
            self._insert_rule_row(r_idx, rule.get("source", ""), rule.get("allowed", ""), rule.get("description", ""))
        self._append_add_placeholder_row()

    def _insert_rule_row(self, row: int, source: str, allowed: str, description: str):
        self.rules_table.insertRow(row)

        item_src = QTableWidgetItem(str(source))
        item_src.setTextAlignment(ALIGN_CENTER)
        self.rules_table.setItem(row, 0, item_src)

        item_alwd = QTableWidgetItem(str(allowed))
        self.rules_table.setItem(row, 1, item_alwd)

        item_desc = QTableWidgetItem(str(description))
        self.rules_table.setItem(row, 2, item_desc)

        del_btn = QPushButton("Kustuta")
        del_btn.setStyleSheet(
            "background-color: #FEE2E2; color: #DC2626; border: 1px solid #FCA5A5; "
            "border-radius: 4px; padding: 2px 6px; font-size: 11px; font-weight: 600;"
        )
        del_btn.clicked.connect(lambda checked, b=del_btn: self._delete_rule_row(b))
        self.rules_table.setCellWidget(row, 3, del_btn)

    def _append_add_placeholder_row(self):
        last_row = self.rules_table.rowCount()
        self.rules_table.insertRow(last_row)

        item_add = QTableWidgetItem("➕ Lisa reegel")
        item_add.setTextAlignment(ALIGN_CENTER)
        item_add.setFlags(ITEM_ENABLED | ITEM_SELECTABLE)
        font = item_add.font()
        font.setBold(True)
        item_add.setFont(font)
        item_add.setForeground(QColor("#15803D"))
        self.rules_table.setItem(last_row, 0, item_add)

        item_hint = QTableWidgetItem("(Klõpsa siia uue reegli lisamiseks)")
        item_hint.setFlags(ITEM_ENABLED | ITEM_SELECTABLE)
        item_hint.setForeground(QColor("#64748B"))
        self.rules_table.setItem(last_row, 1, item_hint)

        item_empty = QTableWidgetItem("")
        item_empty.setFlags(NO_ITEM_FLAGS)
        self.rules_table.setItem(last_row, 2, item_empty)

    def _on_table_cell_clicked(self, row, col):
        if row == self.rules_table.rowCount() - 1:
            self._add_rule_row()

    def _add_rule_row(self):
        target_row = max(0, self.rules_table.rowCount() - 1)
        self._insert_rule_row(target_row, "", "", "")
        self.rules_table.setCurrentCell(target_row, 0)
        item = self.rules_table.item(target_row, 0)
        if item:
            self.rules_table.editItem(item)

    def _delete_rule_row(self, btn):
        for r in range(self.rules_table.rowCount() - 1):
            if self.rules_table.cellWidget(r, 3) is btn:
                self.rules_table.removeRow(r)
                break

    def _on_reset_rules(self):
        reply = QMessageBox.question(
            self,
            "Taasta vaikeväärtused",
            "Kas soovid taastada Profiil 2 esialgsed ametlikud kattuvusreeglid?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self._populate_rules_table(DEFAULT_PROFILE2_RULES)

    def _on_generate_test_data(self):
        folder = QFileDialog.getExistingDirectory(self, "Vali kaust testandmete salvestamiseks")
        if not folder:
            return
        paths = generate_calibration_dataset(folder)
        self.offline_wfs_cb.setChecked(True)
        self.testDataGenerated.emit(paths)
        msg = (
            f"Testandmed loodi kausta:\n{folder}\n\n"
            "• test_sisend.geojson (sisendkiht kõigi sammude 3-7 kontrolljuhtudega)\n"
            "• test_wfs_naabrid.geojson (WFS naabrid + vana ELU_101 asendamiseks)\n"
            "• test_andmed_korras.xlsx (mitme töölehe ja tühjade tabeliridadega 100% klappiv Excel)\n"
            "• test_andmed_veaga.xlsx (vigadega Excel Sammu 1 testimiseks)\n\n"
            "Kiht ja Excel laeti automaatselt pistikprogrammi akendesse!"
        )
        QMessageBox.information(self, "Testandmed loodud", msg)
        self.accept()

    def apply_to_settings(self):
        self.settings.snap_grid_m = self.snap_spin.value()
        self.settings.max_gap_area_ha = self.max_gap_spin.value()
        self.settings.min_overlap_area_m2 = self.min_ov_area_spin.value()
        self.settings.min_overlap_width_m = self.min_ov_width_spin.value()
        self.settings.short_segment_mm = self.short_seg_spin.value()
        self.settings.small_angle_deg = self.angle_spin.value()
        mode = self.report_mode_combo.currentData()
        self.settings.error_reporting_mode = mode
        self.settings.only_input_related = (mode in (2, 3))

        # Collect and save Profile 2 rules
        new_rules = []
        for r in range(self.rules_table.rowCount() - 1):
            it0 = self.rules_table.item(r, 0)
            it1 = self.rules_table.item(r, 1)
            it2 = self.rules_table.item(r, 2)
            src = it0.text().strip() if it0 else ""
            alwd = it1.text().strip() if it1 else ""
            desc = it2.text().strip() if it2 else ""
            if src and alwd:
                new_rules.append({"source": src, "allowed": alwd, "description": desc})

        save_profile2_rules(new_rules)
        self.settings.profile2_rules = new_rules

        return self.wfs_edit.text().strip(), self.offline_wfs_cb.isChecked()


class ExportDialog(QDialog):
    """Dialog for exporting results to GPKG and XLSX."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ekspordi tulemused")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        
        info = QLabel(
            "Vali salvestuskoht. Töökiht ja kõik leitud vead (Augud, Ülekatted jne) "
            "salvestatakse ühte GeoPackage (.gpkg) faili."
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        
        self.xlsx_cb = QCheckBox("Salvesta lisaks ka Exceli (.xlsx) aruanne")
        self.xlsx_cb.setChecked(False)
        layout.addWidget(self.xlsx_cb)
        
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton("Loobu")
        cancel_btn.clicked.connect(self.reject)
        
        export_btn = QPushButton("Vali sihtkaust ja ekspordi...")
        export_btn.setStyleSheet("background-color: #0F766E; color: white; font-weight: bold; padding: 6px 14px; border-radius: 5px;")
        export_btn.clicked.connect(self.accept)
        
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(export_btn)
        layout.addLayout(btn_row)
        
    def wants_xlsx(self) -> bool:
        return self.xlsx_cb.isChecked()

class AutoFixDialog(QDialog):
    def __init__(self, max_gap_ha=0.01, max_overlap_m2=5.0, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Paranda automaatselt")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        
        info = QLabel(
            "<b>Automaatne parandamine:</b><br>"
            "Katsetab leitud aukude ja ülekatete parandamist boole'i operatsioonidega "
            "(combine, difference). Vali sobiv tase:"
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # Levels
        from qgis.PyQt.QtWidgets import QRadioButton, QButtonGroup
        self.btn_group = QButtonGroup(self)
        
        self.rbtn_level1 = QRadioButton("Tase 1: Muuda ainult sisendkihti (Ohutu)")
        self.rbtn_level1.setChecked(True)
        self.rbtn_level1.setToolTip("Lisab augud ja lahutab ülekatted ainult sisendkihi polügoonidest. WFS naabreid ei muudeta.")
        self.btn_group.addButton(self.rbtn_level1, 1)
        layout.addWidget(self.rbtn_level1)
        
        self.rbtn_level2 = QRadioButton("Tase 2: Muuda vajadusel ka WFS naabreid")
        self.rbtn_level2.setToolTip("Lubab lõigata või liita ka WFS naabrite kujusid. Ekspordib parandatud tulemuse uue sisendina.")
        self.btn_group.addButton(self.rbtn_level2, 2)
        layout.addWidget(self.rbtn_level2)
        
        # Limits
        form = QFormLayout()
        
        self.gap_spin = QDoubleSpinBox()
        self.gap_spin.setDecimals(4)
        self.gap_spin.setRange(0.0001, 100.0)
        self.gap_spin.setValue(max_gap_ha)
        self.gap_spin.setSuffix(" ha")
        form.addRow("Maksimaalne parandatav auk:", self.gap_spin)
        
        self.over_spin = QDoubleSpinBox()
        self.over_spin.setDecimals(2)
        self.over_spin.setRange(0.01, 10000.0)
        self.over_spin.setValue(max_overlap_m2)
        self.over_spin.setSuffix(" m²")
        form.addRow("Maksimaalne parandatav ülekate:", self.over_spin)
        
        layout.addLayout(form)
        
        
        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton("Loobu")
        cancel_btn.clicked.connect(self.reject)
        
        fix_btn = QPushButton("🪄 Paranda")
        fix_btn.setStyleSheet("background-color: #0F766E; color: white; font-weight: bold; padding: 6px 14px; border-radius: 5px;")
        fix_btn.clicked.connect(self.accept)
        
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(fix_btn)
        layout.addLayout(btn_row)
        
    def get_settings(self):
        return {
            "level": self.btn_group.checkedId(),
            "max_gap_ha": self.gap_spin.value(),
            "max_overlap_m2": self.over_spin.value()
        }
