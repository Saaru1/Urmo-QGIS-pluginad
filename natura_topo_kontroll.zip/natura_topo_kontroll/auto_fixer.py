# -*- coding: utf-8 -*-
"""
Auto-Fixer Module
Attempts to resolve topology errors with MINIMAL EDITS to satisfy official requirements:
- Only features with verified topology errors are inspected and modified.
- Innocent features (features with zero errors) remain 100% untouched byte-for-byte.
- Level 1: Only input features are modified. WFS neighbors are never touched.
- Level 2: Only touches a WFS neighbor if that specific neighbor shares an unresolved
  error with an input feature.
- Boolean operations (difference for overlaps, combine for gaps) are applied safely
  to single targets to avoid creating new holes.
- Vertex cleanup uses canonical cluster snapping to ensure shared boundaries stay coincident.
"""

from qgis.core import (
    QgsFeature, QgsGeometry, QgsProject, QgsVectorLayer,
    QgsVectorFileWriter, QgsMemoryProviderUtils, QgsSpatialIndex, QgsPointXY, QgsWkbTypes, QgsFields
)
from .qt_compat import extract_polygon_parts, extract_rings_as_point_lists
import os
import math


def _to_pure_multipolygon(geom):
    """
    Ensures geometry is a strict MultiPolygon XY, stripping GeometryCollection/dangling lines.
    """
    if geom.isNull() or geom.isEmpty():
        return geom
    try:
        parts = extract_polygon_parts(geom)
        polys = [p.asPolygon() for p in parts if p.asPolygon()]
        if polys:
            return QgsGeometry.fromMultiPolygonXY(polys)
    except Exception:
        pass
    return geom


def _remove_acute_spikes(geom, max_spike_angle=1.0):
    """
    Removes acute spikes (backtracking needles / hairpin vertices where angle <= max_spike_angle).
    Does not unpick general polygon corners.
    """
    if geom.isNull() or geom.isEmpty():
        return geom
    try:
        parts = extract_polygon_parts(geom)
    except Exception:
        return geom

    new_parts = []
    for p in parts:
        rings = p.asPolygon()
        new_rings = []
        for ring in rings:
            if len(ring) < 4:
                continue
            cur = list(ring[:-1])
            changed = True
            iter_cnt = 0
            while changed and len(cur) >= 3 and iter_cnt < 10:
                changed = False
                iter_cnt += 1
                n = len(cur)
                for i in range(n):
                    p_prev = cur[(i - 1) % n]
                    p_curr = cur[i]
                    p_next = cur[(i + 1) % n]
                    v1x, v1y = p_prev.x() - p_curr.x(), p_prev.y() - p_curr.y()
                    v2x, v2y = p_next.x() - p_curr.x(), p_next.y() - p_curr.y()
                    len1 = math.hypot(v1x, v1y)
                    len2 = math.hypot(v2x, v2y)
                    if len1 < 1e-9 or len2 < 1e-9:
                        cur.pop(i)
                        changed = True
                        break
                    cos_theta = max(-1.0, min(1.0, (v1x * v2x + v1y * v2y) / (len1 * len2)))
                    angle = math.degrees(math.acos(cos_theta))
                    if angle <= max_spike_angle:
                        cur.pop(i)
                        changed = True
                        break
            if len(cur) >= 3:
                cur.append(cur[0])
                new_rings.append(cur)
        if new_rings:
            new_parts.append(QgsGeometry.fromPolygonXY(new_rings))
    if new_parts:
        return QgsGeometry.collectGeometry(new_parts)
    return geom


def _cluster_clean_short_segments(geoms_dict, wfs_points, min_dist=0.021, max_iter=5):
    """
    Synchronized canonical cluster cleaning for short segments (< 20 mm).
    Replaces adjacent nodes closer than min_dist with a single canonical coordinate
    across ALL affected target geometries simultaneously.
    Prioritizes keeping WFS points to prevent pulling boundaries away from official neighbors.
    """
    cur_geoms = {k: QgsGeometry(v) for k, v in geoms_dict.items()}
    min_sq = min_dist * min_dist

    for _ in range(max_iter):
        replacements = {}
        for fid, geom in cur_geoms.items():
            for ring in extract_rings_as_point_lists(geom):
                n = len(ring)
                for i in range(n - 1):
                    p1 = ring[i]
                    p2 = ring[i + 1]
                    dist_sq = (p1.x() - p2.x())**2 + (p1.y() - p2.y())**2
                    if dist_sq < min_sq:
                        k1 = (round(p1.x(), 3), round(p1.y(), 3))
                        k2 = (round(p2.x(), 3), round(p2.y(), 3))
                        if k1 != k2:
                            while k1 in replacements:
                                k1 = replacements[k1]
                            while k2 in replacements:
                                k2 = replacements[k2]
                            if k1 != k2:
                                if k1 in wfs_points and k2 not in wfs_points:
                                    keeper, loser = k1, k2
                                elif k2 in wfs_points and k1 not in wfs_points:
                                    keeper, loser = k2, k1
                                else:
                                    keeper, loser = min(k1, k2), max(k1, k2)
                                replacements[loser] = keeper

        if not replacements:
            break

        for fid, geom in cur_geoms.items():
            parts = extract_polygon_parts(geom)
            new_parts = []
            for p in parts:
                rings = p.asPolygon()
                new_rings = []
                for ring in rings:
                    new_ring = []
                    for pt in ring:
                        k = (round(pt.x(), 3), round(pt.y(), 3))
                        while k in replacements:
                            k = replacements[k]
                        new_pt = QgsPointXY(k[0], k[1])
                        if not new_ring or (new_pt.x() != new_ring[-1].x() or new_pt.y() != new_ring[-1].y()):
                            new_ring.append(new_pt)
                    if len(new_ring) >= 1 and (new_ring[0].x() != new_ring[-1].x() or new_ring[0].y() != new_ring[-1].y()):
                        new_ring.append(new_ring[0])
                    if len(new_ring) >= 4:
                        new_rings.append(new_ring)
                if new_rings:
                    new_parts.append(QgsGeometry.fromPolygonXY(new_rings))
            if new_parts:
                cur_geoms[fid] = QgsGeometry.collectGeometry(new_parts).makeValid()

    return cur_geoms


def _clean_poly_geometry(geom, min_ring_area=0.01, max_spike_angle=1.0):
    """
    Cleans polygon geometry after boolean difference / union / snapping:
    1. Repairs invalid geometries via makeValid() and removes identical consecutive nodes (0.5 mm).
    2. Drops degenerate interior rings (holes) whose area is smaller than min_ring_area (< 0.01 m2).
       GEOS boolean operations can leave sub-millimeter sliver holes which trigger database topology errors.
    3. Prunes acute spike vertices / hairpin turnarounds (angle <= max_spike_angle).
    4. Drops tiny disconnected sliver polygons (< 0.1 m2).
    5. Returns strict MultiPolygon XY.
    """
    if geom.isNull() or geom.isEmpty():
        return geom
    try:
        vg = geom.makeValid()
        vg.removeDuplicateNodes(0.0005, True)
        parts = extract_polygon_parts(vg)
    except Exception:
        return geom

    new_parts = []
    for p in parts:
        if p.area() < 0.1:
            continue
        rings = p.asPolygon()
        if not rings:
            continue
        ext_ring = rings[0]
        valid_holes = []
        for h in rings[1:]:
            h_geom = QgsGeometry.fromPolygonXY([h])
            if h_geom.area() >= min_ring_area:
                valid_holes.append(h)
        clean_poly = QgsGeometry.fromPolygonXY([ext_ring] + valid_holes)
        clean_poly = _remove_acute_spikes(clean_poly, max_spike_angle=max_spike_angle)
        clean_poly.removeDuplicateNodes(0.0005, True)
        if clean_poly.area() >= 0.1:
            new_parts.append(clean_poly)

    if new_parts:
        res = QgsGeometry.collectGeometry(new_parts).makeValid()
        res.removeDuplicateNodes(0.0005, True)
        return _to_pure_multipolygon(res)
    return geom


def run_auto_fix(work_layer, error_layers, level=1, max_gap_ha=0.01, max_overlap_m2=100.0, progress_callback=None):
    """
    Executes automated topology repair.
    - level=1: Minimal edits to input features only; WFS neighbors are never touched.
    - level=2: Minimal edits, touches WFS neighbors only when strictly necessary to fix an input error.
    Returns: (fix_count, added_wfs_ids)
    """
    def _report(pct, msg=""):
        if progress_callback:
            try:
                progress_callback(pct, msg)
            except TypeError:
                progress_callback(pct)

    _report(5, "Ettevalmistus ja vigadega seotud objektide tuvastamine...")
    pr = work_layer.dataProvider()
    allikas_idx = work_layer.fields().indexOf("_allikas")
    
    feats = {f.id(): QgsFeature(f) for f in work_layer.getFeatures()}
    all_ids = {f.id(): str(f["_kontroll_id"]) for f in work_layer.getFeatures()}
    all_src = {f.id(): str(f["_allikas"]) for f in work_layer.getFeatures()}
    
    modified_geoms = {}
    gap_filled_fids = set()
    overlap_modified_fids = set()
    added_wfs_ids = []

    def is_input(allikas):
        return allikas in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM")

    def cur_g(fid):
        return modified_geoms.get(fid, feats[fid].geometry())

    s_idx = QgsSpatialIndex(work_layer.getFeatures())

    # Build reference set of WFS vertices to snap against
    wfs_points = set()
    for fid, feat in feats.items():
        if all_src[fid] == "WFS":
            for r in extract_rings_as_point_lists(feat.geometry()):
                for pt in r:
                    wfs_points.add((round(pt.x(), 3), round(pt.y(), 3)))

    # CRITICAL: STRICT MINIMAL EDITS FILTER
    # Only features that participate in an identified error may be inspected or modified.
    error_fids = set()
    for err_name in ["Sõlmed", "Lühikesed lõigud", "Teravad nurgad"]:
        lyr = error_layers.get(err_name)
        if lyr:
            for ef in lyr.getFeatures():
                oid = str(ef["obj_id"])
                for fid, feat_oid in all_ids.items():
                    if feat_oid == oid:
                        if is_input(all_src[fid]):
                            error_fids.add(fid)

    for err_name in ["Augud", "Ülekatted"]:
        lyr = error_layers.get(err_name)
        if lyr:
            for ef in lyr.getFeatures():
                eg = ef.geometry()
                bbox = eg.boundingBox()
                bbox.grow(0.1)
                for fid in s_idx.intersects(bbox):
                    if is_input(all_src[fid]) and feats[fid].geometry().intersects(eg.buffer(0.01, 3)):
                        error_fids.add(fid)

    if not error_fids:
        _report(100, "Parandatavaid vigu ei leitud.")
        return 0, []

    # PHASE 1: SKELETON CLEANUP on error input features
    # 1. Knot isolation, duplicate removal, spike removal
    _report(15, "Faas 1: Sõlmede ja duplikaatide eemaldamine...")
    for fid in error_fids:
        g = cur_g(fid)
        vg = _clean_poly_geometry(g, min_ring_area=0.01, max_spike_angle=5.0)
        if vg.asWkb() != feats[fid].geometry().asWkb():
            modified_geoms[fid] = vg

    # 2. Synchronized canonical cluster clean for short segments (< 20 mm)
    _report(35, "Faas 1: Lühikeste lõikude klastripõhine rihtimine...")
    cur_geoms = {fid: cur_g(fid) for fid in error_fids}
    cleaned_geoms = _cluster_clean_short_segments(cur_geoms, wfs_points, min_dist=0.021, max_iter=5)
    for fid, res_g in cleaned_geoms.items():
        if res_g.asWkb() != feats[fid].geometry().asWkb():
            modified_geoms[fid] = res_g

    # PHASE 2: OVERLAPS
    _report(50, "Faas 2: Ülekatete lahendamine...")
    lyr_over = error_layers.get("Ülekatted")
    if lyr_over:
        for f in lyr_over.getFeatures():
            if f["pindala_m2"] > max_overlap_m2:
                continue
            err_g = f.geometry()
            bbox = err_g.boundingBox()
            bbox.grow(0.1)
            target_fids = [
                fid for fid in s_idx.intersects(bbox)
                if cur_g(fid).intersects(err_g)
            ]
            # In Level 1: trim only input features
            # In Level 2: trim input feature first; if between WFS and input where WFS should be trimmed, handle WFS
            trimmed = False
            for fid in target_fids:
                if is_input(all_src[fid]):
                    diff = cur_g(fid).difference(err_g)
                    if not diff.isNull() and not diff.isEmpty():
                        diff = _clean_poly_geometry(diff, min_ring_area=0.01, max_spike_angle=1.0)
                        if diff.area() >= 0.1:
                            modified_geoms[fid] = diff
                            overlap_modified_fids.add(fid)
                            trimmed = True
                            break
            
            if not trimmed and level == 2:
                for fid in target_fids:
                    if all_src[fid] in ("WFS", "PARANDATUD_NAABER"):
                        diff = cur_g(fid).difference(err_g)
                        if not diff.isNull() and not diff.isEmpty():
                            diff = _clean_poly_geometry(diff, min_ring_area=0.01, max_spike_angle=1.0)
                            if diff.area() >= 0.1:
                                modified_geoms[fid] = diff
                                overlap_modified_fids.add(fid)
                                if str(feats[fid]["_kontroll_id"]) not in added_wfs_ids:
                                    added_wfs_ids.append(str(feats[fid]["_kontroll_id"]))
                                break

    # PHASE 3: GAPS
    _report(70, "Faas 3: Aukude sulatamine...")
    lyr_gap = error_layers.get("Augud")
    if lyr_gap:
        wfs_gaps = {}
        for f in lyr_gap.getFeatures():
            if f["pindala_ha"] > max_gap_ha:
                continue
            err_g = f.geometry()
            bbox = err_g.boundingBox()
            bbox.grow(0.1)
            target_fids = [
                fid for fid in s_idx.intersects(bbox)
                if cur_g(fid).intersects(err_g.buffer(0.01, 3))
            ]

            # In Level 2: if gap touches a WFS neighbor, assign it to that WFS neighbor.
            # Level 2 is allowed to add the neighbor to the edited features layer and snap/seal the gap.
            if level == 2:
                wfs_targets = [fid for fid in target_fids if all_src[fid] in ("WFS", "PARANDATUD_NAABER")]
                if wfs_targets:
                    # Pick WFS neighbor with largest shared boundary
                    if len(wfs_targets) > 1:
                        wfs_targets.sort(
                            key=lambda fid: cur_g(fid).intersection(err_g.buffer(0.01, 3)).area(),
                            reverse=True
                        )
                    w_fid = wfs_targets[0]
                    wfs_gaps.setdefault(w_fid, []).append(err_g)
                    continue

            # Otherwise (Level 1, or Level 2 gap purely between input features):
            # Absorb into the touching input feature
            for fid in target_fids:
                if is_input(all_src[fid]):
                    comb = cur_g(fid).combine(err_g)
                    if not comb.isNull() and not comb.isEmpty():
                        comb = _clean_poly_geometry(comb.snappedToGrid(0.001, 0.001), min_ring_area=0.01, max_spike_angle=1.0)
                        if comb.area() >= 0.1:
                            modified_geoms[fid] = comb
                            gap_filled_fids.add(fid)
                            break

        # In Level 2: Process all WFS neighbors that have absorbed gaps
        if level == 2 and wfs_gaps:
            _report(85, "Faas 3: Topoloogiline kleepimine (Snapping)...")
            ref_lyr = QgsMemoryProviderUtils.createMemoryLayer(
                "ref_inputs", QgsFields(), QgsWkbTypes.MultiPolygon, work_layer.crs()
            )
            ref_feats = []
            for fid, feat in feats.items():
                if is_input(all_src[fid]):
                    rf = QgsFeature()
                    g = _to_pure_multipolygon(cur_g(fid))
                    if not g.isNull() and not g.isEmpty():
                        rf.setGeometry(g)
                        ref_feats.append(rf)
            ref_lyr.dataProvider().addFeatures(ref_feats)

            from qgis.analysis import QgsGeometrySnapper
            snapper = QgsGeometrySnapper(ref_lyr)

            for w_fid, g_list in wfs_gaps.items():
                orig_w_geom = cur_g(w_fid)
                comb_wfs = QgsGeometry.unaryUnion([orig_w_geom] + g_list)
                if not comb_wfs.isNull() and not comb_wfs.isEmpty():
                    clean_comb = _clean_poly_geometry(comb_wfs.snappedToGrid(0.001, 0.001), min_ring_area=0.01, max_spike_angle=1.0)
                    
                    # Snap to adjacent input features (5 cm tolerance) to perfectly close micro-gaps and align shared boundary
                    snapped_comb = snapper.snapGeometry(clean_comb, 0.05, QgsGeometrySnapper.PreferClosest)
                    if not snapped_comb.isNull() and not snapped_comb.isEmpty():
                        comb_wfs = _clean_poly_geometry(snapped_comb.snappedToGrid(0.001, 0.001), min_ring_area=0.01, max_spike_angle=1.0)
                    else:
                        comb_wfs = clean_comb

                    if comb_wfs.area() >= 0.1:
                        modified_geoms[w_fid] = comb_wfs
                        gap_filled_fids.add(w_fid)
                        wfs_id = str(feats[w_fid]["_kontroll_id"])
                        if wfs_id not in added_wfs_ids:
                            added_wfs_ids.append(wfs_id)

    # PHASE 4: SEAM & SEGMENT CLEANUP (eliminate zero-width seams and short segments on modified polygons)
    _report(92, "Faas 4: Piiriõmbluste ja mikro-lõikude viimistlus...")
    all_touched = gap_filled_fids.union(overlap_modified_fids)
    for fid in list(all_touched):
        g = cur_g(fid)
        modified_geoms[fid] = _clean_poly_geometry(g, min_ring_area=0.01, max_spike_angle=1.0)

    # Clean any tiny segments (< 20 mm) introduced by gap absorption or overlap trimming
    if all_touched:
        touched_geoms = {fid: cur_g(fid) for fid in all_touched}
        cleaned_touched_geoms = _cluster_clean_short_segments(touched_geoms, wfs_points, min_dist=0.021, max_iter=3)
        for fid, res_g in cleaned_touched_geoms.items():
            modified_geoms[fid] = _clean_poly_geometry(res_g, min_ring_area=0.01, max_spike_angle=1.0)

    # Filter: strictly keep only features whose WKB actually changed
    final_modified = {}
    for fid, g in modified_geoms.items():
        if g.asWkb() != feats[fid].geometry().asWkb():
            final_modified[fid] = g

    if not final_modified:
        _report(100, "Ühtegi muudatust ei tehtud.")
        return 0, []

    # Update layer in-place
    _report(97, "Töökihi geomeetriate ja atribuutide uuendamine...")
    geom_map = {}
    attr_map = {}
    for fid, geom in final_modified.items():
        geom_map[fid] = _to_pure_multipolygon(geom)
        orig_allikas = str(feats[fid].attribute("_allikas"))
        if orig_allikas in ("WFS", "PARANDATUD_NAABER"):
            new_allikas = "PARANDATUD_NAABER"
            wfs_id = str(feats[fid]["_kontroll_id"])
            if wfs_id not in added_wfs_ids:
                added_wfs_ids.append(wfs_id)
        elif orig_allikas == "PARANDATUD_GEOM":
            new_allikas = "PARANDATUD_GEOM"
        else:
            new_allikas = "PARANDATUD_GEOM" if fid in gap_filled_fids else "PARANDATUD_SISEND"
        attr_map[fid] = {allikas_idx: new_allikas}

    pr.changeGeometryValues(geom_map)
    pr.changeAttributeValues(attr_map)
    work_layer.updateExtents()
    work_layer.triggerRepaint()

    _report(100, f"Automaatparandus valmis: muudeti {len(final_modified)} objekti!")
    return len(final_modified), added_wfs_ids


def append_wfs_to_excel(original_xlsx_path, new_xlsx_path, wfs_ids, id_col_name=None, sheet_name=None, wfs_kr_map=None):
    """
    Appends newly modified WFS neighbor IDs to the Excel table for Level 2 export.
    Smartly detects the true column header row (which may not be row 1, e.g. row 2)
    and writes immediately below the last non-empty data row in the ID column,
    preventing rows from being appended at row 1482 of pre-allocated templates.
    """
    try:
        import openpyxl
        import re
        from .step1_id_check import normalize_id_value

        wb = openpyxl.load_workbook(original_xlsx_path)
        if sheet_name and sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
        else:
            ws = wb.active

        # 1. Locate the true column header row (scan first 15 rows for max non-empty cells)
        header_row_idx = 1
        max_non_empty = 0
        best_headers = []

        scan_limit = min(ws.max_row, 15)
        for r_idx in range(1, scan_limit + 1):
            row_vals = [ws.cell(row=r_idx, column=c).value for c in range(1, ws.max_column + 1)]
            non_empty = [v for v in row_vals if v is not None and str(v).strip() != ""]
            if len(non_empty) > max_non_empty:
                max_non_empty = len(non_empty)
                header_row_idx = r_idx
                best_headers = row_vals

        if not best_headers:
            best_headers = [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]

        # 2. Find ID column index and Märkus column index
        id_col_idx = 1
        markus_col_idx = None

        clean_headers = [str(v).strip() if v is not None else "" for v in best_headers]
        if id_col_name:
            for idx, h in enumerate(clean_headers, start=1):
                if h.lower() == str(id_col_name).strip().lower():
                    id_col_idx = idx
                    break

        if id_col_idx == 1:
            for idx, h in enumerate(clean_headers, start=1):
                if any(k in h.lower() for k in ("järjekorranumber", "kood", "obj_id", "id")):
                    id_col_idx = idx
                    break

        for idx, h in enumerate(clean_headers, start=1):
            if "märkus" in h.lower() or "markus" in h.lower() or "kommentaar" in h.lower():
                markus_col_idx = idx
                break

        pan_col_idx = None
        for idx, h in enumerate(clean_headers, start=1):
            if any(k in h.lower() for k in ("pän", "pan", "kr_kood", "pärandniit")):
                pan_col_idx = idx
                break

        # 3. Find the actual last data row by scanning down the ID column
        existing_ids = set()
        last_data_row = header_row_idx
        for r in range(header_row_idx + 1, ws.max_row + 1):
            val = ws.cell(row=r, column=id_col_idx).value
            norm_val = normalize_id_value(val)
            if norm_val != "":
                last_data_row = r
                existing_ids.add(norm_val)

        # 4. Insert only new IDs immediately below last_data_row
        curr_row = last_data_row + 1
        new_ids = [w for w in sorted(list(set(wfs_ids))) if normalize_id_value(w) not in existing_ids]

        for wfs_id in new_ids:
            # Preserve integer type if numeric
            val_to_write = int(wfs_id) if str(wfs_id).lstrip("-").isdigit() else wfs_id
            ws.cell(row=curr_row, column=id_col_idx, value=val_to_write)
            if markus_col_idx:
                ws.cell(row=curr_row, column=markus_col_idx, value="Auto-lisatud Naaber (Tase 2)")
            if pan_col_idx:
                has_kr = False
                if wfs_kr_map:
                    kr_val = wfs_kr_map.get(str(wfs_id), "")
                    if kr_val and str(kr_val).strip() != "" and str(kr_val).strip().upper() not in ("EI", "NO", "NONE", "0", "FALSE"):
                        has_kr = True
                ws.cell(row=curr_row, column=pan_col_idx, value="JAH" if has_kr else "EI")
            curr_row += 1

        # 5. Update any table definitions if present
        for tbl in ws.tables.values():
            m = re.match(r"([A-Z]+)(\d+):([A-Z]+)(\d+)", tbl.ref)
            if m:
                c1, r1, c2, r2 = m.groups()
                if int(r2) < curr_row - 1:
                    tbl.ref = f"{c1}{r1}:{c2}{curr_row - 1}"

        # 6. Update autofilter if present
        if ws.auto_filter and ws.auto_filter.ref:
            m = re.match(r"([A-Z]+)(\d+):([A-Z]+)(\d+)", ws.auto_filter.ref)
            if m:
                c1, r1, c2, r2 = m.groups()
                if int(r2) < curr_row - 1:
                    ws.auto_filter.ref = f"{c1}{r1}:{c2}{curr_row - 1}"

        wb.save(new_xlsx_path)
        return True
    except Exception as e:
        import traceback
        traceback.print_exc()
        import shutil
        shutil.copy2(original_xlsx_path, new_xlsx_path)
        return False
