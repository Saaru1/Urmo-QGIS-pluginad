# -*- coding: utf-8 -*-
def classFactory(iface):
    from .plugin import NaturaTopoKontrollPlugin
    return NaturaTopoKontrollPlugin(iface)
