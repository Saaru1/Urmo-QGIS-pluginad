# -*- coding: utf-8 -*-
"""
Generates synthetic calibration & test datasets (EPSG:3301) for fine-tuning
Natura Topo Kontroll against MapInfo 'Check Regions' rules.
"""

import os
import json


def generate_calibration_dataset(output_dir: str) -> dict:
    os.makedirs(output_dir, exist_ok=True)
    bx, by = 542000.0, 6452000.0

    elu_101_ext = [
        [bx, by],
        [bx + 100.0, by],
        [bx + 100.0, by + 50.0],
        [bx + 100.0, by + 100.0],
        [bx, by + 100.0],
        [bx, by]
    ]
    elu_101_hole_small = [
        [bx + 20.0, by + 20.0],
        [bx + 26.0, by + 20.0],
        [bx + 26.0, by + 27.5],
        [bx + 20.0, by + 27.5],
        [bx + 20.0, by + 20.0]
    ]
    elu_101_hole_large = [
        [bx + 50.0, by + 50.0],
        [bx + 60.0, by + 50.0],
        [bx + 60.0, by + 65.0],
        [bx + 50.0, by + 65.0],
        [bx + 50.0, by + 50.0]
    ]

    elu_102_ext = [
        [bx + 100.0, by],
        [bx + 200.0, by],
        [bx + 201.0, by + 40.0],
        [bx + 200.0, by + 47.0],
        [bx + 200.0, by + 100.0],
        [bx + 100.0, by + 100.0],
        [bx + 100.0, by + 75.0],
        [bx + 100.5, by + 75.0],
        [bx + 100.5, by + 25.0],
        [bx + 100.0, by + 25.0],
        [bx + 100.0, by]
    ]

    sy = by - 120.0
    elu_103_ext = [
        [bx, sy],
        [bx + 40.0, sy],
        [bx + 40.0125, sy],
        [bx + 40.0405, sy],
        [bx + 80.0, sy],
        [bx + 80.0, sy + 40.0],
        [bx + 85.0, sy + 50.0],
        [bx + 75.0, sy + 50.0],
        [bx + 80.0, sy + 60.0],
        [bx + 80.0, sy + 90.0],
        [bx + 50.25, sy + 90.0],
        [bx + 50.0, sy + 100.0],
        [bx + 49.75, sy + 90.0],
        [bx, sy + 90.0],
        [bx, sy]
    ]

    sisend_geojson = {
        "type": "FeatureCollection",
        "name": "test_sisend",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:EPSG::3301"}},
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "id": "ELU_101",
                    "elupaiga_tyyp": "6210",
                    "märkus": "Sisaldab 45m2 auku (<0.01ha) ja 150m2 auku (>0.01ha)"
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [elu_101_ext, elu_101_hole_small, elu_101_hole_large]
                }
            },
            {
                "type": "Feature",
                "properties": {
                    "id": "ELU_102",
                    "elupaiga_tyyp": "6450",
                    "märkus": "25m2 vahe ELU_101-ga ja ülekate WFS_201-ga"
                },
                "geometry": {"type": "Polygon", "coordinates": [elu_102_ext]}
            },
            {
                "type": "Feature",
                "properties": {
                    "id": "ELU_103",
                    "elupaiga_tyyp": "9010",
                    "märkus": "Sõlm (eneselõikumine), 12.5mm lõik ja 2.86° teravnurk"
                },
                "geometry": {"type": "Polygon", "coordinates": [elu_103_ext]}
            }
        ]
    }

    sisend_path = os.path.join(output_dir, "test_sisend.geojson")
    with open(sisend_path, "w", encoding="utf-8") as f:
        json.dump(sisend_geojson, f, ensure_ascii=False, indent=2)

    wfs_old_101 = [
        [bx, by],
        [bx + 95.0, by],
        [bx + 95.0, by + 95.0],
        [bx, by + 95.0],
        [bx, by]
    ]
    wfs_201_ext = [
        [bx + 200.0, by],
        [bx + 300.0, by],
        [bx + 300.0, by + 100.0],
        [bx + 200.0, by + 100.0],
        [bx + 200.0, by]
    ]
    wfs_201_hole = [
        [bx + 240.0, by + 40.0],
        [bx + 246.0, by + 40.0],
        [bx + 246.0, by + 45.0],
        [bx + 240.0, by + 45.0],
        [bx + 240.0, by + 40.0]
    ]
    wfs_202_ext = [
        [bx + 100.0, by + 100.0],
        [bx + 150.0, by + 99.99985],
        [bx + 200.0, by + 100.0],
        [bx + 200.0, by + 160.0],
        [bx + 100.0, by + 160.0],
        [bx + 100.0, by + 100.0]
    ]

    wfs_geojson = {
        "type": "FeatureCollection",
        "name": "test_wfs_naabrid",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:EPSG::3301"}},
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "id": "ELU_101",
                    "elupaiga_tyyp": "6210_VANA",
                    "märkus": "Vana WFS kuju - peab saama asendatud Sammus 2!"
                },
                "geometry": {"type": "Polygon", "coordinates": [wfs_old_101]}
            },
            {
                "type": "Feature",
                "properties": {
                    "id": "WFS_201",
                    "elupaiga_tyyp": "7140",
                    "märkus": "WFS naaber (sisaldab 30m2 WFS-sisest auku)"
                },
                "geometry": {"type": "Polygon", "coordinates": [wfs_201_ext, wfs_201_hole]}
            },
            {
                "type": "Feature",
                "properties": {
                    "id": "WFS_202",
                    "elupaiga_tyyp": "9080",
                    "märkus": "WFS naaber 0.15mm ujukoma nihkega (MapInfo ei loe ülekatteks)"
                },
                "geometry": {"type": "Polygon", "coordinates": [wfs_202_ext]}
            }
        ]
    }

    wfs_path = os.path.join(output_dir, "test_wfs_naabrid.geojson")
    with open(wfs_path, "w", encoding="utf-8") as f:
        json.dump(wfs_geojson, f, ensure_ascii=False, indent=2)

    ok_xlsx_path = None
    err_xlsx_path = None
    try:
        import openpyxl
        wb_ok = openpyxl.Workbook()
        # Sheet 1: Info / Juhend sheet (to test multi-sheet auto-detection!)
        ws_info = wb_ok.active
        ws_info.title = "Ülevaade"
        ws_info.append(["Projekti nimi", "Vastutaja"])
        ws_info.append(["Natura inventuur", "U. Saar"])

        # Sheet 2: Actual data table with trailing blank table rows
        ws_ok = wb_ok.create_sheet(title="Elupaigad")
        ws_ok.append(["obj_id", "elupaiga_kood", "esinduslikkus", "inventeerija"])
        ws_ok.append(["ELU_101", "6210", "A", "U. Saar"])
        ws_ok.append(["ELU_102", "6450", "B", "U. Saar"])
        ws_ok.append(["ELU_103", "9010", "A", "U. Saar"])
        # Simulate formatted Excel Table trailing rows where ID is blank but other columns have defaults
        ws_ok.append([None, "0", "-", ""])
        ws_ok.append(["", "", "", "Tühi tabelirida"])
        ws_ok.append(["Kokku", "3", "", ""])
        ok_xlsx_path = os.path.join(output_dir, "test_andmed_korras.xlsx")
        wb_ok.save(ok_xlsx_path)

        wb_err = openpyxl.Workbook()
        ws_err = wb_err.active
        ws_err.title = "Elupaigad_Vigane"
        ws_err.append(["obj_id", "elupaiga_kood", "esinduslikkus", "inventeerija"])
        ws_err.append(["ELU_101", "6210", "A", "U. Saar"])
        ws_err.append(["ELU_101", "6210", "A", "Duplikaat Excelis"])
        ws_err.append(["ELU_102", "6450", "B", "U. Saar"])
        ws_err.append(["ELU_999", "7140", "C", "Puudub kaardikihil"])
        err_xlsx_path = os.path.join(output_dir, "test_andmed_veaga.xlsx")
        wb_err.save(err_xlsx_path)
    except Exception:
        pass

    return {
        "sisend_path": sisend_path,
        "wfs_path": wfs_path,
        "ok_xlsx_path": ok_xlsx_path,
        "err_xlsx_path": err_xlsx_path,
    }
