# Versiooniajalugu
## 1.7.6
- **Täiustatud ID-veergude ja töölehtede automaattuvastus (Samm 1):**
  - **Kardinaalsuse / unikaalsuse kontroll:** Välistatud olukorrad, kus mõne üksiku korduva klassifikaatoriga veerg (nt 3 unikaalset väärtust nagu `I`, `II`, `III`) valitakse ekslikult ID-veeruks.
  - **Täiustatud veergude nimeheuristika:** Tuvastatakse liitnimetused nagu `"ID/ järjekorranumber"`, `"järjekorranumber"`, `"jrknr"`, `"jrk"` jms.
  - **Mitme lehega töövihikute intelligentne analüüs:** Välditakse valikute/klassifikaatorite abilehtede (nt `Leht1`) valimist põhitabeli (`Niidud_sood`) asemel. Lehe ja veeru valikul arvestatakse kattuvate kirjete absoluutarvu ja tegelikku andmeridade mahtu.
- **WFS naabrite korrektne lisamine ja ID-välja tuvastuse parandus (Samm 2):**
  - **Tõstutundetu veergude võrdlus:** Parandatud probleem, kus MapInfo suurtähtedega ID-väli (`ID`) ei haakunud WFS-i väiketähtedega väljaga (`id`).
  - **WFS ID-välja kaitstud määramine:** WFS naabrite unikaalse identifikaatorina eelistatakse alati ametlikke primaarseid ID-välju (`id`, `sys_id`, `kr_kood`, `gml_id`), välistades numbriliste parameetrite (nt osakaaluprotsent `pohityyp_p` väärtustega 50, 70, 100 jne) eksliku tõlgendamise ID-dena, mis varem põhjustas WFS naabrite täieliku kadumise.
  - **Põhitüübi täiendav automaattuvastus sisendkihist:** Kui Excelis puudub elupaigatüübi veerg, tuvastatakse ja loetakse `pohityyp` automaatselt ka sisendkihi enda atribuutidest (nt `e_Elupaigatüübi_kood_Natura_koo`).

## 1.7.5
- **Töökihi kategooriad enne ja pärast automaatparandust:**
  - Sammus 2 ("2. Koosta kiht") loodav esialgne Töökiht kuvab enne vigade kontrolli ja automaatparandust lihtsaid ja selgeid kategooriaid:
    - `Naabrid` (Kollane)
    - `Sisendkiht` (Helesinine)
  - Alles pärast automaatparanduse läbiviimist ("🪄 Automaatparandus") lülitub kihi legend täpsustatud kategooriatele:
    - `Naabrid (muutmata)`
    - `Sisendkiht (muutmata / ei vajanud parandust)`
    - `Parandatud sisendkiht (piirid ja ülekatted)`
    - `Parandatud sisendkiht (augutäide)`
    - `Parandatud naabrid (WFS)`
  - Kihipuu sümboloogia värskendatakse koheselt automaatparanduse lõpetamisel.

## 1.7.4
- **Töökihi kategooriate ja legendi selguse täiustamine:**
  - Legendi kategooriad on viidud täielikku kooskõlla tegeliku päritolu ja muudatuste sisuga:
    - `Naabrid (muutmata)` (Kollane) – WFS-ist toodud piirnevad polügoonid, mida ei muudetud.
    - `Sisendkiht (muutmata / ei vajanud parandust)` (Helesinine) – kasutaja sisendkihi polügoonid, mis ei vajanud vigade parandamist.
    - `Parandatud sisendkiht (piirid ja ülekatted)` (Oranž) – sisendkihi polügoonid, mille piire korrigeeriti või ülekatted kärbiti.
    - `Parandatud sisendkiht (augutäide)` (Roheline) – selgitatud ja täpsustatud kategooria (`_allikas = PARANDATUD_GEOM`): tähistab eranditult **sisendkihi** polügoone, mis neelasid endasse ja sulgesid leitud tühimiku (augu). WFS-naabritele, mis auke liidavad, kehtib `Parandatud naabrid (WFS)`.
    - `Parandatud naabrid (WFS)` (Lilla) – Tase 2 automaatparanduse käigus muudetud WFS-i naaberpolügoonid.
  - **Dünaamiline kihipuu legend:** Kihi legendis kuvatakse ainult neid kategooriaid, mis kihis tegelikult esinevad (kui parandatud kihil WFS-i naabreid pole, ei näidata tühja "Naabrid (muutmata)" rida).
  - **Automaatparanduse tulemuskihi stiil:** Sama selge ja arusaadav kategoriseeritud stiil määratakse nüüd koheselt ka nupu "Automaatparandus" loodud uuele parandatud kihile (`[Parandatud (Tase 1/2)]`).
- **Visuaalne tagasiside vigade ignoreerimisel ("Värskendan kihti..."):**
  - Tulemuste aknast vigade ignoreerimisel (nii üksiku vea, objekti ID-põhise, grupi kui ka terve kategooria ignoreerimisel) kuvatakse koheselt olekuteade `"🔄 Värskendan kihti..."` nii pistikprogrammi aknas kui ka QGIS-i alumisel olekuribal.
  - Uuendatakse taustal QGIS-i kihipuu sümboloogia (`refreshLayerSymbology`) ja loendurid ning kaardilõuend, mille järel kuvatakse kinnitus `"Kiht värskendatud ✓"`.

## 1.7.3
- **QGIS 4 / Qt6 ühilduvuse parandus seadete aknas:**
  - Parandatud viga `AttributeError: type object 'QHeaderView' has no attribute 'Interactive'` ja Qt6 enumite skoobiprobleemid (`AlignmentFlag`, `ItemFlag`, `ResizeMode`).
  - Lisatud `HEADER_INTERACTIVE`, `HEADER_STRETCH`, `HEADER_FIXED`, `ALIGN_CENTER` jm ühilduvuskonstandid moodulisse `qt_compat.py`, mis tagavad tõrgeteta töö nii QGIS 4.x (Qt6 / Python 3.12) kui ka QGIS 3.x (Qt5) keskkondades.

## 1.7.2
- **Profiil 2 reeglite dünaamiline haldamine seadetes (⚙):**
  - **Uus leht "Profiil 2 lubatud kattuvused" seadete aknas:** Lisatud `QTabWidget` vahelehtedega `⚙ MapInfo & EELIS tolerantsid` ja `🌿 Profiil 2 lubatud kattuvused`.
  - **Täielikult redigeeritav reeglite tabel:**
    - Kasutaja saab muuta olemasolevaid lubatud elupaigatüüpide koode, lubatud kattuvuste mustreid ja kirjeldusi.
    - Igal real on punane `Kustuta` nupp reegli eemaldamiseks.
    - Tabeli viimane rida on `"➕ Lisa reegel"` – sellel klõpsamisel luuakse uus tühi redigeeritav reeglirida ning viimaseks reaks jääb automaatselt taas `"➕ Lisa reegel"`.
    - Lisatud ka nupp `"↺ Taasta vaikeväärtused"`, mis taastab ametlikud Natura 2000 reeglid.
  - **Püsivus ja dünaamiline kontroll:**
    - Reeglid salvestatakse `QSettings`-isse ning Profiil 2 kontrollimisel võetakse arvesse kasutaja aktiivsed reeglid.
    - Toetatakse reeglite mustreid: konkreetsed koodid, `"Kõik"`, `"PLK"`, ja erandid `v.a Kood` (nt `Kõik (v.a 4030)` või `PLK (v.a 6270*)`).
  - **Sünkroonsus infonupuga (ℹ):** Seadetes tehtud reeglimuudatused (uued, muudetud, kustutatud) kajastuvad koheselt ka profiili infoaknas (`ProfileRulesDialog`).

## 1.7.1
- **Vigade parandused ja täiustused:**
  - **Parandatud baasi ekspordi KeyError parandus:** Kõrvaldatud viga `Viga Exceli salvestamine ebaõnnestus: '_kontroll_id'`, mis ilmnes nupu "💾 Parandatud baas..." vajutamisel pärast Tase 2 automaatparandust. Lisatud kontrollid ja tagatud turvaline `kr_kood` lookup `Töökiht`-st ja WFS-kihist.
  - **Uue Exceli PäN automaattäide ka ajutises failis:** Tase 2 automaatparanduse järel koostatav ajutine Exceli tabel saab samuti koheselt WFS-ist täidetud `PäN = JAH/EI` väärtused.
- **Uus funktsionaalsus tulemuste aknas (Tulemused):**
  - **Vigade ignoreerimine objekti ID järgi grupis:** Tulemuste puus paremklõpsates on lisatud valik `"Ignoreeri kõik selle objektiga seotud vead selles grupis"`. Kui viga puudutab mitut objekti (nt auk või ülekate kahe elupaiga vahel), pakub menüü eraldi alamvalikuid konkreetse objekti ID valimiseks või kõigi seotud ID-de korraga eemaldamiseks.
  - **Mugav sorteerimine otse kontekstimenüüst:** Paremklõpsu menüüsse on lisatud kiirvalikud vigade sorteerimiseks:
    - *Sorteeri: ID järgi (A → Z ja Z → A)* – intelligentne loomulik ja numbriline sorteerimine.
    - *Sorteeri: Suuruse järgi (kahanev ja tõusev)* – sorteerib leidude arvväärtuse (pindala ha/m², pikkus mm, nurk °) alusel, tuues suuremad vead esile.
- **Kontrolliprofiilide reeglite teabeaken (Info ℹ):**
  - Profiilivalija kõrvale lisatud info-nupp `ℹ` ning profiili rippmenüü paremklõpsu valik `"ℹ Vaata profiilide reegleid..."`.
  - Avaneb põhjalik ja selgelt kujundatud ülevaateaken Profiil 1 ja Profiil 2 tööpõhimõtetest, lubatud kattuvuste maatriksist ning PLK-koosluste nimekirjast.

## 1.7.0
- **Kontrolliprofiilide süsteem (Profiil 1 ja Profiil 2):**
  - **Uus profiilivalija tööriistaribal:** Nuppude "2. Koosta kiht" ja "▶ Start" vahele lisatud rippmenüü (`ProfileCombo`) profiilide vahetamiseks:
    - *Profiil 1: Tavaline (kõik vead)*
    - *Profiil 2: Lubatud kattuvused*
  - **Vaikimisi profiili määramine:** Paremklõps profiilimenüül võimaldab määrata aktiivse profiili vaikimisi profiiliks (`QSettings`), mida tähistatakse sildiga `[Vaikimisi]`.
  - **Profiil 2 lubatud ülekatete reeglistik:**
    - Realiseeritud ametlikel Natura elupaigatüüpide suhetel põhinev lubatud kattuvuste filter (`is_overlap_allowed`).
    - Profiil 2 valimisel ignoreeritakse ja ei raporteerita reeglistikule vastavaid lubatud ülekatteid (nt `1630*` rannaniidud ja `1140`/`1160` madalaveelised merelahed/pagurannad; `3260` vooluveekogud kõigiga; `1620*` väikesaared v.a `4030`; `7160` ja `3180*` PLK-kooslustega jne).
  - **Põhitüübi prioriteetsus (Excel enne WFS-i):**
    - `pohityyp` väärtuse määramisel eelistatakse alati Exceli tabelis olevat väärtust (kuna see jõuab andmebaasi), puudumisel loetakse WFS-i ametlik väärtus.
  - **Sisendandmete PäN puutumatus ja Tase 2 WFS-naabrite PäN automaattäide:**
    - Kasutaja käsitsi määratud sisendobjektide `PäN = JAH/EI` väärtusi ei kirjutata kunagi üle.
    - Tase 2 ekspordil täidetakse `PäN` veerg automaatselt ainult uutel lisatud WFS-naabritel: `"JAH"` kui WFS-is on `kr_kood` olemas, ja `"EI"` kui puudub.

## 1.6.7
- **EELIS baaskontrolli vigade lahendamine (US2 ja 1792749296):**
  - Lisatud `_clean_poly_geometry`: automaatne geomeetria puhastamine boole'i operatsioonide (`difference`, `combine`, `snapping`) järel.
  - **Sisekontuuride puhastus:** Eemaldatakse sub-millimeetrised siseaugud (`Ring < 0.01 m²`), mis tekkisid GEOS ülekatete lahutamisel (`difference`) ja põhjustasid EELIS kontrollis vea `[6:] Liiga väike kontuuri pindala: 0,000 m²` ning eneselõikumise.
  - **Teravate nurkade ja siugude eemaldamine:** Lisatud automaatne teravate tagasipöördenurkade (`<= 1.0°`) ja mikro-sik-sakide likvideerimine ka ülekatetega modifitseeritud polügonidele (sh `US2`), välistades naabruspiirilt pärandunud siugude ja mikro-sõlmede kandumise sisendkihti.
  - **Faas 4 viimistluse laiendamine:** Klastripõhine lõikude rihtimine ja siugude eemaldus rakendub nüüd kõigile muudetud kujudele (nii aukude kui ülekatete lahendamisel).
- **Vigade raporteerimise vaikerežiimiks määratud Valik 2:**
  - Vaikimisi raporteeritakse töödeldud kihi ja Tase 2 poolt kaasatud WFS-naabrite piirivead, tagades täieliku vastavuse MapInfo Check Regions analüüsiga.

## 1.6.6
- **Täpne MapInfo eksport ("Parandatud baas..."):**
  - Integreeritud `ExtractTabExporter` eksportimismudeli loogika koos MapInfo ametlike L-EST97 koordinaatvõrgu piiridega (`BOUNDS=-503054.5255,5371945.474,1503054.526,7378054.526`), `CP1257` kodeeringuga ja 1.0 mm `Decimal(ROUND_HALF_UP)` tippude täpsusrihtimisega.
  - Failitüüpide valik nupu "💾 Parandatud baas..." all toetab nüüd formaate nõutud järjekorras: `.TAB` (MapInfo TAB), `.SHP` (ESRI Shapefile) ja `.GPKG` (GeoPackage). Vaikimisi failinimeks on `Parandatud_Baas.tab`.
  - **Shapefile (.shp) MapInfo ühilduvus:** Lisatud automaatne 1.0 mm geomeetriate rihtimine, native ESRI WKT projektsiooni genereerimine `.prj` faili (`MorphToESRI()`) ning `.cpg` fail (1257), vältides MapInfo poolseid daatumi nihkeid ja valesid vaikebounds'e.
  - **GeoPackage (.gpkg) MapInfo ühilduvus:** Tagatud 1.0 mm geomeetriate rihtimine ja traditsiooniline GIS telgede järjekord (Easting, Northing), mis välistab MapInfo GDAL lugeja telgede segiajamise.
  - Kõigi formaatide puhul säilitatakse sünkroniseeritud Exceli tabeli eksport (.xlsx).

## 1.6.5
- **Parandatud baasi ja Exceli ekspordi täielik sünkroonimine ("Parandatud baas..."):**
  - Lahendatud probleem, kus eelvormindatud Exceli mallide puhul (nt 1481 reaga `Tabel1`) lisati uued Tase 2 WFS-naabrid rea 1482 peale, mistõttu kasutajale paistis faili avamisel vaid 30 rida ja read 33–1481 olid tühjad.
  - Uus nutikas päise ja andmeridade tuvastus (`append_wfs_to_excel`) tuvastab automaatselt tegeliku veerupäise (sh rea 2 juhul, kui rida 1 sisaldab selgitavaid tekste) ning paigutab uued ID-d vahetult viimase täidetud andmerea järele (read 33–39), säilitades ID numbritüübi ja märkuse `"Auto-lisatud Naaber (Tase 2)"`.
  - Nupule "💾 Parandatud baas..." vajutamisel tagatakse alati parandatud baaskihi (37 objekti) ja sünkroonitud Exceli tabeli (37 rida) 1:1 eksport.
- **Kasutajaliidese sujuvus ja reaalajas tagasiside (UI Performance & Responsiveness):**
  - **Automaatparanduse tagasiside (Tase 1 ja 2):** Lisatud reaalajas progressiriba ja faaside tekstilised indikaatorid ("Faas 1: Sõlmede eemaldamine ja klastrite rihtimine", "Faas 2: Ülekatete lahendamine", "Faas 3: Aukude sulatamine ja kleepimine", "Faas 4: Piiriõmbluste viimistlus"), mis välistab 5–10-sekundilise tardumise ja teadmatuse.
  - **Samm 2 ("Koosta kiht") optimeerimine:** Kohaliku (offline) WFS-kihi päringud kasutavad nüüd ruumiindeksit (`QgsFeatureRequest().setFilterRect()`), kiirendades naabrite lugemist mitmekümnekordselt. Progressi uuendatakse sujuvalt igas etapis.
  - **Sammud 3–7 ("▶ Start") samm-sammuline indikaator:** Topoloogiakontroll raporteerib igat etappi (augud, ülekatted, sõlmed, lühikesed lõigud, teravad nurgad) reaalajas koos sündmuste töötlemisega (`processEvents`), tagades akna sujuvuse.

## 1.6.4
- **Kolmeastmeline vigade raporteerimise filter (asendab senise märkeruudu):** Seadete aknas (`⚙`) asendatud endine märkeruut rippmenüüga "Vigade raporteerimise ulatus":
  - **Valik 1 – Täisaruanne (kõik vead, sh WFS-naabrite omavahelised):** Raporteerib kõik töökihi vead, sh riikliku EELIS-e taustakihi naabrite omavahelised vead (kasutaja testil 201 auku, 197 ülekatet).
  - **Valik 2 – Töödeldud kiht (algne sisend + Tase 2 lisatud naabrid):** Raporteerib vead, mis puudutavad töödeldud kihi objekte. Kui Tase 2 kaasas WFS-naabri, raporteeritakse ka selle naabri välispiiri vead teiste WFS-aladega (kasutaja pildil nähtud 198 auku, 197 ülekatet).
  - **Valik 3 – Ainult algne sisendkiht (UUS VAIKIMISI):** Raporteerib AINULT need vead, mis puudutavad vahetult kasutaja algseid sisendobjekte. Tase 2 poolt kaasatud naabri välised, EELIS-e poolsed vead teiste WFS-aladega filtreeritakse välja. Tulemuseks on puhas ja selge töölaud (0 ülekatet, 0 sõlme, 0 lühikest lõiku, 0 teravat nurka, 2 mikrosliverit).
- **Töökihi allikainfo säilitamine peale re-laadimist:** `tmp_lyr` ja Samm 2 säilitavad nüüd lisatud naabritel atribuudi `_allikas = "PARANDATUD_NAABER"`, tagades filtrite ja sümboloogia korrektse toimimise ka pärast parandatud kihi uueks sisendiks laadimist.

## 1.6.3
- **Tase 2 ökonoomne WFS-naabrite kaasamine aukude lahendamiseks:** Tase 2 lisab nüüd automaatselt ja ökonoomselt vaid need üksikud WFS-naabrid (antud testil vaid 7 naabrit 176-st), mis puutuvad vahetult kokku sisendkihi ja naabrite vaheliste piiriaukudega.
- **Topoloogiline kleepimine (Snapping):** Kasutatakse `QgsGeometrySnapper` mootorit, mis kleepib parandatud naabri piiri 5 cm tolerantsiga vastasoleva sisendpolügoni sõlmede külge, lisades vajadusel puuduvad sõlmed ja sulgedes MapInfo kontrollis seni jäänud mikro-sliverid ja praod.
- **MultiPolygon normaliseerimine:** GEOS `makeValid()` ja `unaryUnion()` operatsioonide järel normaliseeritakse geomeetria alati puhtaks MultiPolygoniks (`_to_pure_multipolygon`), vältides `GeometryCollection` või dangling-joonte tekkimist ja C++ krahhe.
- **Täielik Exceli sünkroonimine:** Kõik Tase 2 poolt lisatud WFS naabrite ID-d lisatakse automaatselt Exceli tabelisse märkusega `"Auto-lisatud Naaber (Tase 2)"`. Samm 1 kahesuunaline ID-kontroll kinnitab 37/37 vastavuse (30 originaal + 7 naabrit) ilma vigadeta.
- **Topoloogia tulemused Tase 2 järel:** Ülekatted = 0, Sõlmed = 0, Teravad nurgad = 0, Lühikesed lõigud = 0, Augud vähendatud 20-lt vaid 2 mikro-sliverile (ala < 0.04 m²).

## 1.6.2
- **Minimaalsete muudatuste põhimõte (Minimal Edits):** Automaatparandus puudutab nüüd rangelt AINULT neid objekte, millel on tuvastatud topoloogiavead. Süütud (veatud) sisendobjektid jäävad 100% puutumata (baiditäpne säilivus), mis minimeerib maaomanike teavituskohustust.
- **Tase 2 WFS-naabrite plahvatuse parandus:** Likvideeritud viga, kus globaalne võrgukorrastus märkis ekslikult kõik 176 WFS-naabrit muudetuks, paisates uueks sisendiks 206 objekti ja genereerides 423 objektiga ning 205 ülekattega töökihi.
- **Sünkroniseeritud klastripõhine lõikude eemaldus:** Likvideeritud naabruspiiride lahknemine lühikeste lõikude (< 20 mm) korrastamisel. Mõlema naabri ühised punktid asendatakse samade kanooniliste koordinaatidega, välistades uute aukude ja ülekatete tekke.
- **Ülekatete lõikamise loogika korrastus:** Ülekatted lahutatakse korraga vaid ühest polügonist (mitte mõlemast), mis varem tekitas ülekatte asemele augu.
- **Töökihi re-kontrolli allikatuvastuse tugi:** `step3_gaps.py`, `step4_overlaps.py`, `step5_intersections.py` ja `step6_7_segments_angles.py` tuvastavad nüüd korrektselt sisendobjektidena ka `PARANDATUD_SISEND` ja `PARANDATUD_GEOM` staatusega polügoone.

## 1.6.1
- Parandatud automaatparanduse (auto_fixer.py) ülekatete ja aukude geomeetria operatsioonid.
- Välistatud uute ülekatete ja aukude tekkimine aukude täitmisel (naabrite lõikamine enne combine operatsiooni).
- Likvideeritud teravate nurkade ja lühikeste lõikude kaskaadne eemaldamine (search_radius vähendatud 15m -> 0.5m), mis varem tekitas sirgeid lõikeid ja auke.
- Lisatud boole'i operatsioonide tulemuste automaatne täpsusvõrku rihtimine (1mm) ja duplikaatsõlmede eemaldamine.
- Ülekatete vaikeväärtus automaatparanduse aknas sünkroniseeritud aukude pindalaga (100 m² = 0.01 ha).
- Töökihi ja ekspordi loogikas tagatud PARANDATUD_GEOM allika säilimine ja kuvamine.

## 1.6.0
- Tulemuste puu on sorteeritav veergude kaupa igas kategoorias.
- Lisatud 'Liigu valikuni' (pan) funktsioon paremklõpsu menüüsse.
- WFS päringute ruumiline plokk-töötlus (chunking) suurte sisendkihtide jõudluse parandamiseks (asendab objektipõhised päringud).
- Osaliste HTTP tõrgete käsitlus (vigased päringud raporteeritakse, mitte ei ignoreerita vaikselt).
- Uuendatud metadata.txt kontaktandmed ja versiooninumber.
