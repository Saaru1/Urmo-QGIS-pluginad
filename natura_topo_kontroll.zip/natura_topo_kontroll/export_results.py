# -*- coding: utf-8 -*-
"""
Export Module:
- Exact MapInfo TAB exporter with official Estonian L-EST97 bounds (-503054.5255 to 1503054.526)
  and 1.0 mm coordinate snapping (Decimal ROUND_HALF_UP).
- High-precision ESRI Shapefile exporter with 1.0 mm coordinate snapping, CP1257 encoding,
  and native ESRI WKT projection string.
- High-precision GeoPackage exporter with 1.0 mm coordinate snapping and traditional GIS axis order.
- Multi-layer findings export to GPKG and XLSX.
"""

import os
import re
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP, getcontext
from osgeo import ogr, osr

from qgis.core import (
    QgsVectorFileWriter, QgsProject, QgsVectorLayer, QgsGeometry,
    QgsPointXY, QgsWkbTypes
)
from qgis.PyQt.QtCore import QDate, QDateTime
from .qt_compat import is_layer_valid

getcontext().prec = 28

GRID = 0.001
B_XMIN, B_YMIN = "-503054.5255", "5371945.474"
B_XMAX, B_YMAX = "1503054.526", "7378054.526"
DEFAULT_ENCODING = "CP1257"


def _snap_val(val, grid: float = GRID) -> float:
    """Snaps a float coordinate to exact grid precision using Decimal."""
    d_val = Decimal(str(val))
    d_grid = Decimal(str(grid))
    return float((d_val / d_grid).to_integral_value(rounding=ROUND_HALF_UP) * d_grid)


def _snap_point(pt: QgsPointXY, grid: float = GRID) -> QgsPointXY:
    return QgsPointXY(_snap_val(pt.x(), grid), _snap_val(pt.y(), grid))


def snap_geometry_to_grid(geom: QgsGeometry, grid: float = GRID) -> QgsGeometry:
    """
    Safely snaps all vertices of a QgsGeometry to the specified grid (default 1 mm).
    Maintains closed rings and valid geometry structures.
    """
    if not geom or geom.isNull() or geom.isEmpty():
        return geom
    flat = QgsWkbTypes.flatType(geom.wkbType())
    try:
        if flat == QgsWkbTypes.Point:
            return QgsGeometry.fromPointXY(_snap_point(geom.asPoint(), grid))
        elif flat == QgsWkbTypes.MultiPoint:
            return QgsGeometry.fromMultiPointXY([_snap_point(p, grid) for p in geom.asMultiPoint()])
        elif flat == QgsWkbTypes.LineString:
            pts = [_snap_point(p, grid) for p in geom.asPolyline()]
            return QgsGeometry.fromPolylineXY(pts)
        elif flat == QgsWkbTypes.MultiLineString:
            lines = [[_snap_point(p, grid) for p in ln] for ln in geom.asMultiPolyline()]
            return QgsGeometry.fromMultiPolylineXY(lines)
        elif flat == QgsWkbTypes.Polygon:
            rings = [[_snap_point(p, grid) for p in r] for r in geom.asPolygon()]
            return QgsGeometry.fromPolygonXY(rings)
        elif flat == QgsWkbTypes.MultiPolygon:
            polys = [[[_snap_point(p, grid) for p in r] for r in poly] for poly in geom.asMultiPolygon()]
            return QgsGeometry.fromMultiPolygonXY(polys)
    except Exception:
        return geom
    return geom


def sanitize_field_name(raw_name: str, max_len: int = 31, existing_names: set = None) -> str:
    """
    Sanitizes field name according to driver constraints:
    - Replaces spaces, dots, and hyphens with underscores
    - Keeps letters, numbers, and underscores
    - Ensures it does not start with a digit
    - Truncates to max_len
    - Deduplicates against existing_names
    """
    if existing_names is None:
        existing_names = set()

    safe_name = re.sub(r'[\s\.-]+', '_', raw_name)
    safe_name = re.sub(r'[^\w_]', '', safe_name)
    if not safe_name or safe_name[0].isdigit():
        safe_name = 'F_' + safe_name
    safe_name = safe_name[:max_len]

    base_safe = safe_name
    counter = 1
    while safe_name in existing_names:
        suffix = f"_{counter}"
        safe_name = base_safe[:max_len - len(suffix)] + suffix
        counter += 1

    existing_names.add(safe_name)
    return safe_name


def format_attribute_val(v, enc: str = DEFAULT_ENCODING) -> str:
    """Formats an attribute value for single-byte character sets with length safety."""
    if isinstance(v, QDate):
        s = v.toString("yyyy-MM-dd")
    elif isinstance(v, QDateTime):
        s = v.toString("yyyy-MM-dd HH:mm:ss")
    elif isinstance(v, date):
        s = v.strftime("%Y-%m-%d")
    elif isinstance(v, datetime):
        s = v.strftime("%Y-%m-%d %H:%M:%S")
    else:
        s = "" if v is None else str(v)

    try:
        s.encode(enc)
    except UnicodeEncodeError:
        s = s.encode(enc, errors='replace').decode(enc)

    return s[:254]


def _clean_siblings(base_path: str, extensions: list):
    """Safely removes auxiliary files before overwriting a dataset."""
    root = os.path.splitext(base_path)[0]
    for ext in extensions:
        for e in (ext.lower(), ext.upper()):
            p = root + e
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass


def export_to_exact_tab(layer: QgsVectorLayer, out_path: str, selected_only: bool = False) -> tuple:
    """
    Exports a layer to MapInfo .TAB using the exact bounds and 1 mm grid snapping
    from ExtractTabExporter, ensuring zero millimeter shift in MapInfo Professional.
    """
    _clean_siblings(out_path, ['.tab', '.dat', '.id', '.map', '.ind'])
    drv = ogr.GetDriverByName("MapInfo File")
    ds = drv.CreateDataSource(out_path)
    if ds is None:
        return False, f"MapInfo faili loomine ebaõnnestus: {out_path}"

    srs = osr.SpatialReference()
    srs.ImportFromEPSG(3301)
    srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)

    lco = [
        f"BOUNDS={B_XMIN},{B_YMIN},{B_XMAX},{B_YMAX}",
        f"ENCODING={DEFAULT_ENCODING}",
        "STRICT_FIELDS_NAME_LAUNDERING=NO"
    ]

    base_name = os.path.splitext(os.path.basename(out_path))[0]
    safe_layer_name = re.sub(r'[^\w_]', '', base_name) or "Parandatud_Baas"
    ol = ds.CreateLayer(safe_layer_name, srs, geom_type=ogr.wkbUnknown, options=lco)
    if ol is None:
        return False, f"MapInfo kihi skeemi loomine ebaõnnestus: {safe_layer_name}"

    fields = layer.fields()
    sanitized = set()
    for field in fields:
        s_name = sanitize_field_name(field.name(), max_len=31, existing_names=sanitized)
        fd = ogr.FieldDefn(s_name, ogr.OFTString)
        fd.SetWidth(254)
        ol.CreateField(fd)

    feature_iter = layer.getSelectedFeatures() if selected_only else layer.getFeatures()
    for feat in feature_iter:
        newf = ogr.Feature(ol.GetLayerDefn())
        if feat.hasGeometry():
            snapped = snap_geometry_to_grid(feat.geometry(), GRID)
            if snapped and not snapped.isNull() and not snapped.isEmpty():
                newf.SetGeometry(ogr.CreateGeometryFromWkb(snapped.asWkb()))

        attrs = feat.attributes()
        for j in range(len(fields)):
            newf.SetField(j, format_attribute_val(attrs[j], DEFAULT_ENCODING))

        ol.CreateFeature(newf)

    ds = None
    return True, ""


def export_to_exact_shp(layer: QgsVectorLayer, out_path: str, selected_only: bool = False) -> tuple:
    """
    Exports a layer to ESRI Shapefile with 1 mm grid snapping, CP1257 encoding,
    and native ESRI WKT projection string in .prj to prevent MapInfo datum shift.
    """
    _clean_siblings(out_path, ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.sbn', '.sbx', '.qix'])
    drv = ogr.GetDriverByName("ESRI Shapefile")
    ds = drv.CreateDataSource(out_path)
    if ds is None:
        return False, f"Shapefile'i loomine ebaõnnestus: {out_path}"

    srs = osr.SpatialReference()
    srs.ImportFromEPSG(3301)
    srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)

    base_name = os.path.splitext(os.path.basename(out_path))[0]
    safe_layer_name = re.sub(r'[^\w_]', '', base_name)[:10] or "Parandatud"

    # Shapefile layer geometry type
    geom_type = ogr.wkbMultiPolygon if layer.geometryType() == 2 else ogr.wkbUnknown
    ol = ds.CreateLayer(safe_layer_name, srs, geom_type=geom_type, options=[f"ENCODING={DEFAULT_ENCODING}"])
    if ol is None:
        return False, f"Shapefile'i kihi loomine ebaõnnestus: {safe_layer_name}"

    fields = layer.fields()
    sanitized = set()
    for field in fields:
        s_name = sanitize_field_name(field.name(), max_len=10, existing_names=sanitized)
        fd = ogr.FieldDefn(s_name, ogr.OFTString)
        fd.SetWidth(254)
        ol.CreateField(fd)

    feature_iter = layer.getSelectedFeatures() if selected_only else layer.getFeatures()
    for feat in feature_iter:
        newf = ogr.Feature(ol.GetLayerDefn())
        if feat.hasGeometry():
            snapped = snap_geometry_to_grid(feat.geometry(), GRID)
            if snapped and not snapped.isNull() and not snapped.isEmpty():
                ogr_geom = ogr.CreateGeometryFromWkb(snapped.asWkb())
                if geom_type == ogr.wkbMultiPolygon and ogr_geom.GetGeometryType() == ogr.wkbPolygon:
                    mp = ogr.Geometry(ogr.wkbMultiPolygon)
                    mp.AddGeometry(ogr_geom)
                    ogr_geom = mp
                newf.SetGeometry(ogr_geom)

        attrs = feat.attributes()
        for j in range(len(fields)):
            newf.SetField(j, format_attribute_val(attrs[j], DEFAULT_ENCODING))

        ol.CreateFeature(newf)

    ds = None

    # 1. Write native ESRI WKT into .prj so MapInfo and ESRI recognize Estonian National Grid without shift
    srs_esri = srs.Clone()
    srs_esri.MorphToESRI()
    prj_path = os.path.splitext(out_path)[0] + ".prj"
    with open(prj_path, "w", encoding="utf-8") as fp:
        fp.write(srs_esri.ExportToWkt())

    # 2. Write .cpg codepage file for CP1257
    cpg_path = os.path.splitext(out_path)[0] + ".cpg"
    with open(cpg_path, "w", encoding="utf-8") as fp:
        fp.write("1257")

    return True, ""


def export_to_exact_gpkg(layer: QgsVectorLayer, out_path: str, selected_only: bool = False) -> tuple:
    """
    Exports a layer to GeoPackage with 1 mm grid snapping and traditional GIS order
    so MapInfo's GDAL reader does not misinterpret axis order.
    """
    _clean_siblings(out_path, ['.gpkg', '.gpkg-wal', '.gpkg-shm'])
    drv = ogr.GetDriverByName("GPKG")
    ds = drv.CreateDataSource(out_path)
    if ds is None:
        return False, f"GeoPackage'i loomine ebaõnnestus: {out_path}"

    srs = osr.SpatialReference()
    srs.ImportFromEPSG(3301)
    srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)

    base_name = os.path.splitext(os.path.basename(out_path))[0]
    safe_layer_name = re.sub(r'[^\w_]', '', base_name) or "Parandatud_Baas"
    ol = ds.CreateLayer(safe_layer_name, srs, geom_type=ogr.wkbMultiPolygon)
    if ol is None:
        return False, f"GeoPackage'i kihi loomine ebaõnnestus: {safe_layer_name}"

    fields = layer.fields()
    sanitized = set()
    for field in fields:
        s_name = sanitize_field_name(field.name(), max_len=63, existing_names=sanitized)
        fd = ogr.FieldDefn(s_name, ogr.OFTString)
        fd.SetWidth(254)
        ol.CreateField(fd)

    feature_iter = layer.getSelectedFeatures() if selected_only else layer.getFeatures()
    for feat in feature_iter:
        newf = ogr.Feature(ol.GetLayerDefn())
        if feat.hasGeometry():
            snapped = snap_geometry_to_grid(feat.geometry(), GRID)
            if snapped and not snapped.isNull() and not snapped.isEmpty():
                ogr_geom = ogr.CreateGeometryFromWkb(snapped.asWkb())
                if ogr_geom.GetGeometryType() == ogr.wkbPolygon:
                    mp = ogr.Geometry(ogr.wkbMultiPolygon)
                    mp.AddGeometry(ogr_geom)
                    ogr_geom = mp
                newf.SetGeometry(ogr_geom)

        attrs = feat.attributes()
        for j in range(len(fields)):
            newf.SetField(j, format_attribute_val(attrs[j], "UTF-8"))

        ol.CreateFeature(newf)

    ds = None
    return True, ""


def export_repaired_base_layer(layer: QgsVectorLayer, out_path: str, selected_only: bool = False) -> tuple:
    """
    Dispatches export of repaired base layer to TAB, SHP, or GPKG based on file extension.
    Returns (success: bool, error_msg: str).
    """
    if not is_layer_valid(layer):
        return False, "Eksportitav kiht on vigane või puudub."

    ext = os.path.splitext(out_path)[1].lower()
    if ext == ".tab":
        return export_to_exact_tab(layer, out_path, selected_only)
    elif ext == ".shp":
        return export_to_exact_shp(layer, out_path, selected_only)
    elif ext == ".gpkg":
        return export_to_exact_gpkg(layer, out_path, selected_only)
    else:
        # Default to TAB if extension unrecognized
        if not ext:
            out_path += ".tab"
        return export_to_exact_tab(layer, out_path, selected_only)


def export_layers_to_gpkg_and_xlsx(layers: list, gpkg_path: str, xlsx_path: str = None) -> tuple:
    """
    Exports a list of QgsVectorLayers to GPKG, and optionally to XLSX.
    Used for exporting topology error report layers.
    Returns (success: bool, error_msg: str)
    """
    if not layers:
        return False, "Ühtegi kihti pole eksportimiseks."

    transform_context = QgsProject.instance().transformContext()

    # 1. Export to GPKG
    try:
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        for i, lyr in enumerate(layers):
            if not is_layer_valid(lyr):
                continue
            options.layerName = lyr.name()
            if i == 0:
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            else:
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

            res = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, gpkg_path, transform_context, options)
            if res[0] != QgsVectorFileWriter.NoError:
                return False, f"Viga GPKG salvestamisel (kiht {lyr.name()}): {res[1]}"
    except Exception as e:
        return False, f"GPKG eksport ebaõnnestus: {str(e)}"

    # 2. Export to XLSX (optional)
    if xlsx_path:
        try:
            options_xls = QgsVectorFileWriter.SaveVectorOptions()
            options_xls.driverName = "XLSX"
            first_xls = True
            for lyr in layers:
                if not is_layer_valid(lyr):
                    continue
                options_xls.layerName = lyr.name()
                if first_xls:
                    options_xls.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
                    first_xls = False
                else:
                    options_xls.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

                QgsVectorFileWriter.writeAsVectorFormatV3(lyr, xlsx_path, transform_context, options_xls)
        except Exception as e:
            return False, f"Exceli eksport ebaõnnestus: {str(e)}"

    return True, ""
