# -*- coding: utf-8 -*-
"""
Main QGIS Plugin Entry Class (NaturaTopoKontrollPlugin).
Handles toolbar icon, Vector menu registration, and dock lifecycle.
"""

import os
from qgis.PyQt.QtGui import QIcon

from .qt_compat import QAction, RIGHT_DOCK_AREA
from .ui_dock import NaturaTopoKontrollDock


class NaturaTopoKontrollPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dock_widget = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(
            QIcon(icon_path),
            "Natura Topo Kontroll",
            self.iface.mainWindow()
        )
        self.action.setToolTip("Ava Natura Topo Kontroll (ID-kontroll, WFS ja MapInfo topoloogia)")
        self.action.setCheckable(True)
        self.action.triggered.connect(self.toggle_dock)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("&Natura Topo Kontroll", self.action)

    def toggle_dock(self, checked: bool):
        if self.dock_widget is None:
            self.dock_widget = NaturaTopoKontrollDock(self.iface, self.iface.mainWindow())
            self.dock_widget.visibilityChanged.connect(self._on_dock_visibility_changed)
            self.iface.addDockWidget(RIGHT_DOCK_AREA, self.dock_widget)

        if checked:
            self.dock_widget.show()
            self.dock_widget.raise_()
        else:
            self.dock_widget.hide()

    def _on_dock_visibility_changed(self, visible: bool):
        if self.action:
            self.action.setChecked(visible)

    def unload(self):
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginVectorMenu("&Natura Topo Kontroll", self.action)
            self.action = None
