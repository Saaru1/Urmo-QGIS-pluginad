# -*- coding: utf-8 -*-
"""
Step 5 Module: Sõlmed (MapInfo Check Regions -> Intersections).
Detects all boundary self-intersections, figure-8 bowties, backtracking spikes,
and pinch points within the MapInfo coordinate grid tolerance.
"""

import math
from qgis.core import (
    QgsFeature, QgsGeometry, QgsPointXY, QgsFields, QgsWkbTypes,
    QgsMemoryProviderUtils, Qgis
)
from .qt_compat import make_field, extract_rings_as_point_lists


def _validate_geometry_qgis_internal(geom: QgsGeometry):
    """Calls QGIS internal geometry validator safely across QGIS 3 and QGIS 4."""
    try:
        if hasattr(Qgis, "GeometryValidationEngine"):
            return geom.validateGeometry(Qgis.GeometryValidationEngine.QgisInternal)
    except Exception:
        pass
    try:
        if hasattr(QgsGeometry, "ValidatorQgis"):
            return geom.validateGeometry(QgsGeometry.ValidatorQgis)
    except Exception:
        pass
    try:
        return geom.validateGeometry()
    except Exception:
        return []


def run_step5_intersections(
    geoms_dict: dict,
    obj_ids: dict,
    obj_sources: dict,
    crs,
    settings
):
    """
    Finds self-intersections and boundary knots ('Sõlmed') matching MapInfo's
    Check Regions -> Intersections behavior.
    """
    solmed_fields = QgsFields()
    solmed_fields.append(make_field("obj_id", "string"))
    solmed_fields.append(make_field("vea_kirjeldus", "string"))
    solmed_fields.append(make_field("allikas", "string"))

    solmed_layer = QgsMemoryProviderUtils.createMemoryLayer(
        "Sõlmed", solmed_fields, QgsWkbTypes.Point, crs
    )
    solmed_pr = solmed_layer.dataProvider()
    solmed_feats = []

    for fid, g in geoms_dict.items():
        src = obj_sources[fid]
        if hasattr(settings, 'is_source_reported'):
            if not settings.is_source_reported(src):
                continue
        elif settings.only_input_related and src not in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM"):
            continue

        oid = obj_ids[fid]
        src = obj_sources[fid]
        found_points = []

        # 5A: QGIS native segment validator
        qgis_errors = _validate_geometry_qgis_internal(g)
        for err in qgis_errors:
            if err.hasWhere():
                pt = err.where()
                found_points.append((QgsPointXY(pt.x(), pt.y()), err.what()))

        # 5B: Explicit MapInfo non-adjacent segment crossing & snap pinch detector
        rings = extract_rings_as_point_lists(g)
        for ring in rings:
            pts = ring[:-1]
            n = len(pts)
            if n < 3:
                continue

            segs = [(pts[k], pts[(k + 1) % n]) for k in range(n)]
            for s1_idx in range(n):
                p1, p2 = segs[s1_idx]
                seg1_geom = QgsGeometry.fromPolylineXY([p1, p2])
                for s2_idx in range(s1_idx + 2, n):
                    if s1_idx == 0 and s2_idx == n - 1:
                        continue
                    q1, q2 = segs[s2_idx]
                    if (
                        max(p1.x(), p2.x()) + settings.snap_grid_m < min(q1.x(), q2.x())
                        or max(q1.x(), q2.x()) + settings.snap_grid_m < min(p1.x(), p2.x())
                        or max(p1.y(), p2.y()) + settings.snap_grid_m < min(q1.y(), q2.y())
                        or max(q1.y(), q2.y()) + settings.snap_grid_m < min(p1.y(), p2.y())
                    ):
                        continue
                    seg2_geom = QgsGeometry.fromPolylineXY([q1, q2])
                    if seg1_geom.intersects(seg2_geom):
                        inter_g = seg1_geom.intersection(seg2_geom)
                        if not inter_g.isEmpty():
                            ipt = inter_g.centroid().asPoint()
                            found_points.append((ipt, "Piiri eneselõikumine (MapInfo Intersection)"))
                    elif settings.snap_grid_m > 0 and seg1_geom.distance(seg2_geom) <= settings.snap_grid_m:
                        near_g = seg1_geom.shortestLine(seg2_geom)
                        if not near_g.isEmpty():
                            ipt = near_g.centroid().asPoint()
                            found_points.append((ipt, "Sõlme puude MapInfo täpsusvõrgus (< 1 mm)"))

        unique_pts = []
        for pt, msg in found_points:
            if not any(math.hypot(pt.x() - up.x(), pt.y() - up.y()) < 0.005 for up, _ in unique_pts):
                unique_pts.append((pt, msg))

        for pt, msg in unique_pts:
            sf = QgsFeature(solmed_fields)
            sf.setGeometry(QgsGeometry.fromPointXY(pt))
            sf["obj_id"] = oid
            sf["vea_kirjeldus"] = msg
            sf["allikas"] = src
            solmed_feats.append(sf)

    solmed_pr.addFeatures(solmed_feats)
    solmed_layer.updateExtents()
    return solmed_layer, len(solmed_feats)
