# -*- coding: utf-8 -*-
"""
Main Dockable UI Panel Module (NaturaTopoKontrollDock):
- Toolbar buttons ('1. ID-kontroll', '2. Koosta kiht', '▶ Start (Sammud 3–7)', '⚙')
- Drag-and-Drop windows for Vector Layer and Excel (.xlsx)
- 'Tulemused' interactive findings tree & HTML log browser
- 'Näita kaardil' toggle button
"""

import os
import re
from datetime import datetime

from qgis.core import QgsProject, QgsVectorLayer, QgsLayerTreeLayer
from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextBrowser, QTreeWidget, QTreeWidgetItem, QFrame, QSplitter,
    QMessageBox, QProgressBar, QApplication, QDialog, QFormLayout, QComboBox, QFileDialog
)

from .qt_compat import (
    VERTICAL_ORIENTATION, USER_ROLE, DIALOG_ACCEPTED, exec_dialog, QMenu, exec_menu, MB_YES, MB_NO, is_layer_valid, extract_polygon_parts, CUSTOM_CONTEXT_MENU, ASCENDING_ORDER, DESCENDING_ORDER
)
from .step1_id_check import (
    normalize_id_value, read_excel_workbook, auto_detect_sheet_and_id_fields,
    run_step1_id_check
)
from .step2_wfs_worklayer import (
    DEFAULT_WFS_URL, run_step2_build_work_layer
)
from .topology_runner import (
    MapInfoTopologySettings, run_steps_3_to_7_topology
)
from .ui_widgets import (
    MODERN_STYLESHEET, SingleItemDropZone, IdFieldSelectDialog,
    CalibrationSettingsDialog, ExportDialog, AutoFixDialog
)
from .export_results import export_layers_to_gpkg_and_xlsx, export_repaired_base_layer
from .auto_fixer import run_auto_fix, append_wfs_to_excel




class CompareIdsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🔍 Võrdle ID-sid (Kadu kontroll)")
        self.setMinimumWidth(400)
        self.setMinimumHeight(350)
        layout = QVBoxLayout(self)
        
        info = QLabel("Kontrolli, kas algse kihi ID-d on parandatud kihil olemas:")
        layout.addWidget(info)
        
        form = QFormLayout()
        self.cb_lyr1 = QComboBox()
        self.cb_fld1 = QComboBox()
        self.cb_lyr2 = QComboBox()
        self.cb_fld2 = QComboBox()
        
        self.layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.type() == QgsVectorLayer.VectorLayer:
                self.layers.append(lyr)
                self.cb_lyr1.addItem(lyr.name(), lyr.id())
                self.cb_lyr2.addItem(lyr.name(), lyr.id())
                
        self.cb_lyr1.currentIndexChanged.connect(self.update_fields1)
        self.cb_lyr2.currentIndexChanged.connect(self.update_fields2)
        self.update_fields1()
        self.update_fields2()
        
        form.addRow("Algne kiht:", self.cb_lyr1)
        form.addRow("Algne ID veerg:", self.cb_fld1)
        form.addRow("Uus (parandatud) kiht:", self.cb_lyr2)
        form.addRow("Uus ID veerg:", self.cb_fld2)
        layout.addLayout(form)
        
        self.btn_compare = QPushButton("Võrdle ID-sid")
        self.btn_compare.setStyleSheet("background-color: #0F766E; color: white; font-weight: bold; padding: 6px; border-radius: 4px;")
        self.btn_compare.clicked.connect(self.do_compare)
        layout.addWidget(self.btn_compare)
        
        self.res_label = QTextBrowser()
        layout.addWidget(self.res_label)
        
    def update_fields1(self):
        self.cb_fld1.clear()
        lyr_id = self.cb_lyr1.currentData()
        if not lyr_id: return
        lyr = QgsProject.instance().mapLayer(lyr_id)
        if lyr:
            self.cb_fld1.addItems([f.name() for f in lyr.fields()])
            
    def update_fields2(self):
        self.cb_fld2.clear()
        lyr_id = self.cb_lyr2.currentData()
        if not lyr_id: return
        lyr = QgsProject.instance().mapLayer(lyr_id)
        if lyr:
            self.cb_fld2.addItems([f.name() for f in lyr.fields()])
            
    def do_compare(self):
        l1 = QgsProject.instance().mapLayer(self.cb_lyr1.currentData())
        l2 = QgsProject.instance().mapLayer(self.cb_lyr2.currentData())
        f1 = self.cb_fld1.currentText()
        f2 = self.cb_fld2.currentText()
        
        if not l1 or not l2 or not f1 or not f2: return
        
        set1 = set()
        for f in l1.getFeatures():
            from .step1_id_check import normalize_id_value
            v = normalize_id_value(f[f1])
            if v: set1.add(v)
            
        set2 = set()
        for f in l2.getFeatures():
            from .step1_id_check import normalize_id_value
            v = normalize_id_value(f[f2])
            if v: set2.add(v)
            
        missing = set1 - set2
        added = set2 - set1
        
        res = f"<b>Tulemused:</b><br>"
        res += f"Algsel kihil: {len(set1)} unikaalset ID-d<br>"
        res += f"Uuel kihil: {len(set2)} unikaalset ID-d<br><br>"
        
        if missing:
            res += f"<span style='color:#DC2626;'><b>Kadunud ID-d ({len(missing)} tk):</b><br>" + ", ".join(sorted(missing)) + "</span><br><br>"
        else:
            res += "<span style='color:#15803D;'><b>Kõik algsed ID-d on uuel kihil olemas!</b></span><br><br>"
            
        if added:
            res += f"<span style='color:#2563EB;'><b>Lisandunud ID-d ({len(added)} tk):</b><br>" + ", ".join(sorted(added)) + "</span>"
            
        self.res_label.setHtml(res)

class ProfileRulesDialog(QDialog):
    """
    Displays the explanation and detailed overlap rule matrix for Profile 1 and Profile 2.
    Dynamically renders active rules from QSettings/defaults.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Kontrolliprofiilide info ja reeglid")
        self.resize(720, 560)
        layout = QVBoxLayout(self)

        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)

        from .step4_overlaps import get_profile2_rules
        rules = get_profile2_rules()

        table_rows = []
        for r in rules:
            src = r.get("source", "")
            alwd = str(r.get("allowed", ""))
            desc = f" <i>({r['description']})</i>" if r.get("description") else ""

            # Formatting
            alwd_fmt = alwd
            if "kõik" in alwd.lower() or "all" in alwd.lower():
                alwd_fmt = re.sub(r'\b(kõik|all)\b', r'<span class="rule-all">\1</span>', alwd_fmt, flags=re.IGNORECASE)
            if "plk" in alwd.lower():
                alwd_fmt = re.sub(r'\b(plk)\b', r'<b>PLK</b>', alwd_fmt, flags=re.IGNORECASE)
            if "v.a" in alwd.lower() or "va " in alwd.lower() or "except" in alwd.lower():
                alwd_fmt = re.sub(r'(\(?(?:v\.a\.?|va|except)[^\)]*\)?)', r'<span class="rule-except">\1</span>', alwd_fmt, flags=re.IGNORECASE)

            table_rows.append(f"""
                <tr>
                    <td><span class="code">{src}</span>{desc}</td>
                    <td>{alwd_fmt}</td>
                </tr>
            """)

        table_rows_html = "\n".join(table_rows)

        html = f"""
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; font-size: 13px; color: #1E293B; line-height: 1.5; }}
            h2 {{ color: #0F766E; margin-top: 0; margin-bottom: 6px; border-bottom: 2px solid #0F766E; padding-bottom: 4px; font-size: 18px; }}
            h3 {{ color: #0F172A; margin-top: 14px; margin-bottom: 6px; font-size: 14px; font-weight: bold; }}
            .badge {{ display: inline-block; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; margin-right: 6px; }}
            .badge-p1 {{ background: #E0F2FE; color: #0369A1; border: 1px solid #BAE6FD; }}
            .badge-p2 {{ background: #DCFCE7; color: #15803D; border: 1px solid #BBF7D0; }}
            table {{ width: 100%; border-collapse: collapse; margin-top: 8px; margin-bottom: 12px; }}
            th {{ background-color: #F1F5F9; text-align: left; padding: 7px 10px; border: 1px solid #CBD5E1; font-weight: 600; color: #334155; }}
            td {{ padding: 6px 10px; border: 1px solid #E2E8F0; vertical-align: top; }}
            tr:nth-child(even) td {{ background-color: #F8FAFC; }}
            .code {{ font-family: Consolas, monospace; font-weight: bold; color: #0F766E; }}
            .rule-all {{ color: #15803D; font-weight: bold; }}
            .rule-except {{ color: #DC2626; font-style: italic; }}
            .note {{ background: #EFF6FF; border-left: 4px solid #3B82F6; padding: 8px 12px; margin-top: 10px; border-radius: 2px; }}
        </style>

        <h2>ℹ Kontrolliprofiilide reeglid</h2>

        <h3><span class="badge badge-p1">Profiil 1</span> Tavaline (kõik vead)</h3>
        <p>Kontrollib kõiki topoloogilisi kattuvusi, auke ja geomeetrilisi vigu ilma eranditeta. Kuvatakse kõik lõikumised ja ülekatted.</p>

        <h3><span class="badge badge-p2">Profiil 2</span> Lubatud kattuvused</h3>
        <p>Eirab automaatselt Natura elupaigatüüpide (põhitüüpide) omavahelisi lubatud kattuvusi vastavalt aktiivsele reeglistikule ({len(rules)} reeglit):</p>

        <table>
            <thead>
                <tr>
                    <th style="width: 32%;">Elupaigatüüp</th>
                    <th>Lubatud kattuda elupaikadega</th>
                </tr>
            </thead>
            <tbody>
                {table_rows_html}
            </tbody>
        </table>

        <p><b>PLK (poollooduslikud kooslused):</b><br>
        <span class="code">1630*, 5130, 6210, 6210*, 6270*, 6280*, 6410, 6430, 6450, 6510, 6530*, 7230, 9070</span></p>

        <div class="note">
            <b>Reeglite haldamine:</b> Neid lubatud kattuvuste reegleid saab vabalt muuta, kustutada ja uusi juurde lisada seadete akna (⚙) lehelt <b>"Profiil 2 lubatud kattuvused"</b>.<br><br>
            <b>Põhitüübi prioriteet:</b> Reeglite kontrollimisel eelistatakse <b>Exceli failis</b> määratud elupaigatüüpi (veerg <i>Elupaigatüübi kood (Natura kood)</i>). Kui Excelis tüüpi pole, kasutatakse WFS kihi välja <b>pohityyp</b>.<br><br>
            <b>Tase 2 auto-fix ja Excel:</b> Uutele WFS-ist juurde lisatud naabritele täidetakse Exceli veerg <i>PäN = JAH/EI</i> automaatselt (JAH kui WFS-is leidub kr_kood, muidu EI), säilitades sisendobjektide algsed väärtused.
        </div>
        """
        browser.setHtml(html)
        layout.addWidget(browser)

        btn_box = QHBoxLayout()
        btn_box.addStretch()
        btn_close = QPushButton("Sulge")
        btn_close.setStyleSheet("background-color: #0F766E; color: white; font-weight: bold; padding: 6px 16px; border-radius: 4px;")
        btn_close.clicked.connect(self.accept)
        btn_box.addWidget(btn_close)
        layout.addLayout(btn_box)


def _natural_sort_key(s):
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', str(s))]


class SortableTreeItem(QTreeWidgetItem):
    def __lt__(self, other):
        # Keep top-level items in natural step order (Samm 1..7)
        if not self.parent() and not other.parent():
            m1 = re.search(r'Samm\s*(\d+)', str(self.text(0)))
            m2 = re.search(r'Samm\s*(\d+)', str(other.text(0)))
            if m1 and m2:
                return int(m1.group(1)) < int(m2.group(1))
            return False

        col = self.treeWidget().sortColumn() if self.treeWidget() else 0
        t1 = str(self.text(col)).strip()
        t2 = str(other.text(col)).strip()

        # Pure numeric sort (handles negative numbers like -1762945083 or decimals)
        try:
            return float(t1) < float(t2)
        except ValueError:
            pass

        # For metric column (column 2), extract first numeric value (e.g. 0.05 ha, 5.22 m2, 35.50 mm)
        if col == 2:
            m1 = re.search(r'[-+]?\d+(?:[.,]\d+)?', t1)
            m2 = re.search(r'[-+]?\d+(?:[.,]\d+)?', t2)
            if m1 and m2:
                try:
                    v1 = float(m1.group(0).replace(',', '.'))
                    v2 = float(m2.group(0).replace(',', '.'))
                    if v1 != v2:
                        return v1 < v2
                except ValueError:
                    pass

        # Fallback to natural alphanumeric sort (e.g. US1 < US2 < US10)
        return _natural_sort_key(t1) < _natural_sort_key(t2)

class NaturaTopoKontrollDock(QDockWidget):
    """
    Main non-modal Dock Widget so user can freely work in QGIS canvas while keeping
    step logs and interactive topology results under eye.
    """
    def __init__(self, iface, parent=None):
        super().__init__("Natura Topo Kontroll", parent)
        self.iface = iface
        self.topo_settings = MapInfoTopologySettings()
        self.wfs_url = DEFAULT_WFS_URL
        self.use_offline_wfs = False
        self.offline_wfs_layer = None

        self.auto_skip_id_dialog = False
        self.selected_layer_id_field = ""
        self.selected_xlsx_sheet = ""
        self.selected_xlsx_id_field = ""
        self.xlsx_workbook = {}

        self.work_layer = None
        self.result_layers = {}
        self.result_group_name = "Kontrolli tulemused (Natura)"
        self.step1_ok = False

        self._init_ui()

    def _init_ui(self):
        container = QWidget()
        container.setObjectName("MainPanel")
        container.setStyleSheet(MODERN_STYLESHEET)
        main_layout = QVBoxLayout(container)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)

        # 1. UPPER PLUGIN TOOLBAR (2 Rows for better docking support)
        toolbar_frame = QFrame()
        toolbar_frame.setObjectName("ToolbarCard")
        tb_layout = QVBoxLayout(toolbar_frame)
        tb_layout.setContentsMargins(8, 6, 8, 6)
        tb_layout.setSpacing(6)

        row1 = QHBoxLayout()
        self.btn_id_check = QPushButton("1. ID-kontroll")
        self.btn_id_check.setProperty("class", "ToolbarBtn")
        self.btn_id_check.setEnabled(False)
        self.btn_id_check.clicked.connect(self.on_step1_id_check)
        row1.addWidget(self.btn_id_check)

        self.btn_build_layer = QPushButton("2. Koosta kiht")
        self.btn_build_layer.setProperty("class", "ToolbarBtn")
        self.btn_build_layer.setEnabled(False)
        self.btn_build_layer.clicked.connect(self.on_step2_build_work_layer)
        row1.addWidget(self.btn_build_layer)

        # Profile selection (between Koosta kiht and Start button)
        self.combo_profile = QComboBox()
        self.combo_profile.setObjectName("ProfileCombo")
        self.combo_profile.setToolTip("Vali kontrolliprofiil. Paremklõps rippmenüül määrab valitud profiili vaikimisi profiiliks.")
        self.combo_profile.setContextMenuPolicy(CUSTOM_CONTEXT_MENU)
        self.combo_profile.customContextMenuRequested.connect(self._on_profile_context_menu)
        self._populate_profiles()
        row1.addWidget(self.combo_profile)

        self.btn_profile_info = QPushButton("ℹ")
        self.btn_profile_info.setObjectName("ProfileInfoBtn")
        self.btn_profile_info.setToolTip("Vaata kontrolliprofiilide reegleid ja lubatud kattuvusi")
        self.btn_profile_info.setFixedWidth(28)
        self.btn_profile_info.setStyleSheet("font-weight: bold; font-size: 13px; padding: 2px;")
        self.btn_profile_info.clicked.connect(self.on_show_profile_rules_info)
        row1.addWidget(self.btn_profile_info)

        self.btn_start_topo = QPushButton("▶ Start (EELIS kontroll)")
        self.btn_start_topo.setObjectName("StartBtn")
        self.btn_start_topo.setEnabled(False)
        self.btn_start_topo.clicked.connect(self.on_steps3_to_7_start)
        row1.addWidget(self.btn_start_topo)
        
        row1.addStretch()
        
        self.btn_compare_ids = QPushButton("🔍 Kadu?")
        self.btn_compare_ids.setObjectName("SecondaryBtn")
        self.btn_compare_ids.setToolTip("Võrdle kahte kihti ID-de kao osas")
        self.btn_compare_ids.clicked.connect(self.on_open_compare_dialog)
        row1.addWidget(self.btn_compare_ids)
        
        tb_layout.addLayout(row1)

        row2 = QHBoxLayout()
        self.btn_show_on_map = QPushButton("👁 Näita kaardil (Sees)")
        self.btn_show_on_map.setObjectName("ToggleMapBtn")
        self.btn_show_on_map.setCheckable(True)
        self.btn_show_on_map.setChecked(True)
        self.btn_show_on_map.setEnabled(False)
        self.btn_show_on_map.toggled.connect(self._on_toggle_map_layers)
        row2.addWidget(self.btn_show_on_map)
        
        self.btn_auto_fix = QPushButton("🪄 Paranda...")
        self.btn_auto_fix.setObjectName("SecondaryBtn")
        self.btn_auto_fix.setEnabled(False)
        self.btn_auto_fix.clicked.connect(self.on_auto_fix_clicked)
        row2.addWidget(self.btn_auto_fix)
        
        self.btn_export = QPushButton("💾 Aruanne...")
        self.btn_export.setObjectName("SecondaryBtn")
        self.btn_export.setToolTip("Ekspordi vigade aruanne GPKG/XLSX")
        self.btn_export.setEnabled(False)
        self.btn_export.clicked.connect(self.on_export_results)
        row2.addWidget(self.btn_export)

        self.btn_export_fixes = QPushButton("💾 Parandatud baas...")
        self.btn_export_fixes.setObjectName("SecondaryBtn")
        self.btn_export_fixes.setToolTip("Salvesta parandatud Töökiht ja uuendatud Excel ketale")
        self.btn_export_fixes.setEnabled(False)
        self.btn_export_fixes.clicked.connect(self.on_export_fixes)
        row2.addWidget(self.btn_export_fixes)

        self.btn_clear_log = QPushButton("Puhasta")
        self.btn_clear_log.setObjectName("SecondaryBtn")
        self.btn_clear_log.setEnabled(False)
        self.btn_clear_log.clicked.connect(self._clear_results_panel)
        row2.addWidget(self.btn_clear_log)
        
        row2.addStretch()
        
        self.btn_settings = QPushButton("⚙")
        self.btn_settings.setObjectName("SecondaryBtn")
        self.btn_settings.clicked.connect(self.on_open_settings)
        row2.addWidget(self.btn_settings)
        tb_layout.addLayout(row2)

        main_layout.addWidget(toolbar_frame)

        # 2. DRAG AND DROP WINDOWS (1 Layer + 1 XLSX)
        self.layer_drop = SingleItemDropZone(
            title="Sisendkiht (TAB / SHP / GPKG)",
            subtitle_hint="Lohista vektorkiht siia (kaustast või QGISi kihiloendist) või vajuta 'Vali fail...'",
            mode="layer",
            iface=self.iface
        )
        self.layer_drop.itemChanged.connect(self._on_inputs_changed)
        main_layout.addWidget(self.layer_drop)

        self.xlsx_drop = SingleItemDropZone(
            title="Atribuuttabel (.xlsx)",
            subtitle_hint="Lohista Exceli (.xlsx) fail siia või vajuta 'Vali fail...'",
            mode="xlsx",
            iface=self.iface
        )
        self.xlsx_drop.itemChanged.connect(self._on_inputs_changed)
        main_layout.addWidget(self.xlsx_drop)

        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumHeight(8)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #CBD5E1;
                border-radius: 4px;
                background-color: #F1F5F9;
            }
            QProgressBar::chunk {
                background-color: #0284C7;
                border-radius: 3px;
            }
        """)
        self.progress_bar.hide()
        main_layout.addWidget(self.progress_bar)

        self.progress_lbl = QLabel("")
        self.progress_lbl.setStyleSheet("color: #0369A1; font-size: 11px; font-weight: 600; margin-top: 1px; margin-bottom: 2px;")
        self.progress_lbl.hide()
        main_layout.addWidget(self.progress_lbl)

        # 3. 'TULEMUSED' PANEL
        res_header = QHBoxLayout()
        res_title = QLabel(
            "<b>Tulemused</b> <span style='color:#64748B;font-size:11px;'>"
            "(Topeltklõps real suurendab veale kaardil)</span>"
        )
        res_header.addWidget(res_title)
        res_header.addStretch()
        main_layout.addLayout(res_header)

        splitter = QSplitter()
        splitter.setOrientation(VERTICAL_ORIENTATION)

        self.findings_tree = QTreeWidget()
        self.findings_tree.setSortingEnabled(True)
        self.findings_tree.setHeaderLabels(
            ["Samm / Kategooria", "ID / Asukoht", "Väärtus / Detailid"]
        )
        self.findings_tree.header().setStretchLastSection(True)
        self.findings_tree.itemDoubleClicked.connect(self._on_finding_double_clicked)
        self.findings_tree.setContextMenuPolicy(CUSTOM_CONTEXT_MENU)
        self.findings_tree.customContextMenuRequested.connect(self._on_tree_context_menu)
        splitter.addWidget(self.findings_tree)

        self.log_browser = QTextBrowser()
        self.log_browser.setOpenExternalLinks(False)
        self.log_browser.setPlaceholderText("Sammude 1–7 logi ilmub siia...")
        splitter.addWidget(self.log_browser)
        splitter.setSizes([180, 150])

        main_layout.addWidget(splitter, 1)


        self.setWidget(container)

    def _show_progress(self, initial_pct: int = 0, msg: str = ""):
        self.progress_bar.setValue(initial_pct)
        self.progress_bar.show()
        if msg:
            self.progress_lbl.setText(f"{msg} ({initial_pct}%)")
        self.progress_lbl.show()
        if self.iface and hasattr(self.iface, "statusBarIface") and self.iface.statusBarIface():
            self.iface.statusBarIface().showMessage(msg, 3000)
        QApplication.processEvents()

    def _update_progress(self, pct: int, msg: str = ""):
        self.progress_bar.setValue(pct)
        if msg:
            self.progress_lbl.setText(f"{msg} ({pct}%)")
            if self.iface and hasattr(self.iface, "statusBarIface") and self.iface.statusBarIface():
                self.iface.statusBarIface().showMessage(msg, 3000)
        QApplication.processEvents()

    def _hide_progress(self):
        self.progress_bar.hide()
        self.progress_lbl.hide()
        self.progress_lbl.setText("")
        QApplication.processEvents()

    def on_open_compare_dialog(self):
        dlg = CompareIdsDialog(self)
        exec_dialog(dlg)

    def on_export_fixes(self):
        export_layer = None
        if hasattr(self, 'last_repaired_layer') and is_layer_valid(self.last_repaired_layer):
            export_layer = self.last_repaired_layer
        elif self.layer_drop.has_item():
            export_layer = self.layer_drop.loaded_layer

        if not export_layer or not self.xlsx_drop.has_item():
            QMessageBox.warning(self, "Viga", "Parandatud baaskiht või Excel puudub!")
            return

        import shutil

        # File type filter in exact requested order: .TAB, .SHP, .GPKG
        file_filter = "MapInfo TAB (*.tab);;ESRI Shapefile (*.shp);;GeoPackage (*.gpkg)"
        chosen_path, selected_filter = QFileDialog.getSaveFileName(
            self, "Salvesta parandatud baaskiht", "Parandatud_Baas.tab", file_filter
        )
        if not chosen_path:
            return

        ext = os.path.splitext(chosen_path)[1].lower()
        if not ext:
            if "(*.tab)" in selected_filter:
                chosen_path += ".tab"
                ext = ".tab"
            elif "(*.shp)" in selected_filter:
                chosen_path += ".shp"
                ext = ".shp"
            elif "(*.gpkg)" in selected_filter:
                chosen_path += ".gpkg"
                ext = ".gpkg"
            else:
                chosen_path += ".tab"
                ext = ".tab"

        xlsx_path = os.path.splitext(chosen_path)[0] + ".xlsx"

        success_export, err_msg = export_repaired_base_layer(export_layer, chosen_path)
        if not success_export:
            QMessageBox.critical(self, "Viga", f"Kihi salvestamine ebaõnnestus:\n{err_msg}")
            return

        try:
            # Collect any added WFS IDs
            added_ids = set()
            if hasattr(self, 'added_wfs_ids') and self.added_wfs_ids:
                added_ids.update([str(x) for x in self.added_wfs_ids if str(x).strip()])
            if is_layer_valid(export_layer):
                f_names = [fld.name() for fld in export_layer.fields()]
                for f in export_layer.getFeatures():
                    allikas = str(f.attribute("_allikas") if "_allikas" in f_names else "")
                    if allikas == "PARANDATUD_NAABER":
                        for id_cand in (self.selected_layer_id_field, "id", "sys_id", "_kontroll_id"):
                            if id_cand and id_cand in f_names:
                                val = f.attribute(id_cand)
                                if val is not None and str(val).strip():
                                    added_ids.add(str(val).strip())
                                    break

            if self.xlsx_drop.loaded_path and os.path.exists(self.xlsx_drop.loaded_path):
                if added_ids:
                    wfs_kr_map = {}
                    check_layers = []
                    if is_layer_valid(self.work_layer):
                        check_layers.append(self.work_layer)
                    if is_layer_valid(getattr(self, 'offline_wfs_layer', None)):
                        check_layers.append(self.offline_wfs_layer)

                    for src_lyr in check_layers:
                        field_names = [fld.name() for fld in src_lyr.fields()]
                        kr_fld = None
                        for cand in ("kr_kood", "KR_KOOD", "pän", "pan", "pärandniit"):
                            if cand in field_names:
                                kr_fld = cand
                                break

                        for f in src_lyr.getFeatures():
                            kr = f.attribute(kr_fld) if kr_fld else None
                            for id_fld in ("_kontroll_id", "id", "sys_id", self.selected_layer_id_field):
                                if id_fld and id_fld in field_names:
                                    val = f.attribute(id_fld)
                                    if val is not None and str(val).strip():
                                        wfs_kr_map[str(val).strip()] = kr

                    success = append_wfs_to_excel(
                        self.xlsx_drop.loaded_path,
                        xlsx_path,
                        list(added_ids),
                        self.selected_xlsx_id_field,
                        self.selected_xlsx_sheet,
                        wfs_kr_map=wfs_kr_map
                    )
                    if not success:
                        shutil.copy2(self.xlsx_drop.loaded_path, xlsx_path)
                else:
                    shutil.copy2(self.xlsx_drop.loaded_path, xlsx_path)

            ext_label = ext.upper().lstrip('.')
            self._append_log(
                f"💾 <b>Eksport õnnestus ({ext_label}):</b><br>"
                f"• Kiht: <code>{chosen_path}</code> ({export_layer.featureCount()} objekti)<br>"
                f"• Tabel: <code>{xlsx_path}</code>"
                + (f" (sh {len(added_ids)} Tase 2 lisatud naabrit)" if added_ids else "")
            )
            QMessageBox.information(
                self, "Eksport edukas",
                f"Parandatud kihid salvestati edukalt ({ext_label}):\n{chosen_path} ({export_layer.featureCount()} obj)\n{xlsx_path}"
            )
        except Exception as e:
            QMessageBox.critical(self, "Viga", f"Exceli salvestamine ebaõnnestus: {e}")

    def _on_inputs_changed(self):
        has_layer = self.layer_drop.has_item()
        has_xlsx = self.xlsx_drop.has_item()

        self.step1_ok = False
        self.btn_id_check.setEnabled(has_layer and has_xlsx)
        self.btn_build_layer.setEnabled(has_layer)
        
        if not has_layer:
            self.work_layer = None
            self.result_layers = {}
            self.btn_start_topo.setEnabled(False)
            self.btn_export.setEnabled(False)
            self.btn_export_fixes.setEnabled(False)
            self.btn_auto_fix.setEnabled(False)
            self.btn_show_on_map.setEnabled(False)

        if has_xlsx:
            try:
                self.xlsx_workbook = read_excel_workbook(self.xlsx_drop.loaded_path)
            except Exception as e:
                self.xlsx_workbook = {}
                self._append_log(f"<span style='color:#DC2626;'>Exceli lugemise viga: {e}</span>")
        else:
            self.xlsx_workbook = {}

        if has_layer and has_xlsx and self.xlsx_workbook:
            best_sh, best_lf, best_xf, _ = auto_detect_sheet_and_id_fields(
                self.layer_drop.loaded_layer, self.xlsx_workbook
            )
            if best_lf and best_xf:
                self.selected_xlsx_sheet = best_sh
                self.selected_layer_id_field = best_lf
                self.selected_xlsx_id_field = best_xf
                self.layer_drop.set_step1_status("ready", f"Auto-ID: {best_lf}")
                if len(self.xlsx_workbook) > 1:
                    self.xlsx_drop.set_step1_status("ready", f"Auto-ID: {best_sh} → {best_xf}")
                else:
                    self.xlsx_drop.set_step1_status("ready", f"Auto-ID: {best_xf}")
        elif has_layer:
            l_fields = [f.name() for f in self.layer_drop.loaded_layer.fields()]
            if l_fields and not self.selected_layer_id_field:
                self.selected_layer_id_field = l_fields[0]

    def _append_log(self, html_msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_browser.append(f"<span style='color:#64748B;'>[{ts}]</span> {html_msg}")

    def _clear_results_panel(self):
        self.findings_tree.clear()
        self.log_browser.clear()
        self.btn_export.setEnabled(False)
        self.btn_export_fixes.setEnabled(False)
        self.btn_auto_fix.setEnabled(False)
        self.btn_show_on_map.setEnabled(False)
        self.btn_show_on_map.setChecked(False)

    def on_step1_id_check(self):
        if not (self.layer_drop.has_item() and self.xlsx_drop.has_item()):
            return

        lyr = self.layer_drop.loaded_layer
        try:
            layer_fields = [f.name() for f in lyr.fields()]
        except RuntimeError:
            QMessageBox.warning(self, "Viga", "Kiht on QGISest kustutatud. Palun lisa kiht uuesti.")
            self.layer_drop.clear_item()
            return
        if not layer_fields or not self.xlsx_workbook:
            QMessageBox.warning(self, "Viga", "Kihil või Exceli tabelil puuduvad veerud.")
            return

        best_sh, best_lf, best_xf, conf = auto_detect_sheet_and_id_fields(lyr, self.xlsx_workbook)
        first_sh = next(iter(self.xlsx_workbook.keys()))
        use_sh = best_sh or first_sh
        use_headers = self.xlsx_workbook[use_sh]["headers"]

        if not (self.auto_skip_id_dialog and conf >= 0.75):
            dlg = IdFieldSelectDialog(
                layer=lyr,
                workbook_dict=self.xlsx_workbook,
                best_sheet=use_sh,
                best_layer_f=best_lf or layer_fields[0],
                best_xlsx_f=best_xf or use_headers[0],
                confidence=conf,
                auto_skip_enabled=self.auto_skip_id_dialog,
                parent=self
            )
            if exec_dialog(dlg) != DIALOG_ACCEPTED:
                return
            (
                self.selected_xlsx_sheet,
                self.selected_layer_id_field,
                self.selected_xlsx_id_field,
                self.auto_skip_id_dialog
            ) = dlg.get_selection()
        else:
            self.selected_xlsx_sheet = use_sh
            self.selected_layer_id_field = best_lf or layer_fields[0]
            self.selected_xlsx_id_field = best_xf or use_headers[0]

        sheet_rows = self.xlsx_workbook.get(self.selected_xlsx_sheet, {}).get("rows", [])
        res = run_step1_id_check(
            lyr, self.selected_layer_id_field, sheet_rows, self.selected_xlsx_id_field
        )

        self._remove_tree_category("Samm 1: ID-kontroll")
        sh_label = (
            f"{self.selected_xlsx_sheet}:{self.selected_xlsx_id_field}"
            if len(self.xlsx_workbook) > 1
            else self.selected_xlsx_id_field
        )
        root_item = QTreeWidgetItem(self.findings_tree, [
            "Samm 1: ID-kontroll",
            f"{self.selected_layer_id_field} ↔ {sh_label}",
            "KORRAS ✓" if res["ok"] else "LAHKNEVUS ⚠"
        ])

        blank_info = (
            f" <i>(ignoreeriti {res['skipped_blank_xlsx_rows']} tühja tabelirida Excelis)</i>"
            if res.get("skipped_blank_xlsx_rows", 0) > 0
            else ""
        )

        if res["ok"]:
            self.step1_ok = True
            badge_txt = f"ID klapib ({res['matched_unique']} tk)"
            self.layer_drop.set_step1_status("ok", badge_txt)
            self.xlsx_drop.set_step1_status("ok", badge_txt)
            self._append_log(
                f"<b>Samm 1 (ID-kontroll): <span style='color:#15803D;'>KORRAS ✓</span></b> — "
                f"Kõik {res['matched_unique']} ID-d klapivad 1:1 kihi "
                f"(<code>{self.selected_layer_id_field}</code>) "
                f"ja Exceli töölehe <code>{self.selected_xlsx_sheet}</code> veeru "
                f"(<code>{self.selected_xlsx_id_field}</code>) vahel.{blank_info}"
            )
        else:
            # Informative per-window status badges so user sees immediately where the mismatch lies
            if res["missing_in_xlsx"]:
                self.layer_drop.set_step1_status(
                    "error", f"Puudub Excelis: {len(res['missing_in_xlsx'])} tk"
                )
            elif res["dup_in_layer"]:
                self.layer_drop.set_step1_status(
                    "error", f"Duplikaat kihil: {len(res['dup_in_layer'])} tk"
                )
            elif res["layer_null_fids"]:
                self.layer_drop.set_step1_status(
                    "error", f"Tühi ID kihil: {len(res['layer_null_fids'])} tk"
                )
            else:
                self.layer_drop.set_step1_status("ok", f"Kihi ID-d olemas ({res['layer_total']} tk)")

            if res["missing_in_layer"]:
                self.xlsx_drop.set_step1_status(
                    "error", f"Puudub kihil: {len(res['missing_in_layer'])} tk"
                )
            elif res["dup_in_xlsx"]:
                self.xlsx_drop.set_step1_status(
                    "error", f"Duplikaat Excelis: {len(res['dup_in_xlsx'])} tk"
                )
            else:
                self.xlsx_drop.set_step1_status("ok", f"Exceli ID-d olemas ({res['xlsx_total']} tk)")

            details = []
            if res["missing_in_xlsx"]:
                s = ", ".join(res["missing_in_xlsx"][:15])
                details.append(f"Puudub Excelis ({len(res['missing_in_xlsx'])} tk): <b>{s}</b>")
                for mid in res["missing_in_xlsx"]:
                    it = QTreeWidgetItem(
                        root_item,
                        ["Puudub Excelis (on kihil)", mid, "Lisa Excelisse või kustuta kihilt"]
                    )
                    it.setData(0, USER_ROLE, ("layer_id", mid))
            if res["missing_in_layer"]:
                s = ", ".join(res["missing_in_layer"][:15])
                details.append(f"Puudub kihil ({len(res['missing_in_layer'])} tk): <b>{s}</b>")
                for mid in res["missing_in_layer"]:
                    QTreeWidgetItem(
                        root_item,
                        ["Puudub kihil (on Excelis)", mid, "Puudub geomeetria kihil"]
                    )
            if res["dup_in_layer"]:
                s = ", ".join(res["dup_in_layer"][:15])
                details.append(f"Duplikaadid kihil: <b>{s}</b>")
                for did in res["dup_in_layer"]:
                    it = QTreeWidgetItem(
                        root_item, ["Duplikaat kihil", did, "Korduv ID vektorkihil"]
                    )
                    it.setData(0, USER_ROLE, ("layer_id", did))
            if res["dup_in_xlsx"]:
                s = ", ".join(res["dup_in_xlsx"][:15])
                details.append(f"Duplikaadid Excelis: <b>{s}</b>")
                for did in res["dup_in_xlsx"]:
                    QTreeWidgetItem(
                        root_item, ["Duplikaat Excelis", did, "Korduv ID Exceli tabelis"]
                    )
            if res["layer_null_fids"]:
                details.append(f"Tühi ID kihil (FID: {res['layer_null_fids']})")

            self._append_log(
                f"<b>Samm 1 (ID-kontroll lehel <code>{self.selected_xlsx_sheet}</code>): "
                f"<span style='color:#DC2626;'>LEITI LAHKNEVUS ⚠</span></b>{blank_info}<br>"
                + "<br>".join(f"• {d}" for d in details)
            )
        root_item.setExpanded(True)

    def on_step2_build_work_layer(self):
        if not self.layer_drop.has_item():
            return
            
        if self.xlsx_drop.has_item() and not self.step1_ok:
            reply = QMessageBox.question(
                self, "ID kontroll vigane või tegemata",
                "Kas oled kindel, et soovid 'Töökihi' koostada ilma eduka ID-kontrollita?",
                MB_YES | MB_NO, MB_NO
            )
            if reply == MB_NO:
                return

        lyr = self.layer_drop.loaded_layer
        try:
            if not self.selected_layer_id_field:
                fields = [f.name() for f in lyr.fields()]
                self.selected_layer_id_field = fields[0] if fields else "id"
        except RuntimeError:
            QMessageBox.warning(self, "Viga", "Kiht on QGISest kustutatud. Palun lisa kiht uuesti.")
            self.layer_drop.clear_item()
            return

        self._show_progress(5, "Töökihi koostamise algus...")

        try:
            added_ids = list(getattr(self, 'added_wfs_ids', []))
            if getattr(self, 'xlsx_workbook', None) and self.selected_xlsx_sheet:
                sheet_data = self.xlsx_workbook.get(self.selected_xlsx_sheet, {}).get("rows", [])
                for r in sheet_data:
                    if r.get("Märkus") == "Auto-lisatud Naaber (Tase 2)":
                        rid = normalize_id_value(r.get(self.selected_xlsx_id_field))
                        if rid and rid not in added_ids:
                            added_ids.append(rid)

            res = run_step2_build_work_layer(
                input_layer=lyr,
                input_id_field=self.selected_layer_id_field,
                wfs_url=self.wfs_url,
                offline_wfs_layer=self.offline_wfs_layer if self.use_offline_wfs else None,
                progress_callback=self._update_progress,
                added_wfs_ids=added_ids,
                xlsx_rows=sheet_data if getattr(self, 'xlsx_workbook', None) and self.selected_xlsx_sheet else None,
                xlsx_id_field=self.selected_xlsx_id_field
            )
            self.work_layer = res["work_layer"]
            self._add_or_replace_layer_in_group(self.work_layer, to_bottom=True)

            rep_str = ", ".join(res["wfs_replaced_ids"][:10]) if res["wfs_replaced_ids"] else "0 tk"
            fail_warn = ""
            if res.get("failed_requests"):
                fail_warn = f"<br><span style='color:#D97706;'>⚠ Hoiatus: {len(res['failed_requests'])} WFS plokk-päringut ebaõnnestus (võrguviga või timeout). Osa naabreid võib puududa.</span>"
                
            self._append_log(
                f"<b>Samm 2 (Koosta kiht – 'Töökiht'): <span style='color:#15803D;'>VALMIS ✓</span></b><br>"
                f"• WFS-ist laetud lõikuvaid/naaberkujusid (unikaalseid): <b>{res['wfs_downloaded_count']}</b><br>"
                f"• WFS-ist kustutatud ja sisendkihiga asendatud ID-d ({res['wfs_replaced_count']} tk): "
                f"<code>{rep_str}</code><br>"
                f"• Loodud <b>Töökiht</b> kokku <b>{res['total_work_features']}</b> objektiga "
                f"(kategooriad: <b>Paranduste kiht</b> {res['input_inserted_count']} tk, "
                f"<b>Naabrid</b> {res['wfs_kept_count']} tk).{fail_warn}"
            )

            self._remove_tree_category("Samm 2: Töökiht")
            s2_item = QTreeWidgetItem(self.findings_tree, [
                "Samm 2: Töökiht",
                f"Kokku {res['total_work_features']} objekti",
                f"Paranduste kiht: {res['input_inserted_count']} | Naabrid: {res['wfs_kept_count']}"
            ])
            s2_item.setExpanded(True)
            self.btn_start_topo.setEnabled(True)
            self.btn_clear_log.setEnabled(True)
            self.iface.mapCanvas().refresh()

        except Exception as e:
            self._append_log(f"<b>Samm 2 VIGA:</b> <span style='color:#DC2626;'>{str(e)}</span>")
            QMessageBox.critical(
                self, "Samm 2 viga", f"Töökihi koostamine ebaõnnestus:\n{str(e)}"
            )
        finally:
            self._hide_progress()

    def _get_default_profile(self) -> int:
        val = QSettings().value("NaturaTopoKontroll/DefaultProfile", 1)
        try:
            return int(val)
        except (ValueError, TypeError):
            return 1

    def _populate_profiles(self):
        def_prof = self._get_default_profile()
        curr_idx = self.combo_profile.currentIndex() if hasattr(self, 'combo_profile') else -1
        if curr_idx < 0:
            curr_idx = def_prof - 1

        self.combo_profile.blockSignals(True)
        self.combo_profile.clear()
        
        t1 = "Profiil 1: Tavaline (kõik vead)"
        if def_prof == 1:
            t1 += " [Vaikimisi]"
        self.combo_profile.addItem(t1, 1)

        t2 = "Profiil 2: Lubatud kattuvused"
        if def_prof == 2:
            t2 += " [Vaikimisi]"
        self.combo_profile.addItem(t2, 2)

        if 0 <= curr_idx < self.combo_profile.count():
            self.combo_profile.setCurrentIndex(curr_idx)
        else:
            self.combo_profile.setCurrentIndex(def_prof - 1)
        self.combo_profile.blockSignals(False)

    def _on_profile_context_menu(self, pos):
        menu = QMenu(self)
        curr_idx = self.combo_profile.currentIndex()
        prof_num = self.combo_profile.itemData(curr_idx)
        act = menu.addAction(f"⭐ Määra Profiil {prof_num} vaikimisi profiiliks")
        menu.addSeparator()
        act_info = menu.addAction("ℹ Vaata profiilide reegleid...")
        action = exec_menu(menu, self.combo_profile.mapToGlobal(pos))
        if action == act:
            QSettings().setValue("NaturaTopoKontroll/DefaultProfile", prof_num)
            self._populate_profiles()
            self.combo_profile.setCurrentIndex(curr_idx)
            self._append_log(f"⚙️ <b>Vaikimisi profiiliks määratud:</b> Profiil {prof_num}")
        elif action == act_info:
            self.on_show_profile_rules_info()

    def on_show_profile_rules_info(self):
        dlg = ProfileRulesDialog(self)
        exec_dialog(dlg)

    def on_steps3_to_7_start(self):
        prof_val = self.combo_profile.currentData() if hasattr(self, 'combo_profile') else 1
        self.topo_settings.active_profile = int(prof_val or 1)
        from .step4_overlaps import get_profile2_rules
        self.topo_settings.profile2_rules = get_profile2_rules()
        target_layer = (
            self.work_layer
            if (is_layer_valid(self.work_layer))
            else self.layer_drop.loaded_layer
        )
        if not is_layer_valid(target_layer):
            QMessageBox.warning(
                self,
                "Kiht puudub",
                "Palun käivita esmalt '2. Koosta kiht' või vali sisendkiht."
            )
            return

        id_col = (
            "_kontroll_id"
            if "_kontroll_id" in [f.name() for f in target_layer.fields()]
            else self.selected_layer_id_field
        )
        self._show_progress(10, "Topoloogia kontrolli ettevalmistus...")

        try:
            topo_res = run_steps_3_to_7_topology(
                work_layer=target_layer,
                id_field_name=id_col,
                settings=self.topo_settings,
                progress_callback=self._update_progress
            )
            self.result_layers = topo_res["layers"]
            counts = topo_res["counts"]

            for lname in ["Augud", "Ülekatted", "Sõlmed", "Lühikesed lõigud", "Teravad nurgad"]:
                self._add_or_replace_layer_in_group(self.result_layers[lname], to_bottom=False)

            self._populate_topology_findings_tree(self.result_layers)

            mode_labels = {
                1: "Valik 1 – Täisaruanne (kõik vead, sh WFS naabrid)",
                2: "Valik 2 – Töödeldud kiht (algne sisend + Tase 2 lisatud naabrid) [Vaikimisi]",
                3: "Valik 3 – Ainult algne sisendkiht (välista lisatud naabrite välisvead)"
            }
            curr_mode = getattr(self.topo_settings, 'error_reporting_mode', 2)
            mode_text = mode_labels.get(curr_mode, "Töödeldud kiht (algne sisend + Tase 2 naabrid)")

            self._append_log(
                f"<b>Sammud 3–7 (Topoloogia kontroll kihil '{target_layer.name()}'):</b><br>"
                f"• <b>Kontrolliprofiil:</b> Profiil {getattr(self.topo_settings, 'active_profile', 1)}<br>"
                f"• <b>Raporteerimise ulatus:</b> {mode_text}<br>"
                f"• <b>Samm 3 – Augud (&lt; {self.topo_settings.max_gap_area_ha} ha):</b> {counts['Augud']} tk<br>"
                f"• <b>Samm 4 – Ülekatted:</b> {counts['Ülekatted']} tk<br>"
                f"• <b>Samm 5 – Sõlmed (eneselõikumised):</b> {counts['Sõlmed']} tk<br>"
                f"• <b>Samm 6 – Lühikesed lõigud (&lt; {self.topo_settings.short_segment_mm} mm):</b> {counts['Lühikesed lõigud']} tk<br>"
                f"• <b>Samm 7 – Teravad nurgad (&lt; {self.topo_settings.small_angle_deg}°):</b> {counts['Teravad nurgad']} tk"
            )
            self.btn_export.setEnabled(True)
            self.btn_auto_fix.setEnabled(True)
            self.btn_show_on_map.setEnabled(True)
            self.btn_clear_log.setEnabled(True)
            self._on_toggle_map_layers(self.btn_show_on_map.isChecked())
            self.iface.mapCanvas().refresh()
        except Exception as e:
            self._append_log(f"<b>Sammude 3–7 VIGA:</b> <span style='color:#DC2626;'>{str(e)}</span>")
            QMessageBox.critical(self, "Topoloogia kontrolli viga", str(e))
        finally:
            self._hide_progress()

    def _populate_topology_findings_tree(self, layers_dict: dict):
        step_titles = [
            (
                "Samm 3: Augud",
                "Augud",
                lambda f: (
                    f["id_loend"],
                    f"{f['vea_tyyp']} | {f['pindala_ha']:.2f} ha ({f['pindala_m2']:.1f} m²)"
                )
            ),
            (
                "Samm 4: Ülekatted",
                "Ülekatted",
                lambda f: (
                    f["id_loend"],
                    f"{f['pindala_m2']:.2f} m² ({f['pindala_ha']:.4f} ha) | laius {f['keskm_laius_mm']:.1f} mm"
                )
            ),
            (
                "Samm 5: Sõlmed",
                "Sõlmed",
                lambda f: (f["obj_id"], f"{f['vea_kirjeldus']} ({f['allikas']})")
            ),
            (
                "Samm 6: Lühikesed lõigud",
                "Lühikesed lõigud",
                lambda f: (f["obj_id"], f"{f['pikkus_mm']:.2f} mm ({f['allikas']})")
            ),
            (
                "Samm 7: Teravad nurgad",
                "Teravad nurgad",
                lambda f: (f["obj_id"], f"{f['nurk_kraad']:.2f}° ({f['allikas']})")
            ),
        ]

        for cat_label, lyr_key, formatter in step_titles:
            self._remove_tree_category(cat_label)
            lyr = layers_dict.get(lyr_key)
            if not lyr:
                continue
            cnt = lyr.featureCount()
            status_str = "0 viga ✓" if cnt == 0 else f"{cnt} leidu ⚠"
            cat_item = QTreeWidgetItem(self.findings_tree, [cat_label, lyr_key, status_str])

            for feat in lyr.getFeatures():
                id_txt, detail_txt = formatter(feat)
                child = SortableTreeItem(cat_item, [lyr_key, str(id_txt), str(detail_txt)])
                child.setData(0, USER_ROLE, ("feature_geom", lyr_key, feat.id()))
            cat_item.setExpanded(cnt > 0)

    def _remove_tree_category(self, prefix: str):
        root = self.findings_tree.invisibleRootItem()
        for i in range(root.childCount() - 1, -1, -1):
            if root.child(i).text(0).startswith(prefix):
                root.removeChild(root.child(i))

    def _on_finding_double_clicked(self, item, column):
        data = item.data(0, USER_ROLE)
        if not data:
            return
        kind = data[0]
        canvas = self.iface.mapCanvas()

        if kind == "feature_geom":
            _, lyr_key, fid = data
            lyr = self.result_layers.get(lyr_key)
            if is_layer_valid(lyr):
                feat = lyr.getFeature(fid)
                if feat.isValid() and not feat.geometry().isEmpty():
                    bbox = feat.geometry().boundingBox()
                    if bbox.width() < 5.0 or bbox.height() < 5.0:
                        bbox.grow(12.0)
                    else:
                        bbox.scale(1.8)
                    canvas.setExtent(bbox)
                    canvas.refresh()
                    try:
                        canvas.flashFeatureIds(lyr, [fid])
                    except Exception:
                        pass
        elif kind == "layer_id":
            _, target_id = data
            lyr = self.layer_drop.loaded_layer
            if is_layer_valid(lyr) and self.selected_layer_id_field:
                for feat in lyr.getFeatures():
                    if normalize_id_value(feat[self.selected_layer_id_field]) == target_id:
                        bbox = feat.geometry().boundingBox()
                        bbox.scale(1.8)
                        canvas.setExtent(bbox)
                        canvas.refresh()
                        try:
                            canvas.flashFeatureIds(lyr, [feat.id()])
                        except Exception:
                            pass
                        break

    
    def _on_tree_context_menu(self, pos):
        item = self.findings_tree.itemAt(pos)
        if not item: return

        menu = QMenu(self)
        obj_target_map = {}
        target_group = item.parent() if item.parent() else item

        if item.parent():
            action_pan = menu.addAction("🔍 Liigu valikuni")
            action_ignore_one = menu.addAction("❌ Ignoreeri seda viga")

            # Extract IDs tied to this finding
            raw_ids = [x.strip() for x in re.split(r'[,;/]+', str(item.text(1))) if x.strip()]
            if len(raw_ids) == 1:
                act_obj = menu.addAction(f"🚫 Ignoreeri kõik selle objektiga seotud vead selles grupis ({raw_ids[0]})")
                obj_target_map[act_obj] = set(raw_ids)
            elif len(raw_ids) > 1:
                sub_ignore = menu.addMenu("🚫 Ignoreeri kõik objektiga seotud vead selles grupis")
                for oid in raw_ids:
                    act_single = sub_ignore.addAction(f"Ainult objekt: {oid}")
                    obj_target_map[act_single] = {oid}
                act_all_ids = sub_ignore.addAction(f"Kõik selle vea objektid ({', '.join(raw_ids)})")
                obj_target_map[act_all_ids] = set(raw_ids)

            action_ignore_all = menu.addAction("🗑️ Ignoreeri kõik vead selles grupis")
        else:
            action_ignore_group = menu.addAction("🗑️ Ignoreeri terve kategooria")

        menu.addSeparator()
        action_sort_id_asc = menu.addAction("↕ Sorteeri: ID järgi (A → Z)")
        action_sort_id_desc = menu.addAction("↕ Sorteeri: ID järgi (Z → A)")
        action_sort_val_desc = menu.addAction("↕ Sorteeri: Suuruse järgi (kahanev)")
        action_sort_val_asc = menu.addAction("↕ Sorteeri: Suuruse järgi (tõusev)")

        action = exec_menu(menu, self.findings_tree.viewport().mapToGlobal(pos))
        if not action:
            return

        # 1. Pan
        if item.parent() and action == action_pan:
            data = item.data(0, USER_ROLE)
            if data and data[0] == "feature_geom":
                _, lyr_key, fid = data
                lyr = self.result_layers.get(lyr_key)
                if is_layer_valid(lyr):
                    feat = lyr.getFeature(fid)
                    if feat.isValid() and not feat.geometry().isEmpty():
                        canvas = self.iface.mapCanvas()
                        canvas.setCenter(feat.geometry().centroid().asPoint())
                        canvas.refresh()

        # 2. Ignore single error
        elif item.parent() and action == action_ignore_one:
            lyr_key = self._delete_feature_from_layer(item)
            parent = item.parent()
            parent.removeChild(item)
            self._update_tree_parent_label(parent)
            self._refresh_layers_after_ignore([lyr_key] if lyr_key else None)

        # 3. Ignore all errors tied to specific ID(s) in this group
        elif item.parent() and action in obj_target_map:
            target_ids = obj_target_map[action]
            parent = item.parent()
            items_to_remove = []

            for i in range(parent.childCount()):
                child = parent.child(i)
                child_raw_ids = set([x.strip() for x in re.split(r'[,;/]+', str(child.text(1))) if x.strip()])
                matched = False
                for tid in target_ids:
                    for cid in child_raw_ids:
                        if tid == cid or normalize_id_value(tid) == normalize_id_value(cid):
                            matched = True
                            break
                    if matched:
                        break
                if matched:
                    items_to_remove.append(child)

            if items_to_remove:
                fids_by_layer = {}
                for ch in items_to_remove:
                    data = ch.data(0, USER_ROLE)
                    if data and data[0] == "feature_geom":
                        l_key, fid = data[1], data[2]
                        fids_by_layer.setdefault(l_key, []).append(fid)

                for l_key, fids in fids_by_layer.items():
                    lyr = self.result_layers.get(l_key)
                    if is_layer_valid(lyr):
                        lyr.dataProvider().deleteFeatures(fids)

                for ch in items_to_remove:
                    parent.removeChild(ch)

                self._update_tree_parent_label(parent)
                self._refresh_layers_after_ignore(list(fids_by_layer.keys()))

                self._append_log(
                    f"ℹ <b>Ignoreeritud:</b> eemaldati {len(items_to_remove)} viga kategooriast '{parent.text(0)}' (seotud ID: {', '.join(sorted(target_ids))})."
                )

        # 4. Ignore all in group
        elif item.parent() and action == action_ignore_all:
            parent = item.parent()
            fids_by_layer = {}
            for i in range(parent.childCount()):
                ch = parent.child(i)
                data = ch.data(0, USER_ROLE)
                if data and data[0] == "feature_geom":
                    l_key, fid = data[1], data[2]
                    fids_by_layer.setdefault(l_key, []).append(fid)
            for l_key, fids in fids_by_layer.items():
                lyr = self.result_layers.get(l_key)
                if is_layer_valid(lyr):
                    lyr.dataProvider().deleteFeatures(fids)
            parent.takeChildren()
            self._update_tree_parent_label(parent)
            self._refresh_layers_after_ignore(list(fids_by_layer.keys()))

        # 5. Ignore whole category (when clicked on top-level parent)
        elif not item.parent() and action == action_ignore_group:
            fids_by_layer = {}
            for i in range(item.childCount()):
                ch = item.child(i)
                data = ch.data(0, USER_ROLE)
                if data and data[0] == "feature_geom":
                    l_key, fid = data[1], data[2]
                    fids_by_layer.setdefault(l_key, []).append(fid)
            for l_key, fids in fids_by_layer.items():
                lyr = self.result_layers.get(l_key)
                if is_layer_valid(lyr):
                    lyr.dataProvider().deleteFeatures(fids)
            item.takeChildren()
            self._update_tree_parent_label(item)
            self._refresh_layers_after_ignore(list(fids_by_layer.keys()))

        # 6. Sorting
        elif action == action_sort_id_asc:
            target_group.sortChildren(1, ASCENDING_ORDER)
        elif action == action_sort_id_desc:
            target_group.sortChildren(1, DESCENDING_ORDER)
        elif action == action_sort_val_desc:
            target_group.sortChildren(2, DESCENDING_ORDER)
        elif action == action_sort_val_asc:
            target_group.sortChildren(2, ASCENDING_ORDER)

    def _delete_feature_from_layer(self, item):
        data = item.data(0, USER_ROLE)
        if not data: return None
        kind = data[0]
        if kind == "feature_geom":
            lyr_key = data[1]
            fid = data[2]
            lyr = self.result_layers.get(lyr_key)
            if is_layer_valid(lyr):
                lyr.dataProvider().deleteFeatures([fid])
            return lyr_key
        return None

    def _refresh_layers_after_ignore(self, layer_keys=None):
        if not layer_keys:
            layer_keys = list(self.result_layers.keys()) if hasattr(self, 'result_layers') and self.result_layers else []

        self.progress_lbl.setText("🔄 Värskendan kihti...")
        self.progress_lbl.show()
        if self.iface and hasattr(self.iface, "statusBarIface") and self.iface.statusBarIface():
            self.iface.statusBarIface().showMessage("🔄 Värskendan kihti...", 3000)
        QApplication.processEvents()

        ltv = self.iface.layerTreeView() if self.iface and hasattr(self.iface, "layerTreeView") else None
        for l_key in layer_keys:
            lyr = self.result_layers.get(l_key) if hasattr(self, 'result_layers') and self.result_layers else None
            if is_layer_valid(lyr):
                try:
                    lyr.triggerRepaint()
                except Exception:
                    pass
                if ltv:
                    try:
                        ltv.refreshLayerSymbology(lyr.id())
                    except Exception:
                        pass

        if ltv:
            try:
                ltv.viewport().update()
            except Exception:
                pass

        if self.iface and hasattr(self.iface, "mapCanvas") and self.iface.mapCanvas():
            try:
                self.iface.mapCanvas().refresh()
            except Exception:
                pass

        QApplication.processEvents()
        self.progress_lbl.hide()
        self.progress_lbl.setText("")
        if self.iface and hasattr(self.iface, "statusBarIface") and self.iface.statusBarIface():
            self.iface.statusBarIface().showMessage("Kiht värskendatud ✓", 2000)

    def _update_tree_parent_label(self, parent_item):
        cnt = parent_item.childCount()
        if "Samm 1" in parent_item.text(0):
            if cnt == 0:
                parent_item.setText(2, "KORRAS (Kohandatud) ✓")
            else:
                parent_item.setText(2, f"LAHKNEVUS ({cnt} viga) ⚠")
        else:
            if cnt == 0:
                parent_item.setText(2, "0 viga (Kõik ignoreeritud) ✓")
                clean_text = parent_item.text(0).replace(" (Eiratud)", "")
                parent_item.setText(0, clean_text + " (Eiratud)")
            else:
                parent_item.setText(2, f"{cnt} leidu ⚠")

    def on_export_results(self):
        layers_to_export = []
        if is_layer_valid(self.work_layer):
            layers_to_export.append(self.work_layer)
        for lname in ["Augud", "Ülekatted", "Sõlmed", "Lühikesed lõigud", "Teravad nurgad"]:
            lyr = self.result_layers.get(lname)
            if is_layer_valid(lyr) and lyr.featureCount() > 0:
                layers_to_export.append(lyr)
                
        if not layers_to_export:
            QMessageBox.information(self, "Tühi", "Ekspordiks puuduvad andmed. Käivita esmalt 'Start'.")
            return
            
        dlg = ExportDialog(self)
        if exec_dialog(dlg) == DIALOG_ACCEPTED:
            wants_xlsx = dlg.wants_xlsx()
            
            from qgis.PyQt.QtWidgets import QFileDialog
            gpkg_path, _ = QFileDialog.getSaveFileName(
                self, "Salvesta GPKG aruanne", "Natura_Kontroll_Aruanne.gpkg", "GeoPackage (*.gpkg)"
            )
            
            if gpkg_path:
                if not gpkg_path.lower().endswith('.gpkg'):
                    gpkg_path += '.gpkg'
                    
                xlsx_path = None
                if wants_xlsx:
                    xlsx_path = gpkg_path.replace(".gpkg", ".xlsx")
                    
                success, err = export_layers_to_gpkg_and_xlsx(layers_to_export, gpkg_path, xlsx_path)
                
                if success:
                    msg = f"Eksport edukas!\n\nSalvestatud: {gpkg_path}"
                    if xlsx_path:
                        msg += f"\nExceli aruanne: {xlsx_path}"
                    self._append_log(f"<b>💾 Eksport õnnestus:</b> Andmed salvestati asukohta {gpkg_path}")
                    QMessageBox.information(self, "Eksport edukas", msg)
                else:
                    self._append_log(f"<span style='color:#DC2626;'>Eksport ebaõnnestus: {err}</span>")
                    QMessageBox.critical(self, "Viga", err)



    def on_auto_fix_clicked(self):
        if not is_layer_valid(self.work_layer):
            return
            
        def_gap = self.topo_settings.max_gap_area_ha
        def_over = round(def_gap * 10000.0, 1)
        
        dlg = AutoFixDialog(def_gap, def_over, self)
        if exec_dialog(dlg) == DIALOG_ACCEPTED:
            sett = dlg.get_settings()
            
            self._append_log("⏳ <i>Käivitan automaatparanduse...</i>")
            self._show_progress(5, f"Automaatparanduse ettevalmistus (Tase {sett['level']})...")
            
            try:
                fix_count, added_wfs_ids = run_auto_fix(
                    self.work_layer, 
                    self.result_layers, 
                    sett["level"], 
                    sett["max_gap_ha"], 
                    sett["max_overlap_m2"],
                    progress_callback=self._update_progress
                )
                
                if fix_count == 0:
                    self._append_log("<b>Automaatparandus:</b> Ühtegi viga ei õnnestunud antud reeglitega parandada.")
                    QMessageBox.information(self, "Info", "Ühtegi viga ei parandatud.")
                    return
                
                from .step2_wfs_worklayer import style_work_layer
                style_work_layer(self.work_layer, is_repaired=True)
                if self.iface:
                    ltv = self.iface.layerTreeView()
                    if ltv:
                        try:
                            ltv.refreshLayerSymbology(self.work_layer.id())
                            ltv.viewport().update()
                        except Exception:
                            pass
                    self.iface.mapCanvas().refresh()
                    
                self._append_log(f"<b>🪄 Automaatparandus lõpetatud:</b> muudeti {fix_count} geomeetriat Töökihi siseselt (Tase {sett['level']}).")
                
                import tempfile
                import shutil
                from qgis.PyQt.QtWidgets import QFileDialog
                from qgis.core import QgsVectorLayer, QgsMemoryProviderUtils, QgsFeature, QgsGeometry, QgsFields, QgsWkbTypes
                
                # UUS LOOGIKA: Mõlemad tasemed teevad ajutise mälukihi. Ei mingit ketta eksporti failisüsteemi kaudu.
                old_fields = self.work_layer.fields()
                idx_kontroll = old_fields.indexOf("_kontroll_id")

                new_fields = QgsFields()
                for i in range(old_fields.count()):
                    if i != idx_kontroll:
                        new_fields.append(old_fields.at(i))

                tmp_lyr = QgsMemoryProviderUtils.createMemoryLayer(
                    "tmp", new_fields, QgsWkbTypes.MultiPolygon, self.work_layer.crs()
                )
                tmp_pr = tmp_lyr.dataProvider()

                feats_to_keep = []
                target_sources = ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM") if sett["level"] == 1 else ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM", "PARANDATUD_NAABER")
                
                for f in self.work_layer.getFeatures():
                    allikas = str(f.attribute("_allikas"))
                    if allikas not in target_sources:
                        continue
                        
                    nf = QgsFeature(new_fields)
                    
                    g = QgsGeometry(f.geometry())
                    if not g.isNull() and not g.isEmpty():
                        parts = extract_polygon_parts(g)
                        if parts:
                            multi_poly = []
                            for p in parts:
                                rngs = p.asPolygon()
                                if rngs:
                                    multi_poly.append(rngs)
                            if multi_poly:
                                nf.setGeometry(QgsGeometry.fromMultiPolygonXY(multi_poly))
                    
                    for field in new_fields:
                        fname = field.name()
                        if fname == "_allikas":
                            nf.setAttribute("_allikas", allikas)
                        elif fname == self.selected_layer_id_field and allikas == "PARANDATUD_NAABER":
                            nf.setAttribute(fname, f.attribute("_kontroll_id"))
                        else:
                            try:
                                nf.setAttribute(fname, f.attribute(fname))
                            except Exception:
                                pass
                            
                    feats_to_keep.append(nf)
                        
                tmp_pr.addFeatures(feats_to_keep)
                tmp_lyr.updateExtents()
                style_work_layer(tmp_lyr, is_repaired=True)
                self.last_repaired_layer = tmp_lyr
                self.btn_export_fixes.setEnabled(True)
                self.added_wfs_ids = list(set(added_wfs_ids))

                # Exceli sünkroonimine (Ainult Tase 2 puhul, teeme mälukausta ajutise koopia, failidialoogi vältimiseks)
                if sett["level"] == 2 and added_wfs_ids and self.xlsx_drop.loaded_path:
                    tmp_dir = tempfile.mkdtemp()
                    new_xlsx_path = os.path.join(tmp_dir, f"parandatud_tabel_tase2.xlsx")
                    added_wfs_ids = list(set(added_wfs_ids))
                    
                    wfs_kr_map = {}
                    if is_layer_valid(self.work_layer):
                        f_names = [fld.name() for fld in self.work_layer.fields()]
                        kr_fld = "kr_kood" if "kr_kood" in f_names else None
                        for f in self.work_layer.getFeatures():
                            kr = f.attribute(kr_fld) if kr_fld else None
                            for id_fld in ("_kontroll_id", "id", "sys_id", self.selected_layer_id_field):
                                if id_fld and id_fld in f_names:
                                    val = f.attribute(id_fld)
                                    if val is not None and str(val).strip():
                                        wfs_kr_map[str(val).strip()] = kr

                    if append_wfs_to_excel(
                        self.xlsx_drop.loaded_path,
                        new_xlsx_path,
                        added_wfs_ids,
                        self.selected_xlsx_id_field,
                        self.selected_xlsx_sheet,
                        wfs_kr_map=wfs_kr_map
                    ):
                        self._append_log(f"📝 Exceli faili lisati {len(added_wfs_ids)} uut WFS naabri ID-d (ajutine fail).")
                        self.xlsx_drop.load_xlsx_file(new_xlsx_path)

                if is_layer_valid(self.layer_drop.loaded_layer):
                    node = QgsProject.instance().layerTreeRoot().findLayer(self.layer_drop.loaded_layer.id())
                    if node:
                        node.setItemVisibilityChecked(False)

                base_name = self.layer_drop.loaded_name
                # Puhastame nimest eelmised sufiksid, et vältida pikki lohisevaid nimesid
                base_name = base_name.replace(" [Parandatud (Tase 1)]", "").replace(" [Parandatud (Tase 2)]", "")
                layer_name = f"{base_name} [Parandatud (Tase {sett['level']})]"

                tmp_lyr.setName(layer_name)
                QgsProject.instance().addMapLayer(tmp_lyr, False)
                
                grp = self._get_or_create_result_group()
                grp.addLayer(tmp_lyr)
                
                if is_layer_valid(self.work_layer):
                    # Rename the old Töökiht so Step 2 doesn't overwrite it!
                    self.work_layer.setName(f"Töökiht (Tase {sett['level']} visuaal)")
                    # We don't need to clone it anymore, it stays in the group safely under the new name.

                reply = QMessageBox.question(
                    self, "Parandus valmis",
                    f"Parandatud {fix_count} geomeetriat (Töökiht värviti oranžiks).\n\nKas soovid laadida puhta parandatud baasi uueks sisendiks ja käivitada kontrolli tsükli uuesti?",
                    MB_YES | MB_NO, MB_YES
                )
                
                if reply == MB_YES:
                    self.layer_drop.load_vector_layer(tmp_lyr, layer_name)
                    
                    QApplication.processEvents()
                    # CRITICAL: Force dictionary refresh before running ID check
                    if self.xlsx_drop.loaded_path:
                        self.xlsx_workbook = read_excel_workbook(self.xlsx_drop.loaded_path)
                        
                    self.on_step1_id_check()
                    if getattr(self, 'step1_ok', False):
                        self.on_step2_build_work_layer()
                        self.on_steps3_to_7_start()
                        
            except Exception as e:
                self._append_log(f"<span style='color:#DC2626;'>Automaatparanduse viga: {e}</span>")
                import traceback
                traceback.print_exc()
            finally:
                self._hide_progress()

    def _get_or_create_result_group(self):
        root = QgsProject.instance().layerTreeRoot()
        grp = root.findGroup(self.result_group_name)
        if not grp:
            grp = root.insertGroup(0, self.result_group_name)
        return grp

    def _add_or_replace_layer_in_group(self, layer, to_bottom: bool = False):
        proj = QgsProject.instance()
        grp = self._get_or_create_result_group()

        for child in list(grp.children()):
            if isinstance(child, QgsLayerTreeLayer) and child.name() == layer.name():
                if child.layerId() in proj.mapLayers():
                    proj.removeMapLayer(child.layerId())

        proj.addMapLayer(layer, False)
        if to_bottom:
            grp.addLayer(layer)
        else:
            grp.insertLayer(0, layer)

    def _on_toggle_map_layers(self, checked: bool):
        root = QgsProject.instance().layerTreeRoot()
        grp = root.findGroup(self.result_group_name)
        if grp:
            grp.setItemVisibilityChecked(checked)
        self.btn_show_on_map.setText(
            "👁 Näita kaardil (Sees)" if checked else "👁 Näita kaardil (Väljas)"
        )
        self.iface.mapCanvas().refresh()

    def on_open_settings(self):
        dlg = CalibrationSettingsDialog(
            self.topo_settings, self.wfs_url, self.use_offline_wfs, self
        )
        dlg.testDataGenerated.connect(self._load_generated_test_data)
        if exec_dialog(dlg) == DIALOG_ACCEPTED:
            self.wfs_url, self.use_offline_wfs = dlg.apply_to_settings()
            self._append_log("⚙️ <b>Seaded salvestatud:</b> MapInfo tolerantsid ja Profiil 2 reeglid on uuendatud.")

    def _load_generated_test_data(self, paths: dict):
        wfs_path = paths.get("wfs_path")
        if wfs_path and os.path.exists(wfs_path):
            self.offline_wfs_layer = QgsVectorLayer(wfs_path, "test_wfs_naabrid", "ogr")
            self.use_offline_wfs = True

        sisend_path = paths.get("sisend_path")
        if sisend_path and os.path.exists(sisend_path):
            self.layer_drop._try_load_file_path(sisend_path)
            if self.layer_drop.loaded_layer:
                self.iface.mapCanvas().setExtent(self.layer_drop.loaded_layer.extent())
                self.iface.mapCanvas().refresh()

        ok_xlsx = paths.get("ok_xlsx_path")
        if ok_xlsx and os.path.exists(ok_xlsx):
            self.xlsx_drop.load_xlsx_file(ok_xlsx)

        self._append_log(
            "🧪 <b>Kalibreerimise testandmed on laetud!</b> "
            "Vajuta järjest <b>1. ID-kontroll</b> → <b>2. Koosta kiht</b> → <b>▶ Start (Sammud 3–7)</b>."
        )

