# -*- coding: utf-8 -*-
"""
Step 6 & Step 7 Module:
- Step 6: Lühikesed lõigud (Short segments between nodes < 20 mm)
- Step 7: Teravad nurgad (Sharp angles at vertices < 5 degrees)
"""

import math
from qgis.core import (
    QgsFeature, QgsGeometry, QgsPointXY, QgsFields, QgsWkbTypes,
    QgsMemoryProviderUtils
)
from .qt_compat import make_field, extract_rings_as_point_lists


def run_step6_and_7_segments_angles(
    geoms_dict: dict,
    obj_ids: dict,
    obj_sources: dict,
    crs,
    settings
):
    """
    Runs Step 6 (< 20 mm segments) and Step 7 (< 5 deg vertex angles),
    returning (loigud_layer, loigud_count, nurgad_layer, nurgad_count).
    """
    loigud_fields = QgsFields()
    loigud_fields.append(make_field("obj_id", "string"))
    loigud_fields.append(make_field("pikkus_mm", "double"))
    loigud_fields.append(make_field("allikas", "string"))

    loigud_layer = QgsMemoryProviderUtils.createMemoryLayer(
        "Lühikesed lõigud", loigud_fields, QgsWkbTypes.LineString, crs
    )
    loigud_pr = loigud_layer.dataProvider()
    loigud_feats = []

    nurgad_fields = QgsFields()
    nurgad_fields.append(make_field("obj_id", "string"))
    nurgad_fields.append(make_field("nurk_kraad", "double"))
    nurgad_fields.append(make_field("allikas", "string"))

    nurgad_layer = QgsMemoryProviderUtils.createMemoryLayer(
        "Teravad nurgad", nurgad_fields, QgsWkbTypes.Point, crs
    )
    nurgad_pr = nurgad_layer.dataProvider()
    nurgad_feats = []

    short_limit_m = settings.short_segment_mm / 1000.0

    for fid, g in geoms_dict.items():
        src = obj_sources[fid]
        if hasattr(settings, 'is_source_reported'):
            if not settings.is_source_reported(src):
                continue
        elif settings.only_input_related and src not in ("SISEND", "PARANDATUD_SISEND", "PARANDATUD_GEOM"):
            continue
        oid = obj_ids[fid]
        src = obj_sources[fid]
        rings = extract_rings_as_point_lists(g)

        for ring in rings:
            pts = list(ring[:-1]) if len(ring) >= 2 and ring[0] == ring[-1] else list(ring)
            n = len(pts)
            if n < 3:
                continue

            # Step 6: Short sections between consecutive nodes
            for i in range(n):
                p1 = pts[i]
                p2 = pts[(i + 1) % n]
                dist_m = math.hypot(p2.x() - p1.x(), p2.y() - p1.y())
                if dist_m < short_limit_m:
                    lf = QgsFeature(loigud_fields)
                    if dist_m > 0:
                        lf.setGeometry(QgsGeometry.fromPolylineXY([p1, p2]))
                    else:
                        lf.setGeometry(
                            QgsGeometry.fromPolylineXY([p1, QgsPointXY(p1.x() + 0.001, p1.y())])
                        )
                    lf["obj_id"] = oid
                    lf["pikkus_mm"] = round(dist_m * 1000.0, 2)
                    lf["allikas"] = src
                    loigud_feats.append(lf)

            # Step 7: Small angles (< 5 degrees)
            for i in range(n):
                p_prev = pts[(i - 1) % n]
                p_curr = pts[i]
                p_next = pts[(i + 1) % n]

                v1x, v1y = p_prev.x() - p_curr.x(), p_prev.y() - p_curr.y()
                v2x, v2y = p_next.x() - p_curr.x(), p_next.y() - p_curr.y()
                len1 = math.hypot(v1x, v1y)
                len2 = math.hypot(v2x, v2y)
                if len1 < 1e-9 or len2 < 1e-9:
                    continue

                cos_theta = max(-1.0, min(1.0, (v1x * v2x + v1y * v2y) / (len1 * len2)))
                angle_deg = math.degrees(math.acos(cos_theta))

                if angle_deg < settings.small_angle_deg:
                    af = QgsFeature(nurgad_fields)
                    af.setGeometry(QgsGeometry.fromPointXY(p_curr))
                    af["obj_id"] = oid
                    af["nurk_kraad"] = round(angle_deg, 2)
                    af["allikas"] = src
                    nurgad_feats.append(af)

    loigud_pr.addFeatures(loigud_feats)
    loigud_layer.updateExtents()

    nurgad_pr.addFeatures(nurgad_feats)
    nurgad_layer.updateExtents()

    return loigud_layer, len(loigud_feats), nurgad_layer, len(nurgad_feats)
