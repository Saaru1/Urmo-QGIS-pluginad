# -*- coding: utf-8 -*-
import os
from qgis.PyQt import QtCore
from qgis.PyQt.QtCore import QObject, QSettings, QTimer
try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QApplication,
    QDialog,
    QVBoxLayout,
    QCheckBox,
    QDialogButtonBox,
    QTableView,
)
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsApplication,
    QgsCoordinateTransform,
)
from qgis.gui import QgsAttributeTableView, QgsAttributeTableModel


def _to_bool(val, default=False):
    if val is None:
        return default
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return bool(val)
    if isinstance(val, str):
        return val.strip().lower() in ("true", "1", "yes", "y", "t")
    return bool(val)


class AutoZoomSettingsDialog(QDialog):
    """Configuration dialog for AutoZoomOnSelection."""
    def __init__(self, parent=None, enabled=False, pan_instead=False, follow_current_row=False):
        super().__init__(parent)
        self.setWindowTitle("Auto Zoom Settings")
        self.setMinimumWidth(380)

        layout = QVBoxLayout(self)

        self.cb_enabled = QCheckBox("Enable Auto Zoom on Selection", self)
        self.cb_enabled.setChecked(enabled)
        layout.addWidget(self.cb_enabled)

        self.cb_pan = QCheckBox("Pan instead of Zoom (Preserve Scale)", self)
        self.cb_pan.setChecked(pan_instead)
        layout.addWidget(self.cb_pan)

        self.cb_follow_cursor = QCheckBox(
            "Follow active row in Attribute Table (Up/Down arrow keys)", self
        )
        self.cb_follow_cursor.setToolTip(
            "Automatically navigates to the feature when using keyboard arrow keys\n"
            "in the attribute table, without altering the layer's selection set."
        )
        self.cb_follow_cursor.setChecked(follow_current_row)
        layout.addWidget(self.cb_follow_cursor)

        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, self
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)


class AutoZoomOnSelectionPlugin(QObject):
    def __init__(self, iface_):
        super().__init__()
        self.iface = iface_
        self.project = QgsProject.instance()

        self.enabled = False
        self.pan_instead = False
        self.follow_current_row = False

        self.toggle_action = None
        self.pan_action = None
        self.arrow_action = None
        self.settings_action = None

        self._layer_handlers = {}
        self._settings_prefix = "AutoZoomOnSelection/"

        # Scan timer to hook open and newly opened attribute table windows
        self._table_poll_timer = QTimer(self)
        self._table_poll_timer.setInterval(800)
        self._table_poll_timer.timeout.connect(self._scan_and_connect_attribute_tables)

    # ---------- Lifecycle ----------
    def initGui(self):
        s = QSettings()
        self.enabled = _to_bool(s.value(self._settings_prefix + "enabled", False))
        self.pan_instead = _to_bool(s.value(self._settings_prefix + "pan_instead", False))
        self.follow_current_row = _to_bool(
            s.value(self._settings_prefix + "follow_current_row", False)
        )

        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        icon_path = os.path.join(plugin_dir, "icon.png")
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
        else:
            icon = QIcon()
            try:
                from . import resources
                resources.qInitResources()
                icon = QIcon(":/AutoZoomOnSelection/icon.png")
            except Exception:
                pass

        if icon.isNull():
            icon = QgsApplication.getThemeIcon("mActionZoomToSelected.svg")

        # Actions
        self.toggle_action = QAction(icon, "Auto Zoom on Selection", self.iface.mainWindow())
        self.toggle_action.setCheckable(True)
        self.toggle_action.setChecked(self.enabled)
        self.toggle_action.setToolTip("Automatically zoom/pan to selected features")
        self.toggle_action.toggled.connect(self._on_toggled)

        self.pan_action = QAction("Pan instead of Zoom", self.iface.mainWindow())
        self.pan_action.setCheckable(True)
        self.pan_action.setChecked(self.pan_instead)
        self.pan_action.toggled.connect(self._on_pan_toggled)

        self.arrow_action = QAction("Follow Row with Arrow Keys", self.iface.mainWindow())
        self.arrow_action.setCheckable(True)
        self.arrow_action.setChecked(self.follow_current_row)
        self.arrow_action.setToolTip("Zoom/pan to active cell row when browsing with Up/Down arrows")
        self.arrow_action.toggled.connect(self._on_arrow_toggled)

        self.settings_action = QAction("Settings...", self.iface.mainWindow())
        self.settings_action.triggered.connect(self.show_settings_dialog)

        # Menus and Toolbars
        menu_title = "Auto Zoom On Selection"
        self.iface.addPluginToMenu(menu_title, self.toggle_action)
        self.iface.addPluginToMenu(menu_title, self.pan_action)
        self.iface.addPluginToMenu(menu_title, self.arrow_action)
        self.iface.addPluginToMenu(menu_title, self.settings_action)
        self.iface.addToolBarIcon(self.toggle_action)

        if self.enabled:
            self._connect_all()
        if self.follow_current_row:
            self._start_table_monitoring()

    def unload(self):
        self._save_settings()
        menu_title = "Auto Zoom On Selection"

        if self.toggle_action:
            self.iface.removeToolBarIcon(self.toggle_action)
            self.iface.removePluginMenu(menu_title, self.toggle_action)
        if self.pan_action:
            self.iface.removePluginMenu(menu_title, self.pan_action)
        if self.arrow_action:
            self.iface.removePluginMenu(menu_title, self.arrow_action)
        if self.settings_action:
            self.iface.removePluginMenu(menu_title, self.settings_action)

        self._stop_table_monitoring()
        self._disconnect_all()

    def _save_settings(self):
        s = QSettings()
        s.setValue(self._settings_prefix + "enabled", self.enabled)
        s.setValue(self._settings_prefix + "pan_instead", self.pan_instead)
        s.setValue(self._settings_prefix + "follow_current_row", self.follow_current_row)

    # ---------- Settings UI ----------
    def show_settings_dialog(self):
        dlg = AutoZoomSettingsDialog(
            parent=self.iface.mainWindow(),
            enabled=self.enabled,
            pan_instead=self.pan_instead,
            follow_current_row=self.follow_current_row,
        )
        res = dlg.exec() if hasattr(dlg, "exec") else dlg.exec_()
        if res:
            self.enabled = dlg.cb_enabled.isChecked()
            self.pan_instead = dlg.cb_pan.isChecked()
            self.follow_current_row = dlg.cb_follow_cursor.isChecked()

            if self.toggle_action:
                self.toggle_action.setChecked(self.enabled)
            if self.pan_action:
                self.pan_action.setChecked(self.pan_instead)
            if self.arrow_action:
                self.arrow_action.setChecked(self.follow_current_row)

            self._save_settings()

            if self.enabled:
                self._connect_all()
            else:
                self._disconnect_all()

            if self.follow_current_row:
                self._start_table_monitoring()
            else:
                self._stop_table_monitoring()

    # ---------- Slots ----------
    def _on_toggled(self, checked):
        self.enabled = checked
        self._save_settings()
        if checked:
            self._connect_all()
            self.iface.messageBar().pushInfo("Auto Zoom", "Enabled")
        else:
            self._disconnect_all()
            self.iface.messageBar().pushInfo("Auto Zoom", "Disabled")

    def _on_pan_toggled(self, checked):
        self.pan_instead = checked
        self._save_settings()
        self.iface.messageBar().pushInfo("Auto Zoom", "Mode: Pan" if checked else "Mode: Zoom")

    def _on_arrow_toggled(self, checked):
        self.follow_current_row = checked
        self._save_settings()
        if checked:
            self._start_table_monitoring()
            self.iface.messageBar().pushInfo("Auto Zoom", "Follow Arrow Keys: Enabled")
        else:
            self._stop_table_monitoring()
            self.iface.messageBar().pushInfo("Auto Zoom", "Follow Arrow Keys: Disabled")

    # ---------- Selection Signal Handling ----------
    def _connect_all(self):
        try:
            self.project.layersAdded.disconnect(self._on_layers_added)
        except Exception:
            pass
        try:
            self.project.layerWillBeRemoved.disconnect(self._on_layer_removed)
        except Exception:
            pass

        self.project.layersAdded.connect(self._on_layers_added)
        self.project.layerWillBeRemoved.connect(self._on_layer_removed)

        for lyr in self.project.mapLayers().values():
            if isinstance(lyr, QgsVectorLayer):
                self._connect_layer(lyr)

    def _disconnect_all(self):
        for layer_id, handler in list(self._layer_handlers.items()):
            layer = self.project.mapLayer(layer_id)
            if layer is not None:
                try:
                    layer.selectionChanged.disconnect(handler)
                except Exception:
                    pass
        self._layer_handlers.clear()

        try:
            self.project.layersAdded.disconnect(self._on_layers_added)
        except Exception:
            pass
        try:
            self.project.layerWillBeRemoved.disconnect(self._on_layer_removed)
        except Exception:
            pass

    def _on_layers_added(self, layers):
        for lyr in layers:
            if isinstance(lyr, QgsVectorLayer) and self.enabled:
                self._connect_layer(lyr)

    def _on_layer_removed(self, layer_or_id):
        if isinstance(layer_or_id, (list, tuple)):
            for item in layer_or_id:
                self._on_layer_removed(item)
            return
        layer_id = layer_or_id.id() if hasattr(layer_or_id, "id") else str(layer_or_id)
        self._layer_handlers.pop(layer_id, None)

    def _connect_layer(self, layer):
        if not layer or not isinstance(layer, QgsVectorLayer):
            return
        lid = layer.id()
        if lid in self._layer_handlers:
            return

        def handler(*args, _layer=layer):
            self._on_selection_changed(_layer)

        try:
            layer.selectionChanged.connect(handler)
            self._layer_handlers[lid] = handler
        except Exception:
            pass

    def _on_selection_changed(self, layer):
        if not self.enabled:
            return
        try:
            if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                return
            ids = layer.selectedFeatureIds()
            if not ids:
                return

            canvas = self.iface.mapCanvas()
            if not canvas:
                return

            if self.pan_instead:
                rect = layer.boundingBoxOfSelected()
                if rect and not rect.isNull():
                    center_pt = rect.center()
                    canvas_crs = canvas.mapSettings().destinationCrs()
                    layer_crs = layer.crs()
                    if layer_crs.isValid() and canvas_crs.isValid() and layer_crs != canvas_crs:
                        transform = QgsCoordinateTransform(layer_crs, canvas_crs, self.project)
                        center_pt = transform.transform(center_pt)
                    canvas.setCenter(center_pt)
                    canvas.refresh()
            else:
                canvas.zoomToSelected(layer)
        except Exception as e:
            self.iface.messageBar().pushWarning("Auto Zoom", f"Failed: {e}")

    # ---------- Arrow Key Navigation in Attribute Table ----------
    def _start_table_monitoring(self):
        self._table_poll_timer.start()
        self._scan_and_connect_attribute_tables()

    def _stop_table_monitoring(self):
        self._table_poll_timer.stop()

    def _get_active_table_views(self):
        views = []
        for widget in QApplication.allWidgets():
            try:
                if isinstance(widget, QgsAttributeTableView):
                    views.append(widget)
                elif isinstance(widget, QTableView):
                    cname = widget.metaObject().className()
                    if "AttributeTable" in cname:
                        views.append(widget)
            except RuntimeError:
                continue
        return views

    def _scan_and_connect_attribute_tables(self):
        if not self.follow_current_row:
            return

        for view in self._get_active_table_views():
            try:
                sm = view.selectionModel()
                if not sm:
                    continue

                # Avoid duplicate connections on the same selection model instance
                if sm.property("_az_connected"):
                    continue

                def on_row_changed(current, previous, _v=view):
                    self._on_current_row_changed(_v, current, previous)

                sm.currentRowChanged.connect(on_row_changed)
                sm.setProperty("_az_connected", True)
                sm._az_handler = on_row_changed  # Prevent GC
            except (RuntimeError, AttributeError):
                continue

    def _resolve_feature_id(self, view, index):
        if not index.isValid():
            return None
        model = view.model()
        if not model:
            return None

        # 1. Direct rowToId on filter proxy model
        if hasattr(model, "rowToId"):
            try:
                fid = model.rowToId(index.row())
                if fid is not None:
                    return fid
            except Exception:
                pass
            try:
                fid = model.rowToId(index)
                if fid is not None:
                    return fid
            except Exception:
                pass

        # 2. Source model mapping
        if hasattr(model, "sourceModel") and hasattr(model, "mapToSource"):
            try:
                src_model = model.sourceModel()
                src_index = model.mapToSource(index)
                if hasattr(src_model, "rowToId"):
                    fid = src_model.rowToId(src_index.row())
                    if fid is not None:
                        return fid
            except Exception:
                pass

        # 3. UserRole / FeatureIdRole fallback
        try:
            role = getattr(
                QgsAttributeTableModel,
                "FeatureIdRole",
                QtCore.Qt.ItemDataRole.UserRole if hasattr(QtCore.Qt, "ItemDataRole") else QtCore.Qt.UserRole,
            )
            fid = model.data(index, int(role))
            if fid is not None:
                return fid
        except Exception:
            pass

        return None

    def _resolve_layer_from_view(self, view):
        model = view.model()
        if model:
            if hasattr(model, "layer") and model.layer():
                return model.layer()
            if hasattr(model, "masterModel"):
                mm = model.masterModel()
                if mm and hasattr(mm, "layer") and mm.layer():
                    return mm.layer()
            if hasattr(model, "sourceModel"):
                sm = model.sourceModel()
                if sm and hasattr(sm, "layer") and sm.layer():
                    return sm.layer()
                if sm and hasattr(sm, "masterModel"):
                    smm = sm.masterModel()
                    if smm and hasattr(smm, "layer") and smm.layer():
                        return smm.layer()

        p = view.parent()
        while p:
            if hasattr(p, "layer"):
                try:
                    lyr = p.layer()
                    if isinstance(lyr, QgsVectorLayer):
                        return lyr
                except Exception:
                    pass
            p = p.parent()

        return self.iface.activeLayer()

    def _on_current_row_changed(self, view, current, previous):
        if not self.follow_current_row or not current.isValid():
            return

        fid = self._resolve_feature_id(view, current)
        if fid is None:
            return

        layer = self._resolve_layer_from_view(view)
        if not layer or not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            return

        self._navigate_to_feature(layer, fid)

    def _navigate_to_feature(self, layer, fid):
        feat = layer.getFeature(fid)
        if not feat.isValid():
            return

        geom = feat.geometry()
        if not geom or geom.isEmpty():
            return

        canvas = self.iface.mapCanvas()
        if not canvas:
            return

        box = geom.boundingBox()
        if box.isNull() or box.isEmpty():
            return

        # CRS Reprojection
        canvas_crs = canvas.mapSettings().destinationCrs()
        layer_crs = layer.crs()
        if layer_crs.isValid() and canvas_crs.isValid() and layer_crs != canvas_crs:
            transform = QgsCoordinateTransform(layer_crs, canvas_crs, self.project)
            box = transform.transformBoundingBox(box)

        # Apply navigation
        if self.pan_instead:
            canvas.setCenter(box.center())
            canvas.refresh()
        else:
            if box.width() == 0 or box.height() == 0:
                canvas.setCenter(box.center())
            else:
                box.scale(1.15)
                canvas.setExtent(box)
            canvas.refresh()