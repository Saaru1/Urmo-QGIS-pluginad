
# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtCore import QObject, QSettings
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject, QgsVectorLayer, QgsApplication
from qgis.utils import iface

class AutoZoomOnSelectionPlugin(QObject):
    def __init__(self, iface_):
        super().__init__()
        self.iface = iface_
        self.project = QgsProject.instance()
        self.enabled = False
        self.pan_instead = False

        self.toggle_action = None
        self.pan_action = None

        # Keep strong references to handlers so they don't get GC'ed
        self._layer_handlers = {}  # layer.id() -> callable

        # Settings keys
        self._settings_prefix = 'AutoZoomOnSelection/'

    # ---------- QGIS plugin entry points ----------
    def initGui(self):
        # Restore settings
        s = QSettings()
        self.enabled = s.value(self._settings_prefix + 'enabled', False, type=bool)
        self.pan_instead = s.value(self._settings_prefix + 'pan_instead', False, type=bool)

        # Try to use resource icon; fallback to file and theme icon
        icon = QIcon()
        try:
            from . import resources
            resources.qInitResources()
            icon = QIcon(':/AutoZoomOnSelection/icon.png')
        except Exception:
            pass
        if icon.isNull():
            # file fallback
            try:
                plugin_dir = os.path.dirname(os.path.abspath(__file__))
                icon = QIcon(os.path.join(plugin_dir, 'icon.png'))
            except Exception:
                pass
        if icon.isNull():
            icon = QgsApplication.getThemeIcon('mActionZoomToSelected.svg')

        self.toggle_action = QAction(icon, 'Auto Zoom on Selection', self.iface.mainWindow())
        self.toggle_action.setCheckable(True)
        self.toggle_action.setChecked(self.enabled)
        self.toggle_action.setToolTip('Automatically zoom the map to selected features in any layer')
        self.toggle_action.toggled.connect(self._on_toggled)

        # Pan instead of zoom action
        self.pan_action = QAction('Pan instead of Zoom', self.iface.mainWindow())
        self.pan_action.setCheckable(True)
        self.pan_action.setChecked(self.pan_instead)
        self.pan_action.setToolTip('Keep current scale and pan to selection instead of zooming')
        self.pan_action.toggled.connect(self._on_pan_toggled)

        # Add to Plugins menu and toolbar
        self.iface.addPluginToMenu('Auto Zoom On Selection', self.toggle_action)
        self.iface.addPluginToMenu('Auto Zoom On Selection', self.pan_action)
        self.iface.addToolBarIcon(self.toggle_action)

        # Apply initial state
        if self.enabled:
            self._connect_all()

    def unload(self):
        # Save settings
        s = QSettings()
        s.setValue(self._settings_prefix + 'enabled', self.enabled)
        s.setValue(self._settings_prefix + 'pan_instead', self.pan_instead)

        # Remove UI
        if self.toggle_action:
            self.iface.removeToolBarIcon(self.toggle_action)
            self.iface.removePluginMenu('Auto Zoom On Selection', self.toggle_action)
        if self.pan_action:
            self.iface.removePluginMenu('Auto Zoom On Selection', self.pan_action)

        # Disconnect
        self._disconnect_all()

    # ---------- Slots ----------
    def _on_toggled(self, checked):
        self.enabled = checked
        if checked:
            self._connect_all()
            self.iface.messageBar().pushInfo('Auto Zoom', 'Enabled')
        else:
            self._disconnect_all()
            self.iface.messageBar().pushInfo('Auto Zoom', 'Disabled')

    def _on_pan_toggled(self, checked):
        self.pan_instead = checked
        self.iface.messageBar().pushInfo('Auto Zoom', 'Mode: Pan' if checked else 'Mode: Zoom')

    # ---------- Core logic ----------
    def _connect_all(self):
        # Connect project-level signals
        try:
            self.project.layersAdded.disconnect(self._on_layers_added)
        except Exception:
            pass
        try:
            self.project.layerWillBeRemoved.disconnect(self._on_layer_removed)
        except Exception:
            pass
        self.project.layersAdded.connect(self._on_layers_added)
        self.project.layerWillBeRemoved.connect(self._on_layer_removed)

        # Connect existing vector layers
        for lyr in self.project.mapLayers().values():
            if isinstance(lyr, QgsVectorLayer):
                self._connect_layer(lyr)

    def _disconnect_all(self):
        # Disconnect layer handlers
        for layer_id, handler in list(self._layer_handlers.items()):
            layer = self.project.mapLayer(layer_id)
            if layer is not None:
                try:
                    layer.selectionChanged.disconnect(handler)
                except Exception:
                    pass
        self._layer_handlers.clear()

        # Disconnect project signals
        try:
            self.project.layersAdded.disconnect(self._on_layers_added)
        except Exception:
            pass
        try:
            self.project.layerWillBeRemoved.disconnect(self._on_layer_removed)
        except Exception:
            pass

    def _on_layers_added(self, layers):
        for lyr in layers:
            if isinstance(lyr, QgsVectorLayer) and self.enabled:
                self._connect_layer(lyr)

    def _on_layer_removed(self, layer_id):
        handler = self._layer_handlers.pop(layer_id, None)
        # Qt auto-disconnects when object is deleted; just clean dict

    def _connect_layer(self, layer):
        if layer.id() in self._layer_handlers:
            return
        # Create a handler bound to this layer
        def handler(*args, _layer=layer):
            self._on_selection_changed(_layer)
        layer.selectionChanged.connect(handler)
        self._layer_handlers[layer.id()] = handler

    def _on_selection_changed(self, layer):
        if not self.enabled:
            return
        if not isinstance(layer, QgsVectorLayer):
            return
        if not layer.selectedFeatureIds():
            return
        try:
            if self.pan_instead:
                rect = layer.boundingBoxOfSelected()
                if rect and not rect.isNull():
                    self.iface.mapCanvas().setCenter(rect.center())
                    self.iface.mapCanvas().refresh()
            else:
                # Use QGIS helper to respect default padding
                self.iface.mapCanvas().zoomToSelected(layer)
        except Exception as e:
            self.iface.messageBar().pushWarning('Auto Zoom', f'Failed: {e}')
