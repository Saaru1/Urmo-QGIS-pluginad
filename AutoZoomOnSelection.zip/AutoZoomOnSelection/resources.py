# -*- coding: utf-8 -*-
from qgis.PyQt import QtCore

def qInitResources():
    pass

def qCleanupResources():
    pass