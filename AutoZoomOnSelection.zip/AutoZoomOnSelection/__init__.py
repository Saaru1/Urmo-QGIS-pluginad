
# -*- coding: utf-8 -*-
"""
QGIS plugin: Auto Zoom On Selection
"""

def classFactory(iface):
    from .autozoom_on_selection import AutoZoomOnSelectionPlugin
    return AutoZoomOnSelectionPlugin(iface)
