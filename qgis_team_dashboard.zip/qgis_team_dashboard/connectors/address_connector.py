# -*- coding: utf-8 -*-
"""
Estonian In-Aadress Gazetteer client (Maa- ja Ruumiamet / inaadress.maaamet.ee).

Inspired by the Estonian Address Search QGIS plugin architecture: queries the official
public gazetteer endpoint and parses coordinates (L-EST97 EPSG:3301), bounding boxes,
and optional GeoJSON footprints for buildings, cadastral parcels, streets, and localities.
"""

import json
from typing import Any, Dict, List, Optional, Tuple
import urllib.parse
import urllib.request


INAADRESS_GAZETTEER_URL = "https://inaadress.maaamet.ee/inaadress/gazetteer"
DEFAULT_ADDRESS_TYPES = "EHITISHOONE,KATASTRIYKSUS,TANAV,EHAK,VAIKEKOHT"


def _parse_bbox_3301(raw_bbox: Any, x_val: Any, y_val: Any) -> Optional[Tuple[float, float, float, float]]:
    """Parse L-EST97 (EPSG:3301) [min_x, min_y, max_x, max_y] from In-Aadress result."""
    if isinstance(raw_bbox, str) and raw_bbox.strip():
        parts = [p for p in raw_bbox.replace(",", " ").split() if p]
        if len(parts) >= 4:
            try:
                vals = [float(p) for p in parts[:4]]
                xs = sorted([vals[0], vals[2]])
                ys = sorted([vals[1], vals[3]])
                if xs[1] > xs[0] or ys[1] > ys[0]:
                    return (xs[0], ys[0], xs[1], ys[1])
            except (TypeError, ValueError):
                pass
    try:
        if x_val is not None and y_val is not None:
            xv = float(x_val)
            yv = float(y_val)
            return (xv - 75.0, yv - 75.0, xv + 75.0, yv + 75.0)
    except (TypeError, ValueError):
        pass
    return None


def search_estonian_address(
    query: str,
    limit: int = 10,
    features: str = DEFAULT_ADDRESS_TYPES,
    include_geometry: bool = True,
    timeout: float = 8.0,
) -> List[Dict[str, Any]]:
    """
    Query Maa- ja Ruumiamet In-Aadress gazetteer and return normalized candidate dicts.

    Note: In-Aadress returns viitepunkt_x as Northing (~6.5M) or Easting depending on endpoint
    mode; in WGS84/L-EST97 results it includes `viitepunkt_l` (lon) & `viitepunkt_b` (lat)
    alongside `viitepunkt_x` (Easting ~500k) and `viitepunkt_y` (Northing ~6.5M).
    """
    clean_q = (query or "").strip()
    if len(clean_q) < 2:
        return []

    params = {
        "results": str(max(1, min(25, int(limit or 10)))),
        "unik": "0",
        "geometry": "1" if include_geometry else "0",
        "address": clean_q,
    }
    if features:
        params["features"] = features

    url = f"{INAADRESS_GAZETTEER_URL}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "QGIS-Team-Dashboard/1.5",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        payload = json.loads(resp.read().decode("utf-8", errors="replace"))

    raw_items = payload.get("addresses") or []
    out: List[Dict[str, Any]] = []
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        label = (
            item.get("ipikkaadress")
            or item.get("pikkaadress")
            or item.get("taisaadress")
            or item.get("aadress")
            or ""
        )
        if not label:
            continue

        x_3301: Optional[float] = None
        y_3301: Optional[float] = None
        try:
            vx = float(item["viitepunkt_x"]) if item.get("viitepunkt_x") is not None else None
            vy = float(item["viitepunkt_y"]) if item.get("viitepunkt_y") is not None else None
            # Handle either (x=easting~500k, y=northing~6.5M) or swapped order safely
            if vx is not None and vy is not None:
                if vx > 3000000.0 and vy < 1000000.0:
                    y_3301, x_3301 = vx, vy
                else:
                    x_3301, y_3301 = vx, vy
        except (TypeError, ValueError):
            pass

        lat: Optional[float] = None
        lon: Optional[float] = None
        try:
            if item.get("viitepunkt_b") is not None and item.get("viitepunkt_l") is not None:
                lat = float(item["viitepunkt_b"])
                lon = float(item["viitepunkt_l"])
        except (TypeError, ValueError):
            pass

        geom_obj = item.get("geometry")
        if isinstance(geom_obj, str) and geom_obj.strip().startswith("{"):
            try:
                geom_obj = json.loads(geom_obj)
            except Exception:
                geom_obj = None

        bbox_3301 = _parse_bbox_3301(item.get("boundingbox"), x_3301, y_3301)
        out.append(
            {
                "label": str(label),
                "type": str(item.get("liikVal") or item.get("liik") or ""),
                "kood": str(item.get("unikood") or item.get("adr_id") or item.get("tunnus") or ""),
                "katastritunnus": str(item.get("katastritunnus") or ""),
                "x_3301": x_3301,
                "y_3301": y_3301,
                "lat": lat,
                "lon": lon,
                "bbox_3301": list(bbox_3301) if bbox_3301 else None,
                "geometry": geom_obj if isinstance(geom_obj, dict) else None,
            }
        )
    return out
