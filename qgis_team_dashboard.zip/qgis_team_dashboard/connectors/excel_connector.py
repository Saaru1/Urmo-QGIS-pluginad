# -*- coding: utf-8 -*-
"""
Zero-Lock Read-Only Excel Connector for QGIS Team Dashboard.
Reads .xlsx and .csv files into an in-memory BytesIO buffer so OneDrive/SharePoint
files are never locked while colleagues edit them in Excel Online or Desktop.
Uses openpyxl/pandas when available, with a built-in zipfile/XML fallback for .xlsx.
"""

import csv
import io
import os
from typing import Any, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET
import zipfile

from ..core.schema import DataSourceConfig, JoinConfig
from .path_resolver import PortablePathResolver


class ExcelConnector:
    """Read-only Excel & CSV ingestion engine with spatial & join hydration."""

    @staticmethod
    def _read_bytes_unlocked(file_path: str) -> bytes:
        """Read file bytes immediately into memory and close the OS file handle."""
        with open(file_path, "rb") as fh:
            return fh.read()

    @classmethod
    def list_sheets(cls, file_path: str, project_dir: Optional[str] = None) -> List[str]:
        """Return worksheet names from an .xlsx file (or ['CSV'] for .csv)."""
        resolved = PortablePathResolver.resolve(file_path, project_dir=project_dir)
        if not os.path.isfile(resolved):
            return []
        if resolved.lower().endswith(".csv"):
            return ["CSV"]

        raw_bytes = cls._read_bytes_unlocked(resolved)
        try:
            import openpyxl

            wb = openpyxl.load_workbook(
                io.BytesIO(raw_bytes), read_only=True, data_only=True
            )
            names = list(wb.sheetnames)
            wb.close()
            return names
        except ImportError:
            return cls._list_sheets_xml_fallback(raw_bytes)

    @classmethod
    def read_records(
        cls,
        file_path: str,
        sheet_name: Optional[str] = None,
        project_dir: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Read an Excel worksheet or CSV file into a list of row dictionaries
        without holding any file lock on disk.
        """
        resolved = PortablePathResolver.resolve(file_path, project_dir=project_dir)
        if not os.path.isfile(resolved):
            raise FileNotFoundError(f"Excel/CSV file not found: {resolved} (from {file_path})")

        raw_bytes = cls._read_bytes_unlocked(resolved)
        if resolved.lower().endswith(".csv"):
            text = raw_bytes.decode("utf-8-sig", errors="replace")
            reader = csv.DictReader(io.StringIO(text))
            return [cls._coerce_row(dict(row)) for row in reader]

        try:
            import openpyxl

            wb = openpyxl.load_workbook(
                io.BytesIO(raw_bytes), read_only=True, data_only=True
            )
            target_sheet = (
                wb[sheet_name]
                if (sheet_name and sheet_name in wb.sheetnames)
                else wb.active
            )
            rows_iter = target_sheet.iter_rows(values_only=True)
            headers_raw = next(rows_iter, None)
            if not headers_raw:
                wb.close()
                return []
            headers = [
                str(h).strip() if h is not None else f"col_{i + 1}"
                for i, h in enumerate(headers_raw)
            ]
            records: List[Dict[str, Any]] = []
            for row_vals in rows_iter:
                if row_vals is None or all(v is None or str(v).strip() == "" for v in row_vals):
                    continue
                row_dict = {
                    headers[i]: row_vals[i] if i < len(row_vals) else None
                    for i in range(len(headers))
                }
                records.append(cls._coerce_row(row_dict))
            wb.close()
            return records
        except ImportError:
            return cls._read_xlsx_xml_fallback(raw_bytes, sheet_name=sheet_name)

    @staticmethod
    def _coerce_row(row: Dict[str, Any]) -> Dict[str, Any]:
        """Coerce stringified numbers cleanly while keeping strings & ISO dates intact."""
        out: Dict[str, Any] = {}
        for k, v in row.items():
            if isinstance(v, str):
                s = v.strip()
                if s == "":
                    out[k] = None
                    continue
                # Try integer then float if purely numeric
                try:
                    if "." not in s and "e" not in s.lower():
                        out[k] = int(s)
                        continue
                    out[k] = float(s)
                    continue
                except ValueError:
                    out[k] = s
            elif hasattr(v, "isoformat"):
                out[k] = v.isoformat()
            else:
                out[k] = v
        return out

    @staticmethod
    def _list_sheets_xml_fallback(raw_bytes: bytes) -> List[str]:
        """Pure-Python zipfile/XML reader for .xlsx sheet names when openpyxl is absent."""
        with zipfile.ZipFile(io.BytesIO(raw_bytes), "r") as zf:
            wb_xml = zf.read("xl/workbook.xml")
            root = ET.fromstring(wb_xml)
            ns = {"main": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            return [
                el.attrib.get("name", "Sheet1")
                for el in root.findall(".//main:sheets/main:sheet", ns)
            ]

    @classmethod
    def _read_xlsx_xml_fallback(
        cls, raw_bytes: bytes, sheet_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Pure-Python zipfile/XML reader for .xlsx worksheets when openpyxl is absent."""
        ns_main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        ns = {"main": ns_main}
        with zipfile.ZipFile(io.BytesIO(raw_bytes), "r") as zf:
            shared_strings: List[str] = []
            if "xl/sharedStrings.xml" in zf.namelist():
                ss_root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
                for si in ss_root.findall(f".//{{{ns_main}}}si"):
                    texts = [t.text or "" for t in si.findall(f".//{{{ns_main}}}t")]
                    shared_strings.append("".join(texts))

            sheet_files = sorted(
                [name for name in zf.namelist() if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")]
            )
            if not sheet_files:
                return []

            sheet_idx = 0
            if sheet_name:
                names = cls._list_sheets_xml_fallback(raw_bytes)
                if sheet_name in names and names.index(sheet_name) < len(sheet_files):
                    sheet_idx = names.index(sheet_name)

            ws_root = ET.fromstring(zf.read(sheet_files[sheet_idx]))
            parsed_rows: List[List[Any]] = []
            for row_el in ws_root.findall(f".//{{{ns_main}}}sheetData/{{{ns_main}}}row"):
                row_vals: List[Any] = []
                for c_el in row_el.findall(f"{{{ns_main}}}c"):
                    c_type = c_el.attrib.get("t", "")
                    v_el = c_el.find(f"{{{ns_main}}}v")
                    is_el = c_el.find(f"{{{ns_main}}}is/{{{ns_main}}}t")
                    if is_el is not None:
                        row_vals.append(is_el.text)
                    elif v_el is not None and v_el.text is not None:
                        if c_type == "s":
                            idx = int(v_el.text)
                            row_vals.append(shared_strings[idx] if idx < len(shared_strings) else "")
                        else:
                            row_vals.append(v_el.text)
                    else:
                        row_vals.append(None)
                parsed_rows.append(row_vals)

            if not parsed_rows:
                return []
            headers = [
                str(h).strip() if h is not None else f"col_{i + 1}"
                for i, h in enumerate(parsed_rows[0])
            ]
            out: List[Dict[str, Any]] = []
            for r in parsed_rows[1:]:
                if not any(v is not None and str(v).strip() != "" for v in r):
                    continue
                row_dict = {
                    headers[i]: r[i] if i < len(r) else None for i in range(len(headers))
                }
                out.append(cls._coerce_row(row_dict))
            return out

    @staticmethod
    def apply_in_memory_join(
        target_records: List[Dict[str, Any]],
        excel_records: List[Dict[str, Any]],
        join_cfg: JoinConfig,
    ) -> List[Dict[str, Any]]:
        """
        Left-join read-only Excel records onto spatial layer records by key field.
        Prefixes joined attributes with join_cfg.join_prefix (e.g. 'xl_').
        """
        if not excel_records or not join_cfg.source_key_field or not join_cfg.target_key_field:
            return target_records

        lookup: Dict[str, Dict[str, Any]] = {}
        for ex_row in excel_records:
            key_val = ex_row.get(join_cfg.source_key_field)
            if key_val is not None:
                lookup[str(key_val).strip()] = ex_row

        prefix = join_cfg.join_prefix or ""
        allowed_fields = set(join_cfg.selected_fields) if join_cfg.selected_fields else None

        enriched: List[Dict[str, Any]] = []
        for row in target_records:
            merged = dict(row)
            t_key = row.get(join_cfg.target_key_field)
            match = lookup.get(str(t_key).strip()) if t_key is not None else None
            if match:
                for k, v in match.items():
                    if k == join_cfg.source_key_field:
                        continue
                    if allowed_fields is not None and k not in allowed_fields:
                        continue
                    merged[f"{prefix}{k}"] = v
            enriched.append(merged)
        return enriched

    @classmethod
    def load_as_qgis_layer(
        cls,
        ds_config: DataSourceConfig,
        project_dir: Optional[str] = None,
        add_to_project: bool = True,
    ) -> Tuple[Optional[Any], List[Dict[str, Any]]]:
        """
        Load an Excel DataSourceConfig into a QGIS QgsVectorLayer (Memory provider)
        if running inside QGIS, and return (qgs_layer_or_None, records).
        """
        records = cls.read_records(
            ds_config.portable_path,
            sheet_name=ds_config.sheet_name or None,
            project_dir=project_dir,
        )

        # Normalize _lon / _lat if xy_points mode is configured
        if ds_config.ingestion_mode == "xy_points" and ds_config.x_field and ds_config.y_field:
            for r in records:
                try:
                    r["_lon"] = float(r[ds_config.x_field])
                    r["_lat"] = float(r[ds_config.y_field])
                except (KeyError, ValueError, TypeError):
                    pass

        try:
            from qgis.core import (
                QgsFeature,
                QgsField,
                QgsGeometry,
                QgsPointXY,
                QgsProject,
                QgsVectorLayer,
            )
            try:
                from qgis.PyQt.QtCore import QMetaType

                field_int = QMetaType.Type.Int
                field_dbl = QMetaType.Type.Double
                field_str = QMetaType.Type.QString
            except (ImportError, AttributeError):
                from qgis.PyQt.QtCore import QVariant

                field_int = QVariant.Int
                field_dbl = QVariant.Double
                field_str = QVariant.String
        except ImportError:
            return None, records

        crs = ds_config.crs or "EPSG:4326"
        if ds_config.ingestion_mode == "xy_points" and ds_config.x_field and ds_config.y_field:
            uri = f"Point?crs={crs}"
        elif ds_config.ingestion_mode == "wkt_geometry" and ds_config.wkt_field:
            uri = f"GeometryCollection?crs={crs}"
        else:
            uri = "None"

        layer = QgsVectorLayer(uri, ds_config.name, "memory")
        pr = layer.dataProvider()

        if records:
            sample = records[0]
            fields = []
            for k, v in sample.items():
                if k.startswith("_"):
                    continue
                if isinstance(v, bool):
                    fields.append(QgsField(k, field_str))
                elif isinstance(v, int):
                    fields.append(QgsField(k, field_int))
                elif isinstance(v, float):
                    fields.append(QgsField(k, field_dbl))
                else:
                    fields.append(QgsField(k, field_str))
            pr.addAttributes(fields)
            layer.updateFields()

            feats = []
            field_names = [f.name() for f in layer.fields()]
            for r in records:
                feat = QgsFeature(layer.fields())
                for fn in field_names:
                    feat.setAttribute(fn, r.get(fn))
                if ds_config.ingestion_mode == "xy_points" and "_lon" in r and "_lat" in r:
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(r["_lon"], r["_lat"])))
                elif ds_config.ingestion_mode == "wkt_geometry" and ds_config.wkt_field:
                    wkt_str = r.get(ds_config.wkt_field)
                    if wkt_str:
                        feat.setGeometry(QgsGeometry.fromWkt(str(wkt_str)))
                feats.append(feat)
            pr.addFeatures(feats)
            layer.updateExtents()

        if not add_to_project:
            if hasattr(layer, "setLabelsEnabled"):
                try:
                    layer.setLabelsEnabled(False)
                except Exception:
                    pass
        else:
            QgsProject.instance().addMapLayer(layer)
        return layer, records
