# -*- coding: utf-8 -*-
"""Connectors for SharePoint, read-only Excel workbooks, and live OGC WFS/WMS services."""
