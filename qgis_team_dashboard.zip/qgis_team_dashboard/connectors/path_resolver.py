# -*- coding: utf-8 -*-
"""
Portable Path Resolver for SharePoint & OneDrive Sync Folders.
Converts machine-specific absolute paths (e.g., C:\\Users\\Alice\\OneDrive - Contoso\\GIS\\data.xlsx)
into portable tokens (${ONEDRIVE_COMMERCIAL}/GIS/data.xlsx) and resolves them on any
team member's machine regardless of Windows username or OneDrive root directory.
"""

import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class PortablePathResolver:
    """Tokenizes and resolves file paths across different users' OneDrive/SharePoint sync roots."""

    TOKEN_ORDER: List[str] = [
        "PROJECT_DIR",
        "PLUGIN_DIR",
        "ONEDRIVE_COMMERCIAL",
        "ONEDRIVE_CONSUMER",
        "ONEDRIVE",
        "SHAREPOINT_SYNC",
        "USERPROFILE",
    ]

    @classmethod
    def detect_roots(
        cls,
        project_dir: Optional[str] = None,
        env_override: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        """
        Discover active OneDrive, SharePoint, Project, and User roots on the current machine.
        Accepts env_override for unit testing across simulated users.
        """
        env = dict(os.environ)
        if env_override:
            env.update(env_override)

        roots: Dict[str, str] = {}

        if project_dir:
            roots["PROJECT_DIR"] = cls._norm(project_dir)
        roots["PLUGIN_DIR"] = cls._norm(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        )

        user_profile = env.get("USERPROFILE") or env.get("HOME") or str(Path.home())
        user_profile_norm = cls._norm(user_profile)

        # 1. Explicit OneDrive environment variables set by the OneDrive Desktop Client
        if env.get("OneDriveCommercial"):
            roots["ONEDRIVE_COMMERCIAL"] = cls._norm(env["OneDriveCommercial"])
        if env.get("OneDriveConsumer"):
            roots["ONEDRIVE_CONSUMER"] = cls._norm(env["OneDriveConsumer"])
        if env.get("OneDrive"):
            roots["ONEDRIVE"] = cls._norm(env["OneDrive"])

        # 2. Scan USERPROFILE for "OneDrive - <OrgName>" or SharePoint sync folders if not in env
        if os.path.isdir(user_profile_norm):
            try:
                for entry in sorted(os.listdir(user_profile_norm)):
                    full = cls._norm(os.path.join(user_profile_norm, entry))
                    if not os.path.isdir(full):
                        continue
                    if entry.lower().startswith("onedrive - "):
                        roots.setdefault("ONEDRIVE_COMMERCIAL", full)
                        roots.setdefault("ONEDRIVE", full)
                    elif entry.lower() == "onedrive":
                        roots.setdefault("ONEDRIVE", full)
                    elif "sharepoint" in entry.lower():
                        roots.setdefault("SHAREPOINT_SYNC", full)
            except OSError:
                pass

        # Fallback aliases so ${ONEDRIVE_COMMERCIAL} and ${ONEDRIVE} cross-resolve gracefully
        if "ONEDRIVE_COMMERCIAL" in roots and "ONEDRIVE" not in roots:
            roots["ONEDRIVE"] = roots["ONEDRIVE_COMMERCIAL"]
        elif "ONEDRIVE" in roots and "ONEDRIVE_COMMERCIAL" not in roots:
            roots["ONEDRIVE_COMMERCIAL"] = roots["ONEDRIVE"]

        if "SHAREPOINT_SYNC" not in roots and "ONEDRIVE_COMMERCIAL" in roots:
            roots["SHAREPOINT_SYNC"] = roots["ONEDRIVE_COMMERCIAL"]

        if user_profile_norm:
            roots["USERPROFILE"] = user_profile_norm

        return roots

    @staticmethod
    def _norm(path_str: str) -> str:
        """Normalize path separators to forward slashes without trailing slash."""
        if not path_str:
            return ""
        cleaned = path_str.strip().replace("\\", "/")
        return cleaned.rstrip("/") if len(cleaned) > 3 else cleaned

    @classmethod
    def tokenize(
        cls,
        raw_path: str,
        project_dir: Optional[str] = None,
        env_override: Optional[Dict[str, str]] = None,
    ) -> str:
        """
        Convert a local path into a portable tokenized path (e.g. '${ONEDRIVE_COMMERCIAL}/GIS/Assets.xlsx').
        Also handles cross-user paths like 'C:/Users/OtherUser/OneDrive - Contoso/GIS/Assets.xlsx'.
        """
        if not raw_path:
            return ""

        norm_path = cls._norm(raw_path)

        # Already tokenized
        if norm_path.startswith("${"):
            return norm_path

        roots = cls.detect_roots(project_dir=project_dir, env_override=env_override)

        # Match against known local roots (longest prefix first)
        candidates: List[Tuple[int, str, str]] = []
        for token in cls.TOKEN_ORDER:
            root_val = roots.get(token)
            if not root_val:
                continue
            if norm_path.lower() == root_val.lower():
                candidates.append((len(root_val), token, ""))
            elif norm_path.lower().startswith(root_val.lower() + "/"):
                rel = norm_path[len(root_val) + 1 :]
                candidates.append((len(root_val), token, rel))

        if candidates:
            candidates.sort(key=lambda item: item[0], reverse=True)
            _, best_token, rel_part = candidates[0]
            return f"${{{best_token}}}/{rel_part}" if rel_part else f"${{{best_token}}}"

        # Regex heuristic for paths coming from another user's Windows profile:
        # e.g. C:/Users/<anyone>/OneDrive - <Org>/<rest>
        match_comm = re.match(
            r"^[a-zA-Z]:/Users/[^/]+/OneDrive\s*-\s*[^/]+(?:/(.*))?$",
            norm_path,
            flags=re.IGNORECASE,
        )
        if match_comm:
            rel = match_comm.group(1) or ""
            return f"${{ONEDRIVE_COMMERCIAL}}/{rel}" if rel else "${ONEDRIVE_COMMERCIAL}"

        match_od = re.match(
            r"^[a-zA-Z]:/Users/[^/]+/OneDrive(?:/(.*))?$",
            norm_path,
            flags=re.IGNORECASE,
        )
        if match_od:
            rel = match_od.group(1) or ""
            return f"${{ONEDRIVE}}/{rel}" if rel else "${ONEDRIVE}"

        return norm_path

    @classmethod
    def resolve(
        cls,
        portable_path: str,
        project_dir: Optional[str] = None,
        env_override: Optional[Dict[str, str]] = None,
    ) -> str:
        """
        Expand a portable tokenized path ('${ONEDRIVE_COMMERCIAL}/GIS/Assets.xlsx')
        or another user's OneDrive path into a valid local file path on the current machine.
        """
        if not portable_path:
            return ""

        # If a colleague saved a hardcoded path from their PC, tokenize it first
        tokenized = cls.tokenize(
            portable_path, project_dir=project_dir, env_override=env_override
        )
        roots = cls.detect_roots(project_dir=project_dir, env_override=env_override)

        def _replace_token(match: re.Match) -> str:
            token_name = match.group(1).upper()
            if token_name in roots:
                return roots[token_name]
            # Fallback if ONEDRIVE_COMMERCIAL requested on a machine with only ONEDRIVE or USERPROFILE
            if token_name in ("ONEDRIVE_COMMERCIAL", "SHAREPOINT_SYNC", "ONEDRIVE"):
                for fallback in ("ONEDRIVE_COMMERCIAL", "ONEDRIVE", "SHAREPOINT_SYNC", "PROJECT_DIR", "USERPROFILE"):
                    if fallback in roots:
                        return roots[fallback]
            return match.group(0)

        resolved = re.sub(r"\$\{([A-Za-z0-9_]+)\}", _replace_token, tokenized)
        return os.path.normpath(resolved)
