# -*- coding: utf-8 -*-
"""
Live OGC WFS & WMS Service Connector for QGIS Team Dashboard.
Supports:
- Building QGIS WFS and WMS provider URIs with configurable authentication
  ('none' for intranet/VPN, 'sso_credentials' for Windows SSO, 'authcfg' for QGIS Auth Manager,
   'bearer' token, and 'basic' auth).
- Loading live WFS vector layers and WMS raster layers into QGIS Desktop.
- Generating live browser WFS GetFeature (GeoJSON) and WMS tile descriptors for
  standalone HTML dashboards hosted on SharePoint / Microsoft Teams.
"""

import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import gzip
import json
import os
import re
import time
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlencode, urlparse, urlunparse, parse_qsl
import urllib.request
import xml.etree.ElementTree as ET

from ..core.schema import DataSourceConfig


ESTONIAN_OGC_PRESETS: List[Dict[str, Any]] = [
    {
        "label": "EELIS WFS (Keskkonnaagentuur — 103 kihti: kaitsealad, Natura, PLK...)",
        "service_type": "wfs",
        "url": "https://gsavalik.envir.ee/geoserver/eelis/ows",
        "crs": "EPSG:3301",
    },
    {
        "label": "PRIA Pärandniidud WFS (kls.pria.ee)",
        "service_type": "wfs",
        "url": "https://kls.pria.ee/geoserver/pria_avalik/wfs",
        "crs": "EPSG:3301",
    },
    {
        "label": "Maa- ja Ruumiamet Hallkaart WMS (EPSG:3301)",
        "service_type": "wms",
        "url": "https://kaart.maaamet.ee/wms/hallkaart",
        "crs": "EPSG:3301",
        "default_layer": "MA-HALLKAART",
        "format": "image/png",
        "is_basemap": True,
    },
    {
        "label": "Maa- ja Ruumiamet Põhikaart WMS (EPSG:3301)",
        "service_type": "wms",
        "url": "https://kaart.maaamet.ee/wms/kaart",
        "crs": "EPSG:3301",
        "default_layer": "MA-KAART",
        "format": "image/png",
        "is_basemap": True,
    },
    {
        "label": "Maa- ja Ruumiamet Ortofoto (EESTIFOTO) WMS (EPSG:3301)",
        "service_type": "wms",
        "url": "https://kaart.maaamet.ee/wms/fotokaart",
        "crs": "EPSG:3301",
        "default_layer": "EESTIFOTO",
        "format": "image/jpeg",
        "is_basemap": True,
    },
    {
        "label": "Maa- ja Ruumiamet Hübriidkaart WMS (EPSG:3301)",
        "service_type": "wms",
        "url": "https://kaart.maaamet.ee/wms/fotokaart",
        "crs": "EPSG:3301",
        "default_layer": "HYBRID",
        "format": "image/jpeg",
        "is_basemap": True,
    },
]


class OgcConnector:
    """Builds and manages live OGC WFS & WMS connections across QGIS Desktop and HTML exports."""

    @staticmethod
    def parse_wfs_capabilities_xml(xml_text: str) -> List[Dict[str, str]]:
        """Parse WFS GetCapabilities XML (1.0/1.1/2.0) into a list of layer descriptors."""
        root = ET.fromstring(xml_text)
        layers: List[Dict[str, str]] = []
        for elem in root.iter():
            tag = elem.tag.split("}")[-1]
            if tag == "FeatureType":
                name, title, crs = "", "", "EPSG:3301"
                for child in elem:
                    ctag = child.tag.split("}")[-1]
                    if ctag == "Name" and child.text:
                        name = child.text.strip()
                    elif ctag == "Title" and child.text:
                        title = child.text.strip()
                    elif ctag in ("DefaultCRS", "DefaultSRS", "SRS") and child.text:
                        raw_crs = child.text.strip()
                        m = re.search(r"EPSG[:/]+(\d+)", raw_crs, re.IGNORECASE)
                        crs = f"EPSG:{m.group(1)}" if m else raw_crs
                if name:
                    layers.append(
                        {
                            "name": name,
                            "title": title or name,
                            "crs": crs,
                            "service_type": "wfs",
                        }
                    )
        return sorted(layers, key=lambda item: item["title"].lower())

    @staticmethod
    def parse_wms_capabilities_xml(xml_text: str) -> List[Dict[str, str]]:
        """Parse WMS GetCapabilities XML (1.1.1 / 1.3.0) into a list of layer descriptors."""
        root = ET.fromstring(xml_text)
        layers: List[Dict[str, str]] = []
        seen = set()
        for elem in root.iter():
            if elem.tag.split("}")[-1] == "Layer":
                name, title, crs = "", "", "EPSG:3301"
                for child in elem:
                    ctag = child.tag.split("}")[-1]
                    if ctag == "Name" and child.text:
                        name = child.text.strip()
                    elif ctag == "Title" and child.text:
                        title = child.text.strip()
                    elif ctag in ("CRS", "SRS") and child.text and crs == "EPSG:3301":
                        crs = child.text.strip()
                if name and name not in seen and name != "OGC:WMS":
                    seen.add(name)
                    layers.append(
                        {
                            "name": name,
                            "title": title or name,
                            "crs": crs,
                            "service_type": "wms",
                        }
                    )
        return layers

    @classmethod
    def discover_layers(
        cls, base_url: str, service_type: str = "wfs", timeout: int = 15
    ) -> List[Dict[str, str]]:
        """
        Fetch GetCapabilities from an OGC WFS or WMS endpoint (e.g. EELIS WFS or Maa-amet WMS)
        and return available layers with their names, titles, and CRS.
        """
        parsed = urlparse(base_url.strip())
        q = dict(parse_qsl(parsed.query, keep_blank_values=True))
        svc = "WMS" if service_type.lower() == "wms" else "WFS"
        q["service"] = svc
        q["request"] = "GetCapabilities"
        if svc == "WFS":
            q.setdefault("version", "2.0.0")
        else:
            q.setdefault("version", "1.3.0")

        caps_url = urlunparse(
            (parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(q), parsed.fragment)
        )
        with urllib.request.urlopen(caps_url, timeout=timeout) as resp:
            xml_text = resp.read().decode("utf-8", errors="replace")

        if svc == "WMS":
            return cls.parse_wms_capabilities_xml(xml_text)
        return cls.parse_wfs_capabilities_xml(xml_text)

    @staticmethod
    def parse_wfs_describe_xml(xml_text: str) -> List[str]:
        """Parse WFS DescribeFeatureType XSD XML to return attribute field names (no geometries)."""
        root = ET.fromstring(xml_text)
        skip_names = {"geom", "the_geom", "geometry", "shape", "msgeometry", "boundedby"}
        fields: List[str] = []
        seen = set()
        for elem in root.iter():
            tag = elem.tag.split("}")[-1]
            if tag == "element":
                fname = (elem.attrib.get("name") or "").strip()
                ftype = (elem.attrib.get("type") or "").lower()
                if not fname or fname.lower() in skip_names or "gml:" in ftype or "geometry" in ftype:
                    continue
                if fname not in seen:
                    seen.add(fname)
                    fields.append(fname)
        return fields

    @classmethod
    def describe_wfs_fields(
        cls, base_url: str, typename: str, timeout: int = 10
    ) -> List[str]:
        """Query WFS DescribeFeatureType to discover attribute column names without loading features."""
        parsed = urlparse(base_url.strip())
        q = dict(parse_qsl(parsed.query, keep_blank_values=True))
        q["service"] = "WFS"
        q["request"] = "DescribeFeatureType"
        q["version"] = "2.0.0"
        q["typeNames"] = typename
        desc_url = urlunparse(
            (parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(q), parsed.fragment)
        )
        with urllib.request.urlopen(desc_url, timeout=timeout) as resp:
            xml_text = resp.read().decode("utf-8", errors="replace")
        return cls.parse_wfs_describe_xml(xml_text)


    @staticmethod
    def is_massive_layer(name: str, typename: str = "") -> bool:
        """Return True for country-wide high-density layers requiring strict BBOX & caps."""
        blob = f"{name or ''} {typename or ''}".lower()
        return any(tok in blob for tok in ("kataster", "ky_kehtiv", "etak", "kitsendus"))

    @staticmethod
    def build_qgis_wfs_uri(ds: DataSourceConfig) -> str:
        """
        Construct a valid QGIS WFS provider URI string matching QGIS WFS connection format.
        Enforces restrictToRequestBBOX='1' and capped pageSize for massive cadastral layers
        like Maa-amet Kataster so QGIS does not freeze downloading the whole country.
        """
        is_massive = OgcConnector.is_massive_layer(ds.name, ds.typename_or_layers)
        raw_page = int(ds.page_size or 1000)
        page_sz = min(raw_page, 400) if is_massive else raw_page
        parts: List[str] = [
            f"pageSize='{page_sz}'",
            "pagingEnabled='true'",
            "preferCoordinatesForWfsT11='false'",
        ]
        if ds.restrict_to_bbox or is_massive:
            parts.append("restrictToRequestBBOX='1'")
        parts.extend(
            [
                f"srsname='{ds.crs or 'EPSG:4326'}'",
                f"typename='{ds.typename_or_layers}'",
                f"url='{ds.url}'",
                f"version='{ds.version or 'auto'}'",
            ]
        )
        if ds.auth_mode == "authcfg" and ds.authcfg_id:
            parts.append(f"authcfg='{ds.authcfg_id}'")
        elif ds.auth_mode == "basic" and ds.basic_user:
            parts.append(f"username='{ds.basic_user}'")
        return " ".join(parts)

    @staticmethod
    def build_qgis_wms_uri(ds: DataSourceConfig) -> str:
        """
        Construct a valid QGIS WMS provider URI query string.
        Example: contextualWMSLegend=0&crs=EPSG:4326&dpiMode=7&format=image/png&layers=basemap&styles=&url=https://...
        """
        params: List[Tuple[str, str]] = [
            ("contextualWMSLegend", "0"),
            ("crs", ds.crs or "EPSG:3301"),
            ("dpiMode", "7"),
            ("format", ds.image_format or "image/png"),
            ("layers", ds.typename_or_layers),
            ("styles", ds.styles or ""),
            ("url", ds.url),
        ]
        if ds.version and ds.version != "auto":
            params.append(("version", ds.version))
        if ds.auth_mode == "authcfg" and ds.authcfg_id:
            params.append(("authcfg", ds.authcfg_id))
        return urlencode(params)

    @classmethod
    def build_browser_wfs_geojson_url(
        cls,
        ds: DataSourceConfig,
        max_features: Optional[int] = None,
        bbox_wgs84: Optional[Tuple[float, float, float, float]] = None,
        start_index: Optional[int] = None,
        sort_by: str = "",
    ) -> str:
        """
        Build a live OGC WFS GetFeature GeoJSON URL for the exported HTML dashboard
        running on the corporate network/VPN or public GeoServer endpoints.
        bbox_wgs84 format (south, west, north, east) uses EPSG:4326 axis order for WFS 2.0.0.
        """
        parsed = urlparse(ds.url)
        query_dict = dict(parse_qsl(parsed.query, keep_blank_values=True))

        version = ds.version if (ds.version and ds.version != "auto") else "2.0.0"
        count_val = (
            int(max_features)
            if (max_features is not None and int(max_features) > 0)
            else int(ds.page_size or 5000)
        )
        query_dict.setdefault("service", "WFS")
        query_dict.setdefault("request", "GetFeature")
        query_dict["version"] = version

        if version.startswith("2."):
            query_dict["typeNames"] = ds.typename_or_layers
            query_dict["count"] = str(count_val)
        else:
            query_dict["typeName"] = ds.typename_or_layers
            query_dict["maxFeatures"] = str(count_val)

        if start_index is not None and int(start_index) >= 0:
            query_dict["startIndex"] = str(int(start_index))
        else:
            query_dict.pop("startIndex", None)

        if sort_by:
            query_dict["sortBy"] = sort_by
        else:
            query_dict.pop("sortBy", None)

        query_dict["outputFormat"] = "application/json"
        query_dict["srsName"] = "EPSG:4326"

        if ds.cql_filter:
            query_dict["CQL_FILTER"] = ds.cql_filter

        if bbox_wgs84 is not None:
            south, west, north, east = bbox_wgs84
            query_dict["bbox"] = f"{south},{west},{north},{east},urn:ogc:def:crs:EPSG::4326"

        new_query = urlencode(query_dict)
        return urlunparse(
            (
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                parsed.params,
                new_query,
                parsed.fragment,
            )
        )

    @classmethod
    def build_browser_descriptor(cls, ds: DataSourceConfig) -> Dict[str, Any]:
        """
        Build the live connection & authentication metadata used by the Leaflet + Fetch
        client inside the exported HTML dashboard.
        """
        if ds.source_type == "wms":
            return {
                "id": ds.id,
                "name": ds.name,
                "type": "wms",
                "url": ds.url,
                "layers": ds.typename_or_layers,
                "format": ds.image_format or "image/png",
                "styles": ds.styles or "",
                "crs": ds.crs or "EPSG:3301",
                "version": ds.version if (ds.version and ds.version != "auto") else "1.1.1",
                "is_basemap": bool(ds.is_basemap),
                "auth_mode": ds.auth_mode,
                "with_credentials": ds.auth_mode == "sso_credentials",
            }

        return {
            "id": ds.id,
            "name": ds.name,
            "type": "wfs",
            "url": ds.url,
            "geojson_url": cls.build_browser_wfs_geojson_url(ds),
            "typename": ds.typename_or_layers,
            "crs": ds.crs or "EPSG:4326",
            "page_size": int(ds.page_size or 1000),
            "max_features": int(getattr(ds, "max_features", 0) or 0),
            "auto_refresh_seconds": int(getattr(ds, "auto_refresh_seconds", 0) or 0),
            "cql_filter": ds.cql_filter or "",
            "restrict_to_bbox": bool(ds.restrict_to_bbox),
            "layer_color": ds.layer_color or "#38bdf8",
            "auth_mode": ds.auth_mode,
            "with_credentials": ds.auth_mode == "sso_credentials",
            "bearer_token_hint": ds.bearer_token_env or "",
        }

    @classmethod
    def connect_qgis_layer(
        cls,
        ds: DataSourceConfig,
        add_to_project: bool = True,
        isolated_store: Optional[Dict[str, Any]] = None,
    ) -> Optional[Any]:
        """
        Connect a live WFS or WMS layer inside QGIS Desktop.
        When add_to_project=True, registers it into QgsProject.instance().
        When add_to_project=False (isolated dashboard mode), keeps it inside isolated_store
        without adding it to the QGIS main canvas layer tree.
        Returns the QgsMapLayer instance (or None if running outside QGIS).
        """
        try:
            from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer
        except ImportError:
            return None

        if not add_to_project and isinstance(isolated_store, dict):
            existing_iso = isolated_store.get(ds.name)
            if existing_iso is not None:
                try:
                    if not hasattr(existing_iso, "isValid") or existing_iso.isValid():
                        return existing_iso
                except RuntimeError:
                    pass
        elif add_to_project:
            existing = QgsProject.instance().mapLayersByName(ds.name)
            if existing:
                return existing[0]

            if ds.typename_or_layers:
                for lyr in QgsProject.instance().mapLayers().values():
                    src = lyr.source() if hasattr(lyr, "source") else ""
                    if ds.typename_or_layers in src and ds.url in src:
                        return lyr

        if ds.source_type == "wms":
            uri = cls.build_qgis_wms_uri(ds)
            layer = QgsRasterLayer(uri, ds.name, "wms")
        else:
            uri = cls.build_qgis_wfs_uri(ds)
            layer = QgsVectorLayer(uri, ds.name, "WFS")

        if layer and layer.isValid():
            if not add_to_project:
                if ds.source_type != "wms" and hasattr(layer, "setLabelsEnabled"):
                    try:
                        layer.setLabelsEnabled(False)
                    except Exception:
                        pass
                if isinstance(isolated_store, dict):
                    isolated_store[ds.name] = layer
            else:
                QgsProject.instance().addMapLayer(layer)
        return layer

    @classmethod
    def _effective_source_cap(cls, ds: DataSourceConfig, max_features: Optional[int] = None) -> int:
        """Resolve effective feature limit (0 = unlimited for non-massive layers)."""
        is_massive = cls.is_massive_layer(ds.name, ds.typename_or_layers)
        if max_features is not None:
            val = int(max_features)
            if is_massive:
                return min(val, 2000) if val > 0 else 400
            return 0 if val <= 0 else val
        raw_ds_max = int(getattr(ds, "max_features", 0) or 0)
        if is_massive:
            return min(raw_ds_max, 2000) if raw_ds_max > 0 else 400
        # Treat unset or legacy hardcoded 10000 default as unlimited for standard layers
        return 0 if raw_ds_max in (0, 10000) else raw_ds_max

    @staticmethod
    def _pick_wfs_sort_field(features: List[Dict[str, Any]]) -> str:
        if not features:
            return ""
        props = (features[0] or {}).get("properties") or {}
        if not isinstance(props, dict) or not props:
            return ""
        lower_map = {str(k).lower(): str(k) for k in props.keys()}
        for cand in ("sys_id", "fid", "objectid", "gid", "id", "parandniidu_nr", "kr_kood"):
            if cand in lower_map and props.get(lower_map[cand]) is not None:
                return lower_map[cand]
        for k, v in props.items():
            if v is not None:
                return str(k)
        return ""

    @classmethod
    def fetch_wfs_geojson_http(
        cls,
        ds: DataSourceConfig,
        bbox_wgs84: Optional[Tuple[float, float, float, float]] = None,
        max_features: Optional[int] = None,
        timeout: int = 45,
        progress_cb: Optional[Callable[[int, int], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Fetch all WFS features as GeoJSON over standard HTTP with paginated startIndex
        support so large layers (80,000+ features) load completely without hitting a
        10,000-feature truncation limit. Safe inside background worker threads.
        Returns (records, geojson_feature_collection).
        """
        from ..core.spatial_overlap import enrich_records_domain_fields, geojson_bbox_wgs84, geom_area_ha

        is_massive = cls.is_massive_layer(ds.name, ds.typename_or_layers)
        cap = cls._effective_source_cap(ds, max_features=max_features)
        raw_ps = int(getattr(ds, "page_size", 0) or 0)
        if is_massive:
            page_size = min(400, cap or 400)
        elif cap > 0:
            page_size = min(cap, 10000)
        else:
            page_size = min(max(raw_ps if raw_ps >= 2000 else 10000, 2000), 10000)
        req_timeout = max(45, int(timeout or 45))

        def _fetch_page(req_count: int, start_idx: int, sort_by: str = "") -> Dict[str, Any]:
            url = cls.build_browser_wfs_geojson_url(
                ds,
                max_features=req_count,
                bbox_wgs84=bbox_wgs84,
                start_index=start_idx if (start_idx > 0 or not is_massive) else None,
                sort_by=sort_by,
            )
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=req_timeout) as resp:
                chunks: List[bytes] = []
                while True:
                    if cancel_check and cancel_check():
                        return {}
                    block = resp.read(65536)
                    if not block:
                        break
                    chunks.append(block)
            raw_txt = b"".join(chunks).decode("utf-8", errors="replace")
            fc_obj = json.loads(raw_txt)
            return fc_obj if isinstance(fc_obj, dict) else {}

        if progress_cb:
            progress_cb(3, 100)

        try:
            fc0 = _fetch_page(page_size, 0)
        except Exception:
            if page_size > 2000:
                page_size = 2000
                fc0 = _fetch_page(page_size, 0)
            else:
                raise

        if cancel_check and cancel_check():
            return [], {"type": "FeatureCollection", "features": []}
        if not isinstance(fc0, dict) or not isinstance(fc0.get("features"), list):
            if progress_cb:
                progress_cb(100, 100)
            return [], {"type": "FeatureCollection", "features": []}

        raw_feats: List[Dict[str, Any]] = []
        seen_fids: set = set()
        dup_detected = False

        def _append_page(page_feats: List[Dict[str, Any]]) -> Tuple[int, bool]:
            added = 0
            dup = False
            for ft in page_feats:
                if not isinstance(ft, dict):
                    continue
                fk = ft.get("id")
                fid_str = str(fk) if fk is not None and fk != "" else ""
                if fid_str:
                    if fid_str in seen_fids:
                        dup = True
                        continue
                    seen_fids.add(fid_str)
                raw_feats.append(ft)
                added += 1
                if cap > 0 and len(raw_feats) >= cap:
                    break
            return added, dup

        page0_feats = fc0.get("features") or []
        _append_page(page0_feats)
        try:
            reported_total = int(fc0.get("totalFeatures") or fc0.get("numberMatched") or 0)
        except Exception:
            reported_total = 0

        target_total = (
            min(cap, reported_total) if (cap > 0 and reported_total > 0) else (cap or reported_total)
        )
        if progress_cb:
            p0_pct = (
                55
                if (target_total > 0 and len(raw_feats) >= target_total) or len(page0_feats) < page_size
                else 15
            )
            progress_cb(p0_pct, 100)

        more_expected = bool(page0_feats) and (
            (target_total > 0 and len(raw_feats) < target_total)
            or (reported_total <= 0 and len(page0_feats) >= page_size and (cap <= 0 or len(raw_feats) < cap))
        )

        if more_expected and not is_massive:
            eff_page_step = max(len(page0_feats), 1)
            if reported_total > 0:
                end_limit = min(cap, reported_total) if cap > 0 else reported_total
                offsets = list(range(len(page0_feats), end_limit, eff_page_step))
                page_results: Dict[int, List[Dict[str, Any]]] = {}
                if len(offsets) > 1:
                    workers = min(3, len(offsets))
                    with ThreadPoolExecutor(max_workers=workers) as pool:
                        fut_map = {
                            pool.submit(
                                _fetch_page,
                                min(eff_page_step, cap - off) if cap > 0 else eff_page_step,
                                off,
                            ): off
                            for off in offsets
                        }
                        done_pages = 0
                        for fut in as_completed(fut_map):
                            if cancel_check and cancel_check():
                                return [], {"type": "FeatureCollection", "features": []}
                            off = fut_map[fut]
                            fc_p = fut.result()
                            page_results[off] = (fc_p or {}).get("features") or []
                            done_pages += 1
                            if progress_cb:
                                progress_cb(15 + int(45 * done_pages / max(1, len(offsets))), 100)
                else:
                    for off in offsets:
                        if cancel_check and cancel_check():
                            return [], {"type": "FeatureCollection", "features": []}
                        req_n = min(eff_page_step, cap - off) if cap > 0 else eff_page_step
                        fc_p = _fetch_page(req_n, off)
                        page_results[off] = (fc_p or {}).get("features") or []

                for off in offsets:
                    _, pdup = _append_page(page_results.get(off) or [])
                    if pdup:
                        dup_detected = True
                    if cap > 0 and len(raw_feats) >= cap:
                        break
            else:
                start_idx = len(page0_feats)
                while cap <= 0 or len(raw_feats) < cap:
                    if cancel_check and cancel_check():
                        return [], {"type": "FeatureCollection", "features": []}
                    req_n = min(page_size, cap - len(raw_feats)) if cap > 0 else page_size
                    fc_p = _fetch_page(req_n, start_idx)
                    pfeats = (fc_p or {}).get("features") or []
                    if not pfeats:
                        break
                    added, pdup = _append_page(pfeats)
                    if pdup:
                        dup_detected = True
                    if added == 0 or len(pfeats) < req_n:
                        break
                    start_idx += len(pfeats)

            if dup_detected and (target_total <= 0 or len(raw_feats) < target_total):
                sort_field = cls._pick_wfs_sort_field(raw_feats)
                if sort_field:
                    try:
                        sorted_feats: List[Dict[str, Any]] = []
                        sorted_seen: set = set()
                        s_idx = 0
                        while cap <= 0 or len(sorted_feats) < cap:
                            if cancel_check and cancel_check():
                                return [], {"type": "FeatureCollection", "features": []}
                            req_n = min(page_size, cap - len(sorted_feats)) if cap > 0 else page_size
                            fc_s = _fetch_page(req_n, s_idx, sort_by=sort_field)
                            s_page = (fc_s or {}).get("features") or []
                            if not s_page:
                                break
                            s_added = 0
                            for ft in s_page:
                                if not isinstance(ft, dict):
                                    continue
                                fk = ft.get("id")
                                fk_s = str(fk) if fk is not None and fk != "" else ""
                                if fk_s:
                                    if fk_s in sorted_seen:
                                        continue
                                    sorted_seen.add(fk_s)
                                sorted_feats.append(ft)
                                s_added += 1
                                if cap > 0 and len(sorted_feats) >= cap:
                                    break
                            eff_target = min(cap, reported_total) if (cap > 0 and reported_total > 0) else reported_total
                            if s_added == 0 or (eff_target > 0 and len(sorted_feats) >= eff_target):
                                break
                            if reported_total <= 0 and len(s_page) < req_n:
                                break
                            s_idx += len(s_page)
                        if len(sorted_feats) > len(raw_feats):
                            raw_feats = sorted_feats
                    except Exception:
                        pass

        if progress_cb:
            progress_cb(62, 100)

        total_feats = max(1, len(raw_feats))
        records: List[Dict[str, Any]] = []
        clean_features: List[Dict[str, Any]] = []
        for idx, feat in enumerate(raw_feats):
            if cancel_check and idx % 200 == 0 and cancel_check():
                return records, {"type": "FeatureCollection", "features": clean_features}
            if not isinstance(feat, dict):
                continue
            fid = feat.get("id") or f"{ds.name}_{idx}"
            props = dict(feat.get("properties") or {})
            props["_feature_id"] = fid
            geom = feat.get("geometry")
            if isinstance(geom, dict):
                gtype = geom.get("type", "")
                if gtype in ("Polygon", "MultiPolygon"):
                    aha = geom_area_ha(geom)
                    props["_geom_area_ha"] = aha
                    if props.get("area_ha") is None:
                        props["area_ha"] = aha
                if gtype not in ("Point", "MultiPoint"):
                    bb = geojson_bbox_wgs84(geom)
                    if bb is not None:
                        props["_bbox"] = [round(v, 5) for v in bb]
                cen = cls._geojson_centroid(geom)
                if cen is not None:
                    props["_lon"], props["_lat"] = cen
            records.append(props)
            clean_features.append(
                {
                    "type": "Feature",
                    "id": fid,
                    "properties": props,
                    "geometry": geom,
                }
            )
            if progress_cb and idx % 500 == 0:
                progress_cb(65 + int(30 * (idx + 1) / total_feats), 100)

        enrich_records_domain_fields(records)
        if progress_cb:
            progress_cb(100, 100)
        return records, {"type": "FeatureCollection", "features": clean_features}

    @staticmethod
    def _geojson_centroid(geom: Dict[str, Any]) -> Optional[Tuple[float, float]]:
        coords = geom.get("coordinates")
        if not coords:
            return None
        pts: List[Tuple[float, float]] = []

        def _collect(node: Any) -> None:
            if not isinstance(node, (list, tuple)) or not node:
                return
            if isinstance(node[0], (int, float)) and len(node) >= 2:
                pts.append((float(node[0]), float(node[1])))
                return
            for child in node:
                if len(pts) >= 400:
                    return
                _collect(child)

        _collect(coords)
        if not pts:
            return None
        return (
            sum(p[0] for p in pts) / len(pts),
            sum(p[1] for p in pts) / len(pts),
        )

    @staticmethod
    def default_layer_color_for_name(layer_name: str, typename: str = "") -> str:
        """Return consistent domain fill hex color when a layer has no custom override."""
        txt = f"{layer_name or ''} {typename or ''}".lower()
        if any(k in txt for k in ("kaitseala", "loodusala", "hoiuala", "linnuala", "püsielupaik", "pysielupaik")):
            return "#f97316"
        if any(k in txt for k in ("natura", "elupaik")):
            return "#10b981"
        if any(k in txt for k in ("pria", "pärandniit", "parandniit", "niit")):
            return "#0ea5e9"
        return "#38bdf8"

    @staticmethod
    def _extract_qgis_primary_color(layer: Any) -> str:
        """Best-effort hex color (#rrggbb) from a QGIS vector layer renderer symbol."""
        try:
            rend = layer.renderer() if hasattr(layer, "renderer") else None
            if rend is None:
                return ""
            sym = None
            if hasattr(rend, "symbol"):
                sym = rend.symbol()
            if sym is None and hasattr(rend, "categories"):
                cats = list(rend.categories() or [])
                if cats and hasattr(cats[0], "symbol"):
                    sym = cats[0].symbol()
            if sym is None:
                return ""
            if hasattr(sym, "symbolLayerCount") and sym.symbolLayerCount() > 0:
                sl0 = sym.symbolLayer(0)
                for fn_name in ("fillColor", "color", "strokeColor"):
                    if hasattr(sl0, fn_name):
                        col = getattr(sl0, fn_name)()
                        if col is not None and (not hasattr(col, "isValid") or col.isValid()):
                            if not hasattr(col, "alpha") or col.alpha() > 0 or fn_name == "strokeColor":
                                return str(col.name())
            if hasattr(sym, "color"):
                col = sym.color()
                if col is not None and (not hasattr(col, "isValid") or col.isValid()):
                    return str(col.name())
        except Exception:
            pass
        return ""

    @staticmethod
    def infer_wfs_datasource_from_qgis_layer(layer: Any) -> Optional[DataSourceConfig]:
        """Extract DataSourceConfig metadata from a live QGIS WFS layer if loaded directly in project."""
        try:
            ptype = layer.providerType().lower() if hasattr(layer, "providerType") else ""
            if ptype != "wfs":
                return None
            src = layer.source() if hasattr(layer, "source") else ""
            m_url = re.search(r"url='([^']+)'", src)
            m_tn = re.search(r"typename='([^']+)'", src)
            m_crs = re.search(r"srsname='([^']+)'", src)
            if not m_url or not m_tn:
                return None
            layer_nm = layer.name()
            tn = m_tn.group(1)
            is_massive = OgcConnector.is_massive_layer(layer_nm, tn)
            layer_col = (
                OgcConnector._extract_qgis_primary_color(layer)
                or OgcConnector.default_layer_color_for_name(layer_nm, tn)
            )
            return DataSourceConfig(
                name=layer_nm,
                source_type="wfs",
                url=m_url.group(1),
                typename_or_layers=tn,
                crs=m_crs.group(1) if m_crs else (layer.crs().authid() or "EPSG:3301"),
                layer_color=layer_col,
                restrict_to_bbox=is_massive,
                page_size=400 if is_massive else 1000,
                max_features=400 if is_massive else 0,
                provider_type="wfs",
                source_uri=src,
            )
        except Exception:
            return None

    @staticmethod
    def infer_datasource_from_qgis_layer(
        layer: Any, project_dir: Optional[str] = None
    ) -> Optional[DataSourceConfig]:
        """Extract a portable DataSourceConfig (WFS, WMS, or file/provider URI) from any QGIS map layer."""
        if layer is None:
            return None
        wfs_ds = OgcConnector.infer_wfs_datasource_from_qgis_layer(layer)
        if wfs_ds is not None:
            return wfs_ds
        try:
            from .path_resolver import PortablePathResolver

            prov = str(layer.providerType() if hasattr(layer, "providerType") else "").strip()
            src = str(layer.source() if hasattr(layer, "source") else "").strip()
            lname = str(layer.name() if hasattr(layer, "name") else "").strip()
            if not lname:
                return None
            crs_auth = ""
            try:
                if hasattr(layer, "crs") and layer.crs() is not None:
                    crs_auth = str(layer.crs().authid() or "")
            except Exception:
                crs_auth = ""
            layer_col = (
                OgcConnector._extract_qgis_primary_color(layer)
                or OgcConnector.default_layer_color_for_name(lname, lname)
            )

            if prov.lower() == "wms" and src:
                params = dict(parse_qsl(src, keep_blank_values=True))
                wms_url = str(params.get("url") or "").strip()
                wms_layers = str(params.get("layers") or "").strip()
                wms_fmt = str(params.get("format") or "image/png").strip()
                wms_crs = str(params.get("crs") or crs_auth or "EPSG:3301").strip()
                if wms_url and wms_layers:
                    return DataSourceConfig(
                        name=lname,
                        source_type="wms",
                        url=wms_url,
                        typename_or_layers=wms_layers,
                        image_format=wms_fmt,
                        crs=wms_crs,
                        layer_color=layer_col,
                        is_basemap=False,
                        provider_type=prov,
                        source_uri=src,
                    )

            tok_uri = src
            tok_file = ""
            if src:
                if "|" in src:
                    file_part, suffix_part = src.split("|", 1)
                    tok_file = PortablePathResolver.tokenize(file_part, project_dir=project_dir)
                    tok_uri = f"{tok_file}|{suffix_part}"
                elif os.path.exists(src) or re.match(r"^[a-zA-Z]:[/\\]|^/", src) or src.startswith("${"):
                    tok_file = PortablePathResolver.tokenize(src, project_dir=project_dir)
                    tok_uri = tok_file

            return DataSourceConfig(
                name=lname,
                source_type="qgis_layer",
                typename_or_layers=lname,
                crs=crs_auth or "EPSG:3301",
                layer_color=layer_col,
                is_basemap=False,
                restrict_to_bbox=False,
                max_features=0,
                provider_type=prov or "ogr",
                source_uri=tok_uri,
                portable_path=tok_file,
            )
        except Exception:
            return None

    @staticmethod
    def _is_qgis_wfs_layer(layer: Any) -> bool:
        try:
            return hasattr(layer, "providerType") and layer.providerType().lower() == "wfs"
        except Exception:
            return False

    @staticmethod
    def extract_records_from_qgis_layer(
        layer: Any,
        max_features: int = 0,
        extent_rect: Optional[Any] = None,
        progress_cb: Optional[Callable[[int, int], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Extract feature attribute dictionaries, computed polygon area_ha (_geom_area_ha),
        and WGS84 centroid (_lon/_lat) from a live QGIS QgsVectorLayer.
        """
        from ..core.spatial_overlap import QgisCartesianAreaCalculator, enrich_records_domain_fields

        if layer is None or not hasattr(layer, "getFeatures"):
            return []

        field_names = [f.name() for f in layer.fields()]
        records: List[Dict[str, Any]] = []

        # Setup coordinate transform to EPSG:4326 and Cartesian area calculator
        xform = None
        area_calc = None
        req = None
        eff_max = int(max_features or 0)
        try:
            from qgis.core import (
                Qgis,
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsFeatureRequest,
                QgsProject,
                QgsWkbTypes,
            )

            proj = QgsProject.instance()
            tctx = proj.transformContext()
            wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
            if layer.crs().isValid() and layer.crs() != wgs84:
                xform = QgsCoordinateTransform(layer.crs(), wgs84, tctx)

            poly_geom_type = getattr(getattr(Qgis, "GeometryType", None), "Polygon", None)
            if poly_geom_type is None:
                poly_geom_type = QgsWkbTypes.PolygonGeometry
            if layer.geometryType() == poly_geom_type:
                area_calc = QgisCartesianAreaCalculator(
                    layer.crs(), tctx, ellipsoid=proj.ellipsoid() or "GRS80", layer=layer
                )

            req = QgsFeatureRequest()
            if extent_rect is not None:
                req.setFilterRect(extent_rect)
            if eff_max > 0:
                req.setLimit(eff_max)
        except Exception:
            req = None

        feat_iter = layer.getFeatures(req) if req is not None else layer.getFeatures()
        est_total = eff_max if eff_max > 0 else 1000
        try:
            if hasattr(layer, "featureCount") and extent_rect is None:
                fc_cnt = int(layer.featureCount())
                if fc_cnt > 0:
                    est_total = min(eff_max, fc_cnt) if eff_max > 0 else fc_cnt
        except Exception:
            pass
        if progress_cb:
            progress_cb(0, max(1, est_total))
        last_yield_ts = time.monotonic()
        for idx, feat in enumerate(feat_iter):
            if eff_max > 0 and idx >= eff_max:
                break
            now_ts = time.monotonic()
            need_tick = (now_ts - last_yield_ts) >= 0.018
            if cancel_check and (idx % 25 == 0 or need_tick) and cancel_check():
                break
            row: Dict[str, Any] = {"_feature_id": feat.id()}
            for fn in field_names:
                val = feat[fn]
                if hasattr(val, "isNull") and val.isNull():
                    row[fn] = None
                elif hasattr(val, "toString") and not isinstance(val, (str, int, float, bool)):
                    row[fn] = val.toString("yyyy-MM-dd") if hasattr(val, "year") else val.toString()
                else:
                    row[fn] = val

            if feat.hasGeometry():
                geom = feat.geometry()
                try:
                    if area_calc is not None:
                        aha = area_calc.measure_ha(geom, decimals=4)
                        row["_geom_area_ha"] = aha
                        if row.get("area_ha") is None:
                            row["area_ha"] = aha
                    cen_geom = geom.centroid()
                    centroid = cen_geom.asPoint() if cen_geom and not cen_geom.isEmpty() else geom.boundingBox().center()
                    if xform is not None:
                        centroid = xform.transform(centroid)
                    row["_lon"] = float(centroid.x())
                    row["_lat"] = float(centroid.y())
                    bb_wgs = geom.boundingBox()
                    if xform is not None:
                        bb_wgs = xform.transformBoundingBox(bb_wgs)
                    if not bb_wgs.isEmpty() and (bb_wgs.width() > 0 or bb_wgs.height() > 0):
                        row["_bbox"] = [
                            round(float(bb_wgs.xMinimum()), 5),
                            round(float(bb_wgs.yMinimum()), 5),
                            round(float(bb_wgs.xMaximum()), 5),
                            round(float(bb_wgs.yMaximum()), 5),
                        ]
                except Exception:
                    pass
            records.append(row)
            if progress_cb and (idx % 100 == 0 or need_tick):
                last_yield_ts = now_ts
                progress_cb(min(max(1, est_total), idx + 1), max(1, est_total))

        enrich_records_domain_fields(records)
        if progress_cb:
            done_n = max(1, len(records))
            progress_cb(done_n, done_n)
        return records

    @staticmethod
    def extract_layer_bundle_from_qgis_layer(
        layer: Any,
        layer_name: str = "",
        max_records: int = 0,
        extent_rect: Optional[Any] = None,
        include_lod0: bool = True,
        include_lod1: bool = True,
        lod0_max_features: int = 3200,
        lod1_max_features: int = 6000,
        initial_geojson_max: int = 2000,
        transform_context: Any = None,
        ellipsoid: str = "GRS80",
        progress_cb: Optional[Callable[[int, int], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> Dict[str, Any]:
        """
        Single-pass extractor yielding `(records, stats, lod0, lod1, initial_geojson)` from
        a QgsVectorLayer. Accepts an explicit *transform_context* so private read-only layers
        opened in background worker threads never touch QgsProject.instance().
        """
        out: Dict[str, Any] = {
            "cancelled": False,
            "records": [],
            "stats": None,
            "lod0": None,
            "lod1": None,
            "initial_geojson": None,
        }
        if layer is None or not hasattr(layer, "getFeatures"):
            return out

        from ..core.spatial_overlap import QgisCartesianAreaCalculator, enrich_records_domain_fields
        from ..core.vector_pyramid import (
            _packed_to_geojson_geometry,
            _simplify_geojson_geometry,
            build_lod0_grid_pyramid,
            compute_layer_statistics,
        )

        field_names = [f.name() for f in layer.fields()]
        records: List[Dict[str, Any]] = []
        row_by_fid: Dict[Any, Dict[str, Any]] = {}
        geom_scores: List[Tuple[float, Any]] = []
        prov_type = ""
        try:
            if hasattr(layer, "providerType"):
                prov_type = str(layer.providerType() or "").lower()
        except Exception:
            prov_type = ""
        capture_in_pass1 = prov_type in ("wfs", "arcgisfeatureserver")
        target_sample_cap = max(
            lod1_max_features if include_lod1 else 0,
            lod0_max_features if include_lod0 else 0,
            initial_geojson_max,
        )
        tol1_deg = 0.00022
        pass1_top_heap: List[Tuple[float, int, Any, Any]] = []
        pass1_sample: Dict[Any, Any] = {}
        pass1_top_cap = max(1, int(target_sample_cap * 0.78))
        pass1_sample_cap = max(1, target_sample_cap - pass1_top_cap)

        xform = None
        area_calc = None
        use_planar_metric = False
        is_point_layer = False
        is_geographic = False
        geom_type_label = ""
        req = None
        req_cls = None
        qgs_geom_cls = None
        try:
            from qgis.core import (
                Qgis,
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsDistanceArea,
                QgsFeatureRequest,
                QgsGeometry,
                QgsProject,
                QgsUnitTypes,
                QgsWkbTypes,
            )

            req_cls = QgsFeatureRequest
            qgs_geom_cls = QgsGeometry

            tctx = transform_context
            eff_ellipsoid = ellipsoid or "GRS80"
            if tctx is None:
                proj = QgsProject.instance()
                tctx = proj.transformContext()
                eff_ellipsoid = proj.ellipsoid() or eff_ellipsoid

            wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
            src_crs = layer.crs()
            if src_crs.isValid():
                is_geographic = bool(src_crs.isGeographic())
                if src_crs != wgs84:
                    xform = QgsCoordinateTransform(src_crs, wgs84, tctx)

            poly_geom_type = getattr(getattr(Qgis, "GeometryType", None), "Polygon", None)
            if poly_geom_type is None:
                poly_geom_type = QgsWkbTypes.PolygonGeometry
            point_geom_type = getattr(getattr(Qgis, "GeometryType", None), "Point", None)
            if point_geom_type is None:
                point_geom_type = QgsWkbTypes.PointGeometry
            line_geom_type = getattr(getattr(Qgis, "GeometryType", None), "Line", None)
            if line_geom_type is None:
                line_geom_type = QgsWkbTypes.LineGeometry

            gtype = layer.geometryType()
            is_point_layer = (gtype == point_geom_type)
            if gtype == poly_geom_type:
                geom_type_label = "Polygon"
            elif gtype == line_geom_type:
                geom_type_label = "LineString"
            elif gtype == point_geom_type:
                geom_type_label = "Point"

            eff_max_records = int(max_records or 0)
            if gtype == poly_geom_type:
                area_calc = QgisCartesianAreaCalculator(
                    src_crs, tctx, ellipsoid=eff_ellipsoid, layer=layer
                )

            req = QgsFeatureRequest()
            if extent_rect is not None:
                req.setFilterRect(extent_rect)
            if eff_max_records > 0:
                req.setLimit(eff_max_records)
        except Exception:
            eff_max_records = int(max_records or 0)
            req = None

        feat_iter = layer.getFeatures(req) if req is not None else layer.getFeatures()
        est_total = eff_max_records if eff_max_records > 0 else 1000
        try:
            if hasattr(layer, "featureCount") and extent_rect is None:
                fc_cnt = int(layer.featureCount())
                if fc_cnt > 0:
                    est_total = min(eff_max_records, fc_cnt) if eff_max_records > 0 else fc_cnt
        except Exception:
            pass

        last_yield_ts = time.monotonic()
        if progress_cb:
            progress_cb(0, 100)

        for idx, feat in enumerate(feat_iter):
            if eff_max_records > 0 and idx >= eff_max_records:
                break
            now_ts = time.monotonic()
            need_tick = (now_ts - last_yield_ts) >= 0.018
            if cancel_check and (idx % 25 == 0 or need_tick) and cancel_check():
                out["cancelled"] = True
                return out

            fid = feat.id()
            row: Dict[str, Any] = {"_feature_id": fid}
            for fn in field_names:
                val = feat[fn]
                if hasattr(val, "isNull") and val.isNull():
                    row[fn] = None
                elif hasattr(val, "toString") and not isinstance(val, (str, int, float, bool)):
                    row[fn] = val.toString("yyyy-MM-dd") if hasattr(val, "year") else val.toString()
                else:
                    row[fn] = val

            if feat.hasGeometry():
                geom = feat.geometry()
                try:
                    if area_calc is not None:
                        aha = area_calc.measure_ha(geom, decimals=4)
                        row["_geom_area_ha"] = aha
                        if row.get("area_ha") is None:
                            row["area_ha"] = aha
                    cen_geom = geom.centroid()
                    centroid = cen_geom.asPoint() if cen_geom and not cen_geom.isEmpty() else geom.boundingBox().center()
                    if xform is not None:
                        centroid = xform.transform(centroid)
                    row["_lon"] = float(centroid.x())
                    row["_lat"] = float(centroid.y())
                    bb_wgs = geom.boundingBox()
                    if xform is not None:
                        bb_wgs = xform.transformBoundingBox(bb_wgs)
                    if not bb_wgs.isEmpty() and (bb_wgs.width() > 0 or bb_wgs.height() > 0):
                        row["_bbox"] = [
                            round(float(bb_wgs.xMinimum()), 5),
                            round(float(bb_wgs.yMinimum()), 5),
                            round(float(bb_wgs.xMaximum()), 5),
                            round(float(bb_wgs.yMaximum()), 5),
                        ]
                    if not is_point_layer and (include_lod0 or include_lod1):
                        bb = geom.boundingBox()
                        area_score = float(bb.width() * bb.height())
                        geom_scores.append((area_score, fid))
                        if capture_in_pass1 and qgs_geom_cls is not None and not geom.isNull() and not geom.isEmpty():
                            import heapq
                            need_top = len(pass1_top_heap) < pass1_top_cap or area_score > pass1_top_heap[0][0]
                            sample_step = max(1, int(est_total // max(1, pass1_sample_cap)))
                            need_sample = (idx % sample_step == 0) and (len(pass1_sample) < pass1_sample_cap)
                            if need_top or need_sample:
                                tol1_nat_p1 = tol1_deg if is_geographic else max(15.0, tol1_deg * 111000.0)
                                sg = qgs_geom_cls(geom)
                                try:
                                    sp_g = sg.simplify(tol1_nat_p1)
                                    if sp_g and not sp_g.isEmpty():
                                        sg = sp_g
                                except Exception:
                                    pass
                                if need_top:
                                    if len(pass1_top_heap) < pass1_top_cap:
                                        heapq.heappush(pass1_top_heap, (area_score, idx, fid, sg))
                                    else:
                                        heapq.heapreplace(pass1_top_heap, (area_score, idx, fid, sg))
                                elif need_sample:
                                    pass1_sample[fid] = sg
                except Exception:
                    pass

            records.append(row)
            row_by_fid[fid] = row
            if progress_cb and need_tick:
                last_yield_ts = now_ts
                pct = min(65, 2 + int(63 * (idx + 1) / max(1, est_total)))
                progress_cb(pct, 100)

        if cancel_check and cancel_check():
            out["cancelled"] = True
            return out

        enrich_records_domain_fields(records)
        out["records"] = records
        out["stats"] = compute_layer_statistics(records, layer_name=layer_name, geom_type=geom_type_label)
        if progress_cb:
            progress_cb(68, 100)

        if is_point_layer:
            if include_lod0 and records:
                out["lod0"] = build_lod0_grid_pyramid(records, layer_name=layer_name)
        elif geom_scores and (include_lod0 or include_lod1) and req_cls is not None and qgs_geom_cls is not None:
            target_sample_cap = max(lod1_max_features if include_lod1 else 0, lod0_max_features if include_lod0 else 0, initial_geojson_max)
            if len(geom_scores) > target_sample_cap:
                by_area = sorted(geom_scores, key=lambda it: it[0], reverse=True)
                top_n = int(target_sample_cap * 0.78)
                chosen_ids = [it[1] for it in by_area[:top_n]]
                chosen_set = set(chosen_ids)
                rem = [it[1] for it in geom_scores if it[1] not in chosen_set]
                need = target_sample_cap - len(chosen_ids)
                if rem and need > 0:
                    step = max(1, len(rem) // need)
                    for pos in range(0, len(rem), step):
                        chosen_ids.append(rem[pos])
                        if len(chosen_ids) >= target_sample_cap:
                            break
            else:
                chosen_ids = [it[1] for it in geom_scores]

            lod0_id_set = set(chosen_ids[:lod0_max_features])
            tol1_native = tol1_deg if is_geographic else max(15.0, tol1_deg * 111000.0)
            packed_lod1: Dict[str, List[Any]] = {}
            lod0_feats: List[Dict[str, Any]] = []
            init_feats: List[Dict[str, Any]] = []

            def _iter_selected_geoms():
                if capture_in_pass1 and (pass1_top_heap or pass1_sample):
                    cached_map: Dict[Any, Any] = dict(pass1_sample)
                    for _sc, _ord_i, tfid, tgeom in pass1_top_heap:
                        cached_map[tfid] = tgeom
                    for tfid in chosen_ids:
                        tg = cached_map.get(tfid)
                        if tg is not None and not tg.isNull() and not tg.isEmpty():
                            yield tfid, tg
                    return
                chunk_size = 400
                for c_off in range(0, len(chosen_ids), chunk_size):
                    chunk_ids = chosen_ids[c_off : c_off + chunk_size]
                    geom_req = req_cls().setFilterFids(chunk_ids)
                    try:
                        geom_req.setSubsetOfAttributes([])
                    except Exception:
                        pass
                    for gf in layer.getFeatures(geom_req):
                        if gf.hasGeometry():
                            yield gf.id(), gf.geometry()

            total_g = max(1, len(chosen_ids))
            for gidx, (fid, raw_geom) in enumerate(_iter_selected_geoms()):
                now_ts = time.monotonic()
                need_tick = (now_ts - last_yield_ts) >= 0.018
                if cancel_check and (gidx % 15 == 0 or need_tick) and cancel_check():
                    out["cancelled"] = True
                    return out
                try:
                    geom = qgs_geom_cls(raw_geom)
                    if geom.isNull() or geom.isEmpty():
                        continue
                    try:
                        simp = geom.simplify(tol1_native)
                        if simp and not simp.isEmpty():
                            geom = simp
                    except Exception:
                        pass
                    if xform is not None:
                        geom.transform(xform)
                    gjson = json.loads(geom.asJson(precision=5))
                    fid_str = str(fid)
                    if include_lod1:
                        entry1 = _simplify_geojson_geometry(gjson, tolerance=tol1_deg, decimals=5)
                        if entry1 is not None:
                            packed_lod1[fid_str] = entry1

                    props_row = row_by_fid.get(fid)
                    props = dict(props_row) if props_row is not None else {"_feature_id": fid}
                    if include_lod0 and fid in lod0_id_set:
                        simp0 = _packed_to_geojson_geometry(
                            _simplify_geojson_geometry(gjson, tolerance=0.0008, decimals=5)
                        )
                        if simp0 is not None:
                            props0 = dict(props)
                            props0["fid"] = fid
                            props0["_pyramid_lod"] = 0
                            if layer_name and not props0.get("_layer_name"):
                                props0["_layer_name"] = layer_name
                            lod0_feats.append(
                                {
                                    "type": "Feature",
                                    "id": fid,
                                    "geometry": simp0,
                                    "properties": props0,
                                }
                            )
                    if len(init_feats) < initial_geojson_max:
                        init_feats.append(
                            {
                                "type": "Feature",
                                "id": fid,
                                "geometry": gjson,
                                "properties": props,
                            }
                        )
                except Exception:
                    continue
                if progress_cb and need_tick:
                    last_yield_ts = now_ts
                    progress_cb(68 + int(28 * (gidx + 1) / total_g), 100)

            if include_lod0 and lod0_feats:
                out["lod0"] = {"type": "FeatureCollection", "features": lod0_feats}
            if include_lod1 and packed_lod1:
                raw_b = json.dumps(packed_lod1, separators=(",", ":")).encode("utf-8")
                comp_b = gzip.compress(raw_b, compresslevel=6)
                out["lod1"] = {
                    "format": "qdash_vp1_gzip_b64",
                    "feature_count": len(packed_lod1),
                    "tolerance": tol1_deg,
                    "data_b64": base64.b64encode(comp_b).decode("ascii"),
                }
            if init_feats:
                out["initial_geojson"] = {"type": "FeatureCollection", "features": init_feats}

        if progress_cb:
            progress_cb(100, 100)
        return out

    @staticmethod
    def extract_geojson_from_qgis_layer(
        layer: Any,
        max_features: int = 1800,
        extent_rect: Optional[Any] = None,
        target_fids: Optional[List[Any]] = None,
        simplify_tolerance_deg: Optional[float] = None,
        prioritize_largest: bool = False,
        transform_context: Any = None,
        ellipsoid: str = "GRS80",
    ) -> Dict[str, Any]:
        """
        Convert features from an active QGIS QgsVectorLayer into a WGS84 (EPSG:4326)
        GeoJSON FeatureCollection so exported HTML maps always render true polygons/lines
        (not fallback centroid dots) even offline or on file:// URLs.
        Accepts an explicit *transform_context* so isolated read-only layers can run
        safely on background worker threads without calling QgsProject.instance().
        """
        empty_fc: Dict[str, Any] = {"type": "FeatureCollection", "features": []}
        if layer is None or not hasattr(layer, "getFeatures"):
            return empty_fc

        try:
            from qgis.core import (
                Qgis,
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsDistanceArea,
                QgsFeatureRequest,
                QgsGeometry,
                QgsProject,
                QgsWkbTypes,
            )
        except ImportError:
            return empty_fc

        proj = QgsProject.instance() if transform_context is None else None
        tctx = transform_context if transform_context is not None else proj.transformContext()
        eff_ellipsoid = ellipsoid or (proj.ellipsoid() if proj is not None else None) or "GRS80"
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        xform = None
        if layer.crs().isValid() and layer.crs() != wgs84:
            xform = QgsCoordinateTransform(layer.crs(), wgs84, tctx)

        from ..core.spatial_overlap import QgisCartesianAreaCalculator

        poly_geom_type = getattr(getattr(Qgis, "GeometryType", None), "Polygon", None)
        if poly_geom_type is None:
            poly_geom_type = QgsWkbTypes.PolygonGeometry
        area_calc = None
        if layer.geometryType() == poly_geom_type:
            area_calc = QgisCartesianAreaCalculator(
                layer.crs(), tctx, ellipsoid=eff_ellipsoid, layer=layer
            )

        eff_max_g = int(max_features or 0)
        req = QgsFeatureRequest()
        int_fids: List[int] = []
        if target_fids:
            for tfid in target_fids:
                try:
                    int_fids.append(int(tfid))
                except (TypeError, ValueError):
                    pass
        int_fid_set = set(int_fids) if int_fids else set()
        used_extent = False
        if extent_rect is not None and (not int_fids or (eff_max_g > 0 and len(int_fids) > eff_max_g)):
            req.setFilterRect(extent_rect)
            if not int_fids and (prioritize_largest or eff_max_g > 0):
                req.setLimit(25000 if prioritize_largest else eff_max_g)
            used_extent = True
        elif int_fids:
            req.setFilterFids(int_fids[:eff_max_g] if eff_max_g > 0 else int_fids)
        else:
            if extent_rect is not None:
                req.setFilterRect(extent_rect)
            if prioritize_largest or eff_max_g > 0:
                req.setLimit(25000 if prioritize_largest else eff_max_g)

        field_names = [f.name() for f in layer.fields()]
        features_out: List[Dict[str, Any]] = []
        is_geographic = layer.crs().isGeographic() if layer.crs().isValid() else False
        disable_simplify = (simplify_tolerance_deg is not None and float(simplify_tolerance_deg) <= 0.0)
        if not disable_simplify and simplify_tolerance_deg is not None and simplify_tolerance_deg > 0:
            simplify_tol = (
                float(simplify_tolerance_deg)
                if is_geographic
                else float(simplify_tolerance_deg) * 111000.0
            )
            force_simplify = True
        else:
            simplify_tol = 0.00008 if is_geographic else 8.0
            force_simplify = False

        if used_extent and int_fid_set:
            feat_list = []
            max_scan = 25000 if prioritize_largest else eff_max_g
            for ft in layer.getFeatures(req):
                if ft.id() in int_fid_set:
                    feat_list.append(ft)
                    if max_scan > 0 and len(feat_list) >= max_scan:
                        break
        else:
            feat_list = list(layer.getFeatures(req))
        if used_extent and not feat_list and int_fids:
            fallback_req = QgsFeatureRequest()
            fallback_req.setFilterFids(int_fids[:eff_max_g] if eff_max_g > 0 else int_fids)
            feat_list = list(layer.getFeatures(fallback_req))

        if prioritize_largest and eff_max_g > 0 and len(feat_list) > eff_max_g:
            def _bbox_area_score(ft: Any) -> float:
                try:
                    if ft.hasGeometry():
                        bb = ft.geometry().boundingBox()
                        return float(bb.width() * bb.height())
                except Exception:
                    pass
                return 0.0
            feat_list.sort(key=_bbox_area_score, reverse=True)
            feat_list = feat_list[:eff_max_g]

        for idx, feat in enumerate(feat_list):
            if eff_max_g > 0 and idx >= eff_max_g:
                break
            if not feat.hasGeometry():
                continue
            geom = QgsGeometry(feat.geometry())
            if geom.isNull() or geom.isEmpty():
                continue

            props: Dict[str, Any] = {"_feature_id": feat.id()}
            for fn in field_names:
                val = feat[fn]
                if hasattr(val, "isNull") and val.isNull():
                    props[fn] = None
                elif hasattr(val, "toString") and not isinstance(val, (str, int, float, bool)):
                    props[fn] = val.toString("yyyy-MM-dd") if hasattr(val, "year") else val.toString()
                else:
                    props[fn] = val

            try:
                if area_calc is not None:
                    aha = area_calc.measure_ha(geom, decimals=4)
                    props["_geom_area_ha"] = aha
                    if props.get("area_ha") is None:
                        props["area_ha"] = aha

                # Lightly simplify huge coastline/cadastral polygons or zoomed-out LOD requests,
                # unless LOD-3 Full Detail (`simplify_tolerance_deg <= 0`) was explicitly requested.
                if not disable_simplify:
                    try:
                        if force_simplify or len(geom.asWkb()) > 3072:
                            simp = geom.simplify(simplify_tol)
                            if simp and not simp.isEmpty():
                                geom = simp
                    except Exception:
                        pass

                if xform is not None:
                    geom.transform(xform)
                geom_json = json.loads(geom.asJson(precision=6))
                cen = geom.centroid().asPoint()
                props["_lon"] = round(float(cen.x()), 6)
                props["_lat"] = round(float(cen.y()), 6)
                bb_wgs = geom.boundingBox()
                if not bb_wgs.isEmpty() and (bb_wgs.width() > 0 or bb_wgs.height() > 0):
                    props["_bbox"] = [
                        round(float(bb_wgs.xMinimum()), 5),
                        round(float(bb_wgs.yMinimum()), 5),
                        round(float(bb_wgs.xMaximum()), 5),
                        round(float(bb_wgs.yMaximum()), 5),
                    ]
            except Exception:
                continue

            features_out.append(
                {
                    "type": "Feature",
                    "id": feat.id(),
                    "properties": props,
                    "geometry": geom_json,
                }
            )

        if features_out:
            from ..core.spatial_overlap import QgisCartesianAreaCalculator, enrich_records_domain_fields

            all_props = [f["properties"] for f in features_out]
            enrich_records_domain_fields(all_props)
            for f_obj, p_obj in zip(features_out, all_props):
                f_obj["properties"] = p_obj

        return {"type": "FeatureCollection", "features": features_out}

    @staticmethod
    def sort_layers_automatically(
        layer_names: List[str],
        layer_stats: Optional[Dict[str, Any]] = None,
        layer_records: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        layer_geom_types: Optional[Dict[str, str]] = None,
    ) -> List[str]:
        """
        Order map layers automatically for optimal map readability (#7):
        - First by geometry hierarchy: Point (0) < Line (1) < Polygon (2)
        - Then by ascending feature count (fewer features sit on top of denser layers).
        Note: index 0 = top-most layer drawn last on canvas.
        """
        seen: set = set()
        unique_names: List[str] = []
        for ln in layer_names or []:
            if ln and ln not in seen:
                seen.add(ln)
                unique_names.append(ln)

        stats = layer_stats or {}
        records_map = layer_records or {}
        geom_map = layer_geom_types or {}

        def _geom_rank(name: str) -> int:
            g = str(geom_map.get(name, "")).lower()
            if not g and isinstance(stats.get(name), dict):
                g = str(stats[name].get("geometry_type", "")).lower()
            if not g and records_map.get(name):
                first = records_map[name][0]
                if isinstance(first, dict):
                    g = str(first.get("_geom_type", "")).lower()
                    if not g and isinstance(first.get("__geom__"), dict):
                        g = str(first["__geom__"].get("type", "")).lower()
            if "point" in g:
                return 0
            if "line" in g:
                return 1
            if "poly" in g:
                return 2
            # Guess by typical layer keywords if metadata is missing
            low = name.lower()
            if any(k in low for k in ("punkt", "point", "vaatlus", "leiukoht")):
                return 0
            if any(k in low for k in ("joon", "line", "tee", "jõgi", "kraav")):
                return 1
            return 2

        def _feat_count(name: str) -> int:
            st = stats.get(name)
            if isinstance(st, dict):
                for key in ("feature_count", "count", "total"):
                    if key in st and st[key] is not None:
                        try:
                            return int(st[key])
                        except (TypeError, ValueError):
                            pass
            recs = records_map.get(name)
            if isinstance(recs, list):
                return len(recs)
            return 10**9

        return sorted(
            unique_names,
            key=lambda n: (_geom_rank(n), _feat_count(n), n.lower()),
        )
