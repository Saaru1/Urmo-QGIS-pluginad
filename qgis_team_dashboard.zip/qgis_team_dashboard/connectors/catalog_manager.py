# -*- coding: utf-8 -*-
"""
Persistent Local Data Catalog Manager for QGIS Team Dashboard.

Design goals (solving QGIS startup lag while giving rich WFS/WMS discovery):
1. Creates & reads a fast local JSON catalog cache (~/.qgis_team_dashboard/ogc_catalog_cache.json)
   on first launch with pre-seeded Estonian public conservation & cadastral services
   (EELIS, PRIA Pärandniidud, Maa-amet Kataster/ETAK, Maa-amet WMS basemaps).
2. Opens the dock instantaneously (< 5 ms) on startup without querying WFS features into memory.
3. Refreshes service GetCapabilities asynchronously on a background thread (only on first run
   when a server has never been indexed, when cache TTL > 24h, or when user clicks Refresh).
"""

import json
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional

from .ogc_connector import OgcConnector


DEFAULT_CATALOG_SERVERS: List[Dict[str, Any]] = [
    {
        "name": "EELIS (Avalik / Keskkonnaagentuur)",
        "service_type": "wfs",
        "url": "https://gsavalik.envir.ee/geoserver/eelis/ows",
        "crs": "EPSG:3301",
        "authcfg": "",
        "layers": [
            {"name": "eelis:natura_elupaik", "title": "Natura 2000 elupaigad", "crs": "EPSG:3301", "service_type": "wfs"},
            {"name": "eelis:kr_kaitseala", "title": "KKR Kaitsealad", "crs": "EPSG:3301", "service_type": "wfs"},
            {"name": "eelis:plk", "title": "EELIS Poollooduslikud kooslused", "crs": "EPSG:3301", "service_type": "wfs"},
            {"name": "eelis:kr_loodusala", "title": "Natura 2000 loodusalad", "crs": "EPSG:3301", "service_type": "wfs"},
            {"name": "eelis:kr_hoiuala", "title": "Hoiualad", "crs": "EPSG:3301", "service_type": "wfs"},
            {"name": "eelis:kr_hooldatav_skv", "title": "Püsielupaigad (hooldatavad)", "crs": "EPSG:3301", "service_type": "wfs"},
            {"name": "eelis:kr_vep", "title": "Vääriselupaigad (VEP)", "crs": "EPSG:3301", "service_type": "wfs"},
        ],
    },
    {
        "name": "PRIA Pärandniidud (Avalik)",
        "service_type": "wfs",
        "url": "https://kls.pria.ee/geoserver/pria_avalik/wfs",
        "crs": "EPSG:3301",
        "authcfg": "",
        "layers": [
            {"name": "pria_avalik:pria_plk", "title": "PRIA Pärandniidud", "crs": "EPSG:3301", "service_type": "wfs"},
        ],
    },
    {
        "name": "Maa- ja Ruumiamet Kataster",
        "service_type": "wfs",
        "url": "https://gsavalik.envir.ee/geoserver/kataster/wfs",
        "crs": "EPSG:3301",
        "authcfg": "",
        "layers": [
            {"name": "kataster:ky_kehtiv", "title": "Kehtivad katastriüksused", "crs": "EPSG:3301", "service_type": "wfs"},
        ],
    },
    {
        "name": "Maa- ja Ruumiamet Aluskaardid (WMS, EPSG:3301)",
        "service_type": "wms",
        "url": "https://kaart.maaamet.ee/wms/hallkaart",
        "crs": "EPSG:3301",
        "authcfg": "",
        "is_basemap": True,
        "layers": [
            {
                "name": "MA-HALLKAART",
                "title": "Maa- ja Ruumiamet Hallkaart",
                "crs": "EPSG:3301",
                "service_type": "wms",
                "url": "https://kaart.maaamet.ee/wms/hallkaart",
                "format": "image/png",
                "is_basemap": True,
                "category": "Aluskaart",
            },
            {
                "name": "MA-KAART",
                "title": "Maa- ja Ruumiamet Põhikaart",
                "crs": "EPSG:3301",
                "service_type": "wms",
                "url": "https://kaart.maaamet.ee/wms/kaart",
                "format": "image/png",
                "is_basemap": True,
                "category": "Aluskaart",
            },
            {
                "name": "EESTIFOTO",
                "title": "Maa- ja Ruumiamet Ortofoto (EESTIFOTO)",
                "crs": "EPSG:3301",
                "service_type": "wms",
                "url": "https://kaart.maaamet.ee/wms/fotokaart",
                "format": "image/jpeg",
                "notes": "crs=EPSG:3301&dpiMode=7&featureCount=10&format=image/jpeg&layers=EESTIFOTO&styles&url=https://kaart.maaamet.ee/wms/fotokaart",
                "is_basemap": True,
                "category": "Aluskaart",
            },
            {
                "name": "HYBRID",
                "title": "Maa- ja Ruumiamet Hübriidkaart (Orto + Hübriid)",
                "crs": "EPSG:3301",
                "service_type": "wms",
                "url": "https://kaart.maaamet.ee/wms/fotokaart",
                "format": "image/jpeg",
                "is_basemap": True,
                "category": "Aluskaart",
            },
        ],
    },
]


class LocalCatalogManager:
    """Manages persistent cached OGC service layer indexes with asynchronous background updates."""

    CACHE_TTL_SECONDS = 86400  # 24 hours

    def __init__(self, cache_path: Optional[str] = None) -> None:
        if cache_path:
            self.cache_path = cache_path
        else:
            base_dir = os.path.join(os.path.expanduser("~"), ".qgis_team_dashboard")
            self.cache_path = os.path.join(base_dir, "ogc_catalog_cache.json")
        self._lock = threading.Lock()
        self.catalog: Dict[str, Any] = self.load_or_initialize()

    @staticmethod
    def _migrate_wms_basemap_block(data: Dict[str, Any]) -> bool:
        """Migrate cached Maa-amet WMS basemap block (#8: keep Hallkaart, Põhikaart, Ortofoto EESTIFOTO, Hybrid; remove CIR)."""
        changed = False
        default_wms = next(
            (s for s in DEFAULT_CATALOG_SERVERS if s.get("service_type") == "wms"),
            None,
        )
        if not default_wms:
            return False
        canonical_layers = [dict(lyr) for lyr in default_wms.get("layers", [])]
        for srv in data.get("servers", []):
            if srv.get("service_type") != "wms":
                continue
            name_low = str(srv.get("name", "")).lower()
            layers = srv.get("layers", [])
            has_ma_layers = any(
                str(l.get("name", "")) in {"MA-HALLKAART", "MA-FOTOKAART", "MA-KAART", "cir_ngr", "EESTIFOTO", "HYBRID"}
                for l in layers
                if isinstance(l, dict)
            )
            if "maa" in name_low or "aluskaart" in name_low or has_ma_layers:
                if [l.get("name") for l in layers if isinstance(l, dict)] != [l["name"] for l in canonical_layers]:
                    srv["layers"] = canonical_layers
                    changed = True
                else:
                    # Ensure EESTIFOTO uses image/jpeg and updated notes
                    for lyr in layers:
                        if isinstance(lyr, dict) and lyr.get("name") == "EESTIFOTO" and lyr.get("format") != "image/jpeg":
                            lyr["format"] = "image/jpeg"
                            lyr["url"] = "https://kaart.maaamet.ee/wms/fotokaart"
                            changed = True
        return changed

    def load_or_initialize(self) -> Dict[str, Any]:
        """Load cached catalog immediately from disk, or create seeded file on first run."""
        if os.path.isfile(self.cache_path):
            try:
                with open(self.cache_path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if isinstance(data, dict) and isinstance(data.get("servers"), list):
                    if self._migrate_wms_basemap_block(data):
                        self._write_cache(data)
                    return data
            except Exception:
                pass

        seeded = {
            "version": 1,
            "servers": [
                {
                    "name": s["name"],
                    "service_type": s["service_type"],
                    "url": s["url"],
                    "crs": s.get("crs", "EPSG:3301"),
                    "authcfg": s.get("authcfg", ""),
                    "is_basemap": bool(s.get("is_basemap", False)),
                    "last_fetched": 0.0,
                    "error": "",
                    "layers": list(s.get("layers", [])),
                }
                for s in DEFAULT_CATALOG_SERVERS
            ],
        }
        self._write_cache(seeded)
        return seeded

    def _write_cache(self, data: Dict[str, Any]) -> None:
        with self._lock:
            os.makedirs(os.path.dirname(os.path.abspath(self.cache_path)), exist_ok=True)
            with open(self.cache_path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)

    def save(self) -> None:
        self._write_cache(self.catalog)

    def get_servers(self) -> List[Dict[str, Any]]:
        return list(self.catalog.get("servers", []))

    def total_cached_layers(self) -> int:
        return sum(len(s.get("layers", [])) for s in self.get_servers())

    def stale_servers(self, ttl_seconds: Optional[int] = None) -> List[Dict[str, Any]]:
        ttl = self.CACHE_TTL_SECONDS if ttl_seconds is None else ttl_seconds
        now = time.time()
        stale: List[Dict[str, Any]] = []
        for s in self.get_servers():
            # Pre-populated Maa-amet WMS basemap group uses hardcoded verified URLs per layer
            if s.get("service_type") == "wms" and any(
                "url" in lyr for lyr in s.get("layers", [])
            ):
                continue
            last_t = float(s.get("last_fetched") or 0.0)
            if last_t <= 0 or (now - last_t) > ttl:
                stale.append(s)
        return stale

    def add_or_update_server(
        self,
        name: str,
        url: str,
        service_type: str = "wfs",
        crs: str = "EPSG:3301",
        authcfg: str = "",
        is_basemap: bool = False,
    ) -> Dict[str, Any]:
        clean_url = url.strip()
        clean_name = name.strip() or clean_url
        servers = self.catalog.setdefault("servers", [])
        for srv in servers:
            if srv.get("name") == clean_name or srv.get("url") == clean_url:
                srv["name"] = clean_name
                srv["url"] = clean_url
                srv["service_type"] = service_type
                srv["crs"] = crs
                srv["authcfg"] = authcfg
                srv["is_basemap"] = is_basemap
                srv["last_fetched"] = 0.0
                self.save()
                return srv

        entry: Dict[str, Any] = {
            "name": clean_name,
            "service_type": service_type,
            "url": clean_url,
            "crs": crs,
            "authcfg": authcfg,
            "is_basemap": is_basemap,
            "last_fetched": 0.0,
            "error": "",
            "layers": [],
        }
        servers.append(entry)
        self.save()
        return entry

    def remove_server(self, name: str) -> None:
        self.catalog["servers"] = [
            s for s in self.get_servers() if s.get("name") != name
        ]
        self.save()

    def refresh_server_sync(self, server_name: str, timeout: int = 12) -> Dict[str, Any]:
        """Synchronously fetch GetCapabilities for one server and persist to cache."""
        target = next((s for s in self.get_servers() if s.get("name") == server_name), None)
        if target is None:
            return {"name": server_name, "error": "Server not found", "layers": []}

        # Keep multi-endpoint Maa-amet basemaps intact without overwriting their per-layer URLs
        if target.get("service_type") == "wms" and any(
            "url" in lyr for lyr in target.get("layers", [])
        ):
            target["last_fetched"] = time.time()
            target["error"] = ""
            self.save()
            return target

        try:
            layers = OgcConnector.discover_layers(
                target["url"],
                service_type=target.get("service_type", "wfs"),
                timeout=timeout,
            )
            if layers:
                target["layers"] = layers
            target["last_fetched"] = time.time()
            target["error"] = ""
        except Exception as exc:
            target["error"] = str(exc)
        self.save()
        return target

    def refresh_async(
        self,
        server_names: Optional[List[str]] = None,
        on_server_updated: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_all_finished: Optional[Callable[[], None]] = None,
    ) -> threading.Thread:
        """
        Refresh specified (or stale) catalog servers in a background daemon thread
        so QGIS Desktop UI never freezes during initialization.
        """
        if server_names is None:
            targets = [s["name"] for s in self.stale_servers()]
        else:
            targets = list(server_names)

        def _worker() -> None:
            for srv_name in targets:
                updated = self.refresh_server_sync(srv_name)
                if on_server_updated:
                    try:
                        on_server_updated(updated)
                    except Exception:
                        pass
            if on_all_finished:
                try:
                    on_all_finished()
                except Exception:
                    pass

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
        return thread
