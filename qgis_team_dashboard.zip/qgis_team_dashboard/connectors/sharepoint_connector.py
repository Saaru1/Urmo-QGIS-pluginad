# -*- coding: utf-8 -*-
"""
Dual-Mode SharePoint Connector for QGIS Team Dashboard:
1. Local OneDrive/SharePoint Sync Folder Catalog (portable across team members via PortablePathResolver).
2. Microsoft Graph API Client (via msal + requests) for remote SharePoint Lists,
   cloud Excel workbook retrieval, and direct HTML/template publishing.
"""

import glob
import json
import os
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from ..core.schema import DashboardConfig, DataSourceConfig, SharePointCatalogConfig
from .path_resolver import PortablePathResolver


class SharePointConnector:
    """Manages SharePoint template catalogs, SharePoint Lists, and remote Excel files."""

    GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"

    def __init__(self, catalog_config: Optional[SharePointCatalogConfig] = None) -> None:
        self.catalog = catalog_config or SharePointCatalogConfig()
        self._access_token: Optional[str] = None

    def resolve_catalog_dir(self, project_dir: Optional[str] = None) -> str:
        """Resolve the team's local synced SharePoint catalog directory."""
        folder = self.catalog.local_sync_folder or "${ONEDRIVE_COMMERCIAL}/GIS_Dashboards"
        return PortablePathResolver.resolve(folder, project_dir=project_dir)

    def list_local_templates(
        self, project_dir: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """
        Scan the synced SharePoint folder for shared .qdash.json dashboard templates.
        Returns a list of dicts with 'name', 'title', 'author', 'path', 'portable_path'.
        """
        cat_dir = self.resolve_catalog_dir(project_dir=project_dir)
        if not os.path.isdir(cat_dir):
            return []

        results: List[Dict[str, str]] = []
        pattern = os.path.join(cat_dir, "*.qdash.json")
        for path in sorted(glob.glob(pattern)):
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                results.append(
                    {
                        "name": os.path.basename(path),
                        "title": data.get("title", os.path.basename(path)),
                        "subtitle": data.get("subtitle", ""),
                        "author": data.get("author", "GIS Team"),
                        "version": data.get("version", "1.0.0"),
                        "path": path,
                        "portable_path": PortablePathResolver.tokenize(
                            path, project_dir=project_dir
                        ),
                    }
                )
            except Exception:
                continue
        return results

    def save_template_to_catalog(
        self,
        dashboard: DashboardConfig,
        filename: Optional[str] = None,
        project_dir: Optional[str] = None,
    ) -> str:
        """Save a portable .qdash.json dashboard template into the synced SharePoint catalog."""
        cat_dir = self.resolve_catalog_dir(project_dir=project_dir)
        os.makedirs(cat_dir, exist_ok=True)

        if not filename:
            safe_slug = "".join(
                c if c.isalnum() or c in ("-", "_") else "_"
                for c in dashboard.title.lower()
            ).strip("_")
            filename = f"{safe_slug or 'dashboard'}.qdash.json"
        elif not filename.endswith(".qdash.json"):
            filename = f"{filename}.qdash.json"

        target_path = os.path.join(cat_dir, filename)
        with open(target_path, "w", encoding="utf-8") as fh:
            fh.write(dashboard.to_json(indent=2))
        return target_path

    @staticmethod
    def load_template_from_file(file_path: str, project_dir: Optional[str] = None) -> DashboardConfig:
        """Load a .qdash.json template from disk (resolving portable paths if needed)."""
        resolved = PortablePathResolver.resolve(file_path, project_dir=project_dir)
        with open(resolved, "r", encoding="utf-8") as fh:
            return DashboardConfig.from_json(fh.read())

    # ------------------------------------------------------------------
    # Microsoft Graph API (Entra ID / OAuth2) methods
    # ------------------------------------------------------------------

    def acquire_graph_token(
        self,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        scopes: Optional[List[str]] = None,
    ) -> str:
        """
        Acquire an OAuth2 Bearer token for Microsoft Graph using MSAL.
        Supports environment override (MS_GRAPH_ACCESS_TOKEN), ConfidentialClient, or Interactive Browser SSO.
        """
        env_token = os.environ.get("MS_GRAPH_ACCESS_TOKEN")
        if env_token:
            self._access_token = env_token
            return env_token

        t_id = tenant_id or self.catalog.tenant_id or "common"
        c_id = client_id or self.catalog.client_id
        if not c_id:
            raise ValueError(
                "Entra ID (Azure AD) Client ID is required for Microsoft Graph API authentication."
            )

        import msal

        authority = f"https://login.microsoftonline.com/{t_id}"
        target_scopes = scopes or ["https://graph.microsoft.com/.default"]

        if client_secret:
            app = msal.ConfidentialClientApplication(
                c_id, authority=authority, client_credential=client_secret
            )
            result = app.acquire_token_for_client(scopes=target_scopes)
        else:
            app = msal.PublicClientApplication(c_id, authority=authority)
            accounts = app.get_accounts()
            result = None
            if accounts:
                result = app.acquire_token_silent(target_scopes, account=accounts[0])
            if not result:
                result = app.acquire_token_interactive(scopes=target_scopes)

        if result and "access_token" in result:
            self._access_token = result["access_token"]
            return self._access_token

        err_desc = (result or {}).get("error_description", "Unknown MSAL error")
        raise RuntimeError(f"Failed to acquire Microsoft Graph token: {err_desc}")

    def fetch_sharepoint_list_records(
        self, ds_config: DataSourceConfig
    ) -> List[Dict[str, Any]]:
        """
        Fetch items from a SharePoint List via Microsoft Graph API:
        GET /sites/{site_id}/lists/{list_id}/items?expand=fields
        """
        import requests

        token = self._access_token or self.acquire_graph_token(
            tenant_id=ds_config.tenant_id, client_id=ds_config.client_id
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }
        site_id = ds_config.sharepoint_site_url.strip("/")
        list_id = ds_config.sharepoint_drive_or_list.strip("/")
        url = f"{self.GRAPH_BASE_URL}/sites/{site_id}/lists/{list_id}/items?expand=fields&$top=5000"

        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        payload = resp.json()

        records: List[Dict[str, Any]] = []
        for item in payload.get("value", []):
            fields = dict(item.get("fields", {}))
            fields.setdefault("id", item.get("id"))
            records.append(fields)
        return records

    def download_remote_excel_to_cache(
        self, ds_config: DataSourceConfig
    ) -> str:
        """
        Download a remote Excel workbook from SharePoint via Microsoft Graph API
        into a local temporary cache file for read-only ingestion.
        """
        import requests

        token = self._access_token or self.acquire_graph_token(
            tenant_id=ds_config.tenant_id, client_id=ds_config.client_id
        )
        headers = {"Authorization": f"Bearer {token}"}
        site_id = ds_config.sharepoint_site_url.strip("/")
        item_path = ds_config.sharepoint_item_path.lstrip("/")
        url = f"{self.GRAPH_BASE_URL}/sites/{site_id}/drive/root:/{item_path}:/content"

        resp = requests.get(url, headers=headers, timeout=60)
        resp.raise_for_status()

        cache_dir = os.path.join(tempfile.gettempdir(), "qgis_team_dashboard_cache")
        os.makedirs(cache_dir, exist_ok=True)
        local_name = os.path.basename(item_path) or f"{ds_config.id}.xlsx"
        local_path = os.path.join(cache_dir, local_name)
        with open(local_path, "wb") as fh:
            fh.write(resp.content)
        return local_path

    def upload_file_to_sharepoint_graph(
        self,
        local_file_path: str,
        remote_relative_path: str,
        site_id: Optional[str] = None,
    ) -> Tuple[bool, str]:
        """
        Upload a .qdash.json template or exported .html dashboard directly to a
        SharePoint Document Library via Microsoft Graph PUT.
        """
        import requests

        token = self._access_token or self.acquire_graph_token()
        target_site = (site_id or self.catalog.site_url).strip("/")
        clean_remote = remote_relative_path.lstrip("/")
        url = f"{self.GRAPH_BASE_URL}/sites/{target_site}/drive/root:/{clean_remote}:/content"

        with open(local_file_path, "rb") as fh:
            content = fh.read()

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/octet-stream",
        }
        resp = requests.put(url, headers=headers, data=content, timeout=60)
        if resp.status_code in (200, 201):
            web_url = resp.json().get("webUrl", url)
            return True, web_url
        return False, f"Graph API upload failed ({resp.status_code}): {resp.text}"
