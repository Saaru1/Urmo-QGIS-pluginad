# -*- coding: utf-8 -*-
"""
Vector Pyramids & Summary Statistics for Large Polygon/Vector Layers (~90k+ features).

Provides two complementary acceleration layers without external native dependencies:
1. Summary Statistics (`compute_layer_statistics`):
   Fast single-pass counts, WGS84 bounding box, total hectares, and per-field
   distinct/numeric statistics cached per layer.
2. Multi-Resolution Vector Geometry Pyramids (`build_lod0_grid_pyramid` +
   `build_lod1_compressed_pyramid_*` / `extract_lod1_pyramid_from_qgis_layer`):
   - LOD 0 (zoomed out): Spatial grid summary polygons carrying feature counts,
     hectares, and dominant classification attributes for 60 FPS overview rendering.
   - LOD 1 (medium/detail zoom & offline filter fallback): Iterative
     Ramer-Douglas-Peucker simplified & 4-decimal quantized geometries indexed by
     feature ID and WGS84 bbox, gzip-compressed for compact transfer and
     client-side `DecompressionStream('gzip')` unpacking.
3. QGIS C++ simplification hint (`apply_qgis_simplify_hint`) for large layers
   rendered inside Design Mode `QgsMapCanvas`.
"""

import base64
from collections import Counter, defaultdict
import gzip
import json
import math
import time
from typing import Any, Callable, Dict, List, Optional, Tuple


_CLASS_FIELDS = (
    "pohityyp",
    "esinduslik",
    "parandniidu_tyyp",
    "koosluse_grupp",
    "kaitstav_ala",
    "tuup",
    "tyyp",
    "sihtkohasus",
)

_AREA_KEYS = ("_geom_area_ha", "area_ha", "pindala_ha", "natura_overlap_ha", "pria_overlap_ha")


def _safe_float(val: Any) -> Optional[float]:
    if val is None or isinstance(val, bool) or val == "":
        return None
    try:
        num = float(val)
        return num if math.isfinite(num) else None
    except (TypeError, ValueError):
        return None


def _record_area_ha(row: Dict[str, Any]) -> float:
    for key in _AREA_KEYS:
        num = _safe_float(row.get(key))
        if num is not None:
            return num
    for key in ("pindala", "shape_area"):
        num = _safe_float(row.get(key))
        if num is not None:
            return num / 10000.0 if num > 500.0 else num
    return 0.0


def compute_layer_statistics(
    records: List[Dict[str, Any]],
    layer_name: str = "",
    geom_type: str = "",
) -> Dict[str, Any]:
    """Compute feature count, WGS84 extent, total area (ha), and field summaries."""
    min_x = min_y = float("inf")
    max_x = max_y = float("-inf")
    total_ha = 0.0
    inferred_geom = geom_type

    field_keys: List[str] = []
    if records:
        field_keys = [
            k for k in records[0].keys() if not str(k).startswith("_")
        ][:30]

    non_null: Dict[str, int] = defaultdict(int)
    cat_counts: Dict[str, Counter] = {k: Counter() for k in field_keys}
    num_stats: Dict[str, List[float]] = {}  # [count, sum, min, max]

    for row in records:
        if not isinstance(row, dict):
            continue
        if not inferred_geom and row.get("_geom_area_ha") is not None:
            inferred_geom = "Polygon"

        lat = _safe_float(row.get("_lat"))
        lon = _safe_float(row.get("_lon"))
        if lat is not None and lon is not None:
            if lon < min_x:
                min_x = lon
            if lon > max_x:
                max_x = lon
            if lat < min_y:
                min_y = lat
            if lat > max_y:
                max_y = lat

        total_ha += max(0.0, _record_area_ha(row))

        for fk in field_keys:
            val = row.get(fk)
            if val is None or val == "":
                continue
            non_null[fk] += 1
            num = _safe_float(val)
            if num is not None and not isinstance(val, str):
                st = num_stats.get(fk)
                if st is None:
                    num_stats[fk] = [1.0, num, num, num]
                else:
                    st[0] += 1.0
                    st[1] += num
                    if num < st[2]:
                        st[2] = num
                    if num > st[3]:
                        st[3] = num
            else:
                sval = str(val).strip()
                if sval and len(cat_counts[fk]) < 5000:
                    cat_counts[fk][sval] += 1

    bbox_wgs84 = None
    if math.isfinite(min_x) and math.isfinite(min_y):
        bbox_wgs84 = [round(min_x, 5), round(min_y, 5), round(max_x, 5), round(max_y, 5)]

    fields_summary: Dict[str, Any] = {}
    for fk in field_keys:
        entry: Dict[str, Any] = {
            "non_null": non_null.get(fk, 0),
        }
        cnt = cat_counts.get(fk)
        if cnt:
            entry["distinct_count"] = len(cnt)
            entry["top_values"] = [[k, c] for k, c in cnt.most_common(8)]
        ns = num_stats.get(fk)
        if ns and ns[0] > 0:
            entry["min"] = round(ns[2], 3)
            entry["max"] = round(ns[3], 3)
            entry["sum"] = round(ns[1], 2)
            entry["mean"] = round(ns[1] / ns[0], 3)
        fields_summary[fk] = entry

    return {
        "layer_name": layer_name,
        "feature_count": len(records),
        "geom_type": inferred_geom or "Unknown",
        "bbox_wgs84": bbox_wgs84,
        "total_area_ha": round(total_ha, 2),
        "fields": fields_summary,
    }


def _perp_dist(pt: List[float], a: List[float], b: List[float]) -> float:
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    if dx == 0.0 and dy == 0.0:
        return math.hypot(pt[0] - a[0], pt[1] - a[1])
    t = ((pt[0] - a[0]) * dx + (pt[1] - a[1]) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    proj_x = a[0] + t * dx
    proj_y = a[1] + t * dy
    return math.hypot(pt[0] - proj_x, pt[1] - proj_y)


def rdp_simplify_ring(
    coords: List[List[float]],
    tolerance: float = 0.0004,
    closed: bool = True,
    decimals: int = 4,
) -> List[List[float]]:
    """Iterative Ramer-Douglas-Peucker simplification with quantization and ring closure."""
    if not coords or len(coords) <= 3:
        return [[round(float(p[0]), decimals), round(float(p[1]), decimals)] for p in coords if len(p) >= 2]

    pts = [[float(p[0]), float(p[1])] for p in coords if len(p) >= 2]
    if len(pts) <= 3:
        return [[round(p[0], decimals), round(p[1], decimals)] for p in pts]

    n = len(pts)
    keep = [False] * n
    keep[0] = True
    keep[-1] = True
    stack = [(0, n - 1)]

    while stack:
        start, end = stack.pop()
        if end - start <= 1:
            continue
        max_d = -1.0
        max_idx = -1
        a = pts[start]
        b = pts[end]
        for idx in range(start + 1, end):
            d = _perp_dist(pts[idx], a, b)
            if d > max_d:
                max_d = d
                max_idx = idx
        if max_d > tolerance and max_idx > start:
            keep[max_idx] = True
            stack.append((start, max_idx))
            stack.append((max_idx, end))

    out = [[round(pts[i][0], decimals), round(pts[i][1], decimals)] for i in range(n) if keep[i]]

    # Deduplicate consecutive identical vertices after rounding
    dedup: List[List[float]] = []
    for p in out:
        if not dedup or p[0] != dedup[-1][0] or p[1] != dedup[-1][1]:
            dedup.append(p)

    if closed:
        if len(dedup) < 4:
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            minx, maxx = round(min(xs), decimals), round(max(xs), decimals)
            miny, maxy = round(min(ys), decimals), round(max(ys), decimals)
            pad = max(10 ** (-decimals), 0.0001)
            if maxx - minx < pad:
                maxx = round(minx + pad, decimals)
            if maxy - miny < pad:
                maxy = round(miny + pad, decimals)
            return [[minx, miny], [maxx, miny], [maxx, maxy], [minx, maxy], [minx, miny]]
        if dedup[0] != dedup[-1]:
            dedup.append([dedup[0][0], dedup[0][1]])
    return dedup


def _bbox_of_rings(rings_nested: Any) -> Optional[List[float]]:
    minx = miny = float("inf")
    maxx = maxy = float("-inf")

    def _scan(node: Any) -> None:
        nonlocal minx, miny, maxx, maxy
        if not isinstance(node, list) or not node:
            return
        if isinstance(node[0], (int, float)) and len(node) >= 2:
            x, y = float(node[0]), float(node[1])
            if x < minx:
                minx = x
            if x > maxx:
                maxx = x
            if y < miny:
                miny = y
            if y > maxy:
                maxy = y
        else:
            for item in node:
                _scan(item)

    _scan(rings_nested)
    if not math.isfinite(minx):
        return None
    return [round(minx, 4), round(miny, 4), round(maxx, 4), round(maxy, 4)]


def _simplify_geojson_geometry(
    geom: Dict[str, Any], tolerance: float = 0.0004, decimals: int = 4
) -> Optional[List[Any]]:
    """Return compact packed geometry tuple `[type_code, bbox4, simplified_coords]`."""
    if not geom or not isinstance(geom, dict):
        return None
    gtype = geom.get("type", "")
    coords = geom.get("coordinates")
    if not gtype or coords is None:
        return None

    if gtype == "Point" and len(coords) >= 2:
        p = [round(float(coords[0]), decimals), round(float(coords[1]), decimals)]
        return ["P", [p[0], p[1], p[0], p[1]], p]

    if gtype == "MultiPoint":
        pts = [[round(float(p[0]), decimals), round(float(p[1]), decimals)] for p in coords if len(p) >= 2]
        bb = _bbox_of_rings(pts)
        return ["MP", bb, pts] if bb and pts else None

    if gtype == "LineString":
        ln = rdp_simplify_ring(coords, tolerance=tolerance, closed=False, decimals=decimals)
        bb = _bbox_of_rings(ln)
        return ["L", bb, ln] if bb and len(ln) >= 2 else None

    if gtype == "MultiLineString":
        lines = [rdp_simplify_ring(l, tolerance=tolerance, closed=False, decimals=decimals) for l in coords]
        lines = [l for l in lines if len(l) >= 2]
        bb = _bbox_of_rings(lines)
        return ["ML", bb, lines] if bb and lines else None

    if gtype == "Polygon":
        if not coords:
            return None
        outer = rdp_simplify_ring(coords[0], tolerance=tolerance, closed=True, decimals=decimals)
        rings = [outer]
        for hole in coords[1:5]:
            hb = _bbox_of_rings(hole)
            if hb and (hb[2] - hb[0] >= tolerance or hb[3] - hb[1] >= tolerance):
                rings.append(rdp_simplify_ring(hole, tolerance=tolerance, closed=True, decimals=decimals))
        bb = _bbox_of_rings(rings)
        return ["G", bb, rings] if bb else None

    if gtype == "MultiPolygon":
        polys = []
        for poly in coords[:40]:
            if not poly:
                continue
            outer = rdp_simplify_ring(poly[0], tolerance=tolerance, closed=True, decimals=decimals)
            rings = [outer]
            for hole in poly[1:4]:
                hb = _bbox_of_rings(hole)
                if hb and (hb[2] - hb[0] >= tolerance or hb[3] - hb[1] >= tolerance):
                    rings.append(rdp_simplify_ring(hole, tolerance=tolerance, closed=True, decimals=decimals))
            polys.append(rings)
        bb = _bbox_of_rings(polys)
        return ["MG", bb, polys] if bb and polys else None

    return None


def build_lod0_grid_pyramid(
    records: List[Dict[str, Any]],
    layer_name: str = "",
    cell_deg: float = 0.025,
    max_cells: int = 2600,
) -> Dict[str, Any]:
    """
    Build a fast LOD-0 spatial grid pyramid FeatureCollection (< 2,200 cells) from
    point/centroid records so zoomed-out views across an entire country render at 60 FPS.
    """
    pts: List[Tuple[float, float, Dict[str, Any]]] = []
    min_x = min_y = float("inf")
    max_x = max_y = float("-inf")
    for row in records:
        if not isinstance(row, dict):
            continue
        lat = _safe_float(row.get("_lat"))
        lon = _safe_float(row.get("_lon"))
        if lat is None or lon is None:
            continue
        pts.append((lon, lat, row))
        if lon < min_x:
            min_x = lon
        if lon > max_x:
            max_x = lon
        if lat < min_y:
            min_y = lat
        if lat > max_y:
            max_y = lat

    if not pts:
        return {"type": "FeatureCollection", "features": []}

    step_lat = max(0.01, float(cell_deg))
    step_lon = max(0.01, step_lat * 1.65)  # ~square visual aspect at Estonian latitude (~58.5N)

    # Ensure total possible occupied cells fit under max_cells
    for _ in range(5):
        span_x = max(step_lon, max_x - min_x)
        span_y = max(step_lat, max_y - min_y)
        est_grid = (span_x / step_lon) * (span_y / step_lat)
        if est_grid <= max_cells * 3.5:
            break
        step_lat *= 1.4
        step_lon = step_lat * 1.65

    cells: Dict[Tuple[int, int], Dict[str, Any]] = {}
    for lon, lat, row in pts:
        gx = int(math.floor(lon / step_lon))
        gy = int(math.floor(lat / step_lat))
        key = (gx, gy)
        bucket = cells.get(key)
        if bucket is None:
            bucket = {
                "count": 0,
                "area_ha": 0.0,
                "sum_lon": 0.0,
                "sum_lat": 0.0,
                "classes": {cf: Counter() for cf in _CLASS_FIELDS},
            }
            cells[key] = bucket
        bucket["count"] += 1
        bucket["sum_lon"] += lon
        bucket["sum_lat"] += lat
        bucket["area_ha"] += max(0.0, _record_area_ha(row))
        for cf in _CLASS_FIELDS:
            v = row.get(cf)
            if v is not None and str(v).strip() != "":
                bucket["classes"][cf][str(v).strip()] += 1

    # If still > max_cells, keep highest-impact / largest-area cells
    items = list(cells.items())
    if len(items) > max_cells:
        items.sort(key=lambda kv: (kv[1]["area_ha"], kv[1]["count"]), reverse=True)
        items = items[:max_cells]

    features: List[Dict[str, Any]] = []
    for idx, ((gx, gy), b) in enumerate(items):
        cnt = max(1, b["count"])
        cx = round(b["sum_lon"] / cnt, 5)
        cy = round(b["sum_lat"] / cnt, 5)
        props: Dict[str, Any] = {
            "_pyramid_lod": 0,
            "_layer_name": layer_name,
            "count": b["count"],
            "area_ha": round(b["area_ha"], 1),
        }
        for cf, counter in b["classes"].items():
            if counter:
                props[cf] = counter.most_common(1)[0][0]
        features.append(
            {
                "type": "Feature",
                "id": f"lod0_{idx}",
                "properties": props,
                "geometry": {
                    "type": "Point",
                    "coordinates": [cx, cy],
                },
            }
        )

    return {"type": "FeatureCollection", "features": features}


def build_lod1_compressed_pyramid_from_geojson(
    features: List[Dict[str, Any]],
    tolerance: float = 0.00022,
    max_features: int = 95000,
) -> Optional[Dict[str, Any]]:
    """
    Compress GeoJSON geometries into an indexed, RDP-simplified LOD-1 lookup packed
    as base64-encoded gzip JSON for offline HTML export and instant fid/bbox decoding.
    """
    packed: Dict[str, List[Any]] = {}
    for idx, feat in enumerate(features):
        if idx >= max_features:
            break
        if not isinstance(feat, dict):
            continue
        props = feat.get("properties") or {}
        fid = feat.get("id")
        if fid is None:
            fid = props.get("_feature_id", idx)
        geom = feat.get("geometry")
        entry = _simplify_geojson_geometry(geom, tolerance=tolerance, decimals=5)
        if entry is not None:
            packed[str(fid)] = entry

    if not packed:
        return None
    raw = json.dumps(packed, separators=(",", ":")).encode("utf-8")
    comp = gzip.compress(raw, compresslevel=6)
    return {
        "format": "qdash_vp1_gzip_b64",
        "feature_count": len(packed),
        "tolerance": tolerance,
        "data_b64": base64.b64encode(comp).decode("ascii"),
    }


def build_qgis_fid_to_record_key_map(
    layer: Any,
    records: Optional[List[Dict[str, Any]]],
) -> Dict[int, str]:
    """
    Map QGIS vector layer integer `feat.id()` -> canonical cached record `_feature_id` string.
    Handles WFS/OGR layers where cached records use GML string IDs (`typename.0` vs QGIS 1-based FID `1`)
    by preferring unique shared key attributes (`sys_id`, `id`, `kr_kood`, etc.), then GML suffix/bbox checks.
    """
    if layer is None or not hasattr(layer, "getFeatures") or not records:
        return {}
    rec_by_fid_str: Dict[str, Dict[str, Any]] = {}
    rec_fids: List[str] = []
    for r in records:
        if not isinstance(r, dict):
            continue
        fid_v = r.get("_feature_id")
        if fid_v is None:
            continue
        fid_s = str(fid_v)
        rec_by_fid_str[fid_s] = r
        rec_fids.append(fid_s)
    if not rec_by_fid_str:
        return {}

    try:
        from qgis.core import QgsFeatureRequest
    except ImportError:
        return {}

    try:
        layer_field_names = [f.name() for f in layer.fields()]
    except Exception:
        layer_field_names = []
    layer_field_set = set(layer_field_names)

    # 1. Try matching by a unique shared attribute present in both records and QGIS layer fields
    sample_n = min(len(records), 400)
    sample_recs = [r for r in records[:sample_n] if isinstance(r, dict)]
    if layer_field_set and sample_recs:
        preferred = (
            "gml_id", "globalid", "sys_id", "ogc_fid", "fid", "id", "gid",
            "objectid", "kr_kood", "parandniidu_nr", "tunnus",
        )
        all_keys = [k for k in sample_recs[0].keys() if not str(k).startswith("_") and k in layer_field_set]
        cand_fields = [k for k in preferred if k in layer_field_set and k in sample_recs[0]]
        for k in all_keys:
            if k not in cand_fields:
                cand_fields.append(k)

        chosen_field = ""
        for fk in cand_fields:
            vals = [r.get(fk) for r in sample_recs]
            non_null = [str(v) for v in vals if v is not None and str(v) != ""]
            if len(non_null) == len(sample_recs) and len(set(non_null)) == len(sample_recs):
                # Also verify uniqueness across full record list
                full_vals = [str(r.get(fk)) for r in records if isinstance(r, dict) and r.get(fk) is not None and str(r.get(fk)) != ""]
                if len(full_vals) == len(rec_by_fid_str) and len(set(full_vals)) == len(full_vals):
                    chosen_field = fk
                    break

        if chosen_field:
            val_to_key: Dict[str, str] = {}
            for r in records:
                if not isinstance(r, dict):
                    continue
                kv = r.get(chosen_field)
                fv = r.get("_feature_id")
                if kv is not None and fv is not None:
                    val_to_key[str(kv)] = str(fv)
            try:
                fidx = layer_field_names.index(chosen_field)
                req = QgsFeatureRequest()
                req.setSubsetOfAttributes([fidx])
                if hasattr(QgsFeatureRequest, "NoGeometry"):
                    req.setFlags(QgsFeatureRequest.NoGeometry)
            except Exception:
                req = QgsFeatureRequest()
            attr_map: Dict[int, str] = {}
            try:
                for feat in layer.getFeatures(req):
                    kv = feat[chosen_field]
                    if kv is None:
                        continue
                    mapped = val_to_key.get(str(kv))
                    if mapped is not None:
                        attr_map[feat.id()] = mapped
            except Exception:
                attr_map = {}
            if len(attr_map) >= max(1, int(0.8 * min(len(rec_by_fid_str), len(records)))):
                return attr_map

    # 2. Direct stringified FID match or verified dot-suffix / offset match
    q_fids: List[int] = []
    req_ids = QgsFeatureRequest()
    try:
        req_ids.setSubsetOfAttributes([])
        if hasattr(QgsFeatureRequest, "NoGeometry"):
            req_ids.setFlags(QgsFeatureRequest.NoGeometry)
    except Exception:
        pass
    try:
        for feat in layer.getFeatures(req_ids):
            q_fids.append(feat.id())
    except Exception:
        return {}

    if not q_fids:
        return {}

    q_set = set(q_fids)
    # Direct match check
    direct_hits = sum(1 for k in rec_fids[:200] if k in rec_by_fid_str and (k.lstrip("-").isdigit() and int(k) in q_set))
    if direct_hits >= min(len(rec_fids), 20):
        return {int(k): k for k in rec_fids if k.lstrip("-").isdigit() and int(k) in q_set}

    # Check dot-suffix (`prefix.<int>`) with optional offset (e.g. 0-based WFS GML vs 1-based QGIS FID)
    suffix_to_key: Dict[int, str] = {}
    for k in rec_fids:
        if "." in k:
            tail = k.rsplit(".", 1)[-1]
            if tail.lstrip("-").isdigit():
                suffix_to_key[int(tail)] = k
    if len(suffix_to_key) >= max(1, int(0.8 * len(rec_fids))):
        # Probe first few QGIS features with geometry bbox if available to verify offset 0 vs +1
        direct_sfx_hits = sum(1 for qf in q_fids[:50] if qf in suffix_to_key)
        plus1_sfx_hits = sum(1 for qf in q_fids[:50] if (qf - 1) in suffix_to_key)
        if plus1_sfx_hits > direct_sfx_hits and 0 in suffix_to_key and 0 not in q_set:
            return {qf: suffix_to_key[qf - 1] for qf in q_fids if (qf - 1) in suffix_to_key}
        if direct_sfx_hits > 0:
            return {qf: suffix_to_key[qf] for qf in q_fids if qf in suffix_to_key}

    # 3. Positional fallback when layer and records share the same length
    if len(q_fids) == len(rec_fids):
        return {qf: rec_fids[idx] for idx, qf in enumerate(q_fids)}
    return {}


def extract_lod1_pyramid_from_qgis_layer(
    layer: Any,
    tolerance_deg: float = 0.00022,
    max_features: int = 6000,
    progress_cb: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
    priority_fids: Optional[List[int]] = None,
    fid_key_map: Optional[Dict[int, str]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Stream geometries from a live QGIS QgsVectorLayer, prioritize largest-area features
    across the entire extent if total count > max_features, simplify in C++ QGIS,
    transform to WGS84, quantize, and gzip-pack by feature ID.
    """
    if layer is None or not hasattr(layer, "getFeatures"):
        return None
    try:
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsFeatureRequest,
            QgsGeometry,
            QgsProject,
        )
    except ImportError:
        return None

    proj = QgsProject.instance()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    xform = None
    is_geo = False
    try:
        if layer.crs().isValid():
            is_geo = bool(layer.crs().isGeographic())
            if layer.crs() != wgs84:
                xform = QgsCoordinateTransform(layer.crs(), wgs84, proj)
    except Exception:
        pass

    tol_native = tolerance_deg if is_geo else max(15.0, tolerance_deg * 111000.0)
    fcount = -1
    try:
        fcount = int(layer.featureCount()) if hasattr(layer, "featureCount") else -1
    except Exception:
        fcount = -1

    selected_feats: List[Any] = []
    req = QgsFeatureRequest()
    try:
        req.setSubsetOfAttributes([])  # Only need FID + geometry! Maximum speed.
    except Exception:
        pass

    if fcount > max_features:
        # Rank across entire layer by bounding-box area so all counties appear at LOD-1
        scored_fids: List[Tuple[float, int]] = []
        scan_req = QgsFeatureRequest()
        try:
            scan_req.setSubsetOfAttributes([])
        except Exception:
            pass
        last_tick = time.monotonic()
        for idx, feat in enumerate(layer.getFeatures(scan_req)):
            if idx >= 120000:
                break
            now_ts = time.monotonic()
            tick = (now_ts - last_tick) >= 0.018
            if cancel_check and (idx % 25 == 0 or tick) and cancel_check():
                return None
            if progress_cb and tick:
                last_tick = now_ts
                progress_cb(min(45, 1 + int(44 * idx / max(1, fcount))), 100)
            if not feat.hasGeometry():
                continue
            try:
                bb = feat.geometry().boundingBox()
                scored_fids.append((float(bb.width() * bb.height()), feat.id()))
            except Exception:
                continue
        if scored_fids:
            prio_set = {int(f) for f in (priority_fids or [])}
            scored_fids.sort(key=lambda item: item[0], reverse=True)
            chosen_fids = [fid for _area, fid in scored_fids if fid in prio_set]
            chosen_set = set(chosen_fids)
            for _area, fid in scored_fids:
                if len(chosen_fids) >= max_features:
                    break
                if fid not in chosen_set:
                    chosen_fids.append(fid)
                    chosen_set.add(fid)
            top_fids = chosen_fids[:max_features]
            fid_req = QgsFeatureRequest().setFilterFids(top_fids)
            try:
                fid_req.setSubsetOfAttributes([])
            except Exception:
                pass
            selected_feats = list(layer.getFeatures(fid_req))
    else:
        req.setLimit(max_features)
        selected_feats = list(layer.getFeatures(req))

    packed: Dict[str, List[Any]] = {}
    last_tick = time.monotonic()
    n_sel = max(1, len(selected_feats))
    for sidx, feat in enumerate(selected_feats):
        now_ts = time.monotonic()
        tick = (now_ts - last_tick) >= 0.018
        if cancel_check and (sidx % 15 == 0 or tick) and cancel_check():
            return None
        if progress_cb and tick:
            last_tick = now_ts
            progress_cb(45 + int(50 * sidx / n_sel), 100)
        if not feat.hasGeometry():
            continue
        try:
            geom = QgsGeometry(feat.geometry())
            if geom.isNull() or geom.isEmpty():
                continue
            try:
                simp = geom.simplify(tol_native)
                if simp and not simp.isEmpty():
                    geom = simp
            except Exception:
                pass
            if xform is not None:
                geom.transform(xform)
            gjson = json.loads(geom.asJson(precision=5))
            entry = _simplify_geojson_geometry(gjson, tolerance=tolerance_deg, decimals=5)
            if entry is not None:
                key_str = fid_key_map.get(feat.id(), str(feat.id())) if fid_key_map else str(feat.id())
                packed[key_str] = entry
        except Exception:
            continue

    if not packed:
        return None
    raw = json.dumps(packed, separators=(",", ":")).encode("utf-8")
    comp = gzip.compress(raw, compresslevel=6)
    return {
        "format": "qdash_vp1_gzip_b64",
        "feature_count": len(packed),
        "tolerance": tolerance_deg,
        "_fid_aligned": bool(fid_key_map is not None),
        "data_b64": base64.b64encode(comp).decode("ascii"),
    }


def _geojson_bbox_area(geom: Dict[str, Any]) -> float:
    """Estimate flat bbox area in deg^2 from a GeoJSON geometry dict."""
    coords = geom.get("coordinates")
    gtype = geom.get("type", "")
    pts: List[List[float]] = []
    if gtype == "Polygon" and coords and isinstance(coords[0], list):
        pts = coords[0]
    elif gtype == "MultiPolygon" and coords and isinstance(coords[0], list) and coords[0]:
        pts = coords[0][0]
    elif gtype == "LineString" and isinstance(coords, list):
        pts = coords
    elif gtype == "MultiLineString" and coords and isinstance(coords[0], list):
        pts = coords[0]
    if len(pts) < 2:
        return 0.0
    xs = [float(p[0]) for p in pts if len(p) >= 2]
    ys = [float(p[1]) for p in pts if len(p) >= 2]
    if not xs or not ys:
        return 0.0
    return (max(xs) - min(xs)) * (max(ys) - min(ys))


def _packed_to_geojson_geometry(packed: Optional[List[Any]]) -> Optional[Dict[str, Any]]:
    """Unpack `[type_code, bbox4, coords]` back into a standard GeoJSON geometry dict."""
    if not isinstance(packed, list) or len(packed) < 3:
        return None
    type_map = {
        "P": "Point",
        "MP": "MultiPoint",
        "L": "LineString",
        "ML": "MultiLineString",
        "G": "Polygon",
        "MG": "MultiPolygon",
    }
    gtype = type_map.get(str(packed[0]))
    if not gtype:
        return None
    return {"type": gtype, "coordinates": packed[2]}


def build_lod0_polygon_pyramid_from_geojson(
    features: List[Dict[str, Any]],
    layer_name: str = "",
    max_features: int = 3200,
    tolerance_deg: float = 0.0008,
) -> Dict[str, Any]:
    """
    Build detailed-outline LOD-0 overview GeoJSON preserving real polygon/line shapes
    (prioritizing largest features + spatial stride, never reducing polygons to dots).
    """
    if not features:
        return {"type": "FeatureCollection", "features": []}

    scored: List[Tuple[float, int, Dict[str, Any]]] = []
    for idx, feat in enumerate(features):
        geom = feat.get("geometry") or {}
        if not geom:
            continue
        scored.append((_geojson_bbox_area(geom), idx, feat))

    if len(scored) > max_features:
        by_area = sorted(scored, key=lambda it: it[0], reverse=True)
        top_n = int(max_features * 0.78)
        chosen: List[Tuple[float, int, Dict[str, Any]]] = list(by_area[:top_n])
        seen_idx = {it[1] for it in chosen}
        rem = [it for it in scored if it[1] not in seen_idx]
        need = max_features - len(chosen)
        if rem and need > 0:
            step = max(1, len(rem) // need)
            for pos in range(0, len(rem), step):
                chosen.append(rem[pos])
                if len(chosen) >= max_features:
                    break
        selected = chosen
    else:
        selected = scored

    out_features: List[Dict[str, Any]] = []
    for _area, _idx, feat in selected:
        geom = feat.get("geometry") or {}
        simp_geom = _packed_to_geojson_geometry(
            _simplify_geojson_geometry(geom, tolerance=tolerance_deg, decimals=5)
        )
        if simp_geom is None:
            continue
        props = dict(feat.get("properties") or {})
        props["_pyramid_lod"] = 0
        if layer_name and not props.get("_layer_name"):
            props["_layer_name"] = layer_name
        out_features.append(
            {
                "type": "Feature",
                "id": feat.get("id", props.get("fid")),
                "geometry": simp_geom,
                "properties": props,
            }
        )

    return {"type": "FeatureCollection", "features": out_features}


def extract_lod0_polygon_pyramid_from_qgis_layer(
    layer: Any,
    layer_name: str = "",
    max_features: int = 3200,
    tolerance_deg: float = 0.0008,
    progress_cb: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Extract real simplified polygon/line outlines for LOD-0 overview from a QGIS vector
    layer without replacing polygons with confusing dots.
    """
    if layer is None or not hasattr(layer, "getFeatures"):
        return None
    try:
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsFeatureRequest,
            QgsProject,
            QgsWkbTypes,
        )
    except ImportError:
        return None

    area_calc = None
    try:
        from .spatial_overlap import QgisCartesianAreaCalculator

        proj = QgsProject.instance()
        src_crs = layer.crs()
        dst_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        xform = None
        if src_crs.isValid() and src_crs != dst_crs:
            xform = QgsCoordinateTransform(src_crs, dst_crs, proj)
        tol_native = 85.0 if (src_crs.isValid() and not src_crs.isGeographic()) else tolerance_deg
        area_calc = QgisCartesianAreaCalculator(
            src_crs, proj.transformContext(), ellipsoid=proj.ellipsoid() or "GRS80", layer=layer
        )
    except Exception:
        xform = None
        tol_native = tolerance_deg

    try:
        gtype_qgis = layer.geometryType()
        gtype_cls = getattr(QgsWkbTypes, "GeometryType", QgsWkbTypes)
        point_enum = getattr(gtype_cls, "PointGeometry", getattr(QgsWkbTypes, "PointGeometry", None))
        is_point_layer = (point_enum is not None and gtype_qgis == point_enum)
    except Exception:
        is_point_layer = False

    field_names: List[str] = []
    try:
        field_names = [f.name() for f in layer.fields()][:48]
    except Exception:
        field_names = []

    req_scan = QgsFeatureRequest()
    req_scan.setSubsetOfAttributes([])
    scored: List[Tuple[float, Any]] = []
    fcount = -1
    try:
        fcount = int(layer.featureCount()) if hasattr(layer, "featureCount") else -1
    except Exception:
        fcount = -1
    last_tick = time.monotonic()
    try:
        for idx, feat in enumerate(layer.getFeatures(req_scan)):
            now_ts = time.monotonic()
            tick = (now_ts - last_tick) >= 0.018
            if cancel_check and (idx % 25 == 0 or tick) and cancel_check():
                return None
            if progress_cb and tick and fcount > 0:
                last_tick = now_ts
                progress_cb(min(45, 1 + int(44 * idx / max(1, fcount))), 100)
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            try:
                bb = geom.boundingBox()
                area_score = float(bb.width() * bb.height())
            except Exception:
                area_score = 0.0
            scored.append((area_score, feat.id()))
    except Exception:
        return None

    if not scored:
        return None

    if len(scored) > max_features:
        by_area = sorted(scored, key=lambda it: it[0], reverse=True)
        top_n = int(max_features * 0.78)
        chosen_ids = [it[1] for it in by_area[:top_n]]
        chosen_set = set(chosen_ids)
        rem = [it[1] for it in scored if it[1] not in chosen_set]
        need = max_features - len(chosen_ids)
        if rem and need > 0:
            step = max(1, len(rem) // need)
            for pos in range(0, len(rem), step):
                chosen_ids.append(rem[pos])
                if len(chosen_ids) >= max_features:
                    break
        target_ids = chosen_ids
    else:
        target_ids = [it[1] for it in scored]

    out_features: List[Dict[str, Any]] = []
    req_full = QgsFeatureRequest().setFilterFids(target_ids)
    try:
        iterator = layer.getFeatures(req_full)
    except Exception:
        return None

    n_target = max(1, len(target_ids))
    last_tick = time.monotonic()
    for tidx, feat in enumerate(iterator):
        now_ts = time.monotonic()
        tick = (now_ts - last_tick) >= 0.018
        if cancel_check and (tidx % 15 == 0 or tick) and cancel_check():
            return None
        if progress_cb and tick:
            last_tick = now_ts
            progress_cb(45 + int(52 * tidx / n_target), 100)
        try:
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            if not is_point_layer and hasattr(geom, "simplify"):
                try:
                    simp_qgs = geom.simplify(tol_native)
                    if simp_qgs and not simp_qgs.isEmpty():
                        geom = simp_qgs
                except Exception:
                    pass
            if xform is not None:
                geom.transform(xform)
            gjson = json.loads(geom.asJson(precision=5))
            simp_geom = _packed_to_geojson_geometry(
                _simplify_geojson_geometry(gjson, tolerance=tolerance_deg, decimals=5)
            )
            if simp_geom is None:
                continue
            props: Dict[str, Any] = {
                "fid": feat.id(),
                "_layer_name": layer_name or getattr(layer, "name", lambda: "")(),
                "_pyramid_lod": 0,
            }
            for fn in field_names:
                try:
                    val = feat[fn]
                    props[fn] = None if val is None else (
                        val if isinstance(val, (str, int, float, bool)) else str(val)
                    )
                except Exception:
                    pass
            try:
                if not is_point_layer:
                    raw_geom = feat.geometry()
                    if raw_geom and not raw_geom.isEmpty():
                        if area_calc is not None:
                            props["_geom_area_ha"] = area_calc.measure_ha(raw_geom, decimals=4)
                        elif raw_geom.area() > 0:
                            props["_geom_area_ha"] = round(float(raw_geom.area()) / 10000.0, 4)
            except Exception:
                pass
            out_features.append(
                {
                    "type": "Feature",
                    "id": feat.id(),
                    "geometry": simp_geom,
                    "properties": props,
                }
            )
        except Exception:
            continue

    return {"type": "FeatureCollection", "features": out_features}


def apply_qgis_simplify_hint(layer: Any) -> None:
    """Enable fast zoomed-out C++ simplification hints on large QGIS vector layers."""
    if layer is None or not hasattr(layer, "setSimplifyMethod"):
        return
    try:
        fcount = layer.featureCount() if hasattr(layer, "featureCount") else -1
        if fcount >= 0 and fcount < 3000:
            return
        from qgis.core import QgsVectorSimplifyMethod

        method = QgsVectorSimplifyMethod()
        hints = getattr(QgsVectorSimplifyMethod, "GeometrySimplification", None)
        if hints is not None:
            method.setSimplifyHints(hints)
        if hasattr(method, "setThreshold"):
            method.setThreshold(1.5)
        layer.setSimplifyMethod(method)
    except Exception:
        pass
