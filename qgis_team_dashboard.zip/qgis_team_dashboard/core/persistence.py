# -*- coding: utf-8 -*-
"""
Dual Persistence & Data Hydration Manager for QGIS Team Dashboard.
1. Embeds/restores DashboardConfig inside the active QGIS project (.qgz).
2. Exports/imports portable .qdash.json templates from the SharePoint Catalog.
3. Automatically provisions WFS/WMS/Excel layers and applies QgsVectorLayerJoinInfo
   joins when a colleague opens a shared template.
"""

from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import os
import re
import threading
import uuid
from typing import Any, Callable, Dict, Iterable, List, Optional, Set, Tuple

from ..connectors.excel_connector import ExcelConnector
from ..connectors.ogc_connector import OgcConnector
from ..connectors.path_resolver import PortablePathResolver
from ..connectors.sharepoint_connector import SharePointConnector
from .schema import DashboardConfig, DataSourceConfig, JoinConfig, WidgetConfig
from .spatial_overlap import (
    _bbox_overlaps,
    compute_spatial_pivot_records,
    geojson_bbox_wgs84,
    geom_intersects_geom,
)
from .spatial_relations import (
    _normalized_pair as _sr_pair_key,
    compute_exact_spatial_relation_geojson,
    compute_exact_spatial_relation_qgis,
    decompress_spatial_relation,
    discover_connected_layer_pairs,
    exact_polygon_intersection_area_ha_geojson,
)
from .vector_pyramid import (
    apply_qgis_simplify_hint,
    build_lod0_grid_pyramid,
    build_lod0_polygon_pyramid_from_geojson,
    build_lod1_compressed_pyramid_from_geojson,
    build_qgis_fid_to_record_key_map,
    compute_layer_statistics,
    extract_lod0_polygon_pyramid_from_qgis_layer,
    extract_lod1_pyramid_from_qgis_layer,
)


class DashboardPersistenceManager:
    """Manages saving, loading, and hydrating dashboard configurations and data sources."""

    PROJECT_SCOPE = "QgisTeamDashboard"
    PROJECT_KEY = "dashboard_config_json"
    RECENT_WORKSPACES_PATH = os.path.join(
        os.path.expanduser("~"), ".qgis_team_dashboard", "recent_workspaces.json"
    )
    SAVED_DASHBOARDS_PATH = os.path.join(
        os.path.expanduser("~"), ".qgis_team_dashboard", "saved_dashboards.json"
    )
    SAVED_THUMBNAILS_DIR = os.path.join(
        os.path.expanduser("~"), ".qgis_team_dashboard", "thumbnails"
    )
    MAX_RECENT_WORKSPACES = 10
    _BG_SAFE_QGIS_PROVIDERS = (
        "ogr",
        "spatialite",
        "postgres",
        "delimitedtext",
        "gpkg",
        "arcgisfeatureserver",
    )

    def __init__(self) -> None:
        self.layer_records_cache: Dict[str, List[Dict[str, Any]]] = {}
        self.layer_geojson_cache: Dict[str, Dict[str, Any]] = {}
        self.layer_stats_cache: Dict[str, Dict[str, Any]] = {}
        self.layer_pyramid_cache: Dict[str, Dict[str, Any]] = {}
        self.initial_geojson_cache: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
        self.excel_records_cache: Dict[str, List[Dict[str, Any]]] = {}
        self.dashboard_layers: Dict[str, Any] = {}
        self.catalog_manager: Optional[Any] = None
        self.active_sync_mode: str = "dashboard_only"
        self._spatial_pivot_cache: Dict[Tuple[Any, ...], List[Dict[str, Any]]] = {}
        self._cross_layer_fid_cache: Dict[Tuple[Any, ...], Any] = {}
        self.spatial_relations_cache: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self._spatial_relations_decoded: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self._preview_cache_lock = threading.RLock()
        self._preview_spatial_index: Dict[
            str, List[Tuple[str, Optional[Tuple[float, float, float, float]], float, Dict[str, Any]]]
        ] = {}
        self._preview_spatial_complete: Dict[str, bool] = {}
        self._preview_feature_query_cache: "OrderedDict[Tuple[Any, ...], Dict[str, Any]]" = OrderedDict()
        self._preview_tile_cache: "OrderedDict[Tuple[Any, ...], bytes]" = OrderedDict()
        self._preview_bg_specs: Dict[str, Dict[str, Any]] = {}
        self._preview_bg_tctx: Any = None
        self._preview_bg_ellipsoid: str = "GRS80"
        self._preview_cache_rev: int = 1

    @staticmethod
    def get_current_project_dir() -> Optional[str]:
        """Return the directory of the currently open .qgz/.qgs project if saved."""
        try:
            from qgis.core import QgsProject

            file_name = QgsProject.instance().fileName()
            if file_name:
                return os.path.dirname(os.path.abspath(file_name))
        except ImportError:
            pass
        return None

    @staticmethod
    def _is_point_only_lod0(lod0: Optional[Dict[str, Any]]) -> bool:
        """Return True if *lod0* FeatureCollection contains only Point/MultiPoint features."""
        if not isinstance(lod0, dict):
            return False
        feats = lod0.get("features")
        if not isinstance(feats, list) or not feats:
            return False
        seen_geom = False
        for feat in feats[:30]:
            geom = (feat or {}).get("geometry") or {}
            gtype = str(geom.get("type") or "")
            if not gtype:
                continue
            seen_geom = True
            if "Polygon" in gtype or "LineString" in gtype or gtype == "GeometryCollection":
                return False
        return seen_geom

    def _layer_has_nonpoint_geometry(
        self,
        layer_name: str,
        recs: Optional[List[Dict[str, Any]]] = None,
        qgs_layer: Any = None,
    ) -> bool:
        """Return True when the layer contains polygon/line geometries rather than pure points."""
        if qgs_layer is None and hasattr(self, "_find_qgis_layer_by_name"):
            qgs_layer = self._find_qgis_layer_by_name(layer_name)
        if qgs_layer is not None and hasattr(qgs_layer, "geometryType"):
            try:
                from qgis.core import QgsWkbTypes

                gt = qgs_layer.geometryType()
                geom_ns = getattr(QgsWkbTypes, "GeometryType", None)
                poly_line = {
                    v
                    for v in (
                        getattr(QgsWkbTypes, "PolygonGeometry", None),
                        getattr(QgsWkbTypes, "LineGeometry", None),
                        getattr(geom_ns, "PolygonGeometry", None) if geom_ns is not None else None,
                        getattr(geom_ns, "LineGeometry", None) if geom_ns is not None else None,
                    )
                    if v is not None
                }
                pt_only = {
                    v
                    for v in (
                        getattr(QgsWkbTypes, "PointGeometry", None),
                        getattr(geom_ns, "PointGeometry", None) if geom_ns is not None else None,
                    )
                    if v is not None
                }
                if gt in poly_line:
                    return True
                if gt in pt_only:
                    return False
            except Exception:
                pass

        gj = self.layer_geojson_cache.get(layer_name)
        if isinstance(gj, dict) and isinstance(gj.get("features"), list) and gj["features"]:
            seen_geom = False
            for feat in gj["features"][:30]:
                gtype = str(((feat or {}).get("geometry") or {}).get("type") or "")
                if not gtype:
                    continue
                seen_geom = True
                if "Polygon" in gtype or "LineString" in gtype or gtype == "GeometryCollection":
                    return True
            if seen_geom:
                return False

        for rec in (recs or [])[:50]:
            if not isinstance(rec, dict):
                continue
            gt_hint = str(rec.get("_geom_type") or rec.get("geometry_type") or "").lower()
            if "polygon" in gt_hint or "line" in gt_hint:
                return True
            bbox = rec.get("_bbox")
            if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
                try:
                    if abs(float(bbox[2]) - float(bbox[0])) > 1e-6 or abs(float(bbox[3]) - float(bbox[1])) > 1e-6:
                        return True
                except Exception:
                    pass
        return False

    @classmethod
    def save_to_qgis_project(cls, config: DashboardConfig) -> bool:
        """Write the serialized DashboardConfig into the current QGIS project (.qgz)."""
        try:
            from qgis.core import QgsProject

            proj = QgsProject.instance()
            proj.writeEntry(cls.PROJECT_SCOPE, cls.PROJECT_KEY, config.to_json(indent=2))
            return True
        except ImportError:
            return False

    @classmethod
    def load_from_qgis_project(cls) -> Optional[DashboardConfig]:
        """Read the embedded DashboardConfig from the current QGIS project (.qgz)."""
        try:
            from qgis.core import QgsProject

            proj = QgsProject.instance()
            raw_json, ok = proj.readEntry(cls.PROJECT_SCOPE, cls.PROJECT_KEY, "")
            if ok and raw_json and raw_json.strip():
                return DashboardConfig.from_json(raw_json)
        except Exception:
            pass
        return None

    @staticmethod
    def save_to_template_file(
        config: DashboardConfig, file_path: str, project_dir: Optional[str] = None
    ) -> str:
        """Tokenize any local paths in DataSourceConfigs and write a portable .qdash.json file."""
        for ds in config.data_sources:
            if ds.portable_path:
                ds.portable_path = PortablePathResolver.tokenize(
                    ds.portable_path, project_dir=project_dir
                )
        resolved_out = PortablePathResolver.resolve(file_path, project_dir=project_dir)
        os.makedirs(os.path.dirname(os.path.abspath(resolved_out)), exist_ok=True)
        with open(resolved_out, "w", encoding="utf-8") as fh:
            fh.write(config.to_json(indent=2))
        return resolved_out

    @classmethod
    def load_recent_workspaces(cls, path: Optional[str] = None) -> List[Dict[str, Any]]:
        """Load up to MAX_RECENT_WORKSPACES recently used dashboards from disk."""
        target = path or cls.RECENT_WORKSPACES_PATH
        if not os.path.isfile(target):
            return []
        try:
            with open(target, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            if isinstance(raw, list):
                return [r for r in raw if isinstance(r, dict)][: cls.MAX_RECENT_WORKSPACES]
        except Exception:
            pass
        return []

    @classmethod
    def _write_recent_workspaces(
        cls, entries: List[Dict[str, Any]], path: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        target = path or cls.RECENT_WORKSPACES_PATH
        trimmed = list(entries)[: cls.MAX_RECENT_WORKSPACES]
        try:
            os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
            with open(target, "w", encoding="utf-8") as fh:
                json.dump(trimmed, fh, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return trimmed

    @classmethod
    def save_recent_workspace(
        cls,
        config: DashboardConfig,
        project_path: str = "",
        template_path: str = "",
        path: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Record or update a workspace in the MRU list (keeps top 10)."""
        if not (config.widgets or config.slicers or config.data_sources):
            return cls.load_recent_workspaces(path=path)
        entry_id = f"{config.id or config.title}|{project_path or template_path or ''}"
        layer_names: List[str] = []
        for ds in config.data_sources:
            if ds.name and ds.name not in layer_names:
                layer_names.append(ds.name)
        for ln in cls.referenced_layer_names(config):
            if ln and ln not in layer_names:
                layer_names.append(ln)
        entry = {
            "id": entry_id,
            "dashboard_id": config.id,
            "title": config.title or "Töölaud",
            "title_en": config.title_en or config.title or "Dashboard",
            "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "widget_count": len(config.widgets),
            "slicer_count": len(config.slicers),
            "source_count": len(config.data_sources),
            "layer_names": layer_names[:12],
            "project_path": project_path or "",
            "template_path": template_path or "",
            "config": config.to_dict(),
        }
        existing = cls.load_recent_workspaces(path=path)
        filtered = [
            item
            for item in existing
            if item.get("id") != entry_id
            and not (config.id and item.get("dashboard_id") == config.id and (project_path or "") == item.get("project_path", ""))
        ]
        updated = [entry] + filtered
        return cls._write_recent_workspaces(updated, path=path)

    @classmethod
    def remove_recent_workspaces(
        cls, entry_ids: Iterable[str], path: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        id_set = {str(eid) for eid in (entry_ids or ()) if str(eid)}
        existing = cls.load_recent_workspaces(path=path)
        remaining = [item for item in existing if str(item.get("id") or "") not in id_set]
        return cls._write_recent_workspaces(remaining, path=path)

    @classmethod
    def remove_recent_workspace(
        cls, entry_id: str, path: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return cls.remove_recent_workspaces([entry_id], path=path)

    @classmethod
    def summarize_dashboard_contents(cls, config: DashboardConfig) -> Dict[str, Any]:
        """Build human-readable & structured content summary for a dashboard."""
        layer_names: List[str] = []
        for ds in getattr(config, "data_sources", []) or []:
            if ds.name and ds.name not in layer_names:
                layer_names.append(ds.name)
        for ln in cls.referenced_layer_names(config):
            if ln and ln not in layer_names:
                layer_names.append(ln)
        widget_types: Dict[str, int] = {}
        for w in getattr(config, "widgets", []) or []:
            wt = str(getattr(w, "widget_type", "") or "widget").lower()
            widget_types[wt] = int(widget_types.get(wt, 0)) + 1
        return {
            "widget_count": len(getattr(config, "widgets", []) or []),
            "slicer_count": len(getattr(config, "slicers", []) or []),
            "source_count": len(getattr(config, "data_sources", []) or []),
            "page_count": len(getattr(config, "pages", []) or []) or 1,
            "join_count": len(getattr(config, "joins", []) or []),
            "widget_types": widget_types,
            "layer_names": layer_names[:20],
        }

    @classmethod
    def load_saved_dashboards(cls, path: Optional[str] = None) -> List[Dict[str, Any]]:
        """Load user-saved named dashboards from disk."""
        target = path or cls.SAVED_DASHBOARDS_PATH
        if not os.path.isfile(target):
            return []
        try:
            with open(target, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            if isinstance(raw, list):
                return [r for r in raw if isinstance(r, dict)]
        except Exception:
            pass
        return []

    @classmethod
    def _write_saved_dashboards(
        cls, entries: List[Dict[str, Any]], path: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        target = path or cls.SAVED_DASHBOARDS_PATH
        cleaned = [e for e in (entries or []) if isinstance(e, dict)]
        try:
            os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
            with open(target, "w", encoding="utf-8") as fh:
                json.dump(cleaned, fh, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return cleaned

    @classmethod
    def save_named_dashboard(
        cls,
        config: DashboardConfig,
        name: Optional[str] = None,
        project_path: str = "",
        thumbnail_png: bytes = b"",
        entry_id: str = "",
        path: Optional[str] = None,
        thumbnails_dir: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Save a named dashboard snapshot with content metadata, timestamps, and optional PNG thumbnail."""
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        existing = cls.load_saved_dashboards(path=path)
        prev_match = next(
            (it for it in existing if entry_id and str(it.get("id") or "") == str(entry_id)),
            None,
        )
        sid = str(entry_id or (prev_match.get("id") if prev_match else "") or f"saved_{uuid.uuid4().hex[:8]}")
        created_at = str((prev_match or {}).get("created_at") or now_str)
        clean_title = str(name or "").strip() or str(config.title or "").strip() or "Töölaud"
        summary = cls.summarize_dashboard_contents(config)

        tdir = thumbnails_dir or cls.SAVED_THUMBNAILS_DIR
        thumb_path = str((prev_match or {}).get("thumbnail_path") or "")
        if thumbnail_png:
            try:
                os.makedirs(os.path.abspath(tdir), exist_ok=True)
                target_png = os.path.join(os.path.abspath(tdir), f"{sid}.png")
                with open(target_png, "wb") as tfh:
                    tfh.write(thumbnail_png)
                thumb_path = target_png
            except Exception:
                pass

        cfg_dict = config.to_dict()
        if clean_title:
            cfg_dict["title"] = clean_title
            if not cfg_dict.get("title_en") or cfg_dict.get("title_en") == "My Dashboard":
                cfg_dict["title_en"] = clean_title
        entry: Dict[str, Any] = {
            "id": sid,
            "dashboard_id": config.id,
            "title": clean_title,
            "title_en": config.title_en or clean_title,
            "created_at": created_at,
            "updated_at": now_str,
            "widget_count": summary["widget_count"],
            "slicer_count": summary["slicer_count"],
            "source_count": summary["source_count"],
            "page_count": summary["page_count"],
            "join_count": summary["join_count"],
            "widget_types": summary["widget_types"],
            "layer_names": summary["layer_names"],
            "project_path": project_path or "",
            "thumbnail_path": thumb_path,
            "config": cfg_dict,
        }
        remaining = [it for it in existing if str(it.get("id") or "") != sid]
        cls._write_saved_dashboards([entry] + remaining, path=path)
        return entry

    @classmethod
    def remove_saved_dashboards(
        cls,
        entry_ids: Iterable[str],
        path: Optional[str] = None,
        thumbnails_dir: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Delete one or more saved dashboards and their thumbnail PNGs."""
        id_set = {str(eid) for eid in (entry_ids or ()) if str(eid)}
        existing = cls.load_saved_dashboards(path=path)
        kept: List[Dict[str, Any]] = []
        for item in existing:
            iid = str(item.get("id") or "")
            if iid in id_set:
                tpath = str(item.get("thumbnail_path") or "")
                if tpath and os.path.isfile(tpath):
                    try:
                        os.remove(tpath)
                    except Exception:
                        pass
                if thumbnails_dir and iid:
                    cand = os.path.join(os.path.abspath(thumbnails_dir), f"{iid}.png")
                    if os.path.isfile(cand):
                        try:
                            os.remove(cand)
                        except Exception:
                            pass
            else:
                kept.append(item)
        return cls._write_saved_dashboards(kept, path=path)

    @staticmethod
    def config_uses_natura_pria_overlap(config: Optional[DashboardConfig]) -> bool:
        """Return True only when at least one widget, slicer, or style explicitly references overlap_* fields."""
        if config is None:
            return True
        ov_fields = {"overlap_pria_ha", "overlap_mn_ha", "overlap_pn_ha", "overlap_pct", "pria_overlap_ha", "_pria_ov"}
        for w in getattr(config, "widgets", []) or []:
            for attr in ("value_field", "category_field", "secondary_field"):
                if str(getattr(w, attr, "") or "").lower() in ov_fields:
                    return True
            for lst_attr in ("table_columns", "pivot_rows", "pivot_cols"):
                for col in getattr(w, lst_attr, []) or []:
                    if str(col or "").lower() in ov_fields:
                        return True
            for pv in getattr(w, "pivot_values", []) or []:
                if isinstance(pv, dict) and str(pv.get("field") or "").lower() in ov_fields:
                    return True
            for st_spec in (getattr(w, "map_layer_styles", {}) or {}).values():
                if isinstance(st_spec, dict):
                    if str(st_spec.get("style_field") or "").lower() in ov_fields:
                        return True
                    for lf in st_spec.get("legend_fields", []) or []:
                        if str(lf or "").lower() in ov_fields:
                            return True
        for sl in getattr(config, "slicers", []) or []:
            if str(getattr(sl, "field_name", "") or "").lower() in ov_fields:
                return True
            for pn in getattr(sl, "panes", []) or []:
                if isinstance(pn, dict) and str(pn.get("field_name") or "").lower() in ov_fields:
                    return True
        return False

    @staticmethod
    def load_from_template_file(
        file_path: str, project_dir: Optional[str] = None
    ) -> DashboardConfig:
        """Load a portable .qdash.json file from disk."""
        return SharePointConnector.load_template_from_file(
            file_path, project_dir=project_dir
        )

    @staticmethod
    def list_qgis_project_layer_schemas() -> Dict[str, List[str]]:
        """Return field schemas of vector layers open in QGIS WITHOUT loading any feature rows."""
        schemas: Dict[str, List[str]] = {}
        try:
            from qgis.core import Qgis, QgsMapLayer, QgsProject

            vec_layer_type = getattr(getattr(Qgis, "LayerType", None), "Vector", None)
            if vec_layer_type is None:
                vec_layer_type = getattr(QgsMapLayer, "VectorLayer", None)
            if vec_layer_type is not None:
                for layer in QgsProject.instance().mapLayers().values():
                    if layer.type() == vec_layer_type and hasattr(layer, "fields"):
                        schemas[layer.name()] = [f.name() for f in layer.fields()]
        except Exception:
            pass
        return schemas

    def get_layer_fields_map(self, config: Optional[DashboardConfig] = None) -> Dict[str, List[str]]:
        """Return known field schemas from cached records, Excel sources, and active dashboard/QGIS layers."""
        out: Dict[str, List[str]] = {}
        sync_main = (
            config is None
            or str(getattr(config, "canvas_sync_mode", "dashboard_only") or "dashboard_only") == "sync_main_canvas"
        )
        if sync_main:
            for lyr_name, cols in self.list_qgis_project_layer_schemas().items():
                if cols:
                    out[lyr_name] = list(cols)
        for lyr_name, lyr in list(getattr(self, "dashboard_layers", {}).items()):
            try:
                if lyr is not None and hasattr(lyr, "fields"):
                    cols = [f.name() for f in lyr.fields()]
                    if cols:
                        out[lyr_name] = cols
            except Exception:
                pass
        if config is not None:
            for ds in getattr(config, "data_sources", []) or []:
                if ds.name and ds.id in self.excel_records_cache and ds.name not in self.layer_records_cache:
                    recs = self.excel_records_cache.get(ds.id) or []
                    if recs:
                        out[ds.name] = [k for k in recs[0].keys() if not str(k).startswith("_")]
        for lyr_name, recs in self.layer_records_cache.items():
            if recs:
                cols = [k for k in recs[0].keys() if not str(k).startswith("_")]
                if cols:
                    out[lyr_name] = cols
        return out

    def list_all_available_sources(self, config: Optional[DashboardConfig] = None) -> List[Dict[str, Any]]:
        """Return unified source descriptors across hydrated caches, Excel tables, DataSources, and QGIS layers."""
        fields_map = self.get_layer_fields_map(config=config)
        qgis_schemas = self.list_qgis_project_layer_schemas()
        seen: Dict[str, Dict[str, Any]] = {}

        def _ensure_entry(name: str, stype: str = "layer", ds_id: str = "") -> Dict[str, Any]:
            ent = seen.get(name)
            if ent is None:
                recs = self.layer_records_cache.get(name)
                if recs is None and ds_id:
                    recs = self.excel_records_cache.get(ds_id)
                ent = {
                    "name": name,
                    "source_type": stype,
                    "source_id": ds_id,
                    "fields": list(fields_map.get(name) or qgis_schemas.get(name) or []),
                    "row_count": len(recs) if isinstance(recs, list) else 0,
                    "hydrated": bool(
                        isinstance(recs, list)
                        and (name in self.layer_records_cache or (ds_id and ds_id in self.excel_records_cache))
                    ),
                }
                seen[name] = ent
            else:
                if ds_id and not ent.get("source_id"):
                    ent["source_id"] = ds_id
                if stype != "layer" and ent.get("source_type") == "layer":
                    ent["source_type"] = stype
            return ent

        if config is not None:
            for ds in getattr(config, "data_sources", []) or []:
                if ds.name and not getattr(ds, "is_basemap", False):
                    _ensure_entry(ds.name, stype=str(ds.source_type or "layer"), ds_id=str(ds.id or ""))
        for lname in sorted(self.layer_records_cache.keys()):
            if lname:
                _ensure_entry(lname, stype="layer")
        for lname in sorted(qgis_schemas.keys()):
            if lname:
                _ensure_entry(lname, stype="qgis_layer")
        return list(seen.values())

    @staticmethod
    def referenced_layer_names(config: DashboardConfig, page_id: Optional[str] = None) -> set:
        """Return the set of layer/source names actively used by widgets, slicers, expressions, or joins (optionally scoped to one Atlas page)."""
        from .expression_engine import (
            extract_layers_from_blocks,
            extract_referenced_layers,
            extract_referenced_widgets,
            extract_widgets_from_blocks,
        )

        pages = list(getattr(config, "pages", []) or [])
        first_pid = pages[0].id if pages else "page_1"
        target_pid = str(page_id).strip() if page_id is not None and str(page_id).strip() else ""

        names = set()
        widget_refs: Set[str] = set()
        for w in config.widgets:
            w_pid = str(getattr(w, "page_id", "") or first_pid)
            if target_pid and w_pid != target_pid:
                continue
            if w.layer_name and w.layer_name != "*":
                names.add(w.layer_name)
            if getattr(w, "spatial_join_layer", ""):
                names.add(w.spatial_join_layer)
            for ml in getattr(w, "map_layers", []) or []:
                if ml and ml != "*":
                    names.add(ml)
            expr_txt = str(getattr(w, "expression", "") or "")
            sub_txt = str(getattr(w, "expression_subtext", "") or "")
            blks = getattr(w, "expression_blocks", None) or []
            if expr_txt:
                names.update(extract_referenced_layers(expr_txt))
                widget_refs.update(extract_referenced_widgets(expr_txt))
            if sub_txt:
                names.update(extract_referenced_layers(sub_txt))
                widget_refs.update(extract_referenced_widgets(sub_txt))
            if blks:
                names.update(extract_layers_from_blocks(blks))
                widget_refs.update(extract_widgets_from_blocks(blks))
        if widget_refs:
            for w in config.widgets:
                if (w.id in widget_refs or w.title in widget_refs or getattr(w, "title_en", "") in widget_refs) and w.layer_name and w.layer_name != "*":
                    names.add(w.layer_name)
        for s in config.slicers:
            if not s.layer_name or s.layer_name == "*":
                continue
            s_pid = str(getattr(s, "page_id", "") or first_pid)
            is_glob = bool(getattr(s, "is_global", False))
            if not target_pid or s_pid == target_pid or (is_glob and s.layer_name in names):
                names.add(s.layer_name)
        ds_by_id = {ds.id: ds for ds in config.data_sources}
        for jn in config.joins:
            src_name = ds_by_id[jn.source_table_id].name if jn.source_table_id in ds_by_id else (jn.source_table_id or "")
            tgt_name = ds_by_id[jn.target_layer_id].name if jn.target_layer_id in ds_by_id else (jn.target_layer_id or "")
            if not target_pid or (src_name and src_name in names) or (tgt_name and tgt_name in names):
                if src_name:
                    names.add(src_name)
                if tgt_name:
                    names.add(tgt_name)
        names.discard("")
        names.discard("*")
        return names

    @staticmethod
    def _call_with_optional_progress(
        fn: Callable[..., Any],
        *args: Any,
        progress_cb: Optional[Callable[..., Any]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        **kwargs: Any,
    ) -> Any:
        """Invoke *fn* passing progress_cb/cancel_check only when non-None and supported by callee."""
        extra: Dict[str, Any] = {}
        if progress_cb is not None:
            extra["progress_cb"] = progress_cb
        if cancel_check is not None:
            extra["cancel_check"] = cancel_check
        if extra:
            try:
                return fn(*args, **kwargs, **extra)
            except TypeError as exc:
                if "unexpected keyword argument" not in str(exc):
                    raise
        return fn(*args, **kwargs)

    @staticmethod
    def _extract_symbol_visuals(sym: Any) -> Dict[str, Any]:
        """Extract fill color, stroke color, opacity, and stroke width from one QgsSymbol."""
        info: Dict[str, Any] = {}
        if sym is None:
            return info
        try:
            if hasattr(sym, "symbolLayerCount") and sym.symbolLayerCount() > 0:
                sl0 = sym.symbolLayer(0)
                if sl0 is not None:
                    if hasattr(sl0, "strokeColor"):
                        sc = sl0.strokeColor()
                        if sc is not None and (not hasattr(sc, "isValid") or sc.isValid()):
                            info["stroke_color"] = str(sc.name())
                    if hasattr(sl0, "strokeWidth"):
                        sw = float(sl0.strokeWidth())
                        if sw > 0:
                            info["stroke_width"] = round(min(6.0, max(0.5, sw * 3.0 if sw < 1.2 else sw)), 2)
                    if hasattr(sl0, "fillColor"):
                        fc = sl0.fillColor()
                        if fc is not None and (not hasattr(fc, "isValid") or fc.isValid()):
                            if not hasattr(fc, "alpha") or fc.alpha() > 0:
                                info["color"] = str(fc.name())
                                info["opacity"] = round(max(0.08, min(0.95, float(fc.alphaF()))), 3)
                            elif info.get("stroke_color"):
                                info["color"] = info["stroke_color"]
                                info["opacity"] = 0.14
            if "color" not in info and hasattr(sym, "color"):
                col = sym.color()
                if col is not None and (not hasattr(col, "isValid") or col.isValid()):
                    info["color"] = str(col.name())
                    if hasattr(col, "alphaF"):
                        a = float(col.alphaF())
                        info["opacity"] = round(max(0.08, min(0.95, a)), 3) if a > 0 else 0.14
            if hasattr(sym, "opacity") and "opacity" in info:
                try:
                    info["opacity"] = round(max(0.08, min(0.95, info["opacity"] * float(sym.opacity()))), 3)
                except Exception:
                    pass
        except Exception:
            pass
        return info

    @staticmethod
    def _extract_qgis_label_info(qgs_layer: Any) -> Dict[str, Any]:
        info: Dict[str, Any] = {}
        try:
            if (
                qgs_layer is not None
                and hasattr(qgs_layer, "labelsEnabled")
                and qgs_layer.labelsEnabled()
                and hasattr(qgs_layer, "labeling")
            ):
                lbl_obj = qgs_layer.labeling()
                if lbl_obj is not None and hasattr(lbl_obj, "settings"):
                    s_lbl = lbl_obj.settings()
                    if s_lbl is not None and getattr(s_lbl, "fieldName", ""):
                        info["label_enabled"] = True
                        info["label_field"] = str(s_lbl.fieldName)
        except Exception:
            pass
        return info

    @classmethod
    def extract_qgis_layer_style(cls, qgs_layer: Any) -> Dict[str, Any]:
        """Snapshot native QGIS renderer style & labels so Leaflet LOD-0 and legends match QGIS tiles."""
        if qgs_layer is None or not hasattr(qgs_layer, "renderer"):
            return {}
        lbl_info = cls._extract_qgis_label_info(qgs_layer)
        try:
            rend = qgs_layer.renderer()
            if rend is None:
                return lbl_info
            if hasattr(rend, "categories") and hasattr(rend, "classAttribute"):
                cats = list(rend.categories() or [])
                cat_colors: Dict[str, str] = {}
                first_vis: Dict[str, Any] = {}
                for cat in cats[:256]:
                    sym = cat.symbol() if hasattr(cat, "symbol") else None
                    vis = cls._extract_symbol_visuals(sym)
                    if not first_vis and vis:
                        first_vis = dict(vis)
                    cval = cat.value() if hasattr(cat, "value") else None
                    if vis.get("color") and cval is not None and str(cval) != "":
                        cat_colors[str(cval)] = vis["color"]
                out_cat: Dict[str, Any] = {
                    "style_mode": "category",
                    "style_field": str(rend.classAttribute() or ""),
                    "category_colors": cat_colors,
                }
                if first_vis.get("color"):
                    out_cat["color"] = first_vis["color"]
                if "opacity" in first_vis:
                    out_cat["opacity"] = first_vis["opacity"]
                if "stroke_width" in first_vis:
                    out_cat["stroke_width"] = first_vis["stroke_width"]
                out_cat.update(lbl_info)
                return out_cat if (out_cat.get("style_field") or cat_colors or out_cat.get("color") or lbl_info) else {}

            sym = rend.symbol() if hasattr(rend, "symbol") else None
            if sym is None and hasattr(rend, "ranges"):
                ranges = list(rend.ranges() or [])
                if ranges and hasattr(ranges[0], "symbol"):
                    sym = ranges[0].symbol()
            vis = cls._extract_symbol_visuals(sym)
            if vis:
                vis["style_mode"] = "single"
                vis.update(lbl_info)
                return vis
            if lbl_info:
                return lbl_info
        except Exception:
            pass
        return lbl_info

    @staticmethod
    def _open_isolated_qgis_vector_layer(spec: Dict[str, Any], lname: str) -> Any:
        """Open a thread-local read-only QgsVectorLayer without touching QgsProject.instance()."""
        if not spec or not spec.get("can_bg_read"):
            return None
        from qgis.core import QgsVectorLayer

        opts = None
        layer_opts_cls = getattr(QgsVectorLayer, "LayerOptions", None)
        if layer_opts_cls is not None:
            try:
                opts = layer_opts_cls(False)
            except Exception:
                opts = None
        if opts is not None:
            bg_lyr = QgsVectorLayer(spec["source"], lname, spec["provider"], opts)
        else:
            bg_lyr = QgsVectorLayer(spec["source"], lname, spec["provider"])
        if bg_lyr is None or not bg_lyr.isValid():
            return None
        return bg_lyr

    def _hydrate_single_qgis_layer(
        self,
        qgs_layer: Any,
        layer_name: str,
        max_records: int,
        extent_rect: Any = None,
        progress_cb: Optional[Callable[[int, int], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """Populate records, stats, pyramids, and initial GeoJSON from one QGIS layer pass."""
        bundle = OgcConnector.extract_layer_bundle_from_qgis_layer(
            qgs_layer,
            layer_name=layer_name,
            max_records=max_records,
            extent_rect=extent_rect,
            include_lod0=True,
            include_lod1=True,
            progress_cb=progress_cb,
            cancel_check=cancel_check,
        )
        if bundle.get("cancelled"):
            return True
        self.layer_records_cache[layer_name] = bundle.get("records") or []
        if bundle.get("stats") is not None:
            st = dict(bundle["stats"])
            if getattr(self, "active_sync_mode", "dashboard_only") == "sync_main_canvas":
                qstyle = self.extract_qgis_layer_style(qgs_layer)
                if qstyle:
                    st["qgis_style"] = qstyle
            self.layer_stats_cache[layer_name] = st
        if bundle.get("lod0") or bundle.get("lod1"):
            pyr_entry: Dict[str, Any] = {}
            if bundle.get("lod0"):
                pyr_entry["lod0"] = bundle["lod0"]
            if bundle.get("lod1"):
                pyr_entry["lod1"] = bundle["lod1"]
            self.layer_pyramid_cache[layer_name] = pyr_entry
        if bundle.get("initial_geojson"):
            self.layer_geojson_cache[layer_name] = bundle["initial_geojson"]
        return False

    def clear_dashboard_layers(self) -> None:
        self.dashboard_layers.clear()

    def set_sync_mode(self, mode: Optional[str]) -> str:
        clean = "sync_main_canvas" if str(mode or "").strip() == "sync_main_canvas" else "dashboard_only"
        self.active_sync_mode = clean
        return clean

    def ensure_referenced_sources_registered(
        self,
        config: DashboardConfig,
        catalog_manager: Optional[Any] = None,
        project_dir: Optional[str] = None,
    ) -> None:
        """
        Ensure every layer referenced by widgets/slicers/expressions/joins has a portable
        DataSourceConfig (WFS/WMS/Excel/URI) so saved/recent dashboards can auto-load
        missing layers even when the QGIS main canvas is empty.
        """
        if config is None:
            return
        proj_dir = project_dir or self.get_current_project_dir()
        needed = self.referenced_layer_names(config)
        for w in getattr(config, "widgets", []) or []:
            for ml in getattr(w, "map_layers", []) or []:
                if ml:
                    needed.add(ml)

        # Upgrade any sparse 'qgis_layer' entries with full provider/URI or WFS metadata
        for idx, ds in enumerate(list(getattr(config, "data_sources", []) or [])):
            if ds.source_type == "qgis_layer" and not getattr(ds, "source_uri", ""):
                lyr = self.dashboard_layers.get(ds.name) or self._find_project_qgis_layer_by_name(ds.name)
                if lyr is not None:
                    inferred = OgcConnector.infer_datasource_from_qgis_layer(lyr, project_dir=proj_dir)
                    if inferred is not None:
                        inferred.id = ds.id
                        config.data_sources[idx] = inferred

        known_names = {ds.name for ds in config.data_sources if ds.name}
        cat = catalog_manager or getattr(self, "catalog_manager", None)
        if cat is None:
            try:
                from ..connectors.catalog_manager import LocalCatalogManager

                cat = LocalCatalogManager()
            except Exception:
                cat = None

        for ln in sorted(n for n in needed if n and n not in known_names):
            lyr = self.dashboard_layers.get(ln) or self._find_project_qgis_layer_by_name(ln)
            if lyr is not None:
                inferred = OgcConnector.infer_datasource_from_qgis_layer(lyr, project_dir=proj_dir)
                if inferred is not None:
                    config.data_sources.append(inferred)
                    known_names.add(inferred.name)
                    continue

            if cat is not None and hasattr(cat, "get_servers"):
                ln_low = ln.strip().lower()
                matched = False
                for srv in cat.get_servers():
                    srv_type = str(srv.get("service_type") or "wfs").lower()
                    srv_url = str(srv.get("url") or "").strip()
                    srv_crs = str(srv.get("crs") or "EPSG:3301")
                    srv_authcfg = str(srv.get("authcfg") or "")
                    for lyr_meta in srv.get("layers", []) or []:
                        if not isinstance(lyr_meta, dict):
                            continue
                        l_title = str(lyr_meta.get("title") or lyr_meta.get("name") or "").strip()
                        l_name = str(lyr_meta.get("name") or l_title).strip()
                        if ln_low in (l_title.lower(), l_name.lower()):
                            stype = str(lyr_meta.get("service_type") or srv_type or "wfs").lower()
                            url_use = str(lyr_meta.get("url") or srv_url).strip()
                            if url_use:
                                is_mass = stype == "wfs" and OgcConnector.is_massive_layer(ln, l_name)
                                ds_new = DataSourceConfig(
                                    name=ln,
                                    source_type="wms" if stype == "wms" else "wfs",
                                    url=url_use,
                                    typename_or_layers=l_name,
                                    crs=str(lyr_meta.get("crs") or srv_crs or "EPSG:3301"),
                                    image_format=str(lyr_meta.get("format") or "image/png"),
                                    auth_mode="qgis_authcfg" if srv_authcfg else "none",
                                    authcfg_id=srv_authcfg,
                                    layer_color=OgcConnector.default_layer_color_for_name(ln, l_name),
                                    is_basemap=bool(lyr_meta.get("is_basemap", False)),
                                    restrict_to_bbox=bool(is_mass),
                                    max_features=400 if is_mass else 0,
                                )
                                config.data_sources.append(ds_new)
                                known_names.add(ln)
                                matched = True
                                break
                    if matched:
                        break

    def _load_missing_qgis_layer_from_ds(
        self,
        ds: DataSourceConfig,
        project_dir: Optional[str] = None,
        add_to_project: bool = False,
    ) -> Optional[Any]:
        """Re-instantiate a missing QGIS layer from its persisted URI, portable file path, or OGC descriptor."""
        if ds is None:
            return None
        if ds.source_type in ("wfs", "wms") or (ds.url and ds.typename_or_layers):
            if ds.source_type not in ("wfs", "wms"):
                ds = DataSourceConfig(**{**ds.__dict__, "source_type": "wms" if str(ds.provider_type).lower() == "wms" else "wfs"})
            return OgcConnector.connect_qgis_layer(
                ds,
                add_to_project=add_to_project,
                isolated_store=None if add_to_project else self.dashboard_layers,
            )

        raw_uri = str(getattr(ds, "source_uri", "") or getattr(ds, "portable_path", "") or "").strip()
        if not raw_uri:
            return None
        proj_dir = project_dir or self.get_current_project_dir()
        resolved_uri = raw_uri
        if "|" in raw_uri:
            fp, suf = raw_uri.split("|", 1)
            resolved_fp = PortablePathResolver.resolve(fp, project_dir=proj_dir)
            resolved_uri = f"{resolved_fp}|{suf}"
        elif raw_uri.startswith("${") or os.path.exists(raw_uri) or re.match(r"^[a-zA-Z]:[/\\]|^/", raw_uri):
            resolved_uri = PortablePathResolver.resolve(raw_uri, project_dir=proj_dir)

        try:
            from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer
        except ImportError:
            return None

        prov = str(getattr(ds, "provider_type", "") or "ogr").strip()
        if prov.lower() in ("wms", "gdal"):
            layer = QgsRasterLayer(resolved_uri, ds.name, prov.lower())
        else:
            layer = QgsVectorLayer(resolved_uri, ds.name, prov or "ogr")

        if layer is not None and layer.isValid():
            if not add_to_project:
                if hasattr(layer, "setLabelsEnabled"):
                    try:
                        layer.setLabelsEnabled(False)
                    except Exception:
                        pass
                self.dashboard_layers[ds.name] = layer
            else:
                QgsProject.instance().addMapLayer(layer)
            return layer
        return None

    def resolve_dashboard_layer(
        self,
        layer_name: str,
        config: Optional[DashboardConfig] = None,
    ) -> Optional[Any]:
        """
        Resolve a QgsMapLayer for dashboard rendering respecting canvas_sync_mode:
        - 'dashboard_only' (default): uses isolated self.dashboard_layers, connecting/cloning
          on demand with labels disabled so main QGIS canvas layers/styles never bleed through.
        - 'sync_main_canvas': resolves directly from QgsProject.instance().
        """
        lname = str(layer_name or "").strip()
        if not lname:
            return None
        sync_main = (
            str(getattr(config, "canvas_sync_mode", "") or self.active_sync_mode or "dashboard_only")
            == "sync_main_canvas"
        )
        if sync_main:
            proj_lyr = self._find_project_qgis_layer_by_name(lname)
            if proj_lyr is not None:
                return proj_lyr
            if config is not None:
                ds = next((d for d in config.data_sources if d.name == lname), None)
                if ds is not None:
                    return self._load_missing_qgis_layer_from_ds(ds, add_to_project=True)
            return None

        iso = self.dashboard_layers.get(lname)
        if iso is not None:
            try:
                _ = iso.name() if hasattr(iso, "name") else lname
                return iso
            except RuntimeError:
                self.dashboard_layers.pop(lname, None)

        if config is not None:
            ds = next((d for d in config.data_sources if d.name == lname), None)
            if ds is not None:
                loaded = self._load_missing_qgis_layer_from_ds(ds, add_to_project=False)
                if loaded is not None:
                    return loaded

        proj_lyr = self._find_project_qgis_layer_by_name(lname)
        if proj_lyr is not None:
            try:
                cloned = proj_lyr.clone() if hasattr(proj_lyr, "clone") else proj_lyr
            except Exception:
                cloned = proj_lyr
            if cloned is not None:
                if hasattr(cloned, "setLabelsEnabled"):
                    try:
                        cloned.setLabelsEnabled(False)
                    except Exception:
                        pass
                self.dashboard_layers[lname] = cloned
                return cloned
        return None

    def hydrate_all_sources(
        self,
        config: DashboardConfig,
        project_dir: Optional[str] = None,
        only_referenced: bool = True,
        only_names: Optional[List[str]] = None,
        use_canvas_extent: bool = False,
        force_refresh_sources: bool = False,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        skip_in_memory_joins: bool = False,
        skip_enriched_overlap: bool = False,
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Connect and load ONLY data sources referenced by widgets/slicers (lazy loading)
        unless only_referenced=False, avoiding slow automatic WFS/layer fetches on startup.
        Protects massive layers (e.g. Kataster) with clamped BBOX and feature caps.
        """
        if force_refresh_sources:
            if only_names is not None:
                rm_set = {str(n).strip() for n in only_names if str(n).strip()}
                for nm in rm_set:
                    self.layer_records_cache.pop(nm, None)
                    self.layer_geojson_cache.pop(nm, None)
                    self.layer_stats_cache.pop(nm, None)
                    self.layer_pyramid_cache.pop(nm, None)
                for ds in getattr(config, "data_sources", []) or []:
                    if ds.name in rm_set:
                        self.excel_records_cache.pop(ds.id, None)
                self.spatial_relations_cache.clear()
                self._spatial_relations_decoded.clear()
                self._cross_layer_fid_cache.clear()
            else:
                self.layer_records_cache.clear()
                self.layer_geojson_cache.clear()
                self.layer_stats_cache.clear()
                self.layer_pyramid_cache.clear()
                self.excel_records_cache.clear()
                self.spatial_relations_cache.clear()
                self._spatial_relations_decoded.clear()
                self._cross_layer_fid_cache.clear()
        proj_dir = project_dir or self.get_current_project_dir()
        sync_mode = self.set_sync_mode(getattr(config, "canvas_sync_mode", "dashboard_only"))
        is_sync_main = (sync_mode == "sync_main_canvas")
        self.ensure_referenced_sources_registered(config, project_dir=proj_dir)
        ds_by_id: Dict[str, DataSourceConfig] = {ds.id: ds for ds in config.data_sources}
        if only_names is not None:
            needed = {str(n).strip() for n in only_names if str(n).strip()}
        else:
            needed = self.referenced_layer_names(config) if only_referenced else None
        qgis_layers_by_id: Dict[str, Any] = {}

        if needed is not None and not needed:
            # Blank/unused dashboard: do NOT fetch random layers or WFS features into memory
            return self.layer_records_cache

        target_sources = [
            ds
            for ds in config.data_sources
            if needed is None or ds.name in needed or ds.id in needed
        ]
        extra_qgis_names = [
            name for name in (needed or ()) if not any(ds.name == name for ds in config.data_sources)
        ]
        work_steps: List[Tuple[str, Any]] = []
        for ds in target_sources:
            if ds.source_type in ("excel", "sharepoint_list", "wfs", "wms", "qgis_layer"):
                work_steps.append((ds.source_type, ds))
        for name in extra_qgis_names:
            work_steps.append(("extra_qgis", name))

        total_items = max(1, len(work_steps))
        _last_pct = [-1]

        def _report_pct(pct: int, label: str) -> None:
            if not progress_cb:
                return
            clamped = max(0, min(100, int(pct)))
            if clamped != _last_pct[0] or label:
                _last_pct[0] = clamped
                try:
                    progress_cb(clamped, 100, label)
                except Exception:
                    pass

        def _slice_cb(idx: int, label: str) -> Callable[[int, int], None]:
            base_pct = 2 + int(80 * idx / total_items)
            end_pct = 2 + int(80 * (idx + 1) / total_items)
            span = max(1, end_pct - base_pct)

            def _sub(d: int, t: int) -> None:
                frac = min(1.0, max(0.0, float(d) / float(max(1, t))))
                pct = base_pct + int(round(frac * span))
                if pct != _last_pct[0]:
                    _report_pct(min(99, pct), label)

            return _sub

        # Ensure QGIS map canvas is not zoomed out over the entire globe before adding WFS layers
        if any(ds.source_type == "wfs" for ds in target_sources):
            self.ensure_safe_qgis_extent(config)

        # Determine whether spatial extent clipping is explicitly enabled
        clip_by_extent = bool(use_canvas_extent or getattr(config, "filter_by_map_extent", False))

        # Execute Excel & SharePoint sources before spatial layers so joins are ready
        ordered_steps: List[Tuple[int, str, Any]] = []
        excel_sp = [(k, v) for k, v in work_steps if k in ("excel", "sharepoint_list")]
        spatial_other = [(k, v) for k, v in work_steps if k not in ("excel", "sharepoint_list")]
        for i, (kind, payload) in enumerate(excel_sp + spatial_other):
            ordered_steps.append((i, kind, payload))

        for step_num, kind, item in ordered_steps:
            if cancel_check and cancel_check():
                return self.layer_records_cache
            label = item.name if hasattr(item, "name") else str(item)
            base_pct = 2 + int(80 * step_num / total_items)
            next_pct = 2 + int(80 * (step_num + 1) / total_items)
            _report_pct(base_pct, label)

            if kind == "excel":
                ds = item
                try:
                    cached_excel = self.excel_records_cache.get(ds.id)
                    existing_ex = self.resolve_dashboard_layer(ds.name, config=config)
                    if cached_excel is not None and not force_refresh_sources and existing_ex is not None:
                        records = cached_excel
                        qgs_layer = existing_ex
                    else:
                        excel_path = ds.portable_path
                        if not excel_path and ds.sharepoint_site_url and ds.sharepoint_item_path:
                            sp = SharePointConnector(config.catalog)
                            excel_path = sp.download_remote_excel_to_cache(ds)
                            ds.portable_path = excel_path
                        qgs_layer, records = ExcelConnector.load_as_qgis_layer(
                            ds, project_dir=proj_dir, add_to_project=is_sync_main
                        )
                        if not is_sync_main and qgs_layer is not None:
                            self.dashboard_layers[ds.name] = qgs_layer
                    self.excel_records_cache[ds.id] = records
                    self.layer_records_cache[ds.name] = records
                    if qgs_layer is not None:
                        qgis_layers_by_id[ds.id] = qgs_layer
                except Exception:
                    self.excel_records_cache.setdefault(ds.id, [])
                    self.layer_records_cache.setdefault(ds.name, [])
                _report_pct(next_pct, label)

            elif kind == "sharepoint_list":
                ds = item
                try:
                    if ds.id in self.excel_records_cache and not force_refresh_sources:
                        records = self.excel_records_cache[ds.id]
                    else:
                        sp = SharePointConnector(config.catalog)
                        records = sp.fetch_sharepoint_list_records(ds)
                    self.excel_records_cache[ds.id] = records
                    self.layer_records_cache[ds.name] = records
                except Exception:
                    self.excel_records_cache.setdefault(ds.id, [])
                    self.layer_records_cache.setdefault(ds.name, [])
                _report_pct(next_pct, label)

            elif kind in ("wfs", "wms"):
                ds = item
                is_massive = OgcConnector.is_massive_layer(ds.name, ds.typename_or_layers)
                should_clip = bool(clip_by_extent or ds.restrict_to_bbox or is_massive)
                cap = OgcConnector._effective_source_cap(ds)
                existing_qgis = (
                    self._find_project_qgis_layer_by_name(ds.name)
                    if is_sync_main
                    else self.dashboard_layers.get(ds.name)
                )
                req_bbox = (self._get_safe_wgs84_bbox(config) if should_clip else None)
                sub_cb = _slice_cb(step_num, ds.name) if progress_cb is not None else None

                if (
                    ds.source_type == "wfs"
                    and ds.name not in self.layer_records_cache
                    and not existing_qgis
                    and ds.auth_mode in ("none", "sso_credentials", "bearer")
                ):
                    # Fast non-freezing HTTP GeoJSON hydration (gives both attributes AND polygons!)
                    try:
                        recs, fc = self._call_with_optional_progress(
                            OgcConnector.fetch_wfs_geojson_http,
                            ds,
                            bbox_wgs84=req_bbox,
                            max_features=cap,
                            timeout=45,
                            progress_cb=sub_cb,
                            cancel_check=cancel_check,
                        )
                        if recs:
                            self.layer_records_cache[ds.name] = recs
                            self.layer_geojson_cache[ds.name] = fc
                    except Exception:
                        pass

                qgs_layer = existing_qgis or OgcConnector.connect_qgis_layer(
                    ds,
                    add_to_project=is_sync_main,
                    isolated_store=None if is_sync_main else self.dashboard_layers,
                )
                if qgs_layer is not None:
                    qgis_layers_by_id[ds.id] = qgs_layer
                    if ds.source_type == "wfs" and ds.name not in self.layer_records_cache:
                        ext_rect = (
                            self._get_canvas_extent_in_layer_crs(qgs_layer, clamp_if_wide=is_massive, config=config)
                            if should_clip
                            else None
                        )
                        qgis_cap = cap if is_massive else (cap if cap > 0 else 0)
                        if self._hydrate_single_qgis_layer(
                            qgs_layer,
                            ds.name,
                            max_records=qgis_cap,
                            extent_rect=ext_rect,
                            progress_cb=sub_cb,
                            cancel_check=cancel_check,
                        ):
                            return self.layer_records_cache
                _report_pct(next_pct, ds.name)

            elif kind == "qgis_layer":
                ds = item
                sub_cb = _slice_cb(step_num, ds.name) if progress_cb is not None else None
                already_hydrated = (
                    not force_refresh_sources
                    and ds.name in self.layer_records_cache
                    and ds.name in self.layer_stats_cache
                    and ds.name in self.layer_pyramid_cache
                )
                qgs_layer = self.resolve_dashboard_layer(ds.name, config=config)
                if qgs_layer is None:
                    qgs_layer = self._load_missing_qgis_layer_from_ds(
                        ds, project_dir=proj_dir, add_to_project=is_sync_main
                    )
                if qgs_layer is not None:
                    apply_qgis_simplify_hint(qgs_layer)
                    qgis_layers_by_id[ds.id] = qgs_layer
                    if not already_hydrated:
                        is_massive = OgcConnector.is_massive_layer(ds.name)
                        ext_rect = (
                            self._get_canvas_extent_in_layer_crs(qgs_layer, clamp_if_wide=is_massive, config=config)
                            if (clip_by_extent or is_massive)
                            else None
                        )
                        if self._hydrate_single_qgis_layer(
                            qgs_layer,
                            ds.name,
                            max_records=400 if is_massive else 0,
                            extent_rect=ext_rect,
                            progress_cb=sub_cb,
                            cancel_check=cancel_check,
                        ):
                            return self.layer_records_cache
                _report_pct(next_pct, ds.name)

            elif kind == "extra_qgis":
                name = str(item)
                sub_cb = _slice_cb(step_num, name) if progress_cb is not None else None
                qgs_layer = self.resolve_dashboard_layer(name, config=config)
                if name not in self.layer_records_cache and qgs_layer is not None:
                    apply_qgis_simplify_hint(qgs_layer)
                    is_massive = OgcConnector.is_massive_layer(name)
                    ext_rect = (
                        self._get_canvas_extent_in_layer_crs(qgs_layer, clamp_if_wide=is_massive, config=config)
                        if (clip_by_extent or is_massive)
                        else None
                    )
                    if self._hydrate_single_qgis_layer(
                        qgs_layer,
                        name,
                        max_records=400 if is_massive else 0,
                        extent_rect=ext_rect,
                        progress_cb=sub_cb,
                        cancel_check=cancel_check,
                    ):
                        return self.layer_records_cache
                _report_pct(next_pct, name)

        # 3. Apply Joins (both QgsVectorLayerJoinInfo in QGIS and in-memory record hydration)
        if config.joins:
            _report_pct(84, (target_sources[0].name if target_sources else ""))
        for join_cfg in config.joins:
            excel_rows = self.excel_records_cache.get(join_cfg.source_table_id, [])
            if not excel_rows:
                src_ds = ds_by_id.get(join_cfg.source_table_id)
                if src_ds:
                    excel_rows = self.layer_records_cache.get(src_ds.name, [])

            target_ds = ds_by_id.get(join_cfg.target_layer_id)
            target_name = target_ds.name if target_ds else join_cfg.target_layer_id

            if not skip_in_memory_joins and target_name in self.layer_records_cache and excel_rows:
                self.layer_records_cache[target_name] = ExcelConnector.apply_in_memory_join(
                    self.layer_records_cache[target_name], excel_rows, join_cfg
                )

            # Register native QgsVectorLayerJoinInfo if running inside QGIS
            src_layer = qgis_layers_by_id.get(join_cfg.source_table_id)
            tgt_layer = qgis_layers_by_id.get(join_cfg.target_layer_id) or self._find_qgis_layer_by_name(
                target_name
            )
            if src_layer is not None and tgt_layer is not None:
                self._apply_qgis_layer_join(src_layer, tgt_layer, join_cfg)

        # 4. Enrich spatial overlap statistics only when overlap_* fields are actually used
        _report_pct(87, "")
        if not skip_enriched_overlap and self.config_uses_natura_pria_overlap(config):
            ov_cb = _slice_cb(total_items - 1, "overlap") if progress_cb is not None else None
            self._enrich_natura_pria_overlap(
                qgis_layers_by_id,
                progress_cb=ov_cb,
                cancel_check=cancel_check,
                force_refresh=force_refresh_sources,
            )

        # 5. Precompute & cache summary statistics + LOD-0 pyramid for loaded vector layers
        stat_items = [(ln, recs) for ln, recs in self.layer_records_cache.items() if recs is not None]
        n_stats = max(1, len(stat_items))
        for si, (ln, recs) in enumerate(stat_items):
            if cancel_check and cancel_check():
                return self.layer_records_cache
            _report_pct(89 + int(9 * si / n_stats), ln)
            qgs_layer = self._find_qgis_layer_by_name(ln)
            if ln not in self.layer_stats_cache or force_refresh_sources:
                old_qstyle = (self.layer_stats_cache.get(ln) or {}).get("qgis_style")
                st = compute_layer_statistics(recs, layer_name=ln)
                if is_sync_main:
                    qstyle = self.extract_qgis_layer_style(qgs_layer) if qgs_layer is not None else (old_qstyle or {})
                    if qstyle:
                        st["qgis_style"] = qstyle
                self.layer_stats_cache[ln] = st
            existing_pyr = self.layer_pyramid_cache.get(ln) or {}
            existing_lod0 = existing_pyr.get("lod0")
            is_nonpoint = self._layer_has_nonpoint_geometry(ln, recs=recs, qgs_layer=qgs_layer)
            if is_nonpoint:
                if existing_lod0 and not self._is_point_only_lod0(existing_lod0):
                    lod0 = existing_lod0
                elif ln in self.layer_geojson_cache and (self.layer_geojson_cache[ln] or {}).get("features"):
                    lod0 = build_lod0_polygon_pyramid_from_geojson(
                        self.layer_geojson_cache[ln]["features"],
                        layer_name=ln,
                        max_features=3200,
                        tolerance_deg=0.0008,
                    )
                elif qgs_layer is not None and hasattr(qgs_layer, "getFeatures"):
                    lod0 = extract_lod0_polygon_pyramid_from_qgis_layer(
                        qgs_layer,
                        layer_name=ln,
                        max_features=3200,
                        tolerance_deg=0.0008,
                        progress_cb=_slice_cb(total_items - 1, ln) if progress_cb else None,
                        cancel_check=cancel_check,
                    )
                else:
                    lod0 = None
            else:
                lod0 = existing_lod0 if existing_lod0 else build_lod0_grid_pyramid(recs, layer_name=ln)
            self.layer_pyramid_cache[ln] = {
                "lod0": lod0,
                "lod1": existing_pyr.get("lod1"),
            }

        _report_pct(100, "")
        return self.layer_records_cache

    def snapshot_qgis_layer_specs(
        self,
        config: DashboardConfig,
        only_referenced: bool = True,
        only_names: Optional[Any] = None,
        force_refresh_sources: bool = False,
        include_cached: bool = False,
    ) -> Dict[str, Any]:
        """
        Capture lightweight QGIS layer metadata & QgsCoordinateTransformContext on the main
        GUI thread so file/DB-backed layers can be safely extracted on a background worker thread.
        """
        specs: Dict[str, Dict[str, Any]] = {}
        tctx = None
        ellipsoid = "GRS80"
        is_sync_main = (
            self.set_sync_mode(getattr(config, "canvas_sync_mode", "dashboard_only"))
            == "sync_main_canvas"
        )
        ds_by_name: Dict[str, DataSourceConfig] = {
            ds.name: ds for ds in getattr(config, "data_sources", []) if ds.name
        }
        if only_names is not None:
            needed: Optional[set] = {str(n).strip() for n in only_names if str(n).strip()}
        else:
            needed = self.referenced_layer_names(config) if only_referenced else None
        if needed is not None and not needed:
            return {"specs": specs, "transform_context": None, "ellipsoid": ellipsoid}

        candidate_names: List[str] = []
        for ds in getattr(config, "data_sources", []):
            if needed is None or ds.name in needed or ds.id in needed:
                if ds.name and ds.name not in candidate_names:
                    candidate_names.append(ds.name)
        for nm in needed or ():
            if nm and nm not in candidate_names:
                candidate_names.append(nm)

        try:
            from qgis.core import QgsCoordinateTransformContext, QgsProject

            proj = QgsProject.instance()
            tctx = QgsCoordinateTransformContext(proj.transformContext())
            ellipsoid = proj.ellipsoid() or "GRS80"
        except Exception:
            tctx = None

        for name in candidate_names:
            ds_obj = ds_by_name.get(name)
            if not is_sync_main and ds_obj is not None and ds_obj.source_type == "wfs":
                lyr = self.dashboard_layers.get(name)
            else:
                lyr = self.resolve_dashboard_layer(name, config=config)
            if lyr is None or not hasattr(lyr, "getFeatures"):
                continue
            qstyle = self.extract_qgis_layer_style(lyr) if is_sync_main else {}
            if qstyle and name in self.layer_stats_cache and isinstance(self.layer_stats_cache[name], dict):
                self.layer_stats_cache[name]["qgis_style"] = qstyle
            is_cached = bool(
                not force_refresh_sources
                and name in self.layer_records_cache
                and name in self.layer_stats_cache
                and name in self.layer_pyramid_cache
            )
            if is_cached and not include_cached:
                continue
            try:
                prov = str(lyr.providerType() if hasattr(lyr, "providerType") else "").lower()
                src = str(lyr.source() if hasattr(lyr, "source") else "")
                is_mod = bool(hasattr(lyr, "isModified") and lyr.isModified())
                can_bg = bool(prov in self._BG_SAFE_QGIS_PROVIDERS and src and not is_mod)
                specs[name] = {
                    "name": name,
                    "source": src,
                    "provider": prov,
                    "is_modified": is_mod,
                    "can_bg_read": can_bg,
                    "is_massive": OgcConnector.is_massive_layer(name),
                    "has_qgis_layer": True,
                    "qgis_style": qstyle,
                    "inferred_wfs": OgcConnector.infer_wfs_datasource_from_qgis_layer(lyr),
                }
            except Exception:
                continue
        return {"specs": specs, "transform_context": tctx, "ellipsoid": ellipsoid}

    def _postprocess_bg_results(
        self,
        config: DashboardConfig,
        out: Dict[str, Any],
        specs: Dict[str, Dict[str, Any]],
        transform_context: Any,
        ellipsoid: str,
        report_fn: Callable[[int, str], None],
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> None:
        """Apply joins, domain fields, and Natura-PRIA spatial overlap inside background worker."""
        from .spatial_overlap import (
            compute_geojson_overlap_for_natura,
            enrich_natura_pria_overlap_qgis,
            enrich_records_domain_fields,
        )

        if str(getattr(config, "canvas_sync_mode", "dashboard_only") or "dashboard_only") == "sync_main_canvas":
            for lname, st in out["layer_stats"].items():
                qst = (specs.get(lname) or {}).get("qgis_style")
                if qst and isinstance(st, dict) and not st.get("qgis_style"):
                    st["qgis_style"] = qst

        ds_by_id: Dict[str, DataSourceConfig] = {ds.id: ds for ds in getattr(config, "data_sources", [])}
        if getattr(config, "joins", None):
            report_fn(86, "")
            for join_cfg in config.joins:
                if cancel_check and cancel_check():
                    out["cancelled"] = True
                    return
                excel_rows = out["excel_records"].get(join_cfg.source_table_id)
                if excel_rows is None:
                    excel_rows = self.excel_records_cache.get(join_cfg.source_table_id)
                if not excel_rows:
                    src_ds = ds_by_id.get(join_cfg.source_table_id)
                    if src_ds:
                        excel_rows = (
                            out["layer_records"].get(src_ds.name)
                            or self.layer_records_cache.get(src_ds.name, [])
                        )
                target_ds = ds_by_id.get(join_cfg.target_layer_id)
                target_name = target_ds.name if target_ds else join_cfg.target_layer_id
                target_recs = out["layer_records"].get(target_name)
                if target_recs is None and target_name in self.layer_records_cache:
                    target_recs = list(self.layer_records_cache[target_name])
                if target_recs is not None and excel_rows:
                    joined = ExcelConnector.apply_in_memory_join(target_recs, excel_rows, join_cfg)
                    out["layer_records"][target_name] = joined
                    st_old = out["layer_stats"].get(target_name) or self.layer_stats_cache.get(target_name) or {}
                    st_new = compute_layer_statistics(joined, layer_name=target_name)
                    if st_old.get("qgis_style"):
                        st_new["qgis_style"] = st_old["qgis_style"]
                    out["layer_stats"][target_name] = st_new
            out["joins_applied"] = True

        merged_recs: Dict[str, List[Dict[str, Any]]] = {}
        merged_recs.update(self.layer_records_cache)
        merged_recs.update(out["layer_records"])
        natura_name: Optional[str] = None
        pria_name: Optional[str] = None
        for lname, recs in merged_recs.items():
            if not recs:
                continue
            if lname in out["layer_records"]:
                enrich_records_domain_fields(recs)
            if any("pohityyp" in r for r in recs[:5]):
                natura_name = lname
            if any("parandniidu_tyyp" in r for r in recs[:5]):
                pria_name = lname

        if natura_name and pria_name and natura_name in out["layer_records"] and self.config_uses_natura_pria_overlap(config):
            nat_recs = out["layer_records"][natura_name]
            needs_ov = bool(
                nat_recs
                and (
                    "overlap_pria_ha" not in nat_recs[0]
                    or (
                        any(float(r.get("overlap_pria_ha") or 0) > 0 for r in nat_recs)
                        and not any("_pria_ov" in r for r in nat_recs)
                    )
                )
            )
            did_enrich = not needs_ov
            if needs_ov:
                report_fn(88, natura_name)
                nat_spec = specs.get(natura_name) or {}
                pria_spec = specs.get(pria_name) or {}
                done_qgis_ov = False
                def _ov_prog(d: int, t: int) -> None:
                    frac = min(1.0, max(0.0, float(d) / float(max(1, t))))
                    report_fn(88 + int(round(frac * 10)), natura_name)

                if nat_spec.get("can_bg_read") and pria_spec.get("can_bg_read"):
                    bg_nat = None
                    bg_pria = None
                    try:
                        bg_nat = self._open_isolated_qgis_vector_layer(nat_spec, natura_name)
                        bg_pria = self._open_isolated_qgis_vector_layer(pria_spec, pria_name)
                        if bg_nat is not None and bg_pria is not None:
                            enrich_natura_pria_overlap_qgis(
                                bg_nat,
                                nat_recs,
                                bg_pria,
                                transform_context=transform_context,
                                ellipsoid=ellipsoid,
                                progress_cb=_ov_prog,
                                cancel_check=cancel_check,
                                pria_records=merged_recs.get(pria_name),
                            )
                            done_qgis_ov = True
                            did_enrich = True
                    finally:
                        bg_nat = None
                        bg_pria = None
                if not done_qgis_ov and not (cancel_check and cancel_check()):
                    nat_fc = out["layer_geojson"].get(natura_name) or self.layer_geojson_cache.get(natura_name) or {}
                    pria_fc = out["layer_geojson"].get(pria_name) or self.layer_geojson_cache.get(pria_name) or {}
                    nat_feats = list(nat_fc.get("features") or [])
                    pria_feats = list(pria_fc.get("features") or [])
                    if nat_feats and pria_feats:
                        ov_res = compute_geojson_overlap_for_natura(
                            nat_feats,
                            pria_feats,
                            progress_cb=_ov_prog,
                            cancel_check=cancel_check,
                        )
                        if isinstance(ov_res, dict) and ov_res.get("cancelled"):
                            out["cancelled"] = True
                            return
                        by_fid: Dict[Any, Dict[str, Any]] = {}
                        for nf in nat_feats:
                            p = nf.get("properties") or {}
                            fid = p.get("_feature_id", nf.get("id"))
                            if fid is not None:
                                by_fid[str(fid)] = p
                        for rec in nat_recs:
                            ov_p = by_fid.get(str(rec.get("_feature_id")))
                            if ov_p:
                                for k in ("overlap_pria_ha", "overlap_mn_ha", "overlap_pn_ha", "overlap_pct", "_pria_ov"):
                                    if k in ov_p:
                                        rec[k] = ov_p[k]
                        did_enrich = True
                if cancel_check and cancel_check():
                    out["cancelled"] = True
                    return
                st_old = out["layer_stats"].get(natura_name) or {}
                st_new = compute_layer_statistics(nat_recs, layer_name=natura_name)
                if st_old.get("qgis_style"):
                    st_new["qgis_style"] = st_old["qgis_style"]
                out["layer_stats"][natura_name] = st_new
                out["layer_pyramids"].get(natura_name, {}).pop("lod1", None)
            fb_layers = set(out.get("fallback_qgis_layers") or [])
            if did_enrich and natura_name not in fb_layers and pria_name not in fb_layers:
                out["overlap_enriched"] = True
        elif not out.get("fallback_qgis_layers"):
            out["overlap_enriched"] = True

    def fetch_remote_sources_bg(
        self,
        config: DashboardConfig,
        wgs84_bbox: Optional[Tuple[float, float, float, float]] = None,
        project_dir: Optional[str] = None,
        only_referenced: bool = True,
        only_names: Optional[Any] = None,
        force_refresh_sources: bool = False,
        existing_qgis_names: Optional[set] = None,
        qgis_layer_specs: Optional[Dict[str, Dict[str, Any]]] = None,
        transform_context: Any = None,
        ellipsoid: str = "GRS80",
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> Dict[str, Any]:
        """
        Thread-safe parallel background worker for WFS GeoJSON, Excel, SharePoint, isolated
        file/DB-backed QGIS vector layers, joins, spatial overlap, and LOD-0/LOD-1 pyramids.
        """
        proj_dir = project_dir or ""
        if only_names is not None:
            needed: Optional[set] = {str(n).strip() for n in only_names if str(n).strip()}
        else:
            needed = self.referenced_layer_names(config) if only_referenced else None
        out: Dict[str, Any] = {
            "layer_records": {},
            "layer_geojson": {},
            "layer_stats": {},
            "layer_pyramids": {},
            "excel_records": {},
            "fallback_qgis_layers": [],
            "joins_applied": False,
            "overlap_enriched": False,
            "cancelled": False,
        }
        if needed is not None and not needed:
            return out

        existing_qgis = existing_qgis_names or set()
        specs = dict(qgis_layer_specs or {})
        target_sources = [
            ds
            for ds in config.data_sources
            if needed is None or ds.name in needed or ds.id in needed
        ]
        target_names = {ds.name for ds in target_sources}
        extra_bg_names = [
            nm
            for nm in (needed or ())
            if nm not in target_names and nm in specs
        ]
        work_items: List[Tuple[str, Any]] = [("ds", ds) for ds in target_sources]
        for nm in extra_bg_names:
            work_items.append(("extra_qgis", nm))

        total_sources = max(1, len(work_items))
        _last_bg_pct = [-1]
        item_fracs = [0.0] * total_sources
        out_lock = threading.Lock()

        def _report(pct: int, label: str, monotonic: bool = False) -> None:
            if not progress_cb:
                return
            with out_lock:
                clamped = max(0, min(100, int(pct)))
                if monotonic and clamped < _last_bg_pct[0]:
                    return
                if clamped != _last_bg_pct[0] or label:
                    _last_bg_pct[0] = max(_last_bg_pct[0], clamped) if monotonic else clamped
                    emit_pct = _last_bg_pct[0]
                else:
                    return
            try:
                progress_cb(emit_pct, 100, label)
            except Exception:
                pass

        def _report_item(item_idx: int, frac: float, label: str) -> None:
            if not progress_cb:
                return
            with out_lock:
                if 0 <= item_idx < len(item_fracs):
                    item_fracs[item_idx] = max(item_fracs[item_idx], min(1.0, max(0.0, float(frac))))
                agg_pct = min(84, 2 + int(round(82.0 * (sum(item_fracs) / float(total_sources)))))
                if agg_pct < _last_bg_pct[0]:
                    agg_pct = _last_bg_pct[0]
                changed = (agg_pct != _last_bg_pct[0]) or bool(label)
                _last_bg_pct[0] = agg_pct
            if changed:
                try:
                    progress_cb(agg_pct, 100, label)
                except Exception:
                    pass

        def _extract_qgis_spec_bg(idx: int, lname: str, spec: Dict[str, Any]) -> bool:
            if not spec.get("can_bg_read"):
                inf_wfs = spec.get("inferred_wfs")
                if (
                    spec.get("provider") == "wfs"
                    and not spec.get("is_modified")
                    and inf_wfs is not None
                    and getattr(inf_wfs, "url", "")
                    and getattr(inf_wfs, "typename_or_layers", "")
                ):
                    return _fetch_wfs_item_bg(idx, inf_wfs, lname)
                with out_lock:
                    if lname not in out["fallback_qgis_layers"]:
                        out["fallback_qgis_layers"].append(lname)
                return False
            bg_lyr = None
            try:
                bg_lyr = self._open_isolated_qgis_vector_layer(spec, lname)
                if bg_lyr is None:
                    with out_lock:
                        if lname not in out["fallback_qgis_layers"]:
                            out["fallback_qgis_layers"].append(lname)
                    return False

                def _sub_q(d: int, t: int) -> None:
                    frac = min(1.0, max(0.0, float(d) / float(max(1, t))))
                    _report_item(idx, frac, lname)

                is_massive = bool(spec.get("is_massive"))
                bundle = OgcConnector.extract_layer_bundle_from_qgis_layer(
                    bg_lyr,
                    layer_name=lname,
                    max_records=400 if is_massive else 0,
                    include_lod0=True,
                    include_lod1=True,
                    transform_context=transform_context,
                    ellipsoid=ellipsoid,
                    progress_cb=_sub_q if progress_cb is not None else None,
                    cancel_check=cancel_check,
                )
                if bundle.get("cancelled"):
                    with out_lock:
                        out["cancelled"] = True
                    return False
                qstyle = spec.get("qgis_style") or self.extract_qgis_layer_style(bg_lyr)
                with out_lock:
                    out["layer_records"][lname] = bundle.get("records") or []
                    if bundle.get("stats") is not None:
                        st = dict(bundle["stats"])
                        if qstyle:
                            st["qgis_style"] = qstyle
                        out["layer_stats"][lname] = st
                    if bundle.get("lod0") or bundle.get("lod1"):
                        pyr_e: Dict[str, Any] = {}
                        if bundle.get("lod0"):
                            pyr_e["lod0"] = bundle["lod0"]
                        if bundle.get("lod1"):
                            pyr_e["lod1"] = bundle["lod1"]
                        out["layer_pyramids"][lname] = pyr_e
                    if bundle.get("initial_geojson"):
                        out["layer_geojson"][lname] = bundle["initial_geojson"]
                return True
            except Exception:
                with out_lock:
                    if lname not in out["fallback_qgis_layers"]:
                        out["fallback_qgis_layers"].append(lname)
                return False
            finally:
                bg_lyr = None

        def _fetch_wfs_item_bg(idx: int, wfs_ds: DataSourceConfig, target_name: str) -> bool:
            if getattr(wfs_ds, "auth_mode", "none") not in ("none", "sso_credentials", "bearer"):
                return False
            if not getattr(wfs_ds, "url", "") or not getattr(wfs_ds, "typename_or_layers", ""):
                return False
            is_massive = OgcConnector.is_massive_layer(target_name, wfs_ds.typename_or_layers)
            should_clip = bool(
                getattr(config, "filter_by_map_extent", False)
                or getattr(wfs_ds, "restrict_to_bbox", False)
                or is_massive
            )
            cap = OgcConnector._effective_source_cap(wfs_ds)

            def _sub_bg(d: int, t: int, _idx: int = idx, _nm: str = target_name) -> None:
                frac = min(1.0, max(0.0, float(d) / float(max(1, t))))
                _report_item(_idx, frac, _nm)

            try:
                recs, fc = self._call_with_optional_progress(
                    OgcConnector.fetch_wfs_geojson_http,
                    wfs_ds,
                    bbox_wgs84=wgs84_bbox if should_clip else None,
                    max_features=cap,
                    timeout=45,
                    progress_cb=_sub_bg if progress_cb is not None else None,
                    cancel_check=cancel_check,
                )
                if cancel_check and cancel_check():
                    with out_lock:
                        out["cancelled"] = True
                    return False
                if recs:
                    st = compute_layer_statistics(recs, layer_name=target_name)
                    feats = (fc or {}).get("features") or []
                    pyr_entry: Dict[str, Any] = {}
                    if feats:
                        if self._layer_has_nonpoint_geometry(target_name, recs=recs):
                            pyr_entry["lod0"] = build_lod0_polygon_pyramid_from_geojson(
                                feats, layer_name=target_name, max_features=3200, tolerance_deg=0.0008
                            )
                        else:
                            pyr_entry["lod0"] = build_lod0_grid_pyramid(recs, layer_name=target_name)
                        if len(recs) <= 95000:
                            lod1_e = build_lod1_compressed_pyramid_from_geojson(feats, max_features=6000)
                            if lod1_e is not None:
                                pyr_entry["lod1"] = lod1_e
                    with out_lock:
                        out["layer_records"][target_name] = recs
                        out["layer_geojson"][target_name] = fc
                        out["layer_stats"][target_name] = st
                        if pyr_entry:
                            out["layer_pyramids"][target_name] = pyr_entry
                    return True
            except Exception:
                pass
            if target_name in specs:
                with out_lock:
                    if target_name not in out["fallback_qgis_layers"]:
                        out["fallback_qgis_layers"].append(target_name)
            return False

        def _run_work_item(idx: int, kind: str, item: Any) -> None:
            if cancel_check and cancel_check():
                with out_lock:
                    out["cancelled"] = True
                return

            if kind == "extra_qgis":
                lname = str(item)
                _report_item(idx, 0.0, lname)
                _extract_qgis_spec_bg(idx, lname, specs.get(lname, {}))
                if not out["cancelled"]:
                    _report_item(idx, 1.0, lname)
                return

            ds = item
            _report_item(idx, 0.0, ds.name)

            if ds.source_type == "qgis_layer":
                if ds.name in specs:
                    _extract_qgis_spec_bg(idx, ds.name, specs[ds.name])
                if not out["cancelled"]:
                    _report_item(idx, 1.0, ds.name)
                return

            if ds.source_type == "excel":
                if not force_refresh_sources and ds.id in self.excel_records_cache:
                    _report_item(idx, 1.0, ds.name)
                    return
                try:
                    excel_path = ds.portable_path
                    if not excel_path and ds.sharepoint_site_url and ds.sharepoint_item_path:
                        sp = SharePointConnector(config.catalog)
                        excel_path = sp.download_remote_excel_to_cache(ds)
                        ds.portable_path = excel_path
                    if excel_path:
                        recs = ExcelConnector.read_records(
                            excel_path, sheet_name=ds.sheet_name, project_dir=proj_dir or None
                        )
                        st = compute_layer_statistics(recs, layer_name=ds.name)
                        with out_lock:
                            out["excel_records"][ds.id] = recs
                            out["layer_records"][ds.name] = recs
                            out["layer_stats"][ds.name] = st
                except Exception:
                    with out_lock:
                        out["excel_records"].setdefault(ds.id, [])
                        out["layer_records"].setdefault(ds.name, [])
                _report_item(idx, 1.0, ds.name)
                return

            if ds.source_type == "sharepoint_list":
                if not force_refresh_sources and ds.id in self.excel_records_cache:
                    _report_item(idx, 1.0, ds.name)
                    return
                try:
                    sp = SharePointConnector(config.catalog)
                    recs = sp.fetch_sharepoint_list_records(ds)
                    st = compute_layer_statistics(recs, layer_name=ds.name)
                    with out_lock:
                        out["excel_records"][ds.id] = recs
                        out["layer_records"][ds.name] = recs
                        out["layer_stats"][ds.name] = st
                except Exception:
                    with out_lock:
                        out["excel_records"].setdefault(ds.id, [])
                        out["layer_records"].setdefault(ds.name, [])
                _report_item(idx, 1.0, ds.name)
                return

            if ds.source_type == "wfs":
                if not force_refresh_sources and ds.name in self.layer_records_cache:
                    _report_item(idx, 1.0, ds.name)
                    return
                eff_ds = ds
                if ds.name in existing_qgis and not force_refresh_sources:
                    spec = specs.get(ds.name) or {}
                    if spec.get("can_bg_read"):
                        _extract_qgis_spec_bg(idx, ds.name, spec)
                        if not out["cancelled"]:
                            _report_item(idx, 1.0, ds.name)
                        return
                    inf_wfs = spec.get("inferred_wfs")
                    if (not eff_ds.url or not eff_ds.typename_or_layers) and inf_wfs is not None:
                        eff_ds = inf_wfs
                    if not (
                        spec.get("provider") == "wfs"
                        and not spec.get("is_modified")
                        and eff_ds.url
                        and eff_ds.typename_or_layers
                        and eff_ds.auth_mode in ("none", "sso_credentials", "bearer")
                    ):
                        if ds.name in specs:
                            with out_lock:
                                if ds.name not in out["fallback_qgis_layers"]:
                                    out["fallback_qgis_layers"].append(ds.name)
                        _report_item(idx, 1.0, ds.name)
                        return
                _fetch_wfs_item_bg(idx, eff_ds, ds.name)
                if not out["cancelled"]:
                    _report_item(idx, 1.0, ds.name)
                return

            _report_item(idx, 1.0, ds.name)

        if len(work_items) <= 1:
            for idx, (kind, item) in enumerate(work_items):
                _run_work_item(idx, kind, item)
                if out["cancelled"]:
                    return out
        else:
            max_workers = min(4, len(work_items))
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futs = [
                    pool.submit(_run_work_item, idx, kind, item)
                    for idx, (kind, item) in enumerate(work_items)
                ]
                for fut in as_completed(futs):
                    try:
                        fut.result()
                    except Exception:
                        pass
                    if cancel_check and cancel_check():
                        out["cancelled"] = True
                        for rem in futs:
                            rem.cancel()
                        break

        if out["cancelled"] or (cancel_check and cancel_check()):
            out["cancelled"] = True
            return out

        self._postprocess_bg_results(
            config=config,
            out=out,
            specs=specs,
            transform_context=transform_context,
            ellipsoid=ellipsoid,
            report_fn=lambda pct, lbl: _report(pct, lbl, monotonic=True),
            cancel_check=cancel_check,
        )
        if out["cancelled"]:
            return out

        _report(100, "", monotonic=True)
        return out

    def export_spatial_relations_for_html(
        self,
        config: DashboardConfig,
        allow_qgis_lookup: bool = True,
        only_layers: Optional[Set[str]] = None,
        progress_cb: Optional[Callable[[int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Precompute exact spatial intersection graphs for all connected layer pairs.
        Uses QGIS GEOS when valid vector layers exist; falls back to complete exact
        GeoJSON geometries (`lod >= 3`), and marks incomplete pairs unavailable instead
        of fabricating overlaps from bounding boxes or simplified pyramids.
        """
        pairs = discover_connected_layer_pairs(config)
        if only_layers is not None:
            only_norm = {str(x).strip() for x in only_layers if str(x).strip()}
            pairs = [(a, b) for (a, b) in pairs if a in only_norm and b in only_norm]
        if not pairs:
            return []

        def _geojson_map(ln: str) -> Dict[str, Dict[str, Any]]:
            out: Dict[str, Dict[str, Any]] = {}
            fc = self.layer_geojson_cache.get(ln) or {}
            for feat in fc.get("features") or []:
                if not isinstance(feat, dict):
                    continue
                g = feat.get("geometry")
                if not isinstance(g, dict):
                    continue
                props = feat.get("properties") or {}
                fk = feat.get("id") if feat.get("id") is not None else props.get("_feature_id")
                if fk is not None:
                    out[str(fk)] = g
            return out

        relations_out: List[Dict[str, Any]] = []
        n_pairs = max(1, len(pairs))
        for idx, (la, lb) in enumerate(pairs):
            if cancel_check and cancel_check():
                break
            if callable(progress_cb):
                progress_cb(int(round(100 * idx / n_pairs)), f"{la} ↔ {lb}")
            pair_key = _sr_pair_key(la, lb)
            recs_a = self.layer_records_cache.get(la)
            recs_b = self.layer_records_cache.get(lb)
            cached = self.spatial_relations_cache.get(pair_key)
            if (
                isinstance(cached, dict)
                and cached.get("complete")
                and cached.get("_rev") == self._preview_cache_rev
                and (recs_a is None or int(cached.get("count_a", -1)) == len(recs_a))
                and (recs_b is None or int(cached.get("count_b", -1)) == len(recs_b))
            ):
                relations_out.append({k: v for k, v in cached.items() if k != "_rev"})
                continue

            q_a = self._find_qgis_layer_by_name(la) if allow_qgis_lookup else None
            q_b = self._find_qgis_layer_by_name(lb) if allow_qgis_lookup else None
            rel: Dict[str, Any]
            if (
                q_a is not None
                and q_b is not None
                and getattr(q_a, "isSpatial", lambda: False)()
                and getattr(q_b, "isSpatial", lambda: False)()
            ):
                def _sub_cb(pct: int, lbl: str) -> None:
                    if callable(progress_cb):
                        base = int(round(100 * idx / n_pairs))
                        span = max(1, int(round(100 / n_pairs)))
                        progress_cb(min(99, base + int(pct * span / 100)), lbl)

                rel = compute_exact_spatial_relation_qgis(
                    la, q_a, recs_a, lb, q_b, recs_b, progress_cb=_sub_cb, cancel_check=cancel_check
                )
            else:
                ga = _geojson_map(la)
                gb = _geojson_map(lb)
                rel = compute_exact_spatial_relation_geojson(
                    la, recs_a or [], ga, lb, recs_b or [], gb
                )

            cached_copy = dict(rel)
            cached_copy["_rev"] = self._preview_cache_rev
            self.spatial_relations_cache[pair_key] = cached_copy
            self._spatial_relations_decoded.pop(pair_key, None)
            relations_out.append({k: v for k, v in rel.items() if k != "_rev"})

        if callable(progress_cb):
            progress_cb(100, "")
        return relations_out

    def resolve_cross_layer_matching_fids(
        self,
        flt: Any,
        target_layer: str,
        target_records: List[Dict[str, Any]],
    ) -> Optional[set]:
        """
        Resolve which target layer `_feature_id` values spatially intersect the
        currently selected features of `flt` (supporting merged multi-layer sources
        by computing the spatial union across all source layers).
        """
        res = self.resolve_cross_layer_result(flt, target_layer, target_records)
        if res is None:
            return None
        return res.get("allowed")

    def resolve_cross_layer_result(
        self,
        flt: Any,
        target_layer: str,
        target_records: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """
        Resolve exact spatial intersection (`allowed`, `clipped_areas`, `unavailable`)
        between `flt` and `target_layer`, merging sources when `flt` spans multiple layers.
        """
        if not target_layer or not target_records:
            return None
        from .filter_bus import ActiveFilter

        raw_sources = (
            flt.target_sources()
            if hasattr(flt, "target_sources")
            else [(str(getattr(flt, "layer_name", "") or ""), str(getattr(flt, "field_name", "") or ""))]
        )
        ext_sources = [(ln, fn) for ln, fn in raw_sources if ln and ln != target_layer]
        if not ext_sources:
            return None

        def _make_proxy(sl_name: str, sl_field: str) -> ActiveFilter:
            return ActiveFilter(
                source_id=str(getattr(flt, "source_id", "") or ""),
                layer_name=sl_name,
                field_name=sl_field,
                filter_type=str(getattr(flt, "filter_type", "category") or "category"),
                values=list(getattr(flt, "values", []) or []),
                min_value=getattr(flt, "min_value", None),
                max_value=getattr(flt, "max_value", None),
                bbox=getattr(flt, "bbox", None),
                geometry=getattr(flt, "geometry", None),
                display_label=str(getattr(flt, "display_label", "") or ""),
                page_id=str(getattr(flt, "page_id", "page_1") or "page_1"),
                is_global=bool(getattr(flt, "is_global", False)),
            )

        if len(ext_sources) > 1 or getattr(flt, "layer_fields", None):
            union_fids: set = set()
            union_clipped: Dict[str, float] = {}
            saw_any = False
            any_unavail = False
            tgt_max_by_fid: Dict[str, float] = {}
            for tr in target_records:
                tfid = tr.get("_feature_id")
                if tfid is not None:
                    try:
                        tgt_max_by_fid[str(tfid)] = float(
                            tr.get("_geom_area_ha") if tr.get("_geom_area_ha") is not None else (tr.get("area_ha") or 0.0)
                        )
                    except (TypeError, ValueError):
                        pass
            for sl_name, sl_field in ext_sources:
                sub = self._resolve_single_source_result(
                    _make_proxy(sl_name, sl_field), target_layer, target_records
                )
                if sub is not None:
                    saw_any = True
                    if sub.get("unavailable"):
                        any_unavail = True
                        continue
                    sub_allowed = sub.get("allowed")
                    if sub_allowed:
                        union_fids.update(sub_allowed)
                    sub_clip = sub.get("clipped_areas")
                    if isinstance(sub_clip, dict):
                        for fid_k, ha_v in sub_clip.items():
                            prev = union_clipped.get(fid_k, 0.0)
                            cand = prev + float(ha_v)
                            max_t = tgt_max_by_fid.get(fid_k, 0.0)
                            union_clipped[fid_k] = min(max_t, cand) if max_t > 0 else cand
            if not saw_any:
                return None
            if any_unavail and not union_fids:
                return {"allowed": set(), "clipped_areas": None, "unavailable": True}
            return {
                "allowed": union_fids,
                "clipped_areas": union_clipped if union_clipped else None,
                "unavailable": False,
            }

        return self._resolve_single_source_result(flt, target_layer, target_records)

    def _resolve_single_source_result(
        self,
        flt: Any,
        target_layer: str,
        target_records: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """Resolve exact intersecting target FIDs and clipped areas for one source layer."""
        source_layer = str(getattr(flt, "layer_name", "") or "")
        if not source_layer or not target_layer or source_layer == target_layer or not target_records:
            return None

        src_records = self.layer_records_cache.get(source_layer, [])
        if not src_records:
            return {"allowed": set(), "clipped_areas": None, "unavailable": True, "reason": "missing_source_records"}

        cache = getattr(self, "_cross_layer_fid_cache", None)
        if cache is None:
            cache = {}
            self._cross_layer_fid_cache = cache

        vals_key = tuple(str(v) for v in (getattr(flt, "values", None) or ()))
        cache_key = (
            source_layer,
            target_layer,
            str(getattr(flt, "field_name", "") or ""),
            str(getattr(flt, "filter_type", "") or ""),
            vals_key,
            str(getattr(flt, "min_value", "")),
            str(getattr(flt, "max_value", "")),
            id(src_records),
            len(src_records),
            id(target_records),
            len(target_records),
            getattr(self, "_preview_cache_rev", 0),
        )
        cached_val = cache.get(cache_key)
        if isinstance(cached_val, dict):
            return cached_val

        from .filter_bus import FilterBus

        matching_src = [r for r in src_records if FilterBus._row_matches_filter(r, flt, layer_name=source_layer)]
        if not matching_src:
            res = {"allowed": set(), "clipped_areas": None, "unavailable": False}
            cache[cache_key] = res
            return res

        # Build max target area map for safe upper clamping
        tgt_max_by_fid: Dict[str, float] = {}
        for tr in target_records:
            tfid = tr.get("_feature_id")
            if tfid is not None:
                try:
                    raw_m = tr.get("_geom_area_ha") if tr.get("_geom_area_ha") is not None else tr.get("area_ha")
                    if raw_m is not None:
                        tgt_max_by_fid[str(tfid)] = float(raw_m)
                except (TypeError, ValueError):
                    pass

        # Tier 0: Verified precomputed exact spatial relation graph
        pair_key = _sr_pair_key(source_layer, target_layer)
        sr_entry = self.spatial_relations_cache.get(pair_key)
        if (
            isinstance(sr_entry, dict)
            and sr_entry.get("complete")
            and sr_entry.get("exact")
            and sr_entry.get("_rev") == getattr(self, "_preview_cache_rev", 1)
        ):
            decoded = self._spatial_relations_decoded.get(pair_key)
            if decoded is None:
                decoded = decompress_spatial_relation(sr_entry)
                if decoded is not None:
                    self._spatial_relations_decoded[pair_key] = decoded
            if decoded is not None:
                adj = decoded["by_a"] if source_layer == sr_entry.get("layer_a") else decoded["by_b"]
                both_poly = sr_entry.get("geom_kind_a") == "polygon" and sr_entry.get("geom_kind_b") == "polygon"
                allowed: set = set()
                clipped_areas: Dict[str, float] = {}
                for sr in matching_src:
                    sfid = sr.get("_feature_id")
                    if sfid is None:
                        continue
                    for tfid, ha in adj.get(str(sfid), ()):
                        allowed.add(tfid)
                        if both_poly and ha >= 0:
                            nxt = clipped_areas.get(tfid, 0.0) + float(ha)
                            max_t = tgt_max_by_fid.get(tfid, 0.0)
                            clipped_areas[tfid] = min(max_t, nxt) if max_t > 0 else nxt
                res = {
                    "allowed": allowed,
                    "clipped_areas": clipped_areas if both_poly else None,
                    "unavailable": False,
                }
                cache[cache_key] = res
                return res

        # Tier 1: Live QGIS GEOS engine (supports WFS string FIDs & integer FIDs cleanly)
        try:
            src_qgis = self._find_qgis_layer_by_name(source_layer)
            tgt_qgis = self._find_qgis_layer_by_name(target_layer)
            if (
                src_qgis is not None
                and tgt_qgis is not None
                and hasattr(src_qgis, "getFeatures")
                and hasattr(tgt_qgis, "getFeatures")
                and getattr(src_qgis, "isSpatial", lambda: False)()
                and getattr(tgt_qgis, "isSpatial", lambda: False)()
            ):
                from qgis.core import (
                    QgsCoordinateReferenceSystem,
                    QgsCoordinateTransform,
                    QgsFeature as _QF,
                    QgsFeatureRequest,
                    QgsGeometry,
                    QgsProject,
                    QgsSpatialIndex,
                )
                from .spatial_overlap import QgisCartesianAreaCalculator, is_qgis_planar_metric_crs

                fc_src = int(src_qgis.featureCount()) if hasattr(src_qgis, "featureCount") else -1
                fc_tgt = int(tgt_qgis.featureCount()) if hasattr(tgt_qgis, "featureCount") else -1
                if (fc_src >= 0 and len(src_records) != fc_src) or (fc_tgt >= 0 and len(target_records) != fc_tgt):
                    return {
                        "allowed": set(),
                        "clipped_areas": None,
                        "unavailable": True,
                        "reason": "incomplete_layer_records",
                    }

                src_fmap = build_qgis_fid_to_record_key_map(src_qgis, src_records)
                rev_src = {k: qf for qf, k in src_fmap.items()}
                tgt_fmap = build_qgis_fid_to_record_key_map(tgt_qgis, target_records)

                src_qids: List[int] = []
                for sr in matching_src:
                    fid_val = sr.get("_feature_id")
                    if fid_val is None:
                        continue
                    fid_s = str(fid_val)
                    if fid_s in rev_src:
                        src_qids.append(rev_src[fid_s])
                    elif isinstance(fid_val, int):
                        src_qids.append(fid_val)
                    elif fid_s.lstrip("-").isdigit():
                        src_qids.append(int(fid_s))

                if len(src_qids) == len(matching_src):
                    tctx = QgsProject.instance().transformContext()
                    crs_s = src_qgis.crs()
                    crs_t = tgt_qgis.crs()
                    work_crs = crs_s
                    if not is_qgis_planar_metric_crs(crs_s) and is_qgis_planar_metric_crs(crs_t):
                        work_crs = crs_t
                    elif not is_qgis_planar_metric_crs(crs_s) and crs_s.isGeographic():
                        try:
                            ext = src_qgis.extent()
                            if (
                                not ext.isEmpty()
                                and ext.xMaximum() >= 19.0
                                and ext.xMinimum() <= 31.0
                                and ext.yMaximum() >= 56.0
                                and ext.yMinimum() <= 62.0
                            ):
                                est = QgsCoordinateReferenceSystem("EPSG:3301")
                                if est.isValid():
                                    work_crs = est
                        except Exception:
                            pass

                    xf_s = QgsCoordinateTransform(crs_s, work_crs, tctx) if crs_s.isValid() and work_crs.isValid() and crs_s != work_crs else None
                    xf_t = QgsCoordinateTransform(crs_t, work_crs, tctx) if crs_t.isValid() and work_crs.isValid() and crs_t != work_crs else None
                    area_calc = QgisCartesianAreaCalculator(work_crs, tctx, layer=src_qgis)

                    def _make_noattr_req():
                        req = QgsFeatureRequest()
                        fcls = getattr(QgsFeatureRequest, "Flags", QgsFeatureRequest)
                        if hasattr(QgsFeatureRequest, "NoAttributes"):
                            req.setFlags(QgsFeatureRequest.NoAttributes)
                        elif hasattr(fcls, "NoAttributes"):
                            req.setFlags(fcls.NoAttributes)
                        return req

                    sreq = _make_noattr_req().setFilterFids(src_qids)
                    src_idx = QgsSpatialIndex()
                    src_geom_by_id: Dict[int, Any] = {}
                    union_rect = None
                    for feat in src_qgis.getFeatures(sreq):
                        if not feat.hasGeometry():
                            continue
                        g = QgsGeometry(feat.geometry())
                        if g.isEmpty():
                            continue
                        if xf_s is not None:
                            g.transform(xf_s)
                        tf = _QF()
                        tf.setId(feat.id())
                        tf.setGeometry(g)
                        src_idx.addFeature(tf)
                        src_geom_by_id[feat.id()] = g
                        bb = g.boundingBox()
                        if union_rect is None:
                            union_rect = bb
                        else:
                            union_rect.combineExtentWith(bb)

                    if union_rect is not None and src_geom_by_id:
                        both_polys = int(src_qgis.geometryType()) == 2 and int(tgt_qgis.geometryType()) == 2
                        allowed = set()
                        clipped_areas: Dict[str, float] = {}
                        treq = _make_noattr_req()
                        # Only push FilterRect down to QGIS when transforms match CRS cleanly
                        if xf_t is None:
                            treq.setFilterRect(union_rect)
                        for tfeat in tgt_qgis.getFeatures(treq):
                            if not tfeat.hasGeometry():
                                continue
                            tg = QgsGeometry(tfeat.geometry())
                            if tg.isEmpty():
                                continue
                            if xf_t is not None:
                                tg.transform(xf_t)
                            cand_sids = src_idx.intersects(tg.boundingBox())
                            if not cand_sids:
                                continue
                            hit_geoms = []
                            for sid in cand_sids:
                                sg = src_geom_by_id.get(sid)
                                if sg is None:
                                    continue
                                try:
                                    if sg.intersects(tg):
                                        hit_geoms.append(sg)
                                except Exception:
                                    pass
                            if not hit_geoms:
                                continue
                            tfid_str = tgt_fmap.get(tfeat.id(), str(tfeat.id()))
                            if both_polys:
                                comb = hit_geoms[0] if len(hit_geoms) == 1 else QgsGeometry.unaryUnion(hit_geoms)
                                try:
                                    inter = comb.intersection(tg)
                                except Exception:
                                    inter = None
                                if inter is None or inter.isEmpty():
                                    continue
                                ha_raw = area_calc.measure_ha(inter, decimals=8)
                                if ha_raw <= 1e-6:
                                    continue
                                ha = round(ha_raw, 6)
                                allowed.add(tfid_str)
                                max_t = tgt_max_by_fid.get(tfid_str, 0.0)
                                clipped_areas[tfid_str] = min(max_t, ha) if max_t > 0 else ha
                            else:
                                allowed.add(tfid_str)
                        res = {
                            "allowed": allowed,
                            "clipped_areas": clipped_areas if both_polys else None,
                            "unavailable": False,
                        }
                        cache[cache_key] = res
                        return res
        except Exception:
            pass

        # Tier 2: Strict exact GeoJSON geometries (no fake bbox rectangles!)
        def _geojson_by_fid(layer_nm: str, recs: List[Dict[str, Any]]) -> Dict[str, Any]:
            out_map: Dict[str, Any] = {}
            fc = self.layer_geojson_cache.get(layer_nm) or {}
            for feat in fc.get("features") or []:
                if not isinstance(feat, dict):
                    continue
                geom = feat.get("geometry")
                if not isinstance(geom, dict):
                    continue
                props = feat.get("properties") or {}
                fid_raw = feat.get("id") if feat.get("id") is not None else props.get("_feature_id")
                if fid_raw is not None:
                    out_map[str(fid_raw)] = geom
            for r in recs:
                g_inline = r.get("__geom__")
                fk = r.get("_feature_id")
                if isinstance(g_inline, dict) and fk is not None and str(fk) not in out_map:
                    out_map[str(fk)] = g_inline
            return out_map

        src_geom_map = _geojson_by_fid(source_layer, src_records)
        tgt_geom_map = _geojson_by_fid(target_layer, target_records)

        src_qgis_chk = self._find_qgis_layer_by_name(source_layer)
        tgt_qgis_chk = self._find_qgis_layer_by_name(target_layer)
        src_is_spatial = bool(
            src_geom_map
            or (src_qgis_chk is not None and getattr(src_qgis_chk, "isSpatial", lambda: False)())
            or any(
                (r.get("_lon") is not None and r.get("_lat") is not None) or isinstance(r.get("_bbox"), (list, tuple))
                for r in src_records[:50]
            )
        )
        tgt_is_spatial = bool(
            tgt_geom_map
            or (tgt_qgis_chk is not None and getattr(tgt_qgis_chk, "isSpatial", lambda: False)())
            or any(
                (r.get("_lon") is not None and r.get("_lat") is not None) or isinstance(r.get("_bbox"), (list, tuple))
                for r in target_records[:50]
            )
        )
        if not src_is_spatial or not tgt_is_spatial:
            return None

        src_shapes: List[Tuple[str, Dict[str, Any], Tuple[float, float, float, float]]] = []
        src_is_poly = False
        for sr in matching_src:
            sfid = sr.get("_feature_id")
            sk = str(sfid) if sfid is not None else ""
            sg = src_geom_map.get(sk) if sk else None
            if not isinstance(sg, dict):
                return {
                    "allowed": set(),
                    "clipped_areas": None,
                    "unavailable": True,
                    "reason": "incomplete_source_geometries",
                }
            sbb = geojson_bbox_wgs84(sg)
            if sbb is None:
                continue
            if "polygon" in str(sg.get("type") or "").lower():
                src_is_poly = True
            src_shapes.append((sk, sg, sbb))

        tgt_shapes: List[Tuple[str, Dict[str, Any], Tuple[float, float, float, float]]] = []
        tgt_is_poly = False
        for tr in target_records:
            tfid = tr.get("_feature_id")
            tk = str(tfid) if tfid is not None else ""
            tg = tgt_geom_map.get(tk) if tk else None
            if not isinstance(tg, dict):
                return {
                    "allowed": set(),
                    "clipped_areas": None,
                    "unavailable": True,
                    "reason": "incomplete_target_geometries",
                }
            tbb = geojson_bbox_wgs84(tg)
            if tbb is None:
                continue
            if "polygon" in str(tg.get("type") or "").lower():
                tgt_is_poly = True
            tgt_shapes.append((tk, tg, tbb))

        if not src_shapes or not tgt_shapes:
            res = {"allowed": set(), "clipped_areas": None, "unavailable": False}
            cache[cache_key] = res
            return res

        u0 = min(bb[0] for _, _, bb in src_shapes)
        u1 = min(bb[1] for _, _, bb in src_shapes)
        u2 = max(bb[2] for _, _, bb in src_shapes)
        u3 = max(bb[3] for _, _, bb in src_shapes)
        union_bb = (u0, u1, u2, u3)

        both_polys_g = src_is_poly and tgt_is_poly
        allowed_fids: set = set()
        clipped_g: Dict[str, float] = {}
        for tk, t_geom, t_bb in tgt_shapes:
            if not _bbox_overlaps(t_bb, union_bb):
                continue
            if both_polys_g:
                ha_sum = 0.0
                for _sk, s_geom, s_bb in src_shapes:
                    if _bbox_overlaps(s_bb, t_bb):
                        ha_sum += exact_polygon_intersection_area_ha_geojson(s_geom, t_geom)
                if ha_sum > 1e-6:
                    allowed_fids.add(tk)
                    max_t = tgt_max_by_fid.get(tk, 0.0)
                    ha_r = round(ha_sum, 6)
                    clipped_g[tk] = min(max_t, ha_r) if max_t > 0 else ha_r
            else:
                for _sk, s_geom, s_bb in src_shapes:
                    if _bbox_overlaps(s_bb, t_bb) and geom_intersects_geom(s_geom, t_geom):
                        allowed_fids.add(tk)
                        break

        res = {
            "allowed": allowed_fids,
            "clipped_areas": clipped_g if both_polys_g else None,
            "unavailable": False,
        }
        cache[cache_key] = res
        return res

    def get_static_packaged_layer_names(self, config: DashboardConfig) -> Set[str]:
        """Return layer/source names whose effective browser export state is 'static'."""
        static_names: Set[str] = set()
        if config is None:
            return static_names
        ds_by_name: Dict[str, DataSourceConfig] = {
            str(ds.name): ds for ds in (getattr(config, "data_sources", []) or []) if getattr(ds, "name", "")
        }
        candidate_names: Set[str] = set(self.referenced_layer_names(config) or set())
        candidate_names.update(self.layer_records_cache.keys())
        candidate_names.update(ds_by_name.keys())
        for ln in candidate_names:
            ds = ds_by_name.get(ln)
            if ds is not None:
                if ds.effective_data_state(for_browser_export=True) == "static":
                    static_names.add(ln)
            else:
                static_names.add(ln)
        return static_names

    def export_initial_geojson_for_html(
        self,
        config: DashboardConfig,
        max_features: int = 5000,
        allow_qgis_lookup: bool = True,
        qgis_meta: Optional[Dict[str, Dict[str, Any]]] = None,
        progress_cb: Optional[Callable[[int, str], None]] = None,
        only_layers: Optional[Set[str]] = None,
    ) -> Dict[str, Any]:
        """
        Export true WGS84 GeoJSON polygons/lines for every vector layer on the dashboard
        so exported HTML maps always display real polygons (never fallback centroid points).
        Reuses cached GeoJSON whenever available instead of rescanning live QGIS layers.
        Also auto-registers WFS descriptors for active QGIS WFS layers not yet in data_sources.
        """
        out_geojson: Dict[str, Any] = {}
        candidate_names = list(self.referenced_layer_names(config))
        for ln in self.layer_records_cache.keys():
            if ln not in candidate_names:
                candidate_names.append(ln)
        if only_layers is not None:
            candidate_names = [ln for ln in candidate_names if ln in only_layers]

        known_ds_names = {ds.name for ds in config.data_sources}
        meta_map = qgis_meta or {}
        total_cands = max(1, len(candidate_names))

        for idx, ln in enumerate(candidate_names):
            if callable(progress_cb):
                pct = 15 + int(round(18 * idx / total_cands))
                progress_cb(pct, f"{ln} ({idx + 1}/{len(candidate_names)})")
            meta = meta_map.get(ln) or {}
            cached_fc = self.layer_geojson_cache.get(ln)
            if isinstance(cached_fc, dict) and cached_fc.get("features"):
                out_geojson[ln] = cached_fc
                if ln not in known_ds_names:
                    inferred = meta.get("inferred_wfs")
                    if inferred is None and allow_qgis_lookup:
                        qgs_layer = self._find_qgis_layer_by_name(ln)
                        if qgs_layer is not None:
                            inferred = OgcConnector.infer_wfs_datasource_from_qgis_layer(qgs_layer)
                    if inferred is not None:
                        config.data_sources.append(inferred)
                        known_ds_names.add(ln)
                continue

            qgs_layer = self._find_qgis_layer_by_name(ln) if allow_qgis_lookup else None
            if qgs_layer is not None and hasattr(qgs_layer, "fields"):
                recs = self.layer_records_cache.get(ln) or []
                fids = [r.get("_feature_id") for r in recs if r.get("_feature_id") is not None]
                is_massive = OgcConnector.is_massive_layer(ln)
                limit = 2000 if is_massive else max_features
                need_extent = bool(
                    config.filter_by_map_extent
                    or is_massive
                    or len(fids) > limit
                )
                ext = (
                    self._get_dashboard_initial_extent_in_layer_crs(
                        qgs_layer, clamp_if_wide=is_massive, config=config
                    )
                    if need_extent
                    else None
                )
                fc = OgcConnector.extract_geojson_from_qgis_layer(
                    qgs_layer,
                    max_features=limit,
                    extent_rect=ext,
                    target_fids=fids or None,
                    prioritize_largest=(len(fids) > limit),
                )
                if not fc.get("features") and ext is not None:
                    # Fallback to whole layer sample if configured home center falls outside layer extent
                    fc = OgcConnector.extract_geojson_from_qgis_layer(
                        qgs_layer,
                        max_features=min(limit, 1500),
                        extent_rect=None,
                        target_fids=fids or None,
                        prioritize_largest=True,
                    )
                if fc.get("features"):
                    out_geojson[ln] = fc
                    if ln not in self.layer_geojson_cache or not (self.layer_geojson_cache[ln] or {}).get("features"):
                        self.layer_geojson_cache[ln] = fc

                if ln not in known_ds_names:
                    inferred = OgcConnector.infer_wfs_datasource_from_qgis_layer(qgs_layer)
                    if inferred is not None:
                        config.data_sources.append(inferred)
                        known_ds_names.add(ln)
            elif ln in self.layer_geojson_cache and self.layer_geojson_cache[ln].get("features"):
                out_geojson[ln] = self.layer_geojson_cache[ln]
                if ln not in known_ds_names and meta.get("inferred_wfs") is not None:
                    config.data_sources.append(meta["inferred_wfs"])
                    known_ds_names.add(ln)

        return out_geojson

    def get_or_build_layer_stats(self, layer_name: str) -> Dict[str, Any]:
        """Return cached summary statistics (feature count, bbox, total ha, field stats)."""
        if layer_name in self.layer_stats_cache:
            return self.layer_stats_cache[layer_name]
        recs = self.layer_records_cache.get(layer_name) or []
        st = compute_layer_statistics(recs, layer_name=layer_name)
        self.layer_stats_cache[layer_name] = st
        return st

    def export_pyramids_for_html(
        self,
        config: DashboardConfig,
        include_lod1: bool = True,
        lod1_max_sync_features: int = 95000,
        allow_qgis_lookup: bool = True,
        qgis_meta: Optional[Dict[str, Dict[str, Any]]] = None,
        progress_cb: Optional[Callable[[int, str], None]] = None,
        lod1_layers: Optional[Set[str]] = None,
        skip_overlap_enrich: bool = False,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Return `(layer_stats, vector_pyramids)` for all active vector layers:
        - `lod0`: Spatial grid summary FeatureCollection (< 2,200 cells) for fast zoomed-out views.
        - `lod1`: Gzip-compressed RDP-simplified geometries indexed by feature ID + WGS84 bbox
          for zoomed-in and offline filtered views.
        """
        if allow_qgis_lookup and not skip_overlap_enrich and self.config_uses_natura_pria_overlap(config):
            self._enrich_natura_pria_overlap({}, config=config)
        stats_out: Dict[str, Any] = {}
        pyramids_out: Dict[str, Any] = {}
        meta_map = qgis_meta or {}
        candidate_names = list(self.referenced_layer_names(config))
        for ln in self.layer_records_cache.keys():
            if ln not in candidate_names:
                candidate_names.append(ln)

        is_sync_main = (
            str(getattr(config, "canvas_sync_mode", "dashboard_only") or "dashboard_only")
            == "sync_main_canvas"
        )
        total_cands = max(1, len(candidate_names))
        for idx, ln in enumerate(candidate_names):
            if callable(progress_cb):
                pct = 35 + int(round(42 * idx / total_cands))
                progress_cb(pct, f"{ln} ({idx + 1}/{len(candidate_names)})")
            recs = self.layer_records_cache.get(ln) or []
            meta = meta_map.get(ln) or {}
            qgs_layer = self._find_qgis_layer_by_name(ln) if allow_qgis_lookup else None
            cached_st = self.layer_stats_cache.get(ln) or {}
            has_qgis = bool(
                qgs_layer is not None
                or meta.get("has_qgis_layer")
                or cached_st.get("has_qgis_layer")
            )
            qstyle = (
                (
                    meta.get("qgis_style")
                    or (self.extract_qgis_layer_style(qgs_layer) if qgs_layer is not None else {})
                    or cached_st.get("qgis_style")
                    or {}
                )
                if is_sync_main
                else {}
            )
            if recs:
                st_entry = dict(self.get_or_build_layer_stats(ln))
                st_entry["has_qgis_layer"] = has_qgis
                if qstyle:
                    st_entry["qgis_style"] = qstyle
                elif not is_sync_main:
                    st_entry.pop("qgis_style", None)
                stats_out[ln] = st_entry
            elif has_qgis:
                st_entry = {"has_qgis_layer": True, "feature_count": 0}
                if qstyle:
                    st_entry["qgis_style"] = qstyle
                stats_out[ln] = st_entry

            cached_pyr = self.layer_pyramid_cache.get(ln)
            lod0 = (cached_pyr or {}).get("lod0")
            is_nonpoint = self._layer_has_nonpoint_geometry(ln, recs=recs, qgs_layer=qgs_layer)
            if lod0 and is_nonpoint and self._is_point_only_lod0(lod0):
                lod0 = None
            if not lod0 or not (lod0 or {}).get("features"):
                if qgs_layer is not None and hasattr(qgs_layer, "getFeatures"):
                    lod0 = extract_lod0_polygon_pyramid_from_qgis_layer(
                        qgs_layer, layer_name=ln, max_features=3200, tolerance_deg=0.0008
                    )
                elif ln in self.layer_geojson_cache and self.layer_geojson_cache[ln].get("features"):
                    lod0 = build_lod0_polygon_pyramid_from_geojson(
                        self.layer_geojson_cache[ln]["features"],
                        layer_name=ln,
                        max_features=3200,
                        tolerance_deg=0.0008,
                    )
                if (not lod0 or not lod0.get("features")) and recs and not is_nonpoint:
                    lod0 = build_lod0_grid_pyramid(recs, layer_name=ln)

            lod1 = (cached_pyr or {}).get("lod1")
            fid_key_map: Dict[int, str] = {}
            if qgs_layer is not None and hasattr(qgs_layer, "getFeatures") and recs:
                fid_key_map = build_qgis_fid_to_record_key_map(qgs_layer, recs)
            rev_fid_map: Dict[str, int] = {k: qf for qf, k in fid_key_map.items()}
            prio_fids: List[int] = []
            sr_prio_keys: Set[str] = set()
            for pair_key, sr_obj in (self.spatial_relations_cache or {}).items():
                if not isinstance(sr_obj, dict) or not sr_obj.get("complete") or ln not in pair_key:
                    continue
                dec = self._spatial_relations_decoded.get(pair_key)
                if dec is None:
                    dec = decompress_spatial_relation(sr_obj)
                    if dec is not None:
                        self._spatial_relations_decoded[pair_key] = dec
                if dec is not None:
                    sr_prio_keys.update(dec.get("by_a" if ln == sr_obj.get("layer_a") else "by_b", {}).keys())
            for r in recs:
                rfid_raw = r.get("_feature_id")
                if rfid_raw is None:
                    continue
                rfid_str = str(rfid_raw)
                is_prio = (rfid_str in sr_prio_keys) if sr_prio_keys else (float(r.get("overlap_pria_ha") or 0) > 0)
                if is_prio:
                    if rfid_str in rev_fid_map:
                        prio_fids.append(rev_fid_map[rfid_str])
                    else:
                        try:
                            prio_fids.append(int(rfid_raw))
                        except (TypeError, ValueError):
                            pass
            needs_prio_rebuild = bool(
                prio_fids
                and qgs_layer is not None
                and hasattr(qgs_layer, "getFeatures")
                and not (isinstance(lod1, dict) and lod1.get("_pria_ov_prioritized"))
            )
            needs_fid_align_rebuild = bool(
                lod1 is not None
                and fid_key_map
                and any(k != str(qf) for qf, k in list(fid_key_map.items())[:25])
                and not (isinstance(lod1, dict) and lod1.get("_fid_aligned"))
            )
            need_lod1 = bool(include_lod1 or (lod1_layers is not None and ln in lod1_layers))
            if need_lod1 and (lod1 is None or needs_prio_rebuild or needs_fid_align_rebuild) and len(recs) <= max(lod1_max_sync_features, 100000):
                lod1_sample_cap = min(max(6000, lod1_max_sync_features), 12000)
                if qgs_layer is not None and hasattr(qgs_layer, "getFeatures"):
                    lod1 = extract_lod1_pyramid_from_qgis_layer(
                        qgs_layer,
                        max_features=lod1_sample_cap,
                        priority_fids=prio_fids or None,
                        fid_key_map=fid_key_map or None,
                    )
                    if isinstance(lod1, dict) and prio_fids:
                        lod1["_pria_ov_prioritized"] = True
                elif ln in self.layer_geojson_cache and self.layer_geojson_cache[ln].get("features"):
                    lod1 = build_lod1_compressed_pyramid_from_geojson(
                        self.layer_geojson_cache[ln]["features"],
                        max_features=lod1_sample_cap,
                    )

            if lod0 or lod1:
                entry = {"lod0": lod0} if lod0 else {}
                if lod1:
                    entry["lod1"] = lod1
                self.layer_pyramid_cache[ln] = entry
                pyramids_out[ln] = entry

        return stats_out, pyramids_out

    @staticmethod
    def _feature_wgs84_bbox(feat: Dict[str, Any]) -> Optional[Tuple[float, float, float, float]]:
        geom = feat.get("geometry") or {}
        coords = geom.get("coordinates")
        if isinstance(coords, list) and coords:
            if isinstance(coords[0], (int, float)) and len(coords) >= 2:
                lon, lat = float(coords[0]), float(coords[1])
                return (lon, lat, lon, lat)
            from .vector_pyramid import _bbox_of_rings

            bb = _bbox_of_rings(coords)
            if bb is not None and len(bb) == 4:
                return (float(bb[0]), float(bb[1]), float(bb[2]), float(bb[3]))
        return None

    def invalidate_preview_caches(self) -> int:
        with self._preview_cache_lock:
            self._preview_spatial_index.clear()
            self._preview_spatial_complete.clear()
            self._preview_feature_query_cache.clear()
            self._preview_tile_cache.clear()
            if hasattr(self, "_cross_layer_fid_cache"):
                self._cross_layer_fid_cache.clear()
            self._preview_cache_rev += 1
            return self._preview_cache_rev

    def set_preview_bg_specs(
        self,
        specs: Optional[Dict[str, Dict[str, Any]]],
        transform_context: Any = None,
        ellipsoid: str = "GRS80",
    ) -> None:
        """Store snapshot of BG-safe QGIS layer specs for worker-thread /api/features queries."""
        with self._preview_cache_lock:
            self._preview_bg_specs = {
                str(k): dict(v) for k, v in (specs or {}).items() if isinstance(v, dict)
            }
            if transform_context is not None:
                self._preview_bg_tctx = transform_context
            if ellipsoid:
                self._preview_bg_ellipsoid = str(ellipsoid)

    def can_query_preview_features_in_bg(self, layer_name: str) -> bool:
        """Return True if *layer_name* can be queried via an isolated BG QGIS layer off the GUI thread."""
        with self._preview_cache_lock:
            spec = self._preview_bg_specs.get(str(layer_name))
            return bool(spec and spec.get("can_bg_read") and self._preview_bg_tctx is not None)

    def build_preview_spatial_cache(self, config: Optional[DashboardConfig] = None) -> int:
        """Build thread-safe pure-Python WGS84 spatial index for HTTP worker queries."""
        rev = self.invalidate_preview_caches()
        new_index: Dict[
            str, List[Tuple[str, Optional[Tuple[float, float, float, float]], float, Dict[str, Any]]]
        ] = {}
        new_complete: Dict[str, bool] = {}
        for ln, fc in (self.layer_geojson_cache or {}).items():
            feats = (fc or {}).get("features") or []
            if not feats:
                continue
            entries: List[Tuple[str, Optional[Tuple[float, float, float, float]], float, Dict[str, Any]]] = []
            for f in feats:
                props = f.get("properties") or {}
                fid_raw = f.get("id") if f.get("id") is not None else props.get("_feature_id", "")
                fid_str = str(fid_raw)
                bb = self._feature_wgs84_bbox(f)
                area_ha = float(props.get("_geom_area_ha") or props.get("area_ha") or 0.0)
                entries.append((fid_str, bb, area_ha, f))
            new_index[ln] = entries
            stats = (self.layer_stats_cache or {}).get(ln) or {}
            stats_count = int(stats.get("feature_count") or 0)
            rec_count = len((self.layer_records_cache or {}).get(ln) or [])
            expected_count = max(stats_count, rec_count)
            has_qgis = bool(stats.get("has_qgis_layer")) or bool(
                (self._preview_bg_specs or {}).get(ln)
            )
            # Mark partial GeoJSON samples (e.g. initial_geojson_max=2000 out of 81k) incomplete
            # so get_cached_preview_features falls through to authoritative QGIS layer queries.
            is_complete = (
                (not has_qgis)
                or (expected_count > 0 and len(feats) >= expected_count)
                or (expected_count == 0 and len(feats) < 2000)
            )
            new_complete[ln] = is_complete
        with self._preview_cache_lock:
            self._preview_spatial_index = new_index
            self._preview_spatial_complete = new_complete
        return rev

    @staticmethod
    def _normalize_preview_lod(
        zoom: int = 12,
        scale_denom: Optional[float] = None,
        lod: Optional[int] = None,
    ) -> int:
        eff_lod = lod
        if eff_lod is None:
            if scale_denom is not None and scale_denom > 0:
                if scale_denom <= 55000:
                    eff_lod = 3
                elif scale_denom <= 250000:
                    eff_lod = 2
                else:
                    eff_lod = 1
            else:
                if zoom >= 13:
                    eff_lod = 3
                elif zoom >= 11:
                    eff_lod = 2
                else:
                    eff_lod = 1
        return int(eff_lod)

    def _feature_query_cache_key(
        self,
        layer_name: str,
        target_fids: Optional[List[Any]],
        bbox_wgs84: Optional[Tuple[float, float, float, float]],
        eff_lod: int,
        max_features: int,
    ) -> Tuple[Any, ...]:
        fid_key = tuple(sorted(str(x) for x in target_fids)) if target_fids else ()
        bbox_key = (
            tuple(round(float(v), 4) for v in bbox_wgs84)
            if (bbox_wgs84 is not None and not fid_key)
            else ()
        )
        return (self._preview_cache_rev, layer_name, int(eff_lod), fid_key, bbox_key, int(max_features))

    def get_cached_preview_features(
        self,
        layer_name: str,
        target_fids: Optional[List[Any]] = None,
        bbox_wgs84: Optional[Tuple[float, float, float, float]] = None,
        zoom: int = 12,
        scale_denom: Optional[float] = None,
        lod: Optional[int] = None,
        max_features: int = 3500,
    ) -> Optional[Dict[str, Any]]:
        """Thread-safe lookup in worker thread without touching QGIS main thread."""
        eff_lod = self._normalize_preview_lod(zoom=zoom, scale_denom=scale_denom, lod=lod)
        eff_max = max(int(max_features or 3500), 7500 if eff_lod >= 3 else 4500)
        q_key = self._feature_query_cache_key(layer_name, target_fids, bbox_wgs84, eff_lod, eff_max)
        with self._preview_cache_lock:
            cached = self._preview_feature_query_cache.get(q_key)
            if cached is not None:
                self._preview_feature_query_cache.move_to_end(q_key)
                return cached
            idx_entries = self._preview_spatial_index.get(layer_name)
            is_complete = self._preview_spatial_complete.get(layer_name, True)

        if not idx_entries or not is_complete:
            return None

        if target_fids:
            wanted = {str(x) for x in target_fids}
            matched = [e[3] for e in idx_entries if e[0] in wanted][:eff_max]
        elif bbox_wgs84 is not None:
            bx0, by0, bx1, by1 = bbox_wgs84
            hits = [
                (e[2], e[3])
                for e in idx_entries
                if e[1] is not None
                and not (e[1][2] < bx0 or e[1][0] > bx1 or e[1][3] < by0 or e[1][1] > by1)
            ]
            if eff_lod < 3 and len(hits) > eff_max:
                hits.sort(key=lambda item: item[0], reverse=True)
            matched = [h[1] for h in hits[:eff_max]]
        else:
            matched = [e[3] for e in idx_entries[:eff_max]]

        out = {"type": "FeatureCollection", "features": matched}
        self._store_preview_feature_query_cache(q_key, out)
        return out

    def _store_preview_feature_query_cache(self, q_key: Tuple[Any, ...], fc: Dict[str, Any]) -> None:
        with self._preview_cache_lock:
            self._preview_feature_query_cache[q_key] = fc
            self._preview_feature_query_cache.move_to_end(q_key)
            while len(self._preview_feature_query_cache) > 192:
                self._preview_feature_query_cache.popitem(last=False)

    def get_cached_preview_tile(self, tile_key: Tuple[Any, ...]) -> Optional[bytes]:
        with self._preview_cache_lock:
            hit = self._preview_tile_cache.get(tile_key)
            if hit is not None:
                self._preview_tile_cache.move_to_end(tile_key)
            return hit

    def put_cached_preview_tile(self, tile_key: Tuple[Any, ...], png_bytes: bytes) -> None:
        with self._preview_cache_lock:
            self._preview_tile_cache[tile_key] = png_bytes
            self._preview_tile_cache.move_to_end(tile_key)
            while len(self._preview_tile_cache) > 512:
                self._preview_tile_cache.popitem(last=False)

    def query_qgis_features_for_preview(
        self,
        layer_name: str,
        target_fids: Optional[List[Any]] = None,
        bbox_wgs84: Optional[Tuple[float, float, float, float]] = None,
        zoom: int = 12,
        scale_denom: Optional[float] = None,
        lod: Optional[int] = None,
        max_features: int = 3500,
    ) -> Dict[str, Any]:
        """
        Serve on-demand GeoJSON polygons/lines for a layer to the local Preview HTTP
        server (`GET /api/features`) filtered by feature IDs or viewport bbox, using
        scale-denominator & pyramid LOD (`lod=3` / `<= 1:55,000` => full detail).
        """
        eff_lod = self._normalize_preview_lod(zoom=zoom, scale_denom=scale_denom, lod=lod)
        cached_hit = self.get_cached_preview_features(
            layer_name=layer_name,
            target_fids=target_fids,
            bbox_wgs84=bbox_wgs84,
            zoom=zoom,
            scale_denom=scale_denom,
            lod=eff_lod,
            max_features=max_features,
        )
        if cached_hit is not None:
            return cached_hit

        if eff_lod >= 3:
            tol_deg = 0.0  # Full unsimplified detail (~1:50,000 or closer)
            eff_max = max(int(max_features or 3500), 7500)
        elif eff_lod == 2:
            tol_deg = 0.00015
            eff_max = max(int(max_features or 3500), 4500)
        else:
            tol_deg = 0.00045
            eff_max = max(int(max_features or 3500), 4500)

        qgs_layer = None
        bg_tctx = None
        bg_ellipsoid = "GRS80"
        is_main = threading.current_thread() is threading.main_thread()
        if not is_main:
            with self._preview_cache_lock:
                bg_spec = dict(self._preview_bg_specs.get(layer_name) or {})
                bg_tctx = self._preview_bg_tctx
                bg_ellipsoid = self._preview_bg_ellipsoid or "GRS80"
            if bg_spec and bg_spec.get("can_bg_read") and bg_tctx is not None:
                try:
                    qgs_layer = self._open_isolated_qgis_vector_layer(bg_spec, layer_name)
                except Exception:
                    qgs_layer = None
        if qgs_layer is None and (is_main or bg_tctx is None):
            qgs_layer = self._find_qgis_layer_by_name(layer_name)
        if qgs_layer is not None and hasattr(qgs_layer, "getFeatures"):
            ext_rect = None
            if bbox_wgs84 is not None and (not target_fids or len(target_fids) > eff_max):
                try:
                    from qgis.core import (
                        QgsCoordinateReferenceSystem,
                        QgsCoordinateTransform,
                        QgsProject,
                        QgsRectangle,
                    )

                    wgs_rect = QgsRectangle(
                        float(bbox_wgs84[0]),
                        float(bbox_wgs84[1]),
                        float(bbox_wgs84[2]),
                        float(bbox_wgs84[3]),
                    )
                    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                    if qgs_layer.crs().isValid() and qgs_layer.crs() != wgs84:
                        tctx_for_ext = bg_tctx if bg_tctx is not None else QgsProject.instance()
                        ext_rect = QgsCoordinateTransform(
                            wgs84, qgs_layer.crs(), tctx_for_ext
                        ).transformBoundingBox(wgs_rect)
                    else:
                        ext_rect = wgs_rect
                except Exception:
                    ext_rect = None

            try:
                fc_res = OgcConnector.extract_geojson_from_qgis_layer(
                    qgs_layer,
                    max_features=eff_max,
                    extent_rect=ext_rect,
                    target_fids=target_fids or None,
                    simplify_tolerance_deg=tol_deg,
                    prioritize_largest=(eff_lod < 3),
                    transform_context=bg_tctx,
                    ellipsoid=bg_ellipsoid,
                )
            except TypeError:
                try:
                    fc_res = OgcConnector.extract_geojson_from_qgis_layer(
                        qgs_layer,
                        max_features=eff_max,
                        extent_rect=ext_rect,
                        target_fids=target_fids or None,
                        simplify_tolerance_deg=tol_deg,
                        prioritize_largest=(eff_lod < 3),
                    )
                except TypeError:
                    fc_res = OgcConnector.extract_geojson_from_qgis_layer(
                        qgs_layer,
                        max_features=eff_max,
                        extent_rect=ext_rect,
                        target_fids=target_fids or None,
                        simplify_tolerance_deg=tol_deg,
                    )
            if fc_res and isinstance(fc_res.get("features"), list):
                q_key = self._feature_query_cache_key(layer_name, target_fids, bbox_wgs84, eff_lod, eff_max)
                self._store_preview_feature_query_cache(q_key, fc_res)
            return fc_res

        # Fallback: slice cached WFS GeoJSON if layer wasn't opened via QGIS provider
        cached_fc = self.layer_geojson_cache.get(layer_name)
        if cached_fc and isinstance(cached_fc.get("features"), list):
            feats = cached_fc["features"]
            if target_fids:
                wanted = {str(x) for x in target_fids}
                matched = [
                    f for f in feats
                    if str(f.get("id") if f.get("id") is not None else (f.get("properties") or {}).get("_feature_id", "")) in wanted
                ]
                return {"type": "FeatureCollection", "features": matched[:eff_max]}
            if bbox_wgs84 is not None:
                from .vector_pyramid import _bbox_of_rings

                bx0, by0, bx1, by1 = bbox_wgs84
                matched = []
                for f in feats:
                    geom = f.get("geometry") or {}
                    coords = geom.get("coordinates")
                    bb = None
                    if isinstance(coords, list) and coords:
                        if isinstance(coords[0], (int, float)) and len(coords) >= 2:
                            bb = [coords[0], coords[1], coords[0], coords[1]]
                        else:
                            bb = _bbox_of_rings(coords)
                    if bb is not None and not (bb[2] < bx0 or bb[0] > bx1 or bb[3] < by0 or bb[1] > by1):
                        matched.append(f)
                if eff_lod < 3 and len(matched) > eff_max:
                    matched.sort(
                        key=lambda ft: float((ft.get("properties") or {}).get("_geom_area_ha") or 0.0),
                        reverse=True,
                    )
                return {"type": "FeatureCollection", "features": matched[:eff_max]}
            return {"type": "FeatureCollection", "features": feats[:eff_max]}

        return {"type": "FeatureCollection", "features": []}

    def _prepare_qgis_map_render_settings(
        self,
        layer_names: List[str],
        bbox_wgs84: Tuple[float, float, float, float],
        width: int = 1024,
        height: int = 768,
        subset_expressions: Optional[Dict[str, str]] = None,
        srs: str = "EPSG:3857",
        bbox_is_native: bool = False,
    ) -> Optional[Tuple[Any, List[Tuple[Any, str]], int, int]]:
        try:
            from qgis.PyQt.QtCore import QSize
            from qgis.PyQt.QtGui import QColor
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsMapSettings,
                QgsProject,
                QgsRectangle,
            )
        except ImportError:
            return None

        w = max(64, min(2048, int(width or 1024)))
        h = max(64, min(2048, int(height or 768)))
        proj = QgsProject.instance()
        qgs_layers = []
        saved_subsets: List[Tuple[Any, str]] = []
        expr_map = subset_expressions or {}

        for ln in layer_names or []:
            lyr = self.resolve_dashboard_layer(ln) or self._find_qgis_layer_by_name(ln)
            if lyr is None:
                continue
            qgs_layers.append(lyr)
            expr = expr_map.get(ln)
            if expr and hasattr(lyr, "subsetString") and hasattr(lyr, "setSubsetString"):
                try:
                    old_sub = lyr.subsetString()
                    saved_subsets.append((lyr, old_sub))
                    lyr.setSubsetString(f"({old_sub}) AND ({expr})" if old_sub else expr)
                except Exception:
                    pass

        if not qgs_layers:
            return None

        try:
            dest_crs = QgsCoordinateReferenceSystem(srs or "EPSG:3857")
            if not dest_crs.isValid():
                dest_crs = QgsCoordinateReferenceSystem("EPSG:3857")
            req_rect = QgsRectangle(
                float(bbox_wgs84[0]),
                float(bbox_wgs84[1]),
                float(bbox_wgs84[2]),
                float(bbox_wgs84[3]),
            )
            if bbox_is_native:
                dest_rect = req_rect
            else:
                wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                dest_rect = (
                    req_rect
                    if dest_crs == wgs84
                    else QgsCoordinateTransform(wgs84, dest_crs, proj).transformBoundingBox(req_rect)
                )

            ms = QgsMapSettings()
            ms.setLayers(qgs_layers)
            ms.setDestinationCrs(dest_crs)
            ms.setExtent(dest_rect)
            ms.setOutputSize(QSize(w, h))
            ms.setBackgroundColor(QColor(0, 0, 0, 0))
            if hasattr(ms, "setOutputDpi"):
                ms.setOutputDpi(96)
            return ms, saved_subsets, w, h
        except Exception:
            for lyr, old_sub in saved_subsets:
                try:
                    lyr.setSubsetString(old_sub)
                except Exception:
                    pass
            return None

    @staticmethod
    def _qimage_to_png_bytes(img: Any) -> Optional[bytes]:
        try:
            from qgis.PyQt.QtCore import QBuffer, QIODevice

            buf = QBuffer()
            wo_flag = getattr(QIODevice, "WriteOnly", None)
            if wo_flag is None and hasattr(QIODevice, "OpenModeFlag"):
                wo_flag = QIODevice.OpenModeFlag.WriteOnly
            buf.open(wo_flag)
            img.save(buf, "PNG")
            raw = bytes(buf.data())
            buf.close()
            return raw if raw else None
        except Exception:
            return None

    def render_qgis_layers_wms_png_async(
        self,
        layer_names: List[str],
        bbox_wgs84: Tuple[float, float, float, float],
        width: int = 1024,
        height: int = 768,
        subset_expressions: Optional[Dict[str, str]] = None,
        layer_styles: Optional[Dict[str, Dict[str, Any]]] = None,
        srs: str = "EPSG:3857",
        bbox_is_native: bool = False,
        on_finished: Optional[Callable[[Optional[bytes]], None]] = None,
        job_holder: Optional[set] = None,
    ) -> bool:
        """
        Non-blocking async PNG tile/WMS renderer using QGIS C++ `QgsMapRendererParallelJob`.
        Starts background multi-core rendering and returns immediately without freezing the Qt GUI thread.
        """
        _ = layer_styles
        prepared = self._prepare_qgis_map_render_settings(
            layer_names=layer_names,
            bbox_wgs84=bbox_wgs84,
            width=width,
            height=height,
            subset_expressions=subset_expressions,
            srs=srs,
            bbox_is_native=bbox_is_native,
        )
        if prepared is None:
            if on_finished is not None:
                on_finished(None)
            return False
        ms, saved_subsets, _w, _h = prepared
        try:
            from qgis.core import QgsMapRendererParallelJob
        except ImportError:
            QgsMapRendererParallelJob = None  # type: ignore[assignment]

        if QgsMapRendererParallelJob is None:
            for lyr, old_sub in saved_subsets:
                try:
                    lyr.setSubsetString(old_sub)
                except Exception:
                    pass
            res = self.render_qgis_layers_wms_png(
                layer_names=layer_names,
                bbox_wgs84=bbox_wgs84,
                width=width,
                height=height,
                subset_expressions=subset_expressions,
                layer_styles=layer_styles,
                srs=srs,
                bbox_is_native=bbox_is_native,
            )
            if on_finished is not None:
                on_finished(res)
            return True

        try:
            job = QgsMapRendererParallelJob(ms)
            if job_holder is not None:
                job_holder.add(job)

            def _done() -> None:
                raw_out: Optional[bytes] = None
                try:
                    img = job.renderedImage()
                    if img is not None and not img.isNull():
                        raw_out = self._qimage_to_png_bytes(img)
                except Exception:
                    raw_out = None
                finally:
                    for lyr, old_sub in saved_subsets:
                        try:
                            lyr.setSubsetString(old_sub)
                        except Exception:
                            pass
                    if job_holder is not None:
                        job_holder.discard(job)
                if on_finished is not None:
                    on_finished(raw_out)

            job.finished.connect(_done)
            job.start()
            return True
        except Exception:
            for lyr, old_sub in saved_subsets:
                try:
                    lyr.setSubsetString(old_sub)
                except Exception:
                    pass
            if on_finished is not None:
                on_finished(None)
            return False

    def render_qgis_layers_wms_png(
        self,
        layer_names: List[str],
        bbox_wgs84: Tuple[float, float, float, float],
        width: int = 1024,
        height: int = 768,
        subset_expressions: Optional[Dict[str, str]] = None,
        layer_styles: Optional[Dict[str, Dict[str, Any]]] = None,
        srs: str = "EPSG:3857",
        bbox_is_native: bool = False,
    ) -> Optional[bytes]:
        """
        Render one or more live QGIS vector layers into a transparent PNG (`EPSG:3857`
        or native `EPSG:3301` tile) using QGIS C++ `QgsMapRendererCustomPainterJob`.
        """
        _ = layer_styles  # Reserved for optional style parity hints; QGIS layer native renderer stays authoritative
        try:
            from qgis.PyQt.QtGui import QColor, QImage, QPainter
            from qgis.core import QgsMapRendererCustomPainterJob
        except ImportError:
            return None

        prepared = self._prepare_qgis_map_render_settings(
            layer_names=layer_names,
            bbox_wgs84=bbox_wgs84,
            width=width,
            height=height,
            subset_expressions=subset_expressions,
            srs=srs,
            bbox_is_native=bbox_is_native,
        )
        if prepared is None:
            return None
        ms, saved_subsets, w, h = prepared

        try:
            img_fmt = getattr(QImage, "Format_ARGB32_Premultiplied", None)
            if img_fmt is None and hasattr(QImage, "Format"):
                img_fmt = QImage.Format.Format_ARGB32_Premultiplied
            img = QImage(w, h, img_fmt)
            img.fill(QColor(0, 0, 0, 0))

            painter = QPainter(img)
            try:
                job = QgsMapRendererCustomPainterJob(ms, painter)
                job.start()
                job.waitForFinished()
            finally:
                painter.end()

            return self._qimage_to_png_bytes(img)
        except Exception:
            return None
        finally:
            for lyr, old_sub in saved_subsets:
                try:
                    lyr.setSubsetString(old_sub)
                except Exception:
                    pass

    def _enrich_natura_pria_overlap(
        self,
        qgis_layers_by_id: Dict[str, Any],
        progress_cb: Optional[Callable[[int, int], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        force_refresh: bool = False,
        config: Optional[DashboardConfig] = None,
    ) -> None:
        if config is not None and not self.config_uses_natura_pria_overlap(config):
            return
        from .spatial_overlap import (
            compute_geojson_overlap_for_natura,
            enrich_natura_pria_overlap_qgis,
            enrich_records_domain_fields,
        )

        natura_name: Optional[str] = None
        pria_name: Optional[str] = None
        for lname, recs in self.layer_records_cache.items():
            enrich_records_domain_fields(recs)
            if recs and any("pohityyp" in r for r in recs[:5]):
                natura_name = lname
            if recs and any("parandniidu_tyyp" in r for r in recs[:5]):
                pria_name = lname
        if natura_name and pria_name:
            nat_recs = self.layer_records_cache.get(natura_name) or []
            needs_enrichment = bool(
                force_refresh
                or (
                    nat_recs
                    and (
                        "overlap_pria_ha" not in nat_recs[0]
                        or (
                            any(float(r.get("overlap_pria_ha") or 0) > 0 for r in nat_recs)
                            and not any("_pria_ov" in r for r in nat_recs)
                        )
                    )
                )
            )
            if not needs_enrichment:
                return
            nat_lyr = self._find_qgis_layer_by_name(natura_name)
            pria_lyr = self._find_qgis_layer_by_name(pria_name)
            if nat_lyr is None:
                for qlyr in qgis_layers_by_id.values():
                    if hasattr(qlyr, "name") and qlyr.name() == natura_name:
                        nat_lyr = qlyr
            if pria_lyr is None:
                for qlyr in qgis_layers_by_id.values():
                    if hasattr(qlyr, "name") and qlyr.name() == pria_name:
                        pria_lyr = qlyr
            enriched = False
            if nat_lyr is not None and pria_lyr is not None:
                enrich_natura_pria_overlap_qgis(
                    nat_lyr,
                    nat_recs,
                    pria_lyr,
                    progress_cb=progress_cb,
                    cancel_check=cancel_check,
                    pria_records=self.layer_records_cache.get(pria_name),
                )
                enriched = True
            else:
                def _cached_features(lname: str, recs_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
                    fc = self.layer_geojson_cache.get(lname) or {}
                    feats = list(fc.get("features") or [])
                    if feats:
                        return feats
                    lod1_obj = (self.layer_pyramid_cache.get(lname) or {}).get("lod1") or {}
                    data_b64 = lod1_obj.get("data_b64")
                    if not data_b64:
                        return []
                    import base64
                    import gzip

                    type_map = {
                        "P": "Point",
                        "MP": "MultiPoint",
                        "L": "LineString",
                        "ML": "MultiLineString",
                        "G": "Polygon",
                        "MG": "MultiPolygon",
                    }
                    try:
                        packed = json.loads(gzip.decompress(base64.b64decode(data_b64)).decode("utf-8"))
                    except Exception:
                        return []
                    rec_map = {
                        str(r.get("_feature_id")): r
                        for r in recs_list
                        if r.get("_feature_id") is not None
                    }
                    out_feats: List[Dict[str, Any]] = []
                    for fid_str, entry in (packed or {}).items():
                        if not isinstance(entry, list) or len(entry) < 3:
                            continue
                        gtype = type_map.get(entry[0], entry[0])
                        props = dict(rec_map.get(str(fid_str)) or {})
                        props.setdefault("_feature_id", fid_str)
                        out_feats.append(
                            {
                                "type": "Feature",
                                "id": fid_str,
                                "properties": props,
                                "geometry": {"type": gtype, "coordinates": entry[2]},
                            }
                        )
                    return out_feats

                pria_recs = self.layer_records_cache.get(pria_name) or []
                nat_feats = _cached_features(natura_name, nat_recs)
                pria_feats = _cached_features(pria_name, pria_recs)
                if nat_feats and pria_feats:
                    compute_geojson_overlap_for_natura(
                        nat_feats,
                        pria_feats,
                        progress_cb=progress_cb,
                        cancel_check=cancel_check,
                    )
                    by_fid: Dict[str, Dict[str, Any]] = {}
                    for nf in nat_feats:
                        p = nf.get("properties") or {}
                        fid = p.get("_feature_id", nf.get("id"))
                        if fid is not None:
                            by_fid[str(fid)] = p
                    for rec in nat_recs:
                        ov_p = by_fid.get(str(rec.get("_feature_id")))
                        if ov_p:
                            for k in ("overlap_pria_ha", "overlap_mn_ha", "overlap_pn_ha", "overlap_pct", "_pria_ov"):
                                if k in ov_p:
                                    rec[k] = ov_p[k]
                        else:
                            for k in ("overlap_pria_ha", "overlap_mn_ha", "overlap_pn_ha", "overlap_pct"):
                                rec.setdefault(k, 0.0)
                    enriched = True

            if enriched:
                if natura_name in self.layer_pyramid_cache and isinstance(self.layer_pyramid_cache[natura_name], dict):
                    self.layer_pyramid_cache[natura_name].pop("lod1", None)
                if hasattr(self, "_cross_layer_fid_cache"):
                    self._cross_layer_fid_cache.clear()
                if natura_name in self.layer_stats_cache and isinstance(self.layer_stats_cache[natura_name], dict):
                    old_st = self.layer_stats_cache[natura_name]
                    new_st = compute_layer_statistics(nat_recs, layer_name=natura_name)
                    if old_st.get("qgis_style"):
                        new_st["qgis_style"] = old_st["qgis_style"]
                    if "has_qgis_layer" in old_st:
                        new_st["has_qgis_layer"] = old_st["has_qgis_layer"]
                    self.layer_stats_cache[natura_name] = new_st

    @staticmethod
    def _find_project_qgis_layer_by_name(layer_name: str) -> Optional[Any]:
        """Locate an active vector layer in the current QGIS project by exact or substring match."""
        target = (layer_name or "").strip().lower()
        if not target:
            return None
        try:
            from qgis.core import Qgis, QgsMapLayer, QgsProject

            layers = QgsProject.instance().mapLayersByName(layer_name)
            if layers:
                return layers[0]
            vec_type = getattr(getattr(Qgis, "LayerType", None), "Vector", None)
            if vec_type is None:
                vec_type = QgsMapLayer.VectorLayer
            vec_layers = [
                lyr for lyr in QgsProject.instance().mapLayers().values()
                if lyr.type() == vec_type
            ]
            for lyr in vec_layers:
                if (lyr.name() or "").strip().lower() == target:
                    return lyr
            for lyr in vec_layers:
                lname = (lyr.name() or "").strip().lower()
                if target in lname or lname in target:
                    return lyr
        except Exception:
            pass
        return None

    def _find_isolated_dashboard_layer(self, layer_name: str) -> Optional[Any]:
        target = (layer_name or "").strip().lower()
        if not target:
            return None
        iso_map = getattr(self, "dashboard_layers", {}) or {}
        if layer_name in iso_map:
            lyr = iso_map[layer_name]
            try:
                _ = lyr.name() if hasattr(lyr, "name") else layer_name
                return lyr
            except RuntimeError:
                iso_map.pop(layer_name, None)
        for k, lyr in list(iso_map.items()):
            try:
                _ = lyr.name() if hasattr(lyr, "name") else k
            except RuntimeError:
                iso_map.pop(k, None)
                continue
            if str(k).strip().lower() == target:
                return lyr
        for k, lyr in list(iso_map.items()):
            kl = str(k).strip().lower()
            if target in kl or kl in target:
                return lyr
        return None

    def _find_qgis_layer_by_name(self, layer_name: str) -> Optional[Any]:
        """Locate a layer respecting active sync mode (isolated dashboard_layers first in dashboard_only mode)."""
        if getattr(self, "active_sync_mode", "dashboard_only") != "sync_main_canvas":
            iso = self._find_isolated_dashboard_layer(layer_name)
            if iso is not None:
                return iso
            return self._find_project_qgis_layer_by_name(layer_name)
        proj_lyr = self._find_project_qgis_layer_by_name(layer_name)
        if proj_lyr is not None:
            return proj_lyr
        return self._find_isolated_dashboard_layer(layer_name)

    @staticmethod
    def ensure_safe_qgis_extent(config: Optional[DashboardConfig] = None) -> None:
        """If QGIS canvas extent is empty or wider than Estonia, set a safe ~15km window first."""
        try:
            from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle
            import qgis.utils

            iface = getattr(qgis.utils, "iface", None)
            if not iface or not hasattr(iface, "mapCanvas"):
                return
            canvas = iface.mapCanvas()
            ext = canvas.extent()
            lat = float(getattr(config, "map_center_lat", 58.758) or 58.758)
            lon = float(getattr(config, "map_center_lon", 23.825) or 23.825)
            dest_crs = canvas.mapSettings().destinationCrs()
            is_too_wide = ext.isEmpty() or (
                (dest_crs.isGeographic() and ext.width() > 15.0)
                or (not dest_crs.isGeographic() and ext.width() > 1200000.0)
            )
            if is_too_wide:
                wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                rect = QgsRectangle(21.65, 57.48, 28.25, 59.70)
                if dest_crs.isValid() and dest_crs != wgs84:
                    xform = QgsCoordinateTransform(wgs84, dest_crs, QgsProject.instance())
                    rect = xform.transformBoundingBox(rect)
                canvas.setExtent(rect)
        except Exception:
            pass

    @staticmethod
    def _get_safe_wgs84_bbox(
        config: Optional[DashboardConfig] = None,
    ) -> Tuple[float, float, float, float]:
        """Return (south, west, north, east) clamped to a safe request window."""
        lat = float(getattr(config, "map_center_lat", 58.758) or 58.758)
        lon = float(getattr(config, "map_center_lon", 23.825) or 23.825)
        try:
            from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
            import qgis.utils

            iface = getattr(qgis.utils, "iface", None)
            if iface and hasattr(iface, "mapCanvas"):
                canvas = iface.mapCanvas()
                ext = canvas.extent()
                if not ext.isEmpty():
                    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                    dest_crs = canvas.mapSettings().destinationCrs()
                    if dest_crs.isValid() and dest_crs != wgs84:
                        ext = QgsCoordinateTransform(dest_crs, wgs84, QgsProject.instance()).transformBoundingBox(ext)
                    if 0.001 < ext.width() <= 1.2 and 0.001 < ext.height() <= 0.8:
                        return (ext.yMinimum(), ext.xMinimum(), ext.yMaximum(), ext.xMaximum())
                    cen = ext.center()
                    lat, lon = float(cen.y()), float(cen.x())
        except Exception:
            pass
        return (lat - 0.08, lon - 0.14, lat + 0.08, lon + 0.14)

    def _get_dashboard_initial_extent_in_layer_crs(
        self,
        layer: Any,
        clamp_if_wide: bool = False,
        config: Optional[DashboardConfig] = None,
    ) -> Optional[Any]:
        """Prefer the dashboard map widget's configured home viewport when slicing massive layers."""
        if config is not None:
            try:
                from qgis.core import (
                    QgsCoordinateReferenceSystem,
                    QgsCoordinateTransform,
                    QgsProject,
                    QgsRectangle,
                )

                widgets_list = list(config.widgets or [])
                lname_target = layer.name() if hasattr(layer, "name") else ""
                mw = next(
                    (
                        w
                        for w in widgets_list
                        if w.widget_type == "map"
                        and lname_target
                        and (w.layer_name == lname_target or lname_target in (w.map_layers or []))
                    ),
                    None,
                )
                if mw is None:
                    mw = next((w for w in widgets_list if w.widget_type == "map"), None)
                lat = float(
                    (mw.map_center_lat if mw and mw.map_center_lat is not None else config.map_center_lat)
                    or 58.758
                )
                lon = float(
                    (mw.map_center_lon if mw and mw.map_center_lon is not None else config.map_center_lon)
                    or 23.825
                )
                zoom_raw = mw.map_zoom if (mw and mw.map_zoom is not None) else config.map_zoom
                zoom_val = int(zoom_raw) if zoom_raw is not None else 7
                # Estonia TMS resolution: z=7 -> 31.25 m/px; ~800x600 viewport -> ~0.38 x 0.22 deg
                scale_pow = max(-3, min(4, 7 - zoom_val))
                half_lon = min(3.5, max(0.08, 0.30 * (2.0 ** scale_pow)))
                half_lat = min(1.8, max(0.05, 0.16 * (2.0 ** scale_pow)))
                wgs_rect = QgsRectangle(lon - half_lon, lat - half_lat, lon + half_lon, lat + half_lat)
                wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                if layer.crs().isValid() and layer.crs() != wgs84:
                    return QgsCoordinateTransform(wgs84, layer.crs(), QgsProject.instance()).transformBoundingBox(
                        wgs_rect
                    )
                return wgs_rect
            except Exception:
                pass
        return self._get_canvas_extent_in_layer_crs(
            layer, clamp_if_wide=clamp_if_wide, config=config
        )

    @staticmethod
    def _get_canvas_extent_in_layer_crs(
        layer: Any,
        clamp_if_wide: bool = False,
        config: Optional[DashboardConfig] = None,
    ) -> Optional[Any]:
        try:
            from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle
            import qgis.utils

            iface = getattr(qgis.utils, "iface", None)
            if not iface or not hasattr(iface, "mapCanvas"):
                return None
            canvas = iface.mapCanvas()
            ext = canvas.extent()
            dest_crs = canvas.mapSettings().destinationCrs()
            wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")

            if ext.isEmpty() or (
                clamp_if_wide
                and (
                    (dest_crs.isGeographic() and ext.width() > 1.2)
                    or (not dest_crs.isGeographic() and ext.width() > 90000.0)
                )
            ):
                if ext.isEmpty():
                    lat = float(getattr(config, "map_center_lat", 58.758) or 58.758)
                    lon = float(getattr(config, "map_center_lon", 23.825) or 23.825)
                    rect = QgsRectangle(lon - 0.12, lat - 0.07, lon + 0.12, lat + 0.07)
                    if layer.crs().isValid() and layer.crs() != wgs84:
                        return QgsCoordinateTransform(wgs84, layer.crs(), QgsProject.instance()).transformBoundingBox(rect)
                    return rect
                cen = ext.center()
                half_w = 0.25 if dest_crs.isGeographic() else 18000.0
                half_h = 0.15 if dest_crs.isGeographic() else 12000.0
                ext = QgsRectangle(cen.x() - half_w, cen.y() - half_h, cen.x() + half_w, cen.y() + half_h)

            if dest_crs.isValid() and layer.crs().isValid() and dest_crs != layer.crs():
                xform = QgsCoordinateTransform(dest_crs, layer.crs(), QgsProject.instance())
                return xform.transformBoundingBox(ext)
            return ext
        except Exception:
            return None

    def _load_active_qgis_layers_into_cache(self) -> None:
        try:
            from qgis.core import Qgis, QgsMapLayer, QgsProject

            vec_layer_type = getattr(getattr(Qgis, "LayerType", None), "Vector", None)
            if vec_layer_type is None:
                vec_layer_type = QgsMapLayer.VectorLayer
            for layer in QgsProject.instance().mapLayers().values():
                if layer.type() == vec_layer_type and layer.name() not in self.layer_records_cache:
                    is_massive = OgcConnector.is_massive_layer(layer.name())
                    ext_rect = (
                        self._get_canvas_extent_in_layer_crs(layer, clamp_if_wide=True)
                        if is_massive
                        else None
                    )
                    self.layer_records_cache[layer.name()] = (
                        OgcConnector.extract_records_from_qgis_layer(
                            layer,
                            max_features=400 if is_massive else 0,
                            extent_rect=ext_rect,
                        )
                    )
        except ImportError:
            pass

    @staticmethod
    def _apply_qgis_layer_join(
        source_layer: Any, target_layer: Any, join_cfg: JoinConfig
    ) -> None:
        try:
            from qgis.core import QgsVectorLayerJoinInfo

            join_info = QgsVectorLayerJoinInfo()
            join_info.setJoinLayerId(source_layer.id())
            join_info.setJoinFieldName(join_cfg.source_key_field)
            join_info.setTargetFieldName(join_cfg.target_key_field)
            join_info.setUsingMemoryCache(True)
            join_info.setPrefix(join_cfg.join_prefix or "xl_")
            if join_cfg.selected_fields:
                join_info.setJoinFieldNamesSubset(join_cfg.selected_fields)
            join_info.setJoinLayer(source_layer)
            target_layer.addJoin(join_info)
        except Exception:
            pass

    def get_spatial_pivot_records(
        self,
        config: DashboardConfig,
        widget_cfg: WidgetConfig,
    ) -> List[Dict[str, Any]]:
        """Return spatially intersected records for a widget configured with spatial_join_layer."""
        base_name = getattr(widget_cfg, "layer_name", "") or ""
        join_name = getattr(widget_cfg, "spatial_join_layer", "") or ""
        base_records = self.layer_records_cache.get(base_name, [])
        if not join_name or not base_records:
            return base_records
        join_records = self.layer_records_cache.get(join_name, [])
        cache_key = (
            base_name,
            join_name,
            id(base_records),
            len(base_records),
            id(join_records),
            len(join_records),
        )
        if cache_key in self._spatial_pivot_cache:
            return self._spatial_pivot_cache[cache_key]

        base_layer = self._find_qgis_layer_by_name(base_name)
        join_layer = self._find_qgis_layer_by_name(join_name)
        enriched = compute_spatial_pivot_records(
            base_records=base_records,
            join_records=join_records,
            join_layer_name=join_name,
            base_layer=base_layer,
            join_layer=join_layer,
            base_geojson=self.layer_geojson_cache.get(base_name),
            join_geojson=self.layer_geojson_cache.get(join_name),
        )
        self._spatial_pivot_cache[cache_key] = enriched
        return enriched
