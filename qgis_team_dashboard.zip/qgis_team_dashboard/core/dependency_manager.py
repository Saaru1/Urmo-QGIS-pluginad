# -*- coding: utf-8 -*-
"""
Dependency Manager for QGIS Team Dashboard.
Detects optional external Python packages (pandas, openpyxl, msal, requests, plotly)
and offers a one-click user-space pip installer for QGIS OSGeo4W environments,
while providing flags for graceful pure-Python/PyQt fallbacks.
"""

import importlib.util
import os
import subprocess
import sys
from typing import Dict, List, Tuple

REQUIRED_PACKAGES: List[Tuple[str, str, str]] = [
    ("pandas", "pandas>=1.5.0", "High-speed DataFrame joins & aggregations"),
    ("openpyxl", "openpyxl>=3.0.10", "Read-only .xlsx Excel workbook ingestion"),
    ("msal", "msal>=1.20.0", "Microsoft Entra ID / Graph API authentication"),
    ("requests", "requests>=2.28.0", "SharePoint REST & OGC HTTP client"),
    ("plotly", "plotly>=5.10.0", "Interactive HTML/D3 chart generation"),
]


class DependencyManager:
    """Checks and installs external Python packages inside the QGIS Python environment."""

    @staticmethod
    def check_status() -> Dict[str, bool]:
        """Return a mapping of module_name -> is_installed."""
        status: Dict[str, bool] = {}
        for module_name, _, _ in REQUIRED_PACKAGES:
            spec = importlib.util.find_spec(module_name)
            status[module_name] = spec is not None
        return status

    @classmethod
    def missing_packages(cls) -> List[Tuple[str, str, str]]:
        """Return list of (module_name, pip_spec, description) for missing packages."""
        status = cls.check_status()
        return [
            (mod, spec, desc)
            for mod, spec, desc in REQUIRED_PACKAGES
            if not status.get(mod, False)
        ]

    @classmethod
    def all_installed(cls) -> bool:
        """Return True if all optional power packages are installed."""
        return len(cls.missing_packages()) == 0

    @staticmethod
    def resolve_python_executable() -> str:
        """Resolve the Python interpreter inside QGIS (handling Windows qgis-bin.exe)."""
        exe = sys.executable
        if exe and os.path.basename(exe).lower().startswith("python"):
            return exe
        # On Windows OSGeo4W, sys.executable may point to qgis-bin.exe or qgis-ltr-bin.exe
        exe_dir = os.path.dirname(exe) if exe else ""
        candidates = [
            os.path.join(exe_dir, "python3.exe"),
            os.path.join(exe_dir, "python.exe"),
            os.path.join(os.path.dirname(exe_dir), "bin", "python3.exe"),
            os.path.join(os.path.dirname(exe_dir), "bin", "python.exe"),
        ]
        for cand in candidates:
            if os.path.isfile(cand):
                return cand
        return "python"

    @classmethod
    def install_missing(cls, upgrade: bool = False) -> Tuple[bool, str]:
        """Install missing packages into the user site-packages directory."""
        missing = cls.missing_packages()
        if not missing and not upgrade:
            return True, "All required packages are already installed."

        specs = [spec for _, spec, _ in (REQUIRED_PACKAGES if upgrade else missing)]
        python_exe = cls.resolve_python_executable()
        cmd = [python_exe, "-m", "pip", "install", "--user"] + specs

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                check=False,
            )
            output = (proc.stdout or "") + "\n" + (proc.stderr or "")
            if proc.returncode == 0:
                importlib.invalidate_caches()
                return True, f"Successfully installed packages:\n{', '.join(specs)}\n\n{output.strip()}"
            return False, f"pip exited with code {proc.returncode}:\n{output.strip()}"
        except Exception as exc:
            return False, f"Failed to execute pip installer: {exc}"
