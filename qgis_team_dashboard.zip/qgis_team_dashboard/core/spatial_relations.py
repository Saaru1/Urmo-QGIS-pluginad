# -*- coding: utf-8 -*-
"""
General, layer-agnostic exact spatial intersection engine for GeoDash.

Computes exact polygon intersection areas (in Cartesian hectares) and
exact point/line intersection edges between arbitrary spatial layer pairs:
  1. Using QGIS GEOS (`QgsSpatialIndex` + `QgsGeometry.intersects` / `intersection`)
     whenever valid complete vector layers are loaded in QGIS.
  2. Using exact planar Green's Theorem boundary integration in pure Python when
     only complete unsimplified GeoJSON geometries (`lod >= 3`) are available.

Never fabricates spatial overlaps from simplified LOD pyramids, bounding-box
rectangles, or incomplete datasets.
"""

import base64
import gzip
import json
import math
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from .spatial_overlap import (
    QgisCartesianAreaCalculator,
    _bbox_overlaps,
    geojson_bbox_wgs84,
    geom_intersects_geom,
    is_qgis_planar_metric_crs,
    project_wgs84_to_estonia_3301,
)
from .vector_pyramid import build_qgis_fid_to_record_key_map


_RAD = math.pi / 180.0


def _normalized_pair(name_a: str, name_b: str) -> Tuple[str, str]:
    a = str(name_a or "").strip()
    b = str(name_b or "").strip()
    return (a, b) if a <= b else (b, a)


def discover_connected_layer_pairs(config: Any) -> List[Tuple[str, str]]:
    """
    Discover all unique unordered spatial layer pairs `(layer_a, layer_b)` (`layer_a < layer_b`)
    participating in cross-layer filtering on `config`.
    """
    if config is None:
        return []

    layer_by_item_id: Dict[str, Set[str]] = {}
    spatial_widget_layers: Set[str] = set()
    slicer_layers: Set[str] = set()
    explicit_pairs: Set[Tuple[str, str]] = set()

    for w in getattr(config, "widgets", []) or []:
        wid = str(getattr(w, "id", "") or "").strip()
        wtype = str(getattr(w, "widget_type", "") or "").strip().lower()
        ln = str(getattr(w, "layer_name", "") or "").strip()
        sjl = str(getattr(w, "spatial_join_layer", "") or "").strip()
        if wtype == "map":
            mlayers = {
                str(x).strip()
                for x in (getattr(w, "map_layers", None) or [])
                if str(x).strip()
            }
            if ln:
                mlayers.add(ln)
            if wid:
                layer_by_item_id[wid] = mlayers
                layer_by_item_id[f"tbl_{wid}"] = mlayers
            layer_by_item_id["__map__"] = mlayers
        elif wid and ln:
            layer_by_item_id[wid] = {ln}
            layer_by_item_id[f"tbl_{wid}"] = {ln}
        if ln and wtype != "image":
            spatial_widget_layers.add(ln)
        if ln and sjl and ln != sjl:
            explicit_pairs.add(_normalized_pair(ln, sjl))

    for sl in getattr(config, "slicers", []) or []:
        sid = str(getattr(sl, "id", "") or "").strip()
        sl_layers: Set[str] = set()
        main_ln = str(getattr(sl, "layer_name", "") or "").strip()
        if main_ln:
            sl_layers.add(main_ln)
        for p in getattr(sl, "panes", []) or []:
            if not isinstance(p, dict):
                continue
            if str(p.get("pane_type") or p.get("type") or "field").strip().lower() == "address":
                continue
            pln = str(p.get("layer_name") or "").strip()
            if pln:
                sl_layers.add(pln)
        if sid:
            layer_by_item_id[sid] = sl_layers
        slicer_layers.update(sl_layers)

    connections = getattr(config, "widget_connections", []) or []
    for conn in connections:
        if isinstance(conn, dict):
            enabled = bool(conn.get("enabled", True))
            src_id = str(conn.get("source_id") or "").strip()
            tgt_id = str(conn.get("target_id") or "").strip()
            act = str(conn.get("action") or "filter_and_zoom").strip().lower()
        else:
            enabled = bool(getattr(conn, "enabled", True))
            src_id = str(getattr(conn, "source_id", "") or "").strip()
            tgt_id = str(getattr(conn, "target_id", "") or "").strip()
            act = str(getattr(conn, "action", "filter_and_zoom") or "filter_and_zoom").strip().lower()
        if not enabled or not src_id or not tgt_id or act == "zoom_only":
            continue
        if tgt_id == "__map__":
            continue
        src_layers = layer_by_item_id.get(src_id, set())
        tgt_layers = layer_by_item_id.get(tgt_id, set())
        for sln in src_layers:
            for tln in tgt_layers:
                if sln and tln and sln != tln:
                    explicit_pairs.add(_normalized_pair(sln, tln))

    # Global slicers / table filters without explicit connections can filter any active layer
    if not connections:
        all_layers = sorted(spatial_widget_layers | slicer_layers)
        for i in range(len(all_layers)):
            for j in range(i + 1, len(all_layers)):
                explicit_pairs.add(_normalized_pair(all_layers[i], all_layers[j]))
    else:
        global_slicers = [
            sl for sl in (getattr(config, "slicers", []) or []) if bool(getattr(sl, "is_global", False))
        ]
        if global_slicers:
            all_layers = sorted(spatial_widget_layers | slicer_layers)
            for sl in global_slicers:
                sid = str(getattr(sl, "id", "") or "").strip()
                sl_set = layer_by_item_id.get(sid, set())
                for sln in sl_set:
                    for tln in all_layers:
                        if sln and tln and sln != tln:
                            explicit_pairs.add(_normalized_pair(sln, tln))

    return sorted(explicit_pairs)


# ---------------------------------------------------------------------------
# Pure-Python Exact Analytical Polygon Intersection Area (Green's Theorem)
# ---------------------------------------------------------------------------


def _ring_signed_area2(pts: List[Tuple[float, float]]) -> float:
    s = 0.0
    for i in range(len(pts) - 1):
        s += pts[i][0] * pts[i + 1][1] - pts[i + 1][0] * pts[i][1]
    return s


def _extract_polys_projected(
    geom: Dict[str, Any],
    ref_x: float,
    ref_y: float,
    use_est: bool,
    cos_lat: float,
) -> List[List[List[Tuple[float, float]]]]:
    gtype = str(geom.get("type") or "")
    coords = geom.get("coordinates")
    if not coords:
        return []
    polys_raw = [coords] if gtype == "Polygon" else (coords if gtype == "MultiPolygon" else [])
    out: List[List[List[Tuple[float, float]]]] = []
    for poly in polys_raw:
        if not isinstance(poly, list):
            continue
        rings: List[List[Tuple[float, float]]] = []
        for ri, raw_ring in enumerate(poly):
            if not isinstance(raw_ring, list) or len(raw_ring) < 3:
                continue
            pts: List[Tuple[float, float]] = []
            for pt in raw_ring:
                if not isinstance(pt, (list, tuple)) or len(pt) < 2:
                    continue
                lon = float(pt[0])
                lat = float(pt[1])
                if use_est:
                    px, py = project_wgs84_to_estonia_3301(lon, lat)
                    x = px - ref_x
                    y = py - ref_y
                else:
                    x = (lon - ref_x) * 111319.4908 * cos_lat
                    y = (lat - ref_y) * 111132.954
                if not pts or abs(x - pts[-1][0]) > 1e-9 or abs(y - pts[-1][1]) > 1e-9:
                    pts.append((x, y))
            if len(pts) < 3:
                continue
            if abs(pts[0][0] - pts[-1][0]) > 1e-9 or abs(pts[0][1] - pts[-1][1]) > 1e-9:
                pts.append(pts[0])
            if len(pts) < 4:
                continue
            sa = _ring_signed_area2(pts)
            if abs(sa) < 1e-10:
                continue
            if (ri == 0 and sa < 0) or (ri > 0 and sa > 0):
                pts.reverse()
            rings.append(pts)
        if rings:
            out.append(rings)
    return out


class _EdgeIndex2D:
    __slots__ = ("y_strips", "nb", "ry0", "dy", "r_edges", "grid", "gx_n", "gy_n", "rx0", "dxg", "dyg")

    def __init__(
        self,
        polys: List[List[List[Tuple[float, float]]]],
        rx0: float,
        ry0: float,
        rx1: float,
        ry1: float,
    ) -> None:
        nb = 24
        dy = max(1e-6, (ry1 - ry0) / nb)
        y_strips: List[List[Tuple[float, float, float, float, float, float, float, float, int]]] = [
            [] for _ in range(nb)
        ]
        gx_n, gy_n = 12, 12
        dxg = max(1e-6, (rx1 - rx0) / gx_n)
        dyg = max(1e-6, (ry1 - ry0) / gy_n)
        grid: List[List[Any]] = [[] for _ in range(gx_n * gy_n)]
        r_edges: List[Any] = []
        eid = 0
        for rings in polys:
            for pts in rings:
                for i in range(len(pts) - 1):
                    x0, y0 = pts[i]
                    x1, y1 = pts[i + 1]
                    ey0 = y0 if y0 < y1 else y1
                    ey1 = y0 if y0 > y1 else y1
                    ex0 = x0 if x0 < x1 else x1
                    ex1 = x0 if x0 > x1 else x1
                    if ey1 >= ry0 - 1e-6 and ey0 <= ry1 + 1e-6 and ex1 >= rx0 - 1e-6:
                        edge = (x0, y0, x1, y1, ex0, ey0, ex1, ey1, eid)
                        eid += 1
                        b0 = max(0, min(nb - 1, int(math.floor((ey0 - ry0) / dy))))
                        b1 = max(0, min(nb - 1, int(math.floor((ey1 - ry0) / dy))))
                        for b in range(b0, b1 + 1):
                            y_strips[b].append(edge)
                        if ex0 <= rx1 + 1e-6:
                            r_edges.append(edge)
                            g0x = max(0, min(gx_n - 1, int(math.floor((ex0 - rx0) / dxg))))
                            g1x = max(0, min(gx_n - 1, int(math.floor((ex1 - rx0) / dxg))))
                            g0y = max(0, min(gy_n - 1, int(math.floor((ey0 - ry0) / dyg))))
                            g1y = max(0, min(gy_n - 1, int(math.floor((ey1 - ry0) / dyg))))
                            for gx in range(g0x, g1x + 1):
                                for gy in range(g0y, g1y + 1):
                                    grid[gy * gx_n + gx].append(edge)
        self.y_strips = y_strips
        self.nb = nb
        self.ry0 = ry0
        self.dy = dy
        self.r_edges = r_edges
        self.grid = grid
        self.gx_n = gx_n
        self.gy_n = gy_n
        self.rx0 = rx0
        self.dxg = dxg
        self.dyg = dyg

    def point_in(self, px: float, py: float) -> bool:
        b = max(0, min(self.nb - 1, int(math.floor((py - self.ry0) / self.dy))))
        inside = False
        for x0, y0, x1, y1, *_rest in self.y_strips[b]:
            if (y0 > py) != (y1 > py):
                xi = x0 + ((py - y0) * (x1 - x0)) / (y1 - y0)
                if px < xi:
                    inside = not inside
        return inside


def exact_polygon_intersection_area_ha_geojson(
    geom_a: Optional[Dict[str, Any]],
    geom_b: Optional[Dict[str, Any]],
) -> float:
    """
    Compute exact analytical polygon/multipolygon intersection area in hectares
    for two WGS84 GeoJSON geometries using Green's Theorem in planar metric coordinates.
    """
    if not isinstance(geom_a, dict) or not isinstance(geom_b, dict):
        return 0.0
    bb_a = geojson_bbox_wgs84(geom_a)
    bb_b = geojson_bbox_wgs84(geom_b)
    if bb_a is None or bb_b is None or not _bbox_overlaps(bb_a, bb_b):
        return 0.0

    ox0 = max(bb_a[0], bb_b[0])
    oy0 = max(bb_a[1], bb_b[1])
    ox1 = min(bb_a[2], bb_b[2])
    oy1 = min(bb_a[3], bb_b[3])
    if ox0 > ox1 or oy0 > oy1:
        return 0.0

    c_lon = (ox0 + ox1) * 0.5
    c_lat = (oy0 + oy1) * 0.5
    use_est = 19.0 <= c_lon <= 31.0 and 56.0 <= c_lat <= 62.0
    cos_lat = math.cos(c_lat * _RAD)
    ref_x, ref_y = project_wgs84_to_estonia_3301(c_lon, c_lat) if use_est else (c_lon, c_lat)

    pa = _extract_polys_projected(geom_a, ref_x, ref_y, use_est, cos_lat)
    pb = _extract_polys_projected(geom_b, ref_x, ref_y, use_est, cos_lat)
    if not pa or not pb:
        return 0.0

    def _pbb(polys: List[List[List[Tuple[float, float]]]]) -> Tuple[float, float, float, float]:
        xs = [c[0] for rings in polys for c in rings[0]]
        ys = [c[1] for rings in polys for c in rings[0]]
        return (min(xs), min(ys), max(xs), max(ys))

    ma = _pbb(pa)
    mb = _pbb(pb)
    rx0 = max(ma[0], mb[0])
    ry0 = max(ma[1], mb[1])
    rx1 = min(ma[2], mb[2])
    ry1 = min(ma[3], mb[3])
    if rx0 > rx1 or ry0 > ry1:
        return 0.0

    idx_a = _EdgeIndex2D(pa, rx0, ry0, rx1, ry1)
    idx_b = _EdgeIndex2D(pb, rx0, ry0, rx1, ry1)

    def _accumulate(src: _EdgeIndex2D, other: _EdgeIndex2D, count_collinear_same: bool) -> float:
        eps = 1e-7
        a2 = 0.0
        for x0, y0, x1, y1, ex0, ey0, ex1, ey1, _eid in src.r_edges:
            dx = x1 - x0
            dy = y1 - y0
            length = math.hypot(dx, dy)
            if length < 1e-9:
                continue
            g0x = max(0, min(other.gx_n - 1, int(math.floor((ex0 - other.rx0) / other.dxg))))
            g1x = max(0, min(other.gx_n - 1, int(math.floor((ex1 - other.rx0) / other.dxg))))
            g0y = max(0, min(other.gy_n - 1, int(math.floor((ey0 - other.ry0) / other.dyg))))
            g1y = max(0, min(other.gy_n - 1, int(math.floor((ey1 - other.ry0) / other.dyg))))
            seen_ids: Set[int] = set()
            ts = [0.0, 1.0]
            col_spans: List[Tuple[float, float, bool]] = []
            inv_l2 = 1.0 / (length * length)
            for gx in range(g0x, g1x + 1):
                for gy in range(g0y, g1y + 1):
                    for ox0, oy0, ox1, oy1, oex0, oey0, oex1, oey1, oeid in other.grid[gy * other.gx_n + gx]:
                        if oeid in seen_ids:
                            continue
                        seen_ids.add(oeid)
                        if not (ex0 <= oex1 + eps and ex1 >= oex0 - eps and ey0 <= oey1 + eps and ey1 >= oey0 - eps):
                            continue
                        odx = ox1 - ox0
                        ody = oy1 - oy0
                        denom = dx * ody - dy * odx
                        qpx = ox0 - x0
                        qpy = oy0 - y0
                        if abs(denom) > 1e-10:
                            t = (qpx * ody - qpy * odx) / denom
                            u = (qpx * dy - qpy * dx) / denom
                            if 1e-9 < t < 1.0 - 1e-9 and -1e-9 <= u <= 1.0 + 1e-9:
                                ts.append(t)
                        else:
                            perp = abs(qpx * dy - qpy * dx) / length
                            if perp < 1e-5:
                                t0 = (qpx * dx + qpy * dy) * inv_l2
                                t1 = ((ox1 - x0) * dx + (oy1 - y0) * dy) * inv_l2
                                same_dir = (dx * odx + dy * ody) > 0.0
                                if t0 > t1:
                                    t0, t1 = t1, t0
                                a = max(0.0, t0)
                                b = min(1.0, t1)
                                if b - a > 1e-9:
                                    if 1e-9 < a < 1.0 - 1e-9:
                                        ts.append(a)
                                    if 1e-9 < b < 1.0 - 1e-9:
                                        ts.append(b)
                                    col_spans.append((a, b, same_dir))
            if len(ts) > 2:
                ts.sort()
            for ti in range(len(ts) - 1):
                ta = ts[ti]
                tb = ts[ti + 1]
                if tb - ta <= 1e-9:
                    continue
                tm = (ta + tb) * 0.5
                is_col = False
                col_same = False
                for ca, cb, csame in col_spans:
                    if ca - 1e-8 <= tm <= cb + 1e-8:
                        is_col = True
                        if csame:
                            col_same = True
                if is_col:
                    include = bool(count_collinear_same and col_same)
                else:
                    include = other.point_in(x0 + dx * tm, y0 + dy * tm)
                if include:
                    ax = x0 + dx * ta
                    ay = y0 + dy * ta
                    bx = x0 + dx * tb
                    by = y0 + dy * tb
                    a2 += ax * by - bx * ay
        return a2

    area2 = _accumulate(idx_a, idx_b, True) + _accumulate(idx_b, idx_a, False)
    return max(0.0, area2 * 0.5) / 10000.0


def _geom_kind_from_qgis_layer(layer: Any) -> str:
    try:
        gtype = int(layer.geometryType())
        if gtype == 2:
            return "polygon"
        if gtype == 1:
            return "line"
        if gtype == 0:
            return "point"
    except Exception:
        pass
    return "unknown"


def _geom_kind_from_geojson(geoms_map: Dict[str, Any]) -> str:
    for g in geoms_map.values():
        if not isinstance(g, dict):
            continue
        gt = str(g.get("type") or "").lower()
        if "polygon" in gt:
            return "polygon"
        if "line" in gt:
            return "line"
        if "point" in gt:
            return "point"
    return "unknown"


def _encode_relation_payload(
    name_a: str,
    name_b: str,
    geom_kind_a: str,
    geom_kind_b: str,
    count_a: int,
    count_b: int,
    raw_edges: List[Tuple[str, str, float]],
) -> Dict[str, Any]:
    ka: List[str] = []
    kb: List[str] = []
    ka_idx: Dict[str, int] = {}
    kb_idx: Dict[str, int] = {}
    packed_edges: List[List[Any]] = []
    for fid_a, fid_b, val in raw_edges:
        ia = ka_idx.get(fid_a)
        if ia is None:
            ia = len(ka)
            ka_idx[fid_a] = ia
            ka.append(fid_a)
        ib = kb_idx.get(fid_b)
        if ib is None:
            ib = len(kb)
            kb_idx[fid_b] = ib
            kb.append(fid_b)
        packed_edges.append([ia, ib, round(val, 6) if val >= 0 else -1])

    payload = {"ka": ka, "kb": kb, "e": packed_edges}
    raw_bytes = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    comp_b64 = base64.b64encode(gzip.compress(raw_bytes, compresslevel=6)).decode("ascii")
    return {
        "layer_a": name_a,
        "layer_b": name_b,
        "geom_kind_a": geom_kind_a,
        "geom_kind_b": geom_kind_b,
        "exact": True,
        "complete": True,
        "count_a": int(count_a),
        "count_b": int(count_b),
        "edge_count": len(packed_edges),
        "edges_gzip_b64": comp_b64,
    }


def decompress_spatial_relation(rel_dict: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Decode `edges_gzip_b64` into fast bi-directional FID adjacency lookups."""
    if not isinstance(rel_dict, dict) or not rel_dict.get("complete") or not rel_dict.get("exact"):
        return None
    b64 = rel_dict.get("edges_gzip_b64")
    if not b64:
        return {"ka": [], "kb": [], "e": [], "by_a": {}, "by_b": {}}
    try:
        raw = gzip.decompress(base64.b64decode(b64)).decode("utf-8")
        obj = json.loads(raw)
        ka = list(obj.get("ka") or [])
        kb = list(obj.get("kb") or [])
        edges = list(obj.get("e") or [])
        by_a: Dict[str, List[Tuple[str, float]]] = {}
        by_b: Dict[str, List[Tuple[str, float]]] = {}
        for item in edges:
            if not isinstance(item, list) or len(item) < 3:
                continue
            fa = ka[int(item[0])]
            fb = kb[int(item[1])]
            ha = float(item[2])
            by_a.setdefault(fa, []).append((fb, ha))
            by_b.setdefault(fb, []).append((fa, ha))
        return {"ka": ka, "kb": kb, "e": edges, "by_a": by_a, "by_b": by_b}
    except Exception:
        return None


def compute_exact_spatial_relation_qgis(
    name_a: str,
    layer_a: Any,
    recs_a: Optional[List[Dict[str, Any]]],
    name_b: str,
    layer_b: Any,
    recs_b: Optional[List[Dict[str, Any]]],
    progress_cb: Optional[Callable[[int, str], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> Dict[str, Any]:
    """
    Compute exact QGIS GEOS spatial intersection graph between any two spatial vector layers.
    Enforces strict dataset completeness before committing results.
    """
    na, nb = _normalized_pair(name_a, name_b)
    if na != name_a:
        name_a, name_b = name_b, name_a
        layer_a, layer_b = layer_b, layer_a
        recs_a, recs_b = recs_b, recs_a

    def _fail(reason: str, ca: int = 0, cb: int = 0) -> Dict[str, Any]:
        return {
            "layer_a": name_a,
            "layer_b": name_b,
            "exact": False,
            "complete": False,
            "reason": reason,
            "count_a": int(ca),
            "count_b": int(cb),
            "edge_count": 0,
        }

    if (
        layer_a is None
        or layer_b is None
        or not hasattr(layer_a, "getFeatures")
        or not hasattr(layer_b, "getFeatures")
        or not getattr(layer_a, "isSpatial", lambda: False)()
        or not getattr(layer_b, "isSpatial", lambda: False)()
    ):
        return _fail("missing_spatial_qgis_layer")

    try:
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsFeatureRequest,
            QgsGeometry,
            QgsProject,
            QgsSpatialIndex,
        )
    except Exception:
        return _fail("qgis_core_unavailable")

    fc_a = int(layer_a.featureCount()) if hasattr(layer_a, "featureCount") else -1
    fc_b = int(layer_b.featureCount()) if hasattr(layer_b, "featureCount") else -1
    if fc_a == 0 or fc_b == 0:
        return _fail("empty_layer", max(0, fc_a), max(0, fc_b))

    if recs_a is not None and fc_a >= 0 and len(recs_a) != fc_a:
        return _fail("incomplete_records_a", len(recs_a), max(0, fc_b))
    if recs_b is not None and fc_b >= 0 and len(recs_b) != fc_b:
        return _fail("incomplete_records_b", max(0, fc_a), len(recs_b))

    kind_a = _geom_kind_from_qgis_layer(layer_a)
    kind_b = _geom_kind_from_qgis_layer(layer_b)
    both_polygons = kind_a == "polygon" and kind_b == "polygon"

    fid_map_a = build_qgis_fid_to_record_key_map(layer_a, recs_a) if recs_a else {}
    fid_map_b = build_qgis_fid_to_record_key_map(layer_b, recs_b) if recs_b else {}

    tctx = QgsProject.instance().transformContext()
    crs_a = layer_a.crs()
    crs_b = layer_b.crs()

    work_crs = crs_a
    if not is_qgis_planar_metric_crs(crs_a) and is_qgis_planar_metric_crs(crs_b):
        work_crs = crs_b
    elif not is_qgis_planar_metric_crs(crs_a):
        try:
            ext = layer_a.extent()
            if (
                not ext.isEmpty()
                and crs_a.isGeographic()
                and ext.xMaximum() >= 19.0
                and ext.xMinimum() <= 31.0
                and ext.yMaximum() >= 56.0
                and ext.yMinimum() <= 62.0
            ):
                est = QgsCoordinateReferenceSystem("EPSG:3301")
                if est.isValid():
                    work_crs = est
        except Exception:
            pass

    xf_a = QgsCoordinateTransform(crs_a, work_crs, tctx) if crs_a.isValid() and work_crs.isValid() and crs_a != work_crs else None
    xf_b = QgsCoordinateTransform(crs_b, work_crs, tctx) if crs_b.isValid() and work_crs.isValid() and crs_b != work_crs else None
    area_calc = QgisCartesianAreaCalculator(work_crs, tctx, layer=layer_a)

    # Index the smaller layer and stream the larger layer
    swap_order = fc_a > 0 and fc_b > 0 and fc_a < fc_b
    idx_layer = layer_a if swap_order else layer_b
    stream_layer = layer_b if swap_order else layer_a
    idx_xf = xf_a if swap_order else xf_b
    stream_xf = xf_b if swap_order else xf_a
    idx_fmap = fid_map_a if swap_order else fid_map_b
    stream_fmap = fid_map_b if swap_order else fid_map_a

    def _no_attr_req():
        req = QgsFeatureRequest()
        flags_cls = getattr(QgsFeatureRequest, "Flags", QgsFeatureRequest)
        if hasattr(QgsFeatureRequest, "NoAttributes"):
            req.setFlags(QgsFeatureRequest.NoAttributes)
        elif hasattr(flags_cls, "NoAttributes"):
            req.setFlags(flags_cls.NoAttributes)
        return req

    sp_index = QgsSpatialIndex()
    indexed_geoms: Dict[int, Any] = {}
    indexed_keys: Dict[int, str] = {}
    indexed_valid_cache: Dict[int, Any] = {}

    for feat in idx_layer.getFeatures(_no_attr_req()):
        if cancel_check and cancel_check():
            return _fail("cancelled")
        if not feat.hasGeometry():
            continue
        g = QgsGeometry(feat.geometry())
        if g.isEmpty():
            continue
        if idx_xf is not None:
            try:
                g.transform(idx_xf)
            except Exception:
                continue
        if idx_xf is None and work_crs == idx_layer.crs():
            sp_index.addFeature(feat)
        else:
            from qgis.core import QgsFeature as _QF  # type: ignore

            tf = _QF()
            tf.setId(feat.id())
            tf.setGeometry(g)
            sp_index.addFeature(tf)
        indexed_geoms[feat.id()] = g
        indexed_keys[feat.id()] = idx_fmap.get(feat.id(), str(feat.id()))

    stream_total = int(stream_layer.featureCount()) if hasattr(stream_layer, "featureCount") else 0
    raw_edges: List[Tuple[str, str, float]] = []
    seen_stream = 0
    step_report = max(250, (stream_total // 12) if stream_total > 0 else 500)

    def _safe_valid(geom_obj: Any) -> Any:
        try:
            if not geom_obj.isGeosValid():
                fixed = geom_obj.makeValid()
                if fixed and not fixed.isEmpty():
                    return fixed
        except Exception:
            pass
        return geom_obj

    for sfeat in stream_layer.getFeatures(_no_attr_req()):
        if cancel_check and cancel_check():
            return _fail("cancelled")
        seen_stream += 1
        if progress_cb and (seen_stream % step_report == 0) and stream_total > 0:
            progress_cb(min(99, int(round(100 * seen_stream / stream_total))), f"{name_a} ↔ {name_b}")
        if not sfeat.hasGeometry():
            continue
        sg = QgsGeometry(sfeat.geometry())
        if sg.isEmpty():
            continue
        if stream_xf is not None:
            try:
                sg.transform(stream_xf)
            except Exception:
                continue
        cand_ids = sp_index.intersects(sg.boundingBox())
        if not cand_ids:
            continue
        s_key = stream_fmap.get(sfeat.id(), str(sfeat.id()))
        sg_valid = None
        for iid in cand_ids:
            ig = indexed_geoms.get(iid)
            if ig is None:
                continue
            i_key = indexed_keys[iid]
            try:
                hits = bool(sg.intersects(ig))
            except Exception:
                sg_valid = sg_valid or _safe_valid(sg)
                ig_v = indexed_valid_cache.get(iid)
                if ig_v is None:
                    ig_v = _safe_valid(ig)
                    indexed_valid_cache[iid] = ig_v
                try:
                    hits = bool(sg_valid.intersects(ig_v))
                except Exception:
                    hits = False
            if not hits:
                continue

            if both_polygons:
                try:
                    src_g = sg_valid if sg_valid is not None else sg
                    tgt_g = indexed_valid_cache.get(iid, ig)
                    inter = src_g.intersection(tgt_g)
                except Exception:
                    sg_valid = sg_valid or _safe_valid(sg)
                    ig_v = indexed_valid_cache.get(iid)
                    if ig_v is None:
                        ig_v = _safe_valid(ig)
                        indexed_valid_cache[iid] = ig_v
                    try:
                        inter = sg_valid.intersection(ig_v)
                    except Exception:
                        inter = None
                if inter is None or inter.isEmpty():
                    continue
                ha_raw = area_calc.measure_ha(inter, decimals=8)
                if ha_raw <= 1e-6:
                    continue
                ha = round(ha_raw, 6)
                edge = (i_key, s_key, ha) if swap_order else (s_key, i_key, ha)
            else:
                edge = (i_key, s_key, -1.0) if swap_order else (s_key, i_key, -1.0)
            raw_edges.append(edge)

    cnt_a = fc_a if fc_a >= 0 else (len(recs_a) if recs_a else (len(indexed_geoms) if swap_order else seen_stream))
    cnt_b = fc_b if fc_b >= 0 else (len(recs_b) if recs_b else (seen_stream if swap_order else len(indexed_geoms)))
    return _encode_relation_payload(name_a, name_b, kind_a, kind_b, cnt_a, cnt_b, raw_edges)


def compute_exact_spatial_relation_geojson(
    name_a: str,
    recs_a: List[Dict[str, Any]],
    geoms_a: Dict[str, Dict[str, Any]],
    name_b: str,
    recs_b: List[Dict[str, Any]],
    geoms_b: Dict[str, Dict[str, Any]],
    progress_cb: Optional[Callable[[int, str], None]] = None,
) -> Dict[str, Any]:
    """
    Compute exact analytical intersection graph from complete unsimplified WGS84 GeoJSON
    geometries (`lod >= 3`). Rejects incomplete geometry sets instead of fabricating overlaps.
    """
    na, nb = _normalized_pair(name_a, name_b)
    if na != name_a:
        name_a, name_b = name_b, name_a
        recs_a, recs_b = recs_b, recs_a
        geoms_a, geoms_b = geoms_b, geoms_a

    def _fail(reason: str) -> Dict[str, Any]:
        return {
            "layer_a": name_a,
            "layer_b": name_b,
            "exact": False,
            "complete": False,
            "reason": reason,
            "count_a": len(recs_a or []),
            "count_b": len(recs_b or []),
            "edge_count": 0,
        }

    if not recs_a or not recs_b:
        return _fail("empty_records")

    items_a: List[Tuple[str, Dict[str, Any], Tuple[float, float, float, float]]] = []
    items_b: List[Tuple[str, Dict[str, Any], Tuple[float, float, float, float]]] = []

    for r in recs_a:
        fid = r.get("_feature_id")
        fk = str(fid) if fid is not None else ""
        g = geoms_a.get(fk) if fk else None
        if not fk or not isinstance(g, dict):
            return _fail("missing_exact_geometries_a")
        bb = geojson_bbox_wgs84(g)
        if bb is None:
            return _fail("invalid_bbox_a")
        items_a.append((fk, g, bb))

    for r in recs_b:
        fid = r.get("_feature_id")
        fk = str(fid) if fid is not None else ""
        g = geoms_b.get(fk) if fk else None
        if not fk or not isinstance(g, dict):
            return _fail("missing_exact_geometries_b")
        bb = geojson_bbox_wgs84(g)
        if bb is None:
            return _fail("invalid_bbox_b")
        items_b.append((fk, g, bb))

    kind_a = _geom_kind_from_geojson(geoms_a)
    kind_b = _geom_kind_from_geojson(geoms_b)
    both_polygons = kind_a == "polygon" and kind_b == "polygon"

    swap_order = len(items_a) < len(items_b)
    idx_items = items_a if swap_order else items_b
    stream_items = items_b if swap_order else items_a

    cell = 0.04
    grid: Dict[Tuple[int, int], List[Tuple[str, Dict[str, Any], Tuple[float, float, float, float]]]] = {}
    for it in idx_items:
        bb = it[2]
        gx0 = int(math.floor(bb[0] / cell))
        gx1 = int(math.floor(bb[2] / cell))
        gy0 = int(math.floor(bb[1] / cell))
        gy1 = int(math.floor(bb[3] / cell))
        for gx in range(gx0, gx1 + 1):
            for gy in range(gy0, gy1 + 1):
                grid.setdefault((gx, gy), []).append(it)

    raw_edges: List[Tuple[str, str, float]] = []
    n_stream = max(1, len(stream_items))
    step_report = max(250, n_stream // 10)
    for idx_s, (sfid, sg, sbb) in enumerate(stream_items):
        if progress_cb and idx_s % step_report == 0:
            progress_cb(min(99, int(round(100 * idx_s / n_stream))), f"{name_a} ↔ {name_b}")
        gx0 = int(math.floor(sbb[0] / cell))
        gx1 = int(math.floor(sbb[2] / cell))
        gy0 = int(math.floor(sbb[1] / cell))
        gy1 = int(math.floor(sbb[3] / cell))
        seen_cands: Set[str] = set()
        for gx in range(gx0, gx1 + 1):
            for gy in range(gy0, gy1 + 1):
                for ifid, ig, ibb in grid.get((gx, gy), ()):
                    if ifid in seen_cands:
                        continue
                    seen_cands.add(ifid)
                    if not _bbox_overlaps(sbb, ibb):
                        continue
                    if both_polygons:
                        ha = exact_polygon_intersection_area_ha_geojson(sg, ig)
                        if ha <= 1e-6:
                            continue
                        ha_r = round(ha, 6)
                        edge = (ifid, sfid, ha_r) if swap_order else (sfid, ifid, ha_r)
                    else:
                        if not geom_intersects_geom(sg, ig):
                            continue
                        edge = (ifid, sfid, -1.0) if swap_order else (sfid, ifid, -1.0)
                    raw_edges.append(edge)

    return _encode_relation_payload(
        name_a, name_b, kind_a, kind_b, len(items_a), len(items_b), raw_edges
    )
