# -*- coding: utf-8 -*-
"""Core dashboard models, reactive filter bus, aggregation engine, and persistence."""
