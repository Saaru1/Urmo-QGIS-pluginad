# -*- coding: utf-8 -*-
"""
QGIS-Oriented Dashboard Expression Engine (Safe AST Parser & Evaluator).

Supports QGIS expression idioms ("field", 'text', $area, || concatenation,
CASE WHEN ... THEN ... ELSE ... END, IN, LIKE/ILIKE, IS [NOT] NULL) alongside
UI-oriented dashboard aggregates & formatting helpers:
  - sum("field" [, condition]) / mean(...) / count(...) / count_distinct(...)
  - minimum(...) / maximum(...) / median(...) / pct_share(condition [, "field"])
  - Cross-layer helpers: layer_sum('Layer', 'field' [, cond]), layer_count(...), ...
  - UI formatting helpers: format_number(x, dec), format_ha(x, dec), format_pct(x, dec),
    percent(part, total), coalesce(...), if(cond, t, f), clamp(v, lo, hi), round(...)
"""

import math
import re
import statistics
from typing import Any, Dict, List, Optional, Set, Tuple

from .aggregator import _resolve_record_value, _to_float


AGG_FUNCTIONS = {
    "sum",
    "mean",
    "avg",
    "count",
    "count_distinct",
    "minimum",
    "maximum",
    "median",
    "pct_share",
    "layer_sum",
    "layer_mean",
    "layer_avg",
    "layer_count",
    "layer_count_distinct",
    "layer_min",
    "layer_max",
    "layer_median",
    "widget",
    "widget_value",
    "widget_count",
}

WIDGET_REF_FUNCTIONS = {"widget", "widget_value", "widget_count"}

CROSS_LAYER_FUNCTIONS = {
    "layer_sum",
    "layer_mean",
    "layer_avg",
    "layer_count",
    "layer_count_distinct",
    "layer_min",
    "layer_max",
    "layer_median",
    "widget",
    "widget_value",
    "widget_count",
}

WIDGET_REF_FUNCTIONS = {"widget", "widget_value", "widget_count"}

EXPRESSION_HELPERS: List[Dict[str, str]] = [
    # Aggregates
    {
        "category": "aggregates",
        "name": "sum",
        "snippet": 'sum("area_ha")',
        "sig": 'sum(väli_või_avaldis [, tingimus])',
        "desc_et": "Liidab kokku aktiivse kihi väärtused. Teise argumendina saab anda tingimuse, nt sum(\"area_ha\", \"pohityyp\" = '7230').",
        "desc_en": "Sums values across filtered features. Optional 2nd argument filters rows, e.g. sum(\"area_ha\", \"pohityyp\" = '7230').",
    },
    {
        "category": "aggregates",
        "name": "mean",
        "snippet": 'mean("area_ha")',
        "sig": 'mean(väli [, tingimus])',
        "desc_et": "Arvutab filtreeritud objektide aritmeetilise keskmise.",
        "desc_en": "Computes the arithmetic average across filtered features.",
    },
    {
        "category": "aggregates",
        "name": "count",
        "snippet": 'count()',
        "sig": 'count([väli [, tingimus]])',
        "desc_et": "Loendab objektid (või tingimusele vastavad mitutühjad väärtused).",
        "desc_en": "Counts features (or non-empty values matching optional filter).",
    },
    {
        "category": "aggregates",
        "name": "count_distinct",
        "snippet": 'count_distinct("pohityyp")',
        "sig": 'count_distinct(väli [, tingimus])',
        "desc_et": "Loendab unikaalsed väärtused määratud veerus.",
        "desc_en": "Counts distinct unique values in a field.",
    },
    {
        "category": "aggregates",
        "name": "minimum",
        "snippet": 'minimum("area_ha")',
        "sig": 'minimum(väli [, tingimus])',
        "desc_et": "Leiab väikseima väärtuse filtreeritud ridadest.",
        "desc_en": "Finds minimum numeric value across filtered rows.",
    },
    {
        "category": "aggregates",
        "name": "maximum",
        "snippet": 'maximum("area_ha")',
        "sig": 'maximum(väli [, tingimus])',
        "desc_et": "Leiab suurima väärtuse filtreeritud ridadest.",
        "desc_en": "Finds maximum numeric value across filtered rows.",
    },
    {
        "category": "aggregates",
        "name": "median",
        "snippet": 'median("area_ha")',
        "sig": 'median(väli [, tingimus])',
        "desc_et": "Arvutab mediaani (keskmise väärtuse) üle ridade.",
        "desc_en": "Computes the median across filtered features.",
    },
    {
        "category": "aggregates",
        "name": "pct_share",
        "snippet": 'pct_share("pohityyp" = \'7230\', "area_ha")',
        "sig": 'pct_share(tingimus [, väli])',
        "desc_et": "Arvutab tingimusele vastava osa protsendi (0–100) kogu kihi väärtusest või arvust.",
        "desc_en": "Calculates percentage share (0–100) of rows matching condition vs total.",
    },
    {
        "category": "aggregates",
        "name": "layer_sum",
        "snippet": "layer_sum('PRIA Pärandniidud', 'area_ha')",
        "sig": "layer_sum('Kihi nimi', 'väli')",
        "desc_et": "Võtab teise töölaua kihi summa (kasulik kihtide omavaheliseks võrdluseks).",
        "desc_en": "Sums a field from another dashboard layer (useful for cross-layer comparisons).",
    },
    {
        "category": "aggregates",
        "name": "layer_count",
        "snippet": "layer_count('KKR kaitsealad')",
        "sig": "layer_count('Kihi nimi')",
        "desc_et": "Loendab teise töölaua kihi filtreeritud objektid.",
        "desc_en": "Counts filtered features from another dashboard layer.",
    },
    {
        "category": "aggregates",
        "name": "widget",
        "snippet": "widget('kpi1')",
        "sig": "widget('vidina_id_või_pealkiri')",
        "desc_et": "Tagastab teise töölaua vidina (näitaja, tabeli või graafiku) kehtiva arvutatud väärtuse.",
        "desc_en": "Returns the current live filtered numeric/aggregate value of another dashboard widget.",
    },
    {
        "category": "aggregates",
        "name": "widget_count",
        "snippet": "widget_count('tbl1')",
        "sig": "widget_count('vidina_id_või_pealkiri')",
        "desc_et": "Tagastab teise vidina aktiivsete (filtreeritud) ridade arvu.",
        "desc_en": "Returns the active filtered record count of another dashboard widget.",
    },
    # Variables
    {
        "category": "variables",
        "name": "$area",
        "snippet": "$area",
        "sig": "$area",
        "desc_et": "Objekti pindala hektarites (EPSG:3301 kartograafiline pindala).",
        "desc_en": "Feature planar area in hectares (EPSG:3301 Cartesian).",
    },
    {
        "category": "variables",
        "name": "$count",
        "snippet": "$count",
        "sig": "$count / @row_count",
        "desc_et": "Aktiivsel kihil praegu filtrisse jäävate objektide arv.",
        "desc_en": "Number of filtered features currently active on the layer.",
    },
    {
        "category": "variables",
        "name": "@total_count",
        "snippet": "@total_count",
        "sig": "@total_count",
        "desc_et": "Kihi objektide koguarv enne filtreerimist.",
        "desc_en": "Total unfiltered feature count on the active layer.",
    },
    {
        "category": "variables",
        "name": "@layer_name",
        "snippet": "@layer_name",
        "sig": "@layer_name",
        "desc_et": "Valitud kihi nimi tekstina.",
        "desc_en": "Name of the active bound layer.",
    },
    # Conditionals
    {
        "category": "conditionals",
        "name": "if",
        "snippet": 'if(sum("area_ha") >= 100, \'Suur\', \'Väike\')',
        "sig": "if(tingimus, tõene_väärtus, väär_väärtus)",
        "desc_et": "Tagastab ühe väärtuse, kui tingimus kehtib, ja teise, kui ei kehti.",
        "desc_en": "Returns one value if condition is true, otherwise the fallback value.",
    },
    {
        "category": "conditionals",
        "name": "CASE WHEN",
        "snippet": 'CASE WHEN sum("area_ha") >= 1000 THEN \'Kõrge\' WHEN sum("area_ha") >= 200 THEN \'Keskmine\' ELSE \'Madal\' END',
        "sig": "CASE WHEN tingimus THEN väärtus ... ELSE muul_juhul END",
        "desc_et": "Mitme haruga tingimusavaldis nagu QGIS-is.",
        "desc_en": "Multi-branch conditional block identical to QGIS CASE WHEN.",
    },
    {
        "category": "conditionals",
        "name": "coalesce",
        "snippet": 'coalesce("nimi", \'Määramata\')',
        "sig": "coalesce(väärtus1, väärtus2, ...)",
        "desc_et": "Tagastab esimese mittetühja väärtuse loendist.",
        "desc_en": "Returns the first non-null/non-empty value.",
    },
    # Math & UI formatting
    {
        "category": "math",
        "name": "round",
        "snippet": 'round(sum("area_ha"), 1)',
        "sig": "round(arv [, komakohad=0])",
        "desc_et": "Ümardab arvu määratud komakohtadeni.",
        "desc_en": "Rounds numeric value to the given decimals.",
    },
    {
        "category": "math",
        "name": "percent",
        "snippet": 'percent($count, @total_count)',
        "sig": "percent(osa, tervik)",
        "desc_et": "Arvutab turvaliselt osakaalu protsentides (ei jaga nulliga).",
        "desc_en": "Safely computes percentage (part / total * 100).",
    },
    {
        "category": "math",
        "name": "clamp",
        "snippet": 'clamp(percent($count, @total_count), 0, 100)',
        "sig": "clamp(väärtus, min, max)",
        "desc_et": "Piirab arvu vahemikku [min, max].",
        "desc_en": "Clamps numeric value to [min, max].",
    },
    {
        "category": "math",
        "name": "abs / floor / ceil",
        "snippet": 'abs(sum("area_ha") - 500)',
        "sig": "abs(x) / floor(x) / ceil(x)",
        "desc_et": "Absoluutväärtus, põranda- või laeümardus.",
        "desc_en": "Absolute value, floor, or ceiling rounding.",
    },
    {
        "category": "formatting",
        "name": "format_ha",
        "snippet": 'format_ha(sum("area_ha"), 1)',
        "sig": "format_ha(väärtus [, komakohad=1])",
        "desc_et": "Vormindab arvu loetavaks hektarite väärtuseks (nt '1 234.5 ha').",
        "desc_en": "Formats number nicely in hectares (e.g. '1 234.5 ha').",
    },
    {
        "category": "formatting",
        "name": "format_pct",
        "snippet": 'format_pct(pct_share("pohityyp" = \'7230\', "area_ha"), 1)',
        "sig": "format_pct(protsent [, komakohad=1])",
        "desc_et": "Vormindab protsendi ilusa järelliitega (nt '34.2 %').",
        "desc_en": "Formats percentage with % suffix (e.g. '34.2 %').",
    },
    {
        "category": "formatting",
        "name": "format_number",
        "snippet": 'format_number(sum("area_ha"), 0)',
        "sig": "format_number(arv [, komakohad=1])",
        "desc_et": "Lisab tuhandeliste eraldaja ja fikseeritud komakohad.",
        "desc_en": "Formats number with thousands grouping and fixed decimals.",
    },
    {
        "category": "formatting",
        "name": "concat / ||",
        "snippet": 'concat(format_ha(sum("area_ha"), 1), \' (\', $count, \' ala)\')',
        "sig": "concat(a, b, ...) või a || b",
        "desc_et": "Ühendab tekstid ja arvud üheks loetavaks sildiks.",
        "desc_en": "Concatenates strings and numbers into one display label.",
    },
    {
        "category": "formatting",
        "name": "upper / lower / replace",
        "snippet": 'upper(coalesce("pohityyp", \'\'))',
        "sig": "upper(s) / lower(s) / replace(s, vana, uus)",
        "desc_et": "Teksti suur-/väiketähtede teisendus ja asendus.",
        "desc_en": "Case conversion and substring replacement.",
    },
]

EXPRESSION_TEMPLATES: List[Dict[str, str]] = [
    {
        "id": "sum_ha",
        "title_et": "Σ Pindala (ha)",
        "title_en": "Σ Total Area (ha)",
        "expr": 'sum($area)',
        "subtext": "format_number($count, 0) || ' / ' || format_number(@total_count, 0) || ' objekti'",
        "desc_et": "Filtreeritud alade kogupindala kartograafilistes hektarites.",
        "desc_en": "Total Cartesian area (ha) of filtered features.",
    },
    {
        "id": "cond_sum",
        "title_et": "Tingimuslik summa",
        "title_en": "Conditional Sum",
        "expr": 'sum($area, "area_ha" >= 1)',
        "subtext": "'Osakaal kogu pinnast: ' || format_pct(pct_share(\"area_ha\" >= 1, $area), 1)",
        "desc_et": "Liidab ainult tingimusele vastavate objektide väärtused.",
        "desc_en": "Sums only features matching a filter condition.",
    },
    {
        "id": "pct_filtered",
        "title_et": "Filtreeritud osakaal (%)",
        "title_en": "Filtered Share (%)",
        "expr": 'percent($count, @total_count)',
        "subtext": "format_number($count, 0) || ' objekti kokku ' || format_number(@total_count, 0) || '-st'",
        "desc_et": "Mitu protsenti kihtidest vastab aktiivsetele filtritele.",
        "desc_en": "Percentage of layer features matching active filters.",
    },
    {
        "id": "avg_area",
        "title_et": "Keskmine pindala",
        "title_en": "Mean Feature Area",
        "expr": 'mean($area)',
        "subtext": "'Min: ' || format_ha(minimum($area), 1) || ' · Max: ' || format_ha(maximum($area), 1)",
        "desc_et": "Keskmine pindala koos miinimumi ja maksimumiga alareana.",
        "desc_en": "Mean feature area with min/max shown in subtext.",
    },
    {
        "id": "status_badge",
        "title_et": "Seisundi hinnang (CASE)",
        "title_en": "Status Rating (CASE)",
        "expr": "CASE WHEN $count = 0 THEN 'Andmed puuduvad' WHEN mean($area) >= 10 THEN 'Suured alad' ELSE 'Killustunud' END",
        "subtext": "'Keskmine suurus: ' || format_ha(mean($area), 2)",
        "desc_et": "Kuvab dünaamilise tekstilise hinnangu lävendi põhjal.",
        "desc_en": "Displays dynamic text status based on threshold rules.",
    },
]


class ExpressionSyntaxError(ValueError):
    """Raised when an expression cannot be tokenized or parsed."""


def _tokenize(text: str) -> List[Tuple[str, Any, int]]:
    tokens: List[Tuple[str, Any, int]] = []
    i = 0
    n = len(text)
    keywords = {
        "AND",
        "OR",
        "NOT",
        "IN",
        "LIKE",
        "ILIKE",
        "IS",
        "NULL",
        "TRUE",
        "FALSE",
        "CASE",
        "WHEN",
        "THEN",
        "ELSE",
        "END",
    }
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch in "(),+-*/%^":
            tokens.append((ch, ch, i))
            i += 1
            continue
        two = text[i : i + 2]
        if two in ("||", "<>", "!=", "<=", ">=", "=="):
            tokens.append(("OP", two, i))
            i += 2
            continue
        if ch in "=<>":
            tokens.append(("OP", ch, i))
            i += 1
            continue
        if ch == "'":
            start = i
            i += 1
            buf = []
            while i < n:
                if text[i] == "'" and i + 1 < n and text[i + 1] == "'":
                    buf.append("'")
                    i += 2
                elif text[i] == "\\":
                    if i + 1 < n:
                        buf.append(text[i + 1])
                        i += 2
                    else:
                        i += 1
                elif text[i] == "'":
                    i += 1
                    break
                else:
                    buf.append(text[i])
                    i += 1
            else:
                raise ExpressionSyntaxError(f"Unterminated string literal at position {start}")
            tokens.append(("STR", "".join(buf), start))
            continue
        if ch == '"':
            start = i
            i += 1
            buf = []
            while i < n:
                if text[i] == '"' and i + 1 < n and text[i + 1] == '"':
                    buf.append('"')
                    i += 2
                elif text[i] == '"':
                    i += 1
                    break
                else:
                    buf.append(text[i])
                    i += 1
            else:
                raise ExpressionSyntaxError(f"Unterminated field reference at position {start}")
            tokens.append(("FIELD", "".join(buf), start))
            continue
        if ch.isdigit() or (ch == "." and i + 1 < n and text[i + 1].isdigit()):
            start = i
            m = re.match(r"\d+(?:\.\d+)?|\.\d+", text[i:])
            assert m is not None
            raw_num = m.group(0)
            i += len(raw_num)
            tokens.append(("NUM", float(raw_num), start))
            continue
        if ch.isalpha() or ch in ("_", "$", "@"):
            start = i
            m = re.match(r"[$@]?(?:[^\W0-9_]|_)[^\W]*|[$@][A-Za-z_][A-Za-z0-9_]*", text[i:], re.UNICODE)
            if not m:
                raise ExpressionSyntaxError(f"Unexpected character '{ch}' at position {i}")
            word = m.group(0)
            i += len(word)
            up = word.upper()
            if up in keywords:
                tokens.append(("KW", up, start))
            else:
                tokens.append(("IDENT", word, start))
            continue
        raise ExpressionSyntaxError(f"Unexpected character '{ch}' at position {i}")
    tokens.append(("EOF", None, n))
    return tokens


class _Parser:
    def __init__(self, tokens: List[Tuple[str, Any, int]]) -> None:
        self.tokens = tokens
        self.pos = 0

    def cur(self) -> Tuple[str, Any, int]:
        return self.tokens[self.pos]

    def match(self, kind: str, val: Any = None) -> bool:
        tk, tv, _ = self.cur()
        if tk != kind:
            return False
        if val is not None and tv != val:
            return False
        self.pos += 1
        return True

    def expect(self, kind: str, val: Any = None) -> Tuple[str, Any, int]:
        tok = self.cur()
        if tok[0] != kind or (val is not None and tok[1] != val):
            raise ExpressionSyntaxError(f"Expected {val or kind} near position {tok[2]}, got {tok[1]!r}")
        self.pos += 1
        return tok

    def parse(self) -> Tuple[Any, ...]:
        node = self.parse_or()
        if self.cur()[0] != "EOF":
            raise ExpressionSyntaxError(f"Unexpected token {self.cur()[1]!r} at position {self.cur()[2]}")
        return node

    def parse_or(self) -> Tuple[Any, ...]:
        node = self.parse_and()
        while self.match("KW", "OR"):
            node = ("OR", node, self.parse_and())
        return node

    def parse_and(self) -> Tuple[Any, ...]:
        node = self.parse_not()
        while self.match("KW", "AND"):
            node = ("AND", node, self.parse_not())
        return node

    def parse_not(self) -> Tuple[Any, ...]:
        if self.match("KW", "NOT"):
            return ("NOT", self.parse_not())
        return self.parse_cmp()

    def parse_cmp(self) -> Tuple[Any, ...]:
        node = self.parse_concat_add()
        while True:
            tk, tv, _ = self.cur()
            if tk == "KW" and tv == "IS":
                self.pos += 1
                neg = self.match("KW", "NOT")
                self.expect("KW", "NULL")
                node = ("IS_NULL", node, neg)
            elif tk == "KW" and tv == "NOT":
                nxt = self.tokens[self.pos + 1] if self.pos + 1 < len(self.tokens) else ("EOF", None, 0)
                if nxt[0] == "KW" and nxt[1] in ("IN", "LIKE", "ILIKE"):
                    self.pos += 2
                    if nxt[1] == "IN":
                        items = self._parse_in_list()
                        node = ("NOT", ("IN", node, items))
                    else:
                        node = ("NOT", (nxt[1], node, self.parse_concat_add()))
                else:
                    break
            elif tk == "KW" and tv == "IN":
                self.pos += 1
                items = self._parse_in_list()
                node = ("IN", node, items)
            elif tk == "KW" and tv in ("LIKE", "ILIKE"):
                self.pos += 1
                node = (tv, node, self.parse_concat_add())
            elif tk == "OP" and tv in ("=", "==", "!=", "<>", "<", "<=", ">", ">="):
                self.pos += 1
                node = ("CMP", tv, node, self.parse_concat_add())
            else:
                break
        return node

    def _parse_in_list(self) -> List[Tuple[Any, ...]]:
        self.expect("(")
        items: List[Tuple[Any, ...]] = []
        if not self.match(")"):
            items.append(self.parse_or())
            while self.match(","):
                items.append(self.parse_or())
            self.expect(")")
        return items

    def parse_concat_add(self) -> Tuple[Any, ...]:
        node = self.parse_mul()
        while True:
            tk, tv, _ = self.cur()
            if (tk == "OP" and tv == "||") or (tk in ("+", "-")):
                self.pos += 1
                node = ("BIN", tv, node, self.parse_mul())
            else:
                break
        return node

    def parse_mul(self) -> Tuple[Any, ...]:
        node = self.parse_pow()
        while self.cur()[0] in ("*", "/", "%"):
            op = self.cur()[1]
            self.pos += 1
            node = ("BIN", op, node, self.parse_pow())
        return node

    def parse_pow(self) -> Tuple[Any, ...]:
        node = self.parse_unary()
        if self.match("^"):
            return ("BIN", "^", node, self.parse_pow())
        return node

    def parse_unary(self) -> Tuple[Any, ...]:
        if self.match("-"):
            return ("NEG", self.parse_unary())
        if self.match("+"):
            return self.parse_unary()
        return self.parse_primary()

    def parse_primary(self) -> Tuple[Any, ...]:
        tk, tv, pos = self.cur()
        if tk == "NUM":
            self.pos += 1
            return ("LIT", tv)
        if tk == "STR":
            self.pos += 1
            return ("LIT", tv)
        if tk == "FIELD":
            self.pos += 1
            return ("FIELD", tv)
        if tk == "KW" and tv == "TRUE":
            self.pos += 1
            return ("LIT", True)
        if tk == "KW" and tv == "FALSE":
            self.pos += 1
            return ("LIT", False)
        if tk == "KW" and tv == "NULL":
            self.pos += 1
            return ("LIT", None)
        if tk == "KW" and tv == "CASE":
            return self._parse_case()
        if tk == "(":
            self.pos += 1
            inner = self.parse_or()
            self.expect(")")
            return inner
        if tk == "IDENT":
            self.pos += 1
            if self.match("("):
                args: List[Tuple[Any, ...]] = []
                if not self.match(")"):
                    args.append(self.parse_or())
                    while self.match(","):
                        args.append(self.parse_or())
                    self.expect(")")
                return ("CALL", str(tv).lower(), args)
            return ("VAR", str(tv))
        raise ExpressionSyntaxError(f"Unexpected token {tv!r} at position {pos}")

    def _parse_case(self) -> Tuple[Any, ...]:
        self.expect("KW", "CASE")
        base_expr = None
        if self.cur()[:2] != ("KW", "WHEN"):
            base_expr = self.parse_or()
        branches: List[Tuple[Any, Any]] = []
        while self.match("KW", "WHEN"):
            cond = self.parse_or()
            self.expect("KW", "THEN")
            res = self.parse_or()
            branches.append((cond, res))
        else_expr: Any = ("LIT", None)
        if self.match("KW", "ELSE"):
            else_expr = self.parse_or()
        self.expect("KW", "END")
        return ("CASE", base_expr, branches, else_expr)


def parse_expression(expr: str) -> Tuple[Any, ...]:
    """Parse an expression string into an AST, raising ExpressionSyntaxError on bad syntax."""
    text = str(expr or "").strip()
    if not text:
        raise ExpressionSyntaxError("Empty expression")
    return _Parser(_tokenize(text)).parse()


def _ast_has_agg(node: Any) -> bool:
    if not isinstance(node, tuple) or not node:
        return False
    op = node[0]
    if op == "CALL":
        fn = node[1]
        if fn in AGG_FUNCTIONS:
            return True
        return any(_ast_has_agg(a) for a in node[2])
    if op == "VAR":
        v = str(node[1]).lower()
        return v in ("$count", "@row_count", "@feature_count", "@total_count", "@filter_count")
    return any(_ast_has_agg(child) for child in node[1:])


def _ast_has_row_field(node: Any) -> bool:
    if not isinstance(node, tuple) or not node:
        return False
    op = node[0]
    if op == "FIELD":
        return True
    if op == "VAR":
        v = str(node[1]).lower()
        return v not in ("$count", "@row_count", "@feature_count", "@total_count", "@filter_count", "@layer", "@layer_name")
    if op == "CALL" and node[1] in AGG_FUNCTIONS:
        return False
    return any(_ast_has_row_field(child) for child in node[1:])


def extract_referenced_layers(expr: str) -> Set[str]:
    """Return cross-layer names referenced by layer_sum('LayerName', ...) calls."""
    if not expr or not str(expr).strip():
        return set()
    try:
        ast = parse_expression(expr)
    except Exception:
        return set()
    out: Set[str] = set()

    def walk(node: Any) -> None:
        if not isinstance(node, tuple) or not node:
            return
        if node[0] == "CALL" and node[1] in CROSS_LAYER_FUNCTIONS and node[2]:
            arg0 = node[2][0]
            if isinstance(arg0, tuple) and arg0[0] in ("LIT", "FIELD", "VAR") and arg0[1]:
                out.add(str(arg0[1]).strip())
        for ch in node[1:]:
            if isinstance(ch, list):
                for el in ch:
                    walk(el)
            elif isinstance(ch, tuple):
                walk(ch)

    walk(ast)
    return out


def extract_referenced_widgets(expr: str) -> Set[str]:
    """Return widget IDs/titles referenced by widget('id') or widget_count('id') calls."""
    if not expr or not str(expr).strip():
        return set()
    try:
        ast = parse_expression(expr)
    except Exception:
        return set()
    out: Set[str] = set()

    def walk(node: Any) -> None:
        if not isinstance(node, tuple) or not node:
            return
        if node[0] == "CALL" and node[1] in WIDGET_REF_FUNCTIONS and node[2]:
            arg0 = node[2][0]
            if isinstance(arg0, tuple) and arg0[0] in ("LIT", "FIELD", "VAR") and arg0[1]:
                out.add(str(arg0[1]).strip())
        for ch in node[1:]:
            if isinstance(ch, list):
                for el in ch:
                    walk(el)
            elif isinstance(ch, tuple):
                walk(ch)

    walk(ast)
    return out


def extract_layers_from_blocks(blocks: Any) -> Set[str]:
    """Extract all layer/table names referenced anywhere inside a Lego block list."""
    out: Set[str] = set()
    if not isinstance(blocks, list):
        return out
    for blk in blocks:
        if not isinstance(blk, dict):
            continue
        if blk.get("kind") == "metric" and str(blk.get("layer") or "").strip():
            out.add(str(blk["layer"]).strip())
        for key in ("items", "part", "whole", "cond", "then", "else", "inner"):
            sub = blk.get(key)
            if isinstance(sub, list):
                out.update(extract_layers_from_blocks(sub))
    return out


def extract_widgets_from_blocks(blocks: Any) -> Set[str]:
    """Extract all widget IDs referenced inside Lego widget_ref blocks."""
    out: Set[str] = set()
    if not isinstance(blocks, list):
        return out
    for blk in blocks:
        if not isinstance(blk, dict):
            continue
        if blk.get("kind") == "widget_ref" and str(blk.get("widget_id") or "").strip():
            out.add(str(blk["widget_id"]).strip())
        for key in ("items", "part", "whole", "cond", "then", "else", "inner"):
            sub = blk.get(key)
            if isinstance(sub, list):
                out.update(extract_widgets_from_blocks(sub))
    return out


def _truthy(val: Any) -> bool:
    if val is None or val is False:
        return False
    if isinstance(val, (int, float)):
        return val != 0 and not math.isnan(float(val))
    s = str(val).strip().lower()
    return s not in ("", "0", "false", "null", "none")


def _norm_qgis_val(val: Any) -> Any:
    if val is None:
        return None
    cname = type(val).__name__
    if "NULL" in repr(val) and cname in ("QVariant", "QPyNullVariant"):
        return None
    return val


def _like_to_regex(pattern: str, ignore_case: bool) -> re.Pattern:
    escaped = []
    for ch in str(pattern):
        if ch == "%":
            escaped.append(".*")
        elif ch == "_":
            escaped.append(".")
        else:
            escaped.append(re.escape(ch))
    flags = re.DOTALL | (re.IGNORECASE if ignore_case else 0)
    return re.compile("^" + "".join(escaped) + "$", flags)


def _format_num_spaced(val: float, dec: int = 1) -> str:
    dec = max(0, min(6, int(dec)))
    if dec == 0:
        return f"{int(round(val)):,}".replace(",", " ")
    return f"{val:,.{dec}f}".replace(",", " ")


class ExpressionEvaluator:
    """Evaluate a parsed AST against dashboard records and optional cross-layers."""

    def __init__(
        self,
        records: Optional[List[Dict[str, Any]]] = None,
        all_records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        layer_name: str = "",
        total_count: Optional[int] = None,
        filter_count: int = 0,
        filter_fn: Optional[Any] = None,
        widget_resolver: Optional[Any] = None,
    ) -> None:
        self.records = list(records or [])
        self.all_records_by_layer = all_records_by_layer or {}
        self.layer_name = str(layer_name or "")
        self.total_count = int(total_count) if total_count is not None else len(self.records)
        self.filter_count = int(filter_count or 0)
        self.filter_fn = filter_fn
        self.widget_resolver = widget_resolver

    def _layer_rows(self, target_layer: str) -> List[Dict[str, Any]]:
        if not target_layer or target_layer == self.layer_name:
            return self.records
        raw = self.all_records_by_layer.get(target_layer, [])
        if callable(self.filter_fn):
            try:
                return list(self.filter_fn(target_layer, raw) or [])
            except Exception:
                return list(raw)
        return list(raw)

    def _agg_values(
        self,
        func: str,
        rows: List[Dict[str, Any]],
        val_ast: Optional[Tuple[Any, ...]],
        cond_ast: Optional[Tuple[Any, ...]],
    ) -> float:
        matched_rows = [r for r in rows if _truthy(self.eval_node(cond_ast, r))] if cond_ast is not None else rows
        if func == "count":
            if val_ast is None:
                return float(len(matched_rows))
            cnt = 0
            for r in matched_rows:
                v = self.eval_node(val_ast, r)
                if v is not None and str(v) != "":
                    cnt += 1
            return float(cnt)
        if func == "count_distinct":
            if val_ast is None:
                return 0.0
            seen = {
                str(self.eval_node(val_ast, r))
                for r in matched_rows
                if self.eval_node(val_ast, r) is not None and str(self.eval_node(val_ast, r)) != ""
            }
            return float(len(seen))
        if func == "pct_share":
            if cond_ast is None:
                return 0.0
            if val_ast is None:
                return (len(matched_rows) / max(1, len(rows))) * 100.0 if rows else 0.0
            part = sum(n for r in matched_rows if (n := _to_float(self.eval_node(val_ast, r))) is not None)
            whole = sum(n for r in rows if (n := _to_float(self.eval_node(val_ast, r))) is not None)
            return (part / whole) * 100.0 if whole > 0 else 0.0

        nums: List[float] = []
        if val_ast is not None:
            for r in matched_rows:
                n = _to_float(self.eval_node(val_ast, r))
                if n is not None:
                    nums.append(n)
        if not nums:
            return 0.0
        if func == "sum":
            return float(sum(nums))
        if func in ("mean", "avg"):
            return float(sum(nums) / len(nums))
        if func == "minimum":
            return float(min(nums))
        if func == "maximum":
            return float(max(nums))
        if func == "median":
            return float(statistics.median(nums))
        return 0.0

    def eval_node(self, node: Any, row: Optional[Dict[str, Any]] = None) -> Any:
        if node is None or not isinstance(node, tuple):
            return None
        op = node[0]
        if op == "LIT":
            return node[1]
        if op == "FIELD":
            if row is None:
                return None
            fname = str(node[1])
            if fname in ("$area", "$area_ha", "area_ha"):
                v = _resolve_record_value(row, "__calc_area_ha__" if fname.startswith("$") else fname)
            else:
                v = _resolve_record_value(row, fname)
            return _norm_qgis_val(v)
        if op == "VAR":
            vname = str(node[1])
            low = vname.lower()
            if low in ("$area", "$area_ha"):
                return float(_to_float(_resolve_record_value(row or {}, "__calc_area_ha__")) or 0.0) if row is not None else 0.0
            if low == "$area_m2":
                ha = float(_to_float(_resolve_record_value(row or {}, "__calc_area_ha__")) or 0.0) if row is not None else 0.0
                return ha * 10000.0
            if low in ("$count", "@row_count", "@feature_count"):
                return len(self.records)
            if low == "@total_count":
                return self.total_count
            if low == "@filter_count":
                return self.filter_count
            if low in ("@layer", "@layer_name"):
                return self.layer_name
            if row is not None and vname in row:
                return _norm_qgis_val(row.get(vname))
            return None
        if op == "NEG":
            val = _to_float(self.eval_node(node[1], row))
            return -(val or 0.0)
        if op == "NOT":
            return not _truthy(self.eval_node(node[1], row))
        if op == "AND":
            return _truthy(self.eval_node(node[1], row)) and _truthy(self.eval_node(node[2], row))
        if op == "OR":
            return _truthy(self.eval_node(node[1], row)) or _truthy(self.eval_node(node[2], row))
        if op == "IS_NULL":
            v = self.eval_node(node[1], row)
            is_n = v is None or v == ""
            return (not is_n) if node[2] else is_n
        if op == "IN":
            left = self.eval_node(node[1], row)
            items = [self.eval_node(it, row) for it in node[2]]
            ln = _to_float(left)
            for item in items:
                if ln is not None and _to_float(item) is not None and ln == _to_float(item):
                    return True
                if str(left) == str(item):
                    return True
            return False
        if op in ("LIKE", "ILIKE"):
            left = "" if self.eval_node(node[1], row) is None else str(self.eval_node(node[1], row))
            pat = "" if self.eval_node(node[2], row) is None else str(self.eval_node(node[2], row))
            return bool(_like_to_regex(pat, op == "ILIKE").match(left))
        if op == "CMP":
            cmp_op = node[1]
            lv = self.eval_node(node[2], row)
            rv = self.eval_node(node[3], row)
            ln, rn = _to_float(lv), _to_float(rv)
            if ln is not None and rn is not None:
                a, b = ln, rn
            else:
                a = "" if lv is None else str(lv)
                b = "" if rv is None else str(rv)
            if cmp_op in ("=", "=="):
                return (lv is None and rv is None) if (lv is None or rv is None) else (a == b)
            if cmp_op in ("!=", "<>"):
                return not ((lv is None and rv is None) if (lv is None or rv is None) else (a == b))
            if lv is None or rv is None:
                return False
            if cmp_op == "<":
                return a < b
            if cmp_op == "<=":
                return a <= b
            if cmp_op == ">":
                return a > b
            if cmp_op == ">=":
                return a >= b
        if op == "BIN":
            bop = node[1]
            if bop == "||":
                lv = self.eval_node(node[2], row)
                rv = self.eval_node(node[3], row)
                return ("" if lv is None else str(lv)) + ("" if rv is None else str(rv))
            ln = _to_float(self.eval_node(node[2], row)) or 0.0
            rn = _to_float(self.eval_node(node[3], row)) or 0.0
            if bop == "+":
                return ln + rn
            if bop == "-":
                return ln - rn
            if bop == "*":
                return ln * rn
            if bop == "/":
                return (ln / rn) if abs(rn) > 1e-12 else 0.0
            if bop == "%":
                return (ln % rn) if abs(rn) > 1e-12 else 0.0
            if bop == "^":
                try:
                    return math.pow(ln, rn)
                except Exception:
                    return 0.0
        if op == "CASE":
            base_expr, branches, else_expr = node[1], node[2], node[3]
            if base_expr is not None:
                bv = self.eval_node(base_expr, row)
                bn = _to_float(bv)
                for cond_ast, res_ast in branches:
                    cv = self.eval_node(cond_ast, row)
                    cn = _to_float(cv)
                    if (bn is not None and cn is not None and bn == cn) or (str(bv) == str(cv)):
                        return self.eval_node(res_ast, row)
            else:
                for cond_ast, res_ast in branches:
                    if _truthy(self.eval_node(cond_ast, row)):
                        return self.eval_node(res_ast, row)
            return self.eval_node(else_expr, row)
        if op == "CALL":
            fn = node[1]
            args = node[2]
            return self._eval_call(fn, args, row)
        return None

    def _eval_call(self, fn: str, args: List[Any], row: Optional[Dict[str, Any]]) -> Any:
        # Dashboard widget output lookup: widget('id_or_title') / widget_count('id_or_title')
        if fn in WIDGET_REF_FUNCTIONS:
            wref = str(self.eval_node(args[0], row) or "").strip() if args else ""
            if callable(self.widget_resolver) and wref:
                mode = "count" if fn == "widget_count" else "value"
                return self.widget_resolver(wref, mode)
            return 0.0

        # Cross-layer aggregates: layer_sum('Layer', 'field' [, cond])
        if fn in CROSS_LAYER_FUNCTIONS:
            lname = str(self.eval_node(args[0], row) or "") if args else self.layer_name
            trows = self._layer_rows(lname)
            base_fn = fn.replace("layer_", "")
            if base_fn == "min":
                base_fn = "minimum"
            elif base_fn == "max":
                base_fn = "maximum"
            if base_fn == "count":
                val_ast = None
                cond_ast = args[1] if len(args) >= 2 else None
                return self._agg_values("count", trows, val_ast, cond_ast)
            field_spec = str(self.eval_node(args[1], row) or "") if len(args) >= 2 else ""
            val_ast = ("VAR", "$area") if field_spec == "$area" else (("FIELD", field_spec) if field_spec else None)
            cond_ast = args[2] if len(args) >= 3 else None
            return self._agg_values(base_fn, trows, val_ast, cond_ast)

        if fn in ("sum", "mean", "avg", "count", "count_distinct", "minimum", "maximum", "median"):
            val_ast = args[0] if len(args) >= 1 else None
            cond_ast = args[1] if len(args) >= 2 else None
            return self._agg_values(fn, self.records, val_ast, cond_ast)

        if fn == "pct_share":
            cond_ast = args[0] if len(args) >= 1 else None
            val_ast = args[1] if len(args) >= 2 else None
            return self._agg_values("pct_share", self.records, val_ast, cond_ast)

        if fn in ("min", "max"):
            if len(args) == 1:
                return self._agg_values("minimum" if fn == "min" else "maximum", self.records, args[0], None)
            if len(args) == 2 and _ast_has_row_field(args[0]) and _ast_has_row_field(args[1]) and not _ast_has_agg(args[0]):
                return self._agg_values("minimum" if fn == "min" else "maximum", self.records, args[0], args[1])
            vals = [_to_float(self.eval_node(a, row)) for a in args]
            nums = [v for v in vals if v is not None]
            return (min(nums) if fn == "min" else max(nums)) if nums else 0.0

        # Conditional / logic
        if fn == "if":
            cond = self.eval_node(args[0], row) if len(args) >= 1 else False
            if _truthy(cond):
                return self.eval_node(args[1], row) if len(args) >= 2 else None
            return self.eval_node(args[2], row) if len(args) >= 3 else None
        if fn == "coalesce":
            for a in args:
                v = self.eval_node(a, row)
                if v is not None and str(v) != "":
                    return v
            return None
        if fn == "is_empty":
            v = self.eval_node(args[0], row) if args else None
            return v is None or str(v).strip() == ""

        def _arg_num(idx: int, default: float) -> float:
            if idx >= len(args):
                return default
            v = _to_float(self.eval_node(args[idx], row))
            return default if v is None else v

        # Math
        if fn == "round":
            x = _arg_num(0, 0.0)
            d = int(_arg_num(1, 0.0))
            return round(float(x), max(0, min(8, d)))
        if fn == "floor":
            return float(math.floor(_arg_num(0, 0.0)))
        if fn == "ceil":
            return float(math.ceil(_arg_num(0, 0.0)))
        if fn == "abs":
            return abs(_arg_num(0, 0.0))
        if fn == "sqrt":
            return math.sqrt(max(0.0, _arg_num(0, 0.0)))
        if fn == "pow":
            try:
                return math.pow(_arg_num(0, 0.0), _arg_num(1, 1.0))
            except Exception:
                return 0.0
        if fn == "clamp":
            return max(_arg_num(1, 0.0), min(_arg_num(2, 100.0), _arg_num(0, 0.0)))
        if fn == "percent":
            part = _arg_num(0, 0.0)
            tot = _arg_num(1, 0.0)
            return (part / tot) * 100.0 if abs(tot) > 1e-12 else 0.0

        # Formatting & Text
        if fn == "format_number":
            return _format_num_spaced(_arg_num(0, 0.0), int(_arg_num(1, 1.0)))
        if fn == "format_ha":
            return f"{_format_num_spaced(_arg_num(0, 0.0), int(_arg_num(1, 1.0)))} ha"
        if fn == "format_pct":
            return f"{_format_num_spaced(_arg_num(0, 0.0), int(_arg_num(1, 1.0)))} %"
        if fn == "concat":
            return "".join("" if (v := self.eval_node(a, row)) is None else str(v) for a in args)
        if fn == "upper":
            v = self.eval_node(args[0], row) if args else ""
            return ("" if v is None else str(v)).upper()
        if fn == "lower":
            v = self.eval_node(args[0], row) if args else ""
            return ("" if v is None else str(v)).lower()
        if fn == "title":
            v = self.eval_node(args[0], row) if args else ""
            return ("" if v is None else str(v)).title()
        if fn == "trim":
            v = self.eval_node(args[0], row) if args else ""
            return ("" if v is None else str(v)).strip()
        if fn == "length":
            v = self.eval_node(args[0], row) if args else ""
            return len("" if v is None else str(v))
        if fn == "left":
            v = "" if not args or self.eval_node(args[0], row) is None else str(self.eval_node(args[0], row))
            n = max(0, int(_to_float(self.eval_node(args[1], row)) or 0)) if len(args) >= 2 else 0
            return v[:n]
        if fn == "right":
            v = "" if not args or self.eval_node(args[0], row) is None else str(self.eval_node(args[0], row))
            n = max(0, int(_to_float(self.eval_node(args[1], row)) or 0)) if len(args) >= 2 else 0
            return v[-n:] if n > 0 else ""
        if fn == "substr":
            v = "" if not args or self.eval_node(args[0], row) is None else str(self.eval_node(args[0], row))
            st = max(1, int(_to_float(self.eval_node(args[1], row)) or 1)) if len(args) >= 2 else 1
            ln = max(0, int(_to_float(self.eval_node(args[2], row)) or len(v))) if len(args) >= 3 else len(v)
            return v[st - 1 : st - 1 + ln]
        if fn == "replace":
            v = "" if not args or self.eval_node(args[0], row) is None else str(self.eval_node(args[0], row))
            old = "" if len(args) < 2 or self.eval_node(args[1], row) is None else str(self.eval_node(args[1], row))
            new = "" if len(args) < 3 or self.eval_node(args[2], row) is None else str(self.eval_node(args[2], row))
            return v.replace(old, new)
        raise ExpressionSyntaxError(f"Unknown function '{fn}()'")


def evaluate_dashboard_expression(
    expr: str,
    records: Optional[List[Dict[str, Any]]] = None,
    *,
    all_records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    layer_name: str = "",
    total_count: Optional[int] = None,
    filter_count: int = 0,
    filter_fn: Optional[Any] = None,
    widget_resolver: Optional[Any] = None,
    fallback_agg: str = "sum",
    decimals: int = 1,
    prefix: str = "",
    suffix: str = "",
) -> Dict[str, Any]:
    """
    Safely parse and evaluate an expression for an Expression Widget.
    Returns dict with keys: ok, value, formatted, is_numeric, error.
    """
    raw_expr = str(expr or "").strip()
    if not raw_expr:
        return {"ok": True, "value": 0.0, "formatted": f"{prefix}0{suffix}", "is_numeric": True, "error": ""}
    try:
        ast = parse_expression(raw_expr)
        ev = ExpressionEvaluator(
            records=records,
            all_records_by_layer=all_records_by_layer,
            layer_name=layer_name,
            total_count=total_count,
            filter_count=filter_count,
            filter_fn=filter_fn,
            widget_resolver=widget_resolver,
        )
        if _ast_has_row_field(ast) and not _ast_has_agg(ast):
            row_vals = [ev.eval_node(ast, r) for r in ev.records]
            num_vals = [_to_float(v) for v in row_vals]
            if any(v is not None for v in num_vals) or fallback_agg == "count":
                from .aggregator import Aggregator

                val: Any = Aggregator.compute_metric(row_vals, fallback_agg or "sum")
            else:
                non_empty = [str(v) for v in row_vals if v is not None and str(v) != ""]
                val = ", ".join(dict.fromkeys(non_empty[:5]))
        else:
            val = ev.eval_node(ast, ev.records[0] if ev.records else {})

        if val is None:
            return {"ok": True, "value": None, "formatted": f"{prefix}—{suffix}", "is_numeric": False, "error": ""}
        if isinstance(val, bool):
            txt = "TRUE" if val else "FALSE"
            return {"ok": True, "value": val, "formatted": f"{prefix}{txt}{suffix}", "is_numeric": False, "error": ""}
        if isinstance(val, (int, float)):
            fval = float(val)
            dec = max(0, min(6, int(decimals)))
            if float(fval).is_integer() and dec == 0:
                num_str = f"{int(round(fval)):,}".replace(",", " ")
            else:
                num_str = _format_num_spaced(fval, dec)
            return {
                "ok": True,
                "value": fval,
                "formatted": f"{prefix}{num_str}{suffix}",
                "is_numeric": True,
                "error": "",
            }
        return {"ok": True, "value": str(val), "formatted": f"{prefix}{val}{suffix}", "is_numeric": False, "error": ""}
    except Exception as exc:
        return {"ok": False, "value": None, "formatted": "!", "is_numeric": False, "error": str(exc)}


def _quote_sq(val: str) -> str:
    return "'" + str(val).replace("'", "''") + "'"


def _metric_block_to_expr(blk: Dict[str, Any], primary_layer: str = "") -> str:
    agg = str(blk.get("agg") or "sum").lower().strip()
    if agg == "avg":
        agg = "mean"
    layer = str(blk.get("layer") or primary_layer or "").strip()
    field = str(blk.get("field") or "$area").strip()
    wf = str(blk.get("where_field") or "").strip()
    wop = str(blk.get("where_op") or "=").strip() or "="
    wval = blk.get("where_val")
    cond_part = ""
    if wf and wval is not None and str(wval).strip() != "":
        wval_num = _to_float(wval) if wop in ("=", "!=", "<", "<=", ">", ">=") else None
        rhs = (
            str(int(wval_num))
            if (wval_num is not None and float(wval_num).is_integer() and not str(wval).strip().startswith("0"))
            else (str(wval_num) if wval_num is not None else _quote_sq(str(wval)))
        )
        cond_part = f'"{wf}" {wop} {rhs}'

    agg_map = {
        "sum": "layer_sum",
        "mean": "layer_mean",
        "count": "layer_count",
        "count_distinct": "layer_count_distinct",
        "minimum": "layer_min",
        "min": "layer_min",
        "maximum": "layer_max",
        "max": "layer_max",
        "median": "layer_median",
    }
    fn = agg_map.get(agg, "layer_sum")
    if layer:
        if fn == "layer_count":
            return f"layer_count({_quote_sq(layer)}, {cond_part})" if cond_part else f"layer_count({_quote_sq(layer)})"
        if cond_part:
            return f"{fn}({_quote_sq(layer)}, {_quote_sq(field)}, {cond_part})"
        return f"{fn}({_quote_sq(layer)}, {_quote_sq(field)})"

    local_map = {
        "layer_sum": "sum",
        "layer_mean": "mean",
        "layer_count": "count",
        "layer_count_distinct": "count_distinct",
        "layer_min": "minimum",
        "layer_max": "maximum",
        "layer_median": "median",
    }
    lfn = local_map[fn]
    f_expr = "$area" if field in ("$area", "$area_ha", "__calc_area_ha__") else f'"{field}"'
    if lfn == "count":
        if cond_part:
            return f"count({f_expr}, {cond_part})"
        return "count()" if field in ("__calc_count__", "") else f"count({f_expr})"
    return f"{lfn}({f_expr}, {cond_part})" if cond_part else f"{lfn}({f_expr})"


def blocks_to_expression(blocks: Any, primary_layer: str = "") -> str:
    """Serialize visual Lego block list (with optional container slots) into QGIS expression string."""
    if not isinstance(blocks, list) or not blocks:
        return ""
    parts: List[str] = []
    for blk in blocks:
        if not isinstance(blk, dict):
            continue
        kind = str(blk.get("kind") or "").strip()
        if kind == "metric":
            parts.append(_metric_block_to_expr(blk, primary_layer=primary_layer))
        elif kind == "widget_ref":
            wref = str(blk.get("widget_id") or blk.get("widget_title") or "").strip()
            wmode = str(blk.get("mode") or "value").strip().lower()
            fn = "widget_count" if wmode == "count" else "widget"
            parts.append(f"{fn}({_quote_sq(wref)})")
        elif kind == "var":
            parts.append(str(blk.get("name") or "$count").strip())
        elif kind == "op":
            op_txt = str(blk.get("op") or "+").strip()
            parts.append(op_txt)
        elif kind == "num":
            v = blk.get("value", 0)
            nv = _to_float(v)
            if nv is not None:
                parts.append(str(int(nv)) if float(nv).is_integer() else str(nv))
            else:
                parts.append("0")
        elif kind == "str":
            parts.append(_quote_sq(str(blk.get("value") or "")))
        elif kind == "raw":
            raw_s = str(blk.get("expr") or "").strip()
            if raw_s:
                parts.append(raw_s)
        elif kind == "group":
            inner = blocks_to_expression(blk.get("items") or [], primary_layer=primary_layer)
            parts.append(f"({inner})" if inner else "(0)")
        elif kind == "pct_share":
            part_s = blocks_to_expression(blk.get("part") or [], primary_layer=primary_layer) or "0"
            whole_s = blocks_to_expression(blk.get("whole") or [], primary_layer=primary_layer) or "1"
            parts.append(f"percent({part_s}, {whole_s})")
        elif kind == "if_else":
            c_s = blocks_to_expression(blk.get("cond") or [], primary_layer=primary_layer) or "TRUE"
            t_s = blocks_to_expression(blk.get("then") or [], primary_layer=primary_layer) or "0"
            e_s = blocks_to_expression(blk.get("else") or [], primary_layer=primary_layer) or "0"
            parts.append(f"if({c_s}, {t_s}, {e_s})")
        elif kind == "format":
            fmt_fn = str(blk.get("fmt") or "format_ha").strip()
            if fmt_fn not in ("format_ha", "format_pct", "format_number"):
                fmt_fn = "format_ha"
            dec = max(0, min(6, int(blk.get("decimals", 1) if blk.get("decimals") is not None else 1)))
            inner_s = blocks_to_expression(blk.get("inner") or [], primary_layer=primary_layer) or "0"
            parts.append(f"{fmt_fn}({inner_s}, {dec})")
    return " ".join(p for p in parts if p).strip()


def _extract_simple_where(cond_node: Any) -> Tuple[Optional[Tuple[str, str, str]], bool]:
    if not isinstance(cond_node, tuple) or len(cond_node) != 4 or cond_node[0] != "CMP":
        return None, False
    op = str(cond_node[1])
    if op == "==":
        op = "="
    elif op == "<>":
        op = "!="
    lhs, rhs = cond_node[2], cond_node[3]
    if not isinstance(lhs, tuple) or lhs[0] not in ("FIELD", "VAR"):
        return None, False
    if not isinstance(rhs, tuple) or rhs[0] != "LIT" or rhs[1] is None:
        return None, False
    val = rhs[1]
    if isinstance(val, (int, float)) and float(val).is_integer():
        v_str = str(int(val))
    else:
        v_str = str(val)
    return (str(lhs[1]), op, v_str), True


def expression_to_blocks(expr: str, default_layer: str = "") -> Tuple[List[Dict[str, Any]], bool]:
    """
    Reconstruct visual Lego blocks from a QGIS expression string.
    Returns (blocks, is_lossless). Unrecognized sub-trees degrade gracefully to {'kind':'raw'}.
    """
    raw = str(expr or "").strip()
    if not raw:
        return [], True
    try:
        ast = parse_expression(raw)
    except Exception:
        return [{"kind": "raw", "expr": raw}], False

    lossless = True

    def _prec(node: Any) -> int:
        if not isinstance(node, tuple) or not node:
            return 99
        op = node[0]
        if op == "OR":
            return 1
        if op == "AND":
            return 2
        if op in ("CMP", "IN", "LIKE", "ILIKE", "IS_NULL"):
            return 3
        if op == "BIN":
            bop = node[1]
            if bop in ("+", "-", "||"):
                return 4
            if bop in ("*", "/", "%"):
                return 5
            if bop == "^":
                return 6
        return 9

    def _convert(node: Any, parent_prec: int = 0) -> List[Dict[str, Any]]:
        nonlocal lossless
        if not isinstance(node, tuple) or not node:
            return []
        op = node[0]
        if op == "LIT":
            v = node[1]
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                val = int(v) if float(v).is_integer() else float(v)
                return [{"kind": "num", "value": val}]
            if isinstance(v, str):
                return [{"kind": "str", "value": v}]
            lossless = False
            return [{"kind": "raw", "expr": "TRUE" if v is True else ("FALSE" if v is False else "NULL")}]

        if op == "VAR":
            nm = str(node[1])
            if nm.lower() in ("$area", "$area_ha", "$area_m2", "$count", "@row_count", "@feature_count", "@total_count", "@filter_count", "@layer", "@layer_name"):
                return [{"kind": "var", "name": nm}]
            lossless = False
            return [{"kind": "raw", "expr": nm}]

        if op == "FIELD":
            fn = str(node[1])
            if fn in ("$area", "$area_ha"):
                return [{"kind": "var", "name": "$area"}]
            lossless = False
            return [{"kind": "raw", "expr": f'"{fn}"'}]

        if op == "NEG":
            inner = node[1]
            if isinstance(inner, tuple) and inner[0] == "LIT" and isinstance(inner[1], (int, float)):
                v = -inner[1]
                return [{"kind": "num", "value": int(v) if float(v).is_integer() else float(v)}]
            lossless = False
            return [{"kind": "raw", "expr": raw}]

        if op in ("OR", "AND", "CMP", "BIN"):
            my_prec = _prec(node)
            if op == "BIN":
                op_sym, left_n, right_n = node[1], node[2], node[3]
            elif op == "CMP":
                op_sym, left_n, right_n = node[1], node[2], node[3]
                if op_sym == "==":
                    op_sym = "="
                elif op_sym == "<>":
                    op_sym = "!="
            else:
                op_sym, left_n, right_n = op, node[1], node[2]

            if op_sym == "^":
                lossless = False
                return [{"kind": "raw", "expr": raw}]

            seq = _convert(left_n, my_prec) + [{"kind": "op", "op": op_sym}] + _convert(right_n, my_prec + (1 if op_sym in ("-", "/") else 0))
            if my_prec < parent_prec:
                return [{"kind": "group", "items": seq}]
            return seq

        if op == "CALL":
            fn = str(node[1]).lower()
            args = node[2]
            if fn in WIDGET_REF_FUNCTIONS and args and isinstance(args[0], tuple) and args[0][0] in ("LIT", "VAR"):
                wid = str(args[0][1])
                return [{"kind": "widget_ref", "widget_id": wid, "widget_title": wid, "mode": "count" if fn == "widget_count" else "value"}]

            if fn in CROSS_LAYER_FUNCTIONS and args and isinstance(args[0], tuple) and args[0][0] == "LIT":
                lname = str(args[0][1])
                agg = fn.replace("layer_", "")
                if agg == "min":
                    agg = "minimum"
                elif agg == "max":
                    agg = "maximum"
                elif agg == "avg":
                    agg = "mean"
                field = ""
                cond_idx = 1 if agg == "count" else 2
                if agg != "count":
                    if len(args) >= 2 and isinstance(args[1], tuple) and args[1][0] == "LIT":
                        field = str(args[1][1])
                    else:
                        lossless = False
                        return [{"kind": "raw", "expr": raw}]
                else:
                    field = "__calc_count__"
                wf, wop, wval = "", "=", ""
                if len(args) > cond_idx:
                    w_info, ok_w = _extract_simple_where(args[cond_idx])
                    if ok_w and w_info:
                        wf, wop, wval = w_info
                    else:
                        lossless = False
                        return [{"kind": "raw", "expr": raw}]
                return [{"kind": "metric", "layer": lname, "field": field or "$area", "agg": agg, "where_field": wf, "where_op": wop, "where_val": wval}]

            if fn in ("sum", "mean", "avg", "count", "count_distinct", "minimum", "maximum", "median"):
                agg = "mean" if fn == "avg" else fn
                field = "__calc_count__" if fn == "count" and not args else ""
                if args:
                    a0 = args[0]
                    if isinstance(a0, tuple) and a0[0] == "FIELD":
                        field = str(a0[1])
                    elif isinstance(a0, tuple) and a0[0] == "VAR" and a0[1].lower() in ("$area", "$area_ha"):
                        field = "$area"
                    else:
                        lossless = False
                        return [{"kind": "raw", "expr": raw}]
                wf, wop, wval = "", "=", ""
                if len(args) >= 2:
                    w_info, ok_w = _extract_simple_where(args[1])
                    if ok_w and w_info:
                        wf, wop, wval = w_info
                    else:
                        lossless = False
                        return [{"kind": "raw", "expr": raw}]
                return [{"kind": "metric", "layer": default_layer, "field": field or "$area", "agg": agg, "where_field": wf, "where_op": wop, "where_val": wval}]

            if fn == "if" and len(args) >= 2:
                cond_b = _convert(args[0], 0)
                then_b = _convert(args[1], 0)
                else_b = _convert(args[2], 0) if len(args) >= 3 else [{"kind": "num", "value": 0}]
                return [{"kind": "if_else", "cond": cond_b, "then": then_b, "else": else_b}]

            if fn == "percent" and len(args) == 2:
                return [{"kind": "pct_share", "part": _convert(args[0], 0), "whole": _convert(args[1], 0)}]

            if fn in ("format_ha", "format_pct", "format_number") and len(args) >= 1:
                dec = 1
                if len(args) >= 2 and isinstance(args[1], tuple) and args[1][0] == "LIT" and isinstance(args[1][1], (int, float)):
                    dec = max(0, min(6, int(args[1][1])))
                return [{"kind": "format", "fmt": fn, "decimals": dec, "inner": _convert(args[0], 0)}]

        lossless = False
        return [{"kind": "raw", "expr": raw}]

    blocks = _convert(ast, 0)
    return blocks, lossless


def compute_dashboard_widget_ref(
    ref_key: str,
    dashboard: Any,
    records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    filter_bus: Any = None,
    mode: str = "value",
    visited: Optional[Set[str]] = None,
) -> float:
    """Resolve the current filtered scalar metric or row count of another dashboard widget cleanly."""
    from .aggregator import Aggregator, COUNT_FIELD_ALIASES, _resolve_record_value

    if dashboard is None or not ref_key:
        return 0.0
    key_norm = str(ref_key).strip()
    target = None
    for w in getattr(dashboard, "widgets", []) or []:
        if w.id == key_norm or w.title == key_norm or getattr(w, "title_en", "") == key_norm:
            target = w
            break
    if target is None:
        return 0.0
    seen = set(visited or ())
    if target.id in seen:
        return 0.0
    seen.add(target.id)

    all_recs = records_by_layer or {}
    raw_recs = list(all_recs.get(getattr(target, "layer_name", ""), []) or [])
    exclude_id = target.id if getattr(target, "ignore_self_filter", True) else None
    filtered = (
        filter_bus.filter_records(
            raw_recs,
            layer_name=getattr(target, "layer_name", ""),
            exclude_source_id=exclude_id,
            target_widget_id=target.id,
        )
        if filter_bus is not None
        else raw_recs
    )
    if mode == "count":
        return float(len(filtered))

    wtype = str(getattr(target, "widget_type", "kpi") or "kpi").lower()
    if wtype == "expression":
        def _sub_filter(ln: str, rws: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            if filter_bus is None:
                return list(rws or [])
            return filter_bus.filter_records(rws, layer_name=ln, exclude_source_id=exclude_id, target_widget_id=target.id)

        def _sub_wres(rk: str, md: str = "value") -> float:
            return compute_dashboard_widget_ref(rk, dashboard, all_recs, filter_bus, mode=md, visited=seen)

        res = evaluate_dashboard_expression(
            str(getattr(target, "expression", "") or "count()"),
            filtered,
            all_records_by_layer=all_recs,
            layer_name=str(getattr(target, "layer_name", "") or ""),
            total_count=len(raw_recs),
            filter_count=len(filter_bus.active_filters()) if filter_bus is not None else 0,
            filter_fn=_sub_filter,
            widget_resolver=_sub_wres,
            fallback_agg=str(getattr(target, "aggregation", "sum") or "sum"),
        )
        nv = _to_float(res.get("value"))
        return float(nv or 0.0)

    agg = str(getattr(target, "aggregation", "sum") or "sum").lower()
    val_field = str(getattr(target, "value_field", "") or "")
    if (agg == "count" and not val_field) or val_field in COUNT_FIELD_ALIASES:
        vals = [1 for _ in filtered]
    elif val_field:
        vals = [_resolve_record_value(r, val_field) for r in filtered]
    else:
        return float(len(filtered))
    return float(Aggregator.compute_metric(vals, agg))


def resolve_expression_accent_color(config: Any, eval_res: Dict[str, Any]) -> str:
    """Resolve card accent color from fixed accent, target_pct, or numeric threshold rules."""
    base = str(getattr(config, "primary_color", "") or "#34d399")
    mode = str(getattr(config, "expression_color_mode", "fixed") or "fixed").strip().lower()
    if mode == "fixed" or not eval_res.get("ok") or not eval_res.get("is_numeric"):
        return base if eval_res.get("ok") else "#f43f5e"

    num = _to_float(eval_res.get("value"))
    if num is None:
        return base

    if mode == "target_pct":
        tgt = _to_float(getattr(config, "target_value", None))
        if tgt is None or tgt <= 0:
            return base
        pct = (num / tgt) * 100.0
        ok_thr = _to_float(getattr(config, "expression_threshold_ok", None))
        warn_thr = _to_float(getattr(config, "expression_threshold_warn", None))
        ok_v = 100.0 if ok_thr is None else ok_thr
        warn_v = 50.0 if warn_thr is None else warn_thr
        if pct >= ok_v:
            return "#10b981"
        if pct >= warn_v:
            return "#f59e0b"
        return "#f43f5e"

    if mode == "rules":
        ok_thr = _to_float(getattr(config, "expression_threshold_ok", None))
        warn_thr = _to_float(getattr(config, "expression_threshold_warn", None))
        for rule in getattr(config, "expression_rules", []) or []:
            if not isinstance(rule, dict):
                continue
            rop = str(rule.get("op") or ">=").strip()
            rv = _to_float(rule.get("val"))
            col = str(rule.get("color") or "").strip()
            if rv is None or not col:
                continue
            hit = (
                (rop == ">=" and num >= rv)
                or (rop == ">" and num > rv)
                or (rop == "<=" and num <= rv)
                or (rop == "<" and num < rv)
                or (rop in ("=", "==") and num == rv)
            )
            if hit:
                return col
        if ok_thr is not None and num >= ok_thr:
            return "#10b981"
        if warn_thr is not None:
            return "#f59e0b" if num >= warn_thr else "#f43f5e"
        if ok_thr is not None:
            return "#f43f5e"
    return base
