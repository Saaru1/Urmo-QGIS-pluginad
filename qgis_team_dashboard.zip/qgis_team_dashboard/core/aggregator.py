# -*- coding: utf-8 -*-
"""
High-Speed BI Aggregation Engine for QGIS Team Dashboard.
Computes KPI metrics, grouped category series, scatter pairs, and filtered table rows
from QGIS Vector Layers, WFS feeds, and joined read-only Excel tables.
Uses pandas when installed and automatically falls back to pure Python.
"""

from collections import defaultdict
import math
import statistics
from typing import Any, Dict, List, Optional, Tuple

from .filter_bus import FilterBus
from .i18n import tr
from .schema import WidgetConfig

CALC_AREA_FIELD = "__calc_area_ha__"
CALC_COUNT_FIELD = "__calc_count__"
AREA_FIELD_ALIASES = {CALC_AREA_FIELD, "Calculate area (ha)", "Arvuta pindala (ha)"}
COUNT_FIELD_ALIASES = {CALC_COUNT_FIELD, "Calculate count", "Kirjete arv"}


def friendly_field_label(
    field_name: str, lang: str = "et", aliases: Optional[Dict[str, str]] = None
) -> str:
    """Human-readable display name for virtual calculated fields or regular attributes."""
    if aliases and field_name:
        custom = str(aliases.get(field_name) or "").strip()
        if custom:
            return custom
    if field_name in AREA_FIELD_ALIASES:
        return "Pindala (ha)" if lang == "et" else "Area (ha)"
    if field_name in COUNT_FIELD_ALIASES:
        return "Arv" if lang == "et" else "Count"
    return field_name


def _dedupe_display_headers(raw_headers: List[str]) -> List[str]:
    """Ensure distinct column header keys so custom duplicate aliases cannot overwrite dict cells."""
    used: Dict[str, int] = {}
    out: List[str] = []
    for raw in raw_headers:
        base = str(raw or "")
        n = used.get(base, 0) + 1
        used[base] = n
        out.append(base if n == 1 else f"{base} ({n})")
    return out


def _resolve_record_value(record: Dict[str, Any], field_name: str) -> Any:
    """Resolve an attribute value or compute a virtual geometric/count metric on the fly."""
    if not field_name:
        return None
    if field_name in COUNT_FIELD_ALIASES:
        return 1
    if field_name in AREA_FIELD_ALIASES:
        if "_geom_area_ha" in record and record["_geom_area_ha"] is not None:
            return record["_geom_area_ha"]
        if "area_ha" in record and record["area_ha"] is not None:
            return record["area_ha"]
        if "_geometry" in record and isinstance(record["_geometry"], dict):
            from .spatial_overlap import geom_area_ha

            return round(geom_area_ha(record["_geometry"]), 4)
        return record.get("pindala_ha", 0.0)
    return record.get(field_name)


def _to_float(val: Any) -> Optional[float]:
    if val is None or val == "":
        return None
    if isinstance(val, bool):
        return 1.0 if val else 0.0
    if isinstance(val, (int, float)):
        if math.isnan(val) or math.isinf(val):
            return None
        return float(val)
    try:
        cleaned = str(val).replace(",", "").strip()
        num = float(cleaned)
        return None if (math.isnan(num) or math.isinf(num)) else num
    except (ValueError, TypeError):
        return None


class Aggregator:
    """Computes aggregated values and chart series over filtered feature/row dictionaries."""

    @staticmethod
    def compute_metric(values: List[Any], agg_func: str) -> float:
        """Compute a single scalar aggregation ('count', 'distinct_count', 'sum', 'avg', 'min', 'max', 'median')."""
        agg = (agg_func or "count").lower().strip()
        if agg == "count":
            return float(len(values))
        if agg == "distinct_count":
            non_empty = {str(v) for v in values if v is not None and str(v) != ""}
            return float(len(non_empty))

        nums = [n for n in (_to_float(v) for v in values) if n is not None]
        if not nums:
            return 0.0

        if agg == "sum":
            return float(sum(nums))
        if agg in ("avg", "mean"):
            return float(sum(nums) / len(nums))
        if agg == "min":
            return float(min(nums))
        if agg == "max":
            return float(max(nums))
        if agg == "median":
            return float(statistics.median(nums))
        return float(len(nums))

    @classmethod
    def compute_kpi(
        cls,
        records: List[Dict[str, Any]],
        widget: WidgetConfig,
        filter_bus: Optional[FilterBus] = None,
    ) -> Dict[str, Any]:
        """
        Compute KPI value, formatted text, and optional target comparison delta.
        """
        exclude_id = widget.id if widget.ignore_self_filter else None
        rows = (
            filter_bus.filter_records(
                records,
                layer_name=widget.layer_name,
                exclude_source_id=exclude_id,
                target_widget_id=widget.id,
            )
            if filter_bus
            else records
        )

        if (widget.aggregation == "count" and not widget.value_field) or widget.value_field in COUNT_FIELD_ALIASES:
            raw_vals = [1 for _ in rows]
        else:
            raw_vals = [_resolve_record_value(r, widget.value_field) for r in rows]

        metric_val = cls.compute_metric(raw_vals, widget.aggregation)
        decimals = max(0, int(widget.decimals))
        if widget.aggregation in ("count", "distinct_count") or decimals == 0:
            formatted_num = f"{int(round(metric_val)):,}"
        else:
            formatted_num = f"{metric_val:,.{decimals}f}"

        formatted = f"{widget.prefix}{formatted_num}{widget.suffix}"

        delta_pct: Optional[float] = None
        if widget.target_value is not None and widget.target_value != 0:
            delta_pct = ((metric_val - widget.target_value) / abs(widget.target_value)) * 100.0

        return {
            "value": metric_val,
            "formatted": formatted,
            "row_count": len(rows),
            "total_count": len(records),
            "target_value": widget.target_value,
            "delta_pct": delta_pct,
        }

    @classmethod
    def compute_series(
        cls,
        records: List[Dict[str, Any]],
        widget: WidgetConfig,
        filter_bus: Optional[FilterBus] = None,
    ) -> List[Tuple[str, float]]:
        """
        Compute grouped (category, aggregated_value) pairs for bar, line, and pie charts.
        """
        exclude_id = widget.id if widget.ignore_self_filter else None
        rows = (
            filter_bus.filter_records(
                records,
                layer_name=widget.layer_name,
                exclude_source_id=exclude_id,
                target_widget_id=widget.id,
            )
            if filter_bus
            else records
        )

        groups: Dict[str, List[Any]] = defaultdict(list)
        cat_field = widget.category_field
        val_field = widget.value_field

        for r in rows:
            raw_cat = _resolve_record_value(r, cat_field)
            cat_label = str(raw_cat) if (raw_cat is not None and str(raw_cat).strip() != "") else "(Unassigned)"
            if (widget.aggregation == "count" and not val_field) or val_field in COUNT_FIELD_ALIASES:
                groups[cat_label].append(1)
            else:
                groups[cat_label].append(_resolve_record_value(r, val_field))

        series: List[Tuple[str, float]] = [
            (cat, cls.compute_metric(vals, widget.aggregation))
            for cat, vals in groups.items()
        ]

        if widget.sort_by == "value_desc":
            series.sort(key=lambda item: item[1], reverse=True)
        elif widget.sort_by == "value_asc":
            series.sort(key=lambda item: item[1])
        else:
            series.sort(key=lambda item: item[0])

        top_n = max(1, int(widget.top_n or 15))
        if len(series) > top_n:
            head = series[: top_n - 1]
            tail_val = sum(item[1] for item in series[top_n - 1 :])
            head.append(("Other", tail_val))
            series = head

        return series

    @classmethod
    def compute_scatter(
        cls,
        records: List[Dict[str, Any]],
        widget: WidgetConfig,
        filter_bus: Optional[FilterBus] = None,
    ) -> List[Dict[str, Any]]:
        """
        Compute (x, y, label, id) points for scatter plots.
        Uses widget.category_field as X, widget.value_field as Y, and widget.secondary_field as label.
        """
        exclude_id = widget.id if widget.ignore_self_filter else None
        rows = (
            filter_bus.filter_records(
                records,
                layer_name=widget.layer_name,
                exclude_source_id=exclude_id,
                target_widget_id=widget.id,
            )
            if filter_bus
            else records
        )

        points: List[Dict[str, Any]] = []
        for idx, r in enumerate(rows):
            xv = _to_float(_resolve_record_value(r, widget.category_field))
            yv = _to_float(_resolve_record_value(r, widget.value_field))
            if xv is None or yv is None:
                continue
            label_field = widget.secondary_field or widget.category_field
            points.append(
                {
                    "x": xv,
                    "y": yv,
                    "label": str(_resolve_record_value(r, label_field) or f"Row {idx + 1}"),
                    "feature_id": r.get("_feature_id", idx),
                }
            )
        return points

    @classmethod
    def _transpose_table(
        cls, headers: List[str], rows: List[Dict[str, Any]], lang: str = "et"
    ) -> Tuple[List[str], List[Dict[str, Any]]]:
        """Swap table rows and columns (Excel-style Transpose)."""
        if not headers:
            return headers, rows
        corner_lbl = headers[0] if rows else ("Väli" if lang == "et" else "Field")
        col_headers: List[str] = [corner_lbl]
        key_cols: List[str] = []
        used = {corner_lbl}
        for idx, row in enumerate(rows[:30]):
            raw_k = str(row.get(headers[0], f"#{idx + 1}") or f"#{idx + 1}")
            cand = raw_k
            suffix = 2
            while cand in used:
                cand = f"{raw_k} ({suffix})"
                suffix += 1
            used.add(cand)
            col_headers.append(cand)
            key_cols.append(cand)

        out_rows: List[Dict[str, Any]] = []
        for h in headers[1:]:
            t_row: Dict[str, Any] = {corner_lbl: h}
            for col_name, src_row in zip(key_cols, rows[:30]):
                t_row[col_name] = src_row.get(h, "")
            out_rows.append(t_row)
        return col_headers, out_rows

    @classmethod
    def compute_table(
        cls,
        records: List[Dict[str, Any]],
        widget: WidgetConfig,
        filter_bus: Optional[FilterBus] = None,
        lang: str = "et",
    ) -> Tuple[List[str], List[Dict[str, Any]]]:
        """
        Compute either a Detail table (with virtual fields like Calculate Area ha) or an
        Excel-style grouped/cross-tab Pivot Table, with optional Totals and Transpose.
        Returns (column_headers, row_dicts).
        """
        exclude_id = widget.id if getattr(widget, "ignore_self_filter", True) else None
        rows = (
            filter_bus.filter_records(
                records,
                layer_name=widget.layer_name,
                exclude_source_id=exclude_id,
                target_widget_id=widget.id,
            )
            if filter_bus
            else list(records)
        )

        is_pivot = (
            getattr(widget, "table_mode", "detail") == "pivot"
            or bool(getattr(widget, "pivot_rows", None))
            or bool(getattr(widget, "pivot_values", None))
        )

        dec = max(0, int(widget.decimals if widget.decimals is not None else 1))
        aliases = dict(getattr(widget, "field_aliases", None) or {})

        if not is_pivot:
            cols = (
                list(widget.table_columns)
                if widget.table_columns
                else [k for k in (rows[0].keys() if rows else []) if not str(k).startswith("_")][:8]
            )
            headers = _dedupe_display_headers([friendly_field_label(c, lang, aliases=aliases) for c in cols])
            out_rows: List[Dict[str, Any]] = []
            for r in rows:
                item: Dict[str, Any] = {}
                for hidden_k in ("_feature_id", "_lat", "_lon", "_bbox"):
                    if hidden_k in r:
                        item[hidden_k] = r[hidden_k]
                for c, hdr in zip(cols, headers):
                    val = _resolve_record_value(r, c)
                    if c in AREA_FIELD_ALIASES and isinstance(val, (int, float)):
                        item[hdr] = round(float(val), dec)
                    else:
                        item[hdr] = "" if val is None else val
                out_rows.append(item)

            if getattr(widget, "table_transpose", False):
                return cls._transpose_table(headers, out_rows, lang=lang)
            return headers, out_rows

        # ---- Excel-style Pivot Table computation ----
        row_fields = list(getattr(widget, "pivot_rows", None) or [])
        col_fields = list(getattr(widget, "pivot_cols", None) or [])
        val_specs = list(getattr(widget, "pivot_values", None) or [])
        if not val_specs:
            val_specs = [{"field": CALC_COUNT_FIELD, "agg": "count", "label": tr("tbl_calc_count", lang)}]

        def _row_tuple(rec: Dict[str, Any], flds: List[str]) -> Tuple[str, ...]:
            if not flds:
                return (tr("tbl_pivot_total", lang),)
            parts = []
            for fn in flds:
                rv = _resolve_record_value(rec, fn)
                parts.append(str(rv).strip() if (rv is not None and str(rv).strip() != "") else "(Tühi)" if lang == "et" else "(Empty)")
            return tuple(parts)

        buckets: Dict[Tuple[str, ...], Dict[Tuple[str, ...], List[Dict[str, Any]]]] = defaultdict(lambda: defaultdict(list))
        col_keys_seen: List[Tuple[str, ...]] = []
        col_key_set = set()

        for rec in rows:
            rk = _row_tuple(rec, row_fields)
            ck = _row_tuple(rec, col_fields) if col_fields else ("__ALL__",)
            buckets[rk][ck].append(rec)
            if col_fields and ck not in col_key_set:
                col_key_set.add(ck)
                col_keys_seen.append(ck)

        if col_fields:
            col_keys_seen.sort()

        display_row_headers = (
            _dedupe_display_headers([friendly_field_label(f, lang, aliases=aliases) for f in row_fields])
            if row_fields
            else ["Rühm" if lang == "et" else "Group"]
        )

        agg_short = {
            "sum": "Sum",
            "count": "Count",
            "distinct_count": "Distinct",
            "avg": "Mean",
            "min": "Min",
            "max": "Max",
            "median": "Median",
        }

        def _val_title(spec: Dict[str, str]) -> str:
            lbl = str(spec.get("label") or "").strip()
            if lbl:
                return lbl
            raw_fld = str(spec.get("field") or "")
            raw_agg = str(spec.get("agg") or "sum")
            metric_alias = str(aliases.get(f"{raw_agg}:{raw_fld}") or "").strip()
            if metric_alias:
                return metric_alias
            f_lbl = friendly_field_label(raw_fld, lang, aliases=aliases)
            a_lbl = agg_short.get(raw_agg, raw_agg)
            default_hdr = f"{f_lbl} ({a_lbl})"
            return str(aliases.get(default_hdr) or "").strip() or default_hdr

        metric_columns: List[Tuple[Optional[Tuple[str, ...]], Dict[str, str], str]] = []
        if not col_fields:
            for sp in val_specs:
                metric_columns.append((None, sp, _val_title(sp)))
        else:
            for ck in col_keys_seen:
                ck_label = " / ".join(ck)
                for sp in val_specs:
                    hdr = ck_label if len(val_specs) == 1 else f"{ck_label} | {_val_title(sp)}"
                    metric_columns.append((ck, sp, hdr))
            if getattr(widget, "table_show_totals", True):
                for sp in val_specs:
                    tot_word = tr("tbl_pivot_total", lang)
                    hdr = tot_word if len(val_specs) == 1 else f"{tot_word} | {_val_title(sp)}"
                    metric_columns.append(("__TOTAL__", sp, hdr))

        headers = _dedupe_display_headers(display_row_headers + [mc[2] for mc in metric_columns])
        if metric_columns:
            deduped_metrics = headers[len(display_row_headers):]
            metric_columns = [(ck, sp, dh) for (ck, sp, _), dh in zip(metric_columns, deduped_metrics)]

        def _eval_spec(sub_recs: List[Dict[str, Any]], sp: Dict[str, str]) -> float:
            fld = sp.get("field", "")
            agg = sp.get("agg", "sum")
            if agg == "count" and (not fld or fld in COUNT_FIELD_ALIASES):
                raw_vals = [1 for _ in sub_recs]
            else:
                raw_vals = [_resolve_record_value(r, fld) for r in sub_recs]
            num = cls.compute_metric(raw_vals, agg)
            return round(num, 0 if agg in ("count", "distinct_count") else dec)

        pivot_rows_out: List[Dict[str, Any]] = []
        for rk, col_map in buckets.items():
            row_dict: Dict[str, Any] = {}
            if len(row_fields) == 1:
                row_dict["_filter_field"] = row_fields[0]
                row_dict["_filter_value"] = rk[0]
            for h, val in zip(display_row_headers, rk):
                row_dict[h] = val

            all_row_recs = [r for sub in col_map.values() for r in sub]
            for ck, sp, hdr in metric_columns:
                if ck is None or ck == "__TOTAL__":
                    sub = all_row_recs
                else:
                    sub = col_map.get(ck, [])
                val = _eval_spec(sub, sp)
                agg = sp.get("agg", "sum")
                row_dict[hdr] = int(val) if agg in ("count", "distinct_count") else val
            pivot_rows_out.append(row_dict)

        # Sort pivot rows by first metric descending (or label ascending if empty)
        if metric_columns:
            sort_hdr = metric_columns[0][2]
            pivot_rows_out.sort(key=lambda d: float(d.get(sort_hdr) or 0.0), reverse=True)

        # Grand Total row
        if getattr(widget, "table_show_totals", True) and len(pivot_rows_out) > 1:
            tot_dict: Dict[str, Any] = {display_row_headers[0]: tr("tbl_pivot_total", lang)}
            for h in display_row_headers[1:]:
                tot_dict[h] = ""
            for ck, sp, hdr in metric_columns:
                if ck is None or ck == "__TOTAL__":
                    sub = rows
                else:
                    sub = [r for r in rows if _row_tuple(r, col_fields) == ck]
                val = _eval_spec(sub, sp)
                agg = sp.get("agg", "sum")
                tot_dict[hdr] = int(val) if agg in ("count", "distinct_count") else val
            pivot_rows_out.append(tot_dict)

        if getattr(widget, "table_transpose", False):
            return cls._transpose_table(headers, pivot_rows_out, lang=lang)
        return headers, pivot_rows_out

    @staticmethod
    def distinct_categories(records: List[Dict[str, Any]], field_name: str) -> List[str]:
        """Return sorted unique non-empty category strings for a slicer field."""
        seen = {
            str(r.get(field_name)).strip()
            for r in records
            if r.get(field_name) is not None and str(r.get(field_name)).strip() != ""
        }
        return sorted(seen)

    @staticmethod
    def numeric_bounds(records: List[Dict[str, Any]], field_name: str) -> Tuple[float, float]:
        """Return (min, max) numeric bounds for a numeric range slicer."""
        nums = [n for n in (_to_float(r.get(field_name)) for r in records) if n is not None]
        if not nums:
            return (0.0, 100.0)
        return (min(nums), max(nums))

    @staticmethod
    def date_bounds(records: List[Dict[str, Any]], field_name: str) -> Tuple[str, str]:
        """Return (min_date, max_date) ISO YYYY-MM-DD strings for a date range slicer."""
        import re

        pat = re.compile(r"^(\d{4}-\d{2}-\d{2})")
        dates: List[str] = []
        for r in records:
            raw = _resolve_record_value(r, field_name)
            if raw is None:
                continue
            m = pat.match(str(raw).strip())
            if m:
                dates.append(m.group(1))
        if not dates:
            return ("", "")
        return (min(dates), max(dates))

    @classmethod
    def compute_multi_series(
        cls,
        records: List[Dict[str, Any]],
        widget: WidgetConfig,
        filter_bus: Optional[FilterBus] = None,
    ) -> Dict[str, Any]:
        """
        Compute grouped/stacked/100%-stacked series data when widget.secondary_field is set.
        Returns categories, ordered series_names, matrix[cat][series], raw_matrix, totals, and stack_mode.
        """
        exclude_id = widget.id if widget.ignore_self_filter else None
        rows = (
            filter_bus.filter_records(
                records,
                layer_name=widget.layer_name,
                exclude_source_id=exclude_id,
                target_widget_id=widget.id,
            )
            if filter_bus
            else records
        )

        cat_field = widget.category_field
        series_field = getattr(widget, "secondary_field", "") or ""
        val_field = widget.value_field
        stack_mode = str(getattr(widget, "chart_stack_mode", "group") or "group").lower()
        if stack_mode not in ("group", "stack", "percent"):
            stack_mode = "group"

        buckets: Dict[str, Dict[str, List[Any]]] = defaultdict(lambda: defaultdict(list))
        cat_all_vals: Dict[str, List[Any]] = defaultdict(list)
        series_totals: Dict[str, List[Any]] = defaultdict(list)

        for r in rows:
            raw_cat = _resolve_record_value(r, cat_field)
            cat_lbl = str(raw_cat) if (raw_cat is not None and str(raw_cat).strip() != "") else "(Unassigned)"
            raw_ser = _resolve_record_value(r, series_field) if series_field else None
            ser_lbl = str(raw_ser) if (raw_ser is not None and str(raw_ser).strip() != "") else "(Unassigned)"
            if (widget.aggregation == "count" and not val_field) or val_field in COUNT_FIELD_ALIASES:
                val = 1
            else:
                val = _resolve_record_value(r, val_field)
            buckets[cat_lbl][ser_lbl].append(val)
            cat_all_vals[cat_lbl].append(val)
            series_totals[ser_lbl].append(val)

        if not buckets:
            return {
                "categories": [],
                "series_names": [],
                "matrix": {},
                "raw_matrix": {},
                "totals": {},
                "stack_mode": stack_mode,
            }

        ordered_series = [
            s
            for s, _ in sorted(
                series_totals.items(),
                key=lambda kv: cls.compute_metric(kv[1], widget.aggregation),
                reverse=True,
            )
        ]

        cat_scores: List[Tuple[str, float]] = [
            (c, cls.compute_metric(vals, widget.aggregation))
            for c, vals in cat_all_vals.items()
        ]
        if widget.sort_by == "value_asc":
            cat_scores.sort(key=lambda item: item[1])
        elif widget.sort_by == "category_asc":
            cat_scores.sort(key=lambda item: item[0])
        else:
            cat_scores.sort(key=lambda item: item[1], reverse=True)

        top_n = max(1, int(widget.top_n or 15))
        head_cats = [c for c, _ in cat_scores]
        tail_cats: List[str] = []
        if len(cat_scores) > top_n:
            head_cats = [c for c, _ in cat_scores[: top_n - 1]]
            tail_cats = [c for c, _ in cat_scores[top_n - 1 :]]

        raw_matrix: Dict[str, Dict[str, float]] = {}
        for cat in head_cats:
            raw_matrix[cat] = {
                s: cls.compute_metric(buckets[cat][s], widget.aggregation)
                for s in ordered_series
                if buckets[cat].get(s)
            }
        if tail_cats:
            other_raw: Dict[str, List[Any]] = defaultdict(list)
            for tc in tail_cats:
                for s, vals in buckets[tc].items():
                    other_raw[s].extend(vals)
            raw_matrix["Other"] = {
                s: cls.compute_metric(other_raw[s], widget.aggregation)
                for s in ordered_series
                if other_raw.get(s)
            }
            head_cats = head_cats + ["Other"]

        totals: Dict[str, float] = {
            cat: sum(abs(v) for v in raw_matrix.get(cat, {}).values())
            for cat in head_cats
        }
        if stack_mode == "percent":
            matrix: Dict[str, Dict[str, float]] = {}
            for cat in head_cats:
                row_map = raw_matrix.get(cat, {})
                den = sum(max(0.0, float(v or 0.0)) for v in row_map.values())
                if den > 0.0:
                    matrix[cat] = {
                        s: round((max(0.0, float(v or 0.0)) / den) * 100.0, 2)
                        for s, v in row_map.items()
                    }
                else:
                    matrix[cat] = {s: 0.0 for s in row_map}
        else:
            matrix = {cat: dict(raw_matrix.get(cat, {})) for cat in head_cats}

        return {
            "categories": head_cats,
            "series_names": ordered_series,
            "matrix": matrix,
            "raw_matrix": raw_matrix,
            "totals": totals,
            "stack_mode": stack_mode,
        }
