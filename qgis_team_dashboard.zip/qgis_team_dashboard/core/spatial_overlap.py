# -*- coding: utf-8 -*-
"""
Spatial overlap & domain enrichment helpers for Estonian Natura 2000 habitats
('eelis:natura_elupaik') and PRIA semi-natural meadows ('pria_avalik:pria_plk').

Supports:
1. Derived conservation attributes:
   - 'koosluse_grupp' ('MN', 'PN', ...) extracted from PRIA 'parandniidu_tyyp'.
   - Normalized 'esinduslik' ('A', 'B', 'C', 'D', 'Määramata') on Natura features.
2. Pure-Python polygon overlap calculation (WGS84 / L-EST97 area estimation)
   requiring zero external geometry dependencies outside QGIS.
3. Native QGIS GEOS QgsSpatialIndex + QgsGeometry.intersection() enrichment
   when running inside QGIS 4.2+ or 3.44+ Desktop.
"""

import math
import time
from typing import Any, Callable, Dict, List, Optional, Tuple


def derive_koosluse_grupp(parandniidu_tyyp: Any) -> str:
    """Extract 'MN' / 'PN' community group prefix from PRIA 'parandniidu_tyyp'."""
    raw = str(parandniidu_tyyp or "").strip()
    if not raw:
        return "Muu"
    prefix = raw.split("-", 1)[0].strip().upper()
    return prefix or "Muu"


def enrich_records_domain_fields(records: List[Dict[str, Any]]) -> None:
    """Mutate extracted attribute dictionaries to normalize conservation categories."""
    for rec in records:
        if "parandniidu_tyyp" in rec:
            rec.setdefault("koosluse_grupp", derive_koosluse_grupp(rec.get("parandniidu_tyyp")))
        if "pohityyp" in rec and "esinduslik" in rec:
            val = rec.get("esinduslik")
            if val is None or str(val).strip() == "":
                rec["esinduslik"] = "Määramata"


# L-EST97 / EPSG:3301 Lambert Conformal Conic 2SP (GRS80 ellipsoid)
_LCC3301_A = 6378137.0
_LCC3301_F = 1.0 / 298.257222101
_LCC3301_E = math.sqrt(2.0 * _LCC3301_F - _LCC3301_F * _LCC3301_F)
_LCC3301_HALF_E = _LCC3301_E * 0.5
_LCC3301_RAD = math.pi / 180.0
_LCC3301_PI4 = math.pi * 0.25
_GRS80_AUTHALIC_R = 6371007.181


def _lcc3301_m(phi: float) -> float:
    s = _LCC3301_E * math.sin(phi)
    return math.cos(phi) / math.sqrt(1.0 - s * s)


def _lcc3301_t(phi: float) -> float:
    es = _LCC3301_E * math.sin(phi)
    return math.tan(_LCC3301_PI4 - phi * 0.5) / (((1.0 - es) / (1.0 + es)) ** _LCC3301_HALF_E)


_LCC3301_P1 = 59.33333333333334 * _LCC3301_RAD
_LCC3301_P2 = 58.0 * _LCC3301_RAD
_LCC3301_P0 = 57.51755393055556 * _LCC3301_RAD
_LCC3301_L0 = 24.0 * _LCC3301_RAD
_LCC3301_M1 = _lcc3301_m(_LCC3301_P1)
_LCC3301_M2 = _lcc3301_m(_LCC3301_P2)
_LCC3301_T0 = _lcc3301_t(_LCC3301_P0)
_LCC3301_T1 = _lcc3301_t(_LCC3301_P1)
_LCC3301_T2 = _lcc3301_t(_LCC3301_P2)
_LCC3301_N = (math.log(_LCC3301_M1) - math.log(_LCC3301_M2)) / (math.log(_LCC3301_T1) - math.log(_LCC3301_T2))
_LCC3301_AF = _LCC3301_A * _LCC3301_M1 / (_LCC3301_N * (_LCC3301_T1 ** _LCC3301_N))
_LCC3301_RHO0 = _LCC3301_AF * (_LCC3301_T0 ** _LCC3301_N)


def project_wgs84_to_estonia_3301(lon: float, lat: float) -> Tuple[float, float]:
    """Project WGS84 (lon, lat) coordinates to Estonian L-EST97 (EPSG:3301) Cartesian meters."""
    phi = lat * _LCC3301_RAD
    es = _LCC3301_E * math.sin(phi)
    t = math.tan(_LCC3301_PI4 - phi * 0.5) / (((1.0 - es) / (1.0 + es)) ** _LCC3301_HALF_E)
    rho = _LCC3301_AF * (t ** _LCC3301_N)
    th = _LCC3301_N * (lon * _LCC3301_RAD - _LCC3301_L0)
    return (500000.0 + rho * math.sin(th), 6375000.0 + _LCC3301_RHO0 - rho * math.cos(th))


def is_qgis_planar_metric_crs(crs: Any) -> bool:
    """Return True when *crs* is a projected metric CRS (safe across QGIS 3.x and 4.x)."""
    if crs is None or not crs.isValid() or crs.isGeographic():
        return False
    try:
        from qgis.core import Qgis, QgsUnitTypes  # type: ignore
    except Exception:
        return False
    unit = crs.mapUnits()
    candidates = []
    du = getattr(Qgis, "DistanceUnit", None)
    if du is not None and hasattr(du, "Meters"):
        candidates.append(getattr(du, "Meters"))
    ut = getattr(QgsUnitTypes, "DistanceUnit", None)
    if ut is not None:
        for attr in ("DistanceMeters", "Meters"):
            if hasattr(ut, attr):
                candidates.append(getattr(ut, attr))
    if hasattr(QgsUnitTypes, "DistanceMeters"):
        candidates.append(getattr(QgsUnitTypes, "DistanceMeters"))
    if unit in candidates:
        return True
    return "meter" in str(unit).lower()


class QgisCartesianAreaCalculator:
    """Measure polygon areas in Cartesian hectares (EPSG:3301 for Estonia / planar metric CRS)."""

    def __init__(self, crs: Any, tctx: Any, ellipsoid: str = "GRS80", layer: Any = None) -> None:
        self._planar = is_qgis_planar_metric_crs(crs)
        self._xform_3301 = None
        self._da = None
        if self._planar:
            return
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsDistanceArea,
            )

            if crs is not None and crs.isValid() and crs.isGeographic():
                in_estonia = False
                if layer is not None and hasattr(layer, "extent"):
                    try:
                        ext = layer.extent()
                        if (
                            not ext.isEmpty()
                            and ext.xMaximum() >= 19.0
                            and ext.xMinimum() <= 31.0
                            and ext.yMaximum() >= 56.0
                            and ext.yMinimum() <= 62.0
                        ):
                            in_estonia = True
                    except Exception:
                        pass
                if in_estonia:
                    est_crs = QgsCoordinateReferenceSystem("EPSG:3301")
                    if est_crs.isValid():
                        self._xform_3301 = QgsCoordinateTransform(crs, est_crs, tctx)
                        return
            self._da = QgsDistanceArea()
            self._da.setSourceCrs(crs, tctx)
            self._da.setEllipsoid(ellipsoid or "GRS80")
        except Exception:
            pass

    def measure_ha(self, geom: Any, decimals: int = 4) -> float:
        if geom is None or geom.isEmpty():
            return 0.0
        area_m2 = 0.0
        if self._planar:
            area_m2 = float(geom.area())
        elif self._xform_3301 is not None:
            try:
                from qgis.core import QgsGeometry  # type: ignore

                g_proj = QgsGeometry(geom)
                g_proj.transform(self._xform_3301)
                area_m2 = float(g_proj.area())
            except Exception:
                area_m2 = 0.0
        elif self._da is not None:
            area_m2 = float(self._da.measureArea(geom))
        else:
            area_m2 = float(geom.area())
        return max(0.0, round(area_m2 / 10000.0, decimals))


def _ring_area_m2(ring: List[List[float]]) -> float:
    if len(ring) < 3:
        return 0.0
    p0 = ring[0]
    lon0 = float(p0[0])
    lat0 = float(p0[1])
    # Use L-EST97 (EPSG:3301) Cartesian planar area for Estonian WGS84 polygons
    if 19.5 <= lon0 <= 30.5 and 56.5 <= lat0 <= 61.5:
        tan = math.tan
        sin = math.sin
        cos = math.cos
        rad = _LCC3301_RAD
        pi4 = _LCC3301_PI4
        e = _LCC3301_E
        half_e = _LCC3301_HALF_E
        n_exp = _LCC3301_N
        af = _LCC3301_AF
        l0 = _LCC3301_L0

        # Origin-shifted Cartesian coords (rho*sin(th), -rho*cos(th)) preserve full float64 precision
        phi = lat0 * rad
        es = e * sin(phi)
        rho = af * ((tan(pi4 - phi * 0.5) / ((1.0 - es) / (1.0 + es)) ** half_e) ** n_exp)
        th = n_exp * (lon0 * rad - l0)
        x0 = rho * sin(th)
        y0 = -rho * cos(th)
        px, py = x0, y0
        area = 0.0
        for pt in ring[1:]:
            phi = float(pt[1]) * rad
            es = e * sin(phi)
            rho = af * ((tan(pi4 - phi * 0.5) / ((1.0 - es) / (1.0 + es)) ** half_e) ** n_exp)
            th = n_exp * (float(pt[0]) * rad - l0)
            cx = rho * sin(th)
            cy = -rho * cos(th)
            area += px * cy - cx * py
            px, py = cx, cy
        area += px * y0 - x0 * py
        return abs(area) * 0.5

    # Already-projected planar metric coordinates (e.g. raw EPSG:3301 GeoJSON)
    if abs(lon0) > 180.0 or abs(lat0) > 90.0:
        px, py = 0.0, 0.0
        area = 0.0
        for pt in ring[1:]:
            cx = float(pt[0]) - lon0
            cy = float(pt[1]) - lat0
            area += px * cy - cx * py
            px, py = cx, cy
        return abs(area) * 0.5

    rad = _LCC3301_RAD
    acc = 0.0
    n = len(ring)
    for i in range(n):
        p1 = ring[i]
        p2 = ring[(i + 1) % n]
        acc += (float(p2[0]) * rad - float(p1[0]) * rad) * (
            2.0 + math.sin(float(p1[1]) * rad) + math.sin(float(p2[1]) * rad)
        )
    return abs((acc * _GRS80_AUTHALIC_R * _GRS80_AUTHALIC_R) / 2.0)


def geom_area_ha(geom: Dict[str, Any]) -> float:
    """Compute Cartesian polygon area in hectares from GeoJSON geometry dict."""
    gtype = (geom or {}).get("type")
    coords = (geom or {}).get("coordinates") or []
    area_m2 = 0.0
    if gtype == "Polygon" and coords:
        area_m2 += _ring_area_m2(coords[0])
        for hole in coords[1:]:
            area_m2 -= _ring_area_m2(hole)
    elif gtype == "MultiPolygon":
        for poly in coords:
            if poly:
                area_m2 += _ring_area_m2(poly[0])
                for hole in poly[1:]:
                    area_m2 -= _ring_area_m2(hole)
    return max(0.0, round(area_m2 / 10000.0, 4))


def _point_in_ring(x: float, y: float, ring: List[List[float]]) -> bool:
    inside = False
    n = len(ring)
    if n < 3:
        return False
    x1, y1 = ring[0][0], ring[0][1]
    for i in range(1, n + 1):
        x2, y2 = ring[i % n][0], ring[i % n][1]
        if (y1 > y) != (y2 > y):
            x_int = (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-18) + x1
            if x < x_int:
                inside = not inside
        x1, y1 = x2, y2
    return inside


def _point_in_poly_coords(x: float, y: float, poly_rings: List[List[List[float]]]) -> bool:
    if not poly_rings or not _point_in_ring(x, y, poly_rings[0]):
        return False
    for hole in poly_rings[1:]:
        if _point_in_ring(x, y, hole):
            return False
    return True


def _extract_poly_parts(
    geom: Optional[Dict[str, Any]],
) -> List[Tuple[Tuple[float, float, float, float], List[List[List[float]]]]]:
    if not geom or not geom.get("coordinates"):
        return []
    gtype = geom.get("type")
    raw_polys: List[List[List[List[float]]]] = []
    if gtype == "Polygon":
        raw_polys = [geom["coordinates"]]
    elif gtype == "MultiPolygon":
        raw_polys = list(geom["coordinates"])

    parts: List[Tuple[Tuple[float, float, float, float], List[List[List[float]]]]] = []
    for rings in raw_polys:
        if not rings or not rings[0]:
            continue
        outer = rings[0]
        xs = [pt[0] for pt in outer]
        ys = [pt[1] for pt in outer]
        bbox = (min(xs), min(ys), max(xs), max(ys))
        parts.append((bbox, rings))
    return parts


def _bbox_overlaps(a: Tuple[float, float, float, float], b: Tuple[float, float, float, float]) -> bool:
    return not (a[2] < b[0] or a[0] > b[2] or a[3] < b[1] or a[1] > b[3])


def geojson_bbox_wgs84(geom: Any) -> Optional[Tuple[float, float, float, float]]:
    """Compute (xmin, ymin, xmax, ymax) bounding box from a GeoJSON geometry dict."""
    if not isinstance(geom, dict):
        return None
    gtype = geom.get("type") or ""
    coords = geom.get("coordinates")
    if not gtype or not coords:
        return None
    xs: List[float] = []
    ys: List[float] = []

    def _walk(c: Any) -> None:
        if isinstance(c, (list, tuple)) and len(c) >= 2 and isinstance(c[0], (int, float)) and isinstance(c[1], (int, float)):
            xs.append(float(c[0]))
            ys.append(float(c[1]))
            return
        if isinstance(c, (list, tuple)):
            for item in c:
                _walk(item)

    if gtype == "GeometryCollection":
        for sub in (geom.get("geometries") or []):
            sb = geojson_bbox_wgs84(sub)
            if sb is not None:
                xs.extend([sb[0], sb[2]])
                ys.extend([sb[1], sb[3]])
    else:
        _walk(coords)
    if not xs or not ys:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def _segments_intersect(
    ax1: float, ay1: float, ax2: float, ay2: float,
    bx1: float, by1: float, bx2: float, by2: float,
) -> bool:
    if max(ax1, ax2) < min(bx1, bx2) or max(bx1, bx2) < min(ax1, ax2):
        return False
    if max(ay1, ay2) < min(by1, by2) or max(by1, by2) < min(ay1, ay2):
        return False

    def _orient(px: float, py: float, qx: float, qy: float, rx: float, ry: float) -> float:
        return (qx - px) * (ry - py) - (qy - py) * (rx - px)

    d1 = _orient(bx1, by1, bx2, by2, ax1, ay1)
    d2 = _orient(bx1, by1, bx2, by2, ax2, ay2)
    d3 = _orient(ax1, ay1, ax2, ay2, bx1, by1)
    d4 = _orient(ax1, ay1, ax2, ay2, bx2, by2)
    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
        return True
    eps = 1e-12
    def _on_seg(px: float, py: float, qx: float, qy: float, rx: float, ry: float) -> bool:
        return min(px, rx) - eps <= qx <= max(px, rx) + eps and min(py, ry) - eps <= qy <= max(py, ry) + eps
    if abs(d1) <= eps and _on_seg(bx1, by1, ax1, ay1, bx2, by2):
        return True
    if abs(d2) <= eps and _on_seg(bx1, by1, ax2, ay2, bx2, by2):
        return True
    if abs(d3) <= eps and _on_seg(ax1, ay1, bx1, by1, ax2, ay2):
        return True
    if abs(d4) <= eps and _on_seg(ax1, ay1, bx2, by2, ax2, ay2):
        return True
    return False


def _extract_point_coords(geom: Any) -> List[Tuple[float, float]]:
    if not isinstance(geom, dict):
        return []
    gt = geom.get("type") or ""
    coords = geom.get("coordinates")
    if gt == "Point" and isinstance(coords, (list, tuple)) and len(coords) >= 2:
        return [(float(coords[0]), float(coords[1]))]
    if gt == "MultiPoint" and isinstance(coords, (list, tuple)):
        return [(float(c[0]), float(c[1])) for c in coords if isinstance(c, (list, tuple)) and len(c) >= 2]
    return []


def _extract_line_coords(geom: Any) -> List[List[Tuple[float, float]]]:
    if not isinstance(geom, dict):
        return []
    gt = geom.get("type") or ""
    coords = geom.get("coordinates")
    if gt == "LineString" and isinstance(coords, (list, tuple)):
        pts = [(float(c[0]), float(c[1])) for c in coords if isinstance(c, (list, tuple)) and len(c) >= 2]
        return [pts] if len(pts) >= 2 else []
    if gt == "MultiLineString" and isinstance(coords, (list, tuple)):
        out = []
        for line in coords:
            if isinstance(line, (list, tuple)):
                pts = [(float(c[0]), float(c[1])) for c in line if isinstance(c, (list, tuple)) and len(c) >= 2]
                if len(pts) >= 2:
                    out.append(pts)
        return out
    return []


def geom_intersects_geom(g1: Any, g2: Any) -> bool:
    """Return True if two WGS84 GeoJSON geometries intersect spatially."""
    if not isinstance(g1, dict) or not isinstance(g2, dict):
        return False
    b1 = geojson_bbox_wgs84(g1)
    b2 = geojson_bbox_wgs84(g2)
    if b1 is None or b2 is None or not _bbox_overlaps(b1, b2):
        return False

    t1 = g1.get("type") or ""
    t2 = g2.get("type") or ""
    if t1 == "GeometryCollection":
        return any(geom_intersects_geom(sub, g2) for sub in (g1.get("geometries") or []))
    if t2 == "GeometryCollection":
        return any(geom_intersects_geom(g1, sub) for sub in (g2.get("geometries") or []))

    p1 = _extract_poly_parts(g1)
    p2 = _extract_poly_parts(g2)
    if p1 and p2:
        for b1_p, rings1 in p1:
            for ring in rings1:
                for x, y in ring:
                    if any(_bbox_overlaps(b1_p, b2_p) and _point_in_poly_coords(x, y, rings2) for b2_p, rings2 in p2):
                        return True
        for b2_p, rings2 in p2:
            for ring in rings2:
                for x, y in ring:
                    if any(_bbox_overlaps(b1_p, b2_p) and _point_in_poly_coords(x, y, rings1) for b1_p, rings1 in p1):
                        return True
        for b1_p, rings1 in p1:
            for ring1 in rings1:
                n1 = len(ring1)
                if n1 < 2:
                    continue
                for i in range(n1):
                    ax1, ay1 = ring1[i][0], ring1[i][1]
                    ax2, ay2 = ring1[(i + 1) % n1][0], ring1[(i + 1) % n1][1]
                    if ax1 == ax2 and ay1 == ay2:
                        continue
                    for b2_p, rings2 in p2:
                        if not _bbox_overlaps(b1_p, b2_p):
                            continue
                        for ring2 in rings2:
                            n2 = len(ring2)
                            if n2 < 2:
                                continue
                            for j in range(n2):
                                bx1, by1 = ring2[j][0], ring2[j][1]
                                bx2, by2 = ring2[(j + 1) % n2][0], ring2[(j + 1) % n2][1]
                                if bx1 == bx2 and by1 == by2:
                                    continue
                                if _segments_intersect(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2):
                                    return True
        return False

    pts1 = _extract_point_coords(g1)
    pts2 = _extract_point_coords(g2)
    if p1 and pts2:
        return any(
            _bbox_overlaps(b1_p, (x, y, x, y)) and _point_in_poly_coords(x, y, rings1)
            for x, y in pts2
            for b1_p, rings1 in p1
        )
    if p2 and pts1:
        return any(
            _bbox_overlaps(b2_p, (x, y, x, y)) and _point_in_poly_coords(x, y, rings2)
            for x, y in pts1
            for b2_p, rings2 in p2
        )

    lines1 = _extract_line_coords(g1)
    lines2 = _extract_line_coords(g2)
    if p1 and lines2:
        for line in lines2:
            for x, y in line:
                if any(_bbox_overlaps(b1_p, (x, y, x, y)) and _point_in_poly_coords(x, y, rings1) for b1_p, rings1 in p1):
                    return True
            for i in range(len(line) - 1):
                for b1_p, rings1 in p1:
                    for ring1 in rings1:
                        n1 = len(ring1)
                        for j in range(n1):
                            if _segments_intersect(
                                line[i][0], line[i][1], line[i + 1][0], line[i + 1][1],
                                ring1[j][0], ring1[j][1], ring1[(j + 1) % n1][0], ring1[(j + 1) % n1][1],
                            ):
                                return True
        return False
    if p2 and lines1:
        return geom_intersects_geom(g2, g1)
    if lines1 and lines2:
        for l1 in lines1:
            for i in range(len(l1) - 1):
                for l2 in lines2:
                    for j in range(len(l2) - 1):
                        if _segments_intersect(l1[i][0], l1[i][1], l1[i + 1][0], l1[i + 1][1], l2[j][0], l2[j][1], l2[j + 1][0], l2[j + 1][1]):
                            return True
        return False
    return True


def compute_geojson_overlap_for_natura(
    natura_features: List[Dict[str, Any]],
    pria_features: List[Dict[str, Any]],
    samples_per_axis: int = 20,
    progress_cb: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> Dict[str, Any]:
    """
    Compute spatial polygon overlap (ha and %) between Natura_elupaik features and
    PRIA Pärandniidud features in pure Python, avoiding double-counting when multiple
    PRIA parcels overlap a single Natura habitat polygon.
    Mutates feature['properties'] in place with area_ha, overlap_pria_ha,
    overlap_mn_ha, overlap_pn_ha, overlap_pct, and derived 'koosluse_grupp'.
    """
    import math

    cell_deg = 0.04
    pria_index: List[Tuple[Tuple[float, float, float, float], List[Tuple[Any, Any]], str, Any]] = []
    pria_grid: Dict[Tuple[int, int], List[int]] = {}
    pria_large: List[int] = []
    pria_total_ha = 0.0
    n_pria = max(1, len(pria_features))
    last_tick = time.monotonic()

    for pidx, pf in enumerate(pria_features):
        if cancel_check and (pidx % 100 == 0) and cancel_check():
            return {"cancelled": True}
        props = pf.setdefault("properties", {})
        area_ha = props.get("area_ha")
        if area_ha is None:
            area_ha = geom_area_ha(pf.get("geometry") or {})
            props["area_ha"] = area_ha
        pria_total_ha += float(area_ha or 0.0)
        grp = derive_koosluse_grupp(props.get("parandniidu_tyyp"))
        props["koosluse_grupp"] = grp
        pfid = pf.get("id")
        if pfid is None:
            pfid = props.get("_feature_id", pidx)
        parts = _extract_poly_parts(pf.get("geometry"))
        if parts:
            bx0 = min(p[0][0] for p in parts)
            by0 = min(p[0][1] for p in parts)
            bx1 = max(p[0][2] for p in parts)
            by1 = max(p[0][3] for p in parts)
            item_idx = len(pria_index)
            pria_index.append(((bx0, by0, bx1, by1), parts, grp, pfid))
            ix0 = int(math.floor(bx0 / cell_deg))
            ix1 = int(math.floor(bx1 / cell_deg))
            iy0 = int(math.floor(by0 / cell_deg))
            iy1 = int(math.floor(by1 / cell_deg))
            if (ix1 - ix0 + 1) * (iy1 - iy0 + 1) > 400:
                pria_large.append(item_idx)
            else:
                for gx in range(ix0, ix1 + 1):
                    for gy in range(iy0, iy1 + 1):
                        pria_grid.setdefault((gx, gy), []).append(item_idx)
        if progress_cb and (pidx % 250 == 0):
            now_ts = time.monotonic()
            if (now_ts - last_tick) >= 0.025:
                last_tick = now_ts
                progress_cb(min(15, 1 + int(14 * (pidx + 1) / n_pria)), 100)

    natura_total_ha = 0.0
    overlap_total_ha = 0.0
    overlap_mn_ha = 0.0
    overlap_pn_ha = 0.0
    by_pohityyp: Dict[str, Dict[str, float]] = {}
    n_nat = max(1, len(natura_features))

    for nidx, nf in enumerate(natura_features):
        now_ts = time.monotonic()
        need_tick = (now_ts - last_tick) >= 0.025
        if cancel_check and (nidx % 100 == 0 or need_tick) and cancel_check():
            return {"cancelled": True}
        if progress_cb and need_tick:
            last_tick = now_ts
            progress_cb(min(99, 15 + int(84 * (nidx + 1) / n_nat)), 100)

        props = nf.setdefault("properties", {})
        area_ha = props.get("area_ha")
        if area_ha is None:
            area_ha = geom_area_ha(nf.get("geometry") or {})
            props["area_ha"] = area_ha
        area_ha_f = float(area_ha or 0.0)
        natura_total_ha += area_ha_f

        if props.get("esinduslik") in (None, ""):
            props["esinduslik"] = "Määramata"

        pohityyp = str(props.get("pohityyp") or "Muu")
        pt_bucket = by_pohityyp.setdefault(pohityyp, {"natura_ha": 0.0, "overlap_ha": 0.0})
        pt_bucket["natura_ha"] += area_ha_f

        geom_obj = nf.get("geometry")
        n_bbox = None
        raw_bb = props.get("_bbox")
        if isinstance(raw_bb, (list, tuple)) and len(raw_bb) == 4:
            try:
                n_bbox = (float(raw_bb[0]), float(raw_bb[1]), float(raw_bb[2]), float(raw_bb[3]))
            except Exception:
                n_bbox = None
        if n_bbox is None:
            n_bbox = geojson_bbox_wgs84(geom_obj)

        if n_bbox is None or area_ha_f <= 0.0:
            props["overlap_pria_ha"] = 0.0
            props["overlap_mn_ha"] = 0.0
            props["overlap_pn_ha"] = 0.0
            props["overlap_pct"] = 0.0
            continue

        nb0, nb1, nb2, nb3 = n_bbox
        ix0 = int(math.floor(nb0 / cell_deg))
        ix1 = int(math.floor(nb2 / cell_deg))
        iy0 = int(math.floor(nb1 / cell_deg))
        iy1 = int(math.floor(nb3 / cell_deg))

        candidates = []
        seen_cidx = set()
        if (ix1 - ix0 + 1) * (iy1 - iy0 + 1) > 400:
            for item_idx in range(len(pria_index)):
                item = pria_index[item_idx]
                if _bbox_overlaps(n_bbox, item[0]):
                    candidates.append(item)
        else:
            for gx in range(ix0, ix1 + 1):
                for gy in range(iy0, iy1 + 1):
                    bucket = pria_grid.get((gx, gy))
                    if not bucket:
                        continue
                    for item_idx in bucket:
                        if item_idx in seen_cidx:
                            continue
                        seen_cidx.add(item_idx)
                        item = pria_index[item_idx]
                        if _bbox_overlaps(n_bbox, item[0]):
                            candidates.append(item)
            for item_idx in pria_large:
                if item_idx not in seen_cidx:
                    seen_cidx.add(item_idx)
                    item = pria_index[item_idx]
                    if _bbox_overlaps(n_bbox, item[0]):
                        candidates.append(item)

        if not candidates:
            props["overlap_pria_ha"] = 0.0
            props["overlap_mn_ha"] = 0.0
            props["overlap_pn_ha"] = 0.0
            props["overlap_pct"] = 0.0
            continue

        n_parts = _extract_poly_parts(geom_obj)
        if not n_parts:
            props["overlap_pria_ha"] = 0.0
            props["overlap_mn_ha"] = 0.0
            props["overlap_pn_ha"] = 0.0
            props["overlap_pct"] = 0.0
            continue
        nb0 = min(p[0][0] for p in n_parts)
        nb1 = min(p[0][1] for p in n_parts)
        nb2 = max(p[0][2] for p in n_parts)
        nb3 = max(p[0][3] for p in n_parts)

        dx = (nb2 - nb0) / samples_per_axis
        dy = (nb3 - nb1) / samples_per_axis
        if dx <= 0 or dy <= 0:
            props["overlap_pria_ha"] = 0.0
            props["overlap_mn_ha"] = 0.0
            props["overlap_pn_ha"] = 0.0
            props["overlap_pct"] = 0.0
            continue

        in_nat = 0
        in_pria = 0
        in_mn = 0
        in_pn = 0
        cand_hits = [0] * len(candidates)
        for ix in range(samples_per_axis):
            px = nb0 + (ix + 0.5) * dx
            for iy in range(samples_per_axis):
                py = nb1 + (iy + 0.5) * dy
                inside_n = any(
                    _bbox_overlaps((px, py, px, py), pb) and _point_in_poly_coords(px, py, rings)
                    for pb, rings in n_parts
                )
                if not inside_n:
                    continue
                in_nat += 1
                hit_any = False
                hit_mn = False
                hit_pn = False
                for c_idx, (cbbox, cparts, cgrp, _cfid) in enumerate(candidates):
                    if not _bbox_overlaps((px, py, px, py), cbbox):
                        continue
                    if any(
                        _bbox_overlaps((px, py, px, py), pb) and _point_in_poly_coords(px, py, rings)
                        for pb, rings in cparts
                    ):
                        hit_any = True
                        cand_hits[c_idx] += 1
                        if cgrp == "MN":
                            hit_mn = True
                        elif cgrp == "PN":
                            hit_pn = True
                if hit_any:
                    in_pria += 1
                if hit_mn:
                    in_mn += 1
                if hit_pn:
                    in_pn += 1

        if in_nat == 0:
            # Tiny polygon falling between grid cells -> fallback centroid point check
            cx = (nb0 + nb2) * 0.5
            cy = (nb1 + nb3) * 0.5
            for c_idx, (cbbox, cparts, cgrp, _cfid) in enumerate(candidates):
                if _bbox_overlaps((cx, cy, cx, cy), cbbox) and any(
                    _point_in_poly_coords(cx, cy, rings) for _, rings in cparts
                ):
                    in_nat = 1
                    in_pria = 1
                    cand_hits[c_idx] = 1
                    if cgrp == "MN":
                        in_mn = 1
                    elif cgrp == "PN":
                        in_pn = 1
                    break

        ratio = (in_pria / in_nat) if in_nat > 0 else 0.0
        ov_ha = round(area_ha_f * ratio, 2)
        mn_ha = round(area_ha_f * ((in_mn / in_nat) if in_nat > 0 else 0.0), 2)
        pn_ha = round(area_ha_f * ((in_pn / in_nat) if in_nat > 0 else 0.0), 2)
        props["overlap_pria_ha"] = ov_ha
        props["overlap_mn_ha"] = mn_ha
        props["overlap_pn_ha"] = pn_ha
        props["overlap_pct"] = round(ratio * 100.0, 1)
        if ov_ha > 0 and in_nat > 0:
            pairs = []
            for c_idx, hits in enumerate(cand_hits):
                if hits > 0:
                    c_ha = round(min(ov_ha, area_ha_f * (hits / in_nat)), 3)
                    if c_ha > 0:
                        pairs.append([candidates[c_idx][3], c_ha])
            if pairs:
                props["_pria_ov"] = pairs

        overlap_total_ha += ov_ha
        overlap_mn_ha += mn_ha
        overlap_pn_ha += pn_ha
        pt_bucket["overlap_ha"] += ov_ha

    return {
        "natura_total_ha": round(natura_total_ha, 2),
        "pria_total_ha": round(pria_total_ha, 2),
        "overlap_total_ha": round(overlap_total_ha, 2),
        "overlap_mn_ha": round(overlap_mn_ha, 2),
        "overlap_pn_ha": round(overlap_pn_ha, 2),
        "overall_overlap_pct": round((overlap_total_ha / natura_total_ha) * 100.0, 1) if natura_total_ha else 0.0,
        "by_pohityyp": by_pohityyp,
    }


def enrich_natura_pria_overlap_qgis(
    natura_layer: Any,
    natura_records: List[Dict[str, Any]],
    pria_layer: Any,
    transform_context: Any = None,
    ellipsoid: str = "",
    progress_cb: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
    pria_records: Optional[List[Dict[str, Any]]] = None,
) -> None:
    """Use QGIS GEOS QgsSpatialIndex + QgsGeometry.intersection() to compute exact overlap hectares."""
    if natura_layer is None or pria_layer is None or not natura_records:
        return
    try:
        from qgis.core import (
            QgsCoordinateTransform,
            QgsDistanceArea,
            QgsFeature,
            QgsGeometry,
            QgsProject,
            QgsSpatialIndex,
        )
        from .vector_pyramid import build_qgis_fid_to_record_key_map

        nat_fid_to_key = build_qgis_fid_to_record_key_map(natura_layer, natura_records)
        pria_fid_to_key = build_qgis_fid_to_record_key_map(pria_layer, pria_records) if pria_records else {}

        proj = QgsProject.instance() if transform_context is None else None
        tctx = transform_context if transform_context is not None else proj.transformContext()
        ellip = ellipsoid or (proj.ellipsoid() if proj is not None else "GRS80") or "GRS80"
        nat_crs = natura_layer.crs()
        pria_crs = pria_layer.crs()
        xform = (
            QgsCoordinateTransform(pria_crs, nat_crs, tctx if transform_context is not None else proj)
            if pria_crs != nat_crs
            else None
        )

        area_calc = QgisCartesianAreaCalculator(nat_crs, tctx, ellipsoid=ellip, layer=natura_layer)

        pria_geoms: Dict[int, Tuple[Any, str]] = {}
        idx = QgsSpatialIndex()
        last_tick = time.monotonic()
        pria_fcount = int(pria_layer.featureCount()) if hasattr(pria_layer, "featureCount") else -1
        for p_idx, pf in enumerate(pria_layer.getFeatures()):
            now_ts = time.monotonic()
            tick = (now_ts - last_tick) >= 0.018
            if cancel_check and (p_idx % 25 == 0 or tick) and cancel_check():
                return
            if tick:
                last_tick = now_ts
                if progress_cb and pria_fcount > 0:
                    progress_cb(min(30, 1 + int(29 * p_idx / max(1, pria_fcount))), 100)
            if not pf.hasGeometry():
                continue
            geom = QgsGeometry(pf.geometry())
            if xform is not None:
                geom.transform(xform)
            grp = derive_koosluse_grupp(pf["parandniidu_tyyp"] if "parandniidu_tyyp" in pf.fields().names() else "")
            pria_geoms[pf.id()] = (geom, grp)
            if xform is None:
                idx.addFeature(pf)

        # Always populate spatial index using transformed geometries
        if xform is not None:
            idx = QgsSpatialIndex()
            for pid, (geom, _grp) in pria_geoms.items():
                tmp = QgsFeature(pid)
                tmp.setGeometry(geom)
                idx.addFeature(tmp)

        rec_by_fid_str = {str(r.get("_feature_id")): r for r in natura_records if r.get("_feature_id") is not None}
        nat_total = max(1, len(rec_by_fid_str))
        for n_idx, nf in enumerate(natura_layer.getFeatures()):
            now_ts = time.monotonic()
            tick = (now_ts - last_tick) >= 0.018
            if cancel_check and (n_idx % 25 == 0 or tick) and cancel_check():
                return
            if tick:
                last_tick = now_ts
                if progress_cb:
                    progress_cb(min(99, 30 + int(69 * n_idx / nat_total)), 100)
            rec_key = nat_fid_to_key.get(nf.id(), str(nf.id()))
            rec = rec_by_fid_str.get(rec_key) or rec_by_fid_str.get(str(nf.id()))
            if rec is None or not nf.hasGeometry():
                continue
            ngeom = nf.geometry()
            cand_ids = idx.intersects(ngeom.boundingBox())
            nat_ha = float(rec.get("area_ha") or area_calc.measure_ha(ngeom, decimals=4))
            ov_geoms: List[Any] = []
            mn_geoms: List[Any] = []
            pn_geoms: List[Any] = []
            pria_pairs: List[List[Any]] = []
            for cid in cand_ids:
                pair = pria_geoms.get(cid)
                if not pair:
                    continue
                pgeom, pgrp = pair
                if ngeom.intersects(pgeom):
                    inter = ngeom.intersection(pgeom)
                    if not inter.isEmpty():
                        pair_ha = area_calc.measure_ha(inter, decimals=4)
                        if pair_ha <= 0.0:
                            continue
                        ov_geoms.append(inter)
                        pria_key = pria_fid_to_key.get(cid, cid) if pria_fid_to_key else cid
                        pria_pairs.append([pria_key, min(nat_ha, pair_ha)])
                        if pgrp == "MN":
                            mn_geoms.append(inter)
                        elif pgrp == "PN":
                            pn_geoms.append(inter)

            def _union_ha(glist: List[Any]) -> float:
                if not glist:
                    return 0.0
                u = QgsGeometry.unaryUnion(glist) if len(glist) > 1 else glist[0]
                return area_calc.measure_ha(u, decimals=4)

            ov_ha = _union_ha(ov_geoms)
            rec["overlap_pria_ha"] = min(nat_ha, ov_ha)
            rec["overlap_mn_ha"] = min(nat_ha, _union_ha(mn_geoms))
            rec["overlap_pn_ha"] = min(nat_ha, _union_ha(pn_geoms))
            rec["overlap_pct"] = round((rec["overlap_pria_ha"] / nat_ha) * 100.0, 1) if nat_ha > 0 else 0.0
            if rec["overlap_pria_ha"] > 0 and pria_pairs:
                rec["_pria_ov"] = pria_pairs
    except Exception:
        pass


def compute_spatial_pivot_records(
    base_records: List[Dict[str, Any]],
    join_records: List[Dict[str, Any]],
    join_layer_name: str,
    base_layer: Any = None,
    join_layer: Any = None,
    base_geojson: Optional[Dict[str, Any]] = None,
    join_geojson: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    Build Spatial Pivot records by spatially intersecting `base_layer` (or `base_records`)
    with `join_layer` (or `join_records`).
    Each output row inherits all attributes of the base feature plus prefixed
    `[<join_layer_name>] <field>` attributes from the intersecting feature (or '(No overlap)'
    for uncovered remainder) and exact intersected `_geom_area_ha` / `area_ha`.
    Inspired directly by QGIS Pivot's spatial intersection matrix.
    """
    if not join_layer_name:
        return list(base_records)

    prefix = f"[{join_layer_name}] "

    # 1. Native QGIS GEOS QgsSpatialIndex + QgsGeometry.intersection path
    if base_layer is not None and join_layer is not None and hasattr(base_layer, "getFeatures"):
        try:
            from qgis.core import (
                QgsCoordinateTransform,
                QgsDistanceArea,
                QgsFeature,
                QgsGeometry,
                QgsProject,
                QgsSpatialIndex,
            )

            proj = QgsProject.instance()
            base_crs = base_layer.crs()
            join_crs = join_layer.crs()
            xform = QgsCoordinateTransform(join_crs, base_crs, proj) if join_crs != base_crs else None

            da = QgisCartesianAreaCalculator(
                base_crs,
                proj.transformContext(),
                ellipsoid=proj.ellipsoid() or "GRS80",
                layer=base_layer,
            )

            j_field_names = [f.name() for f in join_layer.fields()]
            b_field_names = [f.name() for f in base_layer.fields()]

            j_idx = QgsSpatialIndex()
            j_store: Dict[int, Tuple[Any, Dict[str, Any]]] = {}
            for jf in join_layer.getFeatures():
                if not jf.hasGeometry():
                    continue
                jg = QgsGeometry(jf.geometry())
                if jg.isEmpty():
                    continue
                if xform is not None:
                    jg.transform(xform)
                jattrs = {fn: jf[fn] for fn in j_field_names}
                tmp = QgsFeature(jf.id())
                tmp.setGeometry(jg)
                j_idx.addFeature(tmp)
                j_store[jf.id()] = (jg, jattrs)

            rec_by_fid = {r.get("_feature_id"): r for r in base_records if r.get("_feature_id") is not None}
            out_rows: List[Dict[str, Any]] = []

            for bf in base_layer.getFeatures():
                base_row = dict(rec_by_fid.get(bf.id()) or {})
                if not base_row:
                    base_row = {fn: bf[fn] for fn in b_field_names}
                    base_row["_feature_id"] = bf.id()
                if not bf.hasGeometry():
                    continue
                bg = bf.geometry()
                if bg.isEmpty():
                    continue
                total_ha = da.measure_ha(bg, decimals=4)
                cands = j_idx.intersects(bg.boundingBox())
                inter_geoms: List[Any] = []

                for cid in cands:
                    pair = j_store.get(cid)
                    if not pair:
                        continue
                    jg, jattrs = pair
                    if not bg.intersects(jg):
                        continue
                    inter = bg.intersection(jg)
                    if inter.isEmpty():
                        continue
                    part_ha = da.measure_ha(inter, decimals=4)
                    if part_ha <= 0.0 and total_ha > 0.0:
                        continue
                    inter_geoms.append(inter)
                    piece = dict(base_row)
                    for jf_name, jv in jattrs.items():
                        piece[f"{prefix}{jf_name}"] = jv
                    piece["_geom_area_ha"] = part_ha
                    piece["area_ha"] = part_ha
                    out_rows.append(piece)

                # Non-overlapping remainder row if base polygon is only partially covered
                if inter_geoms:
                    try:
                        union_hit = QgsGeometry.unaryUnion(inter_geoms) if len(inter_geoms) > 1 else inter_geoms[0]
                        hit_ha = da.measure_ha(union_hit, decimals=4)
                    except Exception:
                        hit_ha = sum(float(r.get("_geom_area_ha") or 0.0) for r in out_rows[-len(inter_geoms):])
                    rem_ha = max(0.0, round(total_ha - hit_ha, 4))
                else:
                    rem_ha = total_ha

                if rem_ha > 0.01:
                    rem_piece = dict(base_row)
                    for jf_name in j_field_names:
                        rem_piece[f"{prefix}{jf_name}"] = "(No overlap)"
                    rem_piece["_geom_area_ha"] = rem_ha
                    rem_piece["area_ha"] = rem_ha
                    out_rows.append(rem_piece)

            if out_rows:
                return out_rows
        except Exception:
            pass

    # 2. Pure-Python fallback (GeoJSON bbox / point-in-polygon OR cached _lat/_lon proximity)
    j_keys: List[str] = []
    for jr in join_records[:25]:
        for k in jr.keys():
            if not str(k).startswith("_") and k not in j_keys:
                j_keys.append(str(k))

    j_feats_by_id: Dict[Any, Dict[str, Any]] = {}
    if join_geojson and isinstance(join_geojson.get("features"), list):
        for f in join_geojson["features"]:
            fid = f.get("id") or (f.get("properties") or {}).get("_feature_id")
            if fid is not None:
                j_feats_by_id[fid] = f

    b_feats_by_id: Dict[Any, Dict[str, Any]] = {}
    if base_geojson and isinstance(base_geojson.get("features"), list):
        for f in base_geojson["features"]:
            fid = f.get("id") or (f.get("properties") or {}).get("_feature_id")
            if fid is not None:
                b_feats_by_id[fid] = f

    join_geom_index: List[Tuple[Tuple[float, float, float, float], List[Any], Dict[str, Any]]] = []
    for jr in join_records:
        fid = jr.get("_feature_id")
        jf = j_feats_by_id.get(fid)
        parts = _extract_poly_parts((jf or {}).get("geometry"))
        if parts:
            bx0 = min(p[0][0] for p in parts)
            by0 = min(p[0][1] for p in parts)
            bx1 = max(p[0][2] for p in parts)
            by1 = max(p[0][3] for p in parts)
            join_geom_index.append(((bx0, by0, bx1, by1), parts, jr))
        elif jr.get("_lon") is not None and jr.get("_lat") is not None:
            lx, ly = float(jr["_lon"]), float(jr["_lat"])
            join_geom_index.append(((lx - 0.002, ly - 0.002, lx + 0.002, ly + 0.002), [], jr))

    out_py: List[Dict[str, Any]] = []
    for br in base_records:
        fid = br.get("_feature_id")
        bf = b_feats_by_id.get(fid)
        b_parts = _extract_poly_parts((bf or {}).get("geometry"))
        base_ha = float(br.get("_geom_area_ha") or br.get("area_ha") or 0.0)
        if b_parts:
            nb0 = min(p[0][0] for p in b_parts)
            nb1 = min(p[0][1] for p in b_parts)
            nb2 = max(p[0][2] for p in b_parts)
            nb3 = max(p[0][3] for p in b_parts)
            b_box = (nb0, nb1, nb2, nb3)
            if base_ha <= 0.0:
                base_ha = geom_area_ha((bf or {}).get("geometry") or {})
        elif br.get("_lon") is not None and br.get("_lat") is not None:
            lx, ly = float(br["_lon"]), float(br["_lat"])
            b_box = (lx - 0.002, ly - 0.002, lx + 0.002, ly + 0.002)
        else:
            b_box = None

        hits: List[Tuple[Dict[str, Any], float]] = []
        if b_box is not None and join_geom_index:
            cands = [item for item in join_geom_index if _bbox_overlaps(b_box, item[0])]
            if b_parts and cands:
                grid = 10
                dx = (b_box[2] - b_box[0]) / grid
                dy = (b_box[3] - b_box[1]) / grid
                in_base = 0
                counts_by_idx: Dict[int, int] = {}
                for ix in range(grid):
                    cx = b_box[0] + (ix + 0.5) * dx
                    for iy in range(grid):
                        cy = b_box[1] + (iy + 0.5) * dy
                        if not any(_point_in_poly_coords(cx, cy, rings) for _, rings in b_parts):
                            continue
                        in_base += 1
                        for ci, (cbbox, cparts, _jr) in enumerate(cands):
                            if _bbox_overlaps((cx, cy, cx, cy), cbbox):
                                if not cparts or any(_point_in_poly_coords(cx, cy, rings) for _, rings in cparts):
                                    counts_by_idx[ci] = counts_by_idx.get(ci, 0) + 1
                if in_base > 0:
                    matched_frac = 0.0
                    for ci, cnt in counts_by_idx.items():
                        frac = cnt / in_base
                        matched_frac += frac
                        hits.append((cands[ci][2], round(base_ha * frac, 4)))
                    rem_frac = max(0.0, 1.0 - min(1.0, matched_frac))
                    if rem_frac > 0.01:
                        rem = dict(br)
                        for jk in j_keys:
                            rem[f"{prefix}{jk}"] = "(No overlap)"
                        rem["_geom_area_ha"] = round(base_ha * rem_frac, 4)
                        rem["area_ha"] = rem["_geom_area_ha"]
                        out_py.append(rem)
            elif cands:
                hits.append((cands[0][2], base_ha))

        if hits:
            for jr, ha_val in hits:
                piece = dict(br)
                for jk in j_keys:
                    piece[f"{prefix}{jk}"] = jr.get(jk, "")
                piece["_geom_area_ha"] = ha_val
                piece["area_ha"] = ha_val
                out_py.append(piece)
        elif not any(r.get("_feature_id") == fid and f"{prefix}{j_keys[0]}" in r for r in out_py if j_keys):
            rem = dict(br)
            for jk in j_keys:
                rem[f"{prefix}{jk}"] = "(No overlap)"
            out_py.append(rem)

    return out_py
