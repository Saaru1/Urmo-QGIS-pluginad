# -*- coding: utf-8 -*-
"""
Declarative Schema for QGIS Team Dashboard (.qdash.json & .qgz persistence).
Defines data sources (WFS, WMS, Excel, SharePoint List), joins, slicers, and BI widgets.
"""

from dataclasses import asdict, dataclass, field, fields
import json
import math
import uuid
from typing import Any, Dict, List, Optional


def _new_id(prefix: str = "item") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _filter_dataclass_kwargs(cls_type: Any, raw: Dict[str, Any]) -> Dict[str, Any]:
    allowed = {f.name for f in fields(cls_type)}
    return {k: v for k, v in raw.items() if k in allowed}


@dataclass
class JoinConfig:
    """Defines a read-only attribute join from an Excel/SharePoint table onto a spatial layer."""

    id: str = field(default_factory=lambda: _new_id("join"))
    source_table_id: str = ""  # ID of the Excel/SharePoint DataSourceConfig
    target_layer_id: str = ""  # ID or name of the spatial DataSourceConfig / QGIS layer
    source_key_field: str = ""  # Join key column in Excel/SharePoint sheet
    target_key_field: str = ""  # Join key attribute in WFS/Vector layer
    join_prefix: str = "xl_"  # Prefix added to joined fields in QGIS
    selected_fields: List[str] = field(default_factory=list)  # Empty = all fields


@dataclass
class DataSourceConfig:
    """
    Defines a portable data source for the dashboard.
    source_type:
      - 'wfs': Live OGC Web Feature Service vector layer
      - 'wms': Live OGC Web Map Service raster/tile layer
      - 'excel': Read-only Excel (.xlsx) sheet or named range (local sync or Graph API)
      - 'sharepoint_list': Live SharePoint List via Microsoft Graph API
      - 'qgis_layer': Existing layer in the current QGIS project by name
    """

    id: str = field(default_factory=lambda: _new_id("ds"))
    name: str = "New Data Source"
    source_type: str = "wfs"  # 'wfs' | 'wms' | 'excel' | 'sharepoint_list' | 'qgis_layer'

    # OGC WFS / WMS settings
    url: str = ""
    typename_or_layers: str = ""  # WFS typename (e.g. 'ns:assets') or WMS layers param
    crs: str = "EPSG:4326"
    version: str = "auto"  # e.g., '2.0.0' or '1.1.0' for WFS, '1.3.0' for WMS
    image_format: str = "image/png"
    styles: str = ""
    page_size: int = 1000
    cql_filter: str = ""
    restrict_to_bbox: bool = False
    layer_color: str = "#38bdf8"
    is_basemap: bool = False

    # Authentication ('none' | 'sso_credentials' | 'authcfg' | 'bearer' | 'basic')
    auth_mode: str = "none"
    authcfg_id: str = ""  # QGIS Auth Manager 7-char config ID (never stores raw password)
    bearer_token_env: str = ""  # Optional env var name or token placeholder for HTML export
    basic_user: str = ""

    # Excel / SharePoint settings
    portable_path: str = ""  # e.g. '${ONEDRIVE_COMMERCIAL}/GIS_Data/Assets.xlsx'
    sheet_name: str = ""  # Sheet name or named range
    ingestion_mode: str = "table_join"  # 'table_join' | 'xy_points' | 'wkt_geometry'
    x_field: str = ""
    y_field: str = ""
    wkt_field: str = ""
    primary_key_field: str = "id"

    # SharePoint Graph API settings (when fetching remotely without local OneDrive sync)
    sharepoint_site_url: str = ""
    sharepoint_drive_or_list: str = ""
    sharepoint_item_path: str = ""
    tenant_id: str = ""
    client_id: str = ""

    # Refresh interval in seconds (0 = manual only)
    auto_refresh_seconds: int = 0
    # Per-source WFS feature cap (0 = unlimited for standard layers; massive layers stay bounded)
    max_features: int = 0

    # Native QGIS provider persistence for reloading missing layers cleanly (#2)
    provider_type: str = ""  # e.g. 'ogr', 'WFS', 'wms', 'delimitedtext', 'postgres', 'gdal'
    source_uri: str = ""     # Tokenized file path or QGIS provider URI

    # Per-source live vs. static behavior (#4)
    data_state: str = "auto"  # 'auto' | 'live' | 'static'
    sharepoint_web_url: str = ""  # Optional direct SharePoint/OneDrive web URL for HTML/ASPX refresh

    def is_inherently_refreshable(self, for_browser_export: bool = False) -> bool:
        """Return True if this source points to an online/refreshable endpoint (or OneDrive sync in QGIS)."""
        stype = str(getattr(self, "source_type", "") or "").strip().lower()
        if stype in ("wfs", "wms", "sharepoint_list"):
            return True
        for cand in (
            getattr(self, "url", ""),
            getattr(self, "sharepoint_site_url", ""),
            getattr(self, "sharepoint_web_url", ""),
        ):
            s = str(cand or "").strip().lower()
            if s.startswith(("http://", "https://")):
                return True
        if not for_browser_export:
            for cand in (getattr(self, "portable_path", ""), getattr(self, "source_uri", "")):
                s = str(cand or "").strip().lower()
                if "${onedrive" in s or "onedrive" in s or "sharepoint" in s:
                    return True
        return False

    def effective_data_state(self, for_browser_export: bool = False) -> str:
        """Resolve 'live' vs 'static' considering auto-detection, explicit overrides, and export capabilities."""
        st = str(getattr(self, "data_state", "auto") or "auto").strip().lower()
        if st == "static":
            return "static"
        if st == "live":
            if for_browser_export and not self.is_inherently_refreshable(for_browser_export=True):
                return "static"
            return "live"
        return "live" if self.is_inherently_refreshable(for_browser_export=for_browser_export) else "static"

    def is_designer_pinned_static(self) -> bool:
        """Return True if a refresh-capable web/WFS source was explicitly marked static by the designer."""
        st = str(getattr(self, "data_state", "auto") or "auto").strip().lower()
        return st == "static" and self.is_inherently_refreshable(for_browser_export=True)


@dataclass
class DashboardPageConfig:
    """Represents a logical page/panel inside a Multidash / Dash-Atlas dashboard."""

    id: str = "page_1"
    title: str = "Leht 1"
    title_en: str = "Page 1"
    icon: str = "📄"
    color: str = "#0078D4"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "DashboardPageConfig":
        return cls(**_filter_dataclass_kwargs(cls, raw))


def suggest_widget_titles(
    widget_type: str,
    layer_name: str = "",
    dimension_field: str = "",
    value_field: str = "",
    aggregation: str = "sum",
    lang: str = "et",
) -> List[str]:
    """Return 3-4 concise, non-verbose suggested titles derived from widget configuration (#11)."""
    is_en = str(lang).lower().startswith("en")
    layer = str(layer_name or "").strip()
    dim = str(dimension_field or "").strip()
    val = str(value_field or "").strip()
    agg = str(aggregation or "sum").lower().strip()

    # Make readable short versions of field/layer names
    clean_layer = layer.split(":")[-1].replace("_", " ").strip()
    clean_dim = dim.replace("_", " ").strip()
    val_low = val.lower()
    if val_low in {"__calc_area_ha__", "_geom_area_ha", "pindala", "pindala_ha", "area", "area_ha", "shape_area"}:
        val_label = "Area (ha)" if is_en else "Pindala (ha)"
    elif val_low == "__calc_length_m__":
        val_label = "Length (m)" if is_en else "Pikkus (m)"
    elif val_low == "__calc_count__":
        val_label = "Feature count" if is_en else "Objektide arv"
    elif val_low in {"overlap_pria_ha", "pria_overlap_ha"}:
        val_label = "PRIA overlap (ha)" if is_en else "PRIA kattuvus (ha)"
    else:
        clean_val = val.strip("_").replace("_", " ").strip()
        if clean_val:
            val_label = clean_val.capitalize()
        else:
            val_label = ("Count" if is_en else "Arv") if agg in {"count", "distinct_count"} else ""

    agg_words_et = {
        "sum": "",
        "count": "arv",
        "distinct_count": "unikaalseid",
        "avg": "keskmine",
        "min": "miinimum",
        "max": "maksimum",
        "median": "mediaan",
    }
    agg_words_en = {
        "sum": "",
        "count": "count",
        "distinct_count": "unique",
        "avg": "avg",
        "min": "min",
        "max": "max",
        "median": "median",
    }
    agg_tag = (agg_words_en if is_en else agg_words_et).get(agg, "")

    suggestions: List[str] = []

    def _add(text: str) -> None:
        t = " ".join(str(text or "").split()).strip(" —:-")
        if t and t not in suggestions:
            suggestions.append(t[:56])

    if widget_type == "map":
        _add(f"{clean_layer} — Kaart" if not is_en and clean_layer else (f"{clean_layer} Map" if clean_layer else ("Kaartvaade" if not is_en else "Map View")))
        _add("Kaardiülevaade" if not is_en else "Spatial Overview")
        if clean_layer:
            _add(clean_layer)
    elif widget_type == "slicer":
        if clean_dim and clean_layer:
            _add(f"{clean_dim}: {clean_layer}" if len(clean_layer) < 18 else clean_dim.capitalize())
        if clean_dim:
            _add(f"{clean_dim.capitalize()} filter")
        if clean_layer:
            _add(f"{clean_layer} filter")
        _add("Filter" if is_en else "Kategooria filter")
    elif widget_type == "kpi":
        if clean_layer and val_label:
            _add(f"{clean_layer}: {val_label}" if not agg_tag else f"{clean_layer}: {val_label} ({agg_tag})")
        if val_label:
            _add(f"{val_label}" if not agg_tag else f"{agg_tag.capitalize()} {val_label}")
        if clean_layer:
            _add(f"{clean_layer} kokku" if not is_en else f"Total {clean_layer}")
    elif widget_type == "expression":
        if clean_layer:
            _add(f"{clean_layer}: avaldis" if not is_en else f"{clean_layer} Formula")
        _add("Arvutatud näitaja" if not is_en else "Calculated Metric")
        _add("Avaldisvidin" if not is_en else "Expression Card")
    elif widget_type == "table":
        if clean_layer and clean_dim:
            _add(f"{clean_layer} ({clean_dim})" if len(clean_layer) + len(clean_dim) <= 34 else f"{clean_layer} tabel")
        if clean_layer:
            _add(f"{clean_layer} tabel" if not is_en else f"{clean_layer} Table")
        if clean_dim and val_label:
            _add(f"{clean_dim} — {val_label}")
    else:
        # Chart widgets (bar, pie, line, scatter)
        if clean_dim and val_label:
            if not is_en:
                _add(f"{val_label} ({clean_dim})")
                _add(f"{clean_dim.capitalize()} — {val_label}")
            else:
                _add(f"{val_label} by {clean_dim}")
                _add(f"{clean_dim.capitalize()} — {val_label}")
        if clean_layer and val_label:
            _add(f"{clean_layer}: {val_label}")
        if clean_dim:
            _add(f"Top {clean_dim}" if is_en else f"Jaotus: {clean_dim}")
        if clean_layer:
            _add(clean_layer)

    if not suggestions:
        _add("Uus vidin" if not is_en else "New Widget")
    return suggestions[:4]


@dataclass
class SlicerConfig:
    """
    Interactive global filter widget displayed on the dashboard workspace.
    slicer_type:
      - 'category': Multi-select category chips/dropdown/searchable list
      - 'numeric_range': Min/Max numeric slider/inputs
      - 'date_range': Start/End date filter
    """

    id: str = field(default_factory=lambda: _new_id("slicer"))
    title: str = "Kategooria filter"
    title_en: str = ""
    title_custom: bool = False
    layer_name: str = ""  # Target layer or data source name
    field_name: str = ""  # Field to filter on (including joined fields like 'xl_hooldusviis')
    slicer_type: str = "category"  # 'category' | 'numeric_range' | 'date_range'
    display_mode: str = "chips"  # 'chips' | 'list'
    show_search: bool = True
    multi_select: bool = True
    cascade_filters: bool = True  # Narrow choices based on other active filters
    default_values: List[Any] = field(default_factory=list)
    connected_target_ids: List[str] = field(default_factory=list)
    page_id: str = "page_1"
    is_global: bool = False
    panes: List[Dict[str, Any]] = field(default_factory=list)
    merge_shared_fields: bool = True
    layout_x: int = 0
    layout_y: int = 0
    layout_w: int = 240
    layout_h: int = 110


def _infer_field_value_kind(records: List[Dict[str, Any]], field_name: str) -> str:
    """Infer coarse value kind ('numeric' | 'string' | 'unknown') from sampled feature records."""
    if not records or not field_name:
        return "unknown"
    samples: List[Any] = []
    for row in records:
        if not isinstance(row, dict):
            continue
        val = row.get(field_name)
        if val is None or str(val).strip() == "":
            continue
        samples.append(val)
        if len(samples) >= 40:
            break
    if not samples:
        return "unknown"
    num_hits = 0
    for val in samples:
        if isinstance(val, bool):
            continue
        try:
            num = float(str(val).strip().replace(",", "."))
            if math.isfinite(num):
                num_hits += 1
        except (TypeError, ValueError):
            pass
    return "numeric" if num_hits >= max(1, int(0.8 * len(samples))) else "string"


def group_slicer_panes(
    panes: Optional[List[Dict[str, Any]]],
    merge_shared_fields: bool = True,
    layer_records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    fallback_display_mode: str = "list",
    fallback_multi_select: bool = True,
) -> List[Dict[str, Any]]:
    """
    Normalize multi-pane slicer definitions and merge field panes that share the same
    field name and compatible value type across multiple layers (e.g. KKR kaitsealad.nimi
    + KKR hoiualad.nimi -> one unified filter covering both layers).
    """
    if not panes:
        return []
    recs_map = layer_records_by_layer if isinstance(layer_records_by_layer, dict) else {}
    grouped: List[Dict[str, Any]] = []

    for idx, raw_pane in enumerate(panes):
        if not isinstance(raw_pane, dict):
            continue
        ptype = str(raw_pane.get("pane_type") or raw_pane.get("type") or "field").strip().lower()
        if ptype == "address":
            item = dict(raw_pane)
            item["pane_type"] = "address"
            item["merged"] = False
            item["pane_indices"] = [idx]
            grouped.append(item)
            continue

        lname = str(raw_pane.get("layer_name") or "").strip()
        fname = str(raw_pane.get("field_name") or "").strip()
        disp = str(raw_pane.get("display_mode") or fallback_display_mode or "list").strip().lower()
        if disp not in ("list", "chips"):
            disp = "list" if str(fallback_display_mode).lower() == "list" else "chips"
        multi = bool(raw_pane.get("multi_select", fallback_multi_select))
        kind = _infer_field_value_kind(recs_map.get(lname) or [], fname)

        merged_into = None
        if merge_shared_fields and fname and lname:
            fn_key = fname.lower()
            for cand in grouped:
                if cand.get("pane_type") != "field":
                    continue
                if str(cand.get("field_name") or "").strip().lower() != fn_key:
                    continue
                ckind = cand.get("_kind", "unknown")
                if ckind == "unknown" or kind == "unknown" or ckind == kind:
                    merged_into = cand
                    if ckind == "unknown" and kind != "unknown":
                        cand["_kind"] = kind
                    break

        if merged_into is not None:
            if not any(s["layer_name"] == lname and s["field_name"] == fname for s in merged_into["sources"]):
                merged_into["sources"].append({"layer_name": lname, "field_name": fname})
            merged_into["pane_indices"].append(idx)
            merged_into["multi_select"] = bool(merged_into["multi_select"] or multi)
            continue

        item = dict(raw_pane)
        item["pane_type"] = "field"
        item["layer_name"] = lname
        item["field_name"] = fname
        item["display_mode"] = disp
        item["multi_select"] = multi
        item["sources"] = [{"layer_name": lname, "field_name": fname}] if lname else []
        item["pane_indices"] = [idx]
        item["_kind"] = kind
        grouped.append(item)

    result: List[Dict[str, Any]] = []
    for item in grouped:
        item.pop("_kind", None)
        sources = item.get("sources") or []
        unique_layers = list(dict.fromkeys(s["layer_name"] for s in sources if s.get("layer_name")))
        if item.get("pane_type") == "field" and len(unique_layers) >= 2:
            item["merged"] = True
            item["title"] = f"{item.get('field_name', '')} ({' + '.join(unique_layers)})"
        else:
            item["merged"] = False
        result.append(item)
    return result


@dataclass
class WidgetConfig:
    """
    Individual BI Widget on the interactive resizable dashboard workspace.
    widget_type:
      - 'map': Embedded EPSG:3301 Maa-amet WMS + WFS/Vector spatial map view
      - 'kpi': Numeric conservation summary card with unit suffix/target comparison
      - 'bar': Vertical or horizontal bar chart
      - 'line': Time-series or ordered line/area chart
      - 'pie': Pie or Donut chart
      - 'scatter': X/Y scatter plot
      - 'table': Sortable, searchable interactive data table
      - 'image': Organization logo or media picture card
      - 'expression': Interactive QGIS-style formula & UI metric card
    """

    id: str = field(default_factory=lambda: _new_id("widget"))
    title: str = "Uus vidin"
    title_en: str = ""
    title_custom: bool = False
    widget_type: str = "bar"  # 'map' | 'kpi' | 'bar' | 'line' | 'pie' | 'scatter' | 'table' | 'image' | 'expression'
    layer_name: str = ""  # Bound layer or data source name
    category_field: str = ""  # X-axis / Group-by field
    value_field: str = ""  # Y-axis / Metric field
    secondary_field: str = ""  # Optional series split or scatter Y/size field
    aggregation: str = "sum"  # 'count' | 'distinct_count' | 'sum' | 'avg' | 'min' | 'max' | 'median'

    # Grid & Freeform resizable layout coordinates
    row: int = 0
    col: int = 0
    row_span: int = 1
    col_span: int = 1
    layout_x: int = 0
    layout_y: int = 0
    layout_w: int = 440
    layout_h: int = 280
    page_id: str = "page_1"
    drill_to_page_id: str = ""
    border_style: str = "default"  # 'default' | 'subtle' | 'accent' | 'none'

    # Map widget options
    map_basemap: str = "MA-HALLKAART"  # 'MA-HALLKAART' | 'MA-KAART' | 'EESTIFOTO' | 'HYBRID'
    map_layers: List[str] = field(default_factory=list)
    map_center_lat: Optional[float] = None
    map_center_lon: Optional[float] = None
    map_zoom: Optional[int] = None
    map_home_bounds: List[float] = field(default_factory=list)  # [south, west, north, east] EPSG:4326
    map_layers_custom_order: bool = False
    map_layer_panel_collapsed: bool = True  # Layer list-menu starts minimized by default (#6)
    map_show_legend: bool = True
    map_legend_title: str = ""
    map_layer_styles: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    map_legend_layers: List[str] = field(default_factory=list)
    map_legend_collapsed: bool = False
    map_scroll_sensitivity: int = 35  # 1..100 (Precise -> Fast wheel zoom & pan inertia)
    extra_options: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.map_basemap == "MA-FOTOKAART":
            self.map_basemap = "EESTIFOTO"
        elif self.map_basemap == "cir_ngr":
            self.map_basemap = "MA-HALLKAART"

    # Image / Logo widget options
    image_source: str = ""
    image_data_uri: str = ""
    image_fit: str = "contain"  # 'contain' | 'cover'
    image_caption: str = ""
    image_link_url: str = ""
    image_transparent_bg: bool = False

    # Styling & Summary options
    color_palette: str = "emerald"  # 'single' | 'emerald' | 'forest' | 'meadow' | 'ocean' | 'amber' | 'earth' | 'rose' | 'corporate'
    primary_color: str = "#34d399"
    prefix: str = ""
    suffix: str = ""
    decimals: int = 1
    target_value: Optional[float] = None
    donut: bool = True
    horizontal: bool = False
    sort_by: str = "value_desc"  # 'value_desc' | 'value_asc' | 'category_asc'
    top_n: int = 15  # Max categories to plot before grouping 'Other'
    chart_stack_mode: str = "group"  # 'group' | 'stack' | 'percent' (when secondary_field is set)

    # Expression widget options
    expression: str = ""  # QGIS-like UI expression (e.g. "sum(\"area_ha\", \"pohityyp\" = '7230')")
    expression_subtext: str = ""  # Optional secondary expression shown under the main value
    expression_display: str = "auto"  # 'auto' | 'metric' | 'progress' | 'text'
    expression_blocks: List[Dict[str, Any]] = field(default_factory=list)  # Serialized Lego block structure
    expression_color_mode: str = "fixed"  # 'fixed' | 'target_pct' | 'rules'
    expression_threshold_ok: Optional[float] = None  # Threshold >= OK (emerald green)
    expression_threshold_warn: Optional[float] = None  # Threshold >= Warning (amber; < warn -> rose)
    expression_rules: List[Dict[str, Any]] = field(default_factory=list)  # Optional threshold color rules

    # Table & Excel-style Pivot options
    table_columns: List[str] = field(default_factory=list)
    table_mode: str = "detail"  # 'detail' | 'pivot'
    pivot_rows: List[str] = field(default_factory=list)
    pivot_cols: List[str] = field(default_factory=list)
    pivot_values: List[Dict[str, str]] = field(default_factory=list)
    table_transpose: bool = False
    table_show_totals: bool = True
    spatial_join_layer: str = ""  # Optional secondary polygon/vector layer for Spatial Pivot intersections
    field_aliases: Dict[str, str] = field(default_factory=dict)  # Optional custom column/field display labels

    # Interactivity
    enable_cross_filter: bool = True  # Clicking this chart filters map & other widgets
    ignore_self_filter: bool = True  # Keep sibling bars visible when clicking a bar
    zoom_map_on_select: bool = False  # Automatically zoom QGIS/Leaflet map to filtered features
    connected_target_ids: List[str] = field(default_factory=list)


@dataclass
class SharePointCatalogConfig:
    """Settings for the team's shared SharePoint template & HTML publishing catalog."""

    catalog_name: str = "Internal GIS Team Catalog"
    local_sync_folder: str = "${ONEDRIVE_COMMERCIAL}/GIS_Dashboards"
    site_url: str = ""
    document_library: str = "Shared Documents/GIS_Dashboards"
    tenant_id: str = ""
    client_id: str = ""


@dataclass
class WidgetConnectionConfig:
    """Directed Model Designer connection between a filter/widget and a target widget/map."""

    id: str
    source_id: str  # ID of slicer or chart/table widget (or '__map__')
    target_id: str  # ID of target widget, or '__map__'
    action: str = "filter_and_zoom"  # 'filter_and_zoom' | 'filter' | 'zoom_only'
    enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DashboardConfig:
    """Top-level portable dashboard definition (.qdash.json)."""

    id: str = field(default_factory=lambda: _new_id("dash"))
    title: str = "Minu töölaud"
    title_en: str = "My Dashboard"
    subtitle: str = "Interaktiivne kaardi- ja andmeanalüütika töölaud"
    subtitle_en: str = "Interactive map and data analytics dashboard"
    language: str = "et"  # 'et' (EST default) | 'en' (ENG)
    version: str = "1.0.0"
    author: str = ""
    theme: str = "auto"  # 'auto' | 'dark' | 'light'
    grid_columns: int = 3
    canvas_width: int = 1280
    canvas_height: int = 760
    canvas_preset: str = "laptop_1280x720"
    show_grid: bool = True
    snap_to_grid: bool = True
    grid_size: int = 20
    show_design_border: bool = True
    canvas_border_style: str = "dashed"  # 'none' | 'solid' | 'dashed' | 'dotted' | 'double' | 'shadow'
    canvas_border_color: str = "#38bdf8"
    canvas_border_width: int = 2
    canvas_border_radius: int = 10
    dissolve_adjacent_borders: bool = True
    widget_border_style: str = "default"  # 'default' | 'subtle' | 'accent' | 'none'
    export_mode: str = "compact_single"  # 'compact_single' | 'sidecar'
    export_format: str = "html"          # 'html' | 'aspx'
    export_tier: str = "full"            # 'full' | 'medium' | 'minimal'
    package_layers_in_export: bool = True
    open_after_export: bool = False
    canvas_sync_mode: str = "dashboard_only"  # 'dashboard_only' (default) | 'sync_main_canvas'
    html_data_mode: str = "cached"  # 'cached' (default session memory) | 'hybrid' | 'live'
    html_live_max_features: int = 0  # 0 = unlimited for non-massive layers
    html_auto_refresh_seconds: int = 0
    show_connection_wires: bool = True
    preview_mode: bool = False
    filter_by_map_extent: bool = False
    auto_zoom_on_filter: bool = True
    auto_home_on_filter_clear: bool = True
    wfs_bbox_loading: bool = True
    map_center_lat: float = 58.758
    map_center_lon: float = 23.825
    map_zoom: int = 7
    map_home_bounds: List[float] = field(default_factory=list)
    map_scroll_sensitivity: int = 35
    active_page_id: str = "page_1"
    default_page_id: str = ""  # Dedicated default page when exported HTML opens (empty = first page)
    pages: List[DashboardPageConfig] = field(
        default_factory=lambda: [
            DashboardPageConfig(
                id="page_1",
                title="Ülevaade",
                title_en="Overview",
                icon="📊",
                color="#0078D4",
            )
        ]
    )

    wfs_catalog_urls: List[str] = field(
        default_factory=lambda: [
            "https://gsavalik.envir.ee/geoserver/eelis/ows",
            "https://kls.pria.ee/geoserver/pria_avalik/wfs",
        ]
    )
    data_sources: List[DataSourceConfig] = field(default_factory=list)
    joins: List[JoinConfig] = field(default_factory=list)
    slicers: List[SlicerConfig] = field(default_factory=list)
    widgets: List[WidgetConfig] = field(default_factory=list)
    widget_connections: List[WidgetConnectionConfig] = field(default_factory=list)
    locked_border_seams: List[str] = field(default_factory=list)
    catalog: SharePointCatalogConfig = field(default_factory=SharePointCatalogConfig)

    def sync_widget_connections(self) -> None:
        """Keep `widget_connections` and per-slicer/widget `connected_target_ids` in sync."""
        valid_ids = {s.id for s in self.slicers} | {w.id for w in self.widgets} | {"__map__"}
        by_pair: Dict[tuple, WidgetConnectionConfig] = {}
        ordered: List[WidgetConnectionConfig] = []

        for conn in list(self.widget_connections or []):
            if not conn.source_id or not conn.target_id or conn.source_id == conn.target_id:
                continue
            if conn.source_id not in valid_ids or conn.target_id not in valid_ids:
                continue
            key = (conn.source_id, conn.target_id)
            if key not in by_pair:
                by_pair[key] = conn
                ordered.append(conn)

        # Backfill from connected_target_ids if not yet present in widget_connections
        for item in list(self.slicers) + list(self.widgets):
            for tid in getattr(item, "connected_target_ids", []) or []:
                if tid in valid_ids and tid != item.id and (item.id, tid) not in by_pair:
                    cid = f"conn_{item.id}_{tid}"
                    conn = WidgetConnectionConfig(
                        id=cid,
                        source_id=item.id,
                        target_id=tid,
                        action="filter_and_zoom",
                        enabled=True,
                    )
                    by_pair[(item.id, tid)] = conn
                    ordered.append(conn)

        self.widget_connections = ordered

        # Mirror back onto source connected_target_ids
        targets_by_src: Dict[str, List[str]] = {}
        for conn in ordered:
            if conn.enabled:
                targets_by_src.setdefault(conn.source_id, [])
                if conn.target_id not in targets_by_src[conn.source_id]:
                    targets_by_src[conn.source_id].append(conn.target_id)

        for sl in self.slicers:
            sl.connected_target_ids = list(targets_by_src.get(sl.id, []))
        for wg in self.widgets:
            wg.connected_target_ids = list(targets_by_src.get(wg.id, []))

    def get_connections_from(self, source_id: str) -> List[WidgetConnectionConfig]:
        """Return enabled outgoing connections for a source widget or slicer."""
        return [
            c
            for c in self.widget_connections
            if c.enabled and c.source_id == source_id
        ]

    def is_connected(self, source_id: str, target_id: str) -> bool:
        """
        Return True if source_id should affect target_id.
        Backward-compatible: if source_id has no explicit connections, falls back to layer matching
        handled by FilterBus/runtime.
        """
        outgoing = self.get_connections_from(source_id)
        if not outgoing:
            return False
        return any(c.target_id == target_id for c in outgoing)

    def add_or_update_connection(
        self,
        source_id: str,
        target_id: str,
        action: str = "filter_and_zoom",
        enabled: bool = True,
    ) -> Optional[WidgetConnectionConfig]:
        """Create or update a directed connection and sync target lists."""
        if not source_id or not target_id or source_id == target_id:
            return None
        for conn in self.widget_connections:
            if conn.source_id == source_id and conn.target_id == target_id:
                conn.action = action
                conn.enabled = enabled
                self.sync_widget_connections()
                return conn
        new_conn = WidgetConnectionConfig(
            id=f"conn_{source_id}_{target_id}",
            source_id=source_id,
            target_id=target_id,
            action=action,
            enabled=enabled,
        )
        self.widget_connections.append(new_conn)
        self.sync_widget_connections()
        return new_conn

    def remove_connection(self, source_id: str, target_id: str) -> bool:
        """Remove a directed connection and purge it from connected_target_ids so sync does not resurrect it."""
        before = len(self.widget_connections)
        self.widget_connections = [
            c
            for c in self.widget_connections
            if not (c.source_id == source_id and c.target_id == target_id)
        ]

        # Also strip from source's connected_target_ids BEFORE calling sync_widget_connections(),
        # otherwise the backfill loop would immediately recreate the removed connection.
        map_ids = {w.id for w in self.widgets if w.widget_type == "map"}
        ids_to_strip = {target_id}
        if target_id == "__map__":
            ids_to_strip |= map_ids
        elif target_id in map_ids:
            ids_to_strip.add("__map__")

        removed_from_src = False
        for item in list(self.slicers) + list(self.widgets):
            if item.id == source_id:
                existing_tids = list(getattr(item, "connected_target_ids", []) or [])
                filtered_tids = [tid for tid in existing_tids if tid not in ids_to_strip]
                if len(filtered_tids) != len(existing_tids):
                    item.connected_target_ids = filtered_tids
                    removed_from_src = True

        if len(self.widget_connections) != before or removed_from_src:
            self.sync_widget_connections()
            return True
        return False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a plain serializable dictionary."""
        self.sync_widget_connections()
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        """Serialize to formatted JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DashboardConfig":
        """Reconstruct a DashboardConfig from a parsed JSON dictionary."""
        if not data:
            return cls()

        data_sources = [
            DataSourceConfig(**_filter_dataclass_kwargs(DataSourceConfig, ds))
            for ds in data.get("data_sources", [])
            if isinstance(ds, dict)
        ]
        joins = [
            JoinConfig(**_filter_dataclass_kwargs(JoinConfig, jn))
            for jn in data.get("joins", [])
            if isinstance(jn, dict)
        ]
        slicers = [
            SlicerConfig(**_filter_dataclass_kwargs(SlicerConfig, sl))
            for sl in data.get("slicers", [])
            if isinstance(sl, dict)
        ]
        widgets = [
            WidgetConfig(**_filter_dataclass_kwargs(WidgetConfig, wg))
            for wg in data.get("widgets", [])
            if isinstance(wg, dict)
        ]
        widget_connections = [
            WidgetConnectionConfig(**_filter_dataclass_kwargs(WidgetConnectionConfig, wc))
            for wc in data.get("widget_connections", [])
            if isinstance(wc, dict)
        ]
        cat_raw = data.get("catalog", {})
        catalog = (
            SharePointCatalogConfig(**_filter_dataclass_kwargs(SharePointCatalogConfig, cat_raw))
            if isinstance(cat_raw, dict)
            else SharePointCatalogConfig()
        )

        pages_raw = data.get("pages")
        if isinstance(pages_raw, list) and pages_raw:
            pages = [
                DashboardPageConfig.from_dict(p)
                for p in pages_raw
                if isinstance(p, dict)
            ]
        else:
            pages = [
                DashboardPageConfig(
                    id="page_1",
                    title="Ülevaade",
                    title_en="Overview",
                    icon="📊",
                    color="#0078D4",
                )
            ]

        scalar_keys = {
            "id",
            "title",
            "title_en",
            "subtitle",
            "subtitle_en",
            "language",
            "version",
            "author",
            "theme",
            "grid_columns",
            "canvas_width",
            "canvas_height",
            "canvas_preset",
            "show_grid",
            "snap_to_grid",
            "grid_size",
            "show_design_border",
            "canvas_border_style",
            "canvas_border_color",
            "canvas_border_width",
            "canvas_border_radius",
            "dissolve_adjacent_borders",
            "widget_border_style",
            "export_mode",
            "export_format",
            "export_tier",
            "package_layers_in_export",
            "open_after_export",
            "canvas_sync_mode",
            "html_data_mode",
            "html_live_max_features",
            "html_auto_refresh_seconds",
            "show_connection_wires",
            "preview_mode",
            "filter_by_map_extent",
            "auto_zoom_on_filter",
            "auto_home_on_filter_clear",
            "wfs_bbox_loading",
            "map_center_lat",
            "map_center_lon",
            "map_zoom",
            "map_home_bounds",
            "map_scroll_sensitivity",
            "active_page_id",
            "default_page_id",
            "wfs_catalog_urls",
            "locked_border_seams",
        }
        kwargs = {k: v for k, v in data.items() if k in scalar_keys}
        cfg = cls(
            data_sources=data_sources,
            joins=joins,
            slicers=slicers,
            widgets=widgets,
            widget_connections=widget_connections,
            catalog=catalog,
            pages=pages,
            **kwargs,
        )
        if cfg.pages and not any(p.id == cfg.active_page_id for p in cfg.pages):
            cfg.active_page_id = cfg.pages[0].id
        if cfg.default_page_id and (not cfg.pages or not any(p.id == cfg.default_page_id for p in cfg.pages)):
            cfg.default_page_id = ""
        cfg.sync_widget_connections()
        return cfg

    @classmethod
    def from_json(cls, raw_json: str) -> "DashboardConfig":
        """Deserialize from a JSON string."""
        return cls.from_dict(json.loads(raw_json))
