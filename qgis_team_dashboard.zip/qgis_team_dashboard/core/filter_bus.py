# -*- coding: utf-8 -*-
"""
Reactive Cross-Filter Signal Bus for QGIS Team Dashboard.
Coordinates active filters across slicers, chart click selections, and map extent bounds,
compiling them into both QGIS subset/selection expressions and Python/pandas row predicates.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .spatial_overlap import _bbox_overlaps, geojson_bbox_wgs84, geom_intersects_geom


@dataclass
class ActiveFilter:
    """Represents a single active filter emitted by a slicer, chart, table, or address search."""

    source_id: str  # ID of the slicer or widget that emitted the filter
    layer_name: str  # Target layer / data source name (or '__spatial__' for cross-layer spatial geom)
    field_name: str  # Attribute name
    filter_type: str = "category"  # 'category' | 'numeric_range' | 'date_range' | 'spatial_geom' | 'spatial_bbox'
    values: List[Any] = field(default_factory=list)  # Selected categories
    min_value: Optional[Any] = None  # Numeric or ISO date lower bound
    max_value: Optional[Any] = None  # Numeric or ISO date upper bound
    bbox: Optional[Tuple[float, float, float, float]] = None  # (xmin, ymin, xmax, ymax) EPSG:4326
    geometry: Optional[Dict[str, Any]] = None  # GeoJSON geometry EPSG:4326
    display_label: str = ""  # Human-readable chip text for active filters banner & badges
    page_id: str = "page_1"
    is_global: bool = False  # Atlas-wide filter across all dashboard pages
    layer_fields: List[Dict[str, str]] = field(default_factory=list)  # Optional merged multi-layer sources [{layer_name, field_name}]

    def target_sources(self) -> List[Tuple[str, str]]:
        """Return resolved `(layer_name, field_name)` source pairs covered by this filter."""
        if self.layer_fields:
            out: List[Tuple[str, str]] = []
            for item in self.layer_fields:
                if not isinstance(item, dict):
                    continue
                ln = str(item.get("layer_name") or "").strip()
                fn = str(item.get("field_name") or self.field_name or "").strip()
                if ln:
                    out.append((ln, fn))
            if out:
                return out
        return [(self.layer_name, self.field_name)]


@dataclass
class SpatialExtentFilter:
    """Bounding box filter from the QGIS Map Canvas or Leaflet viewport."""

    xmin: float
    ymin: float
    xmax: float
    ymax: float
    crs: str = "EPSG:4326"


class FilterBus:
    """
    Central reactive filter state manager and signal dispatcher.
    Works both inside QGIS (bridging to QgsMapCanvas & QgsVectorLayer) and in headless tests.
    """

    def __init__(self) -> None:
        self._filters: Dict[str, ActiveFilter] = {}
        self._extent_filter: Optional[SpatialExtentFilter] = None
        self._extent_enabled: bool = False
        self._connections: List[Any] = []
        self._cross_layer_resolver: Optional[
            Callable[[ActiveFilter, str, List[Dict[str, Any]]], Optional[set]]
        ] = None
        self._cross_layer_result_resolver: Optional[
            Callable[[ActiveFilter, str, List[Dict[str, Any]]], Optional[Dict[str, Any]]]
        ] = None
        self._listeners: List[Callable[[], None]] = []

    def set_connections(self, connections: Optional[List[Any]]) -> None:
        """Store directed widget connections so FilterBus can route filters accurately."""
        self._connections = list(connections or [])

    def set_cross_layer_resolver(
        self,
        resolver: Optional[Callable[[ActiveFilter, str, List[Dict[str, Any]]], Optional[set]]],
    ) -> None:
        """Register a spatial cross-layer resolver returning matching _feature_id values."""
        self._cross_layer_resolver = resolver

    def set_cross_layer_result_resolver(
        self,
        resolver: Optional[Callable[[ActiveFilter, str, List[Dict[str, Any]]], Optional[Dict[str, Any]]]],
    ) -> None:
        """Register a spatial cross-layer resolver returning {allowed, clipped_areas, unavailable}."""
        self._cross_layer_result_resolver = resolver

    def subscribe(self, callback: Callable[[], None]) -> None:
        """Register a listener invoked whenever any filter state changes."""
        if callback not in self._listeners:
            self._listeners.append(callback)

    def unsubscribe(self, callback: Callable[[], None]) -> None:
        """Remove a registered listener."""
        if callback in self._listeners:
            self._listeners.remove(callback)

    def _emit(self) -> None:
        for listener in list(self._listeners):
            try:
                listener()
            except Exception:
                pass

    def set_filter(self, active_filter: ActiveFilter) -> None:
        """Add or update an active filter from a slicer, chart click, or address search."""
        if (
            active_filter.filter_type == "category"
            and not active_filter.values
        ) or (
            active_filter.filter_type in ("numeric_range", "date_range")
            and active_filter.min_value is None
            and active_filter.max_value is None
        ) or (
            active_filter.filter_type in ("spatial_geom", "spatial_bbox")
            and active_filter.bbox is None
            and active_filter.geometry is None
        ):
            self.clear_filter(active_filter.source_id)
            return

        self._filters.pop(active_filter.source_id, None)
        self._filters[active_filter.source_id] = active_filter
        self._emit()

    def set_range_filter(
        self,
        source_id: str,
        layer_name: str,
        field_name: str,
        filter_type: str = "numeric_range",
        min_value: Optional[Any] = None,
        max_value: Optional[Any] = None,
        page_id: str = "page_1",
        is_global: bool = False,
        display_label: str = "",
    ) -> None:
        """Set or clear a numeric_range or date_range ActiveFilter."""
        self.set_filter(
            ActiveFilter(
                source_id=source_id,
                layer_name=layer_name,
                field_name=field_name,
                filter_type=filter_type,
                min_value=min_value,
                max_value=max_value,
                page_id=page_id,
                is_global=is_global,
                display_label=display_label,
            )
        )

    def toggle_category_value(
        self,
        source_id: str,
        layer_name: str,
        field_name: str,
        value: Any,
        multi: bool = False,
        page_id: str = "page_1",
        is_global: bool = False,
        layer_fields: Optional[List[Dict[str, str]]] = None,
    ) -> None:
        """Toggle a single category value from a chart bar/slice click or slicer selection."""
        existing = self._filters.get(source_id)
        norm_lf = [dict(x) for x in (layer_fields or []) if isinstance(x, dict)]
        if existing and existing.field_name == field_name:
            current_vals = list(existing.values)
            if value in current_vals:
                current_vals.remove(value)
            else:
                if multi:
                    current_vals.append(value)
                else:
                    current_vals = [value]
            if not current_vals:
                self.clear_filter(source_id)
                return
            existing.values = current_vals
            existing.page_id = page_id
            existing.is_global = is_global
            if norm_lf:
                existing.layer_fields = norm_lf
            self._filters.pop(source_id, None)
            self._filters[source_id] = existing
            self._emit()
        else:
            self.set_filter(
                ActiveFilter(
                    source_id=source_id,
                    layer_name=layer_name,
                    field_name=field_name,
                    filter_type="category",
                    values=[value],
                    page_id=page_id,
                    is_global=is_global,
                    layer_fields=norm_lf,
                )
            )

    def clear_filter(self, source_id: str) -> None:
        """Remove a specific filter by its emitter ID."""
        if source_id in self._filters:
            del self._filters[source_id]
            self._emit()

    def clear_all(self) -> None:
        """Reset all attribute and spatial extent filters."""
        changed = bool(self._filters) or (self._extent_filter is not None)
        self._filters.clear()
        self._extent_filter = None
        if changed:
            self._emit()

    def set_spatial_extent(
        self, extent: Optional[SpatialExtentFilter], enabled: Optional[bool] = None
    ) -> None:
        """Update the active map canvas bounding box filter."""
        if enabled is not None:
            self._extent_enabled = enabled
        self._extent_filter = extent
        if self._extent_enabled:
            self._emit()

    def set_extent_enabled(self, enabled: bool) -> None:
        """Enable or disable filtering widgets by map canvas extent."""
        if self._extent_enabled != enabled:
            self._extent_enabled = enabled
            self._emit()

    @property
    def extent_enabled(self) -> bool:
        return self._extent_enabled

    @property
    def spatial_extent(self) -> Optional[SpatialExtentFilter]:
        return self._extent_filter if self._extent_enabled else None

    @staticmethod
    def _norm_conn_id(source_id: Optional[str]) -> str:
        sid = str(source_id or "")
        return sid[4:] if sid.startswith("tbl_") else sid

    def _filter_applies(
        self,
        flt: ActiveFilter,
        layer_name: Optional[str] = None,
        target_widget_id: Optional[str] = None,
        target_page_id: Optional[str] = None,
        connections: Optional[List[Any]] = None,
    ) -> bool:
        """
        Determine whether an ActiveFilter applies to a target widget/layer.
        When `source_id` has explicit Model Designer outgoing connections, only connected
        targets with a filtering action (`filter` or `filter_and_zoom`) receive the filter.
        When `source_id` has no outgoing connections, falls back to same-layer cross-filtering
        (respecting Multidash page boundaries unless `flt.is_global` is True).
        """
        conns = connections if connections is not None else self._connections
        flt_norm = self._norm_conn_id(flt.source_id)
        outgoing = []
        for c in conns or []:
            if isinstance(c, dict):
                enabled = c.get("enabled", True)
                src = c.get("source_id")
                tgt = c.get("target_id")
                act = c.get("action", "filter_and_zoom")
            else:
                enabled = getattr(c, "enabled", True)
                src = getattr(c, "source_id", None)
                tgt = getattr(c, "target_id", None)
                act = getattr(c, "action", "filter_and_zoom")
            if enabled and tgt and (src == flt.source_id or self._norm_conn_id(src) == flt_norm):
                outgoing.append((tgt, act))

        if outgoing and target_widget_id:
            return any(tgt == target_widget_id and act != "zoom_only" for tgt, act in outgoing)

        src_layers = {ln for ln, _ in flt.target_sources() if ln}
        if outgoing and not target_widget_id:
            if (
                layer_name
                and src_layers
                and "__spatial__" not in src_layers
                and layer_name not in src_layers
            ):
                return False
            return True

        # Respect Multidash page isolation when no explicit cross-page connection exists
        if (
            target_page_id
            and not getattr(flt, "is_global", False)
            and getattr(flt, "page_id", "")
            and flt.page_id != target_page_id
            and "__spatial__" not in src_layers
        ):
            return False

        if (
            layer_name
            and src_layers
            and "__spatial__" not in src_layers
            and layer_name not in src_layers
        ):
            return False
        return True

    def active_filters(
        self,
        layer_name: Optional[str] = None,
        exclude_source_id: Optional[str] = None,
        target_widget_id: Optional[str] = None,
        target_page_id: Optional[str] = None,
        connections: Optional[List[Any]] = None,
    ) -> List[ActiveFilter]:
        """Return active filters, optionally scoped to a layer/target widget and excluding a widget's own ID."""
        result: List[ActiveFilter] = []
        ex_norm = self._norm_conn_id(exclude_source_id) if exclude_source_id else ""
        for src_id, flt in self._filters.items():
            if exclude_source_id and (src_id == exclude_source_id or self._norm_conn_id(src_id) == ex_norm):
                continue
            if not self._filter_applies(
                flt,
                layer_name=layer_name,
                target_widget_id=target_widget_id,
                target_page_id=target_page_id,
                connections=connections,
            ):
                continue
            result.append(flt)
        return result

    def get_selected_values(self, source_id: str) -> List[Any]:
        """Return currently selected category values for a given widget or slicer ID."""
        flt = self._filters.get(source_id)
        return list(flt.values) if flt else []

    @staticmethod
    def _escape_qgis_ident(field_name: str) -> str:
        escaped = field_name.replace('"', '""')
        return f'"{escaped}"'

    @staticmethod
    def _escape_qgis_literal(val: Any) -> str:
        if val is None:
            return "NULL"
        if isinstance(val, bool):
            return "TRUE" if val else "FALSE"
        if isinstance(val, (int, float)):
            return str(val)
        text = str(val).replace("'", "''")
        return f"'{text}'"

    def build_qgis_expression(
        self,
        layer_name: Optional[str] = None,
        exclude_source_id: Optional[str] = None,
        target_widget_id: Optional[str] = None,
        connections: Optional[List[Any]] = None,
    ) -> str:
        """
        Compile active attribute filters into a valid QGIS Expression string
        suitable for QgsVectorLayer.selectByExpression() or QgsFeatureRequest.
        """
        clauses: List[str] = []
        for flt in self.active_filters(
            layer_name=layer_name,
            exclude_source_id=exclude_source_id,
            target_widget_id=target_widget_id,
            connections=connections,
        ):
            eff_field = dict(flt.target_sources()).get(layer_name, flt.field_name) if layer_name else flt.field_name
            ident = self._escape_qgis_ident(eff_field)
            if flt.filter_type == "category" and flt.values:
                non_null = [v for v in flt.values if v is not None and str(v) != ""]
                has_null = any(v is None or str(v) == "" for v in flt.values)
                parts: List[str] = []
                if non_null:
                    literals = ", ".join(self._escape_qgis_literal(v) for v in non_null)
                    parts.append(f"{ident} IN ({literals})")
                if has_null:
                    parts.append(f"{ident} IS NULL")
                if parts:
                    clauses.append("(" + " OR ".join(parts) + ")")

            elif flt.filter_type in ("numeric_range", "date_range"):
                range_parts: List[str] = []
                if flt.min_value is not None and str(flt.min_value) != "":
                    lit_min = self._escape_qgis_literal(flt.min_value)
                    range_parts.append(f"{ident} >= {lit_min}")
                if flt.max_value is not None and str(flt.max_value) != "":
                    lit_max = self._escape_qgis_literal(flt.max_value)
                    range_parts.append(f"{ident} <= {lit_max}")
                if range_parts:
                    clauses.append("(" + " AND ".join(range_parts) + ")")

        return " AND ".join(clauses)

    @staticmethod
    def format_filter_badge(flt: ActiveFilter) -> str:
        """Return a concise human-readable label for banners and widget filter badges (#14)."""
        if getattr(flt, "display_label", ""):
            return str(flt.display_label)
        if flt.filter_type == "spatial_geom":
            return f"📍 {flt.field_name or 'Asukoht'}"
        if flt.filter_type == "spatial_bbox":
            return "🗺 Kaardiulatus"
        if flt.filter_type == "category":
            vals = [str(v) for v in (flt.values or [])]
            if len(vals) <= 2:
                return f"{flt.field_name}: {', '.join(vals)}"
            return f"{flt.field_name}: {vals[0]} (+{len(vals) - 1})"
        if flt.filter_type in ("numeric_range", "date_range"):
            lo = "" if flt.min_value is None else str(flt.min_value)
            hi = "" if flt.max_value is None else str(flt.max_value)
            return f"{flt.field_name}: {lo}..{hi}"
        return str(flt.field_name or flt.source_id)

    def get_active_filters_for_widget(
        self,
        widget_id: str,
        layer_name: Optional[str] = None,
        exclude_source_id: Optional[str] = None,
        page_id: Optional[str] = None,
        connections: Optional[List[Any]] = None,
    ) -> List[ActiveFilter]:
        """Return all active filters currently affecting a specific widget (#14)."""
        return self.active_filters(
            layer_name=layer_name,
            exclude_source_id=exclude_source_id or widget_id,
            target_widget_id=widget_id,
            target_page_id=page_id,
            connections=connections,
        )

    def describe_active_filters(self) -> List[Dict[str, Any]]:
        """Return structured descriptors of every active filter for UI banners (#14)."""
        out: List[Dict[str, Any]] = []
        for src_id, flt in self._filters.items():
            out.append(
                {
                    "source_id": src_id,
                    "layer_name": flt.layer_name,
                    "field_name": flt.field_name,
                    "filter_type": flt.filter_type,
                    "label": self.format_filter_badge(flt),
                    "is_global": bool(getattr(flt, "is_global", False)),
                    "page_id": str(getattr(flt, "page_id", "page_1") or "page_1"),
                }
            )
        return out

    @staticmethod
    def _row_matches_filter(row: Dict[str, Any], flt: ActiveFilter, layer_name: Optional[str] = None) -> bool:
        if flt.filter_type in ("spatial_geom", "spatial_bbox"):
            flt_bbox = getattr(flt, "bbox", None)
            if flt_bbox is None and isinstance(getattr(flt, "geometry", None), dict):
                flt_bbox = geojson_bbox_wgs84(flt.geometry)

            # Determine row geometry / bbox / centroid
            row_geom = row.get("__geom__")
            row_bbox = row.get("_bbox")
            if isinstance(row_bbox, (list, tuple)) and len(row_bbox) == 4:
                rb = (float(row_bbox[0]), float(row_bbox[1]), float(row_bbox[2]), float(row_bbox[3]))
            elif isinstance(row_geom, dict):
                rb = geojson_bbox_wgs84(row_geom)
            else:
                rx = row.get("_lon", row.get("_x"))
                ry = row.get("_lat", row.get("_y"))
                if rx is not None and ry is not None:
                    try:
                        fx, fy = float(rx), float(ry)
                        rb = (fx, fy, fx, fy)
                    except (TypeError, ValueError):
                        rb = None
                else:
                    rb = None

            if flt_bbox is not None and rb is not None:
                if not _bbox_overlaps(tuple(flt_bbox), rb):
                    return False

            if flt.filter_type == "spatial_geom" and isinstance(flt.geometry, dict):
                if isinstance(row_geom, dict):
                    return geom_intersects_geom(flt.geometry, row_geom)
                if rb is not None:
                    # Fallback to row bbox rectangle vs spatial polygon when full row geom isn't loaded
                    rx0, ry0, rx1, ry1 = rb
                    rect_geom = {
                        "type": "Polygon",
                        "coordinates": [[[rx0, ry0], [rx1, ry0], [rx1, ry1], [rx0, ry1], [rx0, ry0]]],
                    }
                    return geom_intersects_geom(flt.geometry, rect_geom)
                return False

            return flt_bbox is None or rb is not None

        eff_field = dict(flt.target_sources()).get(layer_name, flt.field_name) if (layer_name and hasattr(flt, "target_sources")) else flt.field_name
        val = row.get(eff_field)
        if flt.filter_type == "category" and flt.values:
            str_values = {str(v) for v in flt.values}
            return str(val) in str_values or val in flt.values
        if flt.filter_type == "numeric_range":
            try:
                num_val = float(val) if val is not None else None
            except (ValueError, TypeError):
                num_val = None
            if num_val is None:
                return False
            if flt.min_value is not None and num_val < float(flt.min_value):
                return False
            if flt.max_value is not None and num_val > float(flt.max_value):
                return False
            return True
        if flt.filter_type == "date_range":
            s_val = str(val or "").strip()
            if not s_val:
                return False
            s_min = str(flt.min_value).strip() if flt.min_value is not None else ""
            s_max = str(flt.max_value).strip() if flt.max_value is not None else ""
            # Normalize ISO timestamps ("2025-05-10T12:00:00Z") to "YYYY-MM-DD" when bounds are date-only
            cmp_val = s_val[:10] if (len(s_val) > 10 and (len(s_min) == 10 or len(s_max) == 10)) else s_val
            if s_min and cmp_val < s_min:
                return False
            if s_max and cmp_val > s_max:
                return False
            return True
        return True

    def filter_records(
        self,
        records: List[Dict[str, Any]],
        layer_name: Optional[str] = None,
        exclude_source_id: Optional[str] = None,
        target_widget_id: Optional[str] = None,
        target_page_id: Optional[str] = None,
        connections: Optional[List[Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Filter a list of feature/row dictionaries according to active attribute
        and spatial extent filters. Used by the Aggregator for KPIs, Charts, and Tables.
        """
        filters = self.active_filters(
            layer_name=layer_name,
            exclude_source_id=exclude_source_id,
            target_widget_id=target_widget_id,
            target_page_id=target_page_id,
            connections=connections,
        )
        extent = self.spatial_extent

        if not filters and not extent:
            return records

        direct_filters: List[ActiveFilter] = []
        cross_allowed_sets: List[set] = []
        cross_clipped_maps: List[Dict[str, float]] = []
        spatial_unavailable = False
        result_resolver = getattr(self, "_cross_layer_result_resolver", None)
        resolver = getattr(self, "_cross_layer_resolver", None)
        for flt in filters:
            src_layers = {ln for ln, _ in flt.target_sources() if ln} if hasattr(flt, "target_sources") else ({flt.layer_name} if flt.layer_name else set())
            if (
                src_layers
                and "__spatial__" not in src_layers
                and layer_name
                and layer_name not in src_layers
                and (result_resolver is not None or resolver is not None)
            ):
                if result_resolver is not None:
                    try:
                        res = result_resolver(flt, layer_name, records)
                    except Exception:
                        res = None
                    if isinstance(res, dict):
                        if res.get("unavailable"):
                            spatial_unavailable = True
                            continue
                        allowed = res.get("allowed")
                        if allowed is not None:
                            cross_allowed_sets.append({str(x) for x in allowed})
                            c_areas = res.get("clipped_areas")
                            if isinstance(c_areas, dict) and c_areas:
                                cross_clipped_maps.append(c_areas)
                            continue
                if resolver is not None:
                    try:
                        allowed = resolver(flt, layer_name, records)
                    except Exception:
                        allowed = None
                    if allowed is not None:
                        cross_allowed_sets.append({str(x) for x in allowed})
                        continue
            direct_filters.append(flt)

        if spatial_unavailable:
            return []

        filtered: List[Dict[str, Any]] = []
        for row in records:
            if extent is not None:
                rx = row.get("_lon", row.get("_x"))
                ry = row.get("_lat", row.get("_y"))
                if rx is not None and ry is not None:
                    try:
                        fx, fy = float(rx), float(ry)
                        if not (extent.xmin <= fx <= extent.xmax and extent.ymin <= fy <= extent.ymax):
                            continue
                    except (ValueError, TypeError):
                        pass

            if cross_allowed_sets:
                row_fid = row.get("_feature_id")
                row_fid_str = str(row_fid) if row_fid is not None else None
                if row_fid_str is None or any(row_fid_str not in aset for aset in cross_allowed_sets):
                    continue

            matched = True
            for flt in direct_filters:
                if not self._row_matches_filter(row, flt, layer_name=layer_name):
                    matched = False
                    break

            if matched:
                filtered.append(row)

        if cross_clipped_maps and target_widget_id != "__map__":
            out_clipped: List[Dict[str, Any]] = []
            for row in filtered:
                fid_str = str(row.get("_feature_id")) if row.get("_feature_id") is not None else ""
                try:
                    raw_ha = row.get("_geom_area_ha")
                    if raw_ha is None:
                        raw_ha = row.get("area_ha")
                    orig_ha = float(raw_ha) if raw_ha is not None else 0.0
                except (TypeError, ValueError):
                    orig_ha = 0.0
                clip_ha = orig_ha
                has_clip = False
                for cmap in cross_clipped_maps:
                    if fid_str and fid_str in cmap:
                        val_ha = float(cmap[fid_str])
                        clip_ha = min(clip_ha, val_ha) if (has_clip or orig_ha > 0.0) else val_ha
                        has_clip = True
                if has_clip and clip_ha != orig_ha:
                    copied = dict(row)
                    copied["_geom_area_ha"] = clip_ha
                    copied["area_ha"] = clip_ha
                    out_clipped.append(copied)
                else:
                    out_clipped.append(row)
            return out_clipped

        return filtered
