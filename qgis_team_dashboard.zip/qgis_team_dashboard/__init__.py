# -*- coding: utf-8 -*-
"""
QGIS Team Dashboard Plugin
Interactive BI Dashboards with SharePoint, Read-Only Excel Joins,
Live WFS/WMS Catalog, Two-Way Map Cross-Filtering, and Standalone HTML Export.
"""


def classFactory(iface):
    """Load QgisTeamDashboardPlugin class from file plugin.py.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .plugin import QgisTeamDashboardPlugin

    return QgisTeamDashboardPlugin(iface)
