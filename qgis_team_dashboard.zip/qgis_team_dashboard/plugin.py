# -*- coding: utf-8 -*-
"""
Main QGIS Plugin Controller for QGIS Team Dashboard.
Registers toolbar buttons, menu actions, project read/write hooks,
and the dockable Dashboard Studio.
"""

import os
from typing import Any, List, Optional

try:
    from qgis.core import QgsProject
except ImportError:
    QgsProject = None  # type: ignore

from .core.i18n import tr
from .core.persistence import DashboardPersistenceManager
from .core.schema import DashboardConfig
from .ui.dashboard_dock import DashboardDockWidget
from .ui.qt_compat import QAction, QtCore, QtGui, qt_enum

Qt = QtCore.Qt
QIcon = QtGui.QIcon


class QgisTeamDashboardPlugin:
    """QGIS Desktop Plugin entry class for QGIS Team Dashboard."""

    def __init__(self, iface: Any) -> None:
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions: List[Any] = []
        self.menu_name = f"&{tr('plugin_title', 'et')}"
        self.dock: Optional[DashboardDockWidget] = None

    def initGui(self) -> None:
        """Create menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = os.path.join(self.plugin_dir, "icon.svg")
        icon = QIcon(icon_path) if QIcon and os.path.exists(icon_path) else QIcon()

        self.act_toggle_dock = QAction(
            icon, tr("menu_open_studio", "et"), self.iface.mainWindow()
        )
        self.act_toggle_dock.triggered.connect(self.toggle_dashboard_dock)
        self.iface.addToolBarIcon(self.act_toggle_dock)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_toggle_dock)
        self.actions.append(self.act_toggle_dock)

        self.act_catalog = QAction(
            tr("menu_catalog", "et"), self.iface.mainWindow()
        )
        self.act_catalog.triggered.connect(self.open_catalog_directly)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_catalog)
        self.actions.append(self.act_catalog)

        self.act_export = QAction(
            tr("menu_export_html", "et"), self.iface.mainWindow()
        )
        self.act_export.triggered.connect(self.export_html_directly)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_export)
        self.actions.append(self.act_export)

        self.act_meadow_preset = QAction(
            tr("menu_load_meadow", "et"), self.iface.mainWindow()
        )
        self.act_meadow_preset.triggered.connect(self.load_meadow_preset)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_meadow_preset)
        self.actions.append(self.act_meadow_preset)

        self.act_soomaa_preset = QAction(
            tr("menu_load_soomaa", "et"), self.iface.mainWindow()
        )
        self.act_soomaa_preset.triggered.connect(self.load_soomaa_preset)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_soomaa_preset)
        self.actions.append(self.act_soomaa_preset)

        self.act_alampedja_preset = QAction(
            tr("menu_load_alampedja", "et"), self.iface.mainWindow()
        )
        self.act_alampedja_preset.triggered.connect(self.load_alampedja_preset)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_alampedja_preset)
        self.actions.append(self.act_alampedja_preset)

        self.act_overlap_preset = QAction(
            tr("menu_load_overlap", "et"), self.iface.mainWindow()
        )
        self.act_overlap_preset.triggered.connect(self.load_overlap_preset)
        self.iface.addPluginToWebMenu(self.menu_name, self.act_overlap_preset)
        self.actions.append(self.act_overlap_preset)

        if QgsProject is not None:
            QgsProject.instance().readProject.connect(self._on_project_read)

    def unload(self) -> None:
        """Remove plugin menu items, toolbar icons, and dock widget from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginWebMenu(self.menu_name, action)
            self.iface.removeToolBarIcon(action)
        self.actions.clear()

        if QgsProject is not None:
            try:
                QgsProject.instance().readProject.disconnect(self._on_project_read)
            except Exception:
                pass

        if self.dock is not None:
            fp = getattr(self.dock, "floating_palette", None)
            if fp is not None and hasattr(fp, "deleteLater"):
                try:
                    fp.hide()
                    fp.deleteLater()
                except Exception:
                    pass
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

    def _ensure_dock(self) -> DashboardDockWidget:
        if self.dock is None:
            self.dock = DashboardDockWidget(
                iface=self.iface, parent=self.iface.mainWindow()
            )
            self.iface.addDockWidget(
                qt_enum(Qt, "DockWidgetArea", "RightDockWidgetArea"), self.dock
            )
            if hasattr(self.dock, "fit_initial_laptop_geometry"):
                self.dock.fit_initial_laptop_geometry(self.iface.mainWindow())
            saved_cfg = DashboardPersistenceManager.load_from_qgis_project()
            self.dock.present_home_view(pending_project_cfg=saved_cfg)
            self.dock.refresh_catalog_views()
        return self.dock

    def toggle_dashboard_dock(self) -> None:
        was_created = self.dock is None
        dock = self._ensure_dock()
        if was_created:
            dock.show()
            dock.raise_()
        else:
            is_min = bool(dock.isMinimized()) if hasattr(dock, "isMinimized") else False
            if is_min:
                if hasattr(dock, "showNormal"):
                    dock.showNormal()
                dock.show()
                dock.raise_()
                if hasattr(dock, "activateWindow"):
                    dock.activateWindow()
                return
            if not dock.isVisible():
                if getattr(dock, "_dock_shaded", False) and hasattr(dock, "_toggle_dock_shaded"):
                    dock._toggle_dock_shaded(False)
                dock.show()
                dock.raise_()
                if hasattr(dock, "activateWindow"):
                    dock.activateWindow()
            else:
                dock.setVisible(False)

    def open_catalog_directly(self) -> None:
        dock = self._ensure_dock()
        dock.show()
        dock.open_sharepoint_catalog()

    def export_html_directly(self) -> None:
        dock = self._ensure_dock()
        dock.export_html_dashboard()

    def load_meadow_preset(self) -> None:
        self._load_bundled_preset("meadow_conservation_test.qdash.json")

    def load_soomaa_preset(self) -> None:
        self._load_bundled_preset("soomaa_workplan_example.qdash.json")

    def load_alampedja_preset(self) -> None:
        self._load_bundled_preset("alam_pedja_example.qdash.json")

    def load_overlap_preset(self) -> None:
        self._load_bundled_preset("natura_pria_overlap_example.qdash.json")

    def _load_bundled_preset(self, filename: str) -> None:
        preset_path = os.path.join(self.plugin_dir, "presets", filename)
        if os.path.isfile(preset_path):
            cfg = DashboardPersistenceManager.load_from_template_file(preset_path)
            dock = self._ensure_dock()
            dock.show()
            dock.raise_()
            dock.load_dashboard_config(cfg)

    def _on_project_read(self, *_args: Any) -> None:
        saved_cfg = DashboardPersistenceManager.load_from_qgis_project()
        if saved_cfg is not None and self.dock is not None:
            self.dock.present_home_view(pending_project_cfg=saved_cfg)
            self.dock.show()
            self.dock.raise_()
