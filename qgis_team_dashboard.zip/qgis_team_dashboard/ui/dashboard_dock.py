# -*- coding: utf-8 -*-
"""
Main Dockable BI Dashboard Studio (QDockWidget) for QGIS 4.2+ (Qt6) and QGIS 3.44+ (Qt5).
Features:
- Persistent Data Catalog sidebar (~/.qgis_team_dashboard/ogc_catalog_cache.json) with
  non-blocking background GetCapabilities sync + animated loading indicator.
- Zero eager WFS feature loading on startup (lazy hydration only for active widgets).
- Freeform Workspace with drag-and-drop from Catalog and directly draggable/resizable
  ResizableCardFrame containers for Map Views, Summary Cards, Charts, Tables, and Filters.
"""

import http.server
import json
import os
import shutil
import socketserver
import tempfile
import threading
import time
import urllib.parse
import webbrowser
from typing import Any, Callable, Dict, List, Optional, Tuple

from .qt_compat import (
    QtCore,
    QtGui,
    QtWidgets,
    exec_dialog,
    exec_menu,
    mouse_global_pos,
    qt_enum,
)

Qt = QtCore.Qt
QBrush = QtGui.QBrush
QColor = QtGui.QColor
QPainter = QtGui.QPainter
QPainterPath = getattr(QtGui, "QPainterPath", None)
QPen = QtGui.QPen
QPointF = getattr(QtCore, "QPointF", QtCore.QPoint)
QPolygonF = getattr(QtGui, "QPolygonF", list)
QAction = getattr(QtWidgets, "QAction", None) or getattr(QtGui, "QAction", None)
QComboBox = QtWidgets.QComboBox
QDockWidget = QtWidgets.QDockWidget
QFileDialog = QtWidgets.QFileDialog
QFrame = QtWidgets.QFrame
QGraphicsDropShadowEffect = getattr(QtWidgets, "QGraphicsDropShadowEffect", None)
QHBoxLayout = QtWidgets.QHBoxLayout
QHeaderView = getattr(QtWidgets, "QHeaderView", None)
QInputDialog = getattr(QtWidgets, "QInputDialog", None)
QLabel = QtWidgets.QLabel
QLineEdit = QtWidgets.QLineEdit
QListWidget = QtWidgets.QListWidget
QListWidgetItem = QtWidgets.QListWidgetItem
QMenu = QtWidgets.QMenu
QMessageBox = QtWidgets.QMessageBox
QProgressBar = QtWidgets.QProgressBar
QPushButton = QtWidgets.QPushButton
QScrollArea = QtWidgets.QScrollArea
QSpinBox = QtWidgets.QSpinBox
QSplitter = QtWidgets.QSplitter
QTabWidget = QtWidgets.QTabWidget
QTreeWidgetItem = QtWidgets.QTreeWidgetItem
QVBoxLayout = QtWidgets.QVBoxLayout
QWidget = QtWidgets.QWidget
QApplication = getattr(QtWidgets, "QApplication", None)
QSizePolicy = getattr(QtWidgets, "QSizePolicy", None)
QGuiApplication = getattr(QtGui, "QGuiApplication", None)

pyqtSignal = getattr(QtCore, "pyqtSignal", getattr(QtCore, "Signal", None))


def _safe_qt_enum(owner: Any, group_name: str, member_name: str, default: Any = 0) -> Any:
    """Resolve a Qt enum cleanly without raising if omitted from headless test mocks."""
    try:
        group = getattr(owner, group_name, None)
        if group is not None and hasattr(group, member_name):
            return getattr(group, member_name)
        if owner is not None and hasattr(owner, member_name):
            return getattr(owner, member_name)
    except Exception:
        pass
    return default


class _SimplePageStack(QWidget):
    """Minimal fallback page switcher when QStackedWidget is absent in a mock toolkit."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._pages: List[QWidget] = []
        self._idx: int = 0
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(0)

    def addWidget(self, w: QWidget) -> int:
        self._pages.append(w)
        self._layout.addWidget(w)
        w.setVisible(len(self._pages) - 1 == self._idx)
        return len(self._pages) - 1

    def setCurrentIndex(self, idx: int) -> None:
        self._idx = max(0, int(idx))
        for i, w in enumerate(self._pages):
            w.setVisible(i == self._idx)

    def currentIndex(self) -> int:
        return self._idx


QStackedWidget = getattr(QtWidgets, "QStackedWidget", None) or _SimplePageStack


def _resolve_web_view_class() -> Any:
    """Return QWebEngineView / QWebView class if JS-capable WebView is installed in QGIS."""
    candidates = (
        ("qgis.PyQt.QtWebEngineWidgets", "QWebEngineView"),
        ("PyQt6.QtWebEngineWidgets", "QWebEngineView"),
        ("PyQt5.QtWebEngineWidgets", "QWebEngineView"),
        ("qgis.PyQt.QtWebKitWidgets", "QWebView"),
        ("PyQt5.QtWebKitWidgets", "QWebView"),
    )
    for mod_name, attr_name in candidates:
        try:
            mod = __import__(mod_name, fromlist=[attr_name])
            cls = getattr(mod, attr_name, None)
            if cls is not None:
                return cls
        except Exception:
            continue
    return None


class _ThreadingPreviewServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class _PreviewApiDispatcher(QtCore.QObject):
    """Marshals background preview HTTP /api/features, /api/wms and /api/tile calls onto QGIS main GUI thread."""

    if pyqtSignal is not None:
        requested = pyqtSignal(object)

    def __init__(
        self,
        callback: Callable[[Dict[str, List[str]]], Dict[str, Any]],
        parent: Optional[Any] = None,
        wms_callback: Optional[Callable[[Dict[str, List[str]]], Optional[bytes]]] = None,
        tile_callback: Optional[Callable[[Dict[str, List[str]]], Optional[bytes]]] = None,
        wms_async_callback: Optional[Callable[[Dict[str, List[str]], Callable[[Optional[bytes]], None]], bool]] = None,
        tile_async_callback: Optional[Callable[[Dict[str, List[str]], Callable[[Optional[bytes]], None]], bool]] = None,
    ) -> None:
        super().__init__(parent)
        self._callback = callback
        self._wms_callback = wms_callback
        self._tile_callback = tile_callback
        self._wms_async_callback = wms_async_callback
        self._tile_async_callback = tile_async_callback
        self._active_jobs: set = set()
        if pyqtSignal is not None:
            self.requested.connect(self._on_requested)

    def _on_requested(self, packet: Any) -> None:
        if isinstance(packet, tuple) and len(packet) == 4:
            kind, qs, ev, out = packet
        else:
            kind = "features"
            qs, ev, out = packet

        if kind == "tile" and self._tile_async_callback is not None:
            def _finish_tile(raw_bytes: Optional[bytes]) -> None:
                out["data"] = raw_bytes if raw_bytes else b""
                if not ev.is_set():
                    ev.set()

            try:
                self._tile_async_callback(qs, _finish_tile)
                return
            except Exception:
                out["data"] = b""
                if not ev.is_set():
                    ev.set()
                return

        if kind == "wms" and self._wms_async_callback is not None:
            def _finish_wms(raw_bytes: Optional[bytes]) -> None:
                out["data"] = raw_bytes if raw_bytes else b""
                if not ev.is_set():
                    ev.set()

            try:
                self._wms_async_callback(qs, _finish_wms)
                return
            except Exception:
                out["data"] = b""
                if not ev.is_set():
                    ev.set()
                return

        try:
            if kind == "tile":
                out["data"] = self._tile_callback(qs) if self._tile_callback is not None else b""
            elif kind == "wms":
                out["data"] = self._wms_callback(qs) if self._wms_callback is not None else b""
            else:
                out["data"] = self._callback(qs)
        except Exception as exc:
            if kind in ("wms", "tile"):
                out["data"] = b""
            else:
                out["data"] = {"type": "FeatureCollection", "features": [], "error": str(exc)}
        finally:
            ev.set()


def _make_preview_handler(
    directory: str,
    feature_fetcher: Optional[Callable[[Dict[str, List[str]]], Dict[str, Any]]] = None,
    wms_fetcher: Optional[Callable[[Dict[str, List[str]]], Optional[bytes]]] = None,
    address_fetcher: Optional[Callable[[Dict[str, List[str]]], List[Dict[str, Any]]]] = None,
    tile_fetcher: Optional[Callable[[Dict[str, List[str]]], Optional[bytes]]] = None,
) -> Any:
    class _QuietPreviewHandler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, directory=directory, **kwargs)

        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path == "/api/address" and address_fetcher is not None:
                try:
                    qs = urllib.parse.parse_qs(parsed.query)
                    items = address_fetcher(qs)
                    body = json.dumps({"addresses": items, "results": items}, ensure_ascii=False).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                except Exception as exc:
                    err = json.dumps({"addresses": [], "error": str(exc)}).encode("utf-8")
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(err)))
                    self.end_headers()
                    self.wfile.write(err)
                return
            if parsed.path == "/api/features" and feature_fetcher is not None:
                try:
                    qs = urllib.parse.parse_qs(parsed.query)
                    fc = feature_fetcher(qs)
                    body = json.dumps(fc, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                except Exception as exc:
                    err = json.dumps(
                        {"type": "FeatureCollection", "features": [], "error": str(exc)}
                    ).encode("utf-8")
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(err)))
                    self.end_headers()
                    self.wfile.write(err)
                return
            if parsed.path == "/api/tile" and tile_fetcher is not None:
                try:
                    qs = urllib.parse.parse_qs(parsed.query)
                    png_bytes = tile_fetcher(qs)
                    if not png_bytes or png_bytes == b"__EMPTY__":
                        self.send_response(204)
                        self.send_header("Cache-Control", "public, max-age=120")
                        self.end_headers()
                        return
                    self.send_response(200)
                    self.send_header("Content-Type", "image/png")
                    self.send_header("Cache-Control", "public, max-age=300")
                    self.send_header("Content-Length", str(len(png_bytes)))
                    self.end_headers()
                    self.wfile.write(png_bytes)
                except Exception:
                    self.send_response(204)
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                return
            if parsed.path == "/api/wms" and wms_fetcher is not None:
                try:
                    qs = urllib.parse.parse_qs(parsed.query)
                    png_bytes = wms_fetcher(qs)
                    if not png_bytes:
                        self.send_response(204)
                        self.send_header("Cache-Control", "no-store")
                        self.end_headers()
                        return
                    self.send_response(200)
                    self.send_header("Content-Type", "image/png")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(len(png_bytes)))
                    self.end_headers()
                    self.wfile.write(png_bytes)
                except Exception:
                    self.send_response(204)
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                return
            super().do_GET()

        def log_message(self, format: str, *args: Any) -> None:
            return

    return _QuietPreviewHandler

from ..connectors.address_connector import search_estonian_address
from ..connectors.catalog_manager import LocalCatalogManager
from ..connectors.excel_connector import ExcelConnector
from ..connectors.ogc_connector import OgcConnector
from ..connectors.path_resolver import PortablePathResolver
from ..core.expression_engine import compute_dashboard_widget_ref
from ..core.filter_bus import FilterBus, SpatialExtentFilter
from ..core.i18n import tr
from ..core.persistence import DashboardPersistenceManager
from ..core.schema import DashboardConfig, DashboardPageConfig, DataSourceConfig, SlicerConfig, WidgetConfig
from ..export.html_exporter import HtmlDashboardExporter
from .dialogs import (
    DashboardSettingsDialog,
    DataSourceJoinDialog,
    ExportDashboardDialog,
    ServerSettingsDialog,
    SharePointCatalogDialog,
    SlicerEditorDialog,
    WidgetConnectionsDialog,
    WidgetEditorDialog,
)
from .expression_lego import ExpressionDesignerDialog
from .theme import ThemeManager
from .widgets import (
    CatalogTreeWidget,
    DashboardMapWidget,
    DataTableWidget,
    DragFieldListWidget,
    ExpressionCardWidget,
    ImageLogoWidget,
    InteractiveChartWidget,
    KpiCardWidget,
    MAAAMET_BASEMAPS,
    ResizableCardFrame,
    SlicerCardWidget,
)


class _HoverMiniToolbar(QFrame):
    """Hoverable-dockable mini toolbar for fast adding of Maps, Charts, Tables, Logos & Filters."""

    def __init__(
        self,
        on_action: Callable[[str], None],
        on_toggle_dock: Callable[[], None],
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("FloatingPaletteDocked")
        self._on_action = on_action
        self._on_toggle_dock = on_toggle_dock
        self._lang = lang
        self._docked = True
        self._expanded = False
        self._dragging = False
        self._drag_off = QtCore.QPoint(0, 0)
        self._press_global: Optional[QtCore.QPoint] = None
        self.setMouseTracking(True)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(5, 6, 5, 6)
        lay.setSpacing(5)

        hdr = QHBoxLayout()
        hdr.setSpacing(3)
        self.lbl_grip = QLabel("⋮⋮")
        self.lbl_grip.setProperty("role", "mutedTiny")
        self.lbl_grip.setCursor(qt_enum(Qt, "CursorShape", "OpenHandCursor"))
        self.lbl_grip.installEventFilter(self)
        self.btn_dock = QPushButton("⧉")
        self.btn_dock.setFixedSize(22, 20)
        self.btn_dock.setProperty("btnRole", "miniStep")
        self.btn_dock.clicked.connect(on_toggle_dock)
        hdr.addWidget(self.lbl_grip, 1)
        hdr.addWidget(self.btn_dock)
        lay.addLayout(hdr)

        self._defs: List[Tuple[str, str, str, str, bool]] = [
            ("map", "🗺️", "btn_add_map", "tip_mini_map", False),
            ("bar", "📊", "wtype_bar", "tip_mini_bar_chart", False),
            ("table", "📋", "wtype_table", "tip_mini_table", False),
            ("kpi", "🌿", "wtype_summary", "tip_mini_kpi", False),
            ("expression", "fx", "wtype_expression", "wtype_expression", False),
            ("image", "🖼️", "wtype_image", "tip_mini_image", False),
            ("slicer", "🔍", "btn_add_slicer", "tip_mini_slicer", False),
            ("conns", "🕸️", "btn_model_conns", "tip_mini_conns", False),
        ]
        self._nav_defs: List[Tuple[str, str, str, str, bool]] = [
            ("pan", "✋", "mini_pan", "tip_design_pan", True),
            ("zoom_in", "➕", "mini_zoom_in", "tip_zoom_in", False),
            ("zoom_out", "➖", "mini_zoom_out", "tip_zoom_out", False),
            ("zoom_fit", "⛶", "mini_zoom_fit", "tip_zoom_fit", False),
        ]
        self._buttons: List[Tuple[QPushButton, str, str, str, str]] = []
        self.btn_pan_mini: Optional[QPushButton] = None

        def _append_defs(defs_list: List[Tuple[str, str, str, str, bool]]) -> None:
            for aid, icon, lbl_key, tip_key, checkable in defs_list:
                btn = QPushButton(icon)
                btn.setProperty("btnRole", "miniPalette")
                if checkable:
                    btn.setCheckable(True)
                if aid == "pan":
                    self.btn_pan_mini = btn
                btn.clicked.connect(lambda _c=False, a=aid: self._on_action(a))
                lay.addWidget(btn)
                self._buttons.append((btn, aid, icon, lbl_key, tip_key))

        _append_defs(self._defs)
        sep = QFrame()
        sep.setFixedHeight(2)
        sep.setStyleSheet("background-color: rgba(148, 163, 184, 0.35); border: none; margin: 2px 4px;")
        lay.addWidget(sep)
        _append_defs(self._nav_defs)
        lay.addStretch()
        self.retranslate(lang)
        self._sync_size()

    def set_pan_checked(self, checked: bool) -> None:
        if self.btn_pan_mini is not None:
            self.btn_pan_mini.blockSignals(True)
            self.btn_pan_mini.setChecked(bool(checked))
            self.btn_pan_mini.blockSignals(False)

    def set_docked(self, docked: bool) -> None:
        self._docked = bool(docked)
        self._expanded = False
        self.setObjectName("FloatingPaletteDocked" if docked else "FloatingPalette")
        self.btn_dock.setText("⧉" if docked else "📌")
        try:
            if docked:
                wflag = qt_enum(Qt, "WindowType", "Widget")
                if wflag is not None and hasattr(self, "setWindowFlags"):
                    self.setWindowFlags(wflag)
            else:
                tflag = qt_enum(Qt, "WindowType", "Tool")
                fflag = qt_enum(Qt, "WindowType", "FramelessWindowHint")
                topflag = qt_enum(Qt, "WindowType", "WindowStaysOnTopHint")
                if tflag is not None and fflag is not None and topflag is not None and hasattr(self, "setWindowFlags"):
                    self.setWindowFlags(tflag | fflag | topflag)
                elif tflag is not None and hasattr(self, "setWindowFlags"):
                    self.setWindowFlags(tflag)
        except Exception:
            pass
        try:
            self.style().unpolish(self)
            self.style().polish(self)
        except Exception:
            pass
        self._sync_size()

    def retranslate(self, lang: str) -> None:
        self._lang = lang
        self.btn_dock.setToolTip(tr("mini_dock_tip", lang))
        self.lbl_grip.setToolTip(tr("mini_dock_tip", lang))
        self.setToolTip("")
        show_labels = not self._docked
        for btn, _aid, icon, lbl_key, tip_key in self._buttons:
            txt = tr(lbl_key, lang).lstrip("+ ").strip()
            btn.setToolTip(tr(tip_key, lang))
            btn.setText(f"{icon}  {txt}" if show_labels else icon)

    def _sync_size(self) -> None:
        # Never auto-expand while docked so the canvas never jumps on hover; use tooltips instead.
        show_labels = not self._docked
        self.setFixedWidth(164 if show_labels else 44)
        for btn, _aid, icon, lbl_key, _tip_key in self._buttons:
            txt = tr(lbl_key, self._lang).lstrip("+ ").strip()
            btn.setText(f"{icon}  {txt}" if show_labels else icon)
        if not self._docked:
            self.adjustSize()

    def enterEvent(self, event: Any) -> None:
        if self._docked:
            if hasattr(super(), "enterEvent"):
                super().enterEvent(event)
            return
        self._expanded = True
        self._sync_size()
        if hasattr(super(), "enterEvent"):
            super().enterEvent(event)

    def leaveEvent(self, event: Any) -> None:
        self._expanded = False
        if not self._docked:
            self._sync_size()
        if hasattr(super(), "leaveEvent"):
            super().leaveEvent(event)

    def eventFilter(self, obj: Any, event: Any) -> bool:
        if obj is self.lbl_grip:
            etype = event.type()
            et_press = qt_enum(QtCore.QEvent, "Type", "MouseButtonPress")
            et_move = qt_enum(QtCore.QEvent, "Type", "MouseMove")
            et_rel = qt_enum(QtCore.QEvent, "Type", "MouseButtonRelease")
            if etype == et_press and event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
                self._press_global = mouse_global_pos(event)
                if not self._docked:
                    self._dragging = True
                    self._drag_off = self._press_global - self.pos()
                return True
            if etype == et_move:
                gpt = mouse_global_pos(event)
                if self._docked and self._press_global is not None:
                    dist = abs(int(gpt.x()) - int(self._press_global.x())) + abs(int(gpt.y()) - int(self._press_global.y()))
                    if dist > 8 and self._on_toggle_dock:
                        self._press_global = None
                        self._on_toggle_dock()
                        if not self._docked:
                            self._dragging = True
                            self._drag_off = QtCore.QPoint(18, 12)
                            self.move(int(gpt.x()) - int(self._drag_off.x()), int(gpt.y()) - int(self._drag_off.y()))
                        return True
                elif self._dragging and not self._docked:
                    np = gpt - self._drag_off
                    self.move(int(np.x()), int(np.y()))
                    return True
            if etype == et_rel:
                self._dragging = False
                self._press_global = None
                return True
        return super().eventFilter(obj, event)

    def mousePressEvent(self, event: Any) -> None:
        if not self._docked and event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            self._dragging = True
            self._drag_off = mouse_global_pos(event) - self.pos()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: Any) -> None:
        if self._dragging and not self._docked:
            np = mouse_global_pos(event) - self._drag_off
            self.move(int(np.x()), int(np.y()))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: Any) -> None:
        self._dragging = False
        self._press_global = None
        super().mouseReleaseEvent(event)


class _CatalogBridge(QtCore.QObject):
    """Thread-safe signal bridge from background catalog worker to GUI thread."""

    if pyqtSignal is not None:
        server_updated = pyqtSignal(str, bool, str)
        all_finished = pyqtSignal()


class _HydrationBridge(QtCore.QObject):
    """Thread-safe signal bridge for asynchronous layer loading & progress updates."""

    if pyqtSignal is not None:
        progress = pyqtSignal(int, int, str)
        finished = pyqtSignal(object)
        preview_ready = pyqtSignal(object)


_BUILTIN_CANVAS_PRESETS: List[Tuple[str, str, int, int]] = [
    ("1280x720", "preset_laptop", 1280, 720),
    ("1440x900", "preset_desktop", 1440, 900),
    ("1920x1080", "preset_fhd", 1920, 1080),
    ("960x640", "preset_dock", 960, 640),
]
_LEGACY_PRESET_KEY_MAP: Dict[str, str] = {
    "laptop_1280x720": "1280x720",
    "desktop_1920x1080": "1920x1080",
}


def _canvas_presets_storage_path() -> str:
    """Return QGIS-profile-scoped JSON file path for saved custom canvas presets (#13)."""
    base_dir = ""
    try:
        from qgis.core import QgsApplication

        if hasattr(QgsApplication, "qgisSettingsDirPath"):
            p = str(QgsApplication.qgisSettingsDirPath() or "").strip()
            if p:
                base_dir = p
    except Exception:
        pass
    if not base_dir:
        base_dir = os.path.join(os.path.expanduser("~"), ".qgis_team_dashboard")
    os.makedirs(base_dir, exist_ok=True)
    return os.path.join(base_dir, "qgis_team_dashboard_presets.json")


def _load_custom_canvas_presets() -> List[Dict[str, Any]]:
    path = _canvas_presets_storage_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        if not isinstance(raw, list):
            return []
        out: List[Dict[str, Any]] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            pid = str(item.get("id") or "").strip()
            name = str(item.get("name") or "").strip()
            w = max(480, min(3840, int(item.get("w") or 0)))
            h = max(320, min(2160, int(item.get("h") or 0)))
            if pid and name and w >= 480 and h >= 320:
                out.append({"id": pid, "name": name, "w": w, "h": h, "custom": True})
        return out
    except Exception:
        return []


def _save_custom_canvas_presets(items: List[Dict[str, Any]]) -> None:
    path = _canvas_presets_storage_path()
    clean = [
        {"id": str(it["id"]), "name": str(it["name"]), "w": int(it["w"]), "h": int(it["h"])}
        for it in (items or [])
        if isinstance(it, dict) and it.get("id") and it.get("name")
    ]
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(clean, fh, indent=2, ensure_ascii=False)


class _ArtboardResizeGrip(QFrame):
    """Interactive bottom-right handle to resize the dashboard design artboard directly."""

    SNAP_TOLERANCE_PX = 18

    def __init__(self, board: "_WorkspaceBoard") -> None:
        super().__init__(board)
        self._board = board
        self.setFixedSize(16, 16)
        self.setObjectName("ResizeHandle")
        self.setCursor(qt_enum(Qt, "CursorShape", "SizeFDiagCursor"))
        self._dragging = False
        self._start_global: Optional[QtCore.QPoint] = None
        self._start_wh = (1280, 720)

    def _find_preset_snap(self, raw_w: int, raw_h: int) -> Optional[Tuple[str, str, int, int]]:
        best: Optional[Tuple[int, str, str, int, int]] = None
        tol = self.SNAP_TOLERANCE_PX
        for p in getattr(self._board, "_available_presets", []) or []:
            try:
                pw = int(p.get("w") or 0)
                ph = int(p.get("h") or 0)
                if pw <= 0 or ph <= 0:
                    continue
                dw = abs(raw_w - pw)
                dh = abs(raw_h - ph)
                if dw <= tol and dh <= tol:
                    dist = dw + dh
                    if best is None or dist < best[0]:
                        best = (dist, str(p.get("id") or ""), str(p.get("name") or f"{pw}×{ph}"), pw, ph)
            except Exception:
                continue
        if best is None:
            return None
        return best[1], best[2], best[3], best[4]

    def mousePressEvent(self, event: Any) -> None:
        if self._board.preview_mode:
            return
        if event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            self._dragging = True
            self._start_global = mouse_global_pos(event)
            self._start_wh = (self._board.canvas_w, self._board.canvas_h)
            self._board._snap_preset_hint = None
            self._board._last_snapped_preset_id = None
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: Any) -> None:
        if self._dragging and self._start_global is not None:
            gpt = mouse_global_pos(event)
            z = max(0.25, float(getattr(self._board, "zoom", 1.0) or 1.0))
            dx_log = int(round((gpt.x() - self._start_global.x()) / z))
            dy_log = int(round((gpt.y() - self._start_global.y()) / z))
            raw_w = max(480, min(3840, self._start_wh[0] + dx_log))
            raw_h = max(320, min(2160, self._start_wh[1] + dy_log))
            snap_match = self._find_preset_snap(raw_w, raw_h)
            if snap_match is not None:
                pid, pname, pw, ph = snap_match
                self._board._snap_preset_hint = (pid, pname, pw, ph)
                self._board._last_snapped_preset_id = pid
                nw, nh = pw, ph
            else:
                self._board._snap_preset_hint = None
                self._board._last_snapped_preset_id = None
                nw, nh = raw_w, raw_h
            self._board.set_artboard_options(canvas_w=int(nw), canvas_h=int(nh))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: Any) -> None:
        if self._dragging:
            self._dragging = False
            snap_hint = getattr(self._board, "_snap_preset_hint", None)
            if snap_hint is not None:
                pid, _pname, pw, ph = snap_hint
                nw, nh = pw, ph
                self._board._last_snapped_preset_id = pid
            else:
                step = max(10, self._board.grid_size)
                nw = max(480, round(self._board.canvas_w / step) * step)
                nh = max(320, round(self._board.canvas_h / step) * step)
                self._board._last_snapped_preset_id = None
            self._board._snap_preset_hint = None
            self._board.set_artboard_options(canvas_w=int(nw), canvas_h=int(nh))
            if self._board.on_canvas_resized:
                self._board.on_canvas_resized(int(nw), int(nh))
            event.accept()
            return
        super().mouseReleaseEvent(event)


class _ConnectionWiresOverlay(QWidget):
    """Transparent overlay painting Bezier Model Designer connection wires between cards."""

    def __init__(self, board: QWidget) -> None:
        super().__init__(board)
        self.wires: List[Dict[str, Any]] = []
        self.live_drag: Optional[Tuple[str, Any]] = None
        self.cards: Dict[str, ResizableCardFrame] = {}
        try:
            trans_attr = qt_enum(Qt, "WidgetAttribute", "WA_TransparentForMouseEvents")
            if trans_attr is not None and hasattr(self, "setAttribute"):
                self.setAttribute(trans_attr, True)
        except Exception:
            pass
        self.setStyleSheet("background: transparent;")

    def set_state(
        self,
        cards: Dict[str, ResizableCardFrame],
        wires: List[Dict[str, Any]],
        live_drag: Optional[Tuple[str, Any]] = None,
    ) -> None:
        self.cards = cards
        self.wires = wires
        self.live_drag = live_drag
        if hasattr(self, "update"):
            self.update()

    def paintEvent(self, _event: Any) -> None:
        if QPainter is None or (not self.wires and not self.live_drag):
            return
        p = QPainter(self)
        try:
            aa = qt_enum(QPainter, "RenderHint", "Antialiasing")
            if aa is not None:
                p.setRenderHint(aa)
        except Exception:
            pass

        action_colors = {
            "filter_and_zoom": QColor(56, 189, 248, 95),
            "filter": QColor(34, 197, 94, 95),
            "zoom_only": QColor(245, 158, 11, 95),
        }

        def _draw_bezier(x0: float, y0: float, x1: float, y1: float, col: QColor, dashed: bool = True, width: float = 1.4) -> None:
            p0 = QPointF(x0, y0)
            p1 = QPointF(x1, y1)
            dx = max(44.0, abs(x1 - x0) * 0.4)
            c1 = QPointF(x0 + dx, y0)
            c2 = QPointF(x1 - dx, y1)
            if QPainterPath is not None:
                path = QPainterPath(p0)
                path.cubicTo(c1, c2, p1)
                pen = QPen(col, width)
                if dashed:
                    dash_st = qt_enum(Qt, "PenStyle", "DashLine")
                    if dash_st is not None:
                        pen.setStyle(dash_st)
                p.setPen(pen)
                p.setBrush(qt_enum(Qt, "BrushStyle", "NoBrush"))
                p.drawPath(path)
            else:
                p.setPen(QPen(col, width))
                p.drawLine(p0.toPoint(), p1.toPoint())
            p.setBrush(QBrush(col))
            p.setPen(QPen(col, 1))
            tri = QPolygonF([
                p1,
                QPointF(x1 - 6, y1 - 3),
                QPointF(x1 - 6, y1 + 3),
            ])
            p.drawPolygon(tri)

        for w in self.wires:
            src_card = self.cards.get(w.get("source_id", ""))
            tgt_card = self.cards.get(w.get("target_id", ""))
            if src_card is None or tgt_card is None:
                continue
            sx = float(src_card.x() + src_card.width() - 6)
            sy = float(src_card.y() + 17)
            tx = float(tgt_card.x() + 4)
            ty = float(tgt_card.y() + min(tgt_card.height() * 0.5, 42))
            col = action_colors.get(w.get("action", "filter_and_zoom"), QColor(56, 189, 248, 95))
            _draw_bezier(sx, sy, tx, ty, col, dashed=True, width=1.4)

        if self.live_drag:
            src_id, board_pt = self.live_drag
            src_card = self.cards.get(src_id)
            if src_card is not None and board_pt is not None:
                sx = float(src_card.x() + src_card.width() - 6)
                sy = float(src_card.y() + 17)
                _draw_bezier(sx, sy, float(board_pt.x()), float(board_pt.y()), QColor(56, 189, 248, 220), dashed=True, width=2.0)
        p.end()


class _BorderSeamLockNode(QPushButton):
    """Hover-on midpoint handle on a shared border allowing lock toggle & coupled drag-resize."""

    def __init__(
        self,
        board: QWidget,
        seam_key: str,
        axis: str,
        card_id: str,
        edge_name: str,
        locked: bool,
        lang: str,
        on_toggle: Callable[[str], None],
        on_drag_begin: Callable[[str, str], bool],
        on_drag_step: Callable[[str, str, int, bool], None],
    ) -> None:
        super().__init__(board)
        self.seam_key = seam_key
        self.axis = axis
        self.card_id = card_id
        self.edge_name = edge_name
        self.locked = bool(locked)
        self.lang = lang
        self._on_toggle = on_toggle
        self._on_drag_begin = on_drag_begin
        self._on_drag_step = on_drag_step
        self._hovered = False
        self._press_global: Optional[QtCore.QPoint] = None
        self._dragging = False
        self.logical_mid: Tuple[float, float] = (0.0, 0.0)
        self.setFixedSize(22, 22)
        self.setMouseTracking(True)
        self._refresh_visual()

    def update_state(
        self,
        seam_key: str,
        axis: str,
        card_id: str,
        edge_name: str,
        locked: bool,
        lang: str,
        mid_x: Optional[float] = None,
        mid_y: Optional[float] = None,
    ) -> None:
        self.seam_key = seam_key
        self.axis = axis
        self.card_id = card_id
        self.edge_name = edge_name
        self.locked = bool(locked)
        self.lang = lang
        if mid_x is not None and mid_y is not None:
            self.logical_mid = (float(mid_x), float(mid_y))
        self._refresh_visual()

    def reposition_for_zoom(self, zoom: float) -> None:
        z = max(0.25, float(zoom or 1.0))
        mx, my = getattr(self, "logical_mid", (0.0, 0.0))
        sx = int(round(mx * z)) - (self.width() // 2)
        sy = int(round(my * z)) - (self.height() // 2)
        self.move(max(0, sx), max(0, sy))

    def set_pan_transparent(self, pan_enabled: bool) -> None:
        try:
            trans_attr = qt_enum(Qt, "WidgetAttribute", "WA_TransparentForMouseEvents")
            if trans_attr is not None:
                self.setAttribute(trans_attr, bool(pan_enabled))
        except Exception:
            pass

    def _refresh_visual(self) -> None:
        tip_key = "unlock_border_tip" if self.locked else "lock_border_tip"
        self.setToolTip(tr(tip_key, self.lang))
        if self.locked:
            self.setText("🔒")
            self.setCursor(
                qt_enum(Qt, "CursorShape", "SizeHorCursor" if self.axis == "v" else "SizeVerCursor")
            )
            bg = "rgba(14, 165, 233, 0.96)" if self._hovered else "rgba(56, 189, 248, 0.78)"
            bd = "#e0f2fe" if self._hovered else "rgba(224, 242, 254, 0.75)"
            self.setStyleSheet(
                f"QPushButton {{ background: {bg}; color: #0f172a; border: 1px solid {bd}; "
                "border-radius: 11px; font-size: 10px; padding: 0px; }}"
            )
        else:
            self.setCursor(qt_enum(Qt, "CursorShape", "PointingHandCursor"))
            if self._hovered:
                self.setText("🔓")
                self.setStyleSheet(
                    "QPushButton { background: rgba(15, 23, 42, 0.88); color: #e2e8f0; "
                    "border: 1.5px solid #38bdf8; border-radius: 11px; font-size: 10px; padding: 0px; }"
                )
            else:
                self.setText("•")
                self.setStyleSheet(
                    "QPushButton { background: rgba(148, 163, 184, 0.16); color: rgba(148, 163, 184, 0.75); "
                    "border: 1px solid rgba(148, 163, 184, 0.30); border-radius: 11px; font-size: 11px; padding: 0px; }"
                )

    def enterEvent(self, event: Any) -> None:
        self._hovered = True
        self._refresh_visual()
        super().enterEvent(event)

    def leaveEvent(self, event: Any) -> None:
        self._hovered = False
        self._refresh_visual()
        super().leaveEvent(event)

    def mousePressEvent(self, event: Any) -> None:
        if event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            self._press_global = mouse_global_pos(event)
            self._dragging = False
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: Any) -> None:
        if self._press_global is not None and self.locked:
            cur_g = mouse_global_pos(event)
            if not self._dragging:
                delta = cur_g - self._press_global
                if abs(delta.x()) + abs(delta.y()) > 4:
                    if self._on_drag_begin(self.card_id, self.edge_name):
                        self._dragging = True
            if self._dragging:
                z = max(0.25, float(getattr(self.parent(), "zoom", 1.0) or 1.0))
                raw_px = (cur_g.x() - self._press_global.x()) if self.axis == "v" else (cur_g.y() - self._press_global.y())
                self._on_drag_step(self.card_id, self.edge_name, int(round(raw_px / z)), False)
                event.accept()
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: Any) -> None:
        if event.button() == qt_enum(Qt, "MouseButton", "LeftButton") and self._press_global is not None:
            was_drag = self._dragging
            self._press_global = None
            self._dragging = False
            if was_drag:
                self._on_drag_step(self.card_id, self.edge_name, 0, True)
            else:
                self._on_toggle(self.seam_key)
            event.accept()
            return
        super().mouseReleaseEvent(event)


class _WorkspaceBoard(QWidget):
    """Droppable artboard painting editable design borders, snap grid & size badge."""

    def __init__(
        self,
        on_drop_payload: Callable[[Dict[str, Any], int, int], None],
        on_canvas_resized: Optional[Callable[[int, int], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("WorkspaceBoard")
        self.setAcceptDrops(True)
        self._canvas = parent
        self._on_drop_payload = on_drop_payload
        self.on_canvas_resized = on_canvas_resized

        self.canvas_w = 1280
        self.canvas_h = 720
        self.zoom = 1.0
        self.show_border = True
        self.border_style = "dashed"
        self.border_color = "#38bdf8"
        self.border_width = 2
        self.border_radius = 10
        self.show_grid = True
        self.grid_size = 20
        self.preview_mode = False
        self._pan_mode = False
        self._panning = False
        self._pan_last_global: Optional[QtCore.QPoint] = None
        self._available_presets: List[Dict[str, Any]] = []
        self._snap_preset_hint: Optional[Tuple[str, str, int, int]] = None
        self._last_snapped_preset_id: Optional[str] = None
        self._lang: str = "et"

        self.artboard_grip = _ArtboardResizeGrip(self)
        self.artboard_grip.raise_()

    def set_pan_mode(self, enabled: bool) -> None:
        self._pan_mode = bool(enabled)
        if not enabled:
            self._panning = False
            self._pan_last_global = None
        try:
            cur = qt_enum(Qt, "CursorShape", "OpenHandCursor" if enabled else "ArrowCursor")
            if cur is not None:
                self.setCursor(cur)
        except Exception:
            pass

    def _begin_pan(self, global_pt: Any) -> None:
        self._panning = True
        self._pan_last_global = global_pt
        try:
            cur = qt_enum(Qt, "CursorShape", "ClosedHandCursor")
            if cur is not None:
                self.setCursor(cur)
        except Exception:
            pass

    def _step_pan(self, global_pt: Any) -> None:
        if not self._panning or self._pan_last_global is None:
            return
        dx = int(global_pt.x() - self._pan_last_global.x())
        dy = int(global_pt.y() - self._pan_last_global.y())
        self._pan_last_global = global_pt
        canvas = self._canvas
        if canvas is not None:
            try:
                hs = canvas.horizontalScrollBar() if hasattr(canvas, "horizontalScrollBar") else None
                vs = canvas.verticalScrollBar() if hasattr(canvas, "verticalScrollBar") else None
                if hs is not None:
                    hs.setValue(int(hs.value()) - dx)
                if vs is not None:
                    vs.setValue(int(vs.value()) - dy)
            except Exception:
                pass

    def _end_pan(self) -> None:
        self._panning = False
        self._pan_last_global = None
        try:
            cur = qt_enum(Qt, "CursorShape", "OpenHandCursor" if self._pan_mode else "ArrowCursor")
            if cur is not None:
                self.setCursor(cur)
        except Exception:
            pass

    def mousePressEvent(self, event: Any) -> None:
        btn = event.button()
        left_btn = qt_enum(Qt, "MouseButton", "LeftButton")
        mid_btn = qt_enum(Qt, "MouseButton", "MiddleButton")
        if (self._pan_mode and btn == left_btn) or (mid_btn is not None and btn == mid_btn):
            self._begin_pan(mouse_global_pos(event))
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: Any) -> None:
        if self._panning:
            self._step_pan(mouse_global_pos(event))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: Any) -> None:
        if self._panning:
            self._end_pan()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def set_artboard_options(
        self,
        canvas_w: Optional[int] = None,
        canvas_h: Optional[int] = None,
        show_border: Optional[bool] = None,
        border_style: Optional[str] = None,
        border_color: Optional[str] = None,
        border_width: Optional[int] = None,
        border_radius: Optional[int] = None,
        show_grid: Optional[bool] = None,
        grid_size: Optional[int] = None,
        preview_mode: Optional[bool] = None,
        zoom: Optional[float] = None,
    ) -> None:
        if canvas_w is not None:
            self.canvas_w = max(480, int(canvas_w))
        if canvas_h is not None:
            self.canvas_h = max(320, int(canvas_h))
        if show_border is not None:
            self.show_border = bool(show_border)
        if border_style is not None:
            self.border_style = str(border_style or "dashed")
        if border_color is not None:
            self.border_color = str(border_color or "#38bdf8")
        if border_width is not None:
            self.border_width = max(1, min(12, int(border_width)))
        if border_radius is not None:
            self.border_radius = max(0, min(32, int(border_radius)))
        if show_grid is not None:
            self.show_grid = bool(show_grid)
        if grid_size is not None:
            self.grid_size = max(5, int(grid_size))
        if preview_mode is not None:
            self.preview_mode = bool(preview_mode)
        if zoom is not None:
            self.zoom = max(0.25, min(2.0, float(zoom or 1.0)))

        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        show_grip = self.show_border and not self.preview_mode
        self.artboard_grip.setVisible(show_grip)
        self.artboard_grip.move(
            int(round((self.canvas_w + 10) * z)) - 8,
            int(round((self.canvas_h + 10) * z)) - 8,
        )
        self.artboard_grip.raise_()
        self.update()

    def paintEvent(self, event: Any) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        ox, oy = int(round(10 * z)), int(round(10 * z))
        w, h = max(40, int(round(self.canvas_w * z))), max(40, int(round(self.canvas_h * z)))
        mode = ThemeManager.resolve_mode(self.window().property("dashboard_theme") if hasattr(self, "window") else None)
        tc = ThemeManager.colors_for_widget(self)
        if mode != "dark":
            painter.fillRect(self.rect(), QColor(tc["bg_main"]))

        fill_col = QColor(15, 23, 42, 120) if mode == "dark" else QColor(255, 255, 255, 248)
        rad = float((self.border_radius if self.show_border and self.border_style != "none" else 0) * z)
        if self.show_border and self.border_style == "shadow" and not self.preview_mode:
            painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
            painter.setBrush(QBrush(QColor(15, 23, 42, 24 if mode != "dark" else 90)))
            painter.drawRoundedRect(ox + 3, oy + 4, w, h, rad, rad)
        painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
        painter.setBrush(QBrush(fill_col))
        if rad > 0:
            painter.drawRoundedRect(ox, oy, w, h, rad, rad)
        else:
            painter.fillRect(ox, oy, w, h, fill_col)

        if self.show_grid and not self.preview_mode:
            eff_step = max(10, self.grid_size)
            while eff_step * z < 6.0 and eff_step < 200:
                eff_step *= 2
            dot_pen = QPen(QColor(tc["grid_dot"]))
            dot_pen.setWidth(1)
            painter.setPen(dot_pen)
            lx_g = eff_step
            while lx_g < self.canvas_w:
                gx = int(round((10 + lx_g) * z))
                ly_g = eff_step
                while ly_g < self.canvas_h:
                    gy = int(round((10 + ly_g) * z))
                    painter.drawPoint(gx, gy)
                    ly_g += eff_step
                lx_g += eff_step

        if self.show_border and self.border_style != "none" and not self.preview_mode:
            bcol = QColor(self.border_color or tc["border_focus"])
            if not bcol.isValid():
                bcol = QColor(tc["border_focus"])
            bw = max(1, int(round((self.border_width or 2) * z)))
            pen_style_map = {
                "solid": "SolidLine",
                "shadow": "SolidLine",
                "double": "SolidLine",
                "dashed": "DashLine",
                "dotted": "DotLine",
            }
            pstyle = qt_enum(Qt, "PenStyle", pen_style_map.get(self.border_style, "DashLine"))
            border_pen = QPen(bcol)
            border_pen.setWidth(bw)
            border_pen.setStyle(pstyle)
            painter.setPen(border_pen)
            painter.setBrush(qt_enum(Qt, "BrushStyle", "NoBrush"))
            if rad > 0:
                painter.drawRoundedRect(ox, oy, w, h, rad, rad)
            else:
                painter.drawRect(ox, oy, w, h)
            if self.border_style == "double" and w > 12 and h > 12:
                inner_pen = QPen(bcol)
                inner_pen.setWidth(max(1, bw // 2))
                painter.setPen(inner_pen)
                if rad > 0:
                    painter.drawRoundedRect(ox + 4, oy + 4, w - 8, h - 8, max(0.0, rad - 3), max(0.0, rad - 3))
                else:
                    painter.drawRect(ox + 4, oy + 4, w - 8, h - 8)

            painter.setPen(QPen(bcol))
            painter.drawText(ox + max(8, w - 92), oy + max(16, h - 8), f"{self.canvas_w}×{self.canvas_h} px")

        snap_hint = getattr(self, "_snap_preset_hint", None)
        if snap_hint is not None and not self.preview_mode:
            _pid, pname, pw, ph = snap_hint
            hint_pen = QPen(QColor("#f59e0b"), 2, qt_enum(Qt, "PenStyle", "DashLine"))
            painter.setPen(hint_pen)
            painter.setBrush(qt_enum(Qt, "BrushStyle", "NoBrush"))
            painter.drawRect(ox, oy, max(40, int(round(pw * z))), max(40, int(round(ph * z))))
            badge_txt = tr("preset_snap_hint", getattr(self, "_lang", "et"), name=pname, w=pw, h=ph)
            bw_est = max(160, len(badge_txt) * 7 + 20)
            bx = ox + max(8, w - bw_est - 12)
            by = oy + max(12, h - 52)
            painter.setPen(QPen(QColor("#f59e0b"), 1))
            painter.setBrush(QBrush(QColor(15, 23, 42, 230)))
            painter.drawRoundedRect(bx, by, bw_est, 24, 6, 6)
            painter.setPen(QPen(QColor("#fef3c7")))
            painter.drawText(bx + 10, by + 16, badge_txt)

        painter.end()

    def _highlight_map_under(self, pos: Optional[Any]) -> None:
        target = None
        for ch in self.children():
            if isinstance(ch, ResizableCardFrame) and isinstance(getattr(ch, "inner_widget", None), DashboardMapWidget):
                matched = False
                if pos is not None:
                    try:
                        matched = bool(ch.geometry().contains(pos))
                    except Exception:
                        matched = False
                ch.inner_widget.set_drop_highlight(matched and target is None)
                if matched and target is None:
                    target = ch.inner_widget

    def dragEnterEvent(self, event: Any) -> None:
        if event.mimeData().hasFormat(CatalogTreeWidget.MIME_TYPE):
            event.acceptProposedAction()
            pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
            self._highlight_map_under(pos)
        else:
            event.ignore()

    def dragMoveEvent(self, event: Any) -> None:
        if event.mimeData().hasFormat(CatalogTreeWidget.MIME_TYPE):
            event.acceptProposedAction()
            pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
            self._highlight_map_under(pos)
        else:
            event.ignore()

    def dragLeaveEvent(self, event: Any) -> None:
        self._highlight_map_under(None)
        super().dragLeaveEvent(event)

    def dropEvent(self, event: Any) -> None:
        self._highlight_map_under(None)
        if not event.mimeData().hasFormat(CatalogTreeWidget.MIME_TYPE):
            event.ignore()
            return
        raw = bytes(event.mimeData().data(CatalogTreeWidget.MIME_TYPE)).decode("utf-8")
        try:
            payload = json.loads(raw)
        except Exception:
            event.ignore()
            return
        pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        event.acceptProposedAction()
        self._on_drop_payload(payload, int(round(pos.x() / z)), int(round(pos.y() / z)))


class DashboardWorkspaceCanvas(QScrollArea):
    """Scrollable freeform container hosting draggable & resizable dashboard cards."""

    _ZOOM_STEPS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.85, 1.0, 1.15, 1.25, 1.5, 1.75, 2.0]

    def __init__(
        self,
        on_drop_payload: Callable[[Dict[str, Any], int, int], None],
        on_canvas_resized: Optional[Callable[[int, int], None]] = None,
        on_zoom_changed: Optional[Callable[[float], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("WorkspaceScroll")
        self.setWidgetResizable(False)
        self.zoom: float = 1.0
        self._on_zoom_changed = on_zoom_changed

        self.board = _WorkspaceBoard(on_drop_payload, on_canvas_resized=on_canvas_resized, parent=self)
        self.board.resize(1340, 780)
        self.setWidget(self.board)

        self.empty_banner = QFrame(self.board)
        self.empty_banner.setObjectName("EmptyBanner")
        eb_layout = QVBoxLayout(self.empty_banner)
        eb_layout.setContentsMargins(24, 20, 24, 20)
        eb_layout.setSpacing(6)
        self.lbl_empty_title = QLabel("")
        self.lbl_empty_title.setWordWrap(True)
        self.lbl_empty_sub = QLabel("")
        self.lbl_empty_sub.setWordWrap(True)
        eb_layout.addWidget(self.lbl_empty_title)
        eb_layout.addWidget(self.lbl_empty_sub)
        self.empty_banner.setFixedWidth(480)
        self.empty_banner.hide()

        self._frames: List[ResizableCardFrame] = []
        self._seam_nodes: List[_BorderSeamLockNode] = []
        self.wire_overlay = _ConnectionWiresOverlay(self.board)
        self.wire_overlay.show()
        try:
            if hasattr(self, "horizontalScrollBar") and self.horizontalScrollBar() is not None:
                self.horizontalScrollBar().valueChanged.connect(self._on_scroll_changed)
            if hasattr(self, "verticalScrollBar") and self.verticalScrollBar() is not None:
                self.verticalScrollBar().valueChanged.connect(self._on_scroll_changed)
        except Exception:
            pass

    def _on_scroll_changed(self, _val: int = 0) -> None:
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        for node in getattr(self, "_seam_nodes", []) or []:
            if not node.isHidden():
                node.reposition_for_zoom(z)
                node.raise_()
                node.update()
        if hasattr(self, "board") and self.board is not None:
            self.board.update()

    def _raise_visible_seam_nodes(self) -> None:
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        for node in getattr(self, "_seam_nodes", []) or []:
            if not node.isHidden():
                if getattr(node, "logical_mid", (0.0, 0.0)) != (0.0, 0.0):
                    node.reposition_for_zoom(z)
                node.raise_()
                node.update()

    def clear_cards(self) -> None:
        for frame in self._frames:
            frame.setParent(None)
            frame.deleteLater()
        self._frames.clear()
        self.clear_seam_nodes()
        self.wire_overlay.set_state({}, [], None)

    def clear_seam_nodes(self) -> None:
        for node in getattr(self, "_seam_nodes", []):
            node.setParent(None)
            node.deleteLater()
        self._seam_nodes = []

    def sync_seam_nodes(
        self,
        seams: List[Dict[str, Any]],
        preview_mode: bool,
        lang: str,
        on_toggle: Callable[[str], None],
        on_drag_begin: Callable[[str, str], bool],
        on_drag_step: Callable[[str, str, int, bool], None],
    ) -> None:
        if preview_mode or not seams:
            for node in self._seam_nodes:
                node.hide()
            return
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        while len(self._seam_nodes) < len(seams):
            node = _BorderSeamLockNode(
                self.board,
                seam_key="",
                axis="v",
                card_id="",
                edge_name="right",
                locked=False,
                lang=lang,
                on_toggle=on_toggle,
                on_drag_begin=on_drag_begin,
                on_drag_step=on_drag_step,
            )
            self._seam_nodes.append(node)
        pan_enabled = bool(getattr(self.board, "_pan_mode", False))
        for idx, s in enumerate(seams):
            node = self._seam_nodes[idx]
            node.update_state(
                seam_key=s["key"],
                axis=s["axis"],
                card_id=s["a_id"],
                edge_name="right" if s["axis"] == "v" else "bottom",
                locked=bool(s["locked"]),
                lang=lang,
                mid_x=float(s["mid_x"]),
                mid_y=float(s["mid_y"]),
            )
            node.set_pan_transparent(pan_enabled)
            node.reposition_for_zoom(z)
            node.show()
            node.raise_()
            node.update()
        for idx in range(len(seams), len(self._seam_nodes)):
            self._seam_nodes[idx].hide()
        if hasattr(self, "wire_overlay"):
            self.wire_overlay.raise_()
        for idx in range(len(seams)):
            self._seam_nodes[idx].raise_()

    def add_card(self, frame: ResizableCardFrame, x: int, y: int, w: int, h: int) -> None:
        frame.setParent(self.board)
        min_lw = getattr(frame, "_min_w", frame.min_w)
        min_lh = getattr(frame, "_min_h", frame.min_h)
        lx, ly = max(12, int(x)), max(12, int(y))
        lw, lh = max(min_lw, int(w)), max(min_lh, int(h))
        frame._logical_rect = (lx, ly, lw, lh)
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        if hasattr(frame, "set_canvas_zoom"):
            frame.set_canvas_zoom(z)
        if hasattr(frame, "set_pan_transparent"):
            frame.set_pan_transparent(bool(getattr(self.board, "_pan_mode", False)))
        frame.setGeometry(
            int(round(lx * z)),
            int(round(ly * z)),
            max(frame.min_w, int(round(lw * z))),
            max(frame.min_h, int(round(lh * z))),
        )
        if hasattr(frame, "apply_theme"):
            frame.apply_theme()
        frame.show()
        self._frames.append(frame)
        self.wire_overlay.raise_()
        self._raise_visible_seam_nodes()

    def set_pan_mode(self, enabled: bool) -> None:
        self.board.set_pan_mode(enabled)
        for f in self._frames:
            if hasattr(f, "set_pan_transparent"):
                f.set_pan_transparent(bool(enabled))
        for node in getattr(self, "_seam_nodes", []) or []:
            if hasattr(node, "set_pan_transparent"):
                node.set_pan_transparent(bool(enabled))

    def set_zoom(self, zoom: float) -> float:
        z = round(max(0.25, min(2.0, float(zoom or 1.0))), 2)
        self.zoom = z
        self.board.set_artboard_options(zoom=z)
        for f in self._frames:
            rect = getattr(f, "_logical_rect", None)
            if rect is None:
                lx = max(8, f._to_logical_val(f.x()) if hasattr(f, "_to_logical_val") else f.x())
                ly = max(8, f._to_logical_val(f.y()) if hasattr(f, "_to_logical_val") else f.y())
                lw = max(getattr(f, "_min_w", 180), f._to_logical_val(f.width()) if hasattr(f, "_to_logical_val") else f.width())
                lh = max(getattr(f, "_min_h", 120), f._to_logical_val(f.height()) if hasattr(f, "_to_logical_val") else f.height())
                rect = (lx, ly, lw, lh)
                f._logical_rect = rect
            if hasattr(f, "set_canvas_zoom"):
                f.set_canvas_zoom(z)
            lx, ly, lw, lh = rect
            f.setGeometry(
                int(round(lx * z)),
                int(round(ly * z)),
                max(f.min_w, int(round(lw * z))),
                max(f.min_h, int(round(lh * z))),
            )
        for node in getattr(self, "_seam_nodes", []) or []:
            if not node.isHidden():
                node.reposition_for_zoom(z)
                node.raise_()
                node.update()
        self.expand_to_fit()
        if hasattr(self, "wire_overlay"):
            self.wire_overlay.update()
        self._raise_visible_seam_nodes()
        if self._on_zoom_changed:
            self._on_zoom_changed(z)
        return z

    def step_zoom(self, delta: int = 1) -> float:
        cur = float(getattr(self, "zoom", 1.0) or 1.0)
        if delta > 0:
            target = next((s for s in self._ZOOM_STEPS if s > cur + 0.015), 2.0)
        elif delta < 0:
            target = next((s for s in reversed(self._ZOOM_STEPS) if s < cur - 0.015), 0.25)
        else:
            target = cur
        return self.set_zoom(target)

    def fit_to_view(self) -> float:
        vp = self.viewport().size()
        vw = max(320, int(vp.width()) - 32)
        vh = max(240, int(vp.height()) - 32)
        req_w = max(480, int(self.board.canvas_w) + 20)
        req_h = max(320, int(self.board.canvas_h) + 20)
        for f in self._frames:
            rect = getattr(f, "_logical_rect", None)
            if rect is not None:
                req_w = max(req_w, rect[0] + rect[2] + 24)
                req_h = max(req_h, rect[1] + rect[3] + 24)
        fit_z = min(vw / float(req_w), vh / float(req_h))
        return self.set_zoom(max(0.25, min(1.0, fit_z)))

    def wheelEvent(self, event: Any) -> None:
        try:
            mods = event.modifiers() if hasattr(event, "modifiers") else 0
            ctrl = qt_enum(Qt, "KeyboardModifier", "ControlModifier")
            if ctrl is not None and bool(mods & ctrl):
                delta = event.angleDelta().y() if hasattr(event, "angleDelta") else 0
                if delta != 0:
                    self.step_zoom(1 if delta > 0 else -1)
                    event.accept()
                    return
        except Exception:
            pass
        super().wheelEvent(event)

    def update_wires(
        self,
        connections: List[Any],
        live_drag: Optional[Tuple[str, Any]] = None,
    ) -> None:
        cards_by_id = {f.item_id: f for f in self._frames}
        wires = [
            {
                "source_id": getattr(c, "source_id", "") if not isinstance(c, dict) else c.get("source_id", ""),
                "target_id": getattr(c, "target_id", "") if not isinstance(c, dict) else c.get("target_id", ""),
                "action": getattr(c, "action", "filter_and_zoom") if not isinstance(c, dict) else c.get("action", "filter_and_zoom"),
            }
            for c in connections or []
            if (getattr(c, "enabled", True) if not isinstance(c, dict) else c.get("enabled", True))
        ]
        self.wire_overlay.set_state(cards_by_id, wires, live_drag=live_drag)
        self.wire_overlay.raise_()
        self._raise_visible_seam_nodes()

    def card_at_global_pos(self, global_pt: Any, exclude_id: Optional[str] = None) -> Optional[str]:
        try:
            local_pt = self.board.mapFromGlobal(global_pt)
            px, py = float(local_pt.x()), float(local_pt.y())
            for frame in reversed(self._frames):
                if exclude_id and frame.item_id == exclude_id:
                    continue
                if frame.x() <= px <= frame.x() + frame.width() and frame.y() <= py <= frame.y() + frame.height():
                    return frame.item_id
        except Exception:
            pass
        return None

    def apply_design_settings(
        self,
        canvas_w: int,
        canvas_h: int,
        show_border: bool,
        show_grid: bool,
        snap_to_grid: bool,
        grid_size: int,
        preview_mode: bool,
        border_style: str = "dashed",
        border_color: str = "#38bdf8",
        border_width: int = 2,
        border_radius: int = 10,
    ) -> None:
        self.board.set_artboard_options(
            canvas_w=canvas_w,
            canvas_h=canvas_h,
            show_border=show_border,
            border_style=border_style,
            border_color=border_color,
            border_width=border_width,
            border_radius=border_radius,
            show_grid=show_grid,
            grid_size=grid_size,
            preview_mode=preview_mode,
        )
        for f in self._frames:
            f.set_grid_snap(snap_to_grid, grid_size)
            f.set_preview_mode(preview_mode)
        self.expand_to_fit()

    def set_empty_state(self, visible: bool, title: str = "", subtitle: str = "") -> None:
        self.lbl_empty_title.setText(f"<h3>{title}</h3>")
        self.lbl_empty_sub.setText(subtitle)
        if visible:
            vp = self.viewport().size()
            bx = max(24, (vp.width() - self.empty_banner.width()) // 2)
            by = max(40, (vp.height() - 150) // 3)
            self.empty_banner.move(bx, by)
            self.empty_banner.adjustSize()
            self.empty_banner.show()
        else:
            self.empty_banner.hide()

    def expand_to_fit(self) -> None:
        vp = self.viewport().size()
        z = max(0.25, float(getattr(self, "zoom", 1.0) or 1.0))
        max_r = max(vp.width() - 4, int(round((self.board.canvas_w + 48) * z)))
        max_b = max(vp.height() - 4, int(round((self.board.canvas_h + 48) * z)))
        for f in self._frames:
            geo = f.geometry()
            max_r = max(max_r, geo.x() + geo.width() + 28)
            max_b = max(max_b, geo.y() + geo.height() + 28)
        self.board.resize(max_r, max_b)
        if hasattr(self, "wire_overlay"):
            self.wire_overlay.setGeometry(0, 0, max_r, max_b)
            self.wire_overlay.raise_()
        self._raise_visible_seam_nodes()

    def resizeEvent(self, event: Any) -> None:
        super().resizeEvent(event)
        self.expand_to_fit()


class DashboardDockWidget(QDockWidget):
    """Interactive Conservation Dashboard Studio Dock Widget for QGIS Desktop."""

    def __init__(self, iface: Any = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(tr("plugin_title", "et"), parent)
        self.iface = iface
        allowed = (
            qt_enum(Qt, "DockWidgetArea", "LeftDockWidgetArea")
            | qt_enum(Qt, "DockWidgetArea", "RightDockWidgetArea")
            | qt_enum(Qt, "DockWidgetArea", "BottomDockWidgetArea")
            | _safe_qt_enum(Qt, "DockWidgetArea", "TopDockWidgetArea", 0)
        )
        self.setAllowedAreas(allowed)
        if hasattr(self, "setFeatures"):
            f_closable = _safe_qt_enum(QDockWidget, "DockWidgetFeature", "DockWidgetClosable", 0)
            f_movable = _safe_qt_enum(QDockWidget, "DockWidgetFeature", "DockWidgetMovable", 0)
            f_floatable = _safe_qt_enum(QDockWidget, "DockWidgetFeature", "DockWidgetFloatable", 0)
            feats = f_closable | f_movable | f_floatable
            if feats:
                try:
                    self.setFeatures(feats)
                except Exception:
                    pass
        self.setMinimumWidth(300)
        if hasattr(self, "setMinimumHeight"):
            self.setMinimumHeight(34)

        self._dock_shaded: bool = False
        self._dock_expanded_ratio: bool = False
        self._pre_shade_cat_visible: Optional[bool] = None
        if hasattr(self, "topLevelChanged"):
            try:
                self.topLevelChanged.connect(self._on_dock_top_level_changed)
            except Exception:
                pass

        self.config = DashboardConfig(language="et")
        self.filter_bus = FilterBus()
        self.persistence = DashboardPersistenceManager()
        self.filter_bus.set_cross_layer_resolver(self.persistence.resolve_cross_layer_matching_fids)
        self.filter_bus.set_cross_layer_result_resolver(self.persistence.resolve_cross_layer_result)
        self.catalog_manager = LocalCatalogManager()
        self.persistence.catalog_manager = self.catalog_manager
        self.persistence.set_sync_mode(getattr(self.config, "canvas_sync_mode", "dashboard_only"))
        self.catalog_data = self.catalog_manager.load_or_initialize()

        self._slicer_cards: List[Tuple[ResizableCardFrame, SlicerCardWidget]] = []
        self._widget_cards: List[Tuple[ResizableCardFrame, QWidget]] = []
        self._extent_filter_enabled = False
        self._canvas_connected = False
        self._refresh_thread_active = False
        self._hydration_active = False
        self._hydration_cancelled = False
        self._pending_project_cfg: Optional[DashboardConfig] = None
        self._preview_server: Any = None
        self._preview_dir: str = ""
        self._preview_url: str = ""
        self._preview_web_view: Any = None
        self._last_added_card_id: Optional[str] = None
        self._active_saved_dashboard_id: str = ""
        self._refresh_in_progress: bool = False
        self._force_map_refresh_next: bool = False
        self._hydration_seq: int = 0

        self._bridge = _CatalogBridge(self)
        if pyqtSignal is not None:
            self._bridge.server_updated.connect(self._on_catalog_server_updated)
            self._bridge.all_finished.connect(self._on_catalog_refresh_finished)

        self._hydr_bridge = _HydrationBridge(self)
        self._last_progress_pump_ts: float = 0.0
        self._pending_preview_after_hydration: bool = False
        self._preview_build_seq: int = 0
        self._had_active_filters: bool = False
        if pyqtSignal is not None:
            self._hydr_bridge.progress.connect(self._on_hydration_bg_progress)
            self._hydr_bridge.finished.connect(self._on_hydration_bg_finished)
            self._hydr_bridge.preview_ready.connect(self._on_preview_build_ready)

        self.filter_bus.subscribe(self._on_filters_changed)
        self._init_dock_title_bar()
        self._init_ui()
        self._apply_theme()
        self._retranslate_ui()
        self._connect_qgis_canvas()

        # Instant catalog tree build from local cache + silent async background sync if stale/empty
        self.refresh_catalog_panel()
        self.refresh_connections_panel()
        self._refresh_home_view()
        self._sync_design_controls()
        self._schedule_background_catalog_sync_if_needed()

    def _init_ui(self) -> None:
        root = QWidget()
        root.setObjectName("DashboardStudioRoot")
        self.setWidget(root)
        main_layout = QVBoxLayout(root)
        main_layout.setContentsMargins(6, 4, 6, 4)
        main_layout.setSpacing(4)

        def _wrap_horizontal_strip(inner: QWidget, strip_h: int) -> QScrollArea:
            sa = QScrollArea()
            sa.setObjectName("StudioBarScroll")
            sa.setWidget(inner)
            sa.setWidgetResizable(True)
            if hasattr(sa, "setFrameShape"):
                sa.setFrameShape(_safe_qt_enum(QFrame, "Shape", "NoFrame", 0))
            if hasattr(sa, "setHorizontalScrollBarPolicy"):
                sa.setHorizontalScrollBarPolicy(_safe_qt_enum(Qt, "ScrollBarPolicy", "ScrollBarAsNeeded", 0))
            if hasattr(sa, "setVerticalScrollBarPolicy"):
                sa.setVerticalScrollBarPolicy(_safe_qt_enum(Qt, "ScrollBarPolicy", "ScrollBarAlwaysOff", 1))
            if hasattr(sa, "setFixedHeight"):
                sa.setFixedHeight(strip_h)
            if QSizePolicy is not None and hasattr(sa, "setSizePolicy"):
                pol_exp = _safe_qt_enum(QSizePolicy, "Policy", "Expanding", 7)
                pol_fix = _safe_qt_enum(QSizePolicy, "Policy", "Fixed", 0)
                sa.setSizePolicy(pol_exp, pol_fix)
            if hasattr(sa, "viewport"):
                vp = sa.viewport()
                if vp is not None and hasattr(vp, "installEventFilter"):
                    vp.installEventFilter(self)
            return sa

        # ---- Top Studio Toolbar ----
        toolbar = QFrame()
        toolbar.setObjectName("StudioToolbar")
        tb_layout = QHBoxLayout(toolbar)
        tb_layout.setContentsMargins(8, 3, 8, 3)
        tb_layout.setSpacing(5)

        self.lbl_title = QLabel("")
        self.lbl_title.setStyleSheet("font-size: 13px; font-weight: 700; padding-right: 6px;")

        self.btn_home_view = QPushButton("")
        self.btn_home_view.setProperty("btnRole", "secondary")
        self.btn_home_view.clicked.connect(self._toggle_home_workspace_view)

        self.btn_toggle_cat = QPushButton("")
        self.btn_toggle_cat.setCheckable(True)
        self.btn_toggle_cat.setChecked(True)
        self.btn_toggle_cat.clicked.connect(self._toggle_catalog_sidebar)

        self.btn_add_map = QPushButton("")
        self.btn_add_map.setProperty("btnRole", "accent")
        self.btn_add_map.clicked.connect(lambda: self.open_add_widget(preset_type="map"))

        self.btn_add_widget = QPushButton("")
        self.btn_add_widget.setProperty("btnRole", "primary")
        self.btn_add_widget.clicked.connect(lambda: self.open_add_widget())

        self.btn_add_slicer = QPushButton("")
        self.btn_add_slicer.clicked.connect(lambda: self.open_add_slicer())

        self.btn_auto_layout = QPushButton("")
        self.btn_auto_layout.clicked.connect(self.auto_arrange_cards)

        self.btn_templates = QPushButton("")
        self._templates_menu = QMenu(self.btn_templates)
        self.btn_templates.setMenu(self._templates_menu)

        self.btn_sources = QPushButton("")
        self.btn_sources.clicked.connect(self.open_sources_dialog)

        self.btn_extent_filter = QPushButton("")
        self.btn_extent_filter.setCheckable(True)
        self.btn_extent_filter.clicked.connect(self._toggle_extent_filter)

        self.btn_reset_filters = QPushButton("")
        self.btn_reset_filters.clicked.connect(self._on_reset_filters_clicked)

        self.btn_refresh = QPushButton("")
        self._refresh_menu: Optional[QMenu] = None
        self.btn_refresh.clicked.connect(self._on_refresh_button_clicked)

        self.btn_catalog = QPushButton("")
        self.btn_catalog.clicked.connect(self.open_sharepoint_catalog)

        self.btn_lang = QPushButton("")
        self.btn_lang.clicked.connect(self._toggle_language)

        self.btn_settings = QPushButton("")
        self.btn_settings.clicked.connect(lambda _checked=False: self.open_settings_dialog(initial_tab=0))

        self.btn_save_dashboard = QPushButton("")
        self.btn_save_dashboard.setProperty("btnRole", "secondary")
        self.btn_save_dashboard.clicked.connect(lambda _c=False: self.save_dashboard_action())

        self.btn_export = QPushButton("")
        self.btn_export.setProperty("btnRole", "primary")
        self.btn_export.clicked.connect(self.export_html_dashboard)

        self.btn_mini_bar = QPushButton("")
        self.btn_mini_bar.setCheckable(True)
        self.btn_mini_bar.setChecked(True)
        self.btn_mini_bar.clicked.connect(self._toggle_floating_palette)

        for w in (
            self.lbl_title,
            self.btn_home_view,
            self.btn_toggle_cat,
            self.btn_mini_bar,
            self.btn_add_map,
            self.btn_add_widget,
            self.btn_add_slicer,
            self.btn_auto_layout,
            self.btn_templates,
            self.btn_sources,
            self.btn_extent_filter,
            self.btn_reset_filters,
            self.btn_refresh,
            self.btn_catalog,
            self.btn_settings,
            self.btn_lang,
            self.btn_save_dashboard,
            self.btn_export,
        ):
            tb_layout.addWidget(w)
        tb_layout.addStretch()
        self.toolbar_scroll = _wrap_horizontal_strip(toolbar, 56)
        main_layout.addWidget(self.toolbar_scroll)

        # ---- Main Studio Stack: Page 0 = Home View, Page 1 = Catalog + Workspace ----
        self.studio_stack = QStackedWidget()
        self.home_view = self._build_home_view()
        self.studio_stack.addWidget(self.home_view)
        self.splitter = QSplitter(qt_enum(Qt, "Orientation", "Horizontal"))
        if hasattr(self.splitter, "setChildrenCollapsible"):
            self.splitter.setChildrenCollapsible(True)
        self.studio_stack.addWidget(self.splitter)
        self.studio_stack.setCurrentIndex(0)
        main_layout.addWidget(self.studio_stack, 1)

        # Left Panel Container with Tabs (0: Catalog, 1: Connections Overview)
        self.catalog_panel = QFrame()
        self.catalog_panel.setObjectName("CatalogPanel")
        self.catalog_panel.setMinimumWidth(160)
        self.catalog_panel.setMaximumWidth(420)
        left_wrap = QVBoxLayout(self.catalog_panel)
        left_wrap.setContentsMargins(6, 6, 6, 6)
        left_wrap.setSpacing(6)

        self.left_tabs = QTabWidget()
        left_wrap.addWidget(self.left_tabs, 1)

        # Tab 0: Data Catalog
        cat_tab = QWidget()
        cat_layout = QVBoxLayout(cat_tab)
        cat_layout.setContentsMargins(6, 6, 6, 6)
        cat_layout.setSpacing(6)

        cat_hdr_row = QHBoxLayout()
        self.lbl_cat_title = QLabel("")
        self.lbl_cat_title.setStyleSheet("font-size: 13px; font-weight: 700;")
        self.btn_cat_refresh = QPushButton("🔄")
        self.btn_cat_refresh.setFixedWidth(30)
        self.btn_cat_refresh.clicked.connect(lambda: self.start_catalog_background_refresh(force=True))
        cat_hdr_row.addWidget(self.lbl_cat_title, 1)
        cat_hdr_row.addWidget(self.btn_cat_refresh)
        cat_layout.addLayout(cat_hdr_row)

        self.lbl_cat_subtitle = QLabel("")
        self.lbl_cat_subtitle.setWordWrap(True)
        self.lbl_cat_subtitle.setProperty("role", "muted")
        cat_layout.addWidget(self.lbl_cat_subtitle)

        self.ed_cat_search = QLineEdit()
        self.ed_cat_search.textChanged.connect(lambda _t: self.refresh_catalog_panel())
        cat_layout.addWidget(self.ed_cat_search)

        self.cat_progress = QProgressBar()
        self.cat_progress.setRange(0, 0)
        self.cat_progress.setFixedHeight(7)
        self.cat_progress.setTextVisible(False)
        self.cat_progress.hide()
        cat_layout.addWidget(self.cat_progress)

        self.lbl_cat_status = QLabel("")
        self.lbl_cat_status.setProperty("role", "accentSmall")
        self.lbl_cat_status.setWordWrap(True)
        cat_layout.addWidget(self.lbl_cat_status)

        self.catalog_tree = CatalogTreeWidget()
        self.catalog_tree.setContextMenuPolicy(
            qt_enum(Qt, "ContextMenuPolicy", "CustomContextMenu")
        )
        self.catalog_tree.customContextMenuRequested.connect(self._on_catalog_context_menu)
        self.catalog_tree.itemDoubleClicked.connect(self._on_catalog_item_activated)
        cat_layout.addWidget(self.catalog_tree, 1)

        cat_btn_row = QHBoxLayout()
        self.btn_cat_add_srv = QPushButton("")
        self.btn_cat_add_srv.clicked.connect(lambda: self._open_server_settings())
        self.btn_cat_add_xl = QPushButton("")
        self.btn_cat_add_xl.clicked.connect(self._quick_add_excel_file)
        cat_btn_row.addWidget(self.btn_cat_add_srv)
        cat_btn_row.addWidget(self.btn_cat_add_xl)
        cat_layout.addLayout(cat_btn_row)
        self.left_tabs.addTab(cat_tab, "Kataloog")

        # Tab 1: Connections Overview Panel
        self.connections_panel = QWidget()
        conn_layout = QVBoxLayout(self.connections_panel)
        conn_layout.setContentsMargins(6, 6, 6, 6)
        conn_layout.setSpacing(6)

        self.lbl_conn_title = QLabel("")
        self.lbl_conn_title.setProperty("role", "cardTitle")
        conn_layout.addWidget(self.lbl_conn_title)

        self.lbl_conn_summary = QLabel("")
        self.lbl_conn_summary.setWordWrap(True)
        self.lbl_conn_summary.setProperty("role", "muted")
        conn_layout.addWidget(self.lbl_conn_summary)

        self.connections_list = DragFieldListWidget(
            role_mode="connections",
            lang=self.config.language,
            on_remove_row=self._remove_connection_at_row,
            context_menu_cb=self._on_connection_context_menu,
        )
        self.connections_list.itemDoubleClicked.connect(lambda _it: self._load_selected_connection())
        conn_layout.addWidget(self.connections_list, 1)

        conn_add_row = QHBoxLayout()
        self.btn_conn_add_ogc = QPushButton("+ WFS / WMS")
        self.btn_conn_add_ogc.clicked.connect(self.open_sources_dialog)
        self.btn_conn_add_xl = QPushButton("+ Excel")
        self.btn_conn_add_xl.clicked.connect(self._quick_add_excel_file)
        self.btn_conn_add_qgis = QPushButton("+ QGIS")
        self.btn_conn_add_qgis.clicked.connect(self._quick_add_qgis_layer)
        conn_add_row.addWidget(self.btn_conn_add_ogc)
        conn_add_row.addWidget(self.btn_conn_add_xl)
        conn_add_row.addWidget(self.btn_conn_add_qgis)
        conn_layout.addLayout(conn_add_row)

        conn_act_row = QHBoxLayout()
        self.btn_conn_edit = QPushButton("")
        self.btn_conn_edit.clicked.connect(self.open_sources_dialog)
        self.btn_conn_load = QPushButton("")
        self.btn_conn_load.clicked.connect(self._load_selected_connection)
        self.btn_conn_remove = QPushButton("")
        self.btn_conn_remove.clicked.connect(self._remove_selected_connection)
        conn_act_row.addWidget(self.btn_conn_edit)
        conn_act_row.addWidget(self.btn_conn_load)
        conn_act_row.addWidget(self.btn_conn_remove)
        conn_layout.addLayout(conn_act_row)
        self.left_tabs.addTab(self.connections_panel, tr("tab_connections", self.config.language))

        # Right Panel: Design Artboard Controls + Loading Progress + Freeform Workspace
        self.workspace_wrap = QWidget()
        ws_layout = QVBoxLayout(self.workspace_wrap)
        ws_layout.setContentsMargins(0, 0, 0, 0)
        ws_layout.setSpacing(4)

        self.design_bar = QFrame()
        self.design_bar.setObjectName("DesignStrip")
        db_row = QHBoxLayout(self.design_bar)
        db_row.setContentsMargins(8, 3, 8, 3)
        db_row.setSpacing(6)

        self.lbl_design_size = QLabel("")
        self.lbl_design_size.setProperty("role", "muted")
        self.cb_preset = QComboBox()
        self.cb_preset.currentIndexChanged.connect(self._on_preset_changed)

        self.btn_save_preset = QPushButton("💾")
        self.btn_save_preset.setFixedWidth(28)
        self.btn_save_preset.setProperty("btnRole", "miniStep")
        self.btn_save_preset.clicked.connect(self._on_save_custom_preset)

        self.btn_delete_preset = QPushButton("🗑")
        self.btn_delete_preset.setFixedWidth(28)
        self.btn_delete_preset.setProperty("btnRole", "miniStep")
        self.btn_delete_preset.setEnabled(False)
        self.btn_delete_preset.clicked.connect(self._on_delete_custom_preset)

        self.sp_canvas_w = QSpinBox()
        self.sp_canvas_w.setRange(480, 3840)
        self.sp_canvas_w.setSingleStep(40)
        self.sp_canvas_w.valueChanged.connect(self._on_canvas_dims_edited)
        self.sp_canvas_h = QSpinBox()
        self.sp_canvas_h.setRange(320, 2160)
        self.sp_canvas_h.setSingleStep(40)
        self.sp_canvas_h.valueChanged.connect(self._on_canvas_dims_edited)

        self.btn_border = QPushButton("")
        self._border_menu = QMenu(self.btn_border)
        self._border_actions: Dict[str, Any] = {}
        self.btn_border.setMenu(self._border_menu)

        self.btn_grid_menu = QPushButton("")
        self._grid_menu = QMenu(self.btn_grid_menu)
        self._grid_density_actions: Dict[int, Any] = {}
        self._act_grid_show: Optional[Any] = None
        self._act_grid_snap: Optional[Any] = None
        self.btn_grid_menu.setMenu(self._grid_menu)

        self.btn_pan = QPushButton("")
        self.btn_pan.setCheckable(True)
        self.btn_pan.clicked.connect(self._on_pan_toggled)

        self.btn_zoom_out = QPushButton("➖")
        self.btn_zoom_out.setFixedWidth(28)
        self.btn_zoom_out.setProperty("btnRole", "miniStep")
        self.btn_zoom_out.clicked.connect(lambda: self._step_canvas_zoom(-1))

        self.btn_zoom_reset = QPushButton("100%")
        self.btn_zoom_reset.setFixedWidth(48)
        self.btn_zoom_reset.setProperty("btnRole", "miniStep")
        self.btn_zoom_reset.clicked.connect(self._reset_canvas_zoom)

        self.btn_zoom_in = QPushButton("➕")
        self.btn_zoom_in.setFixedWidth(28)
        self.btn_zoom_in.setProperty("btnRole", "miniStep")
        self.btn_zoom_in.clicked.connect(lambda: self._step_canvas_zoom(1))

        self.btn_zoom_fit = QPushButton("")
        self.btn_zoom_fit.clicked.connect(self._fit_canvas_zoom)

        self.btn_toggle_wires = QPushButton("")
        self.btn_toggle_wires.setCheckable(True)
        self.btn_toggle_wires.clicked.connect(self._on_design_toggled)

        self.btn_preview = QPushButton("")
        self._preview_menu = QMenu(self.btn_preview)
        self._preview_actions: Dict[str, Any] = {}
        self.btn_preview.setMenu(self._preview_menu)

        self.btn_model_conns = QPushButton("")
        self.btn_model_conns.clicked.connect(lambda: self._open_model_connections_dialog())

        self.btn_conn_jump = QPushButton("")
        self.btn_conn_jump.clicked.connect(self._jump_to_connections_tab)

        for dw in (
            self.lbl_design_size,
            self.cb_preset,
            self.btn_save_preset,
            self.btn_delete_preset,
            self.sp_canvas_w,
            QLabel("×"),
            self.sp_canvas_h,
            self.btn_border,
            self.btn_grid_menu,
            self.btn_pan,
            self.btn_zoom_out,
            self.btn_zoom_reset,
            self.btn_zoom_in,
            self.btn_zoom_fit,
            self.btn_toggle_wires,
            self.btn_preview,
        ):
            db_row.addWidget(dw)
        db_row.addStretch()
        db_row.addWidget(self.btn_model_conns)
        db_row.addWidget(self.btn_conn_jump)
        self.design_bar_scroll = _wrap_horizontal_strip(self.design_bar, 50)
        ws_layout.addWidget(self.design_bar_scroll)

        # Multidash / Dash-Atlas Page Bar (#18)
        self.page_bar = QFrame()
        self.page_bar.setObjectName("DesignStrip")
        pb_row = QHBoxLayout(self.page_bar)
        pb_row.setContentsMargins(8, 3, 8, 3)
        pb_row.setSpacing(6)
        self.page_tabs_host = QWidget()
        self.page_tabs_layout = QHBoxLayout(self.page_tabs_host)
        self.page_tabs_layout.setContentsMargins(0, 0, 0, 0)
        self.page_tabs_layout.setSpacing(4)
        self.btn_add_page = QPushButton(tr("add_page", self.config.language))
        self.btn_add_page.setProperty("btnRole", "miniTool")
        self.btn_add_page.clicked.connect(self._on_add_page_clicked)
        self.btn_rename_page = QPushButton("✏️")
        self.btn_rename_page.setProperty("btnRole", "miniStep")
        self.btn_rename_page.setToolTip(tr("rename_page", self.config.language))
        self.btn_rename_page.clicked.connect(self._on_rename_page_clicked)
        self.btn_del_page = QPushButton("🗑")
        self.btn_del_page.setProperty("btnRole", "miniStep")
        self.btn_del_page.setToolTip(tr("delete_page", self.config.language))
        self.btn_del_page.clicked.connect(self._on_delete_page_clicked)
        pb_row.addWidget(self.page_tabs_host, 0)
        pb_row.addStretch(1)
        pb_row.addWidget(self.btn_add_page)
        pb_row.addWidget(self.btn_rename_page)
        pb_row.addWidget(self.btn_del_page)
        ws_layout.addWidget(self.page_bar)

        # Global Active Filters Banner (#14)
        self.active_filters_bar = QFrame()
        self.active_filters_bar.setObjectName("DesignStrip")
        self.active_filters_bar.setStyleSheet(
            "QFrame#DesignStrip { background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.28); border-radius: 6px; }"
        )
        afb_row = QHBoxLayout(self.active_filters_bar)
        afb_row.setContentsMargins(8, 3, 8, 3)
        afb_row.setSpacing(6)
        self.lbl_active_filters_hdr = QLabel(f"⚡ {tr('active_filters_label', self.config.language)}")
        self.lbl_active_filters_hdr.setProperty("role", "accent")
        self.active_filters_chips_host = QWidget()
        self.active_filters_chips_layout = QHBoxLayout(self.active_filters_chips_host)
        self.active_filters_chips_layout.setContentsMargins(0, 0, 0, 0)
        self.active_filters_chips_layout.setSpacing(5)
        self.btn_clear_all_banner = QPushButton(tr("btn_reset_filters", self.config.language))
        self.btn_clear_all_banner.setProperty("btnRole", "miniStep")
        self.btn_clear_all_banner.clicked.connect(self._on_reset_filters_clicked)
        afb_row.addWidget(self.lbl_active_filters_hdr)
        afb_row.addWidget(self.active_filters_chips_host, 1)
        afb_row.addWidget(self.btn_clear_all_banner)
        self.active_filters_bar.hide()
        ws_layout.addWidget(self.active_filters_bar)

        # Layer Loading Progress Bar (visible during WFS/Excel hydration or Refresh 0-100%)
        self.hydration_bar = QFrame()
        self.hydration_bar.setObjectName("HydrationBar")
        self.hydration_bar.setStyleSheet(
            "#HydrationBar { background: rgba(56, 189, 248, 0.12); border: 1px solid rgba(56, 189, 248, 0.35); border-radius: 6px; }"
        )
        hb_row = QHBoxLayout(self.hydration_bar)
        hb_row.setContentsMargins(10, 4, 10, 4)
        hb_row.setSpacing(8)
        self.lbl_progress = QLabel("")
        self.lbl_progress.setProperty("role", "accent")
        self.workspace_progress = QProgressBar()
        self.workspace_progress.setRange(0, 100)
        if hasattr(self.workspace_progress, "setTextVisible"):
            self.workspace_progress.setTextVisible(True)
        if hasattr(self.workspace_progress, "setFormat"):
            self.workspace_progress.setFormat("%p%")
        if hasattr(self.workspace_progress, "setFixedHeight"):
            self.workspace_progress.setFixedHeight(16)
        if hasattr(self.workspace_progress, "setMinimumWidth"):
            self.workspace_progress.setMinimumWidth(160)
        if hasattr(self.workspace_progress, "setMaximumWidth"):
            self.workspace_progress.setMaximumWidth(240)
        self.btn_cancel_load = QPushButton("×")
        self.btn_cancel_load.setProperty("btnRole", "miniStep")
        self.btn_cancel_load.setFixedWidth(26)
        self.btn_cancel_load.clicked.connect(self._cancel_active_hydration)
        hb_row.addWidget(self.lbl_progress, 1)
        hb_row.addWidget(self.workspace_progress, 0)
        hb_row.addWidget(self.btn_cancel_load, 0)
        self.hydration_bar.hide()
        ws_layout.addWidget(self.hydration_bar)

        self.workspace_view_stack = QStackedWidget()
        self.workspace_canvas = DashboardWorkspaceCanvas(
            self._on_catalog_item_dropped,
            on_canvas_resized=self._on_artboard_drag_resized,
            on_zoom_changed=self._on_canvas_zoom_changed,
        )
        self.workspace_view_stack.addWidget(self.workspace_canvas)
        self.html_preview_panel = self._build_preview_panel()
        self.workspace_view_stack.addWidget(self.html_preview_panel)
        self.workspace_view_stack.setCurrentIndex(0)

        # Prominent centered loading overlay card shown when hydrating heavy workspaces / layers
        self.loading_overlay_card = QFrame(self.workspace_view_stack)
        self.loading_overlay_card.setObjectName("LoadingOverlayCard")
        self.loading_overlay_card.setFixedWidth(420)
        ov_l = QVBoxLayout(self.loading_overlay_card)
        ov_l.setContentsMargins(20, 16, 20, 16)
        ov_l.setSpacing(10)
        self.lbl_overlay_title = QLabel("")
        self.lbl_overlay_title.setProperty("role", "accentTitle")
        self.lbl_overlay_sub = QLabel("")
        self.lbl_overlay_sub.setWordWrap(True)
        self.lbl_overlay_sub.setProperty("role", "muted")
        self.overlay_progress = QProgressBar()
        self.overlay_progress.setRange(0, 100)
        if hasattr(self.overlay_progress, "setTextVisible"):
            self.overlay_progress.setTextVisible(True)
        if hasattr(self.overlay_progress, "setFormat"):
            self.overlay_progress.setFormat("%p%")
        self.overlay_progress.setFixedHeight(16)
        ov_btn_row = QHBoxLayout()
        ov_btn_row.addStretch()
        self.btn_overlay_cancel = QPushButton("× Katkesta")
        self.btn_overlay_cancel.clicked.connect(self._cancel_active_hydration)
        ov_btn_row.addWidget(self.btn_overlay_cancel)
        ov_l.addWidget(self.lbl_overlay_title)
        ov_l.addWidget(self.lbl_overlay_sub)
        ov_l.addWidget(self.overlay_progress)
        ov_l.addLayout(ov_btn_row)
        self.loading_overlay_card.hide()

        ws_body_row = QHBoxLayout()
        ws_body_row.setContentsMargins(0, 0, 0, 0)
        ws_body_row.setSpacing(6)
        self._ws_body_row = ws_body_row
        self.floating_palette = self._build_floating_mini_palette()
        ws_body_row.addWidget(self.floating_palette, 0)
        ws_body_row.addWidget(self.workspace_view_stack, 1)
        ws_layout.addLayout(ws_body_row, 1)

        self.splitter.addWidget(self.catalog_panel)
        self.splitter.addWidget(self.workspace_wrap)
        self.splitter.setSizes([305, 820])

        # ---- Footer Status Bar ----
        self.lbl_status = QLabel("")
        self.lbl_status.setProperty("role", "muted")
        self.lbl_status.setContentsMargins(4, 2, 4, 2)
        self.lbl_status.setToolTip(
            f"{tr('status_cached_desc', self.config.language)}\n{tr('status_live_desc', self.config.language)}"
        )
        main_layout.addWidget(self.lbl_status)

    def _apply_theme(self) -> None:
        resolved = ThemeManager.resolve_mode(getattr(self.config, "theme", None))
        self.setProperty("dashboard_theme", resolved)
        self.setStyleSheet(ThemeManager.get_stylesheet(theme_mode=resolved))
        for card in (self.findChildren(ResizableCardFrame) or []):
            if hasattr(card, "apply_theme"):
                card.apply_theme(resolved)
        for chart in (self.findChildren(InteractiveChartWidget) or []):
            if hasattr(chart, "canvas") and chart.canvas is not None:
                chart.canvas.update()
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None:
            self.workspace_canvas.update()
        if hasattr(self, "floating_palette") and self.floating_palette is not None and not getattr(self, "_palette_docked", True):
            self.floating_palette.setStyleSheet(ThemeManager.get_stylesheet(theme_mode=resolved))

    def _retranslate_ui(self) -> None:
        lang = self.config.language or "et"
        self.setWindowTitle(tr("plugin_title", lang))
        title_txt = (
            self.config.title_en if lang == "en" and self.config.title_en else self.config.title
        )
        self.lbl_title.setText(f"📊 {title_txt}")
        if hasattr(self, "lbl_dock_bar_title"):
            base_bar = f"📊 {tr('plugin_title', lang)}"
            self.lbl_dock_bar_title.setText(
                tr("dock_shaded_status", lang) if getattr(self, "_dock_shaded", False) else base_bar
            )
            self.btn_dock_shade.setToolTip(tr("dock_shade_tip", lang))
            self.btn_dock_minimize.setToolTip(tr("dock_minimize_tip", lang))
            self.btn_dock_float.setToolTip(tr("dock_float_tip", lang))
            self.btn_dock_maximize.setToolTip(tr("dock_maximize_tip", lang))
            self.btn_dock_close.setToolTip(tr("dock_close_tip", lang))

        on_home = hasattr(self, "studio_stack") and self.studio_stack.currentIndex() == 0
        self.btn_home_view.setText(tr("home_workspace_btn" if on_home else "home_tab_btn", lang))
        self.btn_toggle_cat.setText(tr("cat_title", lang))
        if hasattr(self, "btn_mini_bar"):
            self.btn_mini_bar.setText(f"🧰 {tr('mini_bar_toggle', lang)}")
            self.btn_mini_bar.setToolTip(tr("tip_mini_bar", lang))
        self._retranslate_floating_palette(lang)
        self.btn_add_map.setText(tr("btn_add_map", lang))
        self.btn_add_widget.setText(tr("btn_add_widget", lang))
        self.btn_add_slicer.setText(tr("btn_add_slicer", lang))
        self.btn_auto_layout.setText(tr("btn_auto_layout", lang))
        if hasattr(self, "btn_templates"):
            self.btn_templates.setText(tr("btn_designer_templates", lang))
            self._rebuild_templates_menu(lang)
        self.btn_sources.setText(tr("btn_sources", lang))
        self.btn_extent_filter.setText(
            tr("btn_extent_on", lang) if self._extent_filter_enabled else tr("btn_extent_off", lang)
        )
        self.btn_reset_filters.setText(tr("btn_reset_filters", lang))
        self._rebuild_refresh_menu(lang)
        self.btn_catalog.setText(tr("btn_catalog", lang))
        self.btn_settings.setText(tr("btn_settings", lang))
        self.btn_lang.setText(tr("lang_toggle", lang))
        if hasattr(self, "btn_save_dashboard"):
            self.btn_save_dashboard.setText(tr("btn_save_dashboard", lang))
        self.btn_export.setText(tr("btn_export_html", lang))

        self.left_tabs.setTabText(0, tr("tab_catalog", lang))
        self.left_tabs.setTabText(1, tr("tab_connections", lang))

        self.lbl_cat_title.setText(tr("cat_title", lang))
        self.lbl_cat_subtitle.setText(tr("cat_subtitle", lang))
        self.ed_cat_search.setPlaceholderText(tr("cat_search", lang))
        self.btn_cat_refresh.setToolTip(tr("cat_refresh_tip", lang))
        self.btn_cat_add_srv.setText(tr("cat_add_server", lang))
        self.btn_cat_add_xl.setText(tr("cat_add_excel", lang))

        self.lbl_conn_title.setText(tr("conn_panel_title", lang))
        if hasattr(self.connections_list, "lang"):
            self.connections_list.lang = lang
        if hasattr(self, "home_recents_list") and hasattr(self.home_recents_list, "lang"):
            self.home_recents_list.lang = lang
        if hasattr(self, "home_saved_list") and hasattr(self.home_saved_list, "lang"):
            self.home_saved_list.lang = lang
        self.btn_conn_edit.setText(tr("conn_edit_btn", lang))
        self.btn_conn_load.setText(tr("conn_load_qgis", lang))
        self.btn_conn_remove.setText(tr("conn_remove_btn", lang))
        self.lbl_design_size.setText(tr("design_size", lang) + ":")
        if hasattr(self, "btn_save_preset"):
            self.btn_save_preset.setToolTip(tr("btn_save_preset_tip", lang))
        if hasattr(self, "btn_delete_preset"):
            self.btn_delete_preset.setToolTip(tr("btn_delete_preset_tip", lang))
        self._rebuild_preset_combo(lang)
        self._rebuild_border_menu(lang)
        self._rebuild_grid_menu(lang)
        if hasattr(self, "btn_pan"):
            self.btn_pan.setText(tr("design_pan", lang))
            self.btn_pan.setToolTip(tr("tip_design_pan", lang))
        if hasattr(self, "btn_zoom_out"):
            self.btn_zoom_out.setToolTip(tr("tip_zoom_out", lang))
        if hasattr(self, "btn_zoom_reset"):
            self.btn_zoom_reset.setToolTip(tr("tip_zoom_reset", lang))
        if hasattr(self, "btn_zoom_in"):
            self.btn_zoom_in.setToolTip(tr("tip_zoom_in", lang))
        if hasattr(self, "btn_zoom_fit"):
            self.btn_zoom_fit.setText(tr("btn_zoom_fit", lang))
            self.btn_zoom_fit.setToolTip(tr("tip_zoom_fit", lang))
        if hasattr(self, "btn_toggle_wires"):
            self.btn_toggle_wires.setText(tr("btn_toggle_wires", lang))
            self.btn_toggle_wires.setToolTip(tr("tip_toggle_wires", lang))
        if hasattr(self, "lbl_overlay_title"):
            self.lbl_overlay_title.setText(f"⏳ {tr('loading_overlay_title', lang)}")
            if hasattr(self, "btn_overlay_cancel"):
                self.btn_overlay_cancel.setText("× " + ("Katkesta" if lang == "et" else "Cancel"))
        self._rebuild_preview_menu(lang)
        self.btn_model_conns.setText(f"🕸️ {tr('btn_model_conns', lang)} ({len(self.config.widget_connections)})")
        self.btn_conn_jump.setText(f"🔗 {tr('tab_connections', lang)} ({len(self.config.data_sources)})")

        # Home View translations
        if hasattr(self, "lbl_home_title"):
            self.lbl_home_title.setText(f"📊 {tr('home_welcome_title', lang)}")
            self.lbl_home_sub.setText(tr("home_welcome_sub", lang))
            self.lbl_home_resume_title.setText(f"📂 {tr('home_resume_title', lang)}")
            self.btn_home_resume.setText(tr("home_btn_resume", lang))
            self.btn_home_new.setText(tr("home_btn_new", lang))
            if hasattr(self, "lbl_home_saved_title"):
                self.lbl_home_saved_title.setText(f"💾 {tr('home_saved_title', lang)}")
                self.lbl_home_saved_empty.setText(tr("home_no_saved", lang))
                self.btn_home_load_saved.setText(tr("home_load_saved", lang))
                self._update_home_saved_action_labels()
            self.lbl_home_recents_title.setText(f"🕒 {tr('home_recents_title', lang)}")
            self.lbl_home_recents_empty.setText(tr("home_no_recents", lang))
            if hasattr(self, "lbl_home_recents_hint"):
                self.lbl_home_recents_hint.setText(tr("home_recents_hint", lang))
            self.btn_home_open_recent.setText("▶ " + ("Ava valitud" if lang == "et" else "Open Selected"))
            self._update_home_recent_action_labels()
            self.lbl_home_templates_title.setText(f"🧭 {tr('home_templates_title', lang)}")
            if hasattr(self, "lbl_home_empty_templates_title"):
                self.lbl_home_empty_templates_title.setText(
                    f"📐 {tr('home_empty_templates_title', lang)}"
                )
            self.btn_home_sharepoint.setText(tr("btn_catalog", lang))
            for btn, tkey, _fname in getattr(self, "_home_empty_preset_buttons", []):
                btn.setText(tr(tkey, lang))
            for btn, tkey, _fname in getattr(self, "_home_preset_buttons", []):
                btn.setText(tr(tkey, lang))

        # Preview Panel translations
        if hasattr(self, "lbl_preview_title"):
            self.lbl_preview_title.setText(tr("preview_title", lang))
            if hasattr(self, "lbl_preview_tier"):
                self.lbl_preview_tier.setText(tr("preview_tier_label", lang))
            if hasattr(self, "cb_preview_tier"):
                cur_t = str(getattr(self.config, "export_tier", "full") or "full").lower()
                self.cb_preview_tier.blockSignals(True)
                self.cb_preview_tier.setItemText(0, tr("export_tier_full", lang))
                self.cb_preview_tier.setItemText(1, tr("export_tier_medium", lang))
                self.cb_preview_tier.setItemText(2, tr("export_tier_minimal", lang))
                idx_pt = self.cb_preview_tier.findData(cur_t)
                if idx_pt >= 0:
                    self.cb_preview_tier.setCurrentIndex(idx_pt)
                self.cb_preview_tier.blockSignals(False)
            self.btn_preview_refresh.setText(tr("preview_refresh_btn", lang))
            self.btn_preview_browser.setText(tr("preview_open_browser", lang))
            self.btn_preview_back.setText(tr("preview_back_btn", lang))
            if hasattr(self, "btn_preview_browser_center"):
                self.btn_preview_browser_center.setText(tr("preview_open_browser", lang))
            if self._preview_web_view is not None:
                self.lbl_preview_info.setText(tr("preview_sub_embedded", lang))
            else:
                self.lbl_preview_info.setText(tr("preview_sub_browser", lang))

        if not self._refresh_thread_active:
            n_cached = self.catalog_manager.total_cached_layers()
            self.lbl_cat_status.setText(tr("cat_ready", lang, count=n_cached))
        if hasattr(self, "lbl_status"):
            self.lbl_status.setToolTip(
                f"{tr('status_cached_desc', lang)}\n{tr('status_live_desc', lang)}"
            )
        if hasattr(self, "btn_add_page"):
            self.btn_add_page.setText(tr("add_page", lang))
            self.btn_rename_page.setToolTip(tr("rename_page", lang))
            self.btn_del_page.setToolTip(tr("delete_page", lang))
            self._refresh_page_bar()
        if hasattr(self, "lbl_active_filters_hdr"):
            self.lbl_active_filters_hdr.setText(f"⚡ {tr('active_filters_label', lang)}")
            self.btn_clear_all_banner.setText(tr("btn_reset_filters", lang))
            self._refresh_active_filters_banner()

    def _toggle_catalog_sidebar(self) -> None:
        self.catalog_panel.setVisible(self.btn_toggle_cat.isChecked())

    def _build_floating_mini_palette(self) -> QWidget:
        self._palette_docked = True
        return _HoverMiniToolbar(
            on_action=self._on_mini_palette_action,
            on_toggle_dock=self._toggle_palette_dock_mode,
            lang=self.config.language or "et",
            parent=self,
        )

    def _retranslate_floating_palette(self, lang: str) -> None:
        if hasattr(self, "floating_palette") and self.floating_palette is not None:
            self.floating_palette.retranslate(lang)

    def _toggle_floating_palette(self) -> None:
        if not hasattr(self, "floating_palette") or self.floating_palette is None:
            return
        vis = bool(self.btn_mini_bar.isChecked())
        self.floating_palette.setVisible(vis)
        if vis and not getattr(self, "_palette_docked", True):
            self.floating_palette.raise_()

    def _toggle_palette_dock_mode(self) -> None:
        if not hasattr(self, "floating_palette") or self.floating_palette is None:
            return
        docked = not getattr(self, "_palette_docked", True)
        self._palette_docked = docked
        if docked:
            self.floating_palette.set_docked(True)
            self.floating_palette.setParent(self)
            self.floating_palette.setStyleSheet("")
            self._ws_body_row.insertWidget(0, self.floating_palette, 0)
            self.floating_palette.show()
        else:
            self._ws_body_row.removeWidget(self.floating_palette)
            anchor = QtCore.QPoint(120, 120)
            try:
                if hasattr(self, "workspace_view_stack") and self.workspace_view_stack is not None:
                    anchor = self.workspace_view_stack.mapToGlobal(QtCore.QPoint(14, 14))
            except Exception:
                pass
            win = self.window() if hasattr(self, "window") else None
            host_parent = win if (win is not None and win is not self and win is not getattr(self, "workspace_view_stack", None)) else None
            self.floating_palette.setParent(host_parent)
            self.floating_palette.set_docked(False)
            resolved = ThemeManager.resolve_mode(getattr(self.config, "theme", None))
            self.floating_palette.setStyleSheet(ThemeManager.get_stylesheet(theme_mode=resolved))
            self.floating_palette.move(int(anchor.x()), int(anchor.y()))
            self.floating_palette.show()
            self.floating_palette.raise_()

    _EMPTY_STARTER_PRESETS: Tuple[Tuple[str, str], ...] = (
        ("menu_empty_map_kpi_table", "empty_map_kpi_table_filter.qdash.json"),
        ("menu_empty_map_charts", "empty_map_charts_filter.qdash.json"),
        ("menu_empty_analytics_grid", "empty_analytics_grid.qdash.json"),
        ("menu_empty_blank_canvas", "empty_blank_canvas.qdash.json"),
    )

    def _rebuild_templates_menu(self, lang: Optional[str] = None) -> None:
        if not hasattr(self, "_templates_menu") or self._templates_menu is None:
            return
        cur_lang = lang or self.config.language or "et"
        self._templates_menu.clear()
        for tkey, fname in self._EMPTY_STARTER_PRESETS:
            act = QAction(tr(tkey, cur_lang), self._templates_menu)
            act.triggered.connect(
                lambda _c=False, f=fname: self._apply_empty_template_from_designer(f)
            )
            self._templates_menu.addAction(act)

    def _apply_empty_template_from_designer(self, filename: str) -> None:
        has_content = bool(
            getattr(self.config, "widgets", None)
            or getattr(self.config, "slicers", None)
            or getattr(self.config, "data_sources", None)
        )
        if has_content and not os.environ.get("PYTEST_CURRENT_TEST"):
            lang = self.config.language or "et"
            yes_btn = qt_enum(QMessageBox, "StandardButton", "Yes")
            no_btn = qt_enum(QMessageBox, "StandardButton", "No")
            try:
                resp = QMessageBox.question(
                    self,
                    tr("btn_designer_templates", lang),
                    tr("confirm_load_empty_tpl", lang),
                    yes_btn | no_btn,
                )
            except TypeError:
                resp = QMessageBox.question(
                    self,
                    tr("btn_designer_templates", lang),
                    tr("confirm_load_empty_tpl", lang),
                )
            if resp is False or (
                resp is not None and not isinstance(resp, bool) and resp != yes_btn
            ):
                return
        self._load_bundled_preset(filename)

    def _rebuild_border_menu(self, lang: Optional[str] = None) -> None:
        if not hasattr(self, "_border_menu") or self._border_menu is None:
            return
        cur_lang = lang or self.config.language or "et"
        self._border_menu.clear()
        self._border_actions.clear()
        for bstyle, bkey in (
            ("none", "border_none"),
            ("solid", "border_solid"),
            ("dashed", "border_dashed"),
            ("dotted", "border_dotted"),
            ("double", "border_double"),
            ("shadow", "border_shadow"),
        ):
            act = QAction(tr(bkey, cur_lang), self._border_menu)
            act.setCheckable(True)
            act.triggered.connect(lambda _c=False, s=bstyle: self._set_border_style_from_menu(s))
            self._border_menu.addAction(act)
            self._border_actions[bstyle] = act
        self._border_menu.addSeparator()
        act_cfg = QAction(tr("sett_border_color_btn", cur_lang), self._border_menu)
        act_cfg.triggered.connect(lambda _checked=False: self.open_settings_dialog(initial_tab=1))
        self._border_menu.addAction(act_cfg)
        self._update_border_button_state()

    def _update_border_button_state(self) -> None:
        if not hasattr(self, "btn_border") or self.btn_border is None:
            return
        lang = self.config.language or "et"
        show_b = bool(getattr(self.config, "show_design_border", True))
        cur_bs = str(getattr(self.config, "canvas_border_style", "dashed") or "dashed").lower()
        active_key = cur_bs if (show_b and cur_bs != "none") else "none"
        key_map = {
            "none": "border_none",
            "solid": "border_solid",
            "dashed": "border_dashed",
            "dotted": "border_dotted",
            "double": "border_double",
            "shadow": "border_shadow",
        }
        for s, act in getattr(self, "_border_actions", {}).items():
            act.setChecked(s == active_key)
        style_lbl = tr(key_map.get(active_key, "border_dashed"), lang)
        self.btn_border.setText(f"{tr('design_border', lang)}: {style_lbl}")

    def _set_border_style_from_menu(self, style_id: str) -> None:
        style_clean = str(style_id or "none").strip().lower()
        if style_clean == "none":
            self.config.show_design_border = False
            self.config.canvas_border_style = "none"
        else:
            self.config.show_design_border = True
            self.config.canvas_border_style = style_clean
        self._sync_design_controls()
        self._save_project_state()

    def _on_pan_toggled(self) -> None:
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None and hasattr(self, "btn_pan"):
            enabled = bool(self.btn_pan.isChecked())
            self.workspace_canvas.set_pan_mode(enabled)
            if hasattr(self, "floating_palette") and self.floating_palette is not None and hasattr(self.floating_palette, "set_pan_checked"):
                self.floating_palette.set_pan_checked(enabled)

    def _step_canvas_zoom(self, delta: int) -> None:
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None:
            self.workspace_canvas.step_zoom(delta)

    def _reset_canvas_zoom(self) -> None:
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None:
            self.workspace_canvas.set_zoom(1.0)

    def _fit_canvas_zoom(self) -> None:
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None:
            self.workspace_canvas.fit_to_view()

    def _on_canvas_zoom_changed(self, zoom: float) -> None:
        if hasattr(self, "btn_zoom_reset") and self.btn_zoom_reset is not None:
            self.btn_zoom_reset.setText(f"{int(round(float(zoom or 1.0) * 100))}%")
        if hasattr(self, "_update_adjacent_card_borders"):
            self._update_adjacent_card_borders()

    def _on_mini_palette_action(self, action_id: str) -> None:
        if action_id == "slicer":
            self.open_add_slicer()
        elif action_id == "conns":
            self._open_model_connections_dialog()
        elif action_id == "pan":
            if hasattr(self, "btn_pan") and self.btn_pan is not None:
                mini_btn = getattr(getattr(self, "floating_palette", None), "btn_pan_mini", None)
                state = bool(mini_btn.isChecked()) if mini_btn is not None else (not self.btn_pan.isChecked())
                self.btn_pan.blockSignals(True)
                self.btn_pan.setChecked(state)
                self.btn_pan.blockSignals(False)
                self._on_pan_toggled()
        elif action_id == "zoom_in":
            self._step_canvas_zoom(1)
        elif action_id == "zoom_out":
            self._step_canvas_zoom(-1)
        elif action_id == "zoom_fit":
            self._fit_canvas_zoom()
        else:
            self.open_add_widget(preset_type=action_id)

    def _all_presets_list(self, lang: Optional[str] = None) -> List[Dict[str, Any]]:
        cur_lang = lang or getattr(self.config, "language", "et") or "et"
        out: List[Dict[str, Any]] = [
            {"id": pid, "name": tr(key, cur_lang), "w": pw, "h": ph, "custom": False}
            for pid, key, pw, ph in _BUILTIN_CANVAS_PRESETS
        ]
        for cp in _load_custom_canvas_presets():
            out.append(dict(cp))
        return out

    def _rebuild_preset_combo(self, lang: Optional[str] = None) -> None:
        if not hasattr(self, "cb_preset") or self.cb_preset is None:
            return
        cur_lang = lang or getattr(self.config, "language", "et") or "et"
        presets = self._all_presets_list(cur_lang)
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None and hasattr(self.workspace_canvas, "board"):
            self.workspace_canvas.board._available_presets = list(presets)
            self.workspace_canvas.board._lang = cur_lang
        cur_id = str(getattr(self.config, "canvas_preset", "1280x720") or "1280x720")
        cur_id = _LEGACY_PRESET_KEY_MAP.get(cur_id, cur_id)
        self.cb_preset.blockSignals(True)
        self.cb_preset.clear()
        for p in presets:
            prefix = "★ " if p.get("custom") else ""
            lbl = p["name"] if not p.get("custom") else f"{prefix}{p['name']} ({p['w']}×{p['h']})"
            self.cb_preset.addItem(lbl, p["id"])
        self.cb_preset.addItem(tr("preset_custom", cur_lang), "custom")
        idx = self.cb_preset.findData(cur_id)
        if idx < 0:
            w_val = int(getattr(self.config, "canvas_width", 1280) or 1280)
            h_val = int(getattr(self.config, "canvas_height", 720) or 720)
            matched = next((p["id"] for p in presets if p["w"] == w_val and p["h"] == h_val), "custom")
            idx = self.cb_preset.findData(matched)
        self.cb_preset.setCurrentIndex(idx if idx >= 0 else self.cb_preset.count() - 1)
        self.cb_preset.blockSignals(False)
        self._update_preset_delete_enabled()

    def _update_preset_delete_enabled(self) -> None:
        if not hasattr(self, "btn_delete_preset") or self.btn_delete_preset is None:
            return
        cur_data = str(self.cb_preset.currentData() or "custom")
        custom_ids = {str(p.get("id") or "") for p in _load_custom_canvas_presets()}
        self.btn_delete_preset.setEnabled(cur_data in custom_ids)

    def _on_save_custom_preset(self) -> None:
        lang = getattr(self.config, "language", "et") or "et"
        cw = max(480, min(3840, int(getattr(self.config, "canvas_width", 1280) or 1280)))
        ch = max(320, min(2160, int(getattr(self.config, "canvas_height", 720) or 720)))
        default_name = f"Kohandatud {cw}×{ch}" if lang == "et" else f"Custom {cw}×{ch}"
        if QInputDialog is None:
            return
        raw_name, ok = QInputDialog.getText(
            self,
            tr("dlg_save_preset_title", lang),
            tr("dlg_save_preset_prompt", lang, w=cw, h=ch),
            text=default_name,
        )
        if not ok:
            return
        pname = str(raw_name or "").strip()
        if not pname:
            return
        pid = f"custom_{int(time.time() * 1000)}"
        items = _load_custom_canvas_presets()
        items.append({"id": pid, "name": pname, "w": cw, "h": ch, "custom": True})
        _save_custom_canvas_presets(items)
        self.config.canvas_preset = pid
        self._rebuild_preset_combo(lang)
        self._sync_design_controls()
        self._save_project_state()

    def _on_delete_custom_preset(self) -> None:
        lang = getattr(self.config, "language", "et") or "et"
        cur_id = str(self.cb_preset.currentData() or "")
        items = _load_custom_canvas_presets()
        target = next((p for p in items if p.get("id") == cur_id), None)
        if target is None:
            return
        if QMessageBox is not None:
            yes_btn = _safe_qt_enum(QMessageBox, "StandardButton", "Yes", 16384)
            no_btn = _safe_qt_enum(QMessageBox, "StandardButton", "No", 65536)
            resp = QMessageBox.question(
                self,
                tr("confirm_delete_preset_title", lang),
                tr("confirm_delete_preset_body", lang, name=target["name"]),
                yes_btn | no_btn,
            )
            if resp != yes_btn:
                return
        remaining = [p for p in items if p.get("id") != cur_id]
        _save_custom_canvas_presets(remaining)
        self.config.canvas_preset = "custom"
        self._rebuild_preset_combo(lang)
        self._sync_design_controls()
        self._save_project_state()

    def _on_refresh_button_clicked(self) -> None:
        if getattr(self, "_refresh_menu", None) is not None and self.btn_refresh.menu() is not None:
            return
        self.reload_and_hydrate(force_refresh_sources=True)

    def _rebuild_refresh_menu(self, lang: Optional[str] = None) -> None:
        if not hasattr(self, "btn_refresh") or self.btn_refresh is None:
            return
        cur_lang = lang or getattr(self.config, "language", "et") or "et"
        pages = list(getattr(self.config, "pages", []) or [])
        base_lbl = tr("btn_refresh", cur_lang)
        if len(pages) <= 1:
            self.btn_refresh.setMenu(None)
            self.btn_refresh.setText(base_lbl)
            return

        if getattr(self, "_refresh_menu", None) is None:
            self._refresh_menu = QMenu(self.btn_refresh)
        else:
            self._refresh_menu.clear()

        active_id = getattr(self.config, "active_page_id", "") or pages[0].id
        if not any(p.id == active_id for p in pages):
            active_id = pages[0].id
        ordered_pages = [p for p in pages if p.id == active_id] + [p for p in pages if p.id != active_id]

        for pg in ordered_pages:
            ptitle = pg.title_en if (cur_lang == "en" and getattr(pg, "title_en", "")) else pg.title
            pg_layers = self.persistence.referenced_layer_names(self.config, page_id=pg.id)
            n = len(pg_layers)
            cnt_txt = (
                tr("refresh_menu_page_layer_one", cur_lang)
                if n == 1
                else tr("refresh_menu_page_layers", cur_lang, n=n)
            )
            if pg.id == active_id:
                item_lbl = f"↻ {ptitle} ({cnt_txt} · {tr('refresh_menu_current_badge', cur_lang)})"
            else:
                item_lbl = f"↻ {ptitle} ({cnt_txt})"
            act_pg = QAction(item_lbl, self._refresh_menu)
            act_pg.setEnabled(n > 0)
            act_pg.triggered.connect(
                lambda _c=False, pid=pg.id: self.reload_and_hydrate(force_refresh_sources=True, page_id=pid)
            )
            self._refresh_menu.addAction(act_pg)

        self._refresh_menu.addSeparator()
        all_layers = self.persistence.referenced_layer_names(self.config)
        all_lbl = (
            tr("refresh_menu_all_pages_count", cur_lang, n=len(all_layers))
            if all_layers
            else tr("refresh_menu_all_pages", cur_lang)
        )
        act_all = QAction(f"↻ {all_lbl}", self._refresh_menu)
        act_all.triggered.connect(
            lambda _c=False: self.reload_and_hydrate(force_refresh_sources=True, page_id=None)
        )
        self._refresh_menu.addAction(act_all)
        self.btn_refresh.setMenu(self._refresh_menu)
        self.btn_refresh.setText(base_lbl if base_lbl.endswith("▾") else f"{base_lbl} ▾")

    def _rebuild_grid_menu(self, lang: Optional[str] = None) -> None:
        if not hasattr(self, "_grid_menu") or self._grid_menu is None:
            return
        cur_lang = lang or getattr(self.config, "language", "et") or "et"
        self._grid_menu.clear()
        self._grid_density_actions.clear()
        self._act_grid_show = QAction(tr("grid_show_toggle", cur_lang), self._grid_menu)
        self._act_grid_show.setCheckable(True)
        self._act_grid_show.triggered.connect(self._toggle_show_grid_from_menu)
        self._grid_menu.addAction(self._act_grid_show)

        self._grid_menu.addSeparator()
        hdr = QAction(tr("grid_density_label", cur_lang), self._grid_menu)
        hdr.setEnabled(False)
        self._grid_menu.addAction(hdr)
        for step_px in (10, 20, 25, 40):
            act = QAction(f"{step_px} px", self._grid_menu)
            act.setCheckable(True)
            act.triggered.connect(lambda _c=False, sp=step_px: self._set_grid_density_from_menu(sp))
            self._grid_menu.addAction(act)
            self._grid_density_actions[step_px] = act

        self._grid_menu.addSeparator()
        self._act_grid_snap = QAction(tr("design_snap", cur_lang), self._grid_menu)
        self._act_grid_snap.setCheckable(True)
        self._act_grid_snap.triggered.connect(self._toggle_snap_from_menu)
        self._grid_menu.addAction(self._act_grid_snap)
        self._update_grid_button_state()

    def _update_grid_button_state(self) -> None:
        if not hasattr(self, "btn_grid_menu") or self.btn_grid_menu is None:
            return
        lang = getattr(self.config, "language", "et") or "et"
        show_g = bool(getattr(self.config, "show_grid", True))
        step_px = int(getattr(self.config, "grid_size", 20) or 20)
        snap_g = bool(getattr(self.config, "snap_to_grid", True))
        if self._act_grid_show is not None:
            self._act_grid_show.setChecked(show_g)
        for sp, act in getattr(self, "_grid_density_actions", {}).items():
            act.setChecked(sp == step_px)
        if self._act_grid_snap is not None:
            self._act_grid_snap.setChecked(snap_g)
        step_txt = f"{step_px}px" if show_g else tr("grid_off_short", lang)
        snap_badge = " 🧲" if snap_g else ""
        self.btn_grid_menu.setText(f"{tr('design_grid', lang)}: {step_txt}{snap_badge}")

    def _toggle_show_grid_from_menu(self) -> None:
        self.config.show_grid = not bool(getattr(self.config, "show_grid", True))
        self._sync_design_controls()
        self._save_project_state()

    def _set_grid_density_from_menu(self, step_px: int) -> None:
        self.config.grid_size = max(5, int(step_px))
        self.config.show_grid = True
        self._sync_design_controls()
        self._save_project_state()

    def _toggle_snap_from_menu(self) -> None:
        self.config.snap_to_grid = not bool(getattr(self.config, "snap_to_grid", True))
        self._sync_design_controls()
        self._save_project_state()

    def _rebuild_preview_menu(self, lang: Optional[str] = None) -> None:
        if not hasattr(self, "_preview_menu") or self._preview_menu is None:
            return
        cur_lang = lang or getattr(self.config, "language", "et") or "et"
        self._preview_menu.clear()
        self._preview_actions.clear()
        cur_tier = str(getattr(self.config, "export_tier", "full") or "full").lower()
        in_preview = bool(getattr(self.config, "preview_mode", False))
        for tier_id, tier_key in (
            ("full", "export_tier_full"),
            ("medium", "export_tier_medium"),
            ("minimal", "export_tier_minimal"),
        ):
            act = QAction(tr(tier_key, cur_lang), self._preview_menu)
            act.setCheckable(True)
            act.setChecked(in_preview and cur_tier == tier_id)
            act.triggered.connect(lambda _c=False, t=tier_id: self._enter_preview_with_tier(t))
            self._preview_menu.addAction(act)
            self._preview_actions[tier_id] = act
        if in_preview:
            self._preview_menu.addSeparator()
            act_exit = QAction(tr("preview_exit_to_designer", cur_lang), self._preview_menu)
            act_exit.triggered.connect(lambda _c=False: self._exit_preview_mode())
            self._preview_menu.addAction(act_exit)
        if hasattr(self, "btn_preview") and self.btn_preview is not None:
            short_tier = {"full": "Full", "medium": "Med", "minimal": "Mini"}.get(cur_tier, "Full")
            base_lbl = tr("design_preview", cur_lang)
            self.btn_preview.setText(f"{base_lbl} · {short_tier}" if in_preview else base_lbl)

    def _enter_preview_with_tier(self, tier: str) -> None:
        tier_clean = str(tier or "full").strip().lower()
        if tier_clean not in ("full", "medium", "minimal"):
            tier_clean = "full"
        self.config.export_tier = tier_clean
        self.config.preview_mode = True
        self._sync_design_controls()
        self._save_project_state()
        self._show_workspace_view()
        self._refresh_html_preview(force=True, open_external_if_fallback=True)

    def _exit_preview_mode(self) -> None:
        self.config.preview_mode = False
        if hasattr(self, "workspace_view_stack"):
            self.workspace_view_stack.setCurrentIndex(0)
        self._sync_design_controls()
        self._save_project_state()

    def _jump_to_connections_tab(self) -> None:
        self.catalog_panel.setVisible(True)
        self.btn_toggle_cat.setChecked(True)
        self.left_tabs.setCurrentIndex(1)
        self.refresh_connections_panel()

    def _sync_design_controls(self) -> None:
        ctrls = [
            self.cb_preset,
            self.sp_canvas_w,
            self.sp_canvas_h,
        ]
        if hasattr(self, "btn_toggle_wires"):
            ctrls.append(self.btn_toggle_wires)
        for obj in ctrls:
            obj.blockSignals(True)
        lang = getattr(self.config, "language", "et") or "et"
        raw_preset = str(getattr(self.config, "canvas_preset", "1280x720") or "1280x720")
        raw_preset = _LEGACY_PRESET_KEY_MAP.get(raw_preset, raw_preset)
        idx_p = self.cb_preset.findData(raw_preset)
        if idx_p >= 0:
            self.cb_preset.setCurrentIndex(idx_p)
        else:
            idx_cust = self.cb_preset.findData("custom")
            if idx_cust >= 0:
                self.cb_preset.setCurrentIndex(idx_cust)
        self._update_preset_delete_enabled()
        self.sp_canvas_w.setValue(int(getattr(self.config, "canvas_width", 1280) or 1280))
        self.sp_canvas_h.setValue(int(getattr(self.config, "canvas_height", 720) or 720))
        self._update_border_button_state()
        self._update_grid_button_state()
        self._rebuild_preview_menu(lang)
        if hasattr(self, "btn_toggle_wires"):
            self.btn_toggle_wires.setChecked(bool(getattr(self.config, "show_connection_wires", True)))
        if hasattr(self, "cb_preview_tier"):
            self.cb_preview_tier.blockSignals(True)
            idx_pt = self.cb_preview_tier.findData(str(getattr(self.config, "export_tier", "full") or "full").lower())
            if idx_pt >= 0:
                self.cb_preview_tier.setCurrentIndex(idx_pt)
            self.cb_preview_tier.blockSignals(False)
        for obj in ctrls:
            obj.blockSignals(False)
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None and hasattr(self.workspace_canvas, "board"):
            self.workspace_canvas.board._available_presets = self._all_presets_list(lang)
            self.workspace_canvas.board._lang = lang
        self.workspace_canvas.apply_design_settings(
            canvas_w=self.sp_canvas_w.value(),
            canvas_h=self.sp_canvas_h.value(),
            show_border=bool(getattr(self.config, "show_design_border", True)),
            show_grid=bool(getattr(self.config, "show_grid", True)),
            snap_to_grid=bool(getattr(self.config, "snap_to_grid", True)),
            grid_size=int(getattr(self.config, "grid_size", 20) or 20),
            preview_mode=bool(getattr(self.config, "preview_mode", False)),
            border_style=str(getattr(self.config, "canvas_border_style", "dashed") or "dashed"),
            border_color=str(getattr(self.config, "canvas_border_color", "#38bdf8") or "#38bdf8"),
            border_width=int(getattr(self.config, "canvas_border_width", 2) or 2),
            border_radius=int(getattr(self.config, "canvas_border_radius", 10) if getattr(self.config, "canvas_border_radius", None) is not None else 10),
        )
        self._update_canvas_wires()

    def _on_preset_changed(self, _idx: int) -> None:
        preset = str(self.cb_preset.currentData() or "custom")
        preset = _LEGACY_PRESET_KEY_MAP.get(preset, preset)
        self.config.canvas_preset = preset
        matched = next((p for p in self._all_presets_list() if p["id"] == preset), None)
        if matched is not None:
            self.config.canvas_width = int(matched["w"])
            self.config.canvas_height = int(matched["h"])
        elif "x" in preset:
            try:
                w_str, h_str = preset.split("x", 1)
                self.config.canvas_width = int(w_str)
                self.config.canvas_height = int(h_str)
            except Exception:
                pass
        self._sync_design_controls()
        self._save_project_state()

    def _on_canvas_dims_edited(self) -> None:
        self.config.canvas_preset = "custom"
        self.config.canvas_width = int(self.sp_canvas_w.value())
        self.config.canvas_height = int(self.sp_canvas_h.value())
        self._sync_design_controls()
        self._save_project_state()

    def _on_artboard_drag_resized(self, nw: int, nh: int) -> None:
        snapped_id = None
        if hasattr(self, "workspace_canvas") and self.workspace_canvas is not None and hasattr(self.workspace_canvas, "board"):
            snapped_id = getattr(self.workspace_canvas.board, "_last_snapped_preset_id", None)
            self.workspace_canvas.board._last_snapped_preset_id = None
        self.config.canvas_preset = str(snapped_id or "custom")
        self.config.canvas_width = int(nw)
        self.config.canvas_height = int(nh)
        self._sync_design_controls()
        self._save_project_state()

    def _on_design_toggled(self) -> None:
        was_preview = bool(getattr(self.config, "preview_mode", False))
        if hasattr(self, "btn_toggle_wires"):
            self.config.show_connection_wires = self.btn_toggle_wires.isChecked()
        self._sync_design_controls()
        self._save_project_state()
        if getattr(self.config, "preview_mode", False):
            self._show_workspace_view()
            if not was_preview or not getattr(self, "_preview_loaded_once", False):
                self._refresh_html_preview(open_external_if_fallback=True)
        else:
            if hasattr(self, "workspace_view_stack"):
                self.workspace_view_stack.setCurrentIndex(0)

    # ------------------------------------------------------------------
    # Home View & Recent Workspaces (<= 10 MRU)
    # ------------------------------------------------------------------

    def _build_home_view(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(qt_enum(QFrame, "Shape", "NoFrame"))
        scroll.setObjectName("HomeScroll")

        container = QWidget()
        container.setObjectName("HomeContent")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(18, 16, 18, 18)
        layout.setSpacing(12)

        def _apply_card_shadow(frame: QFrame) -> None:
            try:
                eff = QGraphicsDropShadowEffect(frame)
                eff.setBlurRadius(18)
                eff.setOffset(0, 3)
                eff.setColor(QColor(15, 23, 42, 32))
                frame.setGraphicsEffect(eff)
            except Exception:
                pass

        # Welcome Card
        hero = QFrame()
        hero.setObjectName("FrameCard")
        _apply_card_shadow(hero)
        hero_l = QVBoxLayout(hero)
        hero_l.setContentsMargins(16, 14, 16, 14)
        hero_l.setSpacing(6)
        self.lbl_home_title = QLabel("")
        self.lbl_home_title.setProperty("role", "heroTitle")
        self.lbl_home_sub = QLabel("")
        self.lbl_home_sub.setWordWrap(True)
        self.lbl_home_sub.setProperty("role", "heroSub")

        hero_btns = QHBoxLayout()
        hero_btns.setSpacing(8)
        self.btn_home_new = QPushButton("")
        self.btn_home_new.setProperty("btnRole", "primary")
        self.btn_home_new.clicked.connect(self._start_new_workspace)
        self.btn_home_sharepoint = QPushButton("")
        self.btn_home_sharepoint.setProperty("btnRole", "secondary")
        self.btn_home_sharepoint.clicked.connect(self.open_sharepoint_catalog)
        hero_btns.addWidget(self.btn_home_new)
        hero_btns.addWidget(self.btn_home_sharepoint)
        hero_btns.addStretch()

        hero_l.addWidget(self.lbl_home_title)
        hero_l.addWidget(self.lbl_home_sub)
        hero_l.addLayout(hero_btns)
        layout.addWidget(hero)

        # Resume Prompt Card (shown when a saved project config or recent workspace exists)
        self.home_resume_box = QFrame()
        self.home_resume_box.setObjectName("FrameCard")
        _apply_card_shadow(self.home_resume_box)
        res_l = QVBoxLayout(self.home_resume_box)
        res_l.setContentsMargins(16, 12, 16, 12)
        res_l.setSpacing(6)
        self.lbl_home_resume_title = QLabel("")
        self.lbl_home_resume_title.setProperty("role", "accentTitle")
        self.lbl_home_resume_detail = QLabel("")
        self.lbl_home_resume_detail.setWordWrap(True)
        self.lbl_home_resume_detail.setProperty("role", "heroSub")
        res_btns = QHBoxLayout()
        self.btn_home_resume = QPushButton("")
        self.btn_home_resume.setProperty("btnRole", "accent")
        self.btn_home_resume.clicked.connect(self._resume_previous_workspace)
        res_btns.addWidget(self.btn_home_resume)
        res_btns.addStretch()
        res_l.addWidget(self.lbl_home_resume_title)
        res_l.addWidget(self.lbl_home_resume_detail)
        res_l.addLayout(res_btns)
        layout.addWidget(self.home_resume_box)

        # Two Columns: Saved Dashboards + Recent Workspaces (left) | Quick Templates (right)
        cols = QHBoxLayout()
        cols.setSpacing(12)

        left_col = QVBoxLayout()
        left_col.setSpacing(12)

        saved_card = QFrame()
        saved_card.setObjectName("FrameCard")
        _apply_card_shadow(saved_card)
        saved_l = QVBoxLayout(saved_card)
        saved_l.setContentsMargins(14, 12, 14, 12)
        saved_l.setSpacing(6)
        self.lbl_home_saved_title = QLabel("")
        self.lbl_home_saved_title.setProperty("role", "cardTitle")
        self.lbl_home_saved_empty = QLabel("")
        self.lbl_home_saved_empty.setWordWrap(True)
        self.lbl_home_saved_empty.setProperty("role", "muted")
        self.home_saved_list = DragFieldListWidget(
            role_mode="connections",
            on_remove_row=self._remove_saved_at_row,
            on_remove_rows=self._remove_saved_rows,
            lang="et",
        )
        self.home_saved_list.setMinimumHeight(210)
        if hasattr(self.home_saved_list, "setIconSize") and hasattr(QtCore, "QSize"):
            try:
                self.home_saved_list.setIconSize(QtCore.QSize(132, 82))
            except Exception:
                pass
        if hasattr(self.home_saved_list, "setSelectionMode"):
            qabs = getattr(QtWidgets, "QAbstractItemView", None)
            if qabs is not None:
                self.home_saved_list.setSelectionMode(
                    _safe_qt_enum(qabs, "SelectionMode", "ExtendedSelection", 3)
                )
        self.home_saved_list.itemDoubleClicked.connect(lambda _it: self._open_selected_saved_dashboard())
        if hasattr(self.home_saved_list, "itemSelectionChanged"):
            self.home_saved_list.itemSelectionChanged.connect(self._on_home_saved_selection_changed)

        self.lbl_home_saved_info = QLabel("")
        self.lbl_home_saved_info.setWordWrap(True)
        self.lbl_home_saved_info.setProperty("role", "muted")
        self.lbl_home_saved_info.setStyleSheet("font-size: 11px; padding: 2px 0;")

        saved_btns = QHBoxLayout()
        self.btn_home_load_saved = QPushButton("")
        self.btn_home_load_saved.setProperty("btnRole", "primary")
        self.btn_home_load_saved.clicked.connect(self._open_selected_saved_dashboard)
        self.btn_home_delete_saved = QPushButton("")
        self.btn_home_delete_saved.setProperty("btnRole", "secondary")
        self.btn_home_delete_saved.clicked.connect(self._remove_selected_saved)
        saved_btns.addWidget(self.btn_home_load_saved)
        saved_btns.addWidget(self.btn_home_delete_saved)
        saved_l.addWidget(self.lbl_home_saved_title)
        saved_l.addWidget(self.lbl_home_saved_empty)
        saved_l.addWidget(self.home_saved_list, 1)
        saved_l.addWidget(self.lbl_home_saved_info)
        saved_l.addLayout(saved_btns)
        left_col.addWidget(saved_card, 1)

        rec_card = QFrame()
        rec_card.setObjectName("FrameCard")
        _apply_card_shadow(rec_card)
        rec_l = QVBoxLayout(rec_card)
        rec_l.setContentsMargins(14, 12, 14, 12)
        rec_l.setSpacing(6)
        self.lbl_home_recents_title = QLabel("")
        self.lbl_home_recents_title.setProperty("role", "cardTitle")
        self.lbl_home_recents_empty = QLabel("")
        self.lbl_home_recents_empty.setWordWrap(True)
        self.lbl_home_recents_empty.setProperty("role", "muted")
        self.home_recents_list = DragFieldListWidget(
            role_mode="connections",
            on_remove_row=self._remove_recent_at_row,
            on_remove_rows=self._remove_recent_rows,
            lang="et",
        )
        self.home_recents_list.setMinimumHeight(180)
        if hasattr(self.home_recents_list, "setSelectionMode"):
            qabs = getattr(QtWidgets, "QAbstractItemView", None)
            if qabs is not None:
                self.home_recents_list.setSelectionMode(
                    _safe_qt_enum(qabs, "SelectionMode", "ExtendedSelection", 3)
                )
        self.home_recents_list.itemDoubleClicked.connect(lambda _it: self._open_selected_recent_workspace())
        if hasattr(self.home_recents_list, "itemSelectionChanged"):
            self.home_recents_list.itemSelectionChanged.connect(self._on_home_recents_selection_changed)
        self.lbl_home_recents_hint = QLabel("")
        self.lbl_home_recents_hint.setWordWrap(True)
        self.lbl_home_recents_hint.setProperty("role", "muted")
        self.lbl_home_recents_hint.setStyleSheet("font-size: 11px;")
        rec_btns = QHBoxLayout()
        self.btn_home_open_recent = QPushButton("")
        self.btn_home_open_recent.setProperty("btnRole", "primary")
        self.btn_home_open_recent.clicked.connect(self._open_selected_recent_workspace)
        self.btn_home_remove_recent = QPushButton("")
        self.btn_home_remove_recent.setProperty("btnRole", "secondary")
        self.btn_home_remove_recent.clicked.connect(self._remove_selected_recent)
        rec_btns.addWidget(self.btn_home_open_recent)
        rec_btns.addWidget(self.btn_home_remove_recent)
        rec_l.addWidget(self.lbl_home_recents_title)
        rec_l.addWidget(self.lbl_home_recents_empty)
        rec_l.addWidget(self.home_recents_list, 1)
        rec_l.addWidget(self.lbl_home_recents_hint)
        rec_l.addLayout(rec_btns)
        left_col.addWidget(rec_card, 1)

        cols.addLayout(left_col, 3)

        tpl_card = QFrame()
        tpl_card.setObjectName("FrameCard")
        _apply_card_shadow(tpl_card)
        tpl_l = QVBoxLayout(tpl_card)
        tpl_l.setContentsMargins(14, 12, 14, 12)
        tpl_l.setSpacing(6)

        self.lbl_home_empty_templates_title = QLabel("")
        self.lbl_home_empty_templates_title.setProperty("role", "cardTitle")
        tpl_l.addWidget(self.lbl_home_empty_templates_title)

        self._home_empty_preset_buttons: List[Tuple[QPushButton, str, str]] = []
        for tkey, fname in self._EMPTY_STARTER_PRESETS:
            b = QPushButton("")
            b.setProperty("btnRole", "secondary")
            b.clicked.connect(lambda _checked=False, f=fname: self._load_bundled_preset(f))
            tpl_l.addWidget(b)
            self._home_empty_preset_buttons.append((b, tkey, fname))

        self.lbl_home_templates_title = QLabel("")
        self.lbl_home_templates_title.setProperty("role", "cardTitle")
        tpl_l.addSpacing(6)
        tpl_l.addWidget(self.lbl_home_templates_title)

        self._home_preset_buttons: List[Tuple[QPushButton, str, str]] = []
        presets = [
            ("menu_load_meadow", "meadow_conservation_test.qdash.json"),
            ("menu_load_overlap", "natura_pria_overlap_example.qdash.json"),
            ("menu_load_soomaa", "soomaa_workplan_example.qdash.json"),
            ("menu_load_alampedja", "alam_pedja_example.qdash.json"),
        ]
        for tkey, fname in presets:
            b = QPushButton("")
            b.setProperty("btnRole", "secondary")
            b.clicked.connect(lambda _checked=False, f=fname: self._load_bundled_preset(f))
            tpl_l.addWidget(b)
            self._home_preset_buttons.append((b, tkey, fname))
        tpl_l.addStretch()
        cols.addWidget(tpl_card, 2)

        layout.addLayout(cols, 1)
        layout.addStretch()
        scroll.setWidget(container)
        return scroll

    @staticmethod
    def _qimage_to_png_bytes(img: Any) -> bytes:
        QBufferCls = getattr(QtCore, "QBuffer", None)
        QByteArrayCls = getattr(QtCore, "QByteArray", None)
        QIODeviceCls = getattr(QtCore, "QIODevice", None)
        if img is None or QBufferCls is None or QByteArrayCls is None or QIODeviceCls is None:
            return b""
        try:
            ba = QByteArrayCls()
            buf = QBufferCls(ba)
            mode = _safe_qt_enum(QIODeviceCls, "OpenModeFlag", "WriteOnly", 2)
            if not buf.open(mode):
                return b""
            img.save(buf, "PNG")
            buf.close()
            return bytes(ba.data())
        except Exception:
            return b""

    def _render_schematic_thumbnail_qimage(self, cfg: DashboardConfig, width: int = 264, height: int = 164) -> Any:
        QImageCls = getattr(QtGui, "QImage", None)
        if QImageCls is None:
            return None
        try:
            fmt = _safe_qt_enum(QImageCls, "Format", "Format_ARGB32", 5)
            img = QImageCls(width, height, fmt)
            img.fill(QColor("#0f172a"))
            p = QPainter(img)
            try:
                aa = _safe_qt_enum(QPainter, "RenderHint", "Antialiasing", 1)
                p.setRenderHint(aa, True)
                cw = float(max(600, getattr(cfg, "canvas_width", 1280) or 1280))
                ch = float(max(400, getattr(cfg, "canvas_height", 720) or 720))
                for item in list(getattr(cfg, "slicers", []) or []) + list(getattr(cfg, "widgets", []) or []):
                    wt = str(getattr(item, "widget_type", "") or ("slicer" if hasattr(item, "field_name") else "widget"))
                    lx = float(getattr(item, "layout_x", 12) or 12)
                    ly = float(getattr(item, "layout_y", 12) or 12)
                    lw = float(getattr(item, "layout_w", 240) or 240)
                    lh = float(getattr(item, "layout_h", 140) or 140)
                    cw = max(cw, lx + lw + 12)
                    ch = max(ch, ly + lh + 12)
                sx = (width - 12) / cw
                sy = (height - 12) / ch
                sc = min(sx, sy)
                ox = (width - cw * sc) * 0.5
                oy = (height - ch * sc) * 0.5

                p.setPen(QPen(QColor("#334155"), 1))
                p.setBrush(QBrush(QColor("#1e293b")))
                p.drawRoundedRect(3, 3, width - 6, height - 6, 6, 6)

                color_map = {
                    "map": ("#064e3b", "#10b981"),
                    "kpi": ("#0c4a6e", "#38bdf8"),
                    "table": ("#1e293b", "#64748b"),
                    "bar": ("#064e3b", "#34d399"),
                    "pie": ("#3b0764", "#c084fc"),
                    "line": ("#1e1b4b", "#818cf8"),
                    "slicer": ("#172554", "#60a5fa"),
                }
                for item in list(getattr(cfg, "widgets", []) or []) + list(getattr(cfg, "slicers", []) or []):
                    wt = str(getattr(item, "widget_type", "") or "slicer").lower()
                    fill_hex, brd_hex = color_map.get(wt, ("#1e293b", "#38bdf8"))
                    rx = int(round(ox + float(getattr(item, "layout_x", 16) or 16) * sc))
                    ry = int(round(oy + float(getattr(item, "layout_y", 16) or 16) * sc))
                    rw = max(12, int(round(float(getattr(item, "layout_w", 240) or 240) * sc)))
                    rh = max(8, int(round(float(getattr(item, "layout_h", 120) or 120) * sc)))
                    p.setPen(QPen(QColor(brd_hex), 1))
                    p.setBrush(QBrush(QColor(fill_hex)))
                    p.drawRoundedRect(rx, ry, rw, rh, 3, 3)
                    if wt == "map" and rw > 24 and rh > 20:
                        p.setPen(QPen(QColor("#34d399"), 1))
                        p.setBrush(QBrush(QColor(16, 185, 129, 90)))
                        p.drawEllipse(rx + 6, ry + 6, max(8, rw // 3), max(8, rh // 3))
                        p.drawEllipse(rx + rw // 2, ry + rh // 3, max(8, rw // 4), max(8, rh // 3))
                    elif wt in ("bar", "line") and rw > 20 and rh > 16:
                        p.setPen(QPen(QColor(brd_hex), 2))
                        bars = 4
                        bw = max(2, (rw - 10) // (bars * 2))
                        for bi in range(bars):
                            bh = max(3, int((rh - 8) * (0.35 + 0.18 * ((bi + 1) % 3 + 1) / 3.0)))
                            bx = rx + 5 + bi * (bw * 2)
                            p.fillRect(bx, ry + rh - 4 - bh, bw, bh, QColor(brd_hex))
            finally:
                p.end()
            return img
        except Exception:
            return None

    def _capture_dashboard_thumbnail_bytes(self) -> bytes:
        """Capture a 264x164 PNG thumbnail of the live workspace canvas, or draw a schematic layout preview."""
        QImageCls = getattr(QtGui, "QImage", None)
        if (
            QImageCls is not None
            and hasattr(self, "workspace_canvas")
            and self.workspace_canvas is not None
            and hasattr(self.workspace_canvas, "grab")
            and hasattr(self, "studio_stack")
            and self.studio_stack.currentIndex() == 1
            and (getattr(self.config, "widgets", None) or getattr(self.config, "slicers", None))
        ):
            try:
                if self.workspace_canvas.width() > 60 and self.workspace_canvas.height() > 60:
                    pm = self.workspace_canvas.grab()
                    if pm is not None and not pm.isNull():
                        aspect = _safe_qt_enum(Qt, "AspectRatioMode", "KeepAspectRatio", 1)
                        smooth = _safe_qt_enum(Qt, "TransformationMode", "SmoothTransformation", 1)
                        scaled = pm.scaled(264, 164, aspect, smooth)
                        fmt = _safe_qt_enum(QImageCls, "Format", "Format_ARGB32", 5)
                        out_img = QImageCls(264, 164, fmt)
                        out_img.fill(QColor("#0f172a"))
                        p = QPainter(out_img)
                        try:
                            dx = max(0, (264 - scaled.width()) // 2)
                            dy = max(0, (164 - scaled.height()) // 2)
                            p.drawPixmap(dx, dy, scaled)
                        finally:
                            p.end()
                        raw = self._qimage_to_png_bytes(out_img)
                        if raw:
                            return raw
            except Exception:
                pass
        sched = self._render_schematic_thumbnail_qimage(self.config)
        raw = self._qimage_to_png_bytes(sched)
        return raw if raw else self._fallback_schematic_png_bytes(self.config)

    @staticmethod
    def _fallback_schematic_png_bytes(cfg: DashboardConfig, width: int = 132, height: int = 82) -> bytes:
        """Pure-Python RGBA PNG miniature renderer used when Qt QImage/QBuffer is unavailable."""
        import struct
        import zlib

        buf = bytearray(width * height * 4)
        for y in range(height):
            for x in range(width):
                pos = (y * width + x) * 4
                buf[pos : pos + 4] = b"\x0f\x17\x2a\xff"

        cw = float(max(600, getattr(cfg, "canvas_width", 1280) or 1280))
        ch = float(max(400, getattr(cfg, "canvas_height", 720) or 720))
        sc = min((width - 8) / cw, (height - 8) / ch)
        rgb_map = {
            "map": (16, 185, 129),
            "kpi": (56, 189, 248),
            "table": (100, 116, 139),
            "bar": (52, 211, 153),
            "pie": (192, 132, 252),
            "slicer": (96, 165, 250),
        }
        for item in list(getattr(cfg, "widgets", []) or []) + list(getattr(cfg, "slicers", []) or []):
            wt = str(getattr(item, "widget_type", "") or "slicer").lower()
            r, g, b = rgb_map.get(wt, (56, 189, 248))
            x0 = max(2, min(width - 4, int(round(4 + float(getattr(item, "layout_x", 16) or 16) * sc))))
            y0 = max(2, min(height - 4, int(round(4 + float(getattr(item, "layout_y", 16) or 16) * sc))))
            x1 = max(x0 + 4, min(width - 2, int(round(4 + (float(getattr(item, "layout_x", 16) or 16) + float(getattr(item, "layout_w", 240) or 240)) * sc))))
            y1 = max(y0 + 3, min(height - 2, int(round(4 + (float(getattr(item, "layout_y", 16) or 16) + float(getattr(item, "layout_h", 120) or 120)) * sc))))
            for yy in range(y0, y1):
                row_off = yy * width * 4
                is_edge = yy in (y0, y1 - 1)
                for xx in range(x0, x1):
                    p = row_off + xx * 4
                    if is_edge or xx in (x0, x1 - 1):
                        buf[p], buf[p + 1], buf[p + 2], buf[p + 3] = r, g, b, 255
                    else:
                        buf[p], buf[p + 1], buf[p + 2], buf[p + 3] = r // 4, g // 4, b // 4, 255

        def _chunk(tag: bytes, data: bytes) -> bytes:
            return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

        raw_scan = b"".join(b"\x00" + bytes(buf[y * width * 4 : (y + 1) * width * 4]) for y in range(height))
        ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
        return b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", ihdr) + _chunk(b"IDAT", zlib.compress(raw_scan, 6)) + _chunk(b"IEND", b"")

    def _build_thumbnail_icon(self, entry: Dict[str, Any]) -> Any:
        QIconCls = getattr(QtGui, "QIcon", None)
        QPixmapCls = getattr(QtGui, "QPixmap", None)
        if QIconCls is None or QPixmapCls is None:
            return None
        try:
            tpath = str(entry.get("thumbnail_path") or "").strip()
            if tpath and os.path.isfile(tpath):
                pm = QPixmapCls(tpath)
                if pm is not None and not pm.isNull():
                    return QIconCls(pm)
            cfg_dict = entry.get("config")
            if isinstance(cfg_dict, dict):
                cfg = DashboardConfig.from_dict(cfg_dict)
                img = self._render_schematic_thumbnail_qimage(cfg)
                if img is not None:
                    return QIconCls(QPixmapCls.fromImage(img))
        except Exception:
            pass
        return None

    def _format_saved_dashboard_details(self, entry: Dict[str, Any], lang: str) -> str:
        title = str(entry.get("title") or "Töölaud")
        created = str(entry.get("created_at") or entry.get("updated_at") or "").replace("T", " ")[:16]
        updated = str(entry.get("updated_at") or "").replace("T", " ")[:16]
        nw = int(entry.get("widget_count") or 0)
        nsl = int(entry.get("slicer_count") or 0)
        npages = int(entry.get("page_count") or 1)
        wtypes = entry.get("widget_types") or {}
        type_labels_et = {"map": "kaart", "table": "tabel", "kpi": "KPI", "bar": "tulp", "pie": "sektor", "line": "joon", "scatter": "hajuvus", "image": "pilt"}
        type_labels_en = {"map": "map", "table": "table", "kpi": "KPI", "bar": "bar", "pie": "pie", "line": "line", "scatter": "scatter", "image": "image"}
        tmap = type_labels_et if lang == "et" else type_labels_en
        type_parts = [f"{tmap.get(k, k)}: {v}" for k, v in wtypes.items() if v]
        type_str = f" ({', '.join(type_parts)})" if type_parts else ""
        layers = [str(x) for x in (entry.get("layer_names") or []) if x]
        layers_str = ", ".join(layers[:6]) + (f" (+{len(layers) - 6})" if len(layers) > 6 else "")
        if lang == "et":
            parts = [
                f"📌 {title}",
                f"Loodud: {created}" + (f" | Muudetud: {updated}" if updated and updated != created else ""),
                f"Sisu: {nw} vidinat{type_str} · {nsl} filtrit · {npages} lk",
            ]
            if layers_str:
                parts.append(f"Kihid ({len(layers)}): {layers_str}")
        else:
            parts = [
                f"📌 {title}",
                f"Created: {created}" + (f" | Updated: {updated}" if updated and updated != created else ""),
                f"Contains: {nw} widgets{type_str} · {nsl} filters · {npages} page(s)",
            ]
            if layers_str:
                parts.append(f"Layers ({len(layers)}): {layers_str}")
        return "\n".join(parts)

    def _update_home_saved_action_labels(self) -> None:
        if not hasattr(self, "btn_home_delete_saved") or not hasattr(self, "home_saved_list"):
            return
        lang = self.config.language or "et"
        sel_n = len(list(self.home_saved_list.selectedItems() or []))
        base = tr("home_delete_saved", lang)
        self.btn_home_delete_saved.setText(f"{base} ({sel_n})" if sel_n > 1 else base)

    def _update_home_recent_action_labels(self) -> None:
        if not hasattr(self, "btn_home_remove_recent") or not hasattr(self, "home_recents_list"):
            return
        lang = self.config.language or "et"
        sel_n = len(list(self.home_recents_list.selectedItems() or []))
        base = tr("home_clear_recent", lang)
        self.btn_home_remove_recent.setText(f"{base} ({sel_n})" if sel_n > 1 else base)

    def _on_home_saved_selection_changed(self) -> None:
        lang = self.config.language or "et"
        self._update_home_saved_action_labels()
        if not hasattr(self, "lbl_home_saved_info"):
            return
        sel = list(self.home_saved_list.selectedItems() or [])
        it = sel[0] if sel else self.home_saved_list.currentItem()
        if it is None:
            self.lbl_home_saved_info.setText(tr("home_saved_info_hint", lang))
            return
        entry = it.data(qt_enum(Qt, "ItemDataRole", "UserRole"))
        if isinstance(entry, dict):
            self.lbl_home_saved_info.setText(self._format_saved_dashboard_details(entry, lang))
        else:
            self.lbl_home_saved_info.setText(tr("home_saved_info_hint", lang))

    def _on_home_recents_selection_changed(self) -> None:
        self._update_home_recent_action_labels()

    def _refresh_home_view(self) -> None:
        lang = self.config.language or "et"
        role = qt_enum(Qt, "ItemDataRole", "UserRole")

        # 1. Saved Dashboards Panel
        if hasattr(self, "home_saved_list"):
            saved_list = DashboardPersistenceManager.load_saved_dashboards()
            self.home_saved_list.clear()
            for entry in saved_list:
                title = str(entry.get("title") or "Töölaud")
                created = str(entry.get("created_at") or entry.get("updated_at") or "").replace("T", " ")[:16]
                nw = int(entry.get("widget_count") or 0)
                nsl = int(entry.get("slicer_count") or 0)
                layers = [str(x) for x in (entry.get("layer_names") or []) if x]
                layer_preview = ", ".join(layers[:3]) + ("…" if len(layers) > 3 else "")
                meta = (
                    f"🕒 {created} · {nw} vidinat · {nsl} filtrit"
                    if lang == "et"
                    else f"🕒 {created} · {nw} widgets · {nsl} filters"
                )
                if layer_preview:
                    meta += f"\n🗂 {layer_preview}"
                it = QListWidgetItem(f"{title}\n{meta}")
                it.setData(role, entry)
                it.setToolTip(self._format_saved_dashboard_details(entry, lang))
                icon = self._build_thumbnail_icon(entry)
                if icon is not None and hasattr(it, "setIcon"):
                    it.setIcon(icon)
                self.home_saved_list.addItem(it)
            has_saved = bool(saved_list)
            self.lbl_home_saved_empty.setVisible(not has_saved)
            self.btn_home_load_saved.setEnabled(has_saved)
            self.btn_home_delete_saved.setEnabled(has_saved)
            if has_saved and self.home_saved_list.count() > 0:
                first_it = self.home_saved_list.item(0)
                self.home_saved_list.setCurrentItem(first_it)
            self._on_home_saved_selection_changed()

        # 2. Recent Workspaces Panel
        if not hasattr(self, "home_recents_list"):
            return
        recents = DashboardPersistenceManager.load_recent_workspaces()
        self.home_recents_list.clear()
        for entry in recents:
            title = str(entry.get("title") or "Töölaud")
            ts = str(entry.get("updated_at") or "").replace("T", " ")[:16]
            nw = int(entry.get("widget_count") or 0)
            ns = int(entry.get("source_count") or 0)
            proj = str(entry.get("project_path") or "").strip()
            meta = f"{ts} · {nw} vidinat · {ns} allikat" if lang == "et" else f"{ts} · {nw} widgets · {ns} sources"
            if proj:
                meta += f"\n    📁 {proj}"
            it = QListWidgetItem(f"📌 {title}\n    {meta}")
            it.setData(role, entry)
            self.home_recents_list.addItem(it)

        has_rec = bool(recents)
        self.lbl_home_recents_empty.setVisible(not has_rec)
        self.btn_home_open_recent.setEnabled(has_rec)
        self.btn_home_remove_recent.setEnabled(has_rec)
        self._update_home_recent_action_labels()

        if self._pending_project_cfg is not None:
            pc = self._pending_project_cfg
            self.home_resume_box.setVisible(True)
            detail = (
                f"QGIS projektis salvestatud töölaud „{pc.title}” "
                f"({len(pc.widgets)} vidinat, {len(pc.slicers)} filtrit, {len(pc.data_sources)} allikat). "
                "Andmeallikaid ei laadita enne, kui vajutate Jätka."
                if lang == "et"
                else f"Saved dashboard '{pc.title}' in QGIS project "
                f"({len(pc.widgets)} widgets, {len(pc.slicers)} filters, {len(pc.data_sources)} sources). "
                "Layers stay unloaded until you click Resume."
            )
            self.lbl_home_resume_detail.setText(detail)
        elif recents:
            top = recents[0]
            self.home_resume_box.setVisible(True)
            t = str(top.get("title") or "Töölaud")
            detail = (
                f"Viimati avatud töölaud „{t}” ({top.get('widget_count', 0)} vidinat, {top.get('source_count', 0)} allikat)."
                if lang == "et"
                else f"Last workspace '{t}' ({top.get('widget_count', 0)} widgets, {top.get('source_count', 0)} sources)."
            )
            self.lbl_home_resume_detail.setText(detail)
        else:
            self.home_resume_box.setVisible(False)

    def save_dashboard_action(
        self, name: Optional[str] = None, save_as_new: Optional[bool] = None
    ) -> Optional[Dict[str, Any]]:
        """Save the current dashboard to Avaleht Saved Dashboards with metadata, timestamp, and thumbnail."""
        lang = self.config.language or "et"
        entered_name = name
        overwrite_id = ""
        existing = DashboardPersistenceManager.load_saved_dashboards()
        active_id = str(getattr(self, "_active_saved_dashboard_id", "") or "")
        matching_prev = next((e for e in existing if active_id and e.get("id") == active_id), None)

        if entered_name is None:
            QDialogCls = getattr(QtWidgets, "QDialog", None)
            QDialogButtonBoxCls = getattr(QtWidgets, "QDialogButtonBox", None)
            QRadioButtonCls = getattr(QtWidgets, "QRadioButton", None)
            if QDialogCls is not None and not os.environ.get("PYTEST_CURRENT_TEST"):
                dlg = QDialogCls(self)
                dlg.setWindowTitle(tr("save_dash_dlg_title", lang))
                dlg.setMinimumWidth(380)
                dl = QVBoxLayout(dlg)
                dl.setSpacing(8)
                dl.addWidget(QLabel(tr("save_dash_name_lbl", lang)))
                ed_name = QLineEdit(str(self.config.title or ("Minu töölaud" if lang == "et" else "My Dashboard")))
                ed_name.selectAll()
                dl.addWidget(ed_name)

                sum_info = DashboardPersistenceManager.summarize_dashboard_contents(self.config)
                layers_str = ", ".join(sum_info["layer_names"][:5]) or ("—" if lang == "et" else "None")
                preview_lbl = QLabel(
                    (
                        f"Sisu: {sum_info['widget_count']} vidinat · {sum_info['slicer_count']} filtrit · {sum_info['page_count']} lk\n"
                        f"Kihid: {layers_str}"
                    )
                    if lang == "et"
                    else (
                        f"Contains: {sum_info['widget_count']} widgets · {sum_info['slicer_count']} filters · {sum_info['page_count']} page(s)\n"
                        f"Layers: {layers_str}"
                    )
                )
                preview_lbl.setWordWrap(True)
                preview_lbl.setProperty("role", "muted")
                dl.addWidget(preview_lbl)

                rb_overwrite = None
                if matching_prev is not None and QRadioButtonCls is not None:
                    rb_overwrite = QRadioButtonCls(
                        f"{tr('save_dash_overwrite', lang)} ({matching_prev.get('title', '')})"
                    )
                    rb_new = QRadioButtonCls(tr("save_dash_new_copy", lang))
                    rb_overwrite.setChecked(True)
                    dl.addWidget(rb_overwrite)
                    dl.addWidget(rb_new)

                if QDialogButtonBoxCls is not None:
                    btns = QDialogButtonBoxCls(
                        _safe_qt_enum(QDialogButtonBoxCls, "StandardButton", "Ok", 0x00000400)
                        | _safe_qt_enum(QDialogButtonBoxCls, "StandardButton", "Cancel", 0x00400000)
                    )
                    btns.accepted.connect(dlg.accept)
                    btns.rejected.connect(dlg.reject)
                    dl.addWidget(btns)
                accepted_code = _safe_qt_enum(QDialogCls, "DialogCode", "Accepted", 1)
                res = exec_dialog(dlg)
                if res != accepted_code and res is not True:
                    return None
                entered_name = str(ed_name.text() or "").strip()
                if not entered_name:
                    if QMessageBox is not None:
                        QMessageBox.warning(self, tr("save_dash_dlg_title", lang), tr("save_dash_empty_warn", lang))
                    return None
                if rb_overwrite is not None and rb_overwrite.isChecked():
                    overwrite_id = str(matching_prev.get("id") or "")
            else:
                entered_name = str(self.config.title or "Töölaud").strip()
        elif not save_as_new and matching_prev is not None:
            overwrite_id = str(matching_prev.get("id") or "")

        clean_name = str(entered_name or "").strip()
        if not clean_name:
            return None

        thumb_bytes = self._capture_dashboard_thumbnail_bytes()
        self.config.title = clean_name
        if not self.config.title_en or self.config.title_en == "My Dashboard":
            self.config.title_en = clean_name
        self._save_project_state()
        entry = DashboardPersistenceManager.save_named_dashboard(
            self.config,
            name=clean_name,
            project_path=DashboardPersistenceManager.get_current_project_dir() or "",
            thumbnail_png=thumb_bytes,
            entry_id=overwrite_id,
        )
        self._active_saved_dashboard_id = str(entry.get("id") or "")
        self._refresh_home_view()
        self._retranslate_ui()
        if hasattr(self, "lbl_status"):
            self.lbl_status.setText(tr("save_dash_saved_msg", lang, name=clean_name))
        return entry

    def _open_selected_saved_dashboard(self) -> None:
        if not hasattr(self, "home_saved_list"):
            return
        sel = list(self.home_saved_list.selectedItems() or [])
        it = sel[0] if sel else self.home_saved_list.currentItem()
        if it is None and self.home_saved_list.count() > 0:
            it = self.home_saved_list.item(0)
        if it is None:
            return
        entry = it.data(qt_enum(Qt, "ItemDataRole", "UserRole"))
        if isinstance(entry, dict):
            self._open_saved_entry(entry)

    def _open_saved_entry(self, entry: Dict[str, Any]) -> None:
        self._pending_project_cfg = None
        cfg_dict = entry.get("config")
        if isinstance(cfg_dict, dict):
            cfg = DashboardConfig.from_dict(cfg_dict)
            self.load_dashboard_config(cfg)
            self._active_saved_dashboard_id = str(entry.get("id") or "")

    def _remove_saved_rows(self, rows: List[int]) -> None:
        if not hasattr(self, "home_saved_list"):
            return
        role = _safe_qt_enum(Qt, "ItemDataRole", "UserRole", 256)
        ids_to_del: List[str] = []
        for r in rows or []:
            if 0 <= int(r) < self.home_saved_list.count():
                it = self.home_saved_list.item(int(r))
                entry = it.data(role) if it else None
                if isinstance(entry, dict) and entry.get("id"):
                    ids_to_del.append(str(entry["id"]))
        if ids_to_del:
            DashboardPersistenceManager.remove_saved_dashboards(ids_to_del)
            if getattr(self, "_active_saved_dashboard_id", "") in ids_to_del:
                self._active_saved_dashboard_id = ""
        self._refresh_home_view()

    def _remove_saved_at_row(self, row: int) -> None:
        self._remove_saved_rows([row])

    def _remove_selected_saved(self) -> None:
        if not hasattr(self, "home_saved_list"):
            return
        sel = list(self.home_saved_list.selectedItems() or [])
        rows = [self.home_saved_list.row(it) for it in sel if self.home_saved_list.row(it) >= 0]
        if not rows and self.home_saved_list.currentRow() >= 0:
            rows = [self.home_saved_list.currentRow()]
        self._remove_saved_rows(rows)

    def present_home_view(self, pending_project_cfg: Optional[DashboardConfig] = None) -> None:
        """Show the default Home View landing screen without eagerly fetching layers."""
        self._pending_project_cfg = pending_project_cfg
        if pending_project_cfg is not None and pending_project_cfg.language:
            self.config.language = pending_project_cfg.language
        self._refresh_home_view()
        self._show_home_view()
        self._retranslate_ui()

    def _toggle_home_workspace_view(self) -> None:
        if self.studio_stack.currentIndex() == 0:
            self._show_workspace_view()
        else:
            self._show_home_view()

    def _show_home_view(self) -> None:
        self._refresh_home_view()
        self.studio_stack.setCurrentIndex(0)
        self._retranslate_ui()

    def _show_workspace_view(self) -> None:
        self.studio_stack.setCurrentIndex(1)
        self._retranslate_ui()

    def _resume_previous_workspace(self) -> None:
        if self._pending_project_cfg is not None:
            cfg = self._pending_project_cfg
            self._pending_project_cfg = None
            self.load_dashboard_config(cfg)
            return
        recents = DashboardPersistenceManager.load_recent_workspaces()
        if recents:
            self._open_recent_entry(recents[0])
        else:
            self._show_workspace_view()

    def _start_new_workspace(self) -> None:
        lang = self.config.language or "et"
        self._pending_project_cfg = None
        self.filter_bus.clear_all()
        if hasattr(self.config, "sync_widget_connections"):
            self.config.sync_widget_connections()
        self.filter_bus.set_connections(getattr(self.config, "widget_connections", []))
        self.persistence.layer_records_cache.clear()
        self.persistence.layer_geojson_cache.clear()
        self.persistence.excel_records_cache.clear()
        fresh = DashboardConfig(language=lang)
        self.load_dashboard_config(fresh)

    def _open_selected_recent_workspace(self) -> None:
        it = self.home_recents_list.currentItem()
        if it is None and self.home_recents_list.count() > 0:
            it = self.home_recents_list.item(0)
        if it is None:
            return
        entry = it.data(qt_enum(Qt, "ItemDataRole", "UserRole"))
        if isinstance(entry, dict):
            self._open_recent_entry(entry)

    def _open_recent_entry(self, entry: Dict[str, Any]) -> None:
        self._pending_project_cfg = None
        tpath = str(entry.get("template_path") or "").strip()
        if tpath and os.path.isfile(tpath):
            try:
                cfg = DashboardPersistenceManager.load_from_template_file(tpath)
                self.load_dashboard_config(cfg)
                return
            except Exception:
                pass
        cfg_dict = entry.get("config")
        if isinstance(cfg_dict, dict):
            cfg = DashboardConfig.from_dict(cfg_dict)
            self.load_dashboard_config(cfg)

    def _remove_recent_rows(self, rows: List[int]) -> None:
        if not hasattr(self, "home_recents_list"):
            return
        role = _safe_qt_enum(Qt, "ItemDataRole", "UserRole", 256)
        ids_to_del: List[str] = []
        for r in rows or []:
            if 0 <= int(r) < self.home_recents_list.count():
                it = self.home_recents_list.item(int(r))
                entry = it.data(role) if it else None
                if isinstance(entry, dict) and entry.get("id"):
                    ids_to_del.append(str(entry["id"]))
        if ids_to_del:
            DashboardPersistenceManager.remove_recent_workspaces(ids_to_del)
        self._refresh_home_view()

    def _remove_recent_at_row(self, row: int) -> None:
        self._remove_recent_rows([row])

    def _remove_selected_recent(self) -> None:
        if not hasattr(self, "home_recents_list"):
            return
        sel = list(self.home_recents_list.selectedItems() or [])
        rows = [self.home_recents_list.row(it) for it in sel if self.home_recents_list.row(it) >= 0]
        if not rows and self.home_recents_list.currentRow() >= 0:
            rows = [self.home_recents_list.currentRow()]
        self._remove_recent_rows(rows)

    def _load_bundled_preset(self, filename: str) -> None:
        preset_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "presets", filename)
        )
        if os.path.isfile(preset_path):
            self._pending_project_cfg = None
            cfg = DashboardPersistenceManager.load_from_template_file(preset_path)
            self.load_dashboard_config(cfg)

    # ------------------------------------------------------------------
    # Exact HTML Preview Panel (Embedded WebEngine or Local HTTP Loopback)
    # ------------------------------------------------------------------

    def _build_preview_panel(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName("FrameCard")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        hdr = QHBoxLayout()
        hdr.setSpacing(6)
        self.lbl_preview_title = QLabel("")
        self.lbl_preview_title.setProperty("role", "cardTitle")
        self.lbl_preview_info = QLabel("")
        self.lbl_preview_info.setProperty("role", "muted")
        self.lbl_preview_tier = QLabel("")
        self.lbl_preview_tier.setProperty("role", "muted")
        self.cb_preview_tier = QComboBox()
        self.cb_preview_tier.addItem("", "full")
        self.cb_preview_tier.addItem("", "medium")
        self.cb_preview_tier.addItem("", "minimal")
        self.cb_preview_tier.currentIndexChanged.connect(self._on_preview_tier_changed)
        self.btn_preview_refresh = QPushButton("")
        self.btn_preview_refresh.clicked.connect(lambda: self._refresh_html_preview(open_external_if_fallback=False, force=True))
        self.btn_preview_browser = QPushButton("")
        self.btn_preview_browser.clicked.connect(self._open_preview_in_browser)
        self.btn_preview_back = QPushButton("")
        self.btn_preview_back.setProperty("btnRole", "accent")
        self.btn_preview_back.clicked.connect(self._exit_preview_mode)
        hdr.addWidget(self.lbl_preview_title)
        hdr.addWidget(self.lbl_preview_info, 1)
        hdr.addWidget(self.lbl_preview_tier)
        hdr.addWidget(self.cb_preview_tier)
        hdr.addWidget(self.btn_preview_refresh)
        hdr.addWidget(self.btn_preview_browser)
        hdr.addWidget(self.btn_preview_back)
        layout.addLayout(hdr)

        web_cls = _resolve_web_view_class()
        if web_cls is not None:
            try:
                self._preview_web_view = web_cls(panel)
                self._configure_preview_web_view(self._preview_web_view)
                self._install_preview_context_menu(self._preview_web_view)
                layout.addWidget(self._preview_web_view, 1)
                return panel
            except Exception:
                self._preview_web_view = None

        fallback = QFrame()
        fallback.setObjectName("FrameCard")
        fb_l = QVBoxLayout(fallback)
        fb_l.setContentsMargins(24, 24, 24, 24)
        fb_l.setSpacing(10)
        self.lbl_preview_url = QLabel("")
        try:
            self.lbl_preview_url.setTextInteractionFlags(
                qt_enum(Qt, "TextInteractionFlag", "TextSelectableByMouse")
            )
        except Exception:
            pass
        self.lbl_preview_url.setProperty("role", "monoLink")
        self.btn_preview_browser_center = QPushButton("")
        self.btn_preview_browser_center.setProperty("btnRole", "primary")
        self.btn_preview_browser_center.clicked.connect(self._open_preview_in_browser)
        fb_l.addStretch()
        fb_l.addWidget(self.lbl_preview_url)
        fb_l.addWidget(self.btn_preview_browser_center)
        fb_l.addStretch()
        layout.addWidget(fallback, 1)
        return panel

    def _on_preview_tier_changed(self, _idx: int = 0) -> None:
        if not hasattr(self, "cb_preview_tier"):
            return
        tier = str(self.cb_preview_tier.currentData() or "full").lower()
        if str(getattr(self.config, "export_tier", "full") or "full").lower() == tier:
            return
        self.config.export_tier = tier
        self._rebuild_preview_menu()
        self._save_project_state()
        if getattr(self.config, "preview_mode", False):
            self._refresh_html_preview(open_external_if_fallback=False, force=True)

    @staticmethod
    def _configure_preview_web_view(view: Any) -> None:
        try:
            settings_fn = getattr(view, "settings", None)
            settings = settings_fn() if callable(settings_fn) else None
            if settings is not None and hasattr(settings, "setAttribute"):
                wa_cls = getattr(settings, "WebAttribute", None) or type(settings)
                for attr_name, val in (
                    ("ScrollAnimatorEnabled", False),
                    ("JavascriptEnabled", True),
                    ("WebGLEnabled", True),
                    ("Accelerated2dCanvasEnabled", True),
                ):
                    attr = getattr(wa_cls, attr_name, None) or getattr(settings, attr_name, None)
                    if attr is not None:
                        try:
                            settings.setAttribute(attr, val)
                        except Exception:
                            pass
        except Exception:
            pass

    def _install_preview_context_menu(self, view: Any) -> None:
        try:
            policy = qt_enum(Qt, "ContextMenuPolicy", "CustomContextMenu")
            if policy is not None and hasattr(view, "setContextMenuPolicy"):
                view.setContextMenuPolicy(policy)
            sig = getattr(view, "customContextMenuRequested", None)
            if sig is not None and hasattr(sig, "connect"):
                sig.connect(self._on_preview_context_menu)
        except Exception:
            pass

    def _on_preview_context_menu(self, pos: Any) -> None:
        view = getattr(self, "_preview_web_view", None)
        if view is None:
            return
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            return
        lang = getattr(self.config, "language", "et") or "et"
        menu = QMenuCls(view)
        act_refresh_widgets = menu.addAction(tr("ctx_refresh_all_widgets", lang))
        act_clear_filters = menu.addAction(tr("ctx_clear_filters", lang))
        menu.addSeparator()
        act_rebuild = menu.addAction(tr("preview_refresh_btn", lang))
        act_reset_home = menu.addAction(tr("html_reset_dashboard", lang))
        from .qt_compat import exec_menu

        gpos = view.mapToGlobal(pos) if hasattr(view, "mapToGlobal") else pos
        chosen = exec_menu(menu, gpos)
        if chosen is None:
            return
        page = view.page() if hasattr(view, "page") else None
        if chosen == act_refresh_widgets and page is not None and hasattr(page, "runJavaScript"):
            page.runJavaScript(
                "if (typeof renderWidgetsOnly === 'function') { renderWidgetsOnly(); } "
                "else if (typeof renderAll === 'function') { renderAll(); }"
            )
        elif chosen == act_clear_filters and page is not None and hasattr(page, "runJavaScript"):
            page.runJavaScript("if (typeof clearAllFilters === 'function') { clearAllFilters(); }")
        elif chosen == act_rebuild:
            self._refresh_html_preview(open_external_if_fallback=False)
        elif chosen == act_reset_home and page is not None and hasattr(page, "runJavaScript"):
            page.runJavaScript("if (typeof resetDashboardToHome === 'function') { resetDashboardToHome(); }")

    @staticmethod
    def _parse_preview_features_qs(qs: Dict[str, List[str]]) -> Dict[str, Any]:
        def _first(key: str, default: str = "") -> str:
            vals = qs.get(key)
            return str(vals[0]) if vals else default

        layer_name = _first("layer", "")
        fids_raw = _first("fids", "")
        target_fids = [s.strip() for s in fids_raw.split(",") if s.strip()] if fids_raw else None

        bbox_raw = _first("bbox", "")
        bbox_wgs84 = None
        if bbox_raw:
            parts = [p.strip() for p in bbox_raw.split(",")]
            if len(parts) == 4:
                try:
                    bbox_wgs84 = (float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3]))
                except ValueError:
                    bbox_wgs84 = None

        try:
            zoom = int(float(_first("zoom", "12")))
        except ValueError:
            zoom = 12
        scale_raw = _first("scale", "")
        scale_denom = None
        if scale_raw:
            try:
                scale_denom = float(scale_raw)
            except ValueError:
                scale_denom = None
        lod_raw = _first("lod", "")
        lod_val = None
        if lod_raw:
            try:
                lod_val = int(float(lod_raw))
            except ValueError:
                lod_val = None
        try:
            max_features = max(1, min(6000, int(float(_first("max", "3500")))))
        except ValueError:
            max_features = 3500
        return {
            "layer_name": layer_name,
            "target_fids": target_fids,
            "bbox_wgs84": bbox_wgs84,
            "zoom": zoom,
            "scale_denom": scale_denom,
            "lod": lod_val,
            "max_features": max_features,
        }

    def _handle_preview_features_request(self, qs: Dict[str, List[str]]) -> Dict[str, Any]:
        parsed = self._parse_preview_features_qs(qs)
        if not parsed["layer_name"]:
            return {"type": "FeatureCollection", "features": []}
        return self.persistence.query_qgis_features_for_preview(**parsed)

    def _dispatch_preview_features(self, qs: Dict[str, List[str]]) -> Dict[str, Any]:
        parsed = self._parse_preview_features_qs(qs)
        if not parsed["layer_name"]:
            return {"type": "FeatureCollection", "features": []}
        # Serve memoized / pre-indexed spatial hits directly on HTTP worker thread (zero GUI block)
        cached = self.persistence.get_cached_preview_features(**parsed)
        if cached is not None:
            return cached
        # Execute BG-safe QGIS layer queries (GeoPackage, Shapefile, PostGIS, etc.) directly
        # in an isolated thread-local QgsVectorLayer on the HTTP worker thread without blocking UI.
        if self.persistence.can_query_preview_features_in_bg(parsed["layer_name"]):
            return self.persistence.query_qgis_features_for_preview(**parsed)
        if (
            threading.current_thread() is threading.main_thread()
            or self.iface is None
            or pyqtSignal is None
            or bool(os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS"))
            or getattr(self, "_preview_api_dispatcher", None) is None
        ):
            return self._handle_preview_features_request(qs)
        ev = threading.Event()
        out: Dict[str, Any] = {}
        self._preview_api_dispatcher.requested.emit(("features", qs, ev, out))
        if not ev.wait(timeout=8.0):
            return {"type": "FeatureCollection", "features": [], "timeout": True}
        return out.get("data") or {"type": "FeatureCollection", "features": []}

    def _map_layer_styles_snapshot(self) -> Dict[str, Dict[str, Any]]:
        styles_map: Dict[str, Dict[str, Any]] = {}
        for w in getattr(self.config, "widgets", []):
            if w.widget_type == "map" and isinstance(getattr(w, "map_layer_styles", None), dict):
                styles_map.update(w.map_layer_styles)
        return styles_map

    @staticmethod
    def _parse_preview_wms_or_tile_qs(
        qs: Dict[str, List[str]], default_size: Tuple[int, int] = (1024, 768)
    ) -> Optional[Dict[str, Any]]:
        def _first_ci(keys: Tuple[str, ...], default: str = "") -> str:
            for k in keys:
                vals = qs.get(k)
                if vals:
                    return str(vals[0])
            return default

        layers_raw = _first_ci(("layers", "LAYERS"), "")
        layer_names = [s.strip() for s in layers_raw.split(",") if s.strip()]
        if not layer_names:
            return None
        bbox_raw = _first_ci(("bbox", "BBOX"), "")
        parts = [p.strip() for p in bbox_raw.split(",")]
        if len(parts) != 4:
            return None
        try:
            bbox_tuple = (float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3]))
        except ValueError:
            return None
        try:
            width = max(64, min(2048, int(float(_first_ci(("width", "WIDTH"), str(default_size[0]))))))
        except ValueError:
            width = default_size[0]
        try:
            height = max(64, min(2048, int(float(_first_ci(("height", "HEIGHT"), str(default_size[1]))))))
        except ValueError:
            height = default_size[1]
        srs = _first_ci(("srs", "SRS", "crs", "CRS"), "EPSG:3857").strip() or "EPSG:3857"
        rev = _first_ci(("rev", "REV", "styles", "STYLES"), "")
        return {
            "layer_names": layer_names,
            "bbox": bbox_tuple,
            "width": width,
            "height": height,
            "srs": srs,
            "rev": rev,
        }

    def _handle_preview_wms_request(self, qs: Dict[str, List[str]]) -> Optional[bytes]:
        parsed = self._parse_preview_wms_or_tile_qs(qs, default_size=(1024, 768))
        if not parsed:
            return None
        styles_map = self._map_layer_styles_snapshot()
        return self.persistence.render_qgis_layers_wms_png(
            layer_names=parsed["layer_names"],
            bbox_wgs84=parsed["bbox"],
            width=parsed["width"],
            height=parsed["height"],
            layer_styles=styles_map or None,
            srs=parsed["srs"],
            bbox_is_native=(parsed["srs"].upper() == "EPSG:3301" and abs(parsed["bbox"][0]) > 1000.0),
        )

    def _handle_preview_wms_async(
        self, qs: Dict[str, List[str]], on_finished: Callable[[Optional[bytes]], None]
    ) -> bool:
        parsed = self._parse_preview_wms_or_tile_qs(qs, default_size=(1024, 768))
        if not parsed:
            on_finished(None)
            return False
        styles_map = self._map_layer_styles_snapshot()
        holder = getattr(getattr(self, "_preview_api_dispatcher", None), "_active_jobs", None)
        return self.persistence.render_qgis_layers_wms_png_async(
            layer_names=parsed["layer_names"],
            bbox_wgs84=parsed["bbox"],
            width=parsed["width"],
            height=parsed["height"],
            layer_styles=styles_map or None,
            srs=parsed["srs"],
            bbox_is_native=(parsed["srs"].upper() == "EPSG:3301" and abs(parsed["bbox"][0]) > 1000.0),
            on_finished=on_finished,
            job_holder=holder,
        )

    def _handle_preview_tile_request(self, qs: Dict[str, List[str]]) -> Optional[bytes]:
        parsed = self._parse_preview_wms_or_tile_qs(qs, default_size=(256, 256))
        if not parsed:
            return None
        styles_map = self._map_layer_styles_snapshot()
        srs_u = parsed["srs"].upper()
        is_native_3301 = srs_u == "EPSG:3301" and abs(parsed["bbox"][0]) > 1000.0
        return self.persistence.render_qgis_layers_wms_png(
            layer_names=parsed["layer_names"],
            bbox_wgs84=parsed["bbox"],
            width=parsed["width"],
            height=parsed["height"],
            layer_styles=styles_map or None,
            srs=srs_u,
            bbox_is_native=is_native_3301,
        )

    def _handle_preview_tile_async(
        self, qs: Dict[str, List[str]], on_finished: Callable[[Optional[bytes]], None]
    ) -> bool:
        parsed = self._parse_preview_wms_or_tile_qs(qs, default_size=(256, 256))
        if not parsed:
            on_finished(None)
            return False
        styles_map = self._map_layer_styles_snapshot()
        srs_u = parsed["srs"].upper()
        is_native_3301 = srs_u == "EPSG:3301" and abs(parsed["bbox"][0]) > 1000.0
        holder = getattr(getattr(self, "_preview_api_dispatcher", None), "_active_jobs", None)
        return self.persistence.render_qgis_layers_wms_png_async(
            layer_names=parsed["layer_names"],
            bbox_wgs84=parsed["bbox"],
            width=parsed["width"],
            height=parsed["height"],
            layer_styles=styles_map or None,
            srs=srs_u,
            bbox_is_native=is_native_3301,
            on_finished=on_finished,
            job_holder=holder,
        )

    def _dispatch_preview_tile(self, qs: Dict[str, List[str]]) -> Optional[bytes]:
        parsed = self._parse_preview_wms_or_tile_qs(qs, default_size=(256, 256))
        if not parsed:
            return None
        tile_key = (
            getattr(self.persistence, "_preview_cache_rev", 1),
            parsed["rev"],
            tuple(parsed["layer_names"]),
            parsed["srs"].upper(),
            parsed["width"],
            parsed["height"],
            tuple(round(v, 2) for v in parsed["bbox"]),
        )
        cached = self.persistence.get_cached_preview_tile(tile_key)
        if cached is not None:
            return None if cached == b"__EMPTY__" else cached

        if (
            threading.current_thread() is threading.main_thread()
            or self.iface is None
            or pyqtSignal is None
            or bool(os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS"))
            or getattr(self, "_preview_api_dispatcher", None) is None
        ):
            raw = self._handle_preview_tile_request(qs)
        else:
            ev = threading.Event()
            out: Dict[str, Any] = {}
            self._preview_api_dispatcher.requested.emit(("tile", qs, ev, out))
            if not ev.wait(timeout=6.0):
                return None
            val = out.get("data")
            raw = bytes(val) if val else None

        self.persistence.put_cached_preview_tile(tile_key, raw if raw else b"__EMPTY__")
        return raw

    def _dispatch_preview_wms(self, qs: Dict[str, List[str]]) -> Optional[bytes]:
        if (
            threading.current_thread() is threading.main_thread()
            or self.iface is None
            or pyqtSignal is None
            or bool(os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS"))
            or getattr(self, "_preview_api_dispatcher", None) is None
        ):
            return self._handle_preview_wms_request(qs)
        ev = threading.Event()
        out: Dict[str, Any] = {}
        self._preview_api_dispatcher.requested.emit(("wms", qs, ev, out))
        if not ev.wait(timeout=6.0):
            return None
        data = out.get("data")
        return bytes(data) if data else None

    def _ensure_preview_http_server(self) -> str:
        if not self._preview_dir or not os.path.isdir(self._preview_dir):
            self._preview_dir = tempfile.mkdtemp(prefix="qdash_preview_")
        if getattr(self, "_preview_api_dispatcher", None) is None:
            self._preview_api_dispatcher = _PreviewApiDispatcher(
                self._handle_preview_features_request,
                self,
                wms_callback=self._handle_preview_wms_request,
                tile_callback=self._handle_preview_tile_request,
                wms_async_callback=self._handle_preview_wms_async,
                tile_async_callback=self._handle_preview_tile_async,
            )
        if self._preview_server is None:
            handler_cls = _make_preview_handler(
                self._preview_dir,
                feature_fetcher=self._dispatch_preview_features,
                wms_fetcher=self._dispatch_preview_wms,
                address_fetcher=self._handle_preview_address_request,
                tile_fetcher=self._dispatch_preview_tile,
            )
            srv = _ThreadingPreviewServer(("127.0.0.1", 0), handler_cls)
            port = srv.server_address[1]
            self._preview_server = srv
            self._preview_url = f"http://127.0.0.1:{port}/preview.html"
            t = threading.Thread(target=srv.serve_forever, daemon=True)
            t.start()
        return self._preview_url

    def _handle_preview_address_request(self, qs: Dict[str, List[str]]) -> List[Dict[str, Any]]:
        vals = qs.get("q") or qs.get("address") or []
        query = str(vals[0]).strip() if vals else ""
        if len(query) < 2:
            return []
        return search_estonian_address(query, limit=10)

    def _run_preview_js(self, js_code: str) -> bool:
        """Execute JS directly inside the live preview WebEngine view when already loaded."""
        if not getattr(self.config, "preview_mode", False):
            return False
        web_view = getattr(self, "_preview_web_view", None)
        if web_view is None or not getattr(self, "_preview_loaded_once", False):
            return False
        page_fn = getattr(web_view, "page", None)
        page = page_fn() if callable(page_fn) else None
        run_js = getattr(page, "runJavaScript", None) if page is not None else None
        if not callable(run_js):
            return False
        try:
            run_js(js_code)
            return True
        except Exception:
            return False

    def _on_preview_build_ready(self, payload: Any) -> None:
        info = payload if isinstance(payload, dict) else {}
        seq = int(info.get("seq", -1) or -1)
        from_overlay = bool(info.get("from_overlay", False))
        is_async = bool(info.get("async", False))
        if seq != self._preview_build_seq or (is_async and not getattr(self.config, "preview_mode", False)):
            if not from_overlay:
                self._set_loading_overlay(False)
            return
        base_url = str(info.get("base_url") or "")
        open_ext = bool(info.get("open_external_if_fallback", False))
        unchanged = bool(info.get("unchanged", False))
        force = bool(info.get("force", False))
        lang = self.config.language or "et"
        try:
            cache_busted = f"{base_url}?ts={int(time.time() * 1000)}"
            if hasattr(self, "workspace_view_stack"):
                self.workspace_view_stack.setCurrentIndex(1)
            if hasattr(self, "lbl_preview_url"):
                self.lbl_preview_url.setText(base_url)
            if self._preview_web_view is not None:
                if not (unchanged and not force and getattr(self, "_preview_loaded_once", False)):
                    try:
                        qurl_cls = getattr(QtCore, "QUrl", None)
                        if qurl_cls is not None and hasattr(self._preview_web_view, "load"):
                            self._preview_web_view.load(qurl_cls(cache_busted))
                            self._preview_loaded_once = True
                        elif qurl_cls is not None and hasattr(self._preview_web_view, "setUrl"):
                            self._preview_web_view.setUrl(qurl_cls(cache_busted))
                            self._preview_loaded_once = True
                    except Exception:
                        pass
            elif open_ext:
                self._open_preview_in_browser()
            if not from_overlay:
                self._set_loading_overlay(
                    True,
                    title=tr("loading_preview_title", lang),
                    subtitle="",
                    done=100,
                    total=100,
                    force_pump=True,
                )
        finally:
            if not from_overlay:
                self._set_loading_overlay(False)

    @staticmethod
    def _can_run_async_qt() -> bool:
        """Return True when running inside a real PyQt GUI event loop (not unit-test stubs)."""
        return bool(
            pyqtSignal is not None
            and (
                hasattr(QtCore, "PYQT_VERSION_STR")
                or getattr(getattr(QtCore, "QObject", None), "__module__", "").startswith(("PyQt5", "PyQt6"))
            )
            and getattr(QtCore, "QCoreApplication", None) is not None
            and QtCore.QCoreApplication.instance() is not None
            and not os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS")
            and not os.environ.get("PYTEST_CURRENT_TEST")
        )

    def _refresh_html_preview(
        self,
        open_external_if_fallback: bool = False,
        _from_overlay: bool = False,
        force: bool = False,
    ) -> None:
        lang = self.config.language or "et"
        self._set_loading_overlay(
            True,
            title=tr("loading_preview_title", lang),
            subtitle="",
            done=96 if _from_overlay else 10,
            total=100,
            force_pump=True,
        )
        base_url = self._ensure_preview_http_server()
        out_path = os.path.join(self._preview_dir, "preview.html")
        proj_dir = DashboardPersistenceManager.get_current_project_dir()

        self._preview_build_seq += 1
        build_seq = self._preview_build_seq
        real_qt = self._can_run_async_qt()

        if real_qt and not _from_overlay:
            # Capture only lightweight O(1) QGIS styles & WFS descriptors on main thread;
            # run GeoJSON/pyramid packaging, spatial cache, and HTML compilation off-thread.
            qgis_snap = self.persistence.snapshot_qgis_layer_specs(
                self.config, only_referenced=True, include_cached=True
            )
            qgis_specs = qgis_snap.get("specs") or {}
            self.persistence.set_preview_bg_specs(
                qgis_specs,
                transform_context=qgis_snap.get("transform_context"),
                ellipsoid=qgis_snap.get("ellipsoid") or "GRS80",
            )
            known_ds = {ds.name for ds in self.config.data_sources}
            for ln_spec, sp in qgis_specs.items():
                inf = sp.get("inferred_wfs")
                if inf is not None and ln_spec not in known_ds:
                    self.config.data_sources.append(inf)
                    known_ds.add(ln_spec)

            preview_sig = None
            try:
                sig_payload = {
                    "cfg": self.config.to_dict(),
                    "counts": {
                        str(k): len(v or [])
                        for k, v in (self.persistence.layer_records_cache or {}).items()
                    },
                    "geo_counts": {
                        str(k): len((v or {}).get("features") or [])
                        for k, v in (self.persistence.layer_geojson_cache or {}).items()
                    },
                    "pyr_keys": sorted(str(k) for k in (self.persistence.layer_pyramid_cache or {}).keys()),
                    "styles": {
                        str(k): (sp.get("qgis_style") or {})
                        for k, sp in qgis_specs.items()
                    },
                }
                preview_sig = json.dumps(sig_payload, sort_keys=True, default=str)
            except Exception:
                preview_sig = None

            if (
                not force
                and preview_sig is not None
                and getattr(self, "_preview_last_sig", None) == preview_sig
                and os.path.isfile(out_path)
            ):
                self._on_preview_build_ready(
                    {
                        "seq": build_seq,
                        "base_url": base_url,
                        "open_external_if_fallback": open_external_if_fallback,
                        "from_overlay": _from_overlay,
                        "async": False,
                        "unchanged": True,
                        "force": bool(force),
                    }
                )
                return
            self._preview_last_sig = None

            # Extract any uncached static/QGIS layers across ALL pages on main thread
            uncached_main = [
                ln_sp
                for ln_sp, sp in qgis_specs.items()
                if not (self.persistence.layer_geojson_cache.get(ln_sp) or {}).get("features")
            ]
            pre_geojson = (
                self.persistence.export_initial_geojson_for_html(
                    self.config, allow_qgis_lookup=True, qgis_meta=qgis_specs
                )
                if uncached_main
                else {}
            )
            self.persistence._enrich_natura_pria_overlap({}, config=self.config)
            spatial_rels_pre = self.persistence.export_spatial_relations_for_html(self.config, allow_qgis_lookup=True)
            cfg_snap = DashboardConfig.from_dict(self.config.to_dict())
            cfg_snap.package_layers_in_export = True
            cfg_snap.export_format = "html"
            cfg_snap.export_mode = "compact_single"
            records_snap = dict(self.persistence.layer_records_cache)
            excel_snap = dict(self.persistence.excel_records_cache)

            self._set_loading_overlay(
                True,
                title=tr("loading_preview_title", lang),
                subtitle="",
                done=35,
                total=100,
                force_pump=True,
            )

            def _compile_bg() -> None:
                try:
                    initial_geojson = dict(
                        self.persistence.export_initial_geojson_for_html(
                            cfg_snap, allow_qgis_lookup=False, qgis_meta=qgis_specs
                        )
                        or {}
                    )
                    if pre_geojson:
                        initial_geojson.update(pre_geojson)
                    layer_stats, vector_pyramids = self.persistence.export_pyramids_for_html(
                        cfg_snap,
                        include_lod1=True,
                        lod1_max_sync_features=95000,
                        allow_qgis_lookup=False,
                        qgis_meta=qgis_specs,
                        skip_overlap_enrich=True,
                    )
                    preview_rev = self.persistence.build_preview_spatial_cache(cfg_snap)
                    HtmlDashboardExporter.export_to_file(
                        config=cfg_snap,
                        layer_records=records_snap,
                        excel_records_by_id=excel_snap,
                        output_path=out_path,
                        project_dir=proj_dir,
                        initial_geojson=initial_geojson,
                        layer_stats=layer_stats,
                        vector_pyramids=vector_pyramids,
                        spatial_relations=spatial_rels_pre,
                        has_preview_api=True,
                        preview_cache_rev=preview_rev,
                    )
                    err = None
                    if preview_sig is not None:
                        self._preview_last_sig = preview_sig
                except Exception as exc:
                    err = str(exc)
                    self._preview_last_sig = None
                self._hydr_bridge.preview_ready.emit(
                    {
                        "seq": build_seq,
                        "base_url": base_url,
                        "open_external_if_fallback": open_external_if_fallback,
                        "from_overlay": _from_overlay,
                        "async": True,
                        "err": err,
                    }
                )

            threading.Thread(target=_compile_bg, daemon=True).start()
            return

        if not real_qt or _from_overlay:
            self.persistence._enrich_natura_pria_overlap({}, config=self.config)
        spatial_rels_sync = self.persistence.export_spatial_relations_for_html(self.config, allow_qgis_lookup=True)
        initial_geojson = self.persistence.export_initial_geojson_for_html(self.config)
        self._set_loading_overlay(
            True,
            title=tr("loading_preview_title", lang),
            subtitle="",
            done=97 if _from_overlay else 45,
            total=100,
            force_pump=True,
        )
        layer_stats, vector_pyramids = self.persistence.export_pyramids_for_html(
            self.config, include_lod1=True, lod1_max_sync_features=95000, skip_overlap_enrich=True
        )
        self._set_loading_overlay(
            True,
            title=tr("loading_preview_title", lang),
            subtitle="",
            done=98 if _from_overlay else 70,
            total=100,
            force_pump=True,
        )

        try:
            cfg_prev = DashboardConfig.from_dict(self.config.to_dict())
            cfg_prev.package_layers_in_export = True
            cfg_prev.export_format = "html"
            cfg_prev.export_mode = "compact_single"
            preview_rev = self.persistence.build_preview_spatial_cache(cfg_prev)
            HtmlDashboardExporter.export_to_file(
                config=cfg_prev,
                layer_records=self.persistence.layer_records_cache,
                excel_records_by_id=self.persistence.excel_records_cache,
                output_path=out_path,
                project_dir=proj_dir,
                initial_geojson=initial_geojson,
                layer_stats=layer_stats,
                vector_pyramids=vector_pyramids,
                spatial_relations=spatial_rels_sync,
                has_preview_api=True,
                preview_cache_rev=preview_rev,
            )
            self._on_preview_build_ready(
                {
                    "seq": build_seq,
                    "base_url": base_url,
                    "open_external_if_fallback": open_external_if_fallback,
                    "from_overlay": _from_overlay,
                    "async": False,
                }
            )
        except Exception:
            if not _from_overlay:
                self._set_loading_overlay(False)

    def _open_preview_in_browser(self) -> None:
        if not self._preview_url:
            self._refresh_html_preview(open_external_if_fallback=False)
        if not os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS") and not os.environ.get("PYTEST_CURRENT_TEST"):
            webbrowser.open(self._preview_url)

    def _stop_preview_server(self) -> None:
        if self._preview_server is not None:
            try:
                self._preview_server.shutdown()
                self._preview_server.server_close()
            except Exception:
                pass
            self._preview_server = None
        if self._preview_dir and os.path.isdir(self._preview_dir):
            try:
                shutil.rmtree(self._preview_dir, ignore_errors=True)
            except Exception:
                pass
            self._preview_dir = ""

    def _available_screen_rect(self) -> Tuple[int, int, int, int]:
        """Return (x, y, width, height) of the active screen/QGIS main window."""
        try:
            mw = self.iface.mainWindow() if self.iface is not None and hasattr(self.iface, "mainWindow") else None
            scr = None
            if QGuiApplication is not None:
                if hasattr(QGuiApplication, "screenAt") and hasattr(self, "frameGeometry"):
                    fg = self.frameGeometry()
                    if fg is not None and hasattr(fg, "center"):
                        scr = QGuiApplication.screenAt(fg.center())
                if scr is None and mw is not None and hasattr(QGuiApplication, "screenAt") and hasattr(mw, "frameGeometry"):
                    mfg = mw.frameGeometry()
                    if mfg is not None and hasattr(mfg, "center"):
                        scr = QGuiApplication.screenAt(mfg.center())
                if scr is None and hasattr(QGuiApplication, "primaryScreen"):
                    scr = QGuiApplication.primaryScreen()
            if scr is not None and hasattr(scr, "availableGeometry"):
                ag = scr.availableGeometry()
                if ag is not None and int(ag.width()) > 100 and int(ag.height()) > 100:
                    return int(ag.x()), int(ag.y()), int(ag.width()), int(ag.height())
            if mw is not None and hasattr(mw, "width") and int(mw.width()) > 200:
                return int(mw.x()), int(mw.y()), int(mw.width()), int(mw.height())
        except Exception:
            pass
        return 0, 0, 1366, 768

    def _init_dock_title_bar(self) -> None:
        bar = QFrame()
        bar.setObjectName("DockTitleBar")
        if hasattr(bar, "setFixedHeight"):
            bar.setFixedHeight(28)
        row = QHBoxLayout(bar)
        row.setContentsMargins(8, 2, 4, 2)
        row.setSpacing(4)

        self.lbl_dock_bar_title = QLabel(tr("plugin_title", "et"))
        self.lbl_dock_bar_title.setProperty("role", "cardTitleSmall")
        if hasattr(self.lbl_dock_bar_title, "setMinimumWidth"):
            self.lbl_dock_bar_title.setMinimumWidth(60)

        def _mk_ctrl(txt: str, slot: Any) -> QPushButton:
            b = QPushButton(txt)
            b.setProperty("btnRole", "dockCtrl")
            if hasattr(b, "setFixedSize"):
                b.setFixedSize(24, 20)
            b.clicked.connect(slot)
            return b

        self.btn_dock_shade = _mk_ctrl("▾", lambda _c=False: self._toggle_dock_shaded())
        self.btn_dock_minimize = _mk_ctrl("—", lambda _c=False: self._on_dock_minimize_clicked())
        self.btn_dock_float = _mk_ctrl("⧉", lambda _c=False: self._toggle_dock_floating())
        self.btn_dock_maximize = _mk_ctrl("⬜", lambda _c=False: self._on_dock_maximize_clicked())
        self.btn_dock_close = _mk_ctrl("✕", lambda _c=False: self.hide())

        row.addWidget(self.lbl_dock_bar_title, 1)
        row.addWidget(self.btn_dock_shade)
        row.addWidget(self.btn_dock_minimize)
        row.addWidget(self.btn_dock_float)
        row.addWidget(self.btn_dock_maximize)
        row.addWidget(self.btn_dock_close)

        self._dock_title_bar = bar
        if hasattr(self, "setTitleBarWidget"):
            self.setTitleBarWidget(bar)

    def _toggle_dock_shaded(self, shaded: Optional[bool] = None) -> None:
        next_state = (not getattr(self, "_dock_shaded", False)) if shaded is None else bool(shaded)
        self._dock_shaded = next_state
        for attr in ("toolbar_scroll", "studio_stack", "lbl_status"):
            w = getattr(self, attr, None)
            if w is not None and hasattr(w, "setVisible"):
                w.setVisible(not next_state)
        if next_state:
            if hasattr(self, "floating_palette") and self.floating_palette is not None and not getattr(self, "_palette_docked", True):
                self.floating_palette.hide()
            if hasattr(self, "setMaximumHeight"):
                self.setMaximumHeight(34)
        else:
            if hasattr(self, "setMaximumHeight"):
                self.setMaximumHeight(16777215)
            if hasattr(self, "floating_palette") and self.floating_palette is not None and not getattr(self, "_palette_docked", True):
                if not hasattr(self, "btn_mini_bar") or self.btn_mini_bar.isChecked():
                    self.floating_palette.show()
        if hasattr(self, "btn_dock_shade"):
            self.btn_dock_shade.setText("▸" if next_state else "▾")
        lang = self.config.language or "et"
        if hasattr(self, "lbl_dock_bar_title"):
            self.lbl_dock_bar_title.setText(
                tr("dock_shaded_status", lang) if next_state else f"📊 {tr('plugin_title', lang)}"
            )

    def _on_dock_minimize_clicked(self) -> None:
        is_float = bool(self.isFloating()) if hasattr(self, "isFloating") else False
        if is_float and hasattr(self, "showMinimized"):
            self._ensure_floating_window_hints(apply_bounds=False)
            self.showMinimized()
        else:
            self._toggle_dock_shaded()

    def _toggle_dock_floating(self) -> None:
        if getattr(self, "_dock_shaded", False):
            self._toggle_dock_shaded(False)
        is_float = bool(self.isFloating()) if hasattr(self, "isFloating") else False
        next_float = not is_float
        if hasattr(self, "setFloating"):
            self.setFloating(next_float)
        if hasattr(self, "btn_dock_float"):
            self.btn_dock_float.setText("📌" if next_float else "⧉")
        if next_float:
            self._ensure_floating_window_hints(apply_bounds=True)

    def _on_dock_maximize_clicked(self) -> None:
        if getattr(self, "_dock_shaded", False):
            self._toggle_dock_shaded(False)
        is_float = bool(self.isFloating()) if hasattr(self, "isFloating") else False
        if is_float:
            self._ensure_floating_window_hints(apply_bounds=False)
            is_max = bool(self.isMaximized()) if hasattr(self, "isMaximized") else False
            if is_max and hasattr(self, "showNormal"):
                self.showNormal()
                if hasattr(self, "btn_dock_maximize"):
                    self.btn_dock_maximize.setText("⬜")
            elif hasattr(self, "showMaximized"):
                self.showMaximized()
                if hasattr(self, "btn_dock_maximize"):
                    self.btn_dock_maximize.setText("🗗")
            return

        mw = self.iface.mainWindow() if self.iface is not None and hasattr(self.iface, "mainWindow") else None
        _sx, _sy, sw, _sh = self._available_screen_rect()
        self._dock_expanded_ratio = not getattr(self, "_dock_expanded_ratio", False)
        target_w = min(1220, int(sw * 0.84)) if self._dock_expanded_ratio else min(760, max(360, int(sw * 0.45)))
        if mw is not None and hasattr(mw, "resizeDocks"):
            try:
                mw.resizeDocks([self], [target_w], qt_enum(Qt, "Orientation", "Horizontal"))
            except Exception:
                pass
        if hasattr(self, "btn_dock_maximize"):
            self.btn_dock_maximize.setText("🗗" if self._dock_expanded_ratio else "⬜")

    def _on_dock_top_level_changed(self, floating: bool) -> None:
        if hasattr(self, "btn_dock_float"):
            self.btn_dock_float.setText("📌" if floating else "⧉")
        if not floating:
            if hasattr(self, "btn_dock_maximize"):
                self.btn_dock_maximize.setText("⬜")
            self.fit_initial_laptop_geometry()
            return
        timer_cls = getattr(QtCore, "QTimer", None)
        if timer_cls is not None and hasattr(timer_cls, "singleShot"):
            timer_cls.singleShot(60, lambda: self._ensure_floating_window_hints(apply_bounds=True))
        else:
            self._ensure_floating_window_hints(apply_bounds=True)

    def _ensure_floating_window_hints(self, apply_bounds: bool = True) -> None:
        if hasattr(self, "isFloating") and not self.isFloating():
            return
        if QApplication is not None and hasattr(QApplication, "mouseButtons"):
            try:
                no_btn = _safe_qt_enum(Qt, "MouseButton", "NoButton", 0)
                cur_btns = QApplication.mouseButtons()
                is_pressed = bool(cur_btns != no_btn) if no_btn != 0 or type(cur_btns) is not int else bool(cur_btns)
                if is_pressed:
                    timer_cls = getattr(QtCore, "QTimer", None)
                    if timer_cls is not None and hasattr(timer_cls, "singleShot"):
                        timer_cls.singleShot(80, lambda: self._ensure_floating_window_hints(apply_bounds=apply_bounds))
                    return
            except Exception:
                pass

        win_flag = _safe_qt_enum(Qt, "WindowType", "Window", 0)
        title_flag = _safe_qt_enum(Qt, "WindowType", "WindowTitleHint", 0)
        sys_flag = _safe_qt_enum(Qt, "WindowType", "WindowSystemMenuHint", 0)
        min_flag = _safe_qt_enum(Qt, "WindowType", "WindowMinimizeButtonHint", 0)
        max_flag = _safe_qt_enum(Qt, "WindowType", "WindowMaximizeButtonHint", 0)
        close_flag = _safe_qt_enum(Qt, "WindowType", "WindowCloseButtonHint", 0)
        desired = win_flag | title_flag | sys_flag | min_flag | max_flag | close_flag
        if desired and hasattr(self, "windowFlags") and hasattr(self, "setWindowFlags"):
            try:
                cur_flags = self.windowFlags()
                has_min = bool(cur_flags & min_flag) if min_flag else True
                has_win = bool(cur_flags & win_flag) if win_flag else True
                if not (has_min and has_win):
                    was_vis = bool(self.isVisible()) if hasattr(self, "isVisible") else True
                    self.setWindowFlags(desired)
                    if was_vis:
                        self.show()
            except Exception:
                pass
        if apply_bounds and not getattr(self, "_dock_shaded", False):
            sx, sy, sw, sh = self._available_screen_rect()
            w = min(1140, max(360, int(sw * 0.88)))
            h = min(760, max(320, int(sh * 0.84)))
            cx = sx + max(0, (sw - w) // 2)
            cy = sy + max(0, (sh - h) // 2)
            if hasattr(self, "setGeometry"):
                try:
                    self.setGeometry(cx, cy, w, h)
                except Exception:
                    self.resize(w, h)

    def fit_initial_laptop_geometry(self, main_win: Any = None) -> None:
        """Size the dock proportionally so QGIS canvas and controls fit small laptop displays."""
        mw = main_win or (self.iface.mainWindow() if self.iface is not None and hasattr(self.iface, "mainWindow") else None)
        _sx, _sy, sw, _sh = self._available_screen_rect()
        ref_w = int(mw.width()) if mw is not None and hasattr(mw, "width") and int(mw.width()) > 200 else sw
        target_w = min(840, max(340, int(ref_w * 0.48)))
        if hasattr(self, "splitter") and hasattr(self.splitter, "setSizes"):
            cat_w = 195 if ref_w < 1380 else 260
            ws_w = max(240, target_w - cat_w - 8)
            try:
                self.splitter.setSizes([cat_w, ws_w])
            except Exception:
                pass
        if mw is not None and hasattr(mw, "resizeDocks"):
            try:
                mw.resizeDocks([self], [target_w], qt_enum(Qt, "Orientation", "Horizontal"))
            except Exception:
                pass
        self._sync_responsive_dock_ui()

    def _sync_responsive_dock_ui(self) -> None:
        if hasattr(self, "loading_overlay_card") and hasattr(self, "width"):
            try:
                w = int(self.width())
                if w > 80 and hasattr(self.loading_overlay_card, "setFixedWidth"):
                    self.loading_overlay_card.setFixedWidth(min(420, max(220, w - 48)))
            except Exception:
                pass

    def resizeEvent(self, event: Any) -> None:
        if hasattr(super(), "resizeEvent"):
            super().resizeEvent(event)
        self._sync_responsive_dock_ui()

    def eventFilter(self, obj: Any, event: Any) -> bool:
        try:
            wheel_t = _safe_qt_enum(QtCore.QEvent, "Type", "Wheel", None)
            if wheel_t is not None and event is not None and event.type() == wheel_t:
                for attr in ("toolbar_scroll", "design_bar_scroll"):
                    sa = getattr(self, attr, None)
                    if sa is not None and hasattr(sa, "viewport") and obj is sa.viewport():
                        hbar = sa.horizontalScrollBar() if hasattr(sa, "horizontalScrollBar") else None
                        if hbar is not None:
                            delta = 0
                            if hasattr(event, "angleDelta") and event.angleDelta() is not None:
                                delta = int(event.angleDelta().y() or event.angleDelta().x() or 0)
                            if delta:
                                hbar.setValue(int(hbar.value()) - int(delta * 0.6))
                                return True
        except Exception:
            pass
        return super().eventFilter(obj, event) if hasattr(super(), "eventFilter") else False

    def hideEvent(self, event: Any) -> None:
        if hasattr(self, "floating_palette") and self.floating_palette is not None and not getattr(self, "_palette_docked", True):
            self.floating_palette.hide()
        super().hideEvent(event)

    def showEvent(self, event: Any) -> None:
        super().showEvent(event)
        if hasattr(self, "floating_palette") and self.floating_palette is not None and not getattr(self, "_palette_docked", True):
            if not hasattr(self, "btn_mini_bar") or self.btn_mini_bar.isChecked():
                self.floating_palette.show()
                self.floating_palette.raise_()

    def closeEvent(self, event: Any) -> None:
        if hasattr(self, "floating_palette") and self.floating_palette is not None and not getattr(self, "_palette_docked", True):
            self.floating_palette.hide()
        self._stop_preview_server()
        super().closeEvent(event)

    def refresh_connections_panel(self) -> None:
        lang = self.config.language or "et"
        self.connections_list.clear()
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        icons = {
            "wfs": "🌐 [WFS]",
            "wms": "🗺️ [WMS]",
            "excel": "📊 [XLSX]",
            "csv": "📄 [CSV]",
            "sharepoint_list": "☁️ [SharePoint]",
            "qgis_layer": "📌 [QGIS]",
        }
        n_joins = len(self.config.joins)
        self.lbl_conn_summary.setText(
            f"{len(self.config.data_sources)} {tr('conn_sources_lbl', lang)} · {n_joins} {tr('conn_joins_lbl', lang)}"
        )
        self.btn_model_conns.setText(f"🕸️ {tr('btn_model_conns', lang)} ({len(self.config.widget_connections)})")
        self.btn_conn_jump.setText(f"🔗 {tr('tab_connections', lang)} ({len(self.config.data_sources)})")
        if not self.config.data_sources:
            it = QListWidgetItem(tr("conn_none", lang))
            self.connections_list.addItem(it)
            return

        for ds in self.config.data_sources:
            prefix = icons.get(ds.source_type, f"[{ds.source_type.upper()}]")
            target = ds.typename_or_layers or ds.portable_path or ds.url or ""
            rec_cnt = len(self.persistence.layer_records_cache.get(ds.name, []))
            st = (
                self.persistence.layer_stats_cache.get(ds.name)
                or self.persistence.get_or_build_layer_stats(ds.name)
            )
            total_ha = float(st.get("total_area_ha", 0.0) or 0.0) if st else 0.0
            geom_lbl = str(st.get("geom_type", "") or "") if st else ""
            if rec_cnt:
                extra = f", {total_ha:,.1f} ha".replace(",", " ") if total_ha > 0 else ""
                geom_part = f", {geom_lbl}" if geom_lbl else ""
                stat = f"{rec_cnt:,}".replace(",", " ") + f" {tr('records', lang)}{extra}{geom_part}"
            else:
                stat = tr("conn_pending", lang)
            it = QListWidgetItem(f"{prefix} {ds.name}\n    {target} ({stat})")
            it.setData(role, ds.id)
            self.connections_list.addItem(it)

        for jc in self.config.joins:
            it = QListWidgetItem(
                f"🔗 Join: {jc.source_key_field} ↔ {jc.target_key_field} ({jc.join_prefix or ''})"
            )
            it.setData(role, f"join:{jc.id}")
            self.connections_list.addItem(it)

    def _quick_add_qgis_layer(self) -> None:
        schemas = DashboardPersistenceManager.list_qgis_project_layer_schemas()
        existing = {d.name for d in self.config.data_sources}
        candidates = [name for name in schemas.keys() if name not in existing]
        if not candidates:
            return
        name = candidates[0]
        lyr = self.persistence._find_qgis_layer_by_name(name)
        inferred = (
            OgcConnector.infer_datasource_from_qgis_layer(
                lyr, project_dir=DashboardPersistenceManager.get_current_project_dir()
            )
            if lyr is not None
            else None
        )
        if inferred is not None:
            ds = inferred
        else:
            ds = DataSourceConfig(
                name=name,
                source_type="qgis_layer",
                typename_or_layers=name,
                is_basemap=False,
                restrict_to_bbox=False,
                max_features=0,
            )
        self.config.data_sources.append(ds)
        self._save_project_state()
        self.refresh_connections_panel()
        self.reload_and_hydrate()

    def _load_selected_connection(self) -> None:
        it = self.connections_list.currentItem()
        if it is None:
            return
        ds_id = str(it.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or "")
        ds = next((d for d in self.config.data_sources if d.id == ds_id), None)
        if not ds:
            return
        if ds.source_type in ("wfs", "wms"):
            self._load_catalog_layer_into_qgis(
                {
                    "service_type": ds.source_type,
                    "url": ds.url,
                    "typename": ds.typename_or_layers,
                    "name": ds.typename_or_layers,
                    "title": ds.name,
                    "authcfg": ds.authcfg_id,
                    "is_basemap": ds.is_basemap,
                }
            )
        else:
            self.reload_and_hydrate(force_refresh_sources=True)

    def _remove_selected_connection(self) -> None:
        it = self.connections_list.currentItem()
        if it is None:
            return
        key = str(it.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or "")
        self._remove_connection_by_key(key)

    def _remove_connection_at_row(self, row: int) -> None:
        if row < 0 or row >= self.connections_list.count():
            return
        it = self.connections_list.item(row)
        if it is None:
            return
        key = str(it.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or "")
        self._remove_connection_by_key(key)

    def _remove_connection_by_key(self, key: str) -> None:
        if not key:
            return
        if key.startswith("join:"):
            jid = key[5:]
            self.config.joins = [j for j in self.config.joins if j.id != jid]
        else:
            ds = next((d for d in self.config.data_sources if d.id == key), None)
            if not ds:
                return
            self.config.data_sources = [d for d in self.config.data_sources if d.id != key]
            self.config.joins = [
                j
                for j in self.config.joins
                if j.source_table_id != key and j.target_layer_id != key
            ]
            self.persistence.layer_records_cache.pop(ds.name, None)
            self.persistence.layer_geojson_cache.pop(ds.name, None)
            self.persistence.excel_records_cache.pop(ds.id, None)
            if hasattr(self.persistence, "layer_stats_cache"):
                self.persistence.layer_stats_cache.pop(ds.name, None)
            if hasattr(self.persistence, "layer_pyramid_cache"):
                self.persistence.layer_pyramid_cache.pop(ds.name, None)
            for w in getattr(self.config, "widgets", []):
                if isinstance(getattr(w, "map_layers", None), list):
                    w.map_layers = [ln for ln in w.map_layers if ln not in (ds.name, ds.id)]
                if w.layer_name in (ds.name, ds.id) and w.widget_type == "map":
                    w.layer_name = w.map_layers[0] if w.map_layers else ""
        self._save_project_state()
        self.refresh_connections_panel()
        self.refresh_catalog_panel()
        self.rebuild_dashboard_ui()

    def _on_connection_context_menu(self, item: Any, global_pos: Any) -> None:
        if item is None:
            return
        lang = self.config.language or "et"
        key = str(item.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or "")
        self.connections_list.setCurrentItem(item)
        menu = QMenu(self)
        act_load = None
        if not key.startswith("join:"):
            act_load = menu.addAction(f"⚡ {tr('conn_load_qgis', lang)}")
        act_edit = menu.addAction(f"✏️ {tr('conn_edit_btn', lang)}")
        menu.addSeparator()
        act_rm = menu.addAction(f"🗑 {tr('ctx_remove', lang)}")
        chosen = exec_menu(menu, global_pos)
        if chosen is None:
            return
        if chosen == act_load:
            self._load_selected_connection()
        elif chosen == act_edit:
            self.open_sources_dialog()
        elif chosen == act_rm:
            self._remove_connection_by_key(key)

    def _on_reset_filters_clicked(self) -> None:
        self.filter_bus.clear_all()
        if getattr(self.config, "preview_mode", False):
            if not self._run_preview_js("if (typeof clearAllFilters === 'function') clearAllFilters();"):
                pass

    def _toggle_language(self) -> None:
        self.config.language = "en" if self.config.language == "et" else "et"
        self._save_project_state()
        self._retranslate_ui()
        self.refresh_catalog_panel()
        self.refresh_connections_panel()
        self.rebuild_dashboard_ui()
        if getattr(self.config, "preview_mode", False):
            lang_js = json.dumps(self.config.language or "et")
            if not self._run_preview_js(f"if (typeof setHostLanguage === 'function') setHostLanguage({lang_js});"):
                self._refresh_html_preview(open_external_if_fallback=False)

    # ------------------------------------------------------------------
    # Persistent Data Catalog + Non-Blocking Async Background Refresh
    # ------------------------------------------------------------------

    def _schedule_background_catalog_sync_if_needed(self) -> None:
        stale = self.catalog_manager.stale_servers()
        if stale:
            names = [s.get("name", "") for s in stale if s.get("name")]
            has_empty = any(not s.get("layers") for s in stale)
            if has_empty:
                self.lbl_cat_status.setText(tr("cat_first_init", self.config.language))
            self.start_catalog_background_refresh(server_names=names, force=False)

    def start_catalog_background_refresh(
        self, server_names: Optional[List[str]] = None, force: bool = True
    ) -> None:
        if self._refresh_thread_active:
            return
        self._refresh_thread_active = True
        self.cat_progress.show()
        self.btn_cat_refresh.setEnabled(False)
        self.lbl_cat_status.setText(tr("cat_syncing", self.config.language))

        self.catalog_manager.refresh_async(
            server_names=server_names,
            on_server_updated=lambda srv: self._bridge.server_updated.emit(
                str(srv.get("name", "")),
                not bool(srv.get("last_error")),
                str(srv.get("last_error", "")),
            ),
            on_all_finished=lambda: self._bridge.all_finished.emit(),
        )

    def _on_catalog_server_updated(self, srv_name: str, ok: bool, err: str) -> None:
        lang = self.config.language
        if ok:
            self.lbl_cat_status.setText(tr("cat_loading_srv", lang, name=srv_name))
        elif err:
            self.lbl_cat_status.setText(tr("cat_err_srv", lang, name=srv_name, error=err[:80]))
        self.catalog_data = self.catalog_manager.load_or_initialize()
        self.refresh_catalog_panel()

    def _on_catalog_refresh_finished(self) -> None:
        self._refresh_thread_active = False
        self.cat_progress.hide()
        self.btn_cat_refresh.setEnabled(True)
        self.catalog_data = self.catalog_manager.load_or_initialize()
        n_cached = self.catalog_manager.total_cached_layers()
        self.lbl_cat_status.setText(tr("cat_ready", self.config.language, count=n_cached))
        self.refresh_catalog_panel()

    def refresh_catalog_views(self) -> None:
        """Public entry point called on clean dock creation without forcing WFS feature hydration."""
        self.refresh_catalog_panel()
        self.rebuild_dashboard_ui()

    def refresh_catalog_panel(self) -> None:
        """Populate CatalogTreeWidget purely from metadata/cache (0 features fetched)."""
        lang = self.config.language or "et"
        query = self.ed_cat_search.text().strip().lower()
        user_role = qt_enum(Qt, "ItemDataRole", "UserRole")

        self.catalog_tree.clear()

        # 1. Active QGIS Project Layers (metadata schemas only!)
        root_canvas = QTreeWidgetItem([f"🗂️  {tr('cat_root_canvas', lang)}"])
        root_canvas.setData(0, user_role, {"type": "root_canvas"})
        self.catalog_tree.addTopLevelItem(root_canvas)

        qgis_schemas = DashboardPersistenceManager.list_qgis_project_layer_schemas()
        for lyr_name, fields in qgis_schemas.items():
            if query and query not in lyr_name.lower():
                continue
            item = QTreeWidgetItem([f"📐 {lyr_name} ({len(fields)} välja)" if lang == "et" else f"📐 {lyr_name}"])
            item.setData(
                0,
                user_role,
                {
                    "type": "qgis_layer",
                    "name": lyr_name,
                    "title": lyr_name,
                    "fields": fields,
                },
            )
            root_canvas.addChild(item)
        root_canvas.setExpanded(True)

        # 2. Excel / CSV Files on Dashboard
        root_files = QTreeWidgetItem([f"📊  {tr('cat_root_files', lang)}"])
        root_files.setData(0, user_role, {"type": "root_files"})
        self.catalog_tree.addTopLevelItem(root_files)
        for ds in self.config.data_sources:
            if ds.source_type in ("excel", "csv"):
                lbl = f"{ds.name} [{ds.sheet_name or ds.source_type}]"
                if query and query not in lbl.lower():
                    continue
                item = QTreeWidgetItem([f"📄 {lbl}"])
                item.setData(
                    0,
                    user_role,
                    {
                        "type": "excel_source",
                        "name": ds.name,
                        "title": ds.name,
                        "source_type": ds.source_type,
                    },
                )
                root_files.addChild(item)
        root_files.setExpanded(True)

        # 3. Cached WFS / WMS Services (from local JSON cache)
        root_ogc = QTreeWidgetItem([f"🌐  {tr('cat_root_ogc', lang)}"])
        root_ogc.setData(0, user_role, {"type": "root_ogc"})
        self.catalog_tree.addTopLevelItem(root_ogc)

        servers = self.catalog_manager.get_servers()
        for srv in servers:
            srv_name = srv.get("name", "OGC")
            stype = str(srv.get("service_type") or srv.get("type") or "wfs").upper()
            layers = srv.get("layers", [])
            err = srv.get("last_error", "")
            matched_layers = [
                lyr
                for lyr in layers
                if not query
                or query in srv_name.lower()
                or query in str(lyr.get("name", "")).lower()
                or query in str(lyr.get("title", "")).lower()
            ]
            if query and not matched_layers and query not in srv_name.lower():
                continue

            badge = f"({len(layers)})" if not err else "⚠️"
            srv_item = QTreeWidgetItem([f"[{stype}] {srv_name} {badge}"])
            srv_item.setData(
                0,
                user_role,
                {"type": "ogc_server", "server": srv, "server_name": srv_name},
            )
            root_ogc.addChild(srv_item)

            for lyr in matched_layers:
                lname = lyr.get("name", "")
                ltitle = lyr.get("title", "") or lname
                icon = "🖼️" if stype == "WMS" else "🌍"
                child = QTreeWidgetItem([f"{icon} {ltitle}"])
                child.setToolTip(0, f"{lname}\n{srv.get('url', '')}")
                child.setData(
                    0,
                    user_role,
                    {
                        "type": f"ogc_{stype.lower()}_layer",
                        "name": lname,
                        "title": ltitle,
                        "url": srv.get("url", ""),
                        "crs": srv.get("crs", "EPSG:3301"),
                        "authcfg": srv.get("authcfg", ""),
                        "is_basemap": bool(srv.get("is_basemap", False)),
                        "server_name": srv_name,
                    },
                )
                srv_item.addChild(child)
            if query:
                srv_item.setExpanded(True)
        root_ogc.setExpanded(True)

    # ------------------------------------------------------------------
    # Catalog Actions, Context Menu & Drag-and-Drop onto Workspace
    # ------------------------------------------------------------------

    def _open_server_settings(self, server_entry: Optional[Dict[str, Any]] = None) -> None:
        dlg = ServerSettingsDialog(
            self.catalog_manager, server_entry=server_entry, lang=self.config.language, parent=self
        )
        if exec_dialog(dlg):
            self.catalog_data = self.catalog_manager.load_or_initialize()
            self.refresh_catalog_panel()
            if dlg.saved_server_name:
                self.start_catalog_background_refresh(server_names=[dlg.saved_server_name], force=True)

    def _quick_add_excel_file(self) -> None:
        lang = self.config.language
        proj_dir = DashboardPersistenceManager.get_current_project_dir()
        path, _ = QFileDialog.getOpenFileName(
            self,
            tr("btn_browse_excel", lang),
            proj_dir or os.path.expanduser("~"),
            "Excel & CSV (*.xlsx *.xlsm *.csv);;All Files (*.*)",
        )
        if not path:
            return
        portable = PortablePathResolver.tokenize(path, project_dir=proj_dir)
        sheets = ExcelConnector.list_sheets(path)
        sheet = sheets[0] if sheets else ""
        base_name = os.path.splitext(os.path.basename(path))[0]
        ext = os.path.splitext(path)[1].lower()
        ds = DataSourceConfig(
            name=base_name,
            source_type="csv" if ext == ".csv" else "excel",
            portable_path=portable,
            sheet_name=sheet,
            ingestion_mode="table_join",
        )
        self.config.data_sources.append(ds)
        self._save_project_state()
        self.refresh_catalog_panel()
        self.open_sources_dialog()

    def _on_catalog_context_menu(self, pos: Any) -> None:
        item = self.catalog_tree.itemAt(pos)
        if not item:
            return
        payload = item.data(0, qt_enum(Qt, "ItemDataRole", "UserRole")) or {}
        ptype = payload.get("type", "")
        lang = self.config.language
        menu = QMenu(self)

        if ptype == "ogc_server":
            srv = payload.get("server", {})
            act_ref = menu.addAction(tr("cat_ctx_server_refresh", lang))
            act_cfg = menu.addAction(tr("cat_ctx_server_cfg", lang))
            act_ref.triggered.connect(
                lambda: self.start_catalog_background_refresh(server_names=[srv.get("name", "")])
            )
            act_cfg.triggered.connect(lambda: self._open_server_settings(srv))
        elif ptype in ("qgis_layer", "excel_source", "ogc_wfs_layer", "ogc_wms_layer"):
            act_map = menu.addAction(tr("cat_ctx_add_map", lang))
            act_chart = menu.addAction(tr("cat_ctx_add_chart", lang))
            act_expr = menu.addAction(tr("cat_ctx_add_expression", lang))
            act_table = menu.addAction(tr("cat_ctx_add_table", lang))
            act_slicer = menu.addAction(tr("cat_ctx_add_slicer", lang))
            menu.addSeparator()
            act_qgis = menu.addAction(tr("cat_ctx_add_qgis", lang))

            act_map.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "map"))
            act_chart.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "bar", open_dialog=True))
            act_expr.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "expression", open_dialog=True))
            act_table.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "table"))
            act_slicer.triggered.connect(lambda: self._add_slicer_from_catalog_payload(payload))
            act_qgis.triggered.connect(lambda: self._load_catalog_layer_into_qgis(payload))
        else:
            return

        gp = self.catalog_tree.viewport().mapToGlobal(pos)
        exec_menu(menu, gp)

    def _on_catalog_item_activated(self, item: Any, _col: int) -> None:
        payload = item.data(0, qt_enum(Qt, "ItemDataRole", "UserRole")) or {}
        if payload.get("type") in ("qgis_layer", "excel_source", "ogc_wfs_layer", "ogc_wms_layer"):
            self._show_drop_chooser(payload, 20, 20)

    def _find_map_widget_at(self, x: int, y: int) -> Optional[DashboardMapWidget]:
        pt = QtCore.QPoint(int(x), int(y))
        for frame, inner in self._widget_cards:
            if not isinstance(inner, DashboardMapWidget):
                continue
            try:
                geom = frame.geometry()
                if geom and hasattr(geom, "contains") and geom.contains(pt):
                    return inner
            except Exception:
                pass
            cfg = inner.config
            fx = int(getattr(cfg, "layout_x", 0) or 0)
            fy = int(getattr(cfg, "layout_y", 0) or 0)
            fw = int(getattr(cfg, "layout_w", 0) or 0)
            fh = int(getattr(cfg, "layout_h", 0) or 0)
            if fx <= x <= fx + fw and fy <= y <= fy + fh:
                return inner
        return None

    def _add_payload_to_existing_map(
        self, target_map: DashboardMapWidget, payload: Dict[str, Any]
    ) -> None:
        self._show_workspace_view()
        layer_name = self._ensure_catalog_source_registered(payload)
        raw_name = str(payload.get("name") or layer_name).strip()
        basemap_ids = {bm[0] for bm in MAAAMET_BASEMAPS}
        ptype = payload.get("type", "")
        if ptype == "ogc_wms_layer" and raw_name in basemap_ids:
            target_map.config.map_basemap = raw_name
            idx = target_map.cb_basemap.findData(raw_name)
            if idx >= 0:
                target_map.cb_basemap.blockSignals(True)
                target_map.cb_basemap.setCurrentIndex(idx)
                target_map.cb_basemap.blockSignals(False)
        else:
            if not target_map.config.layer_name:
                target_map.config.layer_name = layer_name
            if layer_name:
                if layer_name in target_map.config.map_layers:
                    target_map.config.map_layers.remove(layer_name)
                # Newly added layer always appears on top of existing layers (#9)
                target_map.config.map_layers.insert(0, layer_name)
                target_map.config.layer_name = target_map.config.map_layers[0]
        target_map.sync_layers_and_zoom()
        self._save_project_state()
        self.refresh_connections_panel()
        self.reload_and_hydrate()

    def _on_catalog_item_dropped(self, payload: Dict[str, Any], x: int, y: int) -> None:
        target_map = self._find_map_widget_at(x, y)
        if target_map is not None:
            self._add_payload_to_existing_map(target_map, payload)
            return
        self._show_drop_chooser(payload, max(12, x - 60), max(12, y - 20))

    def _show_drop_chooser(self, payload: Dict[str, Any], x: int, y: int) -> None:
        lang = self.config.language
        menu = QMenu(self)
        act_map = menu.addAction(f"🗺️  {tr('wtype_map', lang)}")
        act_sum = menu.addAction(f"🌿  {tr('wtype_summary', lang)}")
        act_expr = menu.addAction(f"fx  {tr('wtype_expression', lang)}")
        act_chart = menu.addAction(f"📊  {tr('wtype_bar', lang)} / {tr('wtype_pie', lang)}...")
        act_table = menu.addAction(f"📋  {tr('wtype_table', lang)}")
        act_slicer = menu.addAction(f"🔍  {tr('btn_add_slicer', lang)}")

        act_map.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "map", x=x, y=y))
        act_sum.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "kpi", x=x, y=y, open_dialog=True))
        act_expr.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "expression", x=x, y=y, open_dialog=True))
        act_chart.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "bar", x=x, y=y, open_dialog=True))
        act_table.triggered.connect(lambda: self._add_widget_from_catalog_payload(payload, "table", x=x, y=y))
        act_slicer.triggered.connect(lambda: self._add_slicer_from_catalog_payload(payload, x=x, y=y))

        gp = self.workspace_canvas.board.mapToGlobal(QtCore.QPoint(x, y))
        exec_menu(menu, gp)

    def _ensure_catalog_source_registered(self, payload: Dict[str, Any]) -> str:
        """Ensure a catalog payload has a corresponding DataSourceConfig on self.config and return layer_name."""
        ptype = payload.get("type", "")
        layer_name = str(payload.get("title") or payload.get("name") or "").strip()
        raw_name = str(payload.get("name") or layer_name).strip()

        # Re-use existing source matching typename or name (and file_path/sheet for excel)
        for ds in self.config.data_sources:
            if ds.name == layer_name or (raw_name and ds.typename_or_layers == raw_name):
                return ds.name
            if (
                ptype == "excel_source"
                and payload.get("file_path")
                and ds.file_path == str(payload.get("file_path"))
                and ds.sheet_name == str(payload.get("sheet_name", ""))
            ):
                return ds.name

        if ptype == "qgis_layer":
            lyr = (
                self.persistence._find_project_qgis_layer_by_name(raw_name)
                or self.persistence._find_project_qgis_layer_by_name(layer_name)
                or self.persistence._find_qgis_layer_by_name(raw_name)
                or self.persistence._find_qgis_layer_by_name(layer_name)
            )
            inferred = (
                OgcConnector.infer_datasource_from_qgis_layer(
                    lyr, project_dir=DashboardPersistenceManager.get_current_project_dir()
                )
                if lyr is not None
                else None
            )
            if inferred is not None:
                for ds in self.config.data_sources:
                    if ds.name == inferred.name or (
                        inferred.typename_or_layers
                        and ds.typename_or_layers == inferred.typename_or_layers
                    ):
                        return ds.name
                self.config.data_sources.append(inferred)
                self.refresh_connections_panel()
                return inferred.name
            qgis_col = (
                OgcConnector._extract_qgis_primary_color(lyr) if lyr is not None else ""
            ) or OgcConnector.default_layer_color_for_name(layer_name, raw_name)
            ds = DataSourceConfig(
                name=layer_name,
                source_type="qgis_layer",
                typename_or_layers=raw_name,
                crs=str(payload.get("crs", "EPSG:3301")),
                layer_color=qgis_col,
                is_basemap=False,
                restrict_to_bbox=False,
                max_features=0,
            )
            self.config.data_sources.append(ds)
            self.refresh_connections_panel()
            return ds.name

        if ptype == "excel_source":
            ds = DataSourceConfig(
                name=layer_name,
                source_type="excel",
                file_path=str(payload.get("file_path", "")),
                sheet_name=str(payload.get("sheet_name", "")),
                layer_color=OgcConnector.default_layer_color_for_name(layer_name, raw_name),
                is_basemap=False,
                restrict_to_bbox=False,
                max_features=0,
            )
            self.config.data_sources.append(ds)
            self.refresh_connections_panel()
            return ds.name

        stype = "wms" if ptype == "ogc_wms_layer" else "wfs"
        is_massive = stype == "wfs" and OgcConnector.is_massive_layer(layer_name, raw_name)
        ds = DataSourceConfig(
            name=layer_name,
            source_type=stype,
            url=str(payload.get("url", "")),
            typename_or_layers=raw_name,
            crs=str(payload.get("crs", "EPSG:3301")),
            auth_mode="qgis_authcfg" if payload.get("authcfg") else "none",
            authcfg_id=str(payload.get("authcfg", "")),
            layer_color=OgcConnector.default_layer_color_for_name(layer_name, raw_name),
            is_basemap=bool(payload.get("is_basemap", False) or stype == "wms"),
            restrict_to_bbox=bool(is_massive),
            max_features=400 if is_massive else 0,
        )
        self.config.data_sources.append(ds)
        self.refresh_connections_panel()
        return ds.name

    def _load_catalog_layer_into_qgis(self, payload: Dict[str, Any]) -> None:
        try:
            from qgis.core import QgsProject  # type: ignore
        except Exception:
            return
        lang = self.config.language or "et"
        layer_name = self._ensure_catalog_source_registered(payload)
        ds = next((d for d in self.config.data_sources if d.name == layer_name), None)
        if not ds:
            return
        if ds.source_type in ("wfs", "wms"):
            msg = tr("conn_loading_msg", lang, name=ds.name)
            self.lbl_progress.setText(msg)
            self.workspace_progress.setRange(0, 100)
            self.workspace_progress.setValue(20)
            self._set_loading_overlay(True, subtitle=msg, done=20, total=100, force_pump=True)
            try:
                DashboardPersistenceManager.ensure_safe_qgis_extent(self.config)
                lyr = OgcConnector.connect_qgis_layer(ds)
                self.workspace_progress.setValue(85)
                self._set_loading_overlay(True, subtitle=msg, done=85, total=100, force_pump=True)
                if lyr and lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)
                    self._save_project_state()
                    self.refresh_catalog_panel()
                    self.refresh_connections_panel()
                self.workspace_progress.setValue(100)
            finally:
                self.workspace_progress.setRange(0, 100)
                self._set_loading_overlay(False)

    def _active_page_occupied_rects(self) -> List[Tuple[int, int, int, int]]:
        """Return logical (x, y, w, h) rects of all cards on the active page."""
        pages = list(getattr(self.config, "pages", []) or [])
        active_page_id = getattr(self.config, "active_page_id", "") or (pages[0].id if pages else "page_1")
        rects: List[Tuple[int, int, int, int]] = []
        for s in getattr(self.config, "slicers", []) or []:
            if getattr(s, "is_global", False) or (getattr(s, "page_id", "page_1") or "page_1") == active_page_id:
                sw = int(getattr(s, "layout_w", 0) or 240)
                sh = int(getattr(s, "layout_h", 0) or 115)
                if sw > 0 and sh > 0:
                    rects.append((int(getattr(s, "layout_x", 16) or 0), int(getattr(s, "layout_y", 16) or 0), sw, sh))
        for w in getattr(self.config, "widgets", []) or []:
            if (getattr(w, "page_id", "page_1") or "page_1") == active_page_id:
                ww = int(getattr(w, "layout_w", 0) or (560 if w.widget_type == "map" else (240 if w.widget_type == "kpi" else 440)))
                wh = int(getattr(w, "layout_h", 0) or (400 if w.widget_type == "map" else (130 if w.widget_type == "kpi" else 280)))
                if ww > 0 and wh > 0:
                    rects.append((int(getattr(w, "layout_x", 16) or 0), int(getattr(w, "layout_y", 16) or 0), ww, wh))
        return rects

    @staticmethod
    def _rects_overlap(ax: int, ay: int, aw: int, ah: int, occupied: List[Tuple[int, int, int, int]], pad: int = 8) -> bool:
        for ox, oy, ow, oh in occupied:
            if not (ax + aw + pad <= ox or ox + ow + pad <= ax or ay + ah + pad <= oy or oy + oh + pad <= ay):
                return True
        return False

    def _next_default_position(
        self,
        card_w: int,
        card_h: int,
        prefer_x: Optional[int] = None,
        prefer_y: Optional[int] = None,
    ) -> Tuple[int, int]:
        """Find a guaranteed non-overlapping logical (x, y) for newly added widgets/slicers."""
        occupied = self._active_page_occupied_rects()
        margin = 16
        gap = 12
        if not occupied:
            return max(margin, int(prefer_x or margin)), max(margin, int(prefer_y or margin))

        max_r = max((ox + ow for ox, _oy, ow, _oh in occupied), default=margin)
        max_b = max((oy + oh for _ox, oy, _ow, oh in occupied), default=margin)
        board_w = max(int(getattr(self.config, "canvas_width", 1280) or 1280), max_r, card_w + margin * 2)

        xs = sorted({margin} | {ox for ox, _oy, _ow, _oh in occupied if ox >= margin} | {ox + ow + gap for ox, _oy, ow, _oh in occupied} | set(range(margin, max(margin + 1, board_w - card_w + 1), 120)))
        ys = sorted({margin} | {oy for _ox, oy, _ow, _oh in occupied if oy >= margin} | {oy + oh + gap for _ox, oy, _ow, oh in occupied} | set(range(margin, max(margin + 1, max_b + gap + 1), 60)))

        candidates: List[Tuple[int, int]] = []
        for cy in ys:
            if cy > max_b + gap:
                continue
            for cx in xs:
                if cx + card_w > board_w - 8:
                    continue
                if not self._rects_overlap(cx, cy, card_w, card_h, occupied, pad=8):
                    candidates.append((cx, cy))

        if candidates:
            if prefer_x is not None and prefer_y is not None:
                px, py = int(prefer_x), int(prefer_y)
                candidates.sort(key=lambda pt: ((pt[0] - px) ** 2 + (pt[1] - py) ** 2, pt[1], pt[0]))
            return candidates[0]

        # If existing canvas rows are completely full, append cleanly below everything
        return margin, max_b + gap

    def _resolve_non_overlapping_pos(
        self,
        x: Optional[int],
        y: Optional[int],
        card_w: int,
        card_h: int,
    ) -> Tuple[int, int]:
        if x is None or y is None:
            return self._next_default_position(card_w, card_h)
        sx = max(16, int(x))
        sy = max(16, int(y))
        occupied = self._active_page_occupied_rects()
        if not occupied or not self._rects_overlap(sx, sy, card_w, card_h, occupied, pad=6):
            return sx, sy
        return self._next_default_position(card_w, card_h, prefer_x=sx, prefer_y=sy)

    def _add_widget_from_catalog_payload(
        self,
        payload: Dict[str, Any],
        widget_type: str,
        x: Optional[int] = None,
        y: Optional[int] = None,
        open_dialog: bool = False,
    ) -> None:
        self._show_workspace_view()
        layer_name = self._ensure_catalog_source_registered(payload)
        default_w, default_h = (560, 400) if widget_type == "map" else (
            (240, 130) if widget_type == "kpi" else (440, 290)
        )
        px, py = self._resolve_non_overlapping_pos(x, y, default_w, default_h)
        w = WidgetConfig(
            title=tr("map_widget_title", self.config.language) if widget_type == "map" else layer_name,
            title_en=layer_name,
            widget_type=widget_type,
            layer_name=layer_name,
            map_layers=[layer_name] if widget_type == "map" else [],
            page_id=getattr(self.config, "active_page_id", "page_1") or "page_1",
            layout_x=px,
            layout_y=py,
            layout_w=default_w,
            layout_h=default_h,
        )
        if open_dialog:
            self._edit_or_add_widget_dialog(w, is_new=True)
        else:
            self.config.widgets.append(w)
            self._last_added_card_id = w.id
            self._save_project_state()
            self._apply_widget_or_slicer_change()

    def _add_slicer_from_catalog_payload(
        self, payload: Dict[str, Any], x: Optional[int] = None, y: Optional[int] = None
    ) -> None:
        self._show_workspace_view()
        layer_name = self._ensure_catalog_source_registered(payload)
        px, py = self._resolve_non_overlapping_pos(x, y, 240, 115)
        s = SlicerConfig(
            title=f"{layer_name}",
            layer_name=layer_name,
            page_id=getattr(self.config, "active_page_id", "page_1") or "page_1",
            layout_x=px,
            layout_y=py,
            layout_w=240,
            layout_h=115,
        )
        known_schemas = DashboardPersistenceManager.list_qgis_project_layer_schemas()
        if layer_name and layer_name not in self.persistence.layer_records_cache and layer_name not in known_schemas:
            self.reload_and_hydrate()
        dlg = SlicerEditorDialog(
            s,
            self._available_layer_names(),
            self.persistence.get_layer_fields_map(),
            lang=self.config.language,
            catalog_manager=self.catalog_manager,
            dashboard=self.config,
            parent=self,
        )
        if exec_dialog(dlg):
            self.config.slicers.append(s)
            self._last_added_card_id = s.id
            self._save_project_state()
            self._apply_widget_or_slicer_change()

    # ------------------------------------------------------------------
    # QGIS Canvas Integration & Persistence
    # ------------------------------------------------------------------

    def _connect_qgis_canvas(self) -> None:
        if self._canvas_connected or not self.iface or not hasattr(self.iface, "mapCanvas"):
            return
        try:
            canvas = self.iface.mapCanvas()
            canvas.extentsChanged.connect(self._on_qgis_extent_changed)
            if hasattr(canvas, "layersChanged"):
                canvas.layersChanged.connect(self._on_qgis_project_layers_changed)
            try:
                from qgis.core import QgsProject

                proj = QgsProject.instance()
                if hasattr(proj, "layersAdded"):
                    proj.layersAdded.connect(self._on_qgis_project_layers_changed)
                if hasattr(proj, "layersRemoved"):
                    proj.layersRemoved.connect(self._on_qgis_project_layers_changed)
            except Exception:
                pass
            self._canvas_connected = True
        except Exception:
            pass

    def _on_qgis_project_layers_changed(self, *_args: Any) -> None:
        if str(getattr(self.config, "canvas_sync_mode", "dashboard_only") or "dashboard_only") != "sync_main_canvas":
            return
        mc_layers: Optional[List[str]] = None
        if self.iface is not None and hasattr(self.iface, "mapCanvas"):
            try:
                bm_titles = {b[1] for b in MAAAMET_BASEMAPS}
                mc_layers = [
                    lyr.name()
                    for lyr in (self.iface.mapCanvas().layers() or [])
                    if getattr(lyr, "name", None) and lyr.name() and lyr.name() not in bm_titles
                ]
            except Exception:
                mc_layers = None
        for _frame, w in getattr(self, "_widget_cards", []):
            if isinstance(w, DashboardMapWidget):
                if mc_layers and not getattr(w.config, "map_layers_custom_order", False):
                    w.config.map_layers = list(mc_layers)
                    w.config.layer_name = mc_layers[0]
                w.sync_layers_and_zoom(force_layers=True)
                w.apply_configured_layer_styles()

    @staticmethod
    def _transform_rect_to_wgs84(rect: Any, src_crs: Any = None) -> Optional[SpatialExtentFilter]:
        try:
            if hasattr(rect, "xMinimum"):
                xmin, ymin = float(rect.xMinimum()), float(rect.yMinimum())
                xmax, ymax = float(rect.xMaximum()), float(rect.yMaximum())
            elif isinstance(rect, (tuple, list)) and len(rect) >= 4:
                xmin, ymin, xmax, ymax = float(rect[0]), float(rect[1]), float(rect[2]), float(rect[3])
            else:
                return None

            if src_crs is not None:
                try:
                    from qgis.core import (
                        QgsCoordinateReferenceSystem,
                        QgsCoordinateTransform,
                        QgsProject,
                        QgsRectangle,
                    )

                    auth = str(src_crs.authid() or "") if hasattr(src_crs, "authid") else str(src_crs)
                    if auth and auth.upper() != "EPSG:4326":
                        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                        rect_src = QgsRectangle(xmin, ymin, xmax, ymax)
                        xform = QgsCoordinateTransform(src_crs, wgs84, QgsProject.instance())
                        r4326 = xform.transformBoundingBox(rect_src)
                        xmin, ymin = float(r4326.xMinimum()), float(r4326.yMinimum())
                        xmax, ymax = float(r4326.xMaximum()), float(r4326.yMaximum())
                except Exception:
                    pass

            if xmin > xmax:
                xmin, xmax = xmax, xmin
            if ymin > ymax:
                ymin, ymax = ymax, ymin
            return SpatialExtentFilter(xmin=xmin, ymin=ymin, xmax=xmax, ymax=ymax, crs="EPSG:4326")
        except Exception:
            return None

    def _on_map_widget_extent_changed(self, rect: Any, src_crs: Any = None) -> None:
        if not self._extent_filter_enabled:
            return
        ext = self._transform_rect_to_wgs84(rect, src_crs)
        if ext is not None:
            self.filter_bus.set_spatial_extent(ext, enabled=True)

    def _on_qgis_extent_changed(self, *_args: Any) -> None:
        if not self._extent_filter_enabled:
            return
        rect = None
        src_crs = None
        for _frame, w in getattr(self, "_widget_cards", []):
            if isinstance(w, DashboardMapWidget):
                w_rect, w_crs = w.current_canvas_extent()
                if w_rect is not None:
                    rect, src_crs = w_rect, w_crs
                    break
        if rect is None and self.iface and hasattr(self.iface, "mapCanvas"):
            try:
                canvas = self.iface.mapCanvas()
                rect = canvas.extent()
                src_crs = canvas.mapSettings().destinationCrs()
            except Exception:
                rect = None
        if rect is None:
            return
        ext = self._transform_rect_to_wgs84(rect, src_crs)
        if ext is not None:
            self.filter_bus.set_spatial_extent(ext, enabled=True)

    def _toggle_extent_filter(self) -> None:
        self._extent_filter_enabled = self.btn_extent_filter.isChecked()
        self.config.filter_by_map_extent = self._extent_filter_enabled
        self.btn_extent_filter.setText(
            tr("btn_extent_on", self.config.language)
            if self._extent_filter_enabled
            else tr("btn_extent_off", self.config.language)
        )
        if self._extent_filter_enabled:
            self._on_qgis_extent_changed()
        else:
            self.filter_bus.set_spatial_extent(None, enabled=False)
        self._save_project_state()
        if getattr(self.config, "preview_mode", False):
            ext_js = json.dumps(bool(self._extent_filter_enabled))
            if not self._run_preview_js(f"if (typeof setHostExtentFilter === 'function') setHostExtentFilter({ext_js});"):
                self._refresh_html_preview(open_external_if_fallback=False)

    def open_settings_dialog(self, initial_tab: int = 0) -> None:
        tab_idx = 0 if isinstance(initial_tab, bool) else max(0, int(initial_tab or 0))
        before_cfg = dict(self.config.to_dict())
        dlg = DashboardSettingsDialog(
            self.config,
            lang=self.config.language,
            initial_tab=tab_idx,
            catalog_manager=getattr(self, "catalog_manager", None),
            parent=self,
        )
        if exec_dialog(dlg):
            self._extent_filter_enabled = bool(getattr(self.config, "filter_by_map_extent", False))
            self.btn_extent_filter.blockSignals(True)
            self.btn_extent_filter.setChecked(self._extent_filter_enabled)
            self.btn_extent_filter.blockSignals(False)
            self._apply_theme()
            self._sync_design_controls()
            self._retranslate_ui()
            self._refresh_home_view()
            if getattr(dlg, "catalog_changed", False) and hasattr(self, "catalog_manager"):
                self.catalog_data = self.catalog_manager.load_or_initialize()
                if hasattr(self, "refresh_catalog_panel"):
                    self.refresh_catalog_panel()
                if hasattr(self, "start_catalog_background_refresh"):
                    self.start_catalog_background_refresh(force=False)
            self._save_project_state()
            sync_changed = before_cfg.get("canvas_sync_mode") != getattr(self.config, "canvas_sync_mode", "dashboard_only")
            if sync_changed:
                self.persistence.set_sync_mode(getattr(self.config, "canvas_sync_mode", "dashboard_only"))
                self.persistence.clear_dashboard_layers()
                self._force_map_refresh_next = True
                self.reload_and_hydrate(force_refresh_sources=True)
            else:
                self.rebuild_dashboard_ui()
            if self._extent_filter_enabled:
                self._on_qgis_extent_changed()
            if getattr(self.config, "preview_mode", False):
                after_cfg = dict(self.config.to_dict())
                live_keys = {"language", "theme", "filter_by_map_extent"}
                structural_changed = bool(getattr(dlg, "catalog_changed", False)) or any(
                    before_cfg.get(k) != after_cfg.get(k)
                    for k in set(before_cfg.keys()) | set(after_cfg.keys())
                    if k not in live_keys
                )
                live_ok = True
                if not structural_changed:
                    cmds = []
                    if before_cfg.get("language") != after_cfg.get("language"):
                        cmds.append(
                            f"if (typeof setHostLanguage === 'function') setHostLanguage({json.dumps(self.config.language or 'et')});"
                        )
                    if before_cfg.get("theme") != after_cfg.get("theme"):
                        cmds.append(
                            f"if (typeof setHostTheme === 'function') setHostTheme({json.dumps(self.config.theme or 'dark')});"
                        )
                    if before_cfg.get("filter_by_map_extent") != after_cfg.get("filter_by_map_extent"):
                        cmds.append(
                            f"if (typeof setHostExtentFilter === 'function') setHostExtentFilter({json.dumps(bool(self._extent_filter_enabled))});"
                        )
                    if cmds:
                        live_ok = self._run_preview_js(" ".join(cmds))
                if structural_changed or not live_ok:
                    self._refresh_html_preview(open_external_if_fallback=False)

    def _on_filters_changed(self, _state: Any = None) -> None:
        persistence = getattr(self, "persistence", None)
        records_cache = persistence.layer_records_cache if persistence is not None else {}
        total_cached = sum(len(v) for v in records_cache.values())
        cfg = getattr(self, "config", None)
        lang = (getattr(cfg, "language", None) or "et")
        show_busy = total_cached >= 4000 and hasattr(self, "_set_loading_overlay")
        if show_busy:
            self._set_loading_overlay(
                True,
                title=tr("loading_filter_title", lang),
                subtitle=tr("loading_filter_sub", lang),
                done=15,
                total=100,
                force_pump=True,
            )
        try:
            self.refresh_widget_values()
            if show_busy:
                self._set_loading_overlay(
                    True,
                    title=tr("loading_filter_title", lang),
                    subtitle=tr("loading_filter_sub", lang),
                    done=60,
                    total=100,
                    force_pump=True,
                )
            # Highlight filtered features inside active QGIS layers for immediate visual feedback
            if self.iface and persistence is not None:
                try:
                    active = self.filter_bus.active_filters()
                    for lname, recs in records_cache.items():
                        lyr = persistence._find_qgis_layer_by_name(lname)
                        if lyr is None or not hasattr(lyr, "selectByIds"):
                            continue
                        has_layer_flt = any(
                            (not f.layer_name or lname in {ln for ln, _ in (f.target_sources() if hasattr(f, "target_sources") else [(f.layer_name, f.field_name)])})
                            for f in active
                        )
                        if not has_layer_flt:
                            if hasattr(lyr, "removeSelection"):
                                lyr.removeSelection()
                            continue
                        filtered = self.filter_bus.filter_records(recs, layer_name=lname)
                        if len(filtered) >= len(recs):
                            if hasattr(lyr, "removeSelection"):
                                lyr.removeSelection()
                        else:
                            fids = []
                            for r in filtered[:3000]:
                                try:
                                    fids.append(int(r.get("_feature_id")))
                                except (TypeError, ValueError):
                                    pass
                            lyr.selectByIds(fids)
                except Exception:
                    pass
            if getattr(self.config, "auto_zoom_on_filter", True):
                self._zoom_design_maps_to_active_filters()
            now_has_filters = bool(self.filter_bus.active_filters())
            if (
                getattr(self, "_had_active_filters", False)
                and not now_has_filters
                and bool(getattr(self.config, "auto_home_on_filter_clear", True))
            ):
                for _fr, inner in getattr(self, "_widget_cards", []):
                    if hasattr(inner, "reset_to_home_view"):
                        try:
                            inner.reset_to_home_view()
                        except Exception:
                            pass
            self._had_active_filters = now_has_filters
            self._refresh_active_filters_banner()
            last_sid = str(getattr(self, "_last_filter_source_id", "") or "")
            if last_sid:
                norm_sid = self.filter_bus._norm_conn_id(last_sid)
                src_w = next((w for w in self.config.widgets if w.id == norm_sid), None)
                if src_w is not None and getattr(src_w, "drill_to_page_id", "") and self.filter_bus.get_selected_values(last_sid):
                    target_pg = src_w.drill_to_page_id
                    if target_pg != self.config.active_page_id and any(p.id == target_pg for p in (self.config.pages or [])):
                        self._switch_to_page(target_pg)
            if show_busy:
                self._set_loading_overlay(
                    True,
                    title=tr("loading_filter_title", lang),
                    subtitle=tr("loading_filter_sub", lang),
                    done=100,
                    total=100,
                    force_pump=True,
                )
        finally:
            if show_busy:
                self._set_loading_overlay(False)

    def load_dashboard_config(self, cfg: DashboardConfig) -> None:
        """Load a new DashboardConfig, normalize layout geometry if needed, and hydrate lazily."""
        self.config = cfg
        self._active_saved_dashboard_id = ""
        self._pending_project_cfg = None
        if hasattr(self.persistence, "clear_dashboard_layers"):
            self.persistence.clear_dashboard_layers()
        if hasattr(self.persistence, "set_sync_mode"):
            self.persistence.set_sync_mode(getattr(cfg, "canvas_sync_mode", "dashboard_only"))
        if hasattr(self.persistence, "ensure_referenced_sources_registered"):
            self.persistence.ensure_referenced_sources_registered(
                cfg, catalog_manager=getattr(self, "catalog_manager", None)
            )
        self._extent_filter_enabled = bool(getattr(cfg, "filter_by_map_extent", False))
        self.btn_extent_filter.blockSignals(True)
        self.btn_extent_filter.setChecked(self._extent_filter_enabled)
        self.btn_extent_filter.blockSignals(False)
        self._had_active_filters = False
        self.filter_bus.clear_all()
        if hasattr(self.config, "sync_widget_connections"):
            self.config.sync_widget_connections()
        self.filter_bus.set_connections(getattr(self.config, "widget_connections", []))
        self._ensure_card_geometries()
        self._save_project_state()
        self._show_workspace_view()
        if hasattr(self, "workspace_view_stack"):
            self.workspace_view_stack.setCurrentIndex(1 if cfg.preview_mode else 0)
        self._apply_theme()
        self._retranslate_ui()
        self._sync_design_controls()
        self.refresh_catalog_panel()
        self.refresh_connections_panel()
        self._pending_preview_after_hydration = bool(cfg.preview_mode)
        self.reload_and_hydrate()
        if not self._hydration_active:
            if self._extent_filter_enabled:
                self._on_qgis_extent_changed()
            if self._pending_preview_after_hydration and cfg.preview_mode:
                self._pending_preview_after_hydration = False
                self._refresh_html_preview(open_external_if_fallback=False)

    def _ensure_card_geometries(self) -> None:
        """Guarantee any legacy template without layout_x/layout_y gets crisp grid coordinates."""
        all_zero = all(
            (w.layout_x == 0 and w.layout_y == 0) for w in self.config.widgets
        ) and all((s.layout_x == 0 and s.layout_y == 0) for s in self.config.slicers)
        if all_zero and (self.config.widgets or self.config.slicers):
            self._compute_clean_grid_layout()

    def _compute_clean_grid_layout(self) -> None:
        y = 14
        x = 14
        if self.config.slicers:
            for s in self.config.slicers:
                s.layout_w = max(210, s.layout_w or 240)
                s.layout_h = max(105, s.layout_h or 110)
                if x + s.layout_w > 980 and x > 14:
                    x = 14
                    y += 120
                s.layout_x = x
                s.layout_y = y
                x += s.layout_w + 12
            y += 124
            x = 14

        maps = [w for w in self.config.widgets if w.widget_type == "map"]
        kpis = [w for w in self.config.widgets if w.widget_type == "kpi"]
        others = [w for w in self.config.widgets if w.widget_type not in ("map", "kpi")]

        map_bottom = y
        if maps:
            mx = 14
            for m in maps:
                mw = max(480, m.layout_w or 520)
                mh = max(360, m.layout_h or 400)
                m.layout_x = mx
                m.layout_y = y
                m.layout_w = mw
                m.layout_h = mh
                mx += mw + 14
                map_bottom = max(map_bottom, y + mh + 14)

        # Place Summary ("kpi") cards to the right of maps if 1 map, else clean row
        kx = 550 if len(maps) == 1 else 14
        ky = y if len(maps) == 1 else map_bottom
        kx_max = 1040
        if kpis:
            for k in kpis:
                kw = min(max(210, k.layout_w or 230), 280)
                kh = min(max(115, k.layout_h or 130), 170)
                if kx + kw > kx_max:
                    kx = 550 if len(maps) == 1 and ky < map_bottom else 14
                    ky += kh + 12
                k.layout_x = kx
                k.layout_y = ky
                k.layout_w = kw
                k.layout_h = kh
                kx += kw + 12
            ky += (kpis[-1].layout_h or 130) + 14

        cy = max(map_bottom, ky)
        cx = 14
        row_h = 0
        for c in others:
            cw = max(340, c.layout_w or 460)
            ch = max(240, c.layout_h or 290)
            if c.widget_type == "table":
                cw = max(cw, 760)
            if cx + cw > 1040 and cx > 14:
                cx = 14
                cy += row_h + 14
                row_h = 0
            c.layout_x = cx
            c.layout_y = cy
            c.layout_w = cw
            c.layout_h = ch
            cx += cw + 14
            row_h = max(row_h, ch)

    def auto_arrange_cards(self) -> None:
        self._compute_clean_grid_layout()
        self._save_project_state()
        self.rebuild_dashboard_ui()

    def _set_loading_overlay(
        self,
        visible: bool,
        subtitle: str = "",
        done: int = 0,
        total: int = 0,
        title: str = "",
        force_pump: bool = False,
    ) -> None:
        if not hasattr(self, "loading_overlay_card") or self.loading_overlay_card is None:
            return
        lang = self.config.language or "et"
        if not visible:
            self.loading_overlay_card.hide()
            self._last_progress_pump_ts = 0.0
            return
        self.lbl_overlay_title.setText(f"⏳ {title or tr('loading_overlay_title', lang)}")
        sub_text = str(subtitle or "").strip()
        self.lbl_overlay_sub.setText(sub_text)
        if hasattr(self.lbl_overlay_sub, "setVisible"):
            self.lbl_overlay_sub.setVisible(bool(sub_text))
        if total > 0:
            pct = max(0, min(100, int((int(done) * 100) // int(total)))) if total != 100 else max(0, min(100, int(done)))
            self.overlay_progress.setRange(0, 100)
            self.overlay_progress.setValue(pct)
        else:
            self.overlay_progress.setRange(0, 0)
        try:
            sw = self.workspace_view_stack.width() or 600
            sh = self.workspace_view_stack.height() or 400
            self.loading_overlay_card.adjustSize()
            cw = self.loading_overlay_card.width() or 420
            ch = self.loading_overlay_card.height() or 130
            self.loading_overlay_card.move(max(12, (sw - cw) // 2), max(12, (sh - ch) // 3))
        except Exception:
            pass
        self.loading_overlay_card.show()
        self.loading_overlay_card.raise_()
        now = time.monotonic()
        if force_pump or (now - getattr(self, "_last_progress_pump_ts", 0.0)) >= 0.016:
            self._last_progress_pump_ts = now
            try:
                app_cls = getattr(QtWidgets, "QApplication", None)
                if app_cls is not None and app_cls.instance() is not None and not os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS"):
                    app_cls.processEvents()
            except Exception:
                pass

    def _on_hydration_bg_progress(self, done: int, total: int, label: str) -> None:
        if self._hydration_cancelled:
            return
        raw_pct = max(0, min(100, int((int(done) * 100) // max(1, int(total))))) if total > 0 else 0
        scaled_pct = max(2, min(75, 2 + (raw_pct * 73) // 100))
        self._on_hydration_progress(scaled_pct, 100, label)

    def _schedule_hide_hydration_bar(self, seq: int, delay_ms: int = 1800) -> None:
        QTimerCls = getattr(QtCore, "QTimer", None)
        def _hide_if_same() -> None:
            if getattr(self, "_hydration_seq", 0) == seq and not getattr(self, "_hydration_active", False):
                if hasattr(self, "hydration_bar") and self.hydration_bar is not None:
                    self.hydration_bar.hide()
                self._refresh_in_progress = False
        if QTimerCls is not None and hasattr(QTimerCls, "singleShot") and not os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS"):
            try:
                QTimerCls.singleShot(delay_ms, _hide_if_same)
                return
            except Exception:
                pass
        _hide_if_same()

    def _reload_qgis_referenced_layers(self, only_names: Optional[Any] = None) -> None:
        """Reload underlying data providers of referenced QGIS layers while keeping styles, filters, and view intact."""
        if hasattr(self.persistence, "set_sync_mode"):
            self.persistence.set_sync_mode(getattr(self.config, "canvas_sync_mode", "dashboard_only"))
        if hasattr(self.persistence, "ensure_referenced_sources_registered"):
            self.persistence.ensure_referenced_sources_registered(
                self.config, catalog_manager=getattr(self, "catalog_manager", None)
            )
        needed = (
            {str(n).strip() for n in only_names if str(n).strip()}
            if only_names is not None
            else self.persistence.referenced_layer_names(self.config)
        )
        if not needed:
            return
        try:
            from qgis.core import QgsProject

            proj = QgsProject.instance()
            for lname in needed:
                for lyr in proj.mapLayersByName(lname) or []:
                    try:
                        dp = lyr.dataProvider() if hasattr(lyr, "dataProvider") else None
                        if dp is not None:
                            if hasattr(dp, "forceReload"):
                                dp.forceReload()
                            elif hasattr(dp, "reloadData"):
                                dp.reloadData()
                        if hasattr(lyr, "reload"):
                            lyr.reload()
                        if hasattr(lyr, "triggerRepaint"):
                            lyr.triggerRepaint()
                    except Exception:
                        pass
        except Exception:
            pass

    def _on_hydration_progress(self, done: int, total: int, label: str) -> None:
        if self._hydration_cancelled:
            return
        lang = self.config.language or "et"
        pct = max(0, min(100, int((int(done) * 100) // max(1, int(total))))) if total > 0 else 0
        if hasattr(self, "hydration_bar") and self.hydration_bar is not None and hasattr(self.hydration_bar, "show"):
            self.hydration_bar.show()
        self.workspace_progress.setRange(0, 100)
        self.workspace_progress.setValue(pct)
        if label:
            if getattr(self, "_refresh_in_progress", False):
                msg = tr("refreshing_progress_msg", lang, pct=pct, name=label)
            else:
                msg = f"{tr('conn_loading_msg', lang, name=label)} ({pct}%)"
            self.lbl_progress.setText(msg)
        else:
            msg = self.lbl_progress.text() or tr("loading_overlay_sub", lang)
        self._set_loading_overlay(True, subtitle=msg, done=pct, total=100)

    def _cancel_active_hydration(self) -> None:
        self._hydration_cancelled = True
        self._hydration_active = False
        self._refresh_in_progress = False
        self._force_map_refresh_next = False
        self._pending_preview_after_hydration = False
        self.hydration_bar.hide()
        self._set_loading_overlay(False)
        if hasattr(self, "lbl_status"):
            self.lbl_status.setText(tr("conn_cancelled", self.config.language or "et"))

    def reload_and_hydrate(
        self,
        force_refresh_sources: bool = False,
        async_fetch: bool = True,
        page_id: Optional[str] = None,
    ) -> None:
        """Lazily hydrate ONLY layers referenced by widgets/filters/joins, off-thread when possible (optionally scoped to one Atlas page)."""
        lang = self.config.language or "et"
        self._hydration_seq = int(getattr(self, "_hydration_seq", 0)) + 1
        target_pid = str(page_id).strip() if page_id is not None and str(page_id).strip() else ""
        only_names: Optional[set] = (
            self.persistence.referenced_layer_names(self.config, page_id=target_pid)
            if target_pid
            else None
        )
        if force_refresh_sources:
            self._refresh_in_progress = True
            self._force_map_refresh_next = True
            self._reload_qgis_referenced_layers(only_names=only_names)
        else:
            self._refresh_in_progress = False
            self._force_map_refresh_next = False

        if hasattr(self.persistence, "set_sync_mode"):
            self.persistence.set_sync_mode(getattr(self.config, "canvas_sync_mode", "dashboard_only"))
        if hasattr(self.persistence, "ensure_referenced_sources_registered"):
            self.persistence.ensure_referenced_sources_registered(
                self.config, catalog_manager=getattr(self, "catalog_manager", None)
            )
        needed = only_names if only_names is not None else self.persistence.referenced_layer_names(self.config)
        if only_names is not None and not needed:
            self._refresh_in_progress = False
            self._force_map_refresh_next = False
            self.lbl_status.setText(tr("conn_ready", lang) if hasattr(self, "lbl_status") else "")
            return
        remote_needed = [
            ds
            for ds in self.config.data_sources
            if (ds.name in needed or ds.id in needed)
            and ds.source_type in ("wfs", "excel", "sharepoint_list")
            and (force_refresh_sources or ds.name not in self.persistence.layer_records_cache)
        ]
        qgis_snap = self.persistence.snapshot_qgis_layer_specs(
            self.config,
            only_referenced=True,
            only_names=only_names,
            force_refresh_sources=force_refresh_sources,
        )
        all_qgis_specs = qgis_snap.get("specs") or {}
        bg_qgis_specs = {k: v for k, v in all_qgis_specs.items() if v.get("can_bg_read") and k in needed}
        bg_wfs_specs = {
            k: v
            for k, v in all_qgis_specs.items()
            if k in needed
            and not v.get("can_bg_read")
            and v.get("provider") == "wfs"
            and not v.get("is_modified")
            and v.get("inferred_wfs") is not None
            and (force_refresh_sources or k not in self.persistence.layer_records_cache)
        }

        if async_fetch and (remote_needed or bg_qgis_specs or bg_wfs_specs) and pyqtSignal is not None and not self._hydration_active:
            self._hydration_active = True
            self._hydration_cancelled = False
            if hasattr(self, "hydration_bar") and self.hydration_bar is not None and hasattr(self.hydration_bar, "show"):
                self.hydration_bar.show()
            self.workspace_progress.setRange(0, 100)
            self.workspace_progress.setValue(0)
            first_lbl = (
                remote_needed[0].name
                if remote_needed
                else next(iter(bg_qgis_specs.keys()), next(iter(bg_wfs_specs.keys()), ""))
            )
            init_msg = (
                tr("refreshing_progress_msg", lang, pct=2, name=first_lbl)
                if force_refresh_sources
                else f"{tr('conn_loading_msg', lang, name=first_lbl)} (2%)"
            )
            self.workspace_progress.setValue(2)
            self.lbl_progress.setText(init_msg)
            self._set_loading_overlay(True, subtitle=init_msg, done=2, total=100, force_pump=True)
            self.lbl_status.setText(init_msg)

            if remote_needed or bg_wfs_specs:
                DashboardPersistenceManager.ensure_safe_qgis_extent(self.config)
            wgs84_bbox = self.persistence._get_safe_wgs84_bbox(self.config)
            proj_dir = DashboardPersistenceManager.get_current_project_dir()
            existing_qgis = set(DashboardPersistenceManager.list_qgis_project_layer_schemas().keys())
            tctx = qgis_snap.get("transform_context")
            ellipsoid = str(qgis_snap.get("ellipsoid") or "GRS80")

            def _worker() -> None:
                res = self.persistence.fetch_remote_sources_bg(
                    self.config,
                    wgs84_bbox=wgs84_bbox,
                    project_dir=proj_dir,
                    only_referenced=True,
                    only_names=only_names,
                    force_refresh_sources=force_refresh_sources,
                    existing_qgis_names=existing_qgis,
                    qgis_layer_specs=all_qgis_specs,
                    transform_context=tctx,
                    ellipsoid=ellipsoid,
                    progress_cb=lambda d, t, lbl: self._hydr_bridge.progress.emit(d, t, lbl),
                    cancel_check=lambda: self._hydration_cancelled,
                )
                self._hydr_bridge.finished.emit((force_refresh_sources, only_names, res))

            threading.Thread(target=_worker, daemon=True).start()
            return

        self._finish_hydration_sync(
            force_refresh_sources=force_refresh_sources,
            only_names=only_names,
            base_pct=2,
            max_pct=92,
            was_explicit_refresh=bool(force_refresh_sources),
        )

    def _on_hydration_bg_finished(self, payload: Any) -> None:
        self._hydration_active = False
        force_refresh = False
        only_names: Optional[set] = None
        if isinstance(payload, tuple) and len(payload) == 3:
            force_refresh, only_names, data = payload
        elif isinstance(payload, tuple) and len(payload) == 2:
            force_refresh, data = payload
        else:
            data = payload or {}
        if self._hydration_cancelled or (isinstance(data, dict) and data.get("cancelled")):
            self._refresh_in_progress = False
            self._force_map_refresh_next = False
            self._pending_preview_after_hydration = False
            self.hydration_bar.hide()
            self._set_loading_overlay(False)
            return
        joins_done = False
        overlap_done = False
        if isinstance(data, dict):
            if force_refresh:
                if only_names is not None:
                    rm_set = {str(n).strip() for n in only_names if str(n).strip()}
                    for nm in rm_set:
                        self.persistence.layer_records_cache.pop(nm, None)
                        self.persistence.layer_geojson_cache.pop(nm, None)
                        self.persistence.layer_stats_cache.pop(nm, None)
                        self.persistence.layer_pyramid_cache.pop(nm, None)
                    for ds in getattr(self.config, "data_sources", []) or []:
                        if ds.name in rm_set:
                            self.persistence.excel_records_cache.pop(ds.id, None)
                else:
                    self.persistence.layer_records_cache.clear()
                    self.persistence.layer_geojson_cache.clear()
                    self.persistence.layer_stats_cache.clear()
                    self.persistence.layer_pyramid_cache.clear()
                    self.persistence.excel_records_cache.clear()
                if hasattr(self.persistence, "_spatial_pivot_cache"):
                    self.persistence._spatial_pivot_cache.clear()
                if hasattr(self.persistence, "_cross_layer_fid_cache"):
                    self.persistence._cross_layer_fid_cache.clear()
            self.persistence.excel_records_cache.update(data.get("excel_records", {}))
            self.persistence.layer_records_cache.update(data.get("layer_records", {}))
            self.persistence.layer_geojson_cache.update(data.get("layer_geojson", {}))
            self.persistence.layer_stats_cache.update(data.get("layer_stats", {}))
            self.persistence.layer_pyramid_cache.update(data.get("layer_pyramids", {}))
            joins_done = bool(data.get("joins_applied", False))
            overlap_done = bool(data.get("overlap_enriched", False))
        has_fallback = bool(isinstance(data, dict) and data.get("fallback_qgis_layers"))
        self._finish_hydration_sync(
            force_refresh_sources=False,
            only_names=only_names,
            base_pct=75 if has_fallback else 88,
            max_pct=94,
            skip_in_memory_joins=joins_done and not has_fallback,
            skip_enriched_overlap=overlap_done and not has_fallback,
            was_explicit_refresh=bool(force_refresh),
        )

    def _finish_hydration_sync(
        self,
        force_refresh_sources: bool = False,
        only_names: Optional[Any] = None,
        base_pct: int = 2,
        max_pct: int = 92,
        skip_in_memory_joins: bool = False,
        skip_enriched_overlap: bool = False,
        was_explicit_refresh: bool = False,
    ) -> None:
        lang = self.config.language or "et"
        if base_pct <= 2:
            self._hydration_cancelled = False
        start_pct = max(2, min(90, int(base_pct)))
        if hasattr(self, "hydration_bar") and self.hydration_bar is not None and hasattr(self.hydration_bar, "show"):
            self.hydration_bar.show()
        self.lbl_status.setText(
            tr("refreshing_progress_msg", lang, pct=start_pct, name="")
            if (was_explicit_refresh or force_refresh_sources)
            else ("⏳ ..." if lang == "et" else "⏳ Loading referenced layers...")
        )
        self.workspace_progress.setRange(0, 100)
        self.workspace_progress.setValue(start_pct)
        init_sub = self.lbl_progress.text() or tr("loading_overlay_sub", lang)
        self._set_loading_overlay(True, subtitle=init_sub, done=start_pct, total=100, force_pump=True)
        launched_async_preview = False
        try:
            if force_refresh_sources:
                if hasattr(self.persistence, "_spatial_pivot_cache"):
                    self.persistence._spatial_pivot_cache.clear()
                if hasattr(self.persistence, "_cross_layer_fid_cache"):
                    self.persistence._cross_layer_fid_cache.clear()

            def _sync_progress(d: int, t: int, lbl: str) -> None:
                raw = max(0, min(100, int((int(d) * 100) // max(1, int(t))))) if t > 0 else 0
                span = max(1, max_pct - start_pct)
                pct = max(start_pct, min(max_pct, start_pct + (raw * span) // 100))
                self._on_hydration_progress(pct, 100, lbl)

            self.persistence.hydrate_all_sources(
                self.config,
                use_canvas_extent=self._extent_filter_enabled,
                force_refresh_sources=force_refresh_sources,
                only_referenced=True,
                only_names=list(only_names) if only_names is not None else None,
                progress_cb=_sync_progress,
                cancel_check=lambda: self._hydration_cancelled,
                skip_in_memory_joins=skip_in_memory_joins,
                skip_enriched_overlap=skip_enriched_overlap,
            )
            if self._hydration_cancelled:
                return
            if was_explicit_refresh or force_refresh_sources:
                self._force_map_refresh_next = True
            self._on_hydration_progress(94, 100, "")
            self.refresh_connections_panel()
            self._on_hydration_progress(96, 100, "")
            self.rebuild_dashboard_ui()
            s_cards = self._slicer_cards if isinstance(getattr(self, "_slicer_cards", None), (list, tuple)) else ()
            w_cards = self._widget_cards if isinstance(getattr(self, "_widget_cards", None), (list, tuple)) else ()
            for fr, _w in list(s_cards) + list(w_cards):
                if hasattr(fr, "repaint"):
                    try:
                        fr.repaint()
                    except Exception:
                        pass
            if getattr(self, "_extent_filter_enabled", False):
                self._on_qgis_extent_changed()
            if getattr(self.config, "preview_mode", False) and (getattr(self, "_pending_preview_after_hydration", False) or was_explicit_refresh or force_refresh_sources):
                self._pending_preview_after_hydration = False
                if self._can_run_async_qt():
                    launched_async_preview = True
                    self._refresh_html_preview(open_external_if_fallback=False, _from_overlay=False)
                else:
                    self._refresh_html_preview(open_external_if_fallback=False, _from_overlay=True)
            total_recs = sum(len(v) for v in self.persistence.layer_records_cache.values())
            n_layers = len(self.persistence.layer_records_cache)
            now_hms = time.strftime("%H:%M:%S")
            done_msg = tr("refreshing_done_msg", lang, pct=100, layers=n_layers, records=total_recs, time=now_hms)
            self.workspace_progress.setValue(100)
            self.lbl_progress.setText(done_msg)
            if not launched_async_preview:
                self._set_loading_overlay(True, subtitle=done_msg, done=100, total=100, force_pump=True)
        finally:
            self._pending_preview_after_hydration = False
            if not launched_async_preview:
                self._set_loading_overlay(False)
        total_recs = sum(len(v) for v in self.persistence.layer_records_cache.values())
        n_layers = len(self.persistence.layer_records_cache)
        now_hms = time.strftime("%H:%M:%S")
        if was_explicit_refresh or force_refresh_sources:
            done_txt = tr("refreshing_done_msg", lang, pct=100, layers=n_layers, records=total_recs, time=now_hms)
            self.lbl_status.setText(done_txt)
            self._schedule_hide_hydration_bar(getattr(self, "_hydration_seq", 0), delay_ms=1800)
        else:
            self._refresh_in_progress = False
            if hasattr(self, "hydration_bar") and self.hydration_bar is not None and hasattr(self.hydration_bar, "hide"):
                self.hydration_bar.hide()
            if lang == "et":
                self.lbl_status.setText(
                    f"Laetud {n_layers} aktiivset kihti ({total_recs} kirjet) — "
                    "vidinaid ja filtreid saab vabalt lohistada ning nurgast suurendada."
                    if total_recs
                    else "Valmis — lohista vasakult andmekataloogist kiht töölauale või klõpsa '+ Lisa kaardivaade'."
                )
            else:
                self.lbl_status.setText(
                    f"Loaded {n_layers} active layers ({total_recs} records) — "
                    "drag cards to move or resize from corners."
                    if total_recs
                    else "Ready — drag a layer from the Data Catalog onto the workspace."
                )

    def _save_project_state(self) -> None:
        if hasattr(self, "persistence") and hasattr(self.persistence, "ensure_referenced_sources_registered"):
            self.persistence.ensure_referenced_sources_registered(
                self.config, catalog_manager=getattr(self, "catalog_manager", None)
            )
        DashboardPersistenceManager.save_to_qgis_project(self.config)
        if self.config.widgets or self.config.slicers or self.config.data_sources:
            DashboardPersistenceManager.save_recent_workspace(
                self.config,
                project_path=DashboardPersistenceManager.get_current_project_dir() or "",
            )

    # ------------------------------------------------------------------
    # Building Draggable & Resizable Workspace Cards
    # ------------------------------------------------------------------

    def _on_widget_inline_config_changed(self) -> None:
        self._save_project_state()
        if hasattr(self, "_preview_dirty"):
            self._preview_dirty = True

    def _on_table_row_selected(self, w_cfg: WidgetConfig, row: Dict[str, Any]) -> None:
        if not isinstance(row, dict):
            return
        if row.get("_filter_field"):
            had_zoom = getattr(self.config, "auto_zoom_on_filter", True)
            src_id = f"tbl_{w_cfg.id}"
            self._last_filter_source_id = src_id
            try:
                self.filter_bus.toggle_category_value(
                    source_id=src_id,
                    layer_name=w_cfg.layer_name,
                    field_name=str(row["_filter_field"]),
                    value=str(row.get("_filter_value", "")),
                    multi=True,
                    page_id=str(getattr(w_cfg, "page_id", "page_1") or "page_1"),
                )
            finally:
                self._last_filter_source_id = ""
            if not had_zoom and self.filter_bus.active_filters():
                self._zoom_design_maps_to_active_filters(
                    preferred_layer=w_cfg.layer_name,
                    preferred_source_id=src_id,
                )
        else:
            fid = row.get("_feature_id")
            pts: List[Tuple[float, float]] = []
            bb = row.get("_bbox")
            if isinstance(bb, (list, tuple)) and len(bb) == 4:
                try:
                    pts.append((float(bb[1]), float(bb[0])))
                    pts.append((float(bb[3]), float(bb[2])))
                except (TypeError, ValueError):
                    pass
            if row.get("_lat") is not None and row.get("_lon") is not None:
                try:
                    pts.append((float(row["_lat"]), float(row["_lon"])))
                except (TypeError, ValueError):
                    pass
            self._zoom_to_records_or_fids(
                w_cfg.layer_name,
                [fid] if fid is not None else [],
                fallback_points=pts,
            )
            if getattr(w_cfg, "drill_to_page_id", "") and any(p.id == w_cfg.drill_to_page_id for p in (self.config.pages or [])):
                self._switch_to_page(w_cfg.drill_to_page_id)

    def _refresh_page_bar(self) -> None:
        if not hasattr(self, "page_tabs_layout"):
            return
        lang = self.config.language or "et"
        pages = list(getattr(self.config, "pages", []) or [])
        if not pages:
            pages = [DashboardPageConfig(id="page_1", title="Ülevaade", title_en="Overview", icon="📊", color="#0078D4")]
            self.config.pages = pages
        active_id = getattr(self.config, "active_page_id", "") or pages[0].id
        if not any(p.id == active_id for p in pages):
            active_id = pages[0].id
            self.config.active_page_id = active_id

        while self.page_tabs_layout.count():
            it = self.page_tabs_layout.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

        for pg in pages:
            ptitle = pg.title_en if (lang == "en" and pg.title_en) else pg.title
            btn = QPushButton(f"{pg.icon} {ptitle}")
            btn.setCheckable(True)
            is_act = pg.id == active_id
            btn.setChecked(is_act)
            pcol = pg.color or "#0078D4"
            if is_act:
                btn.setStyleSheet(
                    f"QPushButton {{ background: {pcol}; color: #ffffff; font-weight: 700; "
                    f"border-radius: 5px; padding: 3px 10px; border: 1px solid {pcol}; }}"
                )
            else:
                btn.setStyleSheet(
                    f"QPushButton {{ border: 1px solid rgba(148,163,184,0.35); border-bottom: 2px solid {pcol}; "
                    f"border-radius: 5px; padding: 3px 10px; }}"
                )
            btn.clicked.connect(lambda _c=False, pid=pg.id: self._switch_to_page(pid))
            self.page_tabs_layout.addWidget(btn)

        self.btn_del_page.setEnabled(len(pages) > 1)
        self._rebuild_refresh_menu(lang)

    def _switch_to_page(self, page_id: str) -> None:
        if not page_id or page_id == self.config.active_page_id:
            return
        self.config.active_page_id = page_id
        self._save_project_state()
        self.rebuild_dashboard_ui()

    def _on_add_page_clicked(self) -> None:
        lang = self.config.language or "et"
        palette = ["#0078D4", "#10B981", "#F59E0B", "#A855F7", "#EC4899", "#06B6D4"]
        n = len(self.config.pages) + 1
        new_id = f"page_{n}_{int(time.time()) % 1000}"
        pg = DashboardPageConfig(
            id=new_id,
            title=f"Leht {n}" if lang == "et" else f"Page {n}",
            title_en=f"Page {n}",
            icon="📄",
            color=palette[(n - 1) % len(palette)],
        )
        self.config.pages.append(pg)
        self.config.active_page_id = new_id
        self._save_project_state()
        self.rebuild_dashboard_ui()

    def _on_rename_page_clicked(self) -> None:
        lang = self.config.language or "et"
        active_id = self.config.active_page_id or "page_1"
        pg = next((p for p in self.config.pages if p.id == active_id), None)
        if pg is None or QInputDialog is None:
            return
        cur = pg.title_en if (lang == "en" and pg.title_en) else pg.title
        new_name, ok = QInputDialog.getText(self, tr("rename_page", lang), tr("rename_page", lang) + ":", text=cur)
        if ok and str(new_name).strip():
            if lang == "en":
                pg.title_en = str(new_name).strip()
            else:
                pg.title = str(new_name).strip()
            self._save_project_state()
            self._refresh_page_bar()

    def _on_delete_page_clicked(self) -> None:
        if len(self.config.pages) <= 1:
            return
        active_id = self.config.active_page_id or self.config.pages[0].id
        remaining = [p for p in self.config.pages if p.id != active_id]
        fallback_id = remaining[0].id
        self.config.pages = remaining
        for w in self.config.widgets:
            if getattr(w, "page_id", "page_1") == active_id:
                w.page_id = fallback_id
            if getattr(w, "drill_to_page_id", "") == active_id:
                w.drill_to_page_id = ""
        for s in self.config.slicers:
            if getattr(s, "page_id", "page_1") == active_id:
                s.page_id = fallback_id
        if getattr(self.config, "default_page_id", "") == active_id:
            self.config.default_page_id = ""
        self.config.active_page_id = fallback_id
        self._save_project_state()
        self.rebuild_dashboard_ui()

    def _on_map_home_view_saved(self, map_cfg: WidgetConfig) -> None:
        first_page_id = self.config.pages[0].id if self.config.pages else "page_1"
        if len(self.config.pages or []) <= 1 or getattr(map_cfg, "page_id", first_page_id) == first_page_id:
            self.config.map_home_bounds = list(getattr(map_cfg, "map_home_bounds", []) or [])
            if map_cfg.map_center_lat is not None:
                self.config.map_center_lat = float(map_cfg.map_center_lat)
            if map_cfg.map_center_lon is not None:
                self.config.map_center_lon = float(map_cfg.map_center_lon)
            if map_cfg.map_zoom is not None:
                self.config.map_zoom = int(map_cfg.map_zoom)
        self._save_project_state()

    def _on_widget_clear_filter(self, item_id: str) -> None:
        raw_id = str(item_id or "")
        is_addr = (raw_id == "__map_addr__" or raw_id.endswith("__addr"))
        base_id = raw_id[:-6] if raw_id.endswith("__addr") else raw_id
        self.filter_bus.clear_filter(raw_id)
        if base_id and base_id != raw_id:
            self.filter_bus.clear_filter(base_id)
        if base_id and base_id != "__map_addr__":
            self.filter_bus.clear_filter(f"tbl_{base_id}")
            self.filter_bus.clear_filter(f"{base_id}__addr")
            for p_idx in range(12):
                self.filter_bus.clear_filter(f"{base_id}__pane_{p_idx}")
        for frame, inner in self._widget_cards:
            if frame.item_id == base_id or (raw_id == "__map_addr__" and isinstance(inner, DashboardMapWidget)):
                if isinstance(inner, DataTableWidget) and hasattr(inner, "clear_selection"):
                    inner.clear_selection()
                elif isinstance(inner, DashboardMapWidget) and hasattr(inner, "clear_address_search"):
                    inner.clear_address_search()
        if is_addr:
            self._refresh_active_filters_banner()

    def _refresh_active_filters_banner(self) -> None:
        lang = self.config.language or "et"
        descs = self.filter_bus.describe_active_filters() if hasattr(self.filter_bus, "describe_active_filters") else []
        if hasattr(self, "active_filters_chips_layout") and hasattr(self, "active_filters_bar"):
            while self.active_filters_chips_layout.count():
                it = self.active_filters_chips_layout.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()
            if descs:
                for d in descs:
                    btn = QPushButton(f"{d['label']}  ✕")
                    btn.setProperty("btnRole", "chip")
                    btn.setStyleSheet(
                        "QPushButton { background: rgba(56, 189, 248, 0.16); color: #e0f2fe; "
                        "border: 1px solid rgba(56, 189, 248, 0.45); border-radius: 10px; "
                        "padding: 2px 8px; font-size: 11px; }"
                    )
                    sid = d["source_id"]
                    btn.clicked.connect(lambda _c=False, s=sid: self._on_widget_clear_filter(s))
                    self.active_filters_chips_layout.addWidget(btn)
                self.active_filters_chips_layout.addStretch(1)
                self.active_filters_bar.show()
            else:
                self.active_filters_bar.hide()

        # Update per-card outgoing reset button & incoming filter badge (#12, #14)
        active_raw = self.filter_bus._filters if hasattr(self.filter_bus, "_filters") else {}
        for frame, inner in list(self._slicer_cards) + list(self._widget_cards):
            iid = frame.item_id
            has_out = (
                iid in active_raw
                or f"tbl_{iid}" in active_raw
                or f"{iid}__addr" in active_raw
                or any(k.startswith(f"{iid}__pane_") for k in active_raw)
            )
            if hasattr(frame, "set_has_outgoing_filter"):
                frame.set_has_outgoing_filter(has_out)

            if hasattr(inner, "config"):
                wcfg = inner.config
                wlayer = getattr(wcfg, "layer_name", "")
                wpage = getattr(wcfg, "page_id", "page_1")
                incoming = self.filter_bus.get_active_filters_for_widget(
                    iid,
                    layer_name=wlayer,
                    exclude_source_id=iid,
                    page_id=wpage,
                ) if hasattr(self.filter_bus, "get_active_filters_for_widget") else []
                # Ignore filters originating from this widget's own sub-IDs
                incoming = [
                    f for f in incoming
                    if f.source_id not in (iid, f"tbl_{iid}", f"{iid}__addr")
                    and not f.source_id.startswith(f"{iid}__pane_")
                ]
                if incoming and hasattr(frame, "set_incoming_filter_badge"):
                    txt = " · ".join(self.filter_bus.format_filter_badge(f) for f in incoming[:2])
                    if len(incoming) > 2:
                        txt += f" (+{len(incoming) - 2})"
                    frame.set_incoming_filter_badge(f"{tr('filtered_by_prefix', lang)} {txt}")
                elif hasattr(frame, "set_incoming_filter_badge"):
                    frame.set_incoming_filter_badge("")

    def _apply_widget_or_slicer_change(self) -> None:
        """Hydrate only if new uncached data sources are needed; otherwise update cards preserving map state."""
        if hasattr(self.persistence, "set_sync_mode"):
            self.persistence.set_sync_mode(getattr(self.config, "canvas_sync_mode", "dashboard_only"))
        if hasattr(self.persistence, "ensure_referenced_sources_registered"):
            self.persistence.ensure_referenced_sources_registered(
                self.config, catalog_manager=getattr(self, "catalog_manager", None)
            )
        needed = self.persistence.referenced_layer_names(self.config)
        missing = [ln for ln in needed if ln and ln not in self.persistence.layer_records_cache]
        if missing:
            self.reload_and_hydrate()
            return
        self.refresh_connections_panel()
        self.rebuild_dashboard_ui()

    def _compute_shared_seams(self) -> List[Dict[str, Any]]:
        """Return metadata for all touching shared borders between current page cards."""
        locked_set = set(getattr(self.config, "locked_border_seams", []) or [])
        slicer_by_id = {s.id: s for s in self.config.slicers}
        widget_by_id = {w.id: w for w in self.config.widgets}
        rects: List[Tuple[str, int, int, int, int]] = []
        for frame, _inner in list(self._slicer_cards) + list(self._widget_cards):
            cfg = widget_by_id.get(frame.item_id) or slicer_by_id.get(frame.item_id)
            if cfg is None:
                continue
            rect = getattr(frame, "_logical_rect", None)
            if isinstance(rect, (tuple, list)) and len(rect) == 4:
                x, y, w, h = int(rect[0]), int(rect[1]), int(rect[2]), int(rect[3])
            else:
                x = int(getattr(cfg, "layout_x", 0))
                y = int(getattr(cfg, "layout_y", 0))
                w = int(getattr(cfg, "layout_w", 240))
                h = int(getattr(cfg, "layout_h", 140))
            rects.append((frame.item_id, x, y, x + w, y + h))
        seams: List[Dict[str, Any]] = []
        tol = 4
        for i in range(len(rects)):
            aid, ax1, ay1, ax2, ay2 = rects[i]
            for j in range(i + 1, len(rects)):
                bid, bx1, by1, bx2, by2 = rects[j]
                v_ov_s = max(ay1, by1)
                v_ov_e = min(ay2, by2)
                if v_ov_e - v_ov_s > 16:
                    if abs(ax2 - bx1) <= tol:
                        key = f"v:{aid}:{bid}"
                        seams.append({
                            "key": key,
                            "axis": "v",
                            "a_id": aid,
                            "b_id": bid,
                            "pos": int(round((ax2 + bx1) * 0.5)),
                            "mid_x": (ax2 + bx1) * 0.5,
                            "mid_y": (v_ov_s + v_ov_e) * 0.5,
                            "locked": key in locked_set,
                        })
                    elif abs(bx2 - ax1) <= tol:
                        key = f"v:{bid}:{aid}"
                        seams.append({
                            "key": key,
                            "axis": "v",
                            "a_id": bid,
                            "b_id": aid,
                            "pos": int(round((bx2 + ax1) * 0.5)),
                            "mid_x": (bx2 + ax1) * 0.5,
                            "mid_y": (v_ov_s + v_ov_e) * 0.5,
                            "locked": key in locked_set,
                        })
                h_ov_s = max(ax1, bx1)
                h_ov_e = min(ax2, bx2)
                if h_ov_e - h_ov_s > 16:
                    if abs(ay2 - by1) <= tol:
                        key = f"h:{aid}:{bid}"
                        seams.append({
                            "key": key,
                            "axis": "h",
                            "a_id": aid,
                            "b_id": bid,
                            "pos": int(round((ay2 + by1) * 0.5)),
                            "mid_x": (h_ov_s + h_ov_e) * 0.5,
                            "mid_y": (ay2 + by1) * 0.5,
                            "locked": key in locked_set,
                        })
                    elif abs(by2 - ay1) <= tol:
                        key = f"h:{bid}:{aid}"
                        seams.append({
                            "key": key,
                            "axis": "h",
                            "a_id": bid,
                            "b_id": aid,
                            "pos": int(round((by2 + ay1) * 0.5)),
                            "mid_x": (h_ov_s + h_ov_e) * 0.5,
                            "mid_y": (by2 + ay1) * 0.5,
                            "locked": key in locked_set,
                        })
        return seams

    def _is_card_edge_locked(self, item_id: str, edge: str) -> bool:
        axis = "v" if edge in ("left", "right") else "h"
        for s in self._compute_shared_seams():
            if not s["locked"] or s["axis"] != axis:
                continue
            if edge in ("right", "bottom") and s["a_id"] == item_id:
                return True
            if edge in ("left", "top") and s["b_id"] == item_id:
                return True
        return False

    def _toggle_seam_lock(self, seam_key: str) -> None:
        seams = list(getattr(self.config, "locked_border_seams", []) or [])
        if seam_key in seams:
            seams = [k for k in seams if k != seam_key]
        else:
            seams.append(seam_key)
        self.config.locked_border_seams = seams
        self._update_adjacent_card_borders()
        self._save_project_state()

    def _toggle_card_border_locks(self, item_id: str) -> None:
        touching = [s for s in self._compute_shared_seams() if s["a_id"] == item_id or s["b_id"] == item_id]
        if not touching:
            return
        cur = list(getattr(self.config, "locked_border_seams", []) or [])
        any_locked = any(s["locked"] for s in touching)
        if any_locked:
            rm = {s["key"] for s in touching}
            cur = [k for k in cur if k not in rm]
        else:
            for s in touching:
                if s["key"] not in cur:
                    cur.append(s["key"])
        self.config.locked_border_seams = cur
        self._update_adjacent_card_borders()
        self._save_project_state()

    def _begin_linked_edge_resize(self, item_id: str, edge: str) -> bool:
        axis = "v" if edge in ("left", "right") else "h"
        locked_seams = [s for s in self._compute_shared_seams() if s["locked"] and s["axis"] == axis]
        seed = next(
            (
                s for s in locked_seams
                if (edge in ("right", "bottom") and s["a_id"] == item_id)
                or (edge in ("left", "top") and s["b_id"] == item_id)
            ),
            None,
        )
        if seed is None:
            return False

        # Collect connected locked cards along the same seam coordinate
        before_ids = {seed["a_id"]}
        after_ids = {seed["b_id"]}
        changed = True
        while changed:
            changed = False
            for s in locked_seams:
                if abs(s["pos"] - seed["pos"]) > 6:
                    continue
                if s["a_id"] in before_ids and s["b_id"] not in after_ids:
                    after_ids.add(s["b_id"])
                    changed = True
                if s["b_id"] in after_ids and s["a_id"] not in before_ids:
                    before_ids.add(s["a_id"])
                    changed = True

        frame_by_id: Dict[str, ResizableCardFrame] = {
            f.item_id: f for f, _ in list(self._slicer_cards) + list(self._widget_cards)
        }
        slicer_by_id = {s.id: s for s in self.config.slicers}
        widget_by_id = {w.id: w for w in self.config.widgets}
        before_init: Dict[str, Tuple[ResizableCardFrame, Any, Tuple[int, int, int, int]]] = {}
        after_init: Dict[str, Tuple[ResizableCardFrame, Any, Tuple[int, int, int, int]]] = {}
        for cid in before_ids:
            fr = frame_by_id.get(cid)
            cfg = widget_by_id.get(cid) or slicer_by_id.get(cid)
            if fr is not None and cfg is not None:
                before_init[cid] = (fr, cfg, (int(cfg.layout_x), int(cfg.layout_y), int(cfg.layout_w), int(cfg.layout_h)))
        for cid in after_ids:
            fr = frame_by_id.get(cid)
            cfg = widget_by_id.get(cid) or slicer_by_id.get(cid)
            if fr is not None and cfg is not None:
                after_init[cid] = (fr, cfg, (int(cfg.layout_x), int(cfg.layout_y), int(cfg.layout_w), int(cfg.layout_h)))
        if not before_init or not after_init:
            return False

        if axis == "v":
            min_d = max(-(rect[2] - fr._min_w) for fr, _c, rect in before_init.values())
            max_d = min((rect[2] - fr._min_w) for fr, _c, rect in after_init.values())
        else:
            min_d = max(-(rect[3] - fr._min_h) for fr, _c, rect in before_init.values())
            max_d = min((rect[3] - fr._min_h) for fr, _c, rect in after_init.values())

        self._active_linked_resize = {
            "axis": axis,
            "seam_pos": int(seed["pos"]),
            "before": before_init,
            "after": after_init,
            "min_d": int(min_d),
            "max_d": int(max_d),
            "last_delta": 0,
        }
        return True

    def _step_linked_edge_resize(self, _item_id: str, _edge: str, delta_logical: int, commit: bool) -> None:
        st = getattr(self, "_active_linked_resize", None)
        if not isinstance(st, dict):
            return
        axis = st["axis"]
        raw_delta = st["last_delta"] if (commit and int(delta_logical) == 0) else int(delta_logical)
        delta = max(st["min_d"], min(st["max_d"], raw_delta))
        if commit and getattr(self.config, "snap_to_grid", True):
            step = max(5, int(getattr(self.config, "grid_size", 20) or 20))
            target_seam = round((st["seam_pos"] + delta) / step) * step
            delta = max(st["min_d"], min(st["max_d"], int(target_seam - st["seam_pos"])))
        st["last_delta"] = delta
        z = max(0.25, float(getattr(self.workspace_canvas, "zoom", 1.0) or 1.0))

        for fr, cfg, (ox, oy, ow, oh) in st["before"].values():
            nx, ny, nw, nh = (ox, oy, ow + delta, oh) if axis == "v" else (ox, oy, ow, oh + delta)
            fr._logical_rect = (nx, ny, nw, nh)
            fr.setGeometry(int(round(nx * z)), int(round(ny * z)), max(64, int(round(nw * z))), max(44, int(round(nh * z))))
            if commit:
                cfg.layout_x, cfg.layout_y, cfg.layout_w, cfg.layout_h = nx, ny, nw, nh

        for fr, cfg, (ox, oy, ow, oh) in st["after"].values():
            nx, ny, nw, nh = (ox + delta, oy, ow - delta, oh) if axis == "v" else (ox, oy + delta, ow, oh - delta)
            fr._logical_rect = (nx, ny, nw, nh)
            fr.setGeometry(int(round(nx * z)), int(round(ny * z)), max(64, int(round(nw * z))), max(44, int(round(nh * z))))
            if commit:
                cfg.layout_x, cfg.layout_y, cfg.layout_w, cfg.layout_h = nx, ny, nw, nh

        self._update_canvas_wires()
        if commit:
            self._active_linked_resize = None
            self._update_adjacent_card_borders()
            self.workspace_canvas.expand_to_fit()
            self._save_project_state()
        else:
            self._update_adjacent_card_borders()

    def _on_card_geometry_live_changed(self) -> None:
        self._update_adjacent_card_borders()
        self._update_canvas_wires()

    def _update_adjacent_card_borders(self) -> None:
        """Detect cards whose edges touch within 4px, dissolve shared borders (#5), and sync seam lock nodes."""
        dissolve = bool(getattr(self.config, "dissolve_adjacent_borders", True))
        global_bstyle = str(getattr(self.config, "widget_border_style", "default") or "default")
        entries: List[Tuple[ResizableCardFrame, int, int, int, int, str]] = []

        slicer_by_id = {s.id: s for s in self.config.slicers}
        widget_by_id = {w.id: w for w in self.config.widgets}
        for frame, _inner in list(self._slicer_cards) + list(self._widget_cards):
            cfg = widget_by_id.get(frame.item_id) or slicer_by_id.get(frame.item_id)
            if cfg is None:
                continue
            rect = getattr(frame, "_logical_rect", None)
            if isinstance(rect, (tuple, list)) and len(rect) == 4:
                x, y, w, h = int(rect[0]), int(rect[1]), int(rect[2]), int(rect[3])
            else:
                x = int(getattr(cfg, "layout_x", 0))
                y = int(getattr(cfg, "layout_y", 0))
                w = int(getattr(cfg, "layout_w", 240))
                h = int(getattr(cfg, "layout_h", 140))
            bstyle = getattr(cfg, "border_style", "") or global_bstyle
            entries.append((frame, x, y, x + w, y + h, bstyle))

        tol = 4
        for idx, (frame, x1, y1, x2, y2, bstyle) in enumerate(entries):
            adj_t = adj_r = adj_b = adj_l = False
            if dissolve:
                for jdx, (_f2, ox1, oy1, ox2, oy2, _bs2) in enumerate(entries):
                    if idx == jdx:
                        continue
                    h_overlap = min(x2, ox2) - max(x1, ox1) > 16
                    v_overlap = min(y2, oy2) - max(y1, oy1) > 16
                    if h_overlap and abs(y1 - oy2) <= tol:
                        adj_t = True
                    if h_overlap and abs(y2 - oy1) <= tol:
                        adj_b = True
                    if v_overlap and abs(x1 - ox2) <= tol:
                        adj_l = True
                    if v_overlap and abs(x2 - ox1) <= tol:
                        adj_r = True
            if hasattr(frame, "set_adjacent_edges"):
                frame.set_adjacent_edges(adj_t, adj_r, adj_b, adj_l, dissolve=dissolve, border_style=bstyle)

        if hasattr(self.workspace_canvas, "sync_seam_nodes"):
            seams = self._compute_shared_seams()
            self.workspace_canvas.sync_seam_nodes(
                seams=seams,
                preview_mode=bool(getattr(self.config, "preview_mode", False)),
                lang=self.config.language or "et",
                on_toggle=self._toggle_seam_lock,
                on_drag_begin=self._begin_linked_edge_resize,
                on_drag_step=self._step_linked_edge_resize,
            )

    def rebuild_dashboard_ui(self) -> None:
        lang = self.config.language or "et"
        if hasattr(self.config, "sync_widget_connections"):
            self.config.sync_widget_connections()
        self.filter_bus.set_connections(getattr(self.config, "widget_connections", []))
        self._retranslate_ui()

        pages = list(getattr(self.config, "pages", []) or [])
        active_page_id = getattr(self.config, "active_page_id", "") or (pages[0].id if pages else "page_1")
        vis_slicers = [
            s for s in self.config.slicers
            if getattr(s, "is_global", False) or (getattr(s, "page_id", "page_1") or "page_1") == active_page_id
        ]
        vis_widgets = [
            w for w in self.config.widgets
            if (getattr(w, "page_id", "page_1") or "page_1") == active_page_id
        ]
        vis_map_ids = {w.id for w in vis_widgets if w.widget_type == "map"}

        # Preserve live DashboardMapWidget instances across rebuilds so adding a table/chart
        # never reloads map layers or resets the map canvas viewport.
        reused_maps: Dict[str, DashboardMapWidget] = {}
        for old_frame, old_inner in list(self._widget_cards):
            if isinstance(old_inner, DashboardMapWidget) and old_frame.item_id in vis_map_ids:
                detached = old_frame.detach_body_widget() if hasattr(old_frame, "detach_body_widget") else None
                if isinstance(detached, DashboardMapWidget):
                    reused_maps[old_frame.item_id] = detached

        self._slicer_cards.clear()
        self._widget_cards.clear()
        self.workspace_canvas.clear_cards()
        self._ensure_card_geometries()

        has_any = bool(vis_slicers or vis_widgets)
        self.workspace_canvas.set_empty_state(
            not has_any,
            tr("empty_workspace_title", lang),
            tr("empty_workspace_sub", lang),
        )

        grid_size = int(getattr(self.config, "grid_size", 20) or 20)
        snap_enabled = bool(getattr(self.config, "snap_to_grid", True))
        preview_mode = bool(getattr(self.config, "preview_mode", False))
        global_bstyle = str(getattr(self.config, "widget_border_style", "default") or "default")

        # 1. Resizable Filter / Slicer Cards
        for s_cfg in vis_slicers:
            inner = SlicerCardWidget(
                s_cfg,
                self.filter_bus,
                lang=lang,
                layer_records_provider=lambda ln: self.persistence.layer_records_cache.get(ln, []),
            )
            title = s_cfg.title_en if (lang == "en" and s_cfg.title_en) else s_cfg.title
            prefix = "🌐 " if getattr(s_cfg, "is_global", False) else "🔍 "
            frame = ResizableCardFrame(
                item_id=s_cfg.id,
                title=f"{prefix}{title}",
                inner_widget=inner,
                lang=lang,
                accent_color="#38bdf8",
                min_w=190,
                min_h=95,
                grid_size=grid_size,
                snap_enabled=snap_enabled,
                preview_mode=preview_mode,
                on_edit=lambda cfg=s_cfg: self._edit_slicer(cfg),
                on_refresh=self.refresh_widget_values,
                on_delete=lambda _id, cfg=s_cfg: self._delete_slicer(cfg),
                on_geometry_changed=lambda _id, x, y, w, h, cfg=s_cfg: self._on_slicer_geom_changed(cfg, x, y, w, h),
                on_connect_clicked=lambda sid: self._open_model_connections_dialog(focus_id=sid),
                on_connect_drag_move=lambda sid, gpos: self._on_card_connect_drag_move(sid, gpos),
                on_connect_dragged=lambda sid, gpos: self._on_card_connect_dragged(sid, gpos),
                on_geometry_live_changed=self._on_card_geometry_live_changed,
                on_clear_filter=self._on_widget_clear_filter,
                is_edge_locked=self._is_card_edge_locked,
                on_linked_edge_begin=self._begin_linked_edge_resize,
                on_linked_edge_step=self._step_linked_edge_resize,
                on_toggle_border_locks=self._toggle_card_border_locks,
                border_style=global_bstyle,
            )
            self.workspace_canvas.add_card(
                frame, s_cfg.layout_x, s_cfg.layout_y, s_cfg.layout_w or 240, s_cfg.layout_h or 110
            )
            self._slicer_cards.append((frame, inner))

        # 2. Resizable Map, Summary Card, Chart & Table Cards
        first_page_id = self.config.pages[0].id if self.config.pages else "page_1"
        for w_cfg in vis_widgets:
            if w_cfg.widget_type == "map":
                if (
                    (len(self.config.pages or []) <= 1 or getattr(w_cfg, "page_id", first_page_id) == first_page_id)
                    and not getattr(w_cfg, "map_home_bounds", None)
                    and getattr(self.config, "map_home_bounds", None)
                ):
                    w_cfg.map_home_bounds = list(self.config.map_home_bounds)
                if (
                    str(getattr(self.config, "canvas_sync_mode", "dashboard_only") or "dashboard_only") == "sync_main_canvas"
                    and not getattr(w_cfg, "map_layers_custom_order", False)
                    and self.iface is not None
                    and hasattr(self.iface, "mapCanvas")
                ):
                    try:
                        bm_titles = {b[1] for b in MAAAMET_BASEMAPS}
                        mc_layers = [
                            lyr.name()
                            for lyr in (self.iface.mapCanvas().layers() or [])
                            if getattr(lyr, "name", None) and lyr.name() and lyr.name() not in bm_titles
                        ]
                        if mc_layers:
                            w_cfg.map_layers = mc_layers
                            w_cfg.layer_name = mc_layers[0]
                    except Exception:
                        pass
                _layer_res = lambda ln: self.persistence.resolve_dashboard_layer(ln, self.config)
                _cfg_prov = lambda: self.config
                _flds_prov = lambda: self.persistence.get_layer_fields_map(self.config)
                if w_cfg.id in reused_maps:
                    inner = reused_maps[w_cfg.id]
                    inner.config = w_cfg
                    inner.lang = lang
                    inner._records_cache = dict(self.persistence.layer_records_cache or {})
                    inner.on_edit_saved = self._save_project_state
                    inner.on_extent_changed = self._on_map_widget_extent_changed
                    inner.layer_fields_provider = _flds_prov
                    inner.layer_resolver = _layer_res
                    inner.dashboard_config_provider = _cfg_prov
                    inner.on_home_view_saved = lambda cfg=w_cfg: self._on_map_home_view_saved(cfg)
                    inner.show()
                    force_map = bool(getattr(self, "_force_map_refresh_next", False))
                    self._force_map_refresh_next = False
                    if hasattr(inner, "apply_scroll_sensitivity"):
                        inner.apply_scroll_sensitivity(getattr(w_cfg, "map_scroll_sensitivity", 35))
                    inner.sync_layers_and_zoom(force_layers=force_map)
                else:
                    inner = DashboardMapWidget(
                        w_cfg,
                        self.filter_bus,
                        center_lat=w_cfg.map_center_lat or 58.65,
                        center_lon=w_cfg.map_center_lon or 25.0,
                        lang=lang,
                        on_edit_saved=self._save_project_state,
                        on_extent_changed=self._on_map_widget_extent_changed,
                        layer_fields_provider=_flds_prov,
                        on_home_view_saved=lambda cfg=w_cfg: self._on_map_home_view_saved(cfg),
                        layer_resolver=_layer_res,
                        dashboard_config_provider=_cfg_prov,
                    )
                    inner._records_cache = dict(self.persistence.layer_records_cache or {})
                    if hasattr(inner, "apply_scroll_sensitivity"):
                        inner.apply_scroll_sensitivity(getattr(w_cfg, "map_scroll_sensitivity", 35))
                min_w, min_h = 340, 260
            elif w_cfg.widget_type == "kpi":
                inner = KpiCardWidget(w_cfg, lang=lang)
                min_w, min_h = 190, 105
            elif w_cfg.widget_type == "expression":
                inner = ExpressionCardWidget(w_cfg, lang=lang)
                min_w, min_h = 200, 115
            elif w_cfg.widget_type == "image":
                inner = ImageLogoWidget(w_cfg, lang=lang)
                min_w, min_h = 120, 80
            elif w_cfg.widget_type == "table":
                inner = DataTableWidget(
                    w_cfg,
                    lang=lang,
                    on_row_selected=lambda row, cfg=w_cfg: self._on_table_row_selected(cfg, row),
                    on_config_changed=self._on_widget_inline_config_changed,
                )
                min_w, min_h = 340, 200
            else:
                inner = InteractiveChartWidget(w_cfg, self.filter_bus, lang=lang)
                min_w, min_h = 260, 200

            title = w_cfg.title_en if (lang == "en" and w_cfg.title_en) else w_cfg.title
            icon = "🗺️ " if w_cfg.widget_type == "map" else ("🖼️ " if w_cfg.widget_type == "image" else "")
            frame = ResizableCardFrame(
                item_id=w_cfg.id,
                title=f"{icon}{title}",
                inner_widget=inner,
                lang=lang,
                accent_color=w_cfg.primary_color or "#34d399",
                min_w=min_w,
                min_h=min_h,
                grid_size=grid_size,
                snap_enabled=snap_enabled,
                preview_mode=preview_mode,
                on_edit=lambda cfg=w_cfg: self._edit_widget(cfg),
                on_refresh=self.refresh_widget_values,
                on_delete=lambda _id, cfg=w_cfg: self._delete_widget(cfg),
                on_geometry_changed=lambda _id, x, y, w, h, cfg=w_cfg: self._on_widget_geom_changed(cfg, x, y, w, h),
                on_connect_clicked=lambda sid: self._open_model_connections_dialog(focus_id=sid),
                on_connect_drag_move=lambda sid, gpos: self._on_card_connect_drag_move(sid, gpos),
                on_connect_dragged=lambda sid, gpos: self._on_card_connect_dragged(sid, gpos),
                on_geometry_live_changed=self._on_card_geometry_live_changed,
                on_clear_filter=self._on_widget_clear_filter,
                is_edge_locked=self._is_card_edge_locked,
                on_linked_edge_begin=self._begin_linked_edge_resize,
                on_linked_edge_step=self._step_linked_edge_resize,
                on_toggle_border_locks=self._toggle_card_border_locks,
                border_style=getattr(w_cfg, "border_style", "") or global_bstyle,
            )
            self.workspace_canvas.add_card(
                frame,
                w_cfg.layout_x,
                w_cfg.layout_y,
                w_cfg.layout_w or 440,
                w_cfg.layout_h or 280,
            )
            self._widget_cards.append((frame, inner))

        self.workspace_canvas.apply_design_settings(
            canvas_w=int(getattr(self.config, "canvas_width", 1280) or 1280),
            canvas_h=int(getattr(self.config, "canvas_height", 720) or 720),
            show_border=bool(getattr(self.config, "show_design_border", True)),
            show_grid=bool(getattr(self.config, "show_grid", True)),
            snap_to_grid=snap_enabled,
            grid_size=grid_size,
            preview_mode=preview_mode,
            border_style=str(getattr(self.config, "canvas_border_style", "dashed") or "dashed"),
            border_color=str(getattr(self.config, "canvas_border_color", "#38bdf8") or "#38bdf8"),
            border_width=int(getattr(self.config, "canvas_border_width", 2) or 2),
            border_radius=int(getattr(self.config, "canvas_border_radius", 10) if getattr(self.config, "canvas_border_radius", None) is not None else 10),
        )
        self._update_adjacent_card_borders()
        self._update_canvas_wires()
        last_id = getattr(self, "_last_added_card_id", None)
        if last_id:
            self._last_added_card_id = None
            for fr, _inner in list(self._slicer_cards) + list(self._widget_cards):
                if getattr(fr, "item_id", None) == last_id:
                    if hasattr(fr, "raise_"):
                        fr.raise_()
                    if hasattr(self.workspace_canvas, "wire_overlay"):
                        self.workspace_canvas.wire_overlay.raise_()
                    if hasattr(self.workspace_canvas, "artboard_grip"):
                        self.workspace_canvas.artboard_grip.raise_()
                    for sn in getattr(self.workspace_canvas, "_seam_nodes", []) or []:
                        if hasattr(sn, "isVisible") and sn.isVisible():
                            sn.raise_()
                    if hasattr(self.workspace_canvas, "ensureWidgetVisible"):
                        self.workspace_canvas.ensureWidgetVisible(fr)
                    break
        self.refresh_widget_values()
        self._refresh_active_filters_banner()

    def _on_slicer_geom_changed(self, cfg: SlicerConfig, x: int, y: int, w: int, h: int) -> None:
        cfg.layout_x, cfg.layout_y, cfg.layout_w, cfg.layout_h = x, y, w, h
        self._update_adjacent_card_borders()
        self.workspace_canvas.expand_to_fit()
        self._save_project_state()

    def _on_widget_geom_changed(self, cfg: WidgetConfig, x: int, y: int, w: int, h: int) -> None:
        cfg.layout_x, cfg.layout_y, cfg.layout_w, cfg.layout_h = x, y, w, h
        self._update_adjacent_card_borders()
        self.workspace_canvas.expand_to_fit()
        self._save_project_state()

    def _merged_expression_records(self) -> Dict[str, List[Dict[str, Any]]]:
        merged = dict(getattr(self.persistence, "layer_records_cache", {}) or {})
        ex_map = getattr(self.persistence, "excel_records_cache", {}) or {}
        for ds in getattr(self.config, "data_sources", []) or []:
            if ds.name and ds.name not in merged and ds.id in ex_map:
                merged[ds.name] = ex_map[ds.id]
        return merged

    def _hydrate_layers_for_expression(self, layer_names: List[str]) -> None:
        merged = self._merged_expression_records()
        for ln, rows in merged.items():
            if ln and ln not in self.persistence.layer_records_cache:
                self.persistence.layer_records_cache[ln] = rows
        missing = [str(n).strip() for n in (layer_names or []) if str(n).strip() and str(n).strip() not in merged]
        if not missing:
            return
        if hasattr(self.persistence, "hydrate_all_sources"):
            self.persistence.hydrate_all_sources(
                self.config,
                use_canvas_extent=bool(getattr(self, "_extent_filter_enabled", False)),
                force_refresh_sources=False,
                only_referenced=True,
                only_names=missing,
            )

    def refresh_widget_values(self) -> None:
        lang = self.config.language or "et"
        for _frame, slicer in self._slicer_cards:
            records = self.persistence.layer_records_cache.get(slicer.slicer_cfg.layer_name, [])
            slicer.refresh_data(records, lang=lang, all_records_by_layer=self.persistence.layer_records_cache)

        all_recs = self._merged_expression_records()
        expr_cards: List[Tuple[Any, ExpressionCardWidget]] = []
        for _frame, w in self._widget_cards:
            if isinstance(w, DashboardMapWidget):
                w.refresh_data(self.persistence.layer_records_cache, self.filter_bus)
            elif isinstance(w, KpiCardWidget):
                recs = self.persistence.layer_records_cache.get(w.config.layer_name, [])
                w.refresh_data(recs, self.filter_bus, lang=lang)
            elif isinstance(w, ExpressionCardWidget):
                expr_cards.append((_frame, w))
            elif isinstance(w, InteractiveChartWidget):
                if getattr(w.config, "spatial_join_layer", ""):
                    recs = self.persistence.get_spatial_pivot_records(self.config, w.config)
                else:
                    recs = self.persistence.layer_records_cache.get(w.config.layer_name, [])
                w.refresh_data(recs, self.filter_bus, lang=lang)
            elif isinstance(w, DataTableWidget):
                if getattr(w.config, "spatial_join_layer", ""):
                    recs = self.persistence.get_spatial_pivot_records(self.config, w.config)
                else:
                    recs = self.persistence.layer_records_cache.get(w.config.layer_name, [])
                w.refresh_data(recs, self.filter_bus, lang=lang)

        for _frame, w in expr_cards:
            recs = all_recs.get(w.config.layer_name, [])
            w.refresh_data(
                recs,
                self.filter_bus,
                lang=lang,
                all_records_by_layer=all_recs,
                widget_resolver=lambda rk, md="value", wid=w.config.id: compute_dashboard_widget_ref(
                    rk, self.config, all_recs, self.filter_bus, mode=md, visited={wid}
                ),
            )

    def _zoom_to_records_or_fids(
        self,
        layer_name: str,
        fids: List[Any],
        fallback_points: Optional[List[Tuple[float, float]]] = None,
    ) -> None:
        if not fids and not fallback_points:
            return
        for _frame, w in self._widget_cards:
            if isinstance(w, DashboardMapWidget):
                try:
                    w.zoom_to_feature_ids(layer_name, fids, fallback_points=fallback_points)
                except Exception:
                    pass
        if self.iface and (fids or fallback_points):
            try:
                canvas = self.iface.mapCanvas()
                zoomed = False
                lyr = self.persistence._find_qgis_layer_by_name(layer_name)
                if lyr is not None and fids:
                    int_fids = []
                    for fid in fids[:2000]:
                        try:
                            int_fids.append(int(fid))
                        except (TypeError, ValueError):
                            pass
                    if int_fids:
                        canvas.zoomToFeatureIds(lyr, int_fids)
                        canvas.refresh()
                        zoomed = True
                if not zoomed and fallback_points:
                    from qgis.core import (
                        QgsCoordinateReferenceSystem,
                        QgsCoordinateTransform,
                        QgsProject,
                        QgsRectangle,
                    )

                    pts = []
                    for a, b in fallback_points:
                        if a is None or b is None:
                            continue
                        fa, fb = float(a), float(b)
                        lon_v, lat_v = (fb, fa) if (fa > 45.0 and fb < 40.0) else (fa, fb)
                        pts.append((lon_v, lat_v))
                    if pts:
                        xs = [p[0] for p in pts]
                        ys = [p[1] for p in pts]
                        rect = QgsRectangle(min(xs), min(ys), max(xs), max(ys))
                        proj = QgsProject.instance()
                        dest_crs = canvas.mapSettings().destinationCrs()
                        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                        if dest_crs != wgs84:
                            rect = QgsCoordinateTransform(wgs84, dest_crs, proj).transformBoundingBox(rect)
                        pad_x = max(rect.width() * 0.14, 300.0 if not dest_crs.isGeographic() else 0.004)
                        pad_y = max(rect.height() * 0.14, 300.0 if not dest_crs.isGeographic() else 0.004)
                        canvas.setExtent(
                            QgsRectangle(
                                rect.xMinimum() - pad_x,
                                rect.yMinimum() - pad_y,
                                rect.xMaximum() + pad_x,
                                rect.yMaximum() + pad_y,
                            )
                        )
                        canvas.refresh()
            except Exception:
                pass

    def _zoom_design_maps_to_active_filters(
        self, preferred_layer: str = "", preferred_source_id: str = ""
    ) -> None:
        if not preferred_source_id:
            preferred_source_id = str(getattr(self, "_last_filter_source_id", "") or "")
        if getattr(self, "_extent_filter_enabled", False):
            return
        active = self.filter_bus.active_filters()
        if not active:
            return
        map_target_ids = {"__map__"} | {
            w.id for w in getattr(self.config, "widgets", []) if w.widget_type == "map"
        }
        has_any_explicit_conns = bool(getattr(self.config, "widget_connections", []))

        def _norm_sid(sid: str) -> str:
            return sid[4:] if sid.startswith("tbl_") else sid

        ordered_active = list(reversed(active))
        if preferred_source_id or preferred_layer:
            ordered_active.sort(
                key=lambda f: (
                    0
                    if (
                        preferred_source_id
                        and (f.source_id == preferred_source_id or _norm_sid(f.source_id) == _norm_sid(preferred_source_id))
                    )
                    else 1,
                    0 if (preferred_layer and f.layer_name == preferred_layer) else 1,
                )
            )

        target_layers: List[str] = []
        if preferred_layer and any(
            (preferred_source_id and (_norm_sid(f.source_id) == _norm_sid(preferred_source_id)))
            or f.layer_name == preferred_layer
            for f in ordered_active
        ):
            target_layers.append(preferred_layer)

        for flt in ordered_active:
            outgoing = []
            if hasattr(self.config, "get_connections_from"):
                outgoing = self.config.get_connections_from(flt.source_id) or self.config.get_connections_from(
                    _norm_sid(flt.source_id)
                )
            if outgoing:
                wants_map_zoom = any(
                    c.target_id in map_target_ids and (c.action or "filter_and_zoom") in ("filter_and_zoom", "zoom_only")
                    for c in outgoing
                )
                if not wants_map_zoom:
                    continue
            elif not getattr(self.config, "auto_zoom_on_filter", True) and has_any_explicit_conns:
                continue

            for src_ln, _ in (flt.target_sources() if hasattr(flt, "target_sources") else [(flt.layer_name, flt.field_name)]):
                if src_ln and src_ln not in target_layers:
                    target_layers.append(src_ln)
        if not target_layers:
            return

        for lname in target_layers:
            recs = self.persistence.layer_records_cache.get(lname, [])
            if not recs:
                continue
            filtered = self.filter_bus.filter_records(recs, layer_name=lname)
            if not filtered:
                continue
            if len(filtered) >= len(recs) and lname != preferred_layer:
                continue
            fids = [r.get("_feature_id") for r in filtered if r.get("_feature_id") is not None]
            pts: List[Tuple[float, float]] = []
            for r in filtered[:2500]:
                bb = r.get("_bbox")
                if isinstance(bb, (list, tuple)) and len(bb) == 4:
                    try:
                        pts.append((float(bb[1]), float(bb[0])))
                        pts.append((float(bb[3]), float(bb[2])))
                    except (TypeError, ValueError):
                        pass
                lat, lon = r.get("_lat"), r.get("_lon")
                if lat is not None and lon is not None:
                    try:
                        pts.append((float(lat), float(lon)))
                    except (TypeError, ValueError):
                        pass
            if fids or pts:
                self._zoom_to_records_or_fids(lname, fids, fallback_points=pts)
                return

    def _zoom_to_feature(self, layer_name: str, feature_id: Any) -> None:
        if feature_id is None:
            return
        self._zoom_to_records_or_fids(layer_name, [feature_id])

    def _update_canvas_wires(self, live_drag: Optional[Tuple[str, Any]] = None) -> None:
        if hasattr(self, "workspace_canvas") and hasattr(self.workspace_canvas, "update_wires"):
            preview = bool(getattr(self.config, "preview_mode", False))
            show_wires = bool(getattr(self.config, "show_connection_wires", True))
            conns = [] if (preview or not show_wires) else getattr(self.config, "widget_connections", [])
            self.workspace_canvas.update_wires(conns, live_drag=None if preview else live_drag)

    def _on_card_connect_drag_move(self, source_id: str, global_pt: Any) -> None:
        try:
            board_pt = self.workspace_canvas.board.mapFromGlobal(global_pt)
            self._update_canvas_wires(live_drag=(source_id, board_pt))
        except Exception:
            pass

    def _on_card_connect_dragged(self, source_id: str, global_pt: Any) -> None:
        tgt_id = self.workspace_canvas.card_at_global_pos(global_pt, exclude_id=source_id)
        if tgt_id and tgt_id != source_id and hasattr(self.config, "add_or_update_connection"):
            self.config.add_or_update_connection(source_id, tgt_id, action="filter_and_zoom")
            self.filter_bus.set_connections(self.config.widget_connections)
            self._save_project_state()
            self._retranslate_ui()
            self.refresh_widget_values()
        self._update_canvas_wires(live_drag=None)

    def _open_model_connections_dialog(self, focus_id: Optional[str] = None) -> None:
        dlg = WidgetConnectionsDialog(
            self.config,
            focus_node_id=focus_id,
            lang=self.config.language or "et",
            parent=self,
        )
        if exec_dialog(dlg):
            if hasattr(self.config, "sync_widget_connections"):
                self.config.sync_widget_connections()
            self.filter_bus.set_connections(self.config.widget_connections)
            self._save_project_state()
            self._retranslate_ui()
            self.refresh_widget_values()
            if getattr(self.config, "auto_zoom_on_filter", True) and self.filter_bus.active_filters():
                self._zoom_design_maps_to_active_filters()
            self._update_canvas_wires()
            if getattr(self.config, "preview_mode", False):
                self._refresh_html_preview(open_external_if_fallback=False)

    # ------------------------------------------------------------------
    # Interactive CRUD Dialogs
    # ------------------------------------------------------------------

    def _available_layer_names(self) -> List[str]:
        names = list(self.persistence.layer_records_cache.keys())
        for ds in self.config.data_sources:
            if ds.name and not getattr(ds, "is_basemap", False) and ds.name not in names:
                names.append(ds.name)
        for ref in sorted(self.persistence.referenced_layer_names(self.config)):
            if ref and ref not in names:
                names.append(ref)
        sync_main = (
            str(getattr(self.config, "canvas_sync_mode", "dashboard_only") or "dashboard_only")
            == "sync_main_canvas"
        )
        if sync_main or not names:
            for lyr in DashboardPersistenceManager.list_qgis_project_layer_schemas().keys():
                if lyr not in names:
                    names.append(lyr)
        return names

    def open_sources_dialog(self) -> None:
        proj_dir = DashboardPersistenceManager.get_current_project_dir()
        dlg = DataSourceJoinDialog(
            self.config,
            project_dir=proj_dir,
            lang=self.config.language,
            catalog_manager=self.catalog_manager,
            parent=self,
        )
        if exec_dialog(dlg):
            self._save_project_state()
            self.refresh_catalog_panel()
            self.reload_and_hydrate()

    def open_add_widget(self, preset_type: str = "bar") -> None:
        self._show_workspace_view()
        layers = self._available_layer_names()
        default_layer = layers[0] if layers else ""
        init_w = 540 if preset_type == "map" else (280 if preset_type in ("kpi", "expression") else 440)
        init_h = 390 if preset_type == "map" else (150 if preset_type in ("kpi", "expression") else 280)
        px, py = self._next_default_position(init_w, init_h)
        raw_map_layers = (
            (list(self.persistence.referenced_layer_names(self.config)) or list(self.persistence.layer_records_cache.keys()) or ([default_layer] if default_layer else []))
            if preset_type == "map"
            else []
        )
        initial_map_layers = (
            OgcConnector.sort_layers_automatically(raw_map_layers, layer_records=self.persistence.layer_records_cache)
            if len(raw_map_layers) > 1
            else raw_map_layers
        )
        w = WidgetConfig(
            title=tr("map_widget_title", self.config.language) if preset_type == "map" else tr("btn_add_widget", self.config.language),
            widget_type=preset_type,
            layer_name=default_layer,
            map_layers=initial_map_layers,
            page_id=getattr(self.config, "active_page_id", "page_1") or "page_1",
            layout_x=px,
            layout_y=py,
            layout_w=init_w,
            layout_h=init_h,
        )
        self._edit_or_add_widget_dialog(w, is_new=True)

    def _edit_or_add_widget_dialog(self, cfg: WidgetConfig, is_new: bool = False, force_generic: bool = False) -> None:
        recs_map = self._merged_expression_records()
        if cfg.widget_type == "expression" and not force_generic:
            dlg: Any = ExpressionDesignerDialog(
                cfg,
                self.config,
                persistence=self.persistence,
                filter_bus=self.filter_bus,
                on_hydrate_layers=self._hydrate_layers_for_expression,
                on_switch_type=lambda c=cfg, n=is_new: self._edit_or_add_widget_dialog(c, is_new=n, force_generic=True),
                lang=self.config.language,
                records_by_layer=recs_map,
                parent=self,
            )
        else:
            dlg = WidgetEditorDialog(
                cfg,
                self._available_layer_names(),
                self.persistence.get_layer_fields_map(),
                lang=self.config.language,
                catalog_manager=self.catalog_manager,
                dashboard=self.config,
                records_by_layer=recs_map,
                persistence=self.persistence,
                filter_bus=self.filter_bus,
                on_hydrate_layers=self._hydrate_layers_for_expression,
                parent=self,
            )
        if exec_dialog(dlg):
            if is_new:
                self.config.widgets.append(cfg)
                self._last_added_card_id = cfg.id
            self._save_project_state()
            self._apply_widget_or_slicer_change()

    def _edit_widget(self, cfg: WidgetConfig) -> None:
        self._edit_or_add_widget_dialog(cfg, is_new=False)

    def _confirm_card_deletion(self, name: str, is_slicer: bool = False) -> bool:
        lang = self.config.language or "et"
        key = "confirm_del_slicer_msg" if is_slicer else "confirm_del_widget_msg"
        yes_btn = qt_enum(QMessageBox, "StandardButton", "Yes")
        no_btn = qt_enum(QMessageBox, "StandardButton", "No")
        try:
            resp = QMessageBox.question(
                self,
                tr("confirm_del_title", lang),
                tr(key, lang, name=name),
                yes_btn | no_btn,
            )
        except TypeError:
            resp = QMessageBox.question(
                self,
                tr("confirm_del_title", lang),
                tr(key, lang, name=name),
            )
        if resp is None or resp is True:
            return True
        if resp is False:
            return False
        if isinstance(resp, int) or type(resp) is type(yes_btn):
            return resp == yes_btn
        return True

    def _delete_widget(self, cfg: WidgetConfig) -> None:
        if not self._confirm_card_deletion(cfg.title or cfg.widget_type, is_slicer=False):
            return
        self.config.widgets = [w for w in self.config.widgets if w.id != cfg.id]
        self._save_project_state()
        self.rebuild_dashboard_ui()

    def open_add_slicer(self) -> None:
        self._show_workspace_view()
        layers = self._available_layer_names()
        px, py = self._next_default_position(240, 110)
        s = SlicerConfig(
            title=tr("lbl_slicer_title", self.config.language),
            layer_name=layers[0] if layers else "",
            page_id=getattr(self.config, "active_page_id", "page_1") or "page_1",
            layout_x=px,
            layout_y=py,
            layout_w=240,
            layout_h=115,
        )
        dlg = SlicerEditorDialog(
            s,
            layers,
            self.persistence.get_layer_fields_map(),
            lang=self.config.language,
            catalog_manager=self.catalog_manager,
            dashboard=self.config,
            parent=self,
        )
        if exec_dialog(dlg):
            self.config.slicers.append(s)
            self._last_added_card_id = s.id
            self._save_project_state()
            self._apply_widget_or_slicer_change()

    def _edit_slicer(self, cfg: SlicerConfig) -> None:
        dlg = SlicerEditorDialog(
            cfg,
            self._available_layer_names(),
            self.persistence.get_layer_fields_map(),
            lang=self.config.language,
            catalog_manager=self.catalog_manager,
            dashboard=self.config,
            parent=self,
        )
        if exec_dialog(dlg):
            self._save_project_state()
            self._apply_widget_or_slicer_change()

    def _delete_slicer(self, cfg: SlicerConfig) -> None:
        if not self._confirm_card_deletion(cfg.title or cfg.field_name, is_slicer=True):
            return
        self.config.slicers = [s for s in self.config.slicers if s.id != cfg.id]
        self._save_project_state()
        self.rebuild_dashboard_ui()

    def open_sharepoint_catalog(self) -> None:
        proj_dir = DashboardPersistenceManager.get_current_project_dir()
        dlg = SharePointCatalogDialog(
            self.config,
            on_template_loaded=self.load_dashboard_config,
            project_dir=proj_dir,
            lang=self.config.language,
            parent=self,
        )
        exec_dialog(dlg)

    def export_html_dashboard(self) -> None:
        lang = self.config.language or "et"
        if not os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS") and not os.environ.get("PYTEST_CURRENT_TEST"):
            exp_dlg = ExportDashboardDialog(self.config, lang=lang, parent=self)
            if not exec_dialog(exp_dlg):
                return
        fmt = "aspx" if str(getattr(self.config, "export_format", "html") or "html").lower() == "aspx" else "html"
        ext = f".{fmt}"
        proj_dir = DashboardPersistenceManager.get_current_project_dir()
        default_dir = proj_dir or os.path.expanduser("~")
        safe_stem = (self.config.title or "dashboard").strip().lower().replace(" ", "_") or "dashboard"
        default_name = f"{safe_stem}{ext}"
        file_filter = (
            "SharePoint Dashboard Page (*.aspx);;Interactive HTML Dashboard (*.html)"
            if fmt == "aspx"
            else "Interactive HTML Dashboard (*.html);;SharePoint Dashboard Page (*.aspx)"
        )
        out_path, _ = QFileDialog.getSaveFileName(
            self,
            tr("btn_export_html", lang),
            os.path.join(default_dir, default_name),
            file_filter,
        )
        if not out_path:
            return
        if out_path.lower().endswith(".aspx"):
            self.config.export_format = "aspx"
        elif out_path.lower().endswith((".html", ".htm")):
            self.config.export_format = "html"
        else:
            out_path = f"{out_path}{ext}"
        exp_title = tr("exporting_html_title", lang)
        self._set_loading_overlay(
            True,
            title=exp_title,
            subtitle=tr("export_stage_saving", lang),
            done=4,
            total=100,
            force_pump=True,
        )
        try:
            self._save_project_state()
            pkg_layers = bool(getattr(self.config, "package_layers_in_export", True))
            if hasattr(self.persistence, "ensure_referenced_sources_registered"):
                self.persistence.ensure_referenced_sources_registered(
                    self.config, catalog_manager=getattr(self, "catalog_manager", None), project_dir=proj_dir
                )
            static_layers = (
                self.persistence.get_static_packaged_layer_names(self.config)
                if hasattr(self.persistence, "get_static_packaged_layer_names")
                else set()
            )

            def _make_stage_cb(stage_key: str) -> Callable[[int, str], None]:
                def _cb(pct: int, detail: str) -> None:
                    nm = detail
                    idx_s, tot_s = "1", "1"
                    if " (" in detail and "/" in detail and detail.endswith(")"):
                        nm_part, frac_part = detail.rsplit(" (", 1)
                        nm = nm_part
                        parts = frac_part[:-1].split("/", 1)
                        if len(parts) == 2:
                            idx_s, tot_s = parts[0], parts[1]
                    msg = tr(stage_key, lang, name=nm, idx=idx_s, total=tot_s)
                    self._set_loading_overlay(
                        True,
                        title=exp_title,
                        subtitle=msg,
                        done=pct,
                        total=100,
                        force_pump=True,
                    )

                return _cb

            self._set_loading_overlay(
                True,
                title=exp_title,
                subtitle=tr("export_stage_geojson", lang, name="...", idx=0, total=max(1, len(self.persistence.layer_records_cache))),
                done=15,
                total=100,
                force_pump=True,
            )
            if pkg_layers or static_layers:
                self.persistence._enrich_natura_pria_overlap({}, config=self.config)
            if pkg_layers:
                initial_geojson = self.persistence.export_initial_geojson_for_html(
                    self.config, progress_cb=_make_stage_cb("export_stage_geojson")
                )
            elif static_layers:
                initial_geojson = self.persistence.export_initial_geojson_for_html(
                    self.config,
                    only_layers=static_layers,
                    progress_cb=_make_stage_cb("export_stage_geojson"),
                )
            else:
                initial_geojson = {}
            self._set_loading_overlay(
                True,
                title=exp_title,
                subtitle=tr("export_stage_pyramids", lang, name="...", idx=0, total=max(1, len(self.persistence.layer_records_cache))),
                done=35,
                total=100,
                force_pump=True,
            )
            layer_stats, vector_pyramids = self.persistence.export_pyramids_for_html(
                self.config,
                include_lod1=pkg_layers,
                lod1_layers=static_layers,
                lod1_max_sync_features=95000,
                skip_overlap_enrich=True,
                progress_cb=_make_stage_cb("export_stage_pyramids"),
            )
            spatial_relations: List[Dict[str, Any]] = []
            if pkg_layers or static_layers:
                self._set_loading_overlay(
                    True,
                    title=exp_title,
                    subtitle=tr("export_stage_spatial", lang, name="...", idx=0, total=1),
                    done=72,
                    total=100,
                    force_pump=True,
                )
                spatial_relations = self.persistence.export_spatial_relations_for_html(
                    self.config,
                    only_layers=(None if pkg_layers else static_layers),
                    progress_cb=_make_stage_cb("export_stage_spatial"),
                )
            self._set_loading_overlay(
                True,
                title=exp_title,
                subtitle=tr("export_stage_writing", lang),
                done=85,
                total=100,
                force_pump=True,
            )
            self.refresh_connections_panel()
            written = HtmlDashboardExporter.export_to_file(
                config=self.config,
                layer_records=self.persistence.layer_records_cache,
                excel_records_by_id=self.persistence.excel_records_cache,
                output_path=out_path,
                project_dir=proj_dir,
                initial_geojson=initial_geojson,
                layer_stats=layer_stats,
                vector_pyramids=vector_pyramids,
                spatial_relations=spatial_relations,
                has_preview_api=False,
            )
            self._set_loading_overlay(
                True,
                title=exp_title,
                subtitle=tr("export_stage_writing", lang),
                done=100,
                total=100,
                force_pump=True,
            )
        finally:
            self._set_loading_overlay(False)
        QMessageBox.information(
            self,
            tr("btn_export_html", self.config.language),
            f"{'Salvestatud' if self.config.language == 'et' else 'Exported'}:\n{written}",
        )
        if (
            bool(getattr(self.config, "open_after_export", False))
            and not os.environ.get("QGIS_TEAM_DASHBOARD_HEADLESS")
            and not os.environ.get("PYTEST_CURRENT_TEST")
        ):
            webbrowser.open(f"file:///{written}")
