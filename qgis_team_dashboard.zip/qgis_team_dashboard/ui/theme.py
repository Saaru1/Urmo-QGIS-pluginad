# -*- coding: utf-8 -*-
"""
Modern Adaptive Dark/Light Stylesheet & Theme Tokens for QGIS Team Dashboard.
Detects QGIS Desktop's palette lightness (PyQt6 & PyQt5 compatible via qt_compat)
and applies clean card styling to dock panels, catalog trees, and dialogs.
"""

from typing import Any, Dict, Optional

try:
    from ..ui.qt_compat import QtGui, QtWidgets, qt_enum
except Exception:
    QtGui = None  # type: ignore
    QtWidgets = None  # type: ignore
    qt_enum = None  # type: ignore


class ThemeManager:
    """Provides adaptive dark/light color palettes and modern QSS for dialogs & dock."""

    @staticmethod
    def is_dark_mode() -> bool:
        try:
            app = QtWidgets.QApplication.instance()
            if app:
                role_win = qt_enum(QtGui.QPalette, "ColorRole", "Window")
                role_base = qt_enum(QtGui.QPalette, "ColorRole", "Base")
                pal = app.palette()
                return pal.color(role_win).lightness() < 128 or pal.color(role_base).lightness() < 128
        except Exception:
            pass
        return True

    @classmethod
    def resolve_mode(cls, theme_mode: Optional[str] = None) -> str:
        if theme_mode in ("dark", "light"):
            return theme_mode
        return "dark" if cls.is_dark_mode() else "light"

    @classmethod
    def colors_for_widget(cls, widget: Any) -> Dict[str, str]:
        w = widget
        while w is not None:
            try:
                mode = w.property("dashboard_theme")
                if mode in ("dark", "light"):
                    return cls.colors(theme_mode=mode)
            except Exception:
                pass
            try:
                w = w.parentWidget()
            except Exception:
                break
        return cls.colors(theme_mode=None)

    @classmethod
    def colors(cls, force_dark: bool = False, theme_mode: Optional[str] = None) -> Dict[str, str]:
        if force_dark:
            dark = True
        else:
            dark = cls.resolve_mode(theme_mode) == "dark"
        if dark:
            return {
                "bg_main": "#111827",
                "bg_panel": "#1e293b",
                "bg_input": "#0f172a",
                "bg_hover": "#334155",
                "bg_selected": "#0284c7",
                "card_surface": "#0f172a",
                "artboard_fill": "#0f172a",
                "grid_dot": "#334155",
                "chart_muted": "#475569",
                "text_main": "#f1f5f9",
                "text_secondary": "#cbd5e1",
                "text_muted": "#94a3b8",
                "border": "#334155",
                "border_focus": "#38bdf8",
                "accent": "#0ea5e9",
                "accent_hover": "#38bdf8",
                "success": "#10b981",
                "success_hover": "#34d399",
                "danger": "#e11d48",
                "danger_text": "#fb7185",
                "card_handle": "#0f172a",
            }
        return {
            "bg_main": "#f8fafc",
            "bg_panel": "#ffffff",
            "bg_input": "#ffffff",
            "bg_hover": "#e0f2fe",
            "bg_selected": "#0284c7",
            "card_surface": "#f1f5f9",
            "artboard_fill": "#ffffff",
            "grid_dot": "#dbe5f0",
            "chart_muted": "#cbd5e1",
            "text_main": "#0f172a",
            "text_secondary": "#334155",
            "text_muted": "#64748b",
            "border": "#cbd5e1",
            "border_focus": "#0284c7",
            "accent": "#0284c7",
            "accent_hover": "#0369a1",
            "success": "#059669",
            "success_hover": "#10b981",
            "danger": "#dc2626",
            "danger_text": "#dc2626",
            "card_handle": "#f1f5f9",
        }

    @classmethod
    def get_stylesheet(cls, force_dark: bool = False, theme_mode: Optional[str] = None) -> str:
        c = cls.colors(force_dark=force_dark, theme_mode=theme_mode)
        resolved_mode = "dark" if force_dark else cls.resolve_mode(theme_mode)
        return f"""
            QDialog, QDockWidget, QDockWidget > QWidget, QWidget#DashboardStudioRoot,
            QStackedWidget, QSplitter, QScrollArea#HomeScroll,
            QScrollArea#HomeScroll > QWidget, QScrollArea#HomeScroll > QWidget > QWidget,
            QWidget#HomeContent {{
                background-color: {c['bg_main']};
                color: {c['text_main']};
                font-family: 'Segoe UI', -apple-system, Arial, sans-serif;
                font-size: 12px;
            }}
            QSplitter::handle {{
                background-color: {c['border']};
            }}
            QFrame#FrameCard {{
                background-color: {c['bg_panel']};
                border: 1px solid {c['border']};
                border-radius: 10px;
            }}
            QFrame#LoadingOverlayCard {{
                background-color: {c['bg_panel']};
                border: 2px solid {c['border_focus']};
                border-radius: 12px;
            }}
            QFrame#FloatingPalette {{
                background-color: {c['bg_panel']};
                border: 1px solid {c['border_focus']};
                border-radius: 10px;
            }}
            QFrame#FloatingPaletteDocked {{
                background-color: {c['card_surface']};
                border: 1px solid {c['border']};
                border-radius: 8px;
            }}
            QPushButton[btnRole="miniPalette"] {{
                background-color: {c['card_surface']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 11px;
                font-weight: 600;
                min-height: 22px;
                text-align: left;
            }}
            QPushButton[btnRole="miniPalette"]:hover {{
                background-color: {c['bg_hover']};
                border-color: {c['border_focus']};
            }}
            QPushButton[btnRole="miniPalette"]:checked {{
                background-color: {c['bg_selected']};
                color: #ffffff;
                border-color: {c['border_focus']};
            }}
            QFrame#FloatingPaletteDocked QPushButton[btnRole="miniPalette"] {{
                text-align: center;
                padding: 3px 2px;
            }}
            QFrame#StudioToolbar, QFrame#CatalogPanel, QFrame#DesignStrip, QFrame#HydrationBar {{
                background-color: {c['bg_panel']};
                border: 1px solid {c['border']};
                border-radius: 8px;
            }}
            QLabel {{
                color: {c['text_main']};
                background: transparent;
            }}
            QLabel[role="heroTitle"] {{
                color: {c['text_main']};
                font-size: 17px;
                font-weight: 700;
            }}
            QLabel[role="heroSub"] {{
                color: {c['text_secondary']};
                font-size: 12px;
            }}
            QLabel[role="cardTitle"] {{
                color: {c['text_main']};
                font-size: 13px;
                font-weight: 700;
            }}
            QLabel[role="cardTitleSmall"] {{
                color: {c['text_main']};
                font-size: 11px;
                font-weight: 700;
            }}
            QLabel[role="accentTitle"] {{
                color: {c['border_focus']};
                font-size: 14px;
                font-weight: 700;
            }}
            QLabel[role="accent"] {{
                color: {c['border_focus']};
                font-size: 11px;
            }}
            QLabel[role="accentSmall"] {{
                color: {c['border_focus']};
                font-size: 10px;
            }}
            QLabel[role="monoLink"] {{
                color: {c['border_focus']};
                font-size: 12px;
                font-family: monospace;
            }}
            QLabel[role="sectionHeader"] {{
                color: {c['border_focus']};
                font-weight: 700;
                font-size: 12px;
                padding: 4px 0px 2px 0px;
            }}
            QLabel[role="muted"] {{
                color: {c['text_muted']};
                font-size: 11px;
            }}
            QLabel[role="mutedSmall"] {{
                color: {c['text_secondary']};
                font-size: 10px;
                font-weight: 700;
            }}
            QLabel[role="mutedTiny"] {{
                color: {c['text_muted']};
                font-size: 9px;
            }}
            QLabel[role="kpiValue"] {{
                color: {c['text_main']};
                font-size: 24px;
                font-weight: 700;
            }}
            QGroupBox {{
                background-color: {c['bg_panel']};
                border: 1px solid {c['border']};
                border-radius: 8px;
                margin-top: 12px;
                padding: 12px 10px 10px 10px;
                font-weight: 600;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px;
                color: {c['border_focus']};
            }}
            QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
                background-color: {c['bg_input']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 5px;
                padding: 5px 8px;
                min-height: 22px;
            }}
            QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
                border: 1px solid {c['border_focus']};
            }}
            QTableWidget, QListWidget, QTreeWidget {{
                background-color: {c['bg_panel']};
                color: {c['text_main']};
                gridline-color: {c['border']};
                border: 1px solid {c['border']};
                border-radius: 6px;
                outline: none;
            }}
            QHeaderView::section {{
                background-color: {c['card_surface']};
                color: {c['text_secondary']};
                padding: 4px 6px;
                border: 1px solid {c['border']};
                font-weight: 700;
                font-size: 11px;
            }}
            QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{
                background-color: {c['bg_selected']};
                color: #ffffff;
                border-radius: 4px;
            }}
            QPushButton, QToolButton {{
                background-color: {c['bg_panel']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                border-radius: 6px;
                padding: 5px 11px;
                min-height: 22px;
                font-weight: 500;
            }}
            QPushButton:hover, QToolButton:hover {{
                background-color: {c['bg_hover']};
                border-color: {c['border_focus']};
            }}
            QPushButton:checked, QToolButton:checked {{
                background-color: {c['bg_selected']};
                color: #ffffff;
                border-color: {c['border_focus']};
                font-weight: 600;
            }}
            QPushButton[btnRole="primary"] {{
                background-color: {c['accent']};
                color: #ffffff;
                border: 1px solid {c['accent']};
                font-weight: 600;
                padding: 6px 14px;
            }}
            QPushButton[btnRole="primary"]:hover {{
                background-color: {c['accent_hover']};
            }}
            QPushButton[btnRole="secondary"] {{
                background-color: {c['card_surface']};
                color: {c['text_main']};
                border: 1px solid {c['border']};
                font-weight: 600;
            }}
            QPushButton[btnRole="secondary"]:hover {{
                background-color: {c['bg_hover']};
                border-color: {c['border_focus']};
            }}
            QPushButton[btnRole="accent"] {{
                background-color: {c['card_surface']};
                color: {c['border_focus']};
                border: 1px solid {c['accent']};
                font-weight: 600;
            }}
            QPushButton[btnRole="accent"]:hover {{
                background-color: {c['bg_hover']};
            }}
            QPushButton[btnRole="accent"]:checked {{
                background-color: {c['bg_selected']};
                color: #ffffff;
                border-color: {c['border_focus']};
            }}
            QPushButton[btnRole="chip"] {{
                padding: 2px 8px;
                border-radius: 10px;
                font-size: 10px;
                min-height: 18px;
                background-color: {c['card_surface']};
                color: {c['text_secondary']};
                border: 1px solid {c['border']};
            }}
            QPushButton[btnRole="chip"]:checked {{
                background-color: {c['bg_selected']};
                color: #ffffff;
                border-color: {c['border_focus']};
                font-weight: 700;
            }}
            QPushButton[btnRole="cardAction"] {{
                font-size: 10px;
                padding: 1px 7px;
                min-height: 18px;
                background-color: {c['bg_panel']};
                color: {c['text_secondary']};
                border: 1px solid {c['border']};
                border-radius: 4px;
            }}
            QPushButton[btnRole="cardAction"]:hover {{
                background-color: {c['bg_hover']};
                color: {c['text_main']};
            }}
            QPushButton[btnRole="cardClose"] {{
                font-size: 12px;
                padding: 0px;
                min-height: 18px;
                background-color: {c['bg_panel']};
                color: {c['danger_text']};
                border: 1px solid {c['border']};
                border-radius: 4px;
            }}
            QPushButton[btnRole="cardClose"]:hover {{
                background-color: {c['danger']};
                color: #ffffff;
            }}
            QPushButton[btnRole="miniTool"] {{
                font-size: 10px;
                padding: 2px 7px;
                min-height: 20px;
            }}
            QPushButton[btnRole="miniStep"] {{
                font-size: 11px;
                padding: 1px 4px;
                min-height: 18px;
            }}
            QPushButton[btnRole="scalePill"] {{
                color: {('#0369a1' if resolved_mode == 'light' else '#93c5fd')};
                background-color: {('#e0f2fe' if resolved_mode == 'light' else 'rgba(15,23,42,0.78)')};
                border: 1px solid {('#bae6fd' if resolved_mode == 'light' else '#334155')};
                border-radius: 5px;
                padding: 2px 8px;
                min-height: 18px;
                font-size: 10px;
                font-weight: 700;
            }}
            QPushButton[btnRole="scalePill"]:hover {{
                border-color: {c['border_focus']};
                background-color: {c['bg_hover']};
            }}
            QFrame#MapFallback {{
                background-color: {c['card_surface']};
                border: 1px dashed {c['border']};
                border-radius: 6px;
            }}
            QFrame#ResizeHandle {{
                background-color: {c['border_focus']};
                border: 2px solid {c['card_handle']};
                border-radius: 4px;
            }}
            QPushButton[btnRole="success"] {{
                background-color: {c['success']};
                color: #ffffff;
                border: 1px solid {c['success']};
                font-weight: 600;
            }}
            QPushButton[btnRole="success"]:hover {{
                background-color: {c['success_hover']};
            }}
            QPushButton[btnRole="tile"] {{
                background-color: {c['bg_panel']};
                border: 1px solid {c['border']};
                border-radius: 8px;
                padding: 8px 6px;
                min-height: 44px;
                text-align: center;
                font-weight: 600;
            }}
            QPushButton[btnRole="tile"]:checked {{
                background-color: {c['bg_selected']};
                color: #ffffff;
                border: 2px solid {c['border_focus']};
            }}
            QTabWidget::pane {{
                border: 1px solid {c['border']};
                border-radius: 6px;
                background-color: {c['bg_main']};
                padding: 6px;
            }}
            QTabBar::tab {{
                background-color: {c['bg_panel']};
                color: {c['text_muted']};
                border: 1px solid {c['border']};
                border-bottom: none;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                padding: 6px 14px;
                margin-right: 3px;
            }}
            QTabBar::tab:selected {{
                background-color: {c['bg_main']};
                color: {c['text_main']};
                border-top: 2px solid {c['border_focus']};
                font-weight: 600;
            }}
            QProgressBar {{
                background-color: {c['bg_input']};
                border: 1px solid {c['border']};
                border-radius: 3px;
                height: 6px;
                text-align: center;
            }}
            QProgressBar::chunk {{
                background-color: {c['accent']};
                border-radius: 2px;
            }}
            QFrame#DockTitleBar {{
                background-color: {c['card_surface']};
                border-bottom: 1px solid {c['border']};
                padding: 1px 4px;
            }}
            QPushButton[btnRole="dockCtrl"] {{
                background-color: transparent;
                color: {c['text_secondary']};
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 0px 4px;
                min-height: 20px;
                max-height: 20px;
                min-width: 22px;
                font-size: 11px;
                font-weight: 700;
            }}
            QPushButton[btnRole="dockCtrl"]:hover {{
                background-color: {c['bg_hover']};
                color: {c['text_main']};
                border-color: {c['border_focus']};
            }}
            QScrollArea#StudioBarScroll, QScrollArea#StudioBarScroll > QWidget,
            QScrollArea#StudioBarScroll > QWidget > QWidget {{
                background-color: transparent;
                border: none;
            }}
            QScrollArea#StudioBarScroll QScrollBar:horizontal {{
                height: 10px;
                background: {c['bg_panel']};
                border-top: 1px solid {c['border']};
                margin: 0px;
            }}
            QScrollArea#StudioBarScroll QScrollBar::handle:horizontal {{
                background: {c['text_muted']};
                border-radius: 5px;
                min-width: 36px;
                margin: 1px 2px;
            }}
            QScrollArea#StudioBarScroll QScrollBar::handle:horizontal:hover {{
                background: {c['accent']};
            }}
            QScrollArea#StudioBarScroll QScrollBar::add-line:horizontal,
            QScrollArea#StudioBarScroll QScrollBar::sub-line:horizontal {{
                width: 0px;
                border: none;
            }}
        """
