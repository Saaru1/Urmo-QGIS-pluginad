# -*- coding: utf-8 -*-
"""
Connection-Dialog-Style Visual Lego Expression Designer for QGIS Team Dashboard.

Allows standard users to build cross-dashboard expressions like Lego blocks:
- Drag & drop Layers, Excel/CSV tables, Fields ($area, attributes, quick WHERE filters),
  Active Widget outputs, Operators, Constants, and Smart Container Blocks (IF/ELSE, % Share, Group, Format)
  onto a dark dot-grid Model Designer canvas (`#0b1220`).
- Click/double-click any block on the canvas to edit its Layer, Field, Aggregation, Filter, or Value.
- Toggle seamlessly between Visual Lego Mode and Advanced Formula Text Mode with two-way AST sync.
"""

import copy
import json
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..core.expression_engine import (
    EXPRESSION_HELPERS,
    EXPRESSION_TEMPLATES,
    blocks_to_expression,
    compute_dashboard_widget_ref,
    evaluate_dashboard_expression,
    expression_to_blocks,
    extract_layers_from_blocks,
    extract_referenced_layers,
    resolve_expression_accent_color,
)
from ..core.i18n import tr
from ..core.schema import DashboardConfig, WidgetConfig
from .qt_compat import QtCore, QtGui, QtWidgets, exec_dialog, exec_menu, qt_enum
from .theme import ThemeManager

Qt = QtCore.Qt
QMimeData = getattr(QtCore, "QMimeData", None)
QPoint = getattr(QtCore, "QPoint", object)
QPointF = getattr(QtCore, "QPointF", getattr(QtCore, "QPoint", object))
QRectF = getattr(QtCore, "QRectF", getattr(QtCore, "QRect", object))

QBrush = getattr(QtGui, "QBrush", None)
QColor = getattr(QtGui, "QColor", None)
QDrag = getattr(QtGui, "QDrag", None)
QFont = getattr(QtGui, "QFont", None)
QPainter = getattr(QtGui, "QPainter", None)
QPainterPath = getattr(QtGui, "QPainterPath", None)
QPen = getattr(QtGui, "QPen", None)

QCheckBox = QtWidgets.QCheckBox
QColorDialog = getattr(QtWidgets, "QColorDialog", None)
QComboBox = QtWidgets.QComboBox
QDialog = QtWidgets.QDialog
QFormLayout = QtWidgets.QFormLayout
QFrame = QtWidgets.QFrame
QHBoxLayout = QtWidgets.QHBoxLayout
QInputDialog = getattr(QtWidgets, "QInputDialog", None)
QLabel = QtWidgets.QLabel
QLineEdit = QtWidgets.QLineEdit
QListWidget = QtWidgets.QListWidget
QListWidgetItem = QtWidgets.QListWidgetItem
QMenu = QtWidgets.QMenu
QPlainTextEdit = getattr(QtWidgets, "QPlainTextEdit", QtWidgets.QLineEdit)
QPushButton = QtWidgets.QPushButton
QScrollArea = QtWidgets.QScrollArea
QSizePolicy = getattr(QtWidgets, "QSizePolicy", None)
QSpinBox = QtWidgets.QSpinBox
QSplitter = QtWidgets.QSplitter
QStackedWidget = getattr(QtWidgets, "QStackedWidget", QtWidgets.QFrame)
QTreeWidget = QtWidgets.QTreeWidget
QTreeWidgetItem = QtWidgets.QTreeWidgetItem
QVBoxLayout = QtWidgets.QVBoxLayout
QWidget = QtWidgets.QWidget


LEGO_BLOCK_MIME = "application/x-qgis-dashboard-lego-block"

AGG_CHOICES: List[Tuple[str, str, str]] = [
    ("sum", "Σ", "agg_sum"),
    ("count", "#", "agg_count"),
    ("mean", "∅", "agg_avg"),
    ("minimum", "↓", "agg_min"),
    ("maximum", "↑", "agg_max"),
    ("median", "≈", "agg_median"),
    ("count_distinct", "★", "agg_distinct"),
]

OP_CHOICES: List[str] = ["+", "-", "*", "/", "%", "||", "=", "!=", ">", ">=", "<", "<=", "AND", "OR"]


def _short_agg_symbol(agg: str) -> str:
    low = str(agg or "sum").lower().strip()
    if low == "avg":
        low = "mean"
    for k, sym, _lk in AGG_CHOICES:
        if k == low:
            return sym
    return "Σ"


def _block_accent(kind: str) -> str:
    return {
        "metric": "#10b981",
        "widget_ref": "#a855f7",
        "var": "#06b6d4",
        "if_else": "#38bdf8",
        "pct_share": "#38bdf8",
        "group": "#38bdf8",
        "format": "#0ea5e9",
        "op": "#f59e0b",
        "num": "#94a3b8",
        "str": "#94a3b8",
        "raw": "#64748b",
    }.get(kind, "#38bdf8")


def _block_summary_text(blk: Dict[str, Any], lang: str = "et") -> Tuple[str, str]:
    """Return concise (title, subtitle) for rendering a Lego card block."""
    kind = str(blk.get("kind") or "")
    if kind == "metric":
        sym = _short_agg_symbol(blk.get("agg", "sum"))
        lyr = str(blk.get("layer") or "Layer")
        fld = str(blk.get("field") or "$area")
        if blk.get("agg") == "count":
            fld = tr("lego_rows" if False else "records", lang)
        elif fld in ("$area", "$area_ha", "__calc_area_ha__"):
            fld = "Pindala (ha)" if lang == "et" else "Area (ha)"
        wf = str(blk.get("where_field") or "").strip()
        wv = str(blk.get("where_val") or "").strip()
        wop = str(blk.get("where_op") or "=").strip()
        sub = f"{lyr}"
        if wf and wv != "":
            sub = f"{lyr} [{wf} {wop} {wv}]"
        return f"{sym} {fld}", sub
    if kind == "widget_ref":
        nm = str(blk.get("widget_title") or blk.get("widget_id") or "Widget")
        mode_lbl = "#" if blk.get("mode") == "count" else "Σ"
        return f"📊 {mode_lbl} {nm}", "Vidin" if lang == "et" else "Widget"
    if kind == "var":
        nm = str(blk.get("name") or "$count")
        lbl_map = {
            "$count": ("Kirjete arv", "Row count"),
            "@total_count": ("Koguarv", "Total count"),
            "$area": ("Objekti pindala", "Feature area"),
            "@filter_count": ("Filtrite arv", "Active filters"),
        }
        pair = lbl_map.get(nm.lower())
        sub = (pair[0] if lang == "et" else pair[1]) if pair else ("Muutuja" if lang == "et" else "Variable")
        return f"🏷 {nm}", sub
    if kind == "op":
        op_txt = str(blk.get("op") or "+")
        disp = {"*": "×", "/": "÷", "-": "−", "!=": "≠", ">=": "≥", "<=": "≤"}.get(op_txt, op_txt)
        return disp, ""
    if kind == "num":
        return str(blk.get("value", 0)), "#"
    if kind == "str":
        return f"'{blk.get('value', '')}'", "T"
    if kind == "raw":
        expr_s = str(blk.get("expr") or "")
        return (expr_s[:22] + "…") if len(expr_s) > 23 else expr_s, "fx"
    if kind == "if_else":
        return tr("lego_if_lbl", lang), ""
    if kind == "pct_share":
        return tr("lego_pct_lbl", lang), ""
    if kind == "group":
        return tr("lego_group_lbl", lang), ""
    if kind == "format":
        fmt = str(blk.get("fmt") or "format_ha")
        dec = blk.get("decimals", 1)
        tag = {"format_ha": "ha", "format_pct": "%", "format_number": "#"}.get(fmt, "ha")
        return f"{tr('lego_fmt_lbl', lang)} ({tag}, .{dec})", ""
    return kind, ""


def _read_path(root: List[Dict[str, Any]], path: Tuple[Any, ...]) -> List[Dict[str, Any]]:
    cur: Any = root
    for seg in path:
        if isinstance(seg, int):
            cur = cur[seg]
        else:
            cur = cur.setdefault(seg, [])
    return cur


def _clone_blocks(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return copy.deepcopy(blocks)


def _block_width(blk: Dict[str, Any]) -> int:
    kind = str(blk.get("kind") or "")
    if kind == "op":
        return 42
    if kind in ("num", "str"):
        return max(54, min(140, 26 + len(str(blk.get("value", ""))) * 8))
    if kind == "var":
        return max(108, min(170, 34 + len(str(blk.get("name", ""))) * 7))
    if kind in ("metric", "widget_ref", "raw"):
        return 168
    return 180


class _DraggableTreeWidget(QTreeWidget):
    """Tree palette widget supporting both drag-and-drop Lego blocks and double-click insert."""

    def __init__(self, on_activate_block: Optional[Callable[[Dict[str, Any]], None]] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._on_activate_block = on_activate_block
        if hasattr(self, "setDragEnabled"):
            self.setDragEnabled(True)
        if hasattr(self, "setHeaderHidden"):
            self.setHeaderHidden(True)
        if hasattr(self, "setIndentation"):
            self.setIndentation(14)
        if hasattr(self, "itemDoubleClicked"):
            self.itemDoubleClicked.connect(self._on_double)

    def _on_double(self, item: Any, _col: int = 0) -> None:
        if item is None or not callable(self._on_activate_block):
            return
        payload = item.data(0, qt_enum(Qt, "ItemDataRole", "UserRole"))
        if isinstance(payload, dict) and payload.get("kind"):
            self._on_activate_block(copy.deepcopy(payload))

    def startDrag(self, _actions: Any = None) -> None:
        item = self.currentItem() if hasattr(self, "currentItem") else None
        if item is None or QMimeData is None or QDrag is None:
            return
        payload = item.data(0, qt_enum(Qt, "ItemDataRole", "UserRole"))
        if not isinstance(payload, dict) or not payload.get("kind"):
            return
        mime = QMimeData()
        mime.setData(LEGO_BLOCK_MIME, json.dumps(payload, ensure_ascii=False).encode("utf-8"))
        drag = QDrag(self)
        drag.setMimeData(mime)
        drag.exec(qt_enum(Qt, "DropAction", "CopyAction"))


class _DraggableChipButton(QPushButton):
    """Compact Lego chip button: click appends block; drag snaps block at any slot on canvas."""

    def __init__(
        self,
        label: str,
        block_payload: Dict[str, Any],
        on_click_block: Optional[Callable[[Dict[str, Any]], None]] = None,
        accent: str = "#f59e0b",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(label, parent)
        self._payload = copy.deepcopy(block_payload)
        self._on_click_block = on_click_block
        self._press_pos: Optional[Any] = None
        self._drag_started = False
        self.setStyleSheet(
            f"QPushButton {{ background: #1e293b; color: #f8fafc; border: 1px solid {accent}; "
            f"border-top: 3px solid {accent}; border-radius: 6px; padding: 4px 9px; font-weight: 600; font-size: 11px; }}"
            f"QPushButton:hover {{ background: #334155; }}"
        )
        self.clicked.connect(self._handle_click)

    def _handle_click(self) -> None:
        if self._drag_started:
            self._drag_started = False
            return
        if callable(self._on_click_block):
            self._on_click_block(copy.deepcopy(self._payload))

    def mousePressEvent(self, event: Any) -> None:
        try:
            self._press_pos = event.pos()
            self._drag_started = False
        except Exception:
            self._press_pos = None
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: Any) -> None:
        if self._press_pos is not None and QMimeData is not None and QDrag is not None:
            try:
                cur = event.pos()
                dist = abs(int(cur.x()) - int(self._press_pos.x())) + abs(int(cur.y()) - int(self._press_pos.y()))
                if dist >= 6:
                    self._drag_started = True
                    mime = QMimeData()
                    mime.setData(LEGO_BLOCK_MIME, json.dumps(self._payload, ensure_ascii=False).encode("utf-8"))
                    drag = QDrag(self)
                    drag.setMimeData(mime)
                    drag.exec(qt_enum(Qt, "DropAction", "CopyAction"))
                    self._press_pos = None
                    return
            except Exception:
                pass
        super().mouseMoveEvent(event)


class LegoPaletteWidget(QFrame):
    """Searchable palette exposing ALL dashboard layers, Excel tables, active widgets, and Lego parts."""

    def __init__(
        self,
        dashboard: DashboardConfig,
        sources_info: List[Dict[str, Any]],
        on_add_block: Callable[[Dict[str, Any]], None],
        on_hydrate_needed: Optional[Callable[[], None]] = None,
        lang: str = "et",
        exclude_widget_id: str = "",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.sources_info = list(sources_info or [])
        self.on_add_block = on_add_block
        self.on_hydrate_needed = on_hydrate_needed
        self.lang = lang
        self.exclude_widget_id = exclude_widget_id

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(6)

        self.ed_search = QLineEdit()
        self.ed_search.setPlaceholderText(tr("lego_ph_search", lang))
        self.ed_search.textChanged.connect(lambda _t: self.rebuild())
        lay.addWidget(self.ed_search)

        hdr_src = QHBoxLayout()
        hdr_src.addWidget(QLabel(f"<b>{tr('lego_pal_sources', lang)}</b>"), 1)
        if callable(on_hydrate_needed):
            self.btn_hydrate = QPushButton(tr("lego_hydrate_btn", lang))
            self.btn_hydrate.setProperty("btnRole", "miniStep")
            self.btn_hydrate.clicked.connect(on_hydrate_needed)
            hdr_src.addWidget(self.btn_hydrate)
        lay.addLayout(hdr_src)

        self.tree_sources = _DraggableTreeWidget(on_activate_block=self.on_add_block)
        self.tree_sources.setMinimumHeight(150)
        lay.addWidget(self.tree_sources, 3)

        lay.addWidget(QLabel(f"<b>{tr('lego_pal_widgets', lang)}</b>"))
        self.tree_widgets = _DraggableTreeWidget(on_activate_block=self.on_add_block)
        self.tree_widgets.setMaximumHeight(115)
        lay.addWidget(self.tree_widgets, 2)

        lay.addWidget(QLabel(f"<b>{tr('lego_pal_containers', lang)}</b>"))
        cont_wrap = QWidget()
        cont_row = QHBoxLayout(cont_wrap)
        cont_row.setContentsMargins(0, 0, 0, 0)
        cont_row.setSpacing(4)
        for lbl, payload in (
            (tr("lego_pct_lbl", lang), {"kind": "pct_share", "part": [], "whole": []}),
            (tr("lego_if_lbl", lang), {"kind": "if_else", "cond": [], "then": [], "else": []}),
            (tr("lego_group_lbl", lang), {"kind": "group", "items": []}),
            (f"{tr('lego_fmt_lbl', lang)} (ha)", {"kind": "format", "fmt": "format_ha", "decimals": 1, "inner": []}),
        ):
            cont_row.addWidget(_DraggableChipButton(lbl, payload, on_click_block=self.on_add_block, accent="#38bdf8"))
        lay.addWidget(cont_wrap)

        lay.addWidget(QLabel(f"<b>{tr('lego_pal_ops', lang)}</b>"))
        ops_grid_1 = QHBoxLayout()
        ops_grid_1.setSpacing(4)
        for op_sym, disp in (("+", "+"), ("-", "−"), ("*", "×"), ("/", "÷"), ("%", "%"), ("||", "||")):
            ops_grid_1.addWidget(_DraggableChipButton(disp, {"kind": "op", "op": op_sym}, on_click_block=self.on_add_block, accent="#f59e0b"))
        ops_grid_1.addWidget(_DraggableChipButton("123", {"kind": "num", "value": 100}, on_click_block=self.on_add_block, accent="#94a3b8"))
        ops_grid_1.addWidget(_DraggableChipButton('"abc"', {"kind": "str", "value": "ha"}, on_click_block=self.on_add_block, accent="#94a3b8"))
        lay.addLayout(ops_grid_1)

        ops_grid_2 = QHBoxLayout()
        ops_grid_2.setSpacing(4)
        for op_sym, disp in (("=", "="), ("!=", "≠"), (">", ">"), (">=", "≥"), ("<", "<"), ("<=", "≤"), ("AND", "AND"), ("OR", "OR")):
            ops_grid_2.addWidget(_DraggableChipButton(disp, {"kind": "op", "op": op_sym}, on_click_block=self.on_add_block, accent="#f59e0b"))
        lay.addLayout(ops_grid_2)

        vars_row = QHBoxLayout()
        vars_row.setSpacing(4)
        for vnm, vdisp in (("$count", "# $count"), ("@total_count", "@total"), ("$area", "📐 $area"), ("@filter_count", "🔍 filtrid")):
            vars_row.addWidget(_DraggableChipButton(vdisp, {"kind": "var", "name": vnm}, on_click_block=self.on_add_block, accent="#06b6d4"))
        lay.addLayout(vars_row)

        self.rebuild()

    def set_sources_info(self, sources_info: List[Dict[str, Any]]) -> None:
        self.sources_info = list(sources_info or [])
        self.rebuild()

    def rebuild(self) -> None:
        q = self.ed_search.text().strip().lower()
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        self.tree_sources.clear()
        for src in self.sources_info:
            sname = str(src.get("name") or "")
            stype = str(src.get("source_type") or "layer")
            cnt = int(src.get("row_count") or 0)
            hyd = bool(src.get("hydrated"))
            fields = [str(f) for f in (src.get("fields") or []) if f and not str(f).startswith("_")]
            match_src = not q or q in sname.lower() or any(q in f.lower() for f in fields)
            if not match_src:
                continue
            icon = "📗" if stype in ("excel", "csv", "sharepoint_list") else ("🌐" if stype == "wfs" else "🗂️")
            badge = f" ({cnt:,})" if hyd else " (⏳)"
            top = QTreeWidgetItem([f"{icon} {sname}{badge}"])
            top.setData(0, role, {"kind": "metric", "layer": sname, "field": "__calc_count__" if stype in ("excel", "csv") and not fields else "$area", "agg": "sum" if fields else "count", "where_field": "", "where_op": "=", "where_val": ""})
            self.tree_sources.addTopLevelItem(top)

            if not q or q in "pindala area $area count" or q in sname.lower():
                it_cnt = QTreeWidgetItem([f"#  {tr('agg_count', self.lang).split(' (')[0]} ({sname})"])
                it_cnt.setData(0, role, {"kind": "metric", "layer": sname, "field": "__calc_count__", "agg": "count", "where_field": "", "where_op": "=", "where_val": ""})
                top.addChild(it_cnt)
                if stype not in ("excel", "csv", "sharepoint_list"):
                    it_area = QTreeWidgetItem([f"Σ  {'Pindala (ha)' if self.lang == 'et' else 'Area (ha)'} ($area)"])
                    it_area.setData(0, role, {"kind": "metric", "layer": sname, "field": "$area", "agg": "sum", "where_field": "", "where_op": "=", "where_val": ""})
                    top.addChild(it_area)

            for fn in fields:
                if q and q not in fn.lower() and q not in sname.lower():
                    continue
                it_f = QTreeWidgetItem([f'Σ  "{fn}"'])
                it_f.setData(0, role, {"kind": "metric", "layer": sname, "field": fn, "agg": "sum", "where_field": "", "where_op": "=", "where_val": ""})
                top.addChild(it_f)
            if q and hasattr(top, "setExpanded"):
                top.setExpanded(True)

        self.tree_widgets.clear()
        for w in getattr(self.dashboard, "widgets", []) or []:
            if not w or w.id == self.exclude_widget_id or w.widget_type in ("map", "image"):
                continue
            title = w.title_en if (self.lang == "en" and w.title_en) else w.title
            if q and q not in title.lower() and q not in str(w.layer_name).lower():
                continue
            it_v = QTreeWidgetItem([f"📊 Σ {title} ({w.layer_name or w.widget_type})"])
            it_v.setData(0, role, {"kind": "widget_ref", "widget_id": w.id, "widget_title": title, "mode": "value"})
            self.tree_widgets.addTopLevelItem(it_v)
            it_c = QTreeWidgetItem([f"📊 # {title} ({'arv' if self.lang == 'et' else 'count'})"])
            it_c.setData(0, role, {"kind": "widget_ref", "widget_id": w.id, "widget_title": title, "mode": "count"})
            self.tree_widgets.addTopLevelItem(it_c)


class _ExpressionLegoCanvas(QWidget):
    """QGIS Model-Designer-styled dark dot-grid Lego workspace with snap insertion & nested container slots."""

    def __init__(
        self,
        sources_info: List[Dict[str, Any]],
        dashboard: Optional[DashboardConfig] = None,
        records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        lang: str = "et",
        on_changed: Optional[Callable[[], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.sources_info = list(sources_info or [])
        self.dashboard = dashboard
        self.records_by_layer = records_by_layer or {}
        self.lang = lang
        self.on_changed = on_changed
        self.blocks: List[Dict[str, Any]] = []
        self._undo_stack: List[List[Dict[str, Any]]] = []
        self._preview_text = "= —"
        self._preview_color = "#10b981"

        self._hit_blocks: List[Tuple[Any, Tuple[Any, ...], int, Dict[str, Any]]] = []
        self._drop_zones: List[Dict[str, Any]] = []
        self._selected_key: Optional[Tuple[Tuple[Any, ...], int]] = None
        self._selected_close_rect: Optional[Any] = None
        self._active_drop: Optional[Dict[str, Any]] = None
        self._press_pos: Optional[Any] = None
        self._press_block: Optional[Tuple[Tuple[Any, ...], int, Dict[str, Any]]] = None

        self.setMinimumSize(460, 270)
        if hasattr(self, "setAcceptDrops"):
            self.setAcceptDrops(True)
        if hasattr(self, "setMouseTracking"):
            self.setMouseTracking(True)
        try:
            self.setFocusPolicy(qt_enum(Qt, "FocusPolicy", "StrongFocus"))
        except Exception:
            pass

    def set_sources_and_records(
        self, sources_info: List[Dict[str, Any]], records_by_layer: Dict[str, List[Dict[str, Any]]]
    ) -> None:
        self.sources_info = list(sources_info or [])
        self.records_by_layer = records_by_layer or {}
        self.update()

    def set_preview_state(self, formatted_text: str, accent_hex: str) -> None:
        self._preview_text = f"= {formatted_text}" if formatted_text else "= —"
        self._preview_color = accent_hex or "#10b981"
        self.update()

    def set_blocks(self, blocks: List[Dict[str, Any]], record_undo: bool = False) -> None:
        if record_undo:
            self._push_undo()
        self.blocks = _clone_blocks(blocks or [])
        self._selected_key = None
        self._recompute_layout()
        self.update()

    def get_blocks(self) -> List[Dict[str, Any]]:
        return _clone_blocks(self.blocks)

    def _push_undo(self) -> None:
        self._undo_stack.append(_clone_blocks(self.blocks))
        if len(self._undo_stack) > 30:
            self._undo_stack.pop(0)

    def undo(self) -> None:
        if not self._undo_stack:
            return
        self.blocks = self._undo_stack.pop()
        self._selected_key = None
        self._recompute_layout()
        self.update()
        if callable(self.on_changed):
            self.on_changed()

    def clear_blocks(self) -> None:
        if not self.blocks:
            return
        self._push_undo()
        self.blocks = []
        self._selected_key = None
        self._recompute_layout()
        self.update()
        if callable(self.on_changed):
            self.on_changed()

    def append_block(self, block_dict: Dict[str, Any]) -> None:
        self.insert_block(block_dict, target_path=(), index=len(self.blocks))

    def insert_block(
        self,
        block_dict: Dict[str, Any],
        target_path: Tuple[Any, ...] = (),
        index: Optional[int] = None,
    ) -> None:
        self._push_undo()
        blk = copy.deepcopy(block_dict)
        blk.pop("_move_path", None)
        blk.pop("_move_index", None)
        target_list = _read_path(self.blocks, target_path)
        ins_idx = len(target_list) if index is None else max(0, min(len(target_list), int(index)))
        target_list.insert(ins_idx, blk)
        self._selected_key = (target_path, ins_idx)
        self._recompute_layout()
        self.update()
        if callable(self.on_changed):
            self.on_changed()

    def remove_block_at(self, path: Tuple[Any, ...], idx: int) -> None:
        try:
            target_list = _read_path(self.blocks, path)
            if 0 <= idx < len(target_list):
                self._push_undo()
                target_list.pop(idx)
                self._selected_key = None
                self._recompute_layout()
                self.update()
                if callable(self.on_changed):
                    self.on_changed()
        except Exception:
            pass

    @staticmethod
    def _is_ancestor_path(anc_path: Tuple[Any, ...], anc_idx: int, desc_path: Tuple[Any, ...]) -> bool:
        prefix = anc_path + (anc_idx,)
        return len(desc_path) >= len(prefix) and desc_path[: len(prefix)] == prefix

    def move_block(self, src_path: Tuple[Any, ...], src_idx: int, dst_path: Tuple[Any, ...], dst_idx: int) -> None:
        if self._is_ancestor_path(src_path, src_idx, dst_path):
            return
        src_list = _read_path(self.blocks, src_path)
        if not (0 <= src_idx < len(src_list)):
            return
        self._push_undo()
        blk = src_list.pop(src_idx)
        if src_path == dst_path and src_idx < dst_idx:
            dst_idx = max(0, dst_idx - 1)
        dst_list = _read_path(self.blocks, dst_path)
        ins = max(0, min(len(dst_list), int(dst_idx)))
        dst_list.insert(ins, blk)
        self._selected_key = (dst_path, ins)
        self._recompute_layout()
        self.update()
        if callable(self.on_changed):
            self.on_changed()

    def _measure_sequence(self, seq: List[Dict[str, Any]], max_w: float) -> Tuple[float, float]:
        if not seq:
            return 130.0, 36.0
        gap = 12.0
        cur_w = 0.0
        row_h = 0.0
        total_h = 0.0
        best_w = 0.0
        for blk in seq:
            bw, bh = self._measure_block(blk, max(180.0, max_w - 16.0))
            if cur_w > 0 and cur_w + gap + bw > max_w:
                best_w = max(best_w, cur_w)
                total_h += row_h + 14.0
                cur_w = bw
                row_h = bh
            else:
                cur_w = bw if cur_w == 0 else cur_w + gap + bw
                row_h = max(row_h, bh)
        best_w = max(best_w, cur_w)
        total_h += row_h
        return best_w, total_h

    def _measure_block(self, blk: Dict[str, Any], max_w: float) -> Tuple[float, float]:
        kind = str(blk.get("kind") or "")
        if kind == "if_else":
            w_c, h_c = self._measure_sequence(blk.get("cond") or [], max_w - 92.0)
            w_t, h_t = self._measure_sequence(blk.get("then") or [], max_w - 92.0)
            w_e, h_e = self._measure_sequence(blk.get("else") or [], max_w - 92.0)
            w = max(290.0, min(max_w, max(w_c, w_t, w_e) + 104.0))
            h = 32.0 + h_c + h_t + h_e + 30.0
            return w, h
        if kind == "pct_share":
            w_p, h_p = self._measure_sequence(blk.get("part") or [], max_w - 92.0)
            w_w, h_w = self._measure_sequence(blk.get("whole") or [], max_w - 92.0)
            w = max(270.0, min(max_w, max(w_p, w_w) + 104.0))
            h = 32.0 + h_p + h_w + 22.0
            return w, h
        if kind in ("group", "format"):
            w_i, h_i = self._measure_sequence(blk.get("items" if kind == "group" else "inner") or [], max_w - 40.0)
            w = max(185.0, min(max_w, w_i + 36.0))
            h = 32.0 + h_i + 14.0
            return w, h
        return float(_block_width(blk)), 48.0

    def _recompute_layout(self) -> List[Dict[str, Any]]:
        """Compute visual rects for all blocks & drop slots; returns paint command descriptors."""
        self._hit_blocks = []
        self._drop_zones = []
        paint_cmds: List[Dict[str, Any]] = []
        avail_w = max(420.0, float(self.width() if hasattr(self, "width") else 640) - 44.0)

        def _layout_seq(
            seq: List[Dict[str, Any]],
            path: Tuple[Any, ...],
            start_x: float,
            start_y: float,
            max_seq_w: float,
            wrap_rows: bool = True,
        ) -> Tuple[float, float, float]:
            gap = 14.0
            if not seq:
                empty_r = QRectF(start_x, start_y, max(120.0, min(max_seq_w, 170.0)), 34.0)
                self._drop_zones.append({
                    "path": path,
                    "index": 0,
                    "rect": empty_r,
                    "line_x": start_x + 4.0,
                    "line_y1": start_y + 4.0,
                    "line_y2": start_y + 30.0,
                    "empty_slot": True,
                })
                paint_cmds.append({"kind": "_empty_slot", "rect": empty_r, "path": path})
                return empty_r.right(), start_y + 34.0, start_y + 17.0

            cx = start_x
            cy = start_y
            row_h = 0.0
            last_mid_y = start_y + 24.0
            max_right = start_x
            row_items: List[Tuple[int, float, float, float, float]] = []

            for idx, blk in enumerate(seq):
                bw, bh = self._measure_block(blk, max(180.0, max_seq_w))
                if wrap_rows and idx > 0 and (cx + bw > start_x + max_seq_w):
                    cy += row_h + 16.0
                    cx = start_x
                    row_h = 0.0

                if cx == start_x:
                    self._drop_zones.append({
                        "path": path,
                        "index": idx,
                        "rect": QRectF(max(0.0, cx - 14.0), cy, 16.0, bh),
                        "line_x": cx - 5.0,
                        "line_y1": cy + 2.0,
                        "line_y2": cy + bh - 2.0,
                    })

                bx, by = cx, cy
                brect = QRectF(bx, by, bw, bh)
                paint_cmds.append({"kind": "_block", "blk": blk, "rect": brect, "path": path, "index": idx})
                row_items.append((idx, bx, by, bw, bh))
                last_mid_y = by + min(24.0, bh * 0.5)

                btype = str(blk.get("kind") or "")
                if btype == "if_else":
                    sy = by + 30.0
                    for skey, lbl_key in (("cond", "lego_slot_cond"), ("then", "lego_slot_then"), ("else", "lego_slot_else")):
                        sub_seq = blk.setdefault(skey, [])
                        _sw, sh = self._measure_sequence(sub_seq, bw - 96.0)
                        paint_cmds.append({"kind": "_slot_lbl", "rect": QRectF(bx + 10.0, sy, 66.0, sh), "text": tr(lbl_key, self.lang)})
                        _layout_seq(sub_seq, path + (idx, skey), bx + 80.0, sy, bw - 92.0, wrap_rows=False)
                        sy += sh + 8.0
                elif btype == "pct_share":
                    sy = by + 30.0
                    for skey, lbl_key in (("part", "lego_slot_part"), ("whole", "lego_slot_whole")):
                        sub_seq = blk.setdefault(skey, [])
                        _sw, sh = self._measure_sequence(sub_seq, bw - 96.0)
                        paint_cmds.append({"kind": "_slot_lbl", "rect": QRectF(bx + 10.0, sy, 66.0, sh), "text": tr(lbl_key, self.lang)})
                        _layout_seq(sub_seq, path + (idx, skey), bx + 80.0, sy, bw - 92.0, wrap_rows=False)
                        sy += sh + 8.0
                elif btype in ("group", "format"):
                    skey = "items" if btype == "group" else "inner"
                    sub_seq = blk.setdefault(skey, [])
                    _layout_seq(sub_seq, path + (idx, skey), bx + 14.0, by + 30.0, bw - 28.0, wrap_rows=False)

                self._hit_blocks.append((brect, path, idx, blk))

                self._drop_zones.append({
                    "path": path,
                    "index": idx + 1,
                    "rect": QRectF(bx + bw - 4.0, by, gap + 12.0, bh),
                    "line_x": bx + bw + gap * 0.5,
                    "line_y1": by + 2.0,
                    "line_y2": by + bh - 2.0,
                })

                cx = bx + bw + gap
                max_right = max(max_right, bx + bw)
                row_h = max(row_h, bh)

            # Reverse hit order so nested child blocks match before parent container!
            return max_right, cy + row_h, last_mid_y

        end_r, end_b, last_y = _layout_seq(self.blocks, (), 22.0, 22.0, avail_w, wrap_rows=True)
        # Re-order hit list so innermost containers win on click
        self._hit_blocks.sort(key=lambda it: -len(it[1]))

        res_x = min(max(22.0, end_r + 22.0), max(22.0, avail_w - 150.0))
        res_y = 22.0 if not self.blocks else (end_b + 18.0 if end_r + 175.0 > avail_w else max(22.0, last_y - 24.0))
        paint_cmds.append({"kind": "_result_node", "rect": QRectF(res_x, res_y, 165.0, 48.0), "anchor": QPointF(end_r, last_y)})

        need_h = max(270, int(max(end_b, res_y + 48.0) + 32))
        if hasattr(self, "setMinimumHeight"):
            self.setMinimumHeight(need_h)
        return paint_cmds

    def paintEvent(self, _event: Any) -> None:
        if QPainter is None:
            return
        cmds = self._recompute_layout()
        p = QPainter(self)
        try:
            aa = qt_enum(QPainter, "RenderHint", "Antialiasing")
            if aa is not None:
                p.setRenderHint(aa)
        except Exception:
            pass

        w = int(self.width())
        h = int(self.height())
        p.fillRect(0, 0, w, h, QColor("#0b1220"))

        # Subtle dot grid matching QGIS Model Designer Connection Canvas
        p.setPen(QPen(QColor(148, 163, 184, 38), 1))
        for gx in range(16, w, 24):
            for gy in range(16, h, 24):
                p.drawPoint(gx, gy)

        align_c = qt_enum(Qt, "AlignmentFlag", "AlignCenter")
        align_l = qt_enum(Qt, "AlignmentFlag", "AlignVCenter") | qt_enum(Qt, "AlignmentFlag", "AlignLeft")

        if not self.blocks:
            p.setPen(QPen(QColor("#64748b"), 1))
            p.setFont(QFont("Segoe UI", 10))
            p.drawText(QRectF(24, 90, max(200, w - 48), 44), align_c, tr("lego_drop_here", self.lang))

        # Paint connecting wires between consecutive blocks on the root strip
        root_rects = [c["rect"] for c in cmds if c["kind"] == "_block" and c["path"] == ()]
        for i in range(len(root_rects) - 1):
            r0, r1 = root_rects[i], root_rects[i + 1]
            if abs(r0.top() - r1.top()) <= 20:
                p0 = QPointF(r0.right(), r0.top() + 24.0)
                p1 = QPointF(r1.left(), r1.top() + 24.0)
                p.setPen(QPen(QColor("#38bdf8"), 2.0))
                p.drawLine(p0, p1)

        self._selected_close_rect = None
        for cmd in cmds:
            ck = cmd["kind"]
            r = cmd["rect"]
            if ck == "_empty_slot":
                pen = QPen(QColor("#475569"), 1.5)
                dash_st = qt_enum(Qt, "PenStyle", "DashLine")
                if dash_st is not None:
                    pen.setStyle(dash_st)
                p.setPen(pen)
                p.setBrush(QBrush(QColor(15, 23, 42, 110)))
                p.drawRoundedRect(r, 6, 6)
                p.setPen(QPen(QColor("#64748b"), 1))
                p.setFont(QFont("Segoe UI", 8))
                p.drawText(r, align_c, "+")
            elif ck == "_slot_lbl":
                p.setPen(QPen(QColor("#94a3b8"), 1))
                p.setFont(QFont("Segoe UI", 8))
                p.drawText(r, align_l, cmd["text"])
            elif ck == "_block":
                blk = cmd["blk"]
                btype = str(blk.get("kind") or "")
                is_sel = self._selected_key == (cmd["path"], cmd["index"])
                acc = QColor("#f43f5e" if is_sel else _block_accent(btype))
                p.setBrush(QBrush(QColor(19, 31, 52, 220) if btype in ("if_else", "pct_share", "group", "format") else QColor("#1e293b")))
                p.setPen(QPen(acc, 2.2 if is_sel else 1.6))
                p.drawRoundedRect(r, 8, 8)
                p.setBrush(QBrush(acc))
                p.setPen(QPen(acc, 1))
                p.drawRoundedRect(QRectF(r.left(), r.top(), r.width(), 5.0), 3, 3)

                title_txt, sub_txt = _block_summary_text(blk, self.lang)
                if btype == "op":
                    p.setPen(QPen(QColor("#fbbf24"), 1))
                    p.setFont(QFont("Segoe UI", 12, 700))
                    p.drawText(r, align_c, title_txt)
                else:
                    p.setPen(QPen(QColor("#f8fafc"), 1))
                    p.setFont(QFont("Segoe UI", 9, 700))
                    max_c = 28 if r.width() > 210 else 21
                    lbl_t = (title_txt[: max_c - 1] + "…") if len(title_txt) > max_c else title_txt
                    p.drawText(QRectF(r.left() + 9.0, r.top() + 7.0, r.width() - 28.0, 19.0), align_l, lbl_t)
                    if sub_txt:
                        p.setPen(QPen(QColor("#94a3b8"), 1))
                        p.setFont(QFont("Segoe UI", 8))
                        lbl_s = (sub_txt[:22] + "…") if len(sub_txt) > 23 else sub_txt
                        p.drawText(QRectF(r.left() + 9.0, r.top() + 26.0, r.width() - 18.0, 17.0), align_l, lbl_s)

                if is_sel:
                    cr = QRectF(r.right() - 19.0, r.top() + 6.0, 14.0, 14.0)
                    self._selected_close_rect = cr
                    p.setBrush(QBrush(QColor("#ef4444")))
                    p.setPen(QPen(QColor("#ffffff"), 1))
                    p.drawEllipse(cr)
                    p.setFont(QFont("Segoe UI", 8, 700))
                    p.drawText(cr, align_c, "×")
            elif ck == "_result_node":
                anchor = cmd["anchor"]
                if self.blocks and abs(r.left() - anchor.x()) > 10 and abs(r.top() - anchor.y()) < 60:
                    if QPainterPath is not None:
                        p0 = QPointF(anchor.x(), anchor.y())
                        p1 = QPointF(r.left(), r.top() + 24.0)
                        dx = max(14.0, abs(p1.x() - p0.x()) * 0.45)
                        path = QPainterPath(p0)
                        path.cubicTo(QPointF(p0.x() + dx, p0.y()), QPointF(p1.x() - dx, p1.y()), p1)
                        p.setPen(QPen(QColor(self._preview_color), 2.0))
                        p.setBrush(qt_enum(Qt, "BrushStyle", "NoBrush"))
                        p.drawPath(path)
                res_col = QColor(self._preview_color)
                p.setBrush(QBrush(QColor("#0f172a")))
                p.setPen(QPen(res_col, 2.0))
                p.drawRoundedRect(r, 8, 8)
                p.setBrush(QBrush(res_col))
                p.setPen(QPen(res_col, 1))
                p.drawRoundedRect(QRectF(r.left(), r.top(), r.width(), 5.0), 3, 3)
                p.setPen(QPen(QColor("#94a3b8"), 1))
                p.setFont(QFont("Segoe UI", 8))
                p.drawText(QRectF(r.left() + 8, r.top() + 6, r.width() - 16, 15), align_l, tr("lego_result_node", self.lang))
                p.setPen(QPen(QColor("#f8fafc"), 1))
                p.setFont(QFont("Segoe UI", 10, 700))
                ptxt = (self._preview_text[:20] + "…") if len(self._preview_text) > 21 else self._preview_text
                p.drawText(QRectF(r.left() + 8, r.top() + 23, r.width() - 16, 20), align_l, ptxt)

        if self._active_drop is not None:
            dz = self._active_drop
            p.setPen(QPen(QColor("#38bdf8"), 3.0))
            if dz.get("empty_slot"):
                p.setBrush(QBrush(QColor(56, 189, 248, 35)))
                p.drawRoundedRect(dz["rect"], 6, 6)
            else:
                p.drawLine(QPointF(dz["line_x"], dz["line_y1"]), QPointF(dz["line_x"], dz["line_y2"]))
        p.end()

    def _find_drop_target(self, pt: Any) -> Dict[str, Any]:
        px = float(pt.x()) if hasattr(pt, "x") else float(pt[0])
        py = float(pt.y()) if hasattr(pt, "y") else float(pt[1])
        # Prefer container empty slots when pointer is directly inside them
        for dz in self._drop_zones:
            if dz.get("empty_slot") and dz["rect"].contains(QPointF(px, py)):
                return dz
        best = None
        best_dist = 1e12
        for dz in self._drop_zones:
            r = dz["rect"]
            cx = r.center().x()
            cy = r.center().y()
            d = (cx - px) ** 2 + (cy - py) ** 2
            if dz.get("empty_slot"):
                d *= 0.85
            if d < best_dist:
                best_dist = d
                best = dz
        if best is not None:
            return best
        return {"path": (), "index": len(self.blocks), "rect": QRectF(20, 20, 120, 34), "line_x": 22, "line_y1": 22, "line_y2": 56}

    def _event_pos(self, event: Any) -> Any:
        try:
            if hasattr(event, "position"):
                return event.position()
            if hasattr(event, "pos"):
                p = event.pos()
                return QPointF(p.x(), p.y())
        except Exception:
            pass
        return QPointF(0, 0)

    def dragEnterEvent(self, event: Any) -> None:
        md = event.mimeData() if hasattr(event, "mimeData") else None
        if md is not None and md.hasFormat(LEGO_BLOCK_MIME):
            event.acceptProposedAction()
            return
        event.ignore()

    def dragMoveEvent(self, event: Any) -> None:
        md = event.mimeData() if hasattr(event, "mimeData") else None
        if md is not None and md.hasFormat(LEGO_BLOCK_MIME):
            self._recompute_layout()
            self._active_drop = self._find_drop_target(self._event_pos(event))
            self.update()
            event.acceptProposedAction()
            return
        event.ignore()

    def dragLeaveEvent(self, _event: Any) -> None:
        self._active_drop = None
        self.update()

    def dropEvent(self, event: Any) -> None:
        self._active_drop = None
        md = event.mimeData() if hasattr(event, "mimeData") else None
        if md is None or not md.hasFormat(LEGO_BLOCK_MIME):
            event.ignore()
            return
        try:
            raw = bytes(md.data(LEGO_BLOCK_MIME)).decode("utf-8")
            payload = json.loads(raw)
        except Exception:
            event.ignore()
            return
        self._recompute_layout()
        dz = self._find_drop_target(self._event_pos(event))
        t_path = tuple(dz["path"])
        t_idx = int(dz["index"])
        if "_move_path" in payload and "_move_index" in payload:
            self.move_block(tuple(payload["_move_path"]), int(payload["_move_index"]), t_path, t_idx)
        else:
            self.insert_block(payload, target_path=t_path, index=t_idx)
        event.acceptProposedAction()

    def _hit_block_at(self, pt: Any) -> Optional[Tuple[Tuple[Any, ...], int, Dict[str, Any]]]:
        for brect, path, idx, blk in self._hit_blocks:
            if brect.contains(pt):
                return path, idx, blk
        return None

    def mousePressEvent(self, event: Any) -> None:
        pt = self._event_pos(event)
        if self._selected_key and self._selected_close_rect is not None and self._selected_close_rect.contains(pt):
            self.remove_block_at(self._selected_key[0], self._selected_key[1])
            return
        hit = self._hit_block_at(pt)
        self._press_pos = pt
        self._press_block = hit
        if hit:
            self._selected_key = (hit[0], hit[1])
        else:
            self._selected_key = None
        self.update()

    def mouseMoveEvent(self, event: Any) -> None:
        if self._press_pos is not None and self._press_block is not None and QMimeData is not None and QDrag is not None:
            pt = self._event_pos(event)
            dist = abs(float(pt.x()) - float(self._press_pos.x())) + abs(float(pt.y()) - float(self._press_pos.y()))
            if dist >= 7.0:
                path, idx, blk = self._press_block
                self._press_pos = None
                self._press_block = None
                payload = copy.deepcopy(blk)
                payload["_move_path"] = list(path)
                payload["_move_index"] = idx
                mime = QMimeData()
                mime.setData(LEGO_BLOCK_MIME, json.dumps(payload, ensure_ascii=False).encode("utf-8"))
                drag = QDrag(self)
                drag.setMimeData(mime)
                drag.exec(qt_enum(Qt, "DropAction", "MoveAction"))

    def mouseReleaseEvent(self, _event: Any) -> None:
        self._press_pos = None
        self._press_block = None

    def mouseDoubleClickEvent(self, event: Any) -> None:
        hit = self._hit_block_at(self._event_pos(event))
        if hit:
            self._edit_block(hit[0], hit[1], hit[2])

    def keyPressEvent(self, event: Any) -> None:
        try:
            del_k = qt_enum(Qt, "Key", "Key_Delete")
            bk_k = qt_enum(Qt, "Key", "Key_Backspace")
            if event.key() in (del_k, bk_k) and self._selected_key is not None:
                self.remove_block_at(self._selected_key[0], self._selected_key[1])
                event.accept()
                return
        except Exception:
            pass
        super().keyPressEvent(event)

    def contextMenuEvent(self, event: Any) -> None:
        if QMenu is None:
            return
        pt = QPointF(event.pos().x(), event.pos().y())
        hit = self._hit_block_at(pt)
        if not hit:
            return
        path, idx, blk = hit
        menu = QMenu(self)
        act_edit = menu.addAction("✏️  " + ("Muuda plokki..." if self.lang == "et" else "Edit block..."))
        act_wrap = menu.addAction("( ) " + ("Pane sulgudesse" if self.lang == "et" else "Wrap in Group"))
        act_dup = menu.addAction("⧉  " + ("Dubleeri" if self.lang == "et" else "Duplicate"))
        act_rm = menu.addAction(tr("ctx_remove", self.lang))
        chosen = exec_menu(menu, event.globalPos())
        if chosen == act_edit:
            self._edit_block(path, idx, blk)
        elif chosen == act_wrap:
            self._push_undo()
            lst = _read_path(self.blocks, path)
            lst[idx] = {"kind": "group", "items": [copy.deepcopy(blk)]}
            self._recompute_layout()
            self.update()
            if callable(self.on_changed):
                self.on_changed()
        elif chosen == act_dup:
            self.insert_block(blk, target_path=path, index=idx + 1)
        elif chosen == act_rm:
            self.remove_block_at(path, idx)

    def _edit_block(self, path: Tuple[Any, ...], idx: int, blk: Dict[str, Any]) -> None:
        kind = str(blk.get("kind") or "")
        if kind in ("num", "str", "raw") and QInputDialog is not None:
            cur = str(blk.get("expr" if kind == "raw" else "value", ""))
            lbl = "Arv:" if kind == "num" else ("Tekst:" if kind == "str" else "Avaldis:")
            txt, ok = QInputDialog.getText(self, tr("ctx_edit_settings", self.lang), lbl, text=cur)
            if not ok:
                return
            self._push_undo()
            lst = _read_path(self.blocks, path)
            if kind == "num":
                try:
                    num = float(txt.replace(",", ".").strip() or 0)
                    lst[idx]["value"] = int(num) if num.is_integer() else num
                except ValueError:
                    return
            elif kind == "str":
                lst[idx]["value"] = txt
            else:
                lst[idx]["expr"] = txt
            self._recompute_layout()
            self.update()
            if callable(self.on_changed):
                self.on_changed()
            return

        if kind == "op" and QInputDialog is not None:
            cur_op = str(blk.get("op") or "+")
            pos = OP_CHOICES.index(cur_op) if cur_op in OP_CHOICES else 0
            chosen_op, ok = QInputDialog.getItem(self, tr("ctx_edit_settings", self.lang), "Operaator:", OP_CHOICES, pos, False)
            if ok and chosen_op:
                self._push_undo()
                _read_path(self.blocks, path)[idx]["op"] = chosen_op
                self.update()
                if callable(self.on_changed):
                    self.on_changed()
            return

        if kind in ("metric", "format", "widget_ref"):
            dlg = _BlockDetailDialog(blk, self.sources_info, self.dashboard, self.records_by_layer, lang=self.lang, parent=self)
            if exec_dialog(dlg):
                self._push_undo()
                _read_path(self.blocks, path)[idx] = dlg.result_block
                self._recompute_layout()
                self.update()
                if callable(self.on_changed):
                    self.on_changed()


class _BlockDetailDialog(QDialog):
    """Focused inline editor for Metric, Format, or Widget Reference Lego blocks."""

    def __init__(
        self,
        block: Dict[str, Any],
        sources_info: List[Dict[str, Any]],
        dashboard: Optional[DashboardConfig] = None,
        records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.result_block = copy.deepcopy(block)
        self.sources_info = sources_info
        self.dashboard = dashboard
        self.records_by_layer = records_by_layer or {}
        self.lang = lang
        kind = str(block.get("kind") or "")
        self.setWindowTitle(tr("ctx_edit_settings", lang))
        self.setMinimumWidth(360)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        lay = QVBoxLayout(self)
        form = QFormLayout()

        if kind == "metric":
            self.cb_layer = QComboBox()
            for s in sources_info:
                self.cb_layer.addItem(s["name"], s["name"])
            if block.get("layer") and self.cb_layer.findData(block["layer"]) < 0:
                self.cb_layer.addItem(str(block["layer"]), str(block["layer"]))
            idx_l = self.cb_layer.findData(block.get("layer") or "")
            if idx_l >= 0:
                self.cb_layer.setCurrentIndex(idx_l)

            self.cb_agg = QComboBox()
            for ak, asym, alk in AGG_CHOICES:
                self.cb_agg.addItem(f"{asym} {tr(alk, lang)}", ak)
            idx_a = self.cb_agg.findData("mean" if block.get("agg") == "avg" else (block.get("agg") or "sum"))
            if idx_a >= 0:
                self.cb_agg.setCurrentIndex(idx_a)

            self.cb_field = QComboBox()
            self.cb_field.setEditable(True)
            self.cb_where_field = QComboBox()
            self.cb_where_field.setEditable(True)
            self.cb_where_op = QComboBox()
            for op in ("=", "!=", ">", ">=", "<", "<="):
                self.cb_where_op.addItem(op, op)
            idx_wop = self.cb_where_op.findData(block.get("where_op") or "=")
            if idx_wop >= 0:
                self.cb_where_op.setCurrentIndex(idx_wop)

            self.cb_where_val = QComboBox()
            self.cb_where_val.setEditable(True)

            form.addRow(tr("lbl_w_layer", lang), self.cb_layer)
            form.addRow(tr("lbl_w_agg", lang), self.cb_agg)
            form.addRow(tr("lbl_w_val_field", lang), self.cb_field)
            form.addRow("Filter (WHERE väli):" if lang == "et" else "Filter (WHERE field):", self.cb_where_field)
            form.addRow("Filter (tingimus):" if lang == "et" else "Filter (operator):", self.cb_where_op)
            form.addRow("Filter (väärtus):" if lang == "et" else "Filter (value):", self.cb_where_val)

            self.cb_layer.currentIndexChanged.connect(lambda _i: self._populate_layer_fields())
            self.cb_where_field.currentTextChanged.connect(lambda _t: self._populate_where_values())
            self._populate_layer_fields()
            self.cb_field.setCurrentText(str(block.get("field") or "$area"))
            self.cb_where_field.setCurrentText(str(block.get("where_field") or ""))
            self._populate_where_values()
            self.cb_where_val.setCurrentText(str(block.get("where_val") or ""))
        elif kind == "format":
            self.cb_fmt = QComboBox()
            for fk, fl in (("format_ha", "Hektarid (format_ha)"), ("format_pct", "Protsent (format_pct)"), ("format_number", "Arv (format_number)")):
                self.cb_fmt.addItem(fl, fk)
            idx_f = self.cb_fmt.findData(block.get("fmt") or "format_ha")
            if idx_f >= 0:
                self.cb_fmt.setCurrentIndex(idx_f)
            self.sp_dec = QSpinBox()
            self.sp_dec.setRange(0, 6)
            self.sp_dec.setValue(int(block.get("decimals", 1) if block.get("decimals") is not None else 1))
            form.addRow("Vorming:", self.cb_fmt)
            form.addRow("Komakohad:" if lang == "et" else "Decimals:", self.sp_dec)
        elif kind == "widget_ref":
            self.cb_wref = QComboBox()
            for w in getattr(dashboard, "widgets", []) or []:
                if w.widget_type not in ("map", "image"):
                    self.cb_wref.addItem(f"{w.title} ({w.id})", w.id)
            idx_w = self.cb_wref.findData(block.get("widget_id") or "")
            if idx_w >= 0:
                self.cb_wref.setCurrentIndex(idx_w)
            self.cb_wmode = QComboBox()
            self.cb_wmode.addItem("Väärtus (widget)" if lang == "et" else "Metric Value (widget)", "value")
            self.cb_wmode.addItem("Ridade arv (widget_count)" if lang == "et" else "Filtered Row Count", "count")
            idx_m = self.cb_wmode.findData(block.get("mode") or "value")
            if idx_m >= 0:
                self.cb_wmode.setCurrentIndex(idx_m)
            form.addRow("Vidin:" if lang == "et" else "Widget:", self.cb_wref)
            form.addRow("Režiim:" if lang == "et" else "Mode:", self.cb_wmode)

        lay.addLayout(form)
        btns = QHBoxLayout()
        btns.addStretch()
        b_can = QPushButton(tr("btn_cancel", lang))
        b_can.clicked.connect(self.reject)
        b_ok = QPushButton(tr("btn_save", lang))
        b_ok.setProperty("btnRole", "primary")
        b_ok.clicked.connect(self._save_and_accept)
        btns.addWidget(b_can)
        btns.addWidget(b_ok)
        lay.addLayout(btns)

    def _populate_layer_fields(self) -> None:
        lname = str(self.cb_layer.currentData() or self.cb_layer.currentText() or "")
        src = next((s for s in self.sources_info if s["name"] == lname), {})
        fields = [f for f in (src.get("fields") or []) if f and not str(f).startswith("_")]
        self.cb_field.blockSignals(True)
        self.cb_field.clear()
        self.cb_field.addItem("$area")
        self.cb_field.addItem("__calc_count__")
        for f in fields:
            self.cb_field.addItem(f)
        self.cb_field.blockSignals(False)

        self.cb_where_field.blockSignals(True)
        self.cb_where_field.clear()
        self.cb_where_field.addItem("")
        for f in fields:
            self.cb_where_field.addItem(f)
        self.cb_where_field.blockSignals(False)

    def _populate_where_values(self) -> None:
        lname = str(self.cb_layer.currentData() or self.cb_layer.currentText() or "")
        wf = self.cb_where_field.currentText().strip()
        self.cb_where_val.blockSignals(True)
        self.cb_where_val.clear()
        self.cb_where_val.addItem("")
        if lname and wf and lname in self.records_by_layer:
            seen: List[str] = []
            seen_s = set()
            for r in (self.records_by_layer.get(lname) or [])[:3000]:
                v = r.get(wf)
                if v is not None and str(v).strip() != "":
                    sv = str(v)
                    if sv not in seen_s:
                        seen_s.add(sv)
                        seen.append(sv)
                        if len(seen) >= 40:
                            break
            for sv in sorted(seen):
                self.cb_where_val.addItem(sv)
        self.cb_where_val.blockSignals(False)

    def _save_and_accept(self) -> None:
        kind = str(self.result_block.get("kind") or "")
        if kind == "metric":
            self.result_block["layer"] = str(self.cb_layer.currentData() or self.cb_layer.currentText() or "")
            self.result_block["agg"] = str(self.cb_agg.currentData() or "sum")
            self.result_block["field"] = self.cb_field.currentText().strip() or "$area"
            self.result_block["where_field"] = self.cb_where_field.currentText().strip()
            self.result_block["where_op"] = str(self.cb_where_op.currentData() or "=")
            self.result_block["where_val"] = self.cb_where_val.currentText().strip()
        elif kind == "format":
            self.result_block["fmt"] = str(self.cb_fmt.currentData() or "format_ha")
            self.result_block["decimals"] = int(self.sp_dec.value())
        elif kind == "widget_ref":
            wid = str(self.cb_wref.currentData() or "")
            self.result_block["widget_id"] = wid
            self.result_block["widget_title"] = self.cb_wref.currentText().split(" (")[0]
            self.result_block["mode"] = str(self.cb_wmode.currentData() or "value")
        self.accept()


class ExpressionDesignerDialog(QDialog):
    """
    Connection-Dialog-style Expression Builder combining Visual Lego Blocks across all dashboard
    layers/Excel tables/active widgets with seamless Advanced Formula editing & conditional styling.
    """

    def __init__(
        self,
        widget_cfg: WidgetConfig,
        dashboard: DashboardConfig,
        persistence: Any = None,
        filter_bus: Any = None,
        on_hydrate_layers: Optional[Callable[[List[str]], None]] = None,
        on_switch_type: Optional[Callable[[], None]] = None,
        lang: str = "et",
        records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.widget_cfg = widget_cfg
        self.dashboard = dashboard
        self.persistence = persistence
        self.filter_bus = filter_bus
        self.on_hydrate_layers = on_hydrate_layers
        self.on_switch_type = on_switch_type
        self.lang = lang
        self._extra_records_by_layer = records_by_layer or {}
        self._mode = "visual"
        self._selected_color = str(getattr(widget_cfg, "primary_color", "") or "#34d399")
        self._syncing_text = False

        self.setWindowTitle(tr("dlg_lego_expr_title", lang))
        try:
            self.setMinimumSize(640, 460)
            self.resize(980, 700)
        except Exception:
            pass
        self.setStyleSheet(ThemeManager.get_stylesheet())

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(8)

        # 1. Top configuration bar (Title, Display Style, Decimals/Suffix, Target & Threshold Rules)
        hdr_frame = QFrame()
        hdr_v = QVBoxLayout(hdr_frame)
        hdr_v.setContentsMargins(6, 4, 6, 4)
        hdr_v.setSpacing(6)

        row1 = QHBoxLayout()
        row1.setSpacing(6)
        self.ed_title_et = QLineEdit(str(getattr(widget_cfg, "title", "") or ("Avaldisvidin" if lang == "et" else "Expression Card")))
        self.ed_title_et.setPlaceholderText(tr("lbl_w_title_et", lang))
        self.cb_display = QComboBox()
        for dk, lk in (("auto", "expr_disp_auto"), ("metric", "expr_disp_metric"), ("progress", "expr_disp_progress"), ("text", "expr_disp_text")):
            self.cb_display.addItem(tr(lk, lang), dk)
        idx_d = self.cb_display.findData(getattr(widget_cfg, "expression_display", "auto") or "auto")
        if idx_d >= 0:
            self.cb_display.setCurrentIndex(idx_d)

        self.sp_decimals = QSpinBox()
        self.sp_decimals.setRange(0, 6)
        self.sp_decimals.setValue(int(widget_cfg.decimals if widget_cfg.decimals is not None else 1))
        self.ed_prefix = QLineEdit(str(getattr(widget_cfg, "prefix", "") or ""))
        self.ed_prefix.setPlaceholderText("Eesliide" if lang == "et" else "Prefix")
        self.ed_prefix.setMaximumWidth(75)
        self.ed_suffix = QLineEdit(str(getattr(widget_cfg, "suffix", "") or ""))
        self.ed_suffix.setPlaceholderText("nt ha, %" if lang == "et" else "e.g. ha, %")
        self.ed_suffix.setMaximumWidth(80)
        self.ed_target = QLineEdit("" if getattr(widget_cfg, "target_value", None) is None else str(widget_cfg.target_value))
        self.ed_target.setPlaceholderText(tr("lbl_w_target", lang))
        self.ed_target.setMaximumWidth(120)

        row1.addWidget(QLabel(f"<b>{tr('lbl_w_title_et', lang)}</b>"))
        row1.addWidget(self.ed_title_et, 2)
        row1.addWidget(QLabel(tr("lbl_expr_display", lang)))
        row1.addWidget(self.cb_display, 1)
        row1.addWidget(QLabel("." if lang == "et" else "Dec"))
        row1.addWidget(self.sp_decimals)
        row1.addWidget(self.ed_prefix)
        row1.addWidget(self.ed_suffix)
        row1.addWidget(self.ed_target)
        hdr_v.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(6)
        self.cb_color_mode = QComboBox()
        for ck, lk in (("fixed", "lego_color_fixed"), ("target_pct", "lego_color_target"), ("rules", "lego_color_rules")):
            self.cb_color_mode.addItem(tr(lk, lang), ck)
        idx_cm = self.cb_color_mode.findData(getattr(widget_cfg, "expression_color_mode", "fixed") or "fixed")
        if idx_cm >= 0:
            self.cb_color_mode.setCurrentIndex(idx_cm)
        self.cb_color_mode.currentIndexChanged.connect(self._sync_threshold_visibility)

        self.btn_color = QPushButton(tr("lbl_w_color", lang))
        self.lbl_color_swatch = QLabel("  ")
        self.lbl_color_swatch.setFixedSize(22, 18)
        self._update_swatch()
        self.btn_color.clicked.connect(self._pick_color)

        self.lbl_thr_ok = QLabel(tr("lego_thr_ok", lang))
        self.ed_thr_ok = QLineEdit("" if getattr(widget_cfg, "expression_threshold_ok", None) is None else str(widget_cfg.expression_threshold_ok))
        self.ed_thr_ok.setMaximumWidth(75)
        self.lbl_thr_warn = QLabel(tr("lego_thr_warn", lang))
        self.ed_thr_warn = QLineEdit("" if getattr(widget_cfg, "expression_threshold_warn", None) is None else str(widget_cfg.expression_threshold_warn))
        self.ed_thr_warn.setMaximumWidth(75)

        self.btn_mode_visual = QPushButton(tr("lego_mode_visual", lang))
        self.btn_mode_visual.setCheckable(True)
        self.btn_mode_visual.setChecked(True)
        self.btn_mode_adv = QPushButton(tr("lego_mode_advanced", lang))
        self.btn_mode_adv.setCheckable(True)
        self.btn_mode_visual.clicked.connect(lambda: self._switch_mode("visual"))
        self.btn_mode_adv.clicked.connect(lambda: self._switch_mode("advanced"))

        row2.addWidget(QLabel(tr("lego_color_mode", lang)))
        row2.addWidget(self.cb_color_mode)
        row2.addWidget(self.btn_color)
        row2.addWidget(self.lbl_color_swatch)
        row2.addWidget(self.lbl_thr_ok)
        row2.addWidget(self.ed_thr_ok)
        row2.addWidget(self.lbl_thr_warn)
        row2.addWidget(self.ed_thr_warn)
        row2.addStretch()
        if callable(on_switch_type):
            btn_sw = QPushButton(tr("lego_convert_type_link", lang))
            btn_sw.setProperty("btnRole", "miniStep")
            btn_sw.clicked.connect(lambda: (self.reject(), on_switch_type()))
            row2.addWidget(btn_sw)
        row2.addWidget(self.btn_mode_visual)
        row2.addWidget(self.btn_mode_adv)
        hdr_v.addLayout(row2)
        root.addWidget(hdr_frame)

        # 2. Main Splitter: Left Lego Palette <-> Right Visual Lego Canvas / Advanced Stack
        splitter = QSplitter(qt_enum(Qt, "Orientation", "Horizontal"))
        sources_info = self._gather_sources_info()
        records_map = self._gather_records_map()

        self.palette = LegoPaletteWidget(
            dashboard=dashboard,
            sources_info=sources_info,
            on_add_block=self._on_palette_block_clicked,
            on_hydrate_needed=self._hydrate_missing_sources,
            lang=lang,
            exclude_widget_id=widget_cfg.id,
        )
        splitter.addWidget(self.palette)

        right_panel = QFrame()
        rp_lay = QVBoxLayout(right_panel)
        rp_lay.setContentsMargins(0, 0, 0, 0)
        rp_lay.setSpacing(6)

        self.mode_stack = QStackedWidget()

        # Stack Page 0: Visual Lego Canvas (Dark Dot-Grid Connection Style)
        vis_page = QFrame()
        vis_lay = QVBoxLayout(vis_page)
        vis_lay.setContentsMargins(0, 0, 0, 0)
        vis_lay.setSpacing(6)

        vis_bar = QHBoxLayout()
        vis_hint = QLabel(tr("lego_canvas_hint", lang))
        vis_hint.setWordWrap(True)
        vis_hint.setProperty("role", "mutedTiny")
        btn_undo = QPushButton(tr("lego_undo", lang))
        btn_undo.setProperty("btnRole", "miniStep")
        btn_clr = QPushButton(tr("lego_clear", lang))
        btn_clr.setProperty("btnRole", "miniStep")
        btn_tpl = QPushButton("⚡ " + tr("lbl_expr_templates", lang))
        btn_tpl.setProperty("btnRole", "chip")
        btn_tpl.clicked.connect(self._open_templates_menu)

        vis_bar.addWidget(vis_hint, 1)
        vis_bar.addWidget(btn_tpl)
        vis_bar.addWidget(btn_undo)
        vis_bar.addWidget(btn_clr)
        vis_lay.addLayout(vis_bar)

        self.lego_canvas = _ExpressionLegoCanvas(
            sources_info=sources_info,
            dashboard=dashboard,
            records_by_layer=records_map,
            lang=lang,
            on_changed=self._on_canvas_blocks_changed,
        )
        btn_undo.clicked.connect(self.lego_canvas.undo)
        btn_clr.clicked.connect(self.lego_canvas.clear_blocks)

        canvas_scroll = QScrollArea()
        canvas_scroll.setWidgetResizable(True)
        canvas_scroll.setWidget(self.lego_canvas)
        vis_lay.addWidget(canvas_scroll, 1)

        self.lbl_generated_formula = QLabel("fx: —")
        self.lbl_generated_formula.setWordWrap(True)
        self.lbl_generated_formula.setStyleSheet(
            "background: #0f172a; color: #94a3b8; border: 1px solid #334155; "
            "border-radius: 5px; padding: 4px 8px; font-family: Consolas, monospace; font-size: 11px;"
        )
        vis_lay.addWidget(self.lbl_generated_formula)
        self.mode_stack.addWidget(vis_page)

        # Stack Page 1: Advanced QGIS Formula Editor
        adv_page = QFrame()
        adv_lay = QVBoxLayout(adv_page)
        adv_lay.setContentsMargins(0, 0, 0, 0)
        adv_lay.setSpacing(6)
        self.ed_expr = QPlainTextEdit(str(getattr(widget_cfg, "expression", "") or ""))
        if hasattr(self.ed_expr, "setPlaceholderText"):
            self.ed_expr.setPlaceholderText("layer_sum('PRIA Pärandniidud', 'area_ha') / layer_sum('Natura elupaigad', 'area_ha') * 100")
        adv_lay.addWidget(self.ed_expr, 2)

        self.lbl_adv_notice = QLabel("")
        self.lbl_adv_notice.setWordWrap(True)
        self.lbl_adv_notice.setStyleSheet("font-size: 11px; color: #fbbf24;")
        self.lbl_adv_notice.hide()
        adv_lay.addWidget(self.lbl_adv_notice)

        self.list_adv_helpers = QListWidget()
        self.list_adv_helpers.setMaximumHeight(150)
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for meta in EXPRESSION_HELPERS:
            desc = meta["desc_en" if lang == "en" else "desc_et"]
            it = QListWidgetItem(f"fx {meta['sig']} — {desc[:75]}")
            it.setData(role, meta["snippet"])
            self.list_adv_helpers.addItem(it)
        self.list_adv_helpers.itemDoubleClicked.connect(self._insert_adv_helper)
        adv_lay.addWidget(self.list_adv_helpers, 1)
        self.mode_stack.addWidget(adv_page)

        rp_lay.addWidget(self.mode_stack, 1)

        # Subtext + Live Result Footer
        sub_row = QHBoxLayout()
        sub_row.addWidget(QLabel(tr("lbl_expr_subtext", lang)))
        self.ed_subtext = QLineEdit(str(getattr(widget_cfg, "expression_subtext", "") or ""))
        self.ed_subtext.setPlaceholderText("format_number($count, 0) || ' kirjet'")
        sub_row.addWidget(self.ed_subtext, 1)
        rp_lay.addLayout(sub_row)

        self.lbl_live_preview = QLabel("")
        self.lbl_live_preview.setWordWrap(True)
        self.lbl_live_preview.setStyleSheet(
            "background: rgba(15, 23, 42, 0.72); border: 1px solid #334155; "
            "border-radius: 6px; padding: 6px 10px; font-size: 12px;"
        )
        rp_lay.addWidget(self.lbl_live_preview)
        splitter.addWidget(right_panel)
        splitter.setSizes([310, 650])
        root.addWidget(splitter, 1)

        footer = QHBoxLayout()
        footer.addStretch()
        b_cancel = QPushButton(tr("btn_cancel", lang))
        b_cancel.clicked.connect(self.reject)
        b_save = QPushButton(tr("btn_save", lang))
        b_save.setProperty("btnRole", "primary")
        b_save.clicked.connect(self._on_save)
        footer.addWidget(b_cancel)
        footer.addWidget(b_save)
        root.addLayout(footer)

        # Load initial blocks or reconstruct from existing expression text
        init_blocks = list(getattr(widget_cfg, "expression_blocks", []) or [])
        init_expr = str(getattr(widget_cfg, "expression", "") or "").strip()
        if init_blocks:
            self.lego_canvas.set_blocks(init_blocks)
        elif init_expr:
            rec_blocks, ok_lossless = expression_to_blocks(init_expr, default_layer=str(getattr(widget_cfg, "layer_name", "") or ""))
            self.lego_canvas.set_blocks(rec_blocks)
            if not ok_lossless:
                self.lbl_adv_notice.setText(tr("lego_adv_lossless_warn", lang))
                self.lbl_adv_notice.show()
        else:
            default_lyr = str(getattr(widget_cfg, "layer_name", "") or (sources_info[0]["name"] if sources_info else ""))
            if default_lyr:
                self.lego_canvas.set_blocks([{"kind": "metric", "layer": default_lyr, "field": "$area", "agg": "sum", "where_field": "", "where_op": "=", "where_val": ""}])

        for sig in (self.sp_decimals.valueChanged, self.ed_prefix.textChanged, self.ed_suffix.textChanged, self.ed_target.textChanged, self.ed_thr_ok.textChanged, self.ed_thr_warn.textChanged, self.ed_subtext.textChanged):
            sig.connect(lambda *_a: self._refresh_live_preview())
        if hasattr(self.ed_expr, "textChanged"):
            self.ed_expr.textChanged.connect(self._on_adv_text_edited)

        self._sync_threshold_visibility()
        self._on_canvas_blocks_changed()

    def _gather_sources_info(self) -> List[Dict[str, Any]]:
        if self.persistence is not None and hasattr(self.persistence, "list_all_available_sources"):
            return self.persistence.list_all_available_sources(self.dashboard)
        out: List[Dict[str, Any]] = []
        seen = set()
        for ln, rows in (self._extra_records_by_layer or {}).items():
            if not ln or ln in seen:
                continue
            seen.add(ln)
            flds = sorted({k for r in (rows or [])[:25] if isinstance(r, dict) for k in r.keys() if not str(k).startswith("_")})
            out.append({"name": ln, "source_type": "vector", "fields": flds, "row_count": len(rows or []), "hydrated": bool(rows)})
        for ds in getattr(self.dashboard, "data_sources", []) or []:
            if ds.name and not getattr(ds, "is_basemap", False) and ds.name not in seen:
                seen.add(ds.name)
                rows = (self._extra_records_by_layer or {}).get(ds.name, [])
                out.append({"name": ds.name, "source_type": ds.source_type, "fields": list(getattr(ds, "fields", []) or []), "row_count": len(rows), "hydrated": bool(rows)})
        return out

    def _gather_records_map(self) -> Dict[str, List[Dict[str, Any]]]:
        out: Dict[str, List[Dict[str, Any]]] = dict(self._extra_records_by_layer or {})
        if self.persistence is not None:
            out.update(getattr(self.persistence, "layer_records_cache", {}) or {})
            ex_map = getattr(self.persistence, "excel_records_cache", {}) or {}
            for ds in getattr(self.dashboard, "data_sources", []) or []:
                if ds.name and ds.name not in out and ds.id in ex_map:
                    out[ds.name] = ex_map[ds.id]
        return out

    def _hydrate_missing_sources(self) -> None:
        expr_now = self._current_expression_text()
        blks_now = self.lego_canvas.get_blocks()
        needed = sorted(extract_referenced_layers(expr_now) | extract_layers_from_blocks(blks_now))
        if callable(self.on_hydrate_layers):
            self.on_hydrate_layers(needed)
        src = self._gather_sources_info()
        recs = self._gather_records_map()
        self.palette.set_sources_info(src)
        self.lego_canvas.set_sources_and_records(src, recs)
        self._refresh_live_preview()

    def _on_palette_block_clicked(self, block_dict: Dict[str, Any]) -> None:
        if self._mode == "advanced":
            snip = blocks_to_expression([block_dict], primary_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
            if snip:
                if hasattr(self.ed_expr, "textCursor"):
                    cur = self.ed_expr.textCursor()
                    cur.insertText((" " if cur.position() > 0 else "") + snip)
                    self.ed_expr.setTextCursor(cur)
                self._refresh_live_preview()
        else:
            self.lego_canvas.append_block(block_dict)

    def _insert_adv_helper(self, item: Any) -> None:
        if item is None:
            return
        snip = str(item.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or "")
        if snip and hasattr(self.ed_expr, "textCursor"):
            cur = self.ed_expr.textCursor()
            cur.insertText(snip)
            self.ed_expr.setTextCursor(cur)

    def _open_templates_menu(self) -> None:
        if QMenu is None:
            return
        menu = QMenu(self)
        act_map = {}
        for tpl in EXPRESSION_TEMPLATES:
            lbl = tpl["title_en" if self.lang == "en" else "title_et"]
            act_map[menu.addAction(lbl)] = tpl
        chosen = exec_menu(menu, self.mapToGlobal(QPoint(340, 120)))
        if chosen in act_map:
            tpl = act_map[chosen]
            blks, _ok = expression_to_blocks(tpl["expr"], default_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
            self.lego_canvas.set_blocks(blks, record_undo=True)
            if tpl.get("subtext"):
                self.ed_subtext.setText(tpl["subtext"])
            self._on_canvas_blocks_changed()

    def _switch_mode(self, mode: str) -> None:
        if mode == self._mode:
            self.btn_mode_visual.setChecked(mode == "visual")
            self.btn_mode_adv.setChecked(mode == "advanced")
            return
        if mode == "advanced":
            expr = blocks_to_expression(self.lego_canvas.get_blocks(), primary_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
            self._syncing_text = True
            if hasattr(self.ed_expr, "setPlainText"):
                self.ed_expr.setPlainText(expr)
            else:
                self.ed_expr.setText(expr)
            self._syncing_text = False
            self.mode_stack.setCurrentIndex(1)
        else:
            txt = self.ed_expr.toPlainText().strip() if hasattr(self.ed_expr, "toPlainText") else self.ed_expr.text().strip()
            blks, ok_lossless = expression_to_blocks(txt, default_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
            self.lego_canvas.set_blocks(blks)
            self.lbl_adv_notice.setVisible(not ok_lossless)
            if not ok_lossless:
                self.lbl_adv_notice.setText(tr("lego_adv_lossless_warn", self.lang))
            self.mode_stack.setCurrentIndex(0)
        self._mode = mode
        self.btn_mode_visual.setChecked(mode == "visual")
        self.btn_mode_adv.setChecked(mode == "advanced")
        self._refresh_live_preview()

    def _on_canvas_blocks_changed(self) -> None:
        expr = blocks_to_expression(self.lego_canvas.get_blocks(), primary_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
        self.lbl_generated_formula.setText(f"fx: {expr or '—'}")
        self._syncing_text = True
        if hasattr(self.ed_expr, "setPlainText"):
            self.ed_expr.setPlainText(expr)
        else:
            self.ed_expr.setText(expr)
        self._syncing_text = False
        self._refresh_live_preview()

    def _on_adv_text_edited(self) -> None:
        if not self._syncing_text and self._mode == "advanced":
            self._refresh_live_preview()

    def _current_expression_text(self) -> str:
        if self._mode == "visual":
            return blocks_to_expression(self.lego_canvas.get_blocks(), primary_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
        return self.ed_expr.toPlainText().strip() if hasattr(self.ed_expr, "toPlainText") else self.ed_expr.text().strip()

    def _sync_threshold_visibility(self) -> None:
        cm = str(self.cb_color_mode.currentData() or "fixed")
        is_fixed = cm == "fixed"
        self.btn_color.setVisible(is_fixed)
        self.lbl_color_swatch.setVisible(is_fixed)
        self.lbl_thr_ok.setVisible(not is_fixed)
        self.ed_thr_ok.setVisible(not is_fixed)
        self.lbl_thr_warn.setVisible(not is_fixed)
        self.ed_thr_warn.setVisible(not is_fixed)
        self._refresh_live_preview()

    def _update_swatch(self) -> None:
        self.lbl_color_swatch.setStyleSheet(f"background: {self._selected_color}; border-radius: 4px; border: 1px solid #475569;")

    def _pick_color(self) -> None:
        if QColorDialog is None:
            return
        col = QColorDialog.getColor(QColor(self._selected_color), self)
        if col.isValid():
            self._selected_color = col.name()
            self._update_swatch()
            self._refresh_live_preview()

    @staticmethod
    def _parse_opt_float(txt: str) -> Optional[float]:
        s = str(txt or "").strip().replace(",", ".")
        if not s:
            return None
        try:
            return float(s)
        except ValueError:
            return None

    def _refresh_live_preview(self) -> None:
        expr = self._current_expression_text() or "count()"
        recs_map = self._gather_records_map()
        lname = str(getattr(self.widget_cfg, "layer_name", "") or "")
        layers_used = extract_referenced_layers(expr) | extract_layers_from_blocks(self.lego_canvas.get_blocks())
        if not lname and layers_used:
            lname = sorted(layers_used)[0]
        raw_recs = recs_map.get(lname, [])
        filtered_recs = (
            self.filter_bus.filter_records(raw_recs, layer_name=lname, exclude_source_id=self.widget_cfg.id, target_widget_id=self.widget_cfg.id)
            if self.filter_bus is not None
            else raw_recs
        )

        def _flt_fn(ln: str, rws: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            if self.filter_bus is None:
                return list(rws or [])
            return self.filter_bus.filter_records(rws, layer_name=ln, exclude_source_id=self.widget_cfg.id, target_widget_id=self.widget_cfg.id)

        def _w_res(rk: str, md: str = "value") -> float:
            return compute_dashboard_widget_ref(rk, self.dashboard, recs_map, self.filter_bus, mode=md, visited={self.widget_cfg.id})

        res = evaluate_dashboard_expression(
            expr,
            filtered_recs,
            all_records_by_layer=recs_map,
            layer_name=lname,
            total_count=len(raw_recs),
            filter_count=len(self.filter_bus.active_filters()) if self.filter_bus is not None else 0,
            filter_fn=_flt_fn,
            widget_resolver=_w_res,
            decimals=int(self.sp_decimals.value()),
            prefix=self.ed_prefix.text(),
            suffix=self.ed_suffix.text(),
        )
        tmp_cfg = WidgetConfig(
            primary_color=self._selected_color,
            target_value=self._parse_opt_float(self.ed_target.text()),
            expression_color_mode=str(self.cb_color_mode.currentData() or "fixed"),
            expression_threshold_ok=self._parse_opt_float(self.ed_thr_ok.text()),
            expression_threshold_warn=self._parse_opt_float(self.ed_thr_warn.text()),
        )
        accent = resolve_expression_accent_color(tmp_cfg, res)
        self.lego_canvas.set_preview_state(str(res["formatted"] if res["ok"] else "!"), accent)
        if res["ok"]:
            self.lbl_live_preview.setText(
                f"<span style='color:{accent};font-weight:700;'>● {tr('expr_ok_status', self.lang)}</span> <b>{res['formatted']}</b>"
            )
        else:
            self.lbl_live_preview.setText(
                f"<span style='color:#f87171;font-weight:700;'>{tr('expr_err_prefix', self.lang)}</span> {res['error']}"
            )

    def _on_save(self) -> None:
        expr = self._current_expression_text()
        if self._mode == "visual":
            blocks = self.lego_canvas.get_blocks()
        else:
            blocks, ok_lossless = expression_to_blocks(expr, default_layer=str(getattr(self.widget_cfg, "layer_name", "") or ""))
            if not ok_lossless:
                blocks = []

        self.widget_cfg.widget_type = "expression"
        self.widget_cfg.title = self.ed_title_et.text().strip() or ("Avaldisvidin" if self.lang == "et" else "Expression Card")
        self.widget_cfg.title_en = self.widget_cfg.title_en or self.widget_cfg.title
        self.widget_cfg.title_custom = True
        self.widget_cfg.expression = expr
        self.widget_cfg.expression_blocks = blocks
        self.widget_cfg.expression_subtext = self.ed_subtext.text().strip()
        self.widget_cfg.expression_display = str(self.cb_display.currentData() or "auto")
        self.widget_cfg.decimals = int(self.sp_decimals.value())
        self.widget_cfg.prefix = self.ed_prefix.text()
        self.widget_cfg.suffix = self.ed_suffix.text()
        self.widget_cfg.target_value = self._parse_opt_float(self.ed_target.text())
        self.widget_cfg.primary_color = self._selected_color
        self.widget_cfg.expression_color_mode = str(self.cb_color_mode.currentData() or "fixed")
        self.widget_cfg.expression_threshold_ok = self._parse_opt_float(self.ed_thr_ok.text())
        self.widget_cfg.expression_threshold_warn = self._parse_opt_float(self.ed_thr_warn.text())

        refs = extract_referenced_layers(expr) | extract_layers_from_blocks(blocks)
        if refs and not self.widget_cfg.layer_name:
            self.widget_cfg.layer_name = sorted(refs)[0]
        if self.widget_cfg.layout_w > 460:
            self.widget_cfg.layout_w = 280
        if self.widget_cfg.layout_h > 240:
            self.widget_cfg.layout_h = 150
        self.accept()
