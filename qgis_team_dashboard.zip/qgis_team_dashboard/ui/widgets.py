# -*- coding: utf-8 -*-
"""
Interactive, Draggable & Resizable BI Widgets for QGIS Team Dashboard:
- ResizableCardFrame: Drag-to-move title bar + corner/edge resize grip for EVERY widget, map, graph, and filter.
- DashboardMapWidget: Embedded QGIS Map Canvas widget (EPSG:3301 Maa-amet WMS basemaps + WFS/vector layers).
- SlicerCardWidget: Draggable & resizable filter card with clickable category chips.
- KpiCardWidget: Conservation summary metric card (hectares, budgets, counts, target goal delta).
- InteractiveChartWidget: Anti-aliased QPainter chart engine (Bar, Horizontal Bar, Line, Pie/Donut, Scatter).
- DataTableWidget: Searchable, sortable attribute & joined-Excel table linked to map selection.
- CatalogTreeWidget: Drag-enabled OGC/Excel/QGIS tree for the Data Catalog sidebar.
"""

import base64
import json
import math
import os
import re
import threading
import weakref
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..connectors.address_connector import search_estonian_address
from ..connectors.ogc_connector import OgcConnector
from ..core.aggregator import Aggregator, friendly_field_label
from ..core.filter_bus import ActiveFilter, FilterBus
from ..core.i18n import tr
from ..core.schema import DataSourceConfig, SlicerConfig, WidgetConfig, group_slicer_panes
from .theme import ThemeManager
from .qt_compat import (
    QtCore,
    QtGui,
    QtWidgets,
    exec_dialog,
    exec_menu,
    mouse_global_pos,
    mouse_pos_f,
    qt_enum,
)

QMimeData = QtCore.QMimeData
QPoint = QtCore.QPoint
QPointF = QtCore.QPointF
QRectF = QtCore.QRectF
Qt = QtCore.Qt
QBrush = QtGui.QBrush
QColor = QtGui.QColor
QDesktopServices = getattr(QtGui, "QDesktopServices", None)
QDrag = QtGui.QDrag
QFont = QtGui.QFont
QGuiApplication = getattr(QtGui, "QGuiApplication", None)
QPainter = QtGui.QPainter
QPainterPath = QtGui.QPainterPath
QPen = QtGui.QPen
QPixmap = getattr(QtGui, "QPixmap", None)
QAbstractItemView = QtWidgets.QAbstractItemView
QCheckBox = QtWidgets.QCheckBox
QColorDialog = getattr(QtWidgets, "QColorDialog", None)
QComboBox = QtWidgets.QComboBox
QDialog = getattr(QtWidgets, "QDialog", QtWidgets.QWidget)
QDoubleSpinBox = getattr(QtWidgets, "QDoubleSpinBox", None)
QFormLayout = getattr(QtWidgets, "QFormLayout", None)
QFrame = QtWidgets.QFrame
QHBoxLayout = QtWidgets.QHBoxLayout
QHeaderView = QtWidgets.QHeaderView
QLabel = QtWidgets.QLabel
QLineEdit = QtWidgets.QLineEdit
QListWidget = QtWidgets.QListWidget
QListWidgetItem = QtWidgets.QListWidgetItem
QProgressBar = getattr(QtWidgets, "QProgressBar", None)
QPushButton = QtWidgets.QPushButton
QScrollArea = QtWidgets.QScrollArea
QSizePolicy = QtWidgets.QSizePolicy
QSlider = getattr(QtWidgets, "QSlider", None)
QSpinBox = getattr(QtWidgets, "QSpinBox", None)
QTabWidget = getattr(QtWidgets, "QTabWidget", None)
QTableWidget = QtWidgets.QTableWidget
QTableWidgetItem = QtWidgets.QTableWidgetItem
QToolTip = QtWidgets.QToolTip
QTreeWidget = QtWidgets.QTreeWidget
QVBoxLayout = QtWidgets.QVBoxLayout
QWidget = QtWidgets.QWidget

PALETTES: Dict[str, List[str]] = {
    "emerald": ["#34d399", "#059669", "#10b981", "#38bdf8", "#fbbf24", "#a855f7"],
    "forest": ["#15803d", "#22c55e", "#166534", "#84cc16", "#0d9488", "#65a30d"],
    "meadow": ["#4ade80", "#facc15", "#2dd4bf", "#a3e635", "#38bdf8", "#fb923c"],
    "ocean": ["#38bdf8", "#0284c7", "#818cf8", "#22d3ee", "#34d399", "#a78bfa"],
    "amber": ["#fbbf24", "#d97706", "#f59e0b", "#fb7185", "#38bdf8", "#34d399"],
    "earth": ["#d97706", "#a16207", "#65a30d", "#92400e", "#ca8a04", "#0d9488"],
    "rose": ["#f43f5e", "#e11d48", "#fb7185", "#c084fc", "#38bdf8", "#fbbf24"],
    "corporate": ["#2563eb", "#0d9488", "#d97706", "#dc2626", "#7c3aed", "#475569"],
}

MAAAMET_BASEMAPS: List[Tuple[str, str, str, str]] = [
    ("MA-HALLKAART", "Maa- ja Ruumiamet Hallkaart", "https://kaart.maaamet.ee/wms/hallkaart", "image/png"),
    ("MA-KAART", "Maa- ja Ruumiamet Põhikaart", "https://kaart.maaamet.ee/wms/kaart", "image/png"),
    ("EESTIFOTO", "Maa- ja Ruumiamet Ortofoto (EESTIFOTO)", "https://kaart.maaamet.ee/wms/fotokaart", "image/jpeg"),
    ("HYBRID", "Maa- ja Ruumiamet Hübriidkaart (Orto + Hübriid)", "https://kaart.maaamet.ee/wms/fotokaart", "image/jpeg"),
]


class CatalogTreeWidget(QTreeWidget):
    """Data Catalog tree with JSON drag payloads onto the dashboard workspace."""

    MIME_TYPE = "application/x-qgis-team-dashboard-catalog-item"

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setHeaderHidden(True)
        self.setIndentation(16)

    def startDrag(self, supportedActions: Any) -> None:
        item = self.currentItem()
        if not item:
            return
        data = item.data(0, qt_enum(Qt, "ItemDataRole", "UserRole"))
        if not isinstance(data, dict) or data.get("type") in (None, "root", "add_custom", "wfs_server"):
            return
        mime = QMimeData()
        mime.setData(self.MIME_TYPE, json.dumps(data, ensure_ascii=False).encode("utf-8"))
        drag = QDrag(self)
        drag.setMimeData(mime)
        drag.exec(qt_enum(Qt, "DropAction", "CopyAction"))


PIVOT_FIELD_MIME = "application/x-qgis-dashboard-pivot-field"
_StyledDelegateBase = getattr(QtWidgets, "QStyledItemDelegate", object)


class HoverDeleteDelegate(_StyledDelegateBase):
    """Paints a crisp inline '×' delete badge on the hovered item row."""

    def __init__(self, list_widget: Any) -> None:
        if _StyledDelegateBase is not object:
            super().__init__(list_widget)
        self._list = list_widget
        self._hover_row = -1

    def set_hover_row(self, row: int) -> None:
        if self._hover_row != row:
            self._hover_row = row
            try:
                vp = self._list.viewport() if hasattr(self._list, "viewport") else None
                if vp is not None:
                    vp.update()
            except Exception:
                pass

    @staticmethod
    def delete_rect(item_rect: Any) -> Any:
        try:
            QRect = QtCore.QRect
            size = 18
            x = int(item_rect.right()) - size - 6
            y = int(item_rect.top()) + max(1, (int(item_rect.height()) - size) // 2)
            return QRect(x, y, size, size)
        except Exception:
            return None

    def paint(self, painter: Any, option: Any, index: Any) -> None:
        if _StyledDelegateBase is not object:
            try:
                super().paint(painter, option, index)
            except Exception:
                pass
        if getattr(self._list, "role_mode", "source") == "source":
            return
        try:
            state_mouse_over = getattr(getattr(QtWidgets.QStyle, "StateFlag", QtWidgets.QStyle), "State_MouseOver", 0)
            is_hovered = index.row() == self._hover_row or bool(int(option.state) & int(state_mouse_over))
        except Exception:
            is_hovered = index.row() == self._hover_row
        if not is_hovered:
            return
        r = self.delete_rect(option.rect)
        if r is None:
            return
        try:
            painter.save()
            painter.setRenderHint(qt_enum(QPainter, "RenderHint", "Antialiasing"))
            painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
            painter.setBrush(QColor("#ef4444"))
            painter.drawRoundedRect(r, 4, 4)
            painter.setPen(QColor("#ffffff"))
            align_center = qt_enum(Qt, "AlignmentFlag", "AlignCenter")
            painter.drawText(r, align_center, "×")
            painter.restore()
        except Exception:
            pass


class DragFieldListWidget(QListWidget):
    """
    List widget with:
    - Drag-and-drop field pills (from source list into Pivot/Detail zones & internal reorder)
    - Inline hover '×' delete button
    - Delete/Backspace key removal
    - Right-click context menu with Remove (and optional custom actions)
    """

    def __init__(
        self,
        role_mode: str = "pivot_zone",
        lang: str = "et",
        on_remove_row: Optional[Callable[[int], None]] = None,
        on_remove_rows: Optional[Callable[[List[int]], None]] = None,
        on_field_dropped: Optional[Callable[[str, str, int], None]] = None,
        context_menu_cb: Optional[Callable[[Any, Any], None]] = None,
        on_order_changed: Optional[Callable[[], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.role_mode = role_mode
        self.lang = lang
        self.on_remove_row = on_remove_row
        self.on_remove_rows = on_remove_rows
        self.on_field_dropped = on_field_dropped
        self.context_menu_cb = context_menu_cb
        self.on_order_changed = on_order_changed
        self._delegate = HoverDeleteDelegate(self)
        if _StyledDelegateBase is not object:
            try:
                self.setItemDelegate(self._delegate)
            except Exception:
                pass
        try:
            self.setMouseTracking(True)
        except Exception:
            pass

        try:
            if role_mode == "source":
                self.setDragEnabled(True)
                self.setAcceptDrops(False)
                self.setDragDropMode(qt_enum(QAbstractItemView, "DragDropMode", "DragOnly"))
            elif role_mode in ("pivot_zone", "layer_order"):
                self.setDragEnabled(True)
                self.setAcceptDrops(True)
                self.setDragDropMode(qt_enum(QAbstractItemView, "DragDropMode", "DragDrop"))
                self.setDefaultDropAction(qt_enum(Qt, "DropAction", "MoveAction"))
            else:
                self.setDragEnabled(False)
                self.setAcceptDrops(False)
        except Exception:
            pass

        if role_mode != "source":
            try:
                self.setContextMenuPolicy(qt_enum(Qt, "ContextMenuPolicy", "CustomContextMenu"))
                self.customContextMenuRequested.connect(self._on_context_menu)
            except Exception:
                pass

    def _event_point(self, event: Any) -> Any:
        try:
            if hasattr(event, "position"):
                return event.position().toPoint()
            if hasattr(event, "pos"):
                return event.pos()
        except Exception:
            pass
        return QPoint(0, 0)

    def move_selected(self, delta: int) -> None:
        """Move current row up (delta=-1) or down (delta=+1) preserving UserRole and check state."""
        row = self.currentRow()
        new_row = row + delta
        if row < 0 or new_row < 0 or new_row >= self.count():
            return
        item = self.takeItem(row)
        self.insertItem(new_row, item)
        self.setCurrentRow(new_row)
        if callable(getattr(self, "on_order_changed", None)):
            try:
                self.on_order_changed()
            except Exception:
                pass

    def remove_rows_at(self, rows: List[int]) -> None:
        clean_rows = sorted({int(r) for r in (rows or []) if 0 <= int(r) < self.count()}, reverse=True)
        if not clean_rows:
            return
        if self.on_remove_rows is not None:
            self.on_remove_rows(clean_rows)
        elif len(clean_rows) == 1 and self.on_remove_row is not None:
            self.on_remove_row(clean_rows[0])
        else:
            for r in clean_rows:
                if self.on_remove_row is not None:
                    self.on_remove_row(r)
                else:
                    self.takeItem(r)
        self._delegate.set_hover_row(-1)

    def remove_row_at(self, row: int) -> None:
        if row < 0 or row >= self.count():
            return
        if self.on_remove_rows is not None:
            self.on_remove_rows([row])
        elif self.on_remove_row:
            self.on_remove_row(row)
        else:
            self.takeItem(row)
        self._delegate.set_hover_row(-1)

    def mouseMoveEvent(self, event: Any) -> None:
        if self.role_mode != "source":
            try:
                pos = self._event_point(event)
                idx = self.indexAt(pos)
                self._delegate.set_hover_row(idx.row() if idx.isValid() else -1)
            except Exception:
                pass
        super().mouseMoveEvent(event)

    def leaveEvent(self, event: Any) -> None:
        self._delegate.set_hover_row(-1)
        super().leaveEvent(event)

    def mousePressEvent(self, event: Any) -> None:
        if self.role_mode != "source":
            try:
                if event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
                    pos = self._event_point(event)
                    idx = self.indexAt(pos)
                    if idx.isValid():
                        rect = self.visualRect(idx)
                        del_r = self._delegate.delete_rect(rect)
                        if del_r is not None and del_r.contains(pos):
                            self.remove_row_at(idx.row())
                            event.accept()
                            return
            except Exception:
                pass
        super().mousePressEvent(event)

    def keyPressEvent(self, event: Any) -> None:
        if self.role_mode != "source":
            try:
                del_key = qt_enum(Qt, "Key", "Key_Delete")
                bk_key = qt_enum(Qt, "Key", "Key_Backspace")
                if event.key() in (del_key, bk_key):
                    rows = sorted(
                        {self.row(it) for it in self.selectedItems() if self.row(it) >= 0},
                        reverse=True,
                    )
                    if not rows and self.currentRow() >= 0:
                        rows = [self.currentRow()]
                    if rows:
                        self.remove_rows_at(rows)
                        event.accept()
                        return
            except Exception:
                pass
        super().keyPressEvent(event)

    def _on_context_menu(self, pos: Any) -> None:
        item = self.itemAt(pos)
        if item is None:
            return
        try:
            global_pos = self.viewport().mapToGlobal(pos)
        except Exception:
            global_pos = self.mapToGlobal(pos)
        if self.context_menu_cb:
            self.context_menu_cb(item, global_pos)
            return
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            return
        menu = QMenuCls(self)
        act_rm = menu.addAction(tr("ctx_remove", self.lang))
        from .qt_compat import exec_menu
        chosen = exec_menu(menu, global_pos)
        if chosen == act_rm:
            sel_items = list(self.selectedItems() or [])
            if item in sel_items and len(sel_items) > 1:
                self.remove_rows_at([self.row(it) for it in sel_items if self.row(it) >= 0])
            else:
                self.remove_row_at(self.row(item))

    def startDrag(self, supportedActions: Any) -> None:
        item = self.currentItem()
        if item is None:
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        raw = item.data(role)
        if isinstance(raw, tuple):
            fname = str(raw[0] or "")
        elif isinstance(raw, dict):
            fname = str(raw.get("field") or "")
        else:
            fname = str(raw or item.text() or "")
        if not fname:
            return
        payload = {"field": fname, "label": item.text(), "source_id": id(self)}
        mime = QMimeData()
        mime.setData(PIVOT_FIELD_MIME, json.dumps(payload, ensure_ascii=False).encode("utf-8"))
        mime.setText(fname)
        drag = QDrag(self)
        drag.setMimeData(mime)
        action = qt_enum(Qt, "DropAction", "CopyAction" if self.role_mode == "source" else "MoveAction")
        drag.exec(action)

    def _can_accept_drag(self, event: Any) -> bool:
        if self.role_mode not in ("pivot_zone", "layer_order"):
            return False
        md = event.mimeData()
        return bool(md and (md.hasFormat(PIVOT_FIELD_MIME) or md.hasText()))

    def dragEnterEvent(self, event: Any) -> None:
        if self._can_accept_drag(event):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event: Any) -> None:
        if self._can_accept_drag(event):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event: Any) -> None:
        if not self._can_accept_drag(event):
            super().dropEvent(event)
            return
        md = event.mimeData()
        fname = ""
        label = ""
        src_id = 0
        if md.hasFormat(PIVOT_FIELD_MIME):
            try:
                raw_bytes = bytes(md.data(PIVOT_FIELD_MIME)).decode("utf-8")
                payload = json.loads(raw_bytes)
                fname = str(payload.get("field") or "")
                label = str(payload.get("label") or fname)
                src_id = int(payload.get("source_id") or 0)
            except Exception:
                fname = ""
        if not fname and md.hasText():
            fname = str(md.text() or "").strip()
            label = fname
        if not fname:
            event.ignore()
            return

        pos = self._event_point(event)
        idx = self.indexAt(pos)
        target_row = idx.row() if idx.isValid() else self.count()

        if src_id == id(self):
            cur = self.currentItem()
            if cur is not None:
                cur_row = self.row(cur)
                if cur_row >= 0 and cur_row != target_row:
                    taken = self.takeItem(cur_row)
                    if cur_row < target_row:
                        target_row -= 1
                    self.insertItem(max(0, min(self.count(), target_row)), taken)
                    self.setCurrentItem(taken)
                    if callable(getattr(self, "on_order_changed", None)):
                        try:
                            self.on_order_changed()
                        except Exception:
                            pass
            event.acceptProposedAction()
            return
        if self.role_mode == "layer_order":
            event.ignore()
            return

        if self.on_field_dropped:
            self.on_field_dropped(fname, label or fname, target_row)
        else:
            it = QListWidgetItem(label or fname)
            it.setData(qt_enum(Qt, "ItemDataRole", "UserRole"), fname)
            self.insertItem(max(0, min(self.count(), target_row)), it)
        event.acceptProposedAction()


class _ResizeEdgeHandle(QWidget):
    """Transparent interactive overlay handle along card edges and corners (#10)."""

    _CURSORS = {
        "left": "SizeHorCursor",
        "right": "SizeHorCursor",
        "top": "SizeVerCursor",
        "bottom": "SizeVerCursor",
        "top_left": "SizeFDiagCursor",
        "corner": "SizeFDiagCursor",
        "top_right": "SizeBDiagCursor",
        "bottom_left": "SizeBDiagCursor",
    }

    def __init__(self, card: "ResizableCardFrame", mode: str) -> None:
        super().__init__(card)
        self._card = card
        self._mode = mode
        c_name = self._CURSORS.get(mode, "ArrowCursor")
        self.setCursor(qt_enum(Qt, "CursorShape", c_name))
        self.setMouseTracking(True)

    def mousePressEvent(self, event: Any) -> None:
        if event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            self._card.begin_resize(self._mode, mouse_global_pos(event))
            event.accept()

    def mouseMoveEvent(self, event: Any) -> None:
        if self._card.is_resizing():
            self._card.step_resize(mouse_global_pos(event))
            event.accept()

    def mouseReleaseEvent(self, event: Any) -> None:
        if self._card.is_resizing():
            self._card.end_resize()
            event.accept()


class _ResizeCornerGrip(QWidget):
    """Bottom-right visual & interactive resize handle for ResizableCardFrame."""

    def __init__(self, card: "ResizableCardFrame") -> None:
        super().__init__(card)
        self._card = card
        self.setFixedSize(16, 16)
        self.setCursor(qt_enum(Qt, "CursorShape", "SizeFDiagCursor"))
        self.setMouseTracking(True)

    def paintEvent(self, _event: Any) -> None:
        p = QPainter(self)
        p.setRenderHint(qt_enum(QPainter, "RenderHint", "Antialiasing"))
        pen = QPen(QColor("#64748b"), 1.6)
        p.setPen(pen)
        p.drawLine(4, 14, 14, 4)
        p.drawLine(8, 14, 14, 8)
        p.drawLine(12, 14, 14, 12)

    def mousePressEvent(self, event: Any) -> None:
        if event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            self._card.begin_resize("corner", mouse_global_pos(event))
            event.accept()

    def mouseMoveEvent(self, event: Any) -> None:
        if self._card.is_resizing():
            self._card.step_resize(mouse_global_pos(event))
            event.accept()

    def mouseReleaseEvent(self, event: Any) -> None:
        if self._card.is_resizing():
            self._card.end_resize()
            event.accept()


_QLayoutBase = getattr(QtWidgets, "QLayout", object)


class _FlowLayout(_QLayoutBase):
    """Responsive wrapping Qt layout so toolbar buttons never clip or overlap on narrow cards."""

    def __init__(self, parent: Optional[QWidget] = None, margin: int = 0, spacing: int = 5) -> None:
        try:
            super().__init__(parent)
        except Exception:
            pass
        self._items: List[Any] = []
        self._h_space = int(spacing)
        self._v_space = int(spacing)
        if hasattr(self, "setContentsMargins"):
            self.setContentsMargins(margin, margin, margin, margin)

    def addItem(self, item: Any) -> None:
        self._items.append(item)

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, index: int) -> Any:
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index: int) -> Any:
        return self._items.pop(index) if 0 <= index < len(self._items) else None

    def expandingDirections(self) -> Any:
        ori = getattr(Qt, "Orientations", None) or getattr(Qt, "Orientation", None)
        return ori(0) if ori is not None else 0

    def hasHeightForWidth(self) -> bool:
        return True

    def heightForWidth(self, width: int) -> int:
        return self._do_layout(QtCore.QRect(0, 0, max(1, int(width)), 0), True)

    def setGeometry(self, rect: Any) -> None:
        if hasattr(_QLayoutBase, "setGeometry"):
            super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self) -> Any:
        return self.minimumSize()

    def minimumSize(self) -> Any:
        qsize = getattr(QtCore, "QSize", None)
        if qsize is None:
            return None
        sz = qsize(0, 0)
        for item in self._items:
            try:
                sz = sz.expandedTo(item.minimumSize())
            except Exception:
                pass
        if hasattr(self, "contentsMargins"):
            try:
                m = self.contentsMargins()
                sz += qsize(m.left() + m.right(), m.top() + m.bottom())
            except Exception:
                pass
        return sz

    def _do_layout(self, rect: Any, test_only: bool) -> int:
        qrect = getattr(QtCore, "QRect", None)
        qpoint = getattr(QtCore, "QPoint", None)
        qsize = getattr(QtCore, "QSize", None)
        if qrect is None or qpoint is None or qsize is None or not hasattr(rect, "x"):
            return 0
        m = self.contentsMargins() if hasattr(self, "contentsMargins") else None
        left_m = m.left() if m else 0
        top_m = m.top() if m else 0
        right_m = m.right() if m else 0
        bot_m = m.bottom() if m else 0
        eff = rect.adjusted(left_m, top_m, -right_m, -bot_m)
        x = eff.x()
        y = eff.y()
        line_h = 0
        for item in self._items:
            try:
                wid = item.widget()
                if wid is not None and hasattr(wid, "isHidden") and wid.isHidden():
                    continue
                isz = item.sizeHint()
            except Exception:
                continue
            next_x = x + isz.width() + self._h_space
            if next_x - self._h_space > eff.right() and line_h > 0:
                x = eff.x()
                y = y + line_h + self._v_space
                next_x = x + isz.width() + self._h_space
                line_h = 0
            if not test_only:
                item.setGeometry(qrect(qpoint(x, y), isz))
            x = next_x
            line_h = max(line_h, isz.height())
        return (y + line_h - rect.y()) + bot_m


class ResizableCardFrame(QFrame):
    """
    Draggable & Resizable card wrapper rendered on the main workspace canvas.
    Supports:
    - Dragging the title bar to reposition freely on a 10px grid.
    - Dragging the bottom-right grip (or right/bottom edges) to resize any card.
    - Inline Edit and Delete actions plus persistence callback on geometry changes.
    """

    EDGE_MARGIN = 7

    def __init__(
        self,
        item_id: str,
        title: str,
        inner_widget: QWidget,
        lang: str = "et",
        accent_color: str = "#38bdf8",
        min_w: int = 190,
        min_h: int = 95,
        grid_size: int = 20,
        snap_enabled: bool = True,
        preview_mode: bool = False,
        on_edit: Optional[Callable[[], None]] = None,
        on_refresh: Optional[Callable[[], None]] = None,
        on_delete: Optional[Callable[[str], None]] = None,
        on_geometry_changed: Optional[Callable[[str, int, int, int, int], None]] = None,
        on_connect_clicked: Optional[Callable[[str], None]] = None,
        on_connect_dragged: Optional[Callable[[str, Any], None]] = None,
        on_connect_drag_move: Optional[Callable[[str, Any], None]] = None,
        on_geometry_live_changed: Optional[Callable[[], None]] = None,
        on_clear_filter: Optional[Callable[[str], None]] = None,
        is_edge_locked: Optional[Callable[[str, str], bool]] = None,
        on_linked_edge_begin: Optional[Callable[[str, str], bool]] = None,
        on_linked_edge_step: Optional[Callable[[str, str, int, bool], None]] = None,
        on_toggle_border_locks: Optional[Callable[[str], Optional[bool]]] = None,
        border_style: str = "default",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.item_id = item_id
        self.lang = lang
        self.min_w = min_w
        self.min_h = min_h
        self._min_w = min_w
        self._min_h = min_h
        self.grid_size = max(5, int(grid_size))
        self.snap_enabled = bool(snap_enabled)
        self.preview_mode = bool(preview_mode)
        self.canvas_zoom: float = 1.0
        self._logical_rect: Optional[Tuple[int, int, int, int]] = None
        self._on_edit = on_edit
        self._on_refresh = on_refresh
        self._on_delete = on_delete
        self._on_geometry_changed = on_geometry_changed
        self._on_clear_filter = on_clear_filter
        self._border_style = border_style or "default"
        self._adjacent_edges: Tuple[bool, bool, bool, bool] = (False, False, False, False)
        self._dissolve_adjacent: bool = True
        self._last_theme_mode: Optional[str] = None

        self._drag_offset: Optional[QPoint] = None
        self._connect_press_pos: Optional[QPoint] = None
        self._connect_dragging: bool = False
        self._on_connect_clicked = on_connect_clicked
        self._on_connect_dragged = on_connect_dragged
        self._on_connect_drag_move = on_connect_drag_move
        self._on_geometry_live_changed = on_geometry_live_changed
        self._is_edge_locked = is_edge_locked
        self._on_linked_edge_begin = on_linked_edge_begin
        self._on_linked_edge_step = on_linked_edge_step
        self._on_toggle_border_locks = on_toggle_border_locks
        self._linked_resize_active: bool = False
        self._resize_mode: Optional[str] = None
        self._resize_start_global: Optional[QPoint] = None
        self._resize_start_size: Tuple[int, int] = (min_w, min_h)
        self._resize_start_rect: Tuple[int, int, int, int] = (8, 8, min_w, min_h)
        self._edge_handles: Dict[str, _ResizeEdgeHandle] = {}

        self.setObjectName("ResizableCardFrame")
        self.setFrameShape(qt_enum(QFrame, "Shape", "StyledPanel"))
        self.setMouseTracking(True)
        self._accent_color = accent_color
        self.setMinimumSize(min_w, min_h)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Drag handle title bar
        self.title_bar = QFrame(self)
        self.title_bar.setObjectName("CardTitleBar")
        self.title_bar.setFixedHeight(28)
        self.title_bar.setCursor(qt_enum(Qt, "CursorShape", "OpenHandCursor"))
        self.title_bar.setToolTip(tr("card_hint_drag", lang))

        tb = QHBoxLayout(self.title_bar)
        tb.setContentsMargins(8, 2, 6, 2)
        tb.setSpacing(5)

        self.lbl_grip = QLabel("⋮⋮")
        self.lbl_grip.setProperty("role", "muted")
        self.lbl_grip.setStyleSheet("font-weight: bold; font-size: 12px;")
        tb.addWidget(self.lbl_grip)

        self.lbl_title = QLabel(title)
        self.lbl_title.setProperty("role", "cardTitleSmall")
        self.lbl_title.setMinimumWidth(36)
        try:
            self.lbl_title.setSizePolicy(
                qt_enum(QSizePolicy, "Policy", "Expanding"),
                qt_enum(QSizePolicy, "Policy", "Preferred"),
            )
        except Exception:
            pass
        tb.addWidget(self.lbl_title, 1)

        def _pin_hdr_btn(btn: Any) -> None:
            try:
                btn.setSizePolicy(
                    qt_enum(QSizePolicy, "Policy", "Fixed"),
                    qt_enum(QSizePolicy, "Policy", "Fixed"),
                )
            except Exception:
                pass

        self.btn_clear_filter = QPushButton(tr("clear_widget_filter", lang))
        self.btn_clear_filter.setFixedHeight(20)
        self.btn_clear_filter.setProperty("btnRole", "cardAction")
        self.btn_clear_filter.setCursor(qt_enum(Qt, "CursorShape", "PointingHandCursor"))
        _pin_hdr_btn(self.btn_clear_filter)
        self.btn_clear_filter.setStyleSheet(
            "QPushButton { font-size: 10px; padding: 0px 6px; color: #f59e0b; border: 1px solid rgba(245,158,11,0.45); border-radius: 4px; background: rgba(245,158,11,0.08); }"
            "QPushButton:hover { background: rgba(245,158,11,0.20); }"
        )
        self.btn_clear_filter.clicked.connect(self._handle_clear_filter_click)
        self.btn_clear_filter.hide()
        tb.addWidget(self.btn_clear_filter)

        self.btn_connect = QPushButton("🔗")
        self.btn_connect.setFixedSize(26, 20)
        self.btn_connect.setProperty("btnRole", "cardAction")
        self.btn_connect.setToolTip(tr("card_btn_connect_tip", lang))
        self.btn_connect.setCursor(qt_enum(Qt, "CursorShape", "PointingHandCursor"))
        _pin_hdr_btn(self.btn_connect)
        self.btn_connect.installEventFilter(self)
        self.btn_connect.setVisible(not preview_mode)
        tb.addWidget(self.btn_connect)

        if on_edit:
            self.btn_edit = QPushButton(tr("edit", lang))
            self.btn_edit.setFixedHeight(20)
            self.btn_edit.setProperty("btnRole", "cardAction")
            _pin_hdr_btn(self.btn_edit)
            self.btn_edit.clicked.connect(lambda _checked=False, cb=on_edit: cb())
            tb.addWidget(self.btn_edit)
        else:
            self.btn_edit = None

        if on_delete:
            self.btn_del: Optional[QPushButton] = QPushButton("×")
            self.btn_del.setFixedSize(22, 20)
            self.btn_del.setProperty("btnRole", "cardClose")
            _pin_hdr_btn(self.btn_del)
            self.btn_del.clicked.connect(lambda: on_delete(self.item_id))
            tb.addWidget(self.btn_del)
        else:
            self.btn_del = None

        root.addWidget(self.title_bar)

        # Compact incoming active-filter status bar shown when upstream filters narrow this widget (#14)
        self.lbl_incoming_filter = QLabel("")
        self.lbl_incoming_filter.setWordWrap(True)
        try:
            pol_cls = getattr(QtWidgets, "QSizePolicy", None)
            if pol_cls is not None and hasattr(self.lbl_incoming_filter, "setSizePolicy"):
                self.lbl_incoming_filter.setSizePolicy(
                    qt_enum(pol_cls, "Policy", "Expanding"),
                    qt_enum(pol_cls, "Policy", "Minimum"),
                )
        except Exception:
            pass
        self.lbl_incoming_filter.setStyleSheet(
            "background: rgba(56, 189, 248, 0.12); color: #38bdf8; "
            "border-bottom: 1px solid rgba(56, 189, 248, 0.25); "
            "padding: 3px 8px; font-size: 10px; font-weight: 600;"
        )
        self.lbl_incoming_filter.hide()
        root.addWidget(self.lbl_incoming_filter)

        self.body_widget = inner_widget
        self.inner_widget = inner_widget
        root.addWidget(inner_widget, 1)
        self.corner_grip = _ResizeCornerGrip(self)
        self.title_bar.installEventFilter(self)
        self.apply_theme()

    def _handle_clear_filter_click(self) -> None:
        if callable(self._on_clear_filter):
            self._on_clear_filter(self.item_id)

    def set_has_outgoing_filter(self, active: bool) -> None:
        if hasattr(self, "btn_clear_filter"):
            self.btn_clear_filter.setVisible(bool(active))

    def set_incoming_filter_badge(self, text: str) -> None:
        if hasattr(self, "lbl_incoming_filter"):
            clean = str(text or "").strip()
            self.lbl_incoming_filter.setText(clean)
            self.lbl_incoming_filter.setVisible(bool(clean))

    def set_adjacent_edges(
        self,
        top: bool,
        right: bool,
        bottom: bool,
        left: bool,
        dissolve: bool = True,
        border_style: str = "default",
    ) -> None:
        """Dissolve touching edges with neighboring cards while keeping outer perimeter rounded (#5)."""
        state = (bool(top), bool(right), bool(bottom), bool(left))
        style_key = str(border_style or "default")
        if (
            state == self._adjacent_edges
            and bool(dissolve) == self._dissolve_adjacent
            and style_key == self._border_style
        ):
            return
        self._adjacent_edges = state
        self._dissolve_adjacent = bool(dissolve)
        self._border_style = style_key
        self.apply_theme(self._last_theme_mode)

    def set_accent_color(self, color: str) -> None:
        new_c = str(color or "").strip()
        if not new_c or new_c == self._accent_color:
            return
        self._accent_color = new_c
        self.apply_theme(self._last_theme_mode)

    def apply_theme(self, theme_mode: Optional[str] = None) -> None:
        if theme_mode in ("dark", "light"):
            self._last_theme_mode = theme_mode
        c = (
            ThemeManager.colors(theme_mode=theme_mode)
            if theme_mode in ("dark", "light")
            else ThemeManager.colors_for_widget(self)
        )
        adj_t, adj_r, adj_b, adj_l = getattr(self, "_adjacent_edges", (False, False, False, False))
        dissolve = bool(getattr(self, "_dissolve_adjacent", True))
        bstyle = str(getattr(self, "_border_style", "default") or "default")

        base_r = 8
        tl_r = 0 if (dissolve and (adj_t or adj_l)) else base_r
        tr_r = 0 if (dissolve and (adj_t or adj_r)) else base_r
        br_r = 0 if (dissolve and (adj_b or adj_r)) else base_r
        bl_r = 0 if (dissolve and (adj_b or adj_l)) else base_r

        if bstyle == "none":
            bw_t = bw_r = bw_b = bw_l = "0px"
            top_accent = f"0px solid transparent"
        else:
            b_color = c["border"]
            bw = "1px" if bstyle != "accent" else "2px"
            bw_t = "0px" if (dissolve and adj_t) else ("3px" if bstyle != "subtle" else bw)
            bw_r = "1px" if (dissolve and adj_r) else bw
            bw_b = "1px" if (dissolve and adj_b) else bw
            bw_l = "0px" if (dissolve and adj_l) else bw
            top_accent_col = b_color if (dissolve and adj_t) else (self._accent_color if bstyle != "subtle" else b_color)
            top_accent = f"{bw_t} solid {top_accent_col}"

        tb_tl = max(0, tl_r - 2)
        tb_tr = max(0, tr_r - 2)
        self.setStyleSheet(
            f"""
            QFrame#ResizableCardFrame {{
                background-color: {c['bg_panel']};
                border-top: {top_accent};
                border-right: {bw_r} solid {c['border']};
                border-bottom: {bw_b} solid {c['border']};
                border-left: {bw_l} solid {c['border']};
                border-top-left-radius: {tl_r}px;
                border-top-right-radius: {tr_r}px;
                border-bottom-right-radius: {br_r}px;
                border-bottom-left-radius: {bl_r}px;
            }}
            QFrame#CardTitleBar {{
                background-color: {c['card_surface']};
                border-bottom: 1px solid {c['border']};
                border-top-left-radius: {tb_tl}px;
                border-top-right-radius: {tb_tr}px;
            }}
            """
        )

        if getattr(self, "corner_grip", None) is None or not isinstance(self.corner_grip, _ResizeCornerGrip):
            self.corner_grip = _ResizeCornerGrip(self)
            self.title_bar.installEventFilter(self)
        if not getattr(self, "_edge_handles", None):
            self._edge_handles = {
                mode: _ResizeEdgeHandle(self, mode)
                for mode in ("left", "right", "top", "bottom", "top_left", "top_right", "bottom_left")
            }
        self._layout_resize_handles()
        if hasattr(self.corner_grip, "raise_"):
            self.corner_grip.raise_()
        for eh in self._edge_handles.values():
            if hasattr(eh, "raise_"):
                eh.raise_()
        self.set_preview_mode(self.preview_mode)

    def _layout_resize_handles(self) -> None:
        w = max(24, int(self.width()))
        h = max(24, int(self.height()))
        if getattr(self, "corner_grip", None) is not None:
            self.corner_grip.move(w - self.corner_grip.width() - 2, h - self.corner_grip.height() - 2)
            self.corner_grip.raise_()
        handles = getattr(self, "_edge_handles", None) or {}
        geom_map = {
            "left": (0, 12, 6, max(4, h - 24)),
            "right": (w - 6, 12, 6, max(4, h - 24)),
            "top": (12, 0, max(4, w - 24), 5),
            "bottom": (12, h - 6, max(4, w - 24), 6),
            "top_left": (0, 0, 12, 12),
            "top_right": (w - 12, 0, 12, 12),
            "bottom_left": (0, h - 12, 12, 12),
        }
        for mode, (hx, hy, hw, hh) in geom_map.items():
            hdl = handles.get(mode)
            if hdl is not None:
                hdl.setGeometry(hx, hy, hw, hh)
                hdl.raise_()

    def set_grid_snap(self, snap_enabled: bool, grid_size: int = 20) -> None:
        self.snap_enabled = bool(snap_enabled)
        self.grid_size = max(5, int(grid_size))

    def set_canvas_zoom(self, zoom: float) -> None:
        z = max(0.25, min(2.0, float(zoom or 1.0)))
        self.canvas_zoom = z
        sw = max(64, int(round(self._min_w * z)))
        sh = max(44, int(round(self._min_h * z)))
        self.min_w = sw
        self.min_h = sh
        self.setMinimumSize(sw, sh)

    def _to_logical_val(self, px_val: int) -> int:
        z = max(0.25, float(getattr(self, "canvas_zoom", 1.0) or 1.0))
        return int(round(float(px_val) / z))

    def _to_screen_val(self, logical_val: int) -> int:
        z = max(0.25, float(getattr(self, "canvas_zoom", 1.0) or 1.0))
        return int(round(float(logical_val) * z))

    def set_pan_transparent(self, pan_enabled: bool) -> None:
        try:
            trans_attr = qt_enum(Qt, "WidgetAttribute", "WA_TransparentForMouseEvents")
            if trans_attr is not None:
                self.setAttribute(trans_attr, bool(pan_enabled))
                if getattr(self, "corner_grip", None) is not None:
                    self.corner_grip.setAttribute(trans_attr, bool(pan_enabled))
                for eh in (getattr(self, "_edge_handles", None) or {}).values():
                    eh.setAttribute(trans_attr, bool(pan_enabled))
        except Exception:
            pass

    def set_preview_mode(self, preview: bool) -> None:
        self.preview_mode = bool(preview)
        self.lbl_grip.setVisible(not preview)
        if getattr(self, "btn_connect", None) is not None:
            self.btn_connect.setVisible(not preview)
        if self.btn_edit is not None:
            self.btn_edit.setVisible(not preview)
        if self.btn_del is not None:
            self.btn_del.setVisible(not preview)
        self.corner_grip.setVisible(not preview)
        for eh in (getattr(self, "_edge_handles", None) or {}).values():
            eh.setVisible(not preview)
        self.title_bar.setCursor(
            qt_enum(Qt, "CursorShape", "ArrowCursor" if preview else "OpenHandCursor")
        )

    def set_title(self, title: str, lang: str = "et") -> None:
        self.lang = lang
        self.lbl_title.setText(title)
        self.title_bar.setToolTip("" if self.preview_mode else tr("card_hint_drag", lang))
        if getattr(self, "btn_connect", None) is not None:
            self.btn_connect.setToolTip(tr("card_btn_connect_tip", lang))
        if self.btn_edit:
            self.btn_edit.setText(tr("edit", lang))

    def resizeEvent(self, event: Any) -> None:
        super().resizeEvent(event)
        self._layout_resize_handles()

    def _snap_logical(self, val: int) -> int:
        if not self.snap_enabled:
            return max(8, int(val))
        step = max(5, self.grid_size)
        return max(8, round(val / step) * step)

    def _snap(self, val: int) -> int:
        return self._to_screen_val(self._snap_logical(self._to_logical_val(val)))

    def _emit_geom(self) -> None:
        if self._logical_rect is not None:
            lx, ly, lw, lh = self._logical_rect
        else:
            lx = max(8, self._to_logical_val(self.x()))
            ly = max(8, self._to_logical_val(self.y()))
            lw = max(self._min_w, self._to_logical_val(self.width()))
            lh = max(self._min_h, self._to_logical_val(self.height()))
            self._logical_rect = (lx, ly, lw, lh)
        if self._on_geometry_changed:
            self._on_geometry_changed(self.item_id, lx, ly, lw, lh)

    def detach_body_widget(self) -> Optional[QWidget]:
        """Detach inner widget cleanly without deleting it (e.g. preserve live map canvas across card rebuilds)."""
        w = getattr(self, "body_widget", None)
        if w is None:
            return None
        try:
            lay = self.layout()
            if lay is not None:
                lay.removeWidget(w)
            w.hide()
            w.setParent(None)
        except Exception:
            pass
        self.body_widget = None
        return w

    def is_resizing(self) -> bool:
        return self._resize_mode is not None

    def begin_resize(self, mode: str, global_pt: QPoint) -> None:
        if self.preview_mode:
            return
        self._resize_mode = mode
        self._resize_start_global = global_pt
        self._resize_start_size = (self.width(), self.height())
        if self._logical_rect is not None:
            self._resize_start_rect = tuple(int(v) for v in self._logical_rect)  # type: ignore[assignment]
        else:
            self._resize_start_rect = (
                max(8, self._to_logical_val(self.x())),
                max(8, self._to_logical_val(self.y())),
                max(self._min_w, self._to_logical_val(self.width())),
                max(self._min_h, self._to_logical_val(self.height())),
            )
        self._linked_resize_active = False
        if (
            mode in ("left", "right", "top", "bottom")
            and callable(self._on_linked_edge_begin)
            and self._on_linked_edge_begin(self.item_id, mode)
        ):
            self._linked_resize_active = True
        self.raise_()

    def step_resize(self, global_pt: QPoint) -> None:
        if self.preview_mode or not self._resize_mode or self._resize_start_global is None:
            return
        dx = global_pt.x() - self._resize_start_global.x()
        dy = global_pt.y() - self._resize_start_global.y()
        z = max(0.25, float(getattr(self, "canvas_zoom", 1.0) or 1.0))
        if self._linked_resize_active and callable(self._on_linked_edge_step):
            delta_px = dx if self._resize_mode in ("left", "right") else dy
            self._on_linked_edge_step(self.item_id, self._resize_mode, int(round(delta_px / z)), False)
            return

        lx0, ly0, lw0, lh0 = self._resize_start_rect
        rx0 = lx0 + lw0
        by0 = ly0 + lh0
        dx_log = int(round(float(dx) / z))
        dy_log = int(round(float(dy) / z))

        new_lx, new_ly, new_lw, new_lh = lx0, ly0, lw0, lh0
        mode = self._resize_mode
        if mode in ("right", "corner", "top_right"):
            new_lw = max(self._min_w, lw0 + dx_log)
        elif mode in ("left", "top_left", "bottom_left"):
            max_lx = max(8, rx0 - self._min_w)
            new_lx = max(8, min(max_lx, lx0 + dx_log))
            new_lw = max(self._min_w, rx0 - new_lx)

        if mode in ("bottom", "corner", "bottom_left"):
            new_lh = max(self._min_h, lh0 + dy_log)
        elif mode in ("top", "top_left", "top_right"):
            max_ly = max(8, by0 - self._min_h)
            new_ly = max(8, min(max_ly, ly0 + dy_log))
            new_lh = max(self._min_h, by0 - new_ly)

        sx = self._to_screen_val(new_lx)
        sy = self._to_screen_val(new_ly)
        sw = max(64, self._to_screen_val(new_lw))
        sh = max(44, self._to_screen_val(new_lh))
        self.move(sx, sy)
        self.resize(sw, sh)
        self._logical_rect = (new_lx, new_ly, new_lw, new_lh)
        if self._on_geometry_live_changed:
            self._on_geometry_live_changed()
        p = self.parentWidget()
        while p is not None:
            if hasattr(p, "expand_to_fit"):
                p.expand_to_fit()
                break
            p = p.parentWidget()

    def end_resize(self) -> None:
        if self._resize_mode is not None:
            mode = self._resize_mode
            if self._linked_resize_active and callable(self._on_linked_edge_step):
                self._resize_mode = None
                self._resize_start_global = None
                self._linked_resize_active = False
                self._on_linked_edge_step(self.item_id, mode, 0, True)
                return
            lx, ly, lw, lh = self._logical_rect or (
                max(8, self._to_logical_val(self.x())),
                max(8, self._to_logical_val(self.y())),
                max(self._min_w, self._to_logical_val(self.width())),
                max(self._min_h, self._to_logical_val(self.height())),
            )
            if self.snap_enabled:
                step = max(5, self.grid_size)
                if mode in ("left", "top_left", "bottom_left"):
                    rx_fixed = lx + lw
                    max_lx = max(8, rx_fixed - self._min_w)
                    lx = max(8, min(max_lx, round(lx / step) * step))
                    lw = max(self._min_w, rx_fixed - lx)
                elif mode in ("right", "corner", "top_right"):
                    lw = max(self._min_w, round(lw / step) * step)
                if mode in ("top", "top_left", "top_right"):
                    by_fixed = ly + lh
                    max_ly = max(8, by_fixed - self._min_h)
                    ly = max(8, min(max_ly, round(ly / step) * step))
                    lh = max(self._min_h, by_fixed - ly)
                elif mode in ("bottom", "corner", "bottom_left"):
                    lh = max(self._min_h, round(lh / step) * step)
            else:
                lx = max(8, lx)
                ly = max(8, ly)
                lw = max(self._min_w, lw)
                lh = max(self._min_h, lh)
            self._logical_rect = (lx, ly, lw, lh)
            self.move(self._to_screen_val(lx), self._to_screen_val(ly))
            self.resize(max(64, self._to_screen_val(lw)), max(44, self._to_screen_val(lh)))
            self._resize_mode = None
            self._resize_start_global = None
            self._emit_geom()
            if self._on_geometry_live_changed:
                self._on_geometry_live_changed()

    def eventFilter(self, obj: Any, event: Any) -> bool:
        if obj is getattr(self, "btn_connect", None):
            if self.preview_mode:
                return super().eventFilter(obj, event)
            etype = event.type()
            btn_press = qt_enum(QtCore.QEvent, "Type", "MouseButtonPress")
            mouse_move = qt_enum(QtCore.QEvent, "Type", "MouseMove")
            btn_rel = qt_enum(QtCore.QEvent, "Type", "MouseButtonRelease")
            left_btn = qt_enum(Qt, "MouseButton", "LeftButton")

            if etype == btn_press and event.button() == left_btn:
                gpos = mouse_global_pos(event)
                self._connect_press_pos = gpos
                self._connect_dragging = False
                return True
            if etype == mouse_move and self._connect_press_pos is not None:
                gpos = mouse_global_pos(event)
                delta = gpos - self._connect_press_pos
                if abs(delta.x()) + abs(delta.y()) > 8:
                    self._connect_dragging = True
                    self.btn_connect.setCursor(qt_enum(Qt, "CursorShape", "CrossCursor"))
                    if self._on_connect_drag_move:
                        self._on_connect_drag_move(self.item_id, gpos)
                return True
            if etype == btn_rel and self._connect_press_pos is not None:
                gpos = mouse_global_pos(event)
                was_drag = self._connect_dragging
                self._connect_press_pos = None
                self._connect_dragging = False
                self.btn_connect.setCursor(qt_enum(Qt, "CursorShape", "PointingHandCursor"))
                if was_drag and self._on_connect_dragged:
                    self._on_connect_dragged(self.item_id, gpos)
                elif not was_drag and self._on_connect_clicked:
                    self._on_connect_clicked(self.item_id)
                return True
            return super().eventFilter(obj, event)

        if obj is self.title_bar:
            if self.preview_mode:
                return super().eventFilter(obj, event)
            etype = event.type()
            btn_press = qt_enum(QtCore.QEvent, "Type", "MouseButtonPress")
            mouse_move = qt_enum(QtCore.QEvent, "Type", "MouseMove")
            btn_rel = qt_enum(QtCore.QEvent, "Type", "MouseButtonRelease")
            dbl_click = qt_enum(QtCore.QEvent, "Type", "MouseButtonDblClick")
            left_btn = qt_enum(Qt, "MouseButton", "LeftButton")

            if etype == dbl_click and self._on_edit:
                self._on_edit()
                return True
            if etype == btn_press and event.button() == left_btn:
                gpos = mouse_global_pos(event)
                self._drag_offset = gpos - self.pos()
                self.title_bar.setCursor(qt_enum(Qt, "CursorShape", "ClosedHandCursor"))
                self.raise_()
                return True
            if etype == mouse_move and self._drag_offset is not None:
                gpos = mouse_global_pos(event)
                new_pt = gpos - self._drag_offset
                nx_scr = max(8, new_pt.x())
                ny_scr = max(8, new_pt.y())
                self.move(nx_scr, ny_scr)
                cur_lw = self._logical_rect[2] if self._logical_rect else max(self._min_w, self._to_logical_val(self.width()))
                cur_lh = self._logical_rect[3] if self._logical_rect else max(self._min_h, self._to_logical_val(self.height()))
                self._logical_rect = (max(8, self._to_logical_val(nx_scr)), max(8, self._to_logical_val(ny_scr)), cur_lw, cur_lh)
                if self._on_geometry_live_changed:
                    self._on_geometry_live_changed()
                p = self.parentWidget()
                while p is not None:
                    if hasattr(p, "expand_to_fit"):
                        p.expand_to_fit()
                        break
                    p = p.parentWidget()
                return True
            if etype == btn_rel and self._drag_offset is not None:
                self._drag_offset = None
                self.title_bar.setCursor(qt_enum(Qt, "CursorShape", "OpenHandCursor"))
                lx = self._snap_logical(self._to_logical_val(self.x()))
                ly = self._snap_logical(self._to_logical_val(self.y()))
                cur_lw = self._logical_rect[2] if self._logical_rect else max(self._min_w, self._to_logical_val(self.width()))
                cur_lh = self._logical_rect[3] if self._logical_rect else max(self._min_h, self._to_logical_val(self.height()))
                self._logical_rect = (lx, ly, cur_lw, cur_lh)
                self.move(self._to_screen_val(lx), self._to_screen_val(ly))
                self._emit_geom()
                return True
        return super().eventFilter(obj, event)

    def _edge_hit(self, pos: QPointF) -> Optional[str]:
        if self.preview_mode:
            return None
        right = pos.x() >= self.width() - self.EDGE_MARGIN
        bottom = pos.y() >= self.height() - self.EDGE_MARGIN
        left = pos.x() <= self.EDGE_MARGIN
        top = pos.y() <= self.EDGE_MARGIN
        if right and bottom:
            return "corner"
        if left and top:
            return "top_left"
        if right and top:
            return "top_right"
        if left and bottom:
            return "bottom_left"
        if right:
            return "right"
        if bottom:
            return "bottom"
        if left:
            return "left"
        if top:
            return "top"
        return None

    def mousePressEvent(self, event: Any) -> None:
        if event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            edge = self._edge_hit(mouse_pos_f(event))
            if edge:
                self.begin_resize(edge, mouse_global_pos(event))
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: Any) -> None:
        if self._resize_mode:
            self.step_resize(mouse_global_pos(event))
            event.accept()
            return
        edge = self._edge_hit(mouse_pos_f(event))
        if edge in ("corner", "top_left"):
            self.setCursor(qt_enum(Qt, "CursorShape", "SizeFDiagCursor"))
        elif edge in ("top_right", "bottom_left"):
            self.setCursor(qt_enum(Qt, "CursorShape", "SizeBDiagCursor"))
        elif edge in ("right", "left"):
            self.setCursor(qt_enum(Qt, "CursorShape", "SizeHorCursor"))
        elif edge in ("bottom", "top"):
            self.setCursor(qt_enum(Qt, "CursorShape", "SizeVerCursor"))
        else:
            self.setCursor(qt_enum(Qt, "CursorShape", "ArrowCursor"))
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: Any) -> None:
        if self._resize_mode:
            self.end_resize()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def contextMenuEvent(self, event: Any) -> None:
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            return
        lang = getattr(self, "lang", "et") or "et"
        menu = QMenuCls(self)
        act_edit = menu.addAction(tr("ctx_edit_settings", lang)) if self._on_edit else None
        act_refresh = menu.addAction(tr("ctx_refresh_widget", lang)) if getattr(self, "_on_refresh", None) else None
        act_conn = menu.addAction(tr("ctx_connections", lang)) if self._on_connect_clicked else None
        act_leg = (
            menu.addAction(tr("ctx_legend_settings", lang))
            if isinstance(getattr(self, "body_widget", None), DashboardMapWidget)
            else None
        )
        act_lock = None
        if any(getattr(self, "_adjacent_edges", (False, False, False, False))) and callable(self._on_toggle_border_locks):
            has_locked = any(
                callable(self._is_edge_locked) and self._is_edge_locked(self.item_id, ed)
                for ed in ("top", "right", "bottom", "left")
            )
            act_lock = menu.addAction(tr("ctx_unlock_borders" if has_locked else "ctx_lock_borders", lang))
        act_del = None
        if self._on_delete:
            menu.addSeparator()
            act_del = menu.addAction(tr("ctx_remove", lang))
        from .qt_compat import exec_menu
        chosen = exec_menu(menu, event.globalPos())
        if chosen is None:
            return
        if act_edit is not None and chosen == act_edit:
            self._on_edit()
        elif act_refresh is not None and chosen == act_refresh:
            self._on_refresh()
        elif act_conn is not None and chosen == act_conn:
            self._on_connect_clicked(self.item_id)
        elif act_leg is not None and chosen == act_leg:
            self.body_widget._open_style_legend_dialog()
        elif act_lock is not None and chosen == act_lock:
            self._on_toggle_border_locks(self.item_id)
        elif act_del is not None and chosen == act_del:
            self._on_delete(self.item_id)


def _cand_to_wgs84_geom_and_bbox(
    cand: Dict[str, Any]
) -> Tuple[Optional[Dict[str, Any]], Optional[Tuple[float, float, float, float]]]:
    """
    Extract (geojson_geometry_wgs84, (xmin, ymin, xmax, ymax)_wgs84) from an In-Aadress result (#15).
    Uses QgsCoordinateTransform inside QGIS when coordinates are in EPSG:3301 (L-EST97), or builds
    a geodesic parcel/address box around (lon, lat) cleanly in any environment.
    """
    geom_raw = cand.get("geometry")
    lat = cand.get("lat")
    lon = cand.get("lon")
    bbox_3301 = cand.get("bbox_3301")

    def _transform_coords_if_needed(coords: Any, xform: Any) -> Any:
        if isinstance(coords, (list, tuple)) and len(coords) >= 2 and isinstance(coords[0], (int, float)):
            xv, yv = float(coords[0]), float(coords[1])
            if abs(xv) > 1000.0 or abs(yv) > 1000.0:
                if xform is not None:
                    # L-EST97 Easting ~300k..800k, Northing ~6.3M..6.7M
                    pt_in = (yv, xv) if (xv > 3000000.0 and yv < 1000000.0) else (xv, yv)
                    pt = xform.transform(pt_in[0], pt_in[1])
                    return [round(float(pt.x()), 6), round(float(pt.y()), 6)]
                return [round(xv, 6), round(yv, 6)]
            return [round(xv, 6), round(yv, 6)]
        if isinstance(coords, (list, tuple)):
            return [_transform_coords_if_needed(c, xform) for c in coords]
        return coords

    xform_obj = None
    wgs_bbox: Optional[Tuple[float, float, float, float]] = None
    try:
        from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle

        lest = QgsCoordinateReferenceSystem("EPSG:3301")
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        xform_obj = QgsCoordinateTransform(lest, wgs84, QgsProject.instance())
        if isinstance(bbox_3301, (list, tuple)) and len(bbox_3301) == 4:
            rect = QgsRectangle(float(bbox_3301[0]), float(bbox_3301[1]), float(bbox_3301[2]), float(bbox_3301[3]))
            rect_w = xform_obj.transformBoundingBox(rect)
            wgs_bbox = (
                round(float(rect_w.xMinimum()), 6),
                round(float(rect_w.yMinimum()), 6),
                round(float(rect_w.xMaximum()), 6),
                round(float(rect_w.yMaximum()), 6),
            )
    except Exception:
        xform_obj = None

    wgs_geom: Optional[Dict[str, Any]] = None
    if isinstance(geom_raw, dict) and geom_raw.get("coordinates"):
        # Check whether raw geom is already WGS84 or EPSG:3301
        raw_str = json.dumps(geom_raw.get("coordinates"))[:80]
        is_projected = any(len(tok.split(".")[0].lstrip("-")) >= 5 for tok in re.findall(r"-?\d+(?:\.\d+)?", raw_str)) if "re" in globals() else False
        if not is_projected or xform_obj is not None:
            wgs_geom = {
                "type": geom_raw.get("type", "Polygon"),
                "coordinates": _transform_coords_if_needed(geom_raw.get("coordinates"), xform_obj),
            }
            if wgs_bbox is None:
                from ..core.spatial_overlap import geojson_bbox_wgs84
                wgs_bbox = geojson_bbox_wgs84(wgs_geom)

    if wgs_bbox is None and lat is not None and lon is not None:
        try:
            flat, flon = float(lat), float(lon)
            if isinstance(bbox_3301, (list, tuple)) and len(bbox_3301) == 4:
                dx_m = max(35.0, (float(bbox_3301[2]) - float(bbox_3301[0])) * 0.5)
                dy_m = max(35.0, (float(bbox_3301[3]) - float(bbox_3301[1])) * 0.5)
            else:
                dx_m, dy_m = 60.0, 60.0
            dlon = dx_m / max(45000.0, 111320.0 * math.cos(math.radians(flat)))
            dlat = dy_m / 111320.0
            wgs_bbox = (
                round(flon - dlon, 6),
                round(flat - dlat, 6),
                round(flon + dlon, 6),
                round(flat + dlat, 6),
            )
        except (TypeError, ValueError):
            pass

    if wgs_geom is None and wgs_bbox is not None:
        x0, y0, x1, y1 = wgs_bbox
        wgs_geom = {
            "type": "Polygon",
            "coordinates": [[[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]],
        }
    return wgs_geom, wgs_bbox


class SlicerCardWidget(QFrame):
    """Draggable & resizable filter card with cascading category chips/list, numeric range, or date range."""

    def __init__(
        self,
        slicer_cfg: SlicerConfig,
        filter_bus: FilterBus,
        lang: str = "et",
        layer_records_provider: Optional[Callable[[str], List[Dict[str, Any]]]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = slicer_cfg
        self.slicer_cfg = slicer_cfg
        self.filter_bus = filter_bus
        self.lang = lang
        self.layer_records_provider = layer_records_provider
        self._cats: List[str] = []
        self._handling_item_change: bool = False
        self._num_bounds: Tuple[float, float] = (0.0, 100.0)
        self._date_bounds: Tuple[str, str] = ("", "")
        self._pane_widgets: List[Dict[str, Any]] = []
        self._rendered_panes_sig: Optional[str] = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(5)

        self.single_container = QWidget()
        single_lay = QVBoxLayout(self.single_container)
        single_lay.setContentsMargins(0, 0, 0, 0)
        single_lay.setSpacing(5)

        top = QHBoxLayout()
        self.combo = QComboBox()
        self.combo.setMinimumWidth(80)
        self.combo.currentIndexChanged.connect(self._on_combo_changed)
        top.addWidget(self.combo, 1)

        self.btn_mode = QPushButton("☰")
        self.btn_mode.setFixedSize(26, 24)
        self.btn_mode.setProperty("btnRole", "miniStep")
        self.btn_mode.setCheckable(True)
        self.btn_mode.setChecked(getattr(slicer_cfg, "display_mode", "chips") == "list")
        self.btn_mode.setToolTip(tr("lbl_slicer_style", lang))
        self.btn_mode.clicked.connect(self._toggle_display_mode)
        top.addWidget(self.btn_mode)

        self.btn_clear = QPushButton("×")
        self.btn_clear.setFixedSize(26, 24)
        self.btn_clear.setProperty("btnRole", "miniStep")
        self.btn_clear.clicked.connect(self._on_clear_clicked)
        top.addWidget(self.btn_clear)
        single_lay.addLayout(top)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(tr("ph_slicer_search", lang))
        self.search_input.textChanged.connect(self._apply_search_filter)
        single_lay.addWidget(self.search_input)

        self.chips_scroll = QScrollArea()
        self.chips_scroll.setWidgetResizable(True)
        self.chips_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        self.chips_host = QWidget()
        self.chips_layout = QHBoxLayout(self.chips_host)
        self.chips_layout.setContentsMargins(0, 0, 0, 0)
        self.chips_layout.setSpacing(4)
        self.chips_scroll.setWidget(self.chips_host)
        single_lay.addWidget(self.chips_scroll, 1)

        self.list_widget = QListWidget()
        self.list_widget.itemChanged.connect(self._on_list_item_changed)
        if hasattr(getattr(self.list_widget, "itemClicked", None), "connect"):
            self.list_widget.itemClicked.connect(self._on_list_item_clicked)
        single_lay.addWidget(self.list_widget, 1)

        # Numeric Range & Date Range Panel
        self.range_panel = QWidget()
        rp_v = QVBoxLayout(self.range_panel)
        rp_v.setContentsMargins(0, 0, 0, 0)
        rp_v.setSpacing(4)
        self.lbl_range_bounds = QLabel("")
        self.lbl_range_bounds.setProperty("role", "mutedTiny")
        rp_v.addWidget(self.lbl_range_bounds)

        self.num_row = QWidget()
        nr_l = QHBoxLayout(self.num_row)
        nr_l.setContentsMargins(0, 0, 0, 0)
        nr_l.setSpacing(4)
        self.lbl_num_min = QLabel(tr("range_min", lang) + ":")
        if QDoubleSpinBox is not None:
            self.sp_num_min: Any = QDoubleSpinBox()
            self.sp_num_min.setDecimals(2)
            self.sp_num_min.setRange(-1e12, 1e12)
            self.sp_num_max: Any = QDoubleSpinBox()
            self.sp_num_max.setDecimals(2)
            self.sp_num_max.setRange(-1e12, 1e12)
        else:
            self.sp_num_min = QLineEdit()
            self.sp_num_max = QLineEdit()
        self.lbl_num_max = QLabel(tr("range_max", lang) + ":")
        nr_l.addWidget(self.lbl_num_min)
        nr_l.addWidget(self.sp_num_min, 1)
        nr_l.addWidget(self.lbl_num_max)
        nr_l.addWidget(self.sp_num_max, 1)
        rp_v.addWidget(self.num_row)

        self.date_row = QWidget()
        dr_l = QHBoxLayout(self.date_row)
        dr_l.setContentsMargins(0, 0, 0, 0)
        dr_l.setSpacing(4)
        self.lbl_date_from = QLabel(tr("range_from", lang) + ":")
        self.ed_date_min = QLineEdit()
        self.ed_date_min.setPlaceholderText("YYYY-MM-DD")
        self.lbl_date_to = QLabel(tr("range_to", lang) + ":")
        self.ed_date_max = QLineEdit()
        self.ed_date_max.setPlaceholderText("YYYY-MM-DD")
        dr_l.addWidget(self.lbl_date_from)
        dr_l.addWidget(self.ed_date_min, 1)
        dr_l.addWidget(self.lbl_date_to)
        dr_l.addWidget(self.ed_date_max, 1)
        rp_v.addWidget(self.date_row)

        rp_btns = QHBoxLayout()
        rp_btns.setContentsMargins(0, 0, 0, 0)
        rp_btns.setSpacing(4)
        self.btn_range_apply = QPushButton(tr("range_apply", lang))
        self.btn_range_apply.setProperty("btnRole", "primary")
        self.btn_range_apply.clicked.connect(self._apply_range_filter)
        self.btn_range_reset = QPushButton(tr("range_reset", lang))
        self.btn_range_reset.clicked.connect(self._on_clear_clicked)
        rp_btns.addWidget(self.btn_range_apply, 1)
        rp_btns.addWidget(self.btn_range_reset)
        rp_v.addLayout(rp_btns)
        rp_v.addStretch()
        single_lay.addWidget(self.range_panel, 1)

        layout.addWidget(self.single_container, 1)

        # Multi-Pane Filter Container (#15)
        self.multi_panes_container = QWidget()
        self.multi_panes_layout = QHBoxLayout(self.multi_panes_container)
        self.multi_panes_layout.setContentsMargins(0, 0, 0, 0)
        self.multi_panes_layout.setSpacing(8)
        self.multi_panes_container.hide()
        layout.addWidget(self.multi_panes_container, 1)

        self._sync_mode_visibility()

    def _on_clear_clicked(self) -> None:
        self.filter_bus.clear_filter(self.config.id)
        for p_idx in range(len(getattr(self.config, "panes", []) or [])):
            self.filter_bus.clear_filter(f"{self.config.id}__pane_{p_idx}")

    @staticmethod
    def _set_spin_or_edit(widget: Any, value: Any) -> None:
        if hasattr(widget, "setValue") and isinstance(value, (int, float)):
            widget.blockSignals(True)
            widget.setValue(float(value))
            widget.blockSignals(False)
        elif hasattr(widget, "setText"):
            widget.blockSignals(True)
            widget.setText("" if value is None else str(value))
            widget.blockSignals(False)

    @staticmethod
    def _get_spin_or_edit_float(widget: Any) -> Optional[float]:
        if hasattr(widget, "value"):
            try:
                return float(widget.value())
            except Exception:
                return None
        if hasattr(widget, "text"):
            txt = str(widget.text() or "").strip().replace(",", ".")
            if not txt:
                return None
            try:
                return float(txt)
            except ValueError:
                return None
        return None

    def _apply_range_filter(self) -> None:
        stype = str(getattr(self.config, "slicer_type", "category") or "category")
        pg = str(getattr(self.config, "page_id", "page_1") or "page_1")
        is_glob = bool(getattr(self.config, "is_global", False))
        if stype == "numeric_range":
            vmin = self._get_spin_or_edit_float(self.sp_num_min)
            vmax = self._get_spin_or_edit_float(self.sp_num_max)
            if vmin is not None and vmax is not None and vmin > vmax:
                vmin, vmax = vmax, vmin
            self.filter_bus.set_range_filter(
                source_id=self.config.id,
                layer_name=self.config.layer_name,
                field_name=self.config.field_name,
                filter_type="numeric_range",
                min_value=vmin,
                max_value=vmax,
                page_id=pg,
                is_global=is_glob,
            )
        elif stype == "date_range":
            dmin = self.ed_date_min.text().strip() or None
            dmax = self.ed_date_max.text().strip() or None
            if dmin and dmax and dmin > dmax:
                dmin, dmax = dmax, dmin
            self.filter_bus.set_range_filter(
                source_id=self.config.id,
                layer_name=self.config.layer_name,
                field_name=self.config.field_name,
                filter_type="date_range",
                min_value=dmin,
                max_value=dmax,
                page_id=pg,
                is_global=is_glob,
            )

    def _toggle_display_mode(self) -> None:
        self.config.display_mode = "list" if self.btn_mode.isChecked() else "chips"
        self._sync_mode_visibility()
        self._rebuild_options()

    def _sync_mode_visibility(self) -> None:
        has_panes = bool(getattr(self.config, "panes", None))
        if hasattr(self, "single_container"):
            self.single_container.setVisible(not has_panes)
        if hasattr(self, "multi_panes_container"):
            self.multi_panes_container.setVisible(has_panes)
        if has_panes:
            return
        stype = str(getattr(self.config, "slicer_type", "category") or "category")
        is_range = stype in ("numeric_range", "date_range")
        is_list = (not is_range) and (getattr(self.config, "display_mode", "chips") == "list")
        self.combo.setVisible(not is_range)
        self.btn_mode.setVisible(not is_range)
        self.btn_mode.setChecked(is_list)
        show_search = (not is_range) and bool(getattr(self.config, "show_search", True)) and (is_list or len(self._cats) > 6)
        self.search_input.setVisible((not is_range) and (show_search or is_list))
        self.chips_scroll.setVisible((not is_range) and (not is_list))
        self.list_widget.setVisible((not is_range) and is_list)
        self.range_panel.setVisible(is_range)
        self.num_row.setVisible(stype == "numeric_range")
        self.date_row.setVisible(stype == "date_range")

    def _rebuild_multi_panes_ui(self, panes: List[Dict[str, Any]], lang: str) -> None:
        while self.multi_panes_layout.count():
            item = self.multi_panes_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._pane_widgets = []
        pg = str(getattr(self.config, "page_id", "page_1") or "page_1")
        is_glob = bool(getattr(self.config, "is_global", False))

        for p_idx, pane in enumerate(panes):
            ptype = str(pane.get("pane_type") or pane.get("type") or "field")
            ptitle = str(pane.get("title") or pane.get("field_name") or (tr("addr_search_btn", lang) if ptype == "address" else f"Pane {p_idx + 1}"))
            src_id = self.config.id if (len(panes) == 1 and pane.get("merged")) else f"{self.config.id}__pane_{p_idx}"

            frame = QFrame()
            frame.setObjectName("FrameCard")
            flay = QVBoxLayout(frame)
            flay.setContentsMargins(6, 5, 6, 5)
            flay.setSpacing(4)

            hdr = QHBoxLayout()
            lbl = QLabel(ptitle)
            lbl.setProperty("role", "cardTitleSmall")
            hdr.addWidget(lbl, 1)
            btn_x = QPushButton("×")
            btn_x.setFixedSize(20, 20)
            btn_x.setProperty("btnRole", "miniStep")
            btn_x.clicked.connect(lambda _c=False, sid=src_id: self.filter_bus.clear_filter(sid))
            hdr.addWidget(btn_x)
            flay.addLayout(hdr)

            if ptype == "address":
                ed = QLineEdit()
                ed.setPlaceholderText(tr("addr_search_ph", lang))
                btn_s = QPushButton("🔍")
                btn_s.setFixedSize(26, 22)
                btn_s.setProperty("btnRole", "miniTool")
                srow = QHBoxLayout()
                srow.addWidget(ed, 1)
                srow.addWidget(btn_s)
                flay.addLayout(srow)
                lw = QListWidget()
                lw.setMaximumHeight(95)
                lw.hide()
                flay.addWidget(lw, 1)

                def _do_addr_search(edit_w=ed, list_w=lw, lang_c=lang) -> None:
                    q = edit_w.text().strip()
                    if len(q) < 2:
                        list_w.clear()
                        list_w.hide()
                        return
                    list_w.clear()
                    list_w.addItem(tr("addr_searching", lang_c))
                    list_w.show()
                    try:
                        res = search_estonian_address(q, limit=6)
                    except Exception:
                        res = []
                    list_w.clear()
                    role = qt_enum(Qt, "ItemDataRole", "UserRole")
                    for cand in res:
                        tag = f"[{cand['type']}] " if cand.get("type") else ""
                        it = QListWidgetItem(f"{tag}{cand.get('label', '')}")
                        it.setData(role, cand)
                        list_w.addItem(it)
                    if not res:
                        list_w.addItem(tr("addr_no_results", lang_c))

                def _on_addr_pick(item: QListWidgetItem, edit_w=ed, list_w=lw, sid=src_id, ttl=ptitle) -> None:
                    role = qt_enum(Qt, "ItemDataRole", "UserRole")
                    cand = item.data(role) if item is not None else None
                    if not isinstance(cand, dict):
                        return
                    label_txt = str(cand.get("label") or "")
                    edit_w.setText(label_txt)
                    list_w.hide()
                    geom_wgs, bbox_wgs = _cand_to_wgs84_geom_and_bbox(cand)
                    if geom_wgs or bbox_wgs:
                        self.filter_bus.set_filter(
                            ActiveFilter(
                                source_id=sid,
                                layer_name="__spatial__",
                                field_name=str(pane.get("field_name") or "kataster"),
                                filter_type="spatial_geom",
                                bbox=bbox_wgs,
                                geometry=geom_wgs,
                                display_label=f"📍 {label_txt[:28]}",
                                page_id=pg,
                                is_global=is_glob,
                            )
                        )

                ed.returnPressed.connect(_do_addr_search)
                btn_s.clicked.connect(_do_addr_search)
                lw.itemClicked.connect(_on_addr_pick)
                self._pane_widgets.append({"type": "address", "source_id": src_id, "pane": pane, "edit": ed, "list": lw})
            else:
                ed = QLineEdit()
                ed.setPlaceholderText(tr("ph_slicer_search", lang))
                flay.addWidget(ed)
                lw = QListWidget()
                flay.addWidget(lw, 1)
                self._pane_widgets.append({"type": "field", "source_id": src_id, "pane": pane, "edit": ed, "list": lw, "cats": []})
                ed.textChanged.connect(lambda _t, p_idx_c=p_idx: self._render_field_pane_list(p_idx_c))
                lw.itemChanged.connect(lambda it, p_idx_c=p_idx: self._on_field_pane_item_changed(p_idx_c, it))
                if hasattr(getattr(lw, "itemClicked", None), "connect"):
                    lw.itemClicked.connect(lambda it: self._on_list_item_clicked(it))

            self.multi_panes_layout.addWidget(frame, 1)

    def _render_field_pane_list(self, pane_idx: int) -> None:
        if pane_idx < 0 or pane_idx >= len(self._pane_widgets):
            return
        pw = self._pane_widgets[pane_idx]
        if pw.get("type") != "field":
            return
        lw: QListWidget = pw["list"]
        ed: QLineEdit = pw["edit"]
        src_id = pw["source_id"]
        needle = ed.text().strip().lower()
        selected = set(str(v) for v in self.filter_bus.get_selected_values(src_id))
        cats = [c for c in pw.get("cats", []) if not needle or needle in c.lower()]
        lw.blockSignals(True)
        lw.clear()
        check_flag = qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable")
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        unchecked_st = qt_enum(Qt, "CheckState", "Unchecked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        none_it = QListWidgetItem(tr("slicer_no_filter", self.lang))
        none_it.setFlags(none_it.flags() | check_flag)
        none_it.setCheckState(checked_st if not selected else unchecked_st)
        none_it.setData(role, "__NO_FILTER__")
        lw.addItem(none_it)
        for c in cats:
            is_sel = c in selected
            it = QListWidgetItem(c)
            it.setFlags(it.flags() | check_flag)
            it.setCheckState(checked_st if is_sel else unchecked_st)
            it.setData(role, bool(is_sel))
            lw.addItem(it)
        lw.blockSignals(False)

    def _on_field_pane_item_changed(self, pane_idx: int, item: QListWidgetItem) -> None:
        if item is None or pane_idx < 0 or pane_idx >= len(self._pane_widgets):
            return
        pw = self._pane_widgets[pane_idx]
        src_id = pw["source_id"]
        pane = pw["pane"]
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        val = item.text()
        if item.data(role) == "__NO_FILTER__":
            self.filter_bus.clear_filter(src_id)
            return
        lw = pw["list"]
        lw.blockSignals(True)
        item.setData(role, bool(item.checkState() == checked_st))
        lw.blockSignals(False)
        self.filter_bus.toggle_category_value(
            source_id=src_id,
            layer_name=str(pane.get("layer_name") or self.config.layer_name),
            field_name=str(pane.get("field_name") or self.config.field_name),
            value=val,
            multi=bool(pane.get("multi_select", self.config.multi_select)),
            page_id=str(getattr(self.config, "page_id", "page_1") or "page_1"),
            is_global=bool(getattr(self.config, "is_global", False)),
            layer_fields=list(pane.get("sources") or []),
        )

    def refresh_data(
        self,
        records: List[Dict[str, Any]],
        lang: str = "et",
        all_records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    ) -> None:
        self.lang = lang
        raw_panes = list(getattr(self.config, "panes", []) or [])
        if raw_panes:
            recs_map: Dict[str, List[Dict[str, Any]]] = (
                dict(all_records_by_layer)
                if isinstance(all_records_by_layer, dict)
                else {}
            )
            if not recs_map and callable(self.layer_records_provider):
                for rp in raw_panes:
                    if isinstance(rp, dict):
                        ln_rp = str(rp.get("layer_name") or "").strip()
                        if ln_rp and ln_rp != "__spatial__" and ln_rp not in recs_map:
                            recs_map[ln_rp] = self.layer_records_provider(ln_rp) or []
            panes = group_slicer_panes(
                raw_panes,
                merge_shared_fields=bool(getattr(self.config, "merge_shared_fields", True)),
                layer_records_by_layer=recs_map,
                fallback_display_mode=str(getattr(self.config, "display_mode", "list") or "list"),
                fallback_multi_select=bool(getattr(self.config, "multi_select", True)),
            )
            sig = json.dumps(panes, sort_keys=True, ensure_ascii=False)
            if sig != getattr(self, "_rendered_panes_sig", None):
                self._rebuild_multi_panes_ui(panes, lang)
                self._rendered_panes_sig = sig
            self._sync_mode_visibility()
            for pw in self._pane_widgets:
                if pw.get("type") != "field":
                    continue
                pane = pw["pane"]
                sources = list(pane.get("sources") or [])
                if not sources:
                    sources = [{
                        "layer_name": str(pane.get("layer_name") or self.config.layer_name),
                        "field_name": str(pane.get("field_name") or self.config.field_name),
                    }]
                cat_union: set = set()
                for src_entry in sources:
                    lname = str(src_entry.get("layer_name") or self.config.layer_name)
                    fname = str(src_entry.get("field_name") or self.config.field_name)
                    p_recs = (
                        recs_map.get(lname, records)
                        if lname in recs_map
                        else (self.layer_records_provider(lname) if callable(self.layer_records_provider) else records)
                    )
                    eff = (
                        self.filter_bus.filter_records(p_recs or [], layer_name=lname, exclude_source_id=pw["source_id"])
                        if (bool(getattr(self.config, "cascade_filters", True)) and self.filter_bus)
                        else (p_recs or [])
                    )
                    cat_union.update(Aggregator.distinct_categories(eff, fname))
                sel = set(str(v) for v in self.filter_bus.get_selected_values(pw["source_id"]))
                cats = sorted(cat_union | sel) if sel else sorted(cat_union)
                pw["cats"] = cats
                self._render_field_pane_list(self._pane_widgets.index(pw))
            return

        stype = str(getattr(self.config, "slicer_type", "category") or "category")
        if stype == "numeric_range":
            bmin, bmax = Aggregator.numeric_bounds(records, self.config.field_name)
            self._num_bounds = (bmin, bmax)
            flt = self.filter_bus._filters.get(self.config.id) if self.filter_bus else None
            cmin = flt.min_value if (flt and flt.filter_type == "numeric_range" and flt.min_value is not None) else bmin
            cmax = flt.max_value if (flt and flt.filter_type == "numeric_range" and flt.max_value is not None) else bmax
            if hasattr(self.sp_num_min, "setRange") and hasattr(self.sp_num_max, "setRange"):
                self.sp_num_min.setRange(min(-1e12, bmin - 1000.0), max(1e12, bmax + 1000.0))
                self.sp_num_max.setRange(min(-1e12, bmin - 1000.0), max(1e12, bmax + 1000.0))
            self._set_spin_or_edit(self.sp_num_min, cmin)
            self._set_spin_or_edit(self.sp_num_max, cmax)
            self.lbl_range_bounds.setText(f"{bmin:,.2f} … {bmax:,.2f}")
            self.btn_range_apply.setText(tr("range_apply", lang))
            self.btn_range_reset.setText(tr("range_reset", lang))
            self._sync_mode_visibility()
            return
        if stype == "date_range":
            dmin, dmax = Aggregator.date_bounds(records, self.config.field_name)
            self._date_bounds = (dmin, dmax)
            flt = self.filter_bus._filters.get(self.config.id) if self.filter_bus else None
            cmin = str(flt.min_value) if (flt and flt.filter_type == "date_range" and flt.min_value is not None) else dmin
            cmax = str(flt.max_value) if (flt and flt.filter_type == "date_range" and flt.max_value is not None) else dmax
            self._set_spin_or_edit(self.ed_date_min, cmin)
            self._set_spin_or_edit(self.ed_date_max, cmax)
            self.lbl_range_bounds.setText(f"{dmin or '—'} … {dmax or '—'}")
            self.btn_range_apply.setText(tr("range_apply", lang))
            self.btn_range_reset.setText(tr("range_reset", lang))
            self._sync_mode_visibility()
            return

        self.search_input.setPlaceholderText(tr("ph_slicer_search", lang))
        eff_records = records
        if bool(getattr(self.config, "cascade_filters", True)) and self.filter_bus is not None:
            eff_records = self.filter_bus.filter_records(
                records,
                layer_name=self.config.layer_name,
                exclude_source_id=self.config.id,
            )
        selected = set(str(v) for v in self.filter_bus.get_selected_values(self.config.id))
        cats = Aggregator.distinct_categories(eff_records, self.config.field_name)
        if selected:
            missing_sel = sorted(s for s in selected if s not in cats)
            cats = sorted(set(cats) | set(missing_sel)) if missing_sel else cats
        self._cats = cats

        self.combo.blockSignals(True)
        self.combo.clear()
        self.combo.addItem(tr("slicer_no_filter", lang), "")
        for c in self._cats:
            self.combo.addItem(c, c)
        if selected:
            first = next(iter(selected))
            idx = self.combo.findData(first)
            if idx >= 0:
                self.combo.setCurrentIndex(idx)
        self.combo.blockSignals(False)

        self._sync_mode_visibility()
        self._rebuild_options()

    def _rebuild_options(self) -> None:
        selected = set(str(v) for v in self.filter_bus.get_selected_values(self.config.id))
        needle = self.search_input.text().strip().lower()
        filtered = [c for c in self._cats if not needle or needle in c.lower()]
        is_list = getattr(self.config, "display_mode", "chips") == "list"
        no_filter_label = tr("slicer_no_filter", getattr(self, "lang", "et"))

        if is_list:
            self.list_widget.blockSignals(True)
            self.list_widget.clear()
            check_flag = qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable")
            checked_st = qt_enum(Qt, "CheckState", "Checked")
            unchecked_st = qt_enum(Qt, "CheckState", "Unchecked")
            role = qt_enum(Qt, "ItemDataRole", "UserRole")
            none_it = QListWidgetItem(no_filter_label)
            none_it.setFlags(none_it.flags() | check_flag)
            none_it.setCheckState(checked_st if not selected else unchecked_st)
            none_it.setData(role, "__NO_FILTER__")
            self.list_widget.addItem(none_it)
            for c in filtered:
                is_sel = c in selected
                it = QListWidgetItem(c)
                it.setFlags(it.flags() | check_flag)
                it.setCheckState(checked_st if is_sel else unchecked_st)
                it.setData(role, bool(is_sel))
                self.list_widget.addItem(it)
            self.list_widget.blockSignals(False)
            return

        while self.chips_layout.count():
            item = self.chips_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        pg = str(getattr(self.config, "page_id", "page_1") or "page_1")
        is_glob = bool(getattr(self.config, "is_global", False))
        for c in filtered:
            btn = QPushButton(c)
            btn.setCheckable(True)
            btn.setChecked(c in selected)
            btn.setProperty("btnRole", "chip")
            btn.clicked.connect(
                lambda _chk, val=c: self.filter_bus.toggle_category_value(
                    source_id=self.config.id,
                    layer_name=self.config.layer_name,
                    field_name=self.config.field_name,
                    value=val,
                    multi=self.config.multi_select,
                    page_id=pg,
                    is_global=is_glob,
                )
            )
            self.chips_layout.addWidget(btn)
        self.chips_layout.addStretch()

    def _apply_search_filter(self, _text: str) -> None:
        self._rebuild_options()

    def _on_list_item_changed(self, item: QListWidgetItem) -> None:
        if item is None or getattr(self, "_handling_item_change", False):
            return
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        try:
            value = item.text()
            is_checked = bool(item.checkState() == checked_st)
            item_role_val = item.data(role)
        except RuntimeError:
            return
        self._handling_item_change = True
        lw = getattr(self, "list_widget", None)
        was_blocked = False
        try:
            if item_role_val == "__NO_FILTER__":
                if lw is not None and hasattr(lw, "blockSignals"):
                    was_blocked = bool(lw.blockSignals(True))
                try:
                    if not is_checked and not self.filter_bus.get_selected_values(self.config.id):
                        item.setCheckState(checked_st)
                except RuntimeError:
                    return
                finally:
                    if lw is not None and hasattr(lw, "blockSignals"):
                        lw.blockSignals(was_blocked)
                self.filter_bus.clear_filter(self.config.id)
                return
            if lw is not None and hasattr(lw, "blockSignals"):
                was_blocked = bool(lw.blockSignals(True))
            try:
                item.setData(role, is_checked)
            except RuntimeError:
                return
            finally:
                if lw is not None and hasattr(lw, "blockSignals"):
                    lw.blockSignals(was_blocked)
            self.filter_bus.toggle_category_value(
                source_id=self.config.id,
                layer_name=self.config.layer_name,
                field_name=self.config.field_name,
                value=value,
                multi=self.config.multi_select,
                page_id=str(getattr(self.config, "page_id", "page_1") or "page_1"),
                is_global=bool(getattr(self.config, "is_global", False)),
            )
        finally:
            self._handling_item_change = False

    def _on_list_item_clicked(self, item: QListWidgetItem) -> None:
        if item is None:
            return
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        unchecked_st = qt_enum(Qt, "CheckState", "Unchecked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        try:
            cur_checked = bool(item.checkState() == checked_st)
            prev_checked = item.data(role)
            if prev_checked == "__NO_FILTER__":
                self.filter_bus.clear_filter(self.config.id)
                return
            # If user clicked the text label rather than the checkbox box, toggle it now
            if prev_checked is not None and bool(prev_checked) == cur_checked:
                item.setCheckState(unchecked_st if cur_checked else checked_st)
        except RuntimeError:
            return

    def _on_combo_changed(self, _idx: int) -> None:
        val = self.combo.currentData()
        if not val:
            self.filter_bus.clear_filter(self.config.id)
        else:
            self.filter_bus.toggle_category_value(
                source_id=self.config.id,
                layer_name=self.config.layer_name,
                field_name=self.config.field_name,
                value=str(val),
                multi=False,
                page_id=str(getattr(self.config, "page_id", "page_1") or "page_1"),
                is_global=bool(getattr(self.config, "is_global", False)),
            )


_WIDGET_PYQT_SIGNAL = getattr(QtCore, "pyqtSignal", getattr(QtCore, "Signal", None))
_WIDGET_QOBJECT_BASE = getattr(QtCore, "QObject", object)


class _AddressSearchRelay(_WIDGET_QOBJECT_BASE):
    """Marshals background In-Aadress worker results safely back to the GUI thread."""

    if _WIDGET_PYQT_SIGNAL is not None:
        results_ready = _WIDGET_PYQT_SIGNAL(object)

    def __init__(self, owner: Any) -> None:
        try:
            super().__init__(owner)
        except TypeError:
            super().__init__()
        self._owner_ref = weakref.ref(owner)
        if _WIDGET_PYQT_SIGNAL is not None and hasattr(self, "results_ready"):
            self.results_ready.connect(self._on_results)

    def _on_results(self, packet: Any) -> None:
        if not isinstance(packet, tuple) or len(packet) != 3:
            return
        relay_id, req_seq, results = packet
        if relay_id != id(self):
            return
        owner = self._owner_ref()
        if owner is None:
            return
        try:
            owner._populate_address_results(results, req_seq=req_seq)
        except RuntimeError:
            pass


class DashboardMapWidget(QFrame):
    """
    Embedded Spatial Map Widget rendered inside the Dashboard workspace.
    Uses QGIS QgsMapCanvas with Estonian Maa-amet WMS basemaps (EPSG:3301) and live WFS/project layers
    when running inside QGIS Desktop, with a clean informational view when outside QGIS GUI.
    """

    def __init__(
        self,
        config: WidgetConfig,
        filter_bus: FilterBus,
        center_lat: float = 58.758,
        center_lon: float = 23.825,
        lang: str = "et",
        on_extent_filter: Optional[Callable[[bool], None]] = None,
        on_edit_saved: Optional[Callable[[], None]] = None,
        on_extent_changed: Optional[Callable[[Any, Any], None]] = None,
        layer_fields_provider: Optional[Callable[[], Dict[str, List[str]]]] = None,
        on_home_view_saved: Optional[Callable[[], None]] = None,
        layer_resolver: Optional[Callable[[str], Any]] = None,
        dashboard_config_provider: Optional[Callable[[], Any]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.filter_bus = filter_bus
        self.center_lat = center_lat
        self.center_lon = center_lon
        self._default_center_lat = center_lat
        self._default_center_lon = center_lon
        self.lang = lang
        self.on_extent_filter = on_extent_filter
        self.on_edit_saved = on_edit_saved
        self.on_extent_changed = on_extent_changed
        self.layer_fields_provider = layer_fields_provider
        self.on_home_view_saved = on_home_view_saved
        self.layer_resolver = layer_resolver
        self.dashboard_config_provider = dashboard_config_provider
        self._canvas: Optional[Any] = None
        self._pan_tool: Optional[Any] = None
        self._basemap_layer: Optional[Any] = None
        self._last_layers_key: Optional[Tuple[Any, ...]] = None
        self._extent_debounce_timer: Optional[Any] = None
        self._style_edit_layer: str = ""
        self._records_cache: Dict[str, List[Dict[str, Any]]] = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(5)

        bar = _FlowLayout(margin=0, spacing=5)
        bm_wrap = QWidget()
        bm_row = QHBoxLayout(bm_wrap)
        bm_row.setContentsMargins(0, 0, 0, 0)
        bm_row.setSpacing(4)
        self.lbl_bm = QLabel(tr("map_basemap_lbl", lang))
        self.lbl_bm.setProperty("role", "muted")
        bm_row.addWidget(self.lbl_bm)

        self.cb_basemap = QComboBox()
        self.cb_basemap.setMinimumWidth(145)
        try:
            self.cb_basemap.setSizeAdjustPolicy(
                qt_enum(QComboBox, "SizeAdjustPolicy", "AdjustToMinimumContentsLengthWithIcon")
            )
            self.cb_basemap.setMinimumContentsLength(14)
        except Exception:
            pass
        for layer_id, label, _url, _fmt in MAAAMET_BASEMAPS:
            self.cb_basemap.addItem(label, layer_id)
        idx = self.cb_basemap.findData(self.config.map_basemap or "MA-HALLKAART")
        if idx >= 0:
            self.cb_basemap.setCurrentIndex(idx)
        self.cb_basemap.currentIndexChanged.connect(self._on_basemap_changed)
        bm_row.addWidget(self.cb_basemap)
        bar.addWidget(bm_wrap)

        def _fix_bar_btn(b: Any) -> Any:
            try:
                b.setSizePolicy(
                    qt_enum(QSizePolicy, "Policy", "Preferred"),
                    qt_enum(QSizePolicy, "Policy", "Fixed"),
                )
            except Exception:
                pass
            return b

        self.btn_layers = _fix_bar_btn(QPushButton(tr("map_layers_btn", lang)))
        self.btn_layers.setCheckable(True)
        self.btn_layers.setProperty("btnRole", "accent")
        self.btn_layers.clicked.connect(self._toggle_layers_panel)
        bar.addWidget(self.btn_layers)

        self.btn_zoom_sel = _fix_bar_btn(QPushButton(tr("map_zoom_sel", lang)))
        self.btn_zoom_sel.setProperty("btnRole", "miniTool")
        self.btn_zoom_sel.clicked.connect(self.zoom_to_selection_or_layers)
        bar.addWidget(self.btn_zoom_sel)

        self.btn_reset_home = _fix_bar_btn(QPushButton(tr("btn_reset_home", lang)))
        self.btn_reset_home.setProperty("btnRole", "miniTool")
        self.btn_reset_home.setToolTip(tr("btn_reset_home", lang))
        self.btn_reset_home.clicked.connect(self.reset_to_home_view)
        bar.addWidget(self.btn_reset_home)

        self.btn_set_home = _fix_bar_btn(QPushButton("📍"))
        self.btn_set_home.setProperty("btnRole", "miniStep")
        self.btn_set_home.setToolTip(tr("btn_set_home_view", lang))
        self.btn_set_home.clicked.connect(self.set_current_view_as_home)
        bar.addWidget(self.btn_set_home)

        self.btn_style_legend = _fix_bar_btn(QPushButton(tr("btn_open_legend_dlg", lang)))
        self.btn_style_legend.setProperty("btnRole", "miniTool")
        self.btn_style_legend.clicked.connect(self._open_style_legend_dialog)
        bar.addWidget(self.btn_style_legend)

        self.btn_scale = _fix_bar_btn(QPushButton("1:500 000 ▾"))
        self.btn_scale.setProperty("btnRole", "scalePill")
        self.btn_scale.setCursor(qt_enum(Qt, "CursorShape", "PointingHandCursor"))
        self.btn_scale.clicked.connect(self._show_scale_menu)
        self.lbl_scale = self.btn_scale
        bar.addWidget(self.btn_scale)
        layout.addLayout(bar)

        # Estonian Address & Cadastral Search Bar (Maa- ja Ruumiamet In-Aadress)
        addr_row = QHBoxLayout()
        addr_row.setSpacing(4)
        self.ed_addr_search = QLineEdit()
        self.ed_addr_search.setPlaceholderText(tr("addr_search_ph", lang))
        self.ed_addr_search.returnPressed.connect(self._search_address)
        if hasattr(self.ed_addr_search, "textChanged"):
            self.ed_addr_search.textChanged.connect(self._on_address_text_changed)
        self.btn_addr_search = QPushButton(f"🔍 {tr('addr_search_btn', lang)}")
        self.btn_addr_search.setProperty("btnRole", "miniTool")
        self.btn_addr_search.clicked.connect(self._search_address)
        self.btn_addr_clear = QPushButton("×")
        self.btn_addr_clear.setProperty("btnRole", "miniStep")
        self.btn_addr_clear.setToolTip(tr("addr_clear", lang))
        self.btn_addr_clear.clicked.connect(self.clear_address_search)
        addr_row.addWidget(self.ed_addr_search, 1)
        addr_row.addWidget(self.btn_addr_search)
        addr_row.addWidget(self.btn_addr_clear)
        layout.addLayout(addr_row)

        self.list_addr_results = QListWidget()
        self.list_addr_results.setMaximumHeight(110)
        self.list_addr_results.hide()
        self.list_addr_results.itemClicked.connect(self._on_address_item_clicked)
        layout.addWidget(self.list_addr_results)
        self._addr_rubber_band: Optional[Any] = None
        self._addr_seq: int = 0
        self._addr_suppress_change: bool = False
        self._addr_relay: Optional[_AddressSearchRelay] = None
        if _WIDGET_PYQT_SIGNAL is not None:
            try:
                self._addr_relay = _AddressSearchRelay(self)
            except Exception:
                self._addr_relay = None
        qtimer_cls = getattr(QtCore, "QTimer", None)
        if qtimer_cls is not None:
            try:
                self._addr_timer = qtimer_cls(self)
                self._addr_timer.setSingleShot(True)
                self._addr_timer.setInterval(240)
                self._addr_timer.timeout.connect(self._search_address)
            except Exception:
                self._addr_timer = None
        else:
            self._addr_timer = None

        # Floating Non-Modal Kihid / Järjekord + Tabbed Style & Labels Dialog (#4, #5)
        self.layers_panel = QDialog(self)
        self.layers_panel.setObjectName("MapLayersFloatingDialog")
        self.layers_panel.setWindowTitle(tr("map_layers_title", lang))
        try:
            self.layers_panel.setWindowFlags(
                self.layers_panel.windowFlags() | qt_enum(Qt, "WindowType", "Tool")
            )
        except Exception:
            pass
        if hasattr(self.layers_panel, "finished"):
            try:
                self.layers_panel.finished.connect(lambda _r=0: self._on_layers_dialog_closed())
            except Exception:
                pass
        if hasattr(self.layers_panel, "setMinimumSize"):
            self.layers_panel.setMinimumSize(520, 360)
        if hasattr(self.layers_panel, "resize"):
            self.layers_panel.resize(650, 440)
        if hasattr(self.layers_panel, "setStyleSheet"):
            self.layers_panel.setStyleSheet(ThemeManager.get_stylesheet())

        lp_root = QVBoxLayout(self.layers_panel)
        lp_root.setContentsMargins(10, 10, 10, 10)
        lp_root.setSpacing(8)
        lp_hdr = QHBoxLayout()
        lp_hdr.setSpacing(6)
        self.lbl_layers_order = QLabel(tr("map_layers_order_short", lang))
        self.lbl_layers_order.setProperty("role", "mutedSmall")
        lp_hdr.addWidget(self.lbl_layers_order, 1)
        self.btn_layer_up = QPushButton(tr("btn_move_up", lang))
        self.btn_layer_up.setProperty("btnRole", "miniStep")
        self.btn_layer_up.clicked.connect(lambda: self._move_inline_layer(-1))
        self.btn_layer_dn = QPushButton(tr("btn_move_down", lang))
        self.btn_layer_dn.setProperty("btnRole", "miniStep")
        self.btn_layer_dn.clicked.connect(lambda: self._move_inline_layer(1))
        self.btn_inline_style = QPushButton(tr("btn_map_style_legend", lang))
        self.btn_inline_style.setProperty("btnRole", "miniTool")
        self.btn_inline_style.setToolTip(tr("dlg_legend_title", lang))
        self.btn_inline_style.clicked.connect(self._open_style_legend_dialog)
        lp_hdr.addWidget(self.btn_layer_up)
        lp_hdr.addWidget(self.btn_layer_dn)
        lp_hdr.addWidget(self.btn_inline_style)
        lp_root.addLayout(lp_hdr)

        lp_body = QHBoxLayout()
        lp_body.setSpacing(10)

        self.inline_layers_list = DragFieldListWidget(
            role_mode="layer_order",
            lang=lang,
            on_order_changed=self._on_user_reordered_inline_layers,
        )
        self.inline_layers_list.setMinimumWidth(190)
        self.inline_layers_list.itemChanged.connect(lambda _it: self._apply_inline_layer_order())
        _cic_sig = getattr(self.inline_layers_list, "currentItemChanged", None)
        if _cic_sig is not None and hasattr(_cic_sig, "connect"):
            _cic_sig.connect(self._on_inline_layer_selection_changed)
        try:
            self.inline_layers_list.model().rowsMoved.connect(
                lambda *_args: QtCore.QTimer.singleShot(0, self._on_user_reordered_inline_layers)
            )
        except Exception:
            pass
        lp_body.addWidget(self.inline_layers_list, 4)

        # Right Pane: Tabbed Layer Style & Multi-Field Labels (#4, #5)
        self.inline_style_box = QFrame(self.layers_panel)
        self.inline_style_box.setObjectName("FrameCard")
        sb_lay = QVBoxLayout(self.inline_style_box)
        sb_lay.setContentsMargins(8, 8, 8, 8)
        sb_lay.setSpacing(6)
        self.lbl_style_target = QLabel("🎨")
        self.lbl_style_target.setProperty("role", "accent")
        sb_lay.addWidget(self.lbl_style_target)

        self.inline_style_tabs = QTabWidget() if QTabWidget is not None else QWidget()
        sb_lay.addWidget(self.inline_style_tabs, 1)

        # Tab 1: Style
        st_scroll = QScrollArea()
        st_scroll.setWidgetResizable(True)
        st_scroll.setFrameShape(qt_enum(QFrame, "Shape", "NoFrame"))
        st_page = QWidget()
        st_lay = QVBoxLayout(st_page)
        st_lay.setContentsMargins(6, 6, 6, 6)
        st_lay.setSpacing(8)

        row_c1 = QHBoxLayout()
        row_c1.setSpacing(6)
        self.btn_style_fill = QPushButton(tr("style_fill", lang).rstrip(":"))
        self.btn_style_fill.setProperty("btnRole", "miniTool")
        self.btn_style_fill.clicked.connect(self._pick_inline_fill_color)
        self.sp_style_opacity = QDoubleSpinBox() if QDoubleSpinBox is not None else QSpinBox()
        if hasattr(self.sp_style_opacity, "setDecimals"):
            self.sp_style_opacity.setDecimals(0)
        self.sp_style_opacity.setRange(5, 100)
        self.sp_style_opacity.setSuffix("%")
        self.sp_style_opacity.setValue(45)
        self.sp_style_opacity.valueChanged.connect(lambda _v: self._apply_inline_style())
        self.chk_style_outline_only = QCheckBox(tr("style_outline_only", lang))
        self.chk_style_outline_only.toggled.connect(lambda _c: self._apply_inline_style())
        row_c1.addWidget(self.btn_style_fill)
        row_c1.addWidget(QLabel(tr("style_opacity", lang)))
        row_c1.addWidget(self.sp_style_opacity)
        row_c1.addWidget(self.chk_style_outline_only)
        st_lay.addLayout(row_c1)

        row_c2 = QHBoxLayout()
        row_c2.setSpacing(6)
        self.btn_style_border = QPushButton(tr("style_border", lang).rstrip(":"))
        self.btn_style_border.setProperty("btnRole", "miniTool")
        self.btn_style_border.clicked.connect(self._pick_inline_border_color)
        self.sp_style_width = QDoubleSpinBox() if QDoubleSpinBox is not None else QLineEdit()
        if hasattr(self.sp_style_width, "setRange"):
            self.sp_style_width.setDecimals(1)
            self.sp_style_width.setRange(0.5, 6.0)
            self.sp_style_width.setSingleStep(0.5)
            self.sp_style_width.setValue(1.5)
            self.sp_style_width.valueChanged.connect(lambda _v: self._apply_inline_style())
        lbl_mz = QLabel(tr("style_min_zoom", lang))
        lbl_mz.setToolTip(tr("style_min_zoom_tip", lang))
        self.sp_style_min_zoom = QSpinBox()
        self.sp_style_min_zoom.setRange(0, 14)
        self.sp_style_min_zoom.setValue(0)
        self.sp_style_min_zoom.setToolTip(tr("style_min_zoom_tip", lang))
        self.sp_style_min_zoom.valueChanged.connect(lambda _v: self._apply_inline_style())
        row_c2.addWidget(self.btn_style_border)
        row_c2.addWidget(self.sp_style_width)
        row_c2.addWidget(lbl_mz)
        row_c2.addWidget(self.sp_style_min_zoom)
        row_c2.addStretch()
        st_lay.addLayout(row_c2)

        row_c3 = QHBoxLayout()
        row_c3.setSpacing(6)
        self.cb_style_cat = QComboBox()
        self.cb_style_cat.currentIndexChanged.connect(lambda _i: self._apply_inline_style())
        row_c3.addWidget(QLabel(tr("style_categorized", lang)))
        row_c3.addWidget(self.cb_style_cat, 1)
        st_lay.addLayout(row_c3)
        st_lay.addStretch(1)
        st_scroll.setWidget(st_page)

        # Tab 2: Multi-Field Labels
        lb_scroll = QScrollArea()
        lb_scroll.setWidgetResizable(True)
        lb_scroll.setFrameShape(qt_enum(QFrame, "Shape", "NoFrame"))
        lb_page = QWidget()
        lb_lay = QVBoxLayout(lb_page)
        lb_lay.setContentsMargins(6, 6, 6, 6)
        lb_lay.setSpacing(8)
        self._inline_extra_lbl_rows: List[Tuple[QWidget, QComboBox]] = []

        lf_row1 = QHBoxLayout()
        lf_row1.setSpacing(6)
        self.cb_style_label = QComboBox()
        self.cb_style_label.currentIndexChanged.connect(lambda _i: self._apply_inline_style())
        lf_row1.addWidget(QLabel(tr("lbl_label_field_1", lang)))
        lf_row1.addWidget(self.cb_style_label, 1)
        lb_lay.addLayout(lf_row1)

        lf_row2 = QHBoxLayout()
        lf_row2.setSpacing(6)
        self.cb_style_label_2 = QComboBox()
        self.cb_style_label_2.currentIndexChanged.connect(lambda _i: self._apply_inline_style())
        lf_row2.addWidget(QLabel(tr("lbl_label_field_2", lang)))
        lf_row2.addWidget(self.cb_style_label_2, 1)
        lb_lay.addLayout(lf_row2)

        self.inline_extra_fields_host = QWidget()
        self.inline_extra_fields_lay = QVBoxLayout(self.inline_extra_fields_host)
        self.inline_extra_fields_lay.setContentsMargins(0, 0, 0, 0)
        self.inline_extra_fields_lay.setSpacing(4)
        lb_lay.addWidget(self.inline_extra_fields_host)

        self.btn_inline_add_lbl_field = QPushButton(tr("btn_add_label_field", lang))
        self.btn_inline_add_lbl_field.setProperty("btnRole", "miniTool")
        self.btn_inline_add_lbl_field.clicked.connect(lambda: self._add_inline_extra_label_row(""))
        add_ex_row = QHBoxLayout()
        add_ex_row.addWidget(self.btn_inline_add_lbl_field)
        add_ex_row.addStretch()
        lb_lay.addLayout(add_ex_row)

        row_c4 = QHBoxLayout()
        row_c4.setSpacing(6)
        self.sp_style_lbl_size = QSpinBox()
        self.sp_style_lbl_size.setRange(3, 24)
        self.sp_style_lbl_size.setValue(10)
        self.sp_style_lbl_size.setSuffix("px")
        self.sp_style_lbl_size.setToolTip(tr("tip_label_size", lang))
        self.sp_style_lbl_size.valueChanged.connect(lambda _v: self._apply_inline_style())
        self.btn_style_lbl_color = QPushButton("A")
        self.btn_style_lbl_color.setProperty("btnRole", "miniTool")
        self.btn_style_lbl_color.setFixedWidth(28)
        self.btn_style_lbl_color.setProperty("_chosen_color", "#0f172a")
        self.btn_style_lbl_color.clicked.connect(self._pick_inline_label_color)
        row_c4.addWidget(QLabel(tr("lbl_label_size", lang)))
        row_c4.addWidget(self.sp_style_lbl_size)
        row_c4.addWidget(QLabel(tr("lbl_label_color", lang)))
        row_c4.addWidget(self.btn_style_lbl_color)
        row_c4.addStretch()
        lb_lay.addLayout(row_c4)

        row_halo = QHBoxLayout()
        row_halo.setSpacing(6)
        self.sl_style_lbl_halo = QSlider(qt_enum(Qt, "Orientation", "Horizontal")) if QSlider is not None else QSpinBox()
        self.sl_style_lbl_halo.setRange(0, 100)
        self.sl_style_lbl_halo.setValue(90)
        self.sl_style_lbl_halo.setToolTip(tr("tip_label_halo", lang))
        self.lbl_style_halo_val = QLabel("90%")
        self.lbl_style_halo_val.setMinimumWidth(34)
        self.sl_style_lbl_halo.valueChanged.connect(self._on_inline_halo_changed)
        row_halo.addWidget(QLabel(tr("lbl_halo_opacity", lang)))
        row_halo.addWidget(self.sl_style_lbl_halo, 1)
        row_halo.addWidget(self.lbl_style_halo_val)
        lb_lay.addLayout(row_halo)

        row_c5 = QHBoxLayout()
        row_c5.setSpacing(6)
        self.cb_style_lbl_pos = QComboBox()
        self.cb_style_lbl_pos.addItem(tr("lbl_pos_center", lang), "center")
        self.cb_style_lbl_pos.addItem(tr("lbl_pos_outside_line", lang), "outside_line")
        self.cb_style_lbl_pos.addItem(tr("lbl_pos_outside_callout", lang), "outside_callout")
        self.cb_style_lbl_pos.currentIndexChanged.connect(lambda _i: self._apply_inline_style())
        self.sp_style_lbl_zoom = QSpinBox()
        self.sp_style_lbl_zoom.setRange(0, 18)
        self.sp_style_lbl_zoom.setValue(0)
        self.sp_style_lbl_zoom.valueChanged.connect(lambda _v: self._apply_inline_style())
        row_c5.addWidget(QLabel(tr("lbl_label_position", lang)))
        row_c5.addWidget(self.cb_style_lbl_pos, 1)
        row_c5.addWidget(QLabel("Z≥"))
        row_c5.addWidget(self.sp_style_lbl_zoom)
        lb_lay.addLayout(row_c5)
        lb_lay.addStretch(1)
        lb_scroll.setWidget(lb_page)

        if QTabWidget is not None and hasattr(self.inline_style_tabs, "addTab"):
            self.inline_style_tabs.addTab(st_scroll, tr("tab_layer_style", lang))
            self.inline_style_tabs.addTab(lb_scroll, tr("tab_layer_labels", lang))

        lp_body.addWidget(self.inline_style_box, 7)
        lp_root.addLayout(lp_body, 1)

        # Layer dialog always starts minimized by default (#6)
        self.config.map_layer_panel_collapsed = True
        self.btn_layers.setChecked(False)
        self.layers_panel.setVisible(False)

        self._map_holder = QVBoxLayout()
        self._map_holder.setContentsMargins(0, 0, 0, 0)
        layout.addLayout(self._map_holder, 1)

        self._map_render_overlay = None
        self._map_render_label = None
        self._map_render_safety_timer = None
        self._init_map_render_overlay()
        self._init_qgis_canvas()
        try:
            self.setAcceptDrops(False)
        except Exception:
            pass

    def _init_map_render_overlay(self) -> None:
        self._map_render_overlay = QFrame(self)
        self._map_render_overlay.setObjectName("MapRenderOverlay")
        self._map_render_overlay.setStyleSheet(
            "QFrame#MapRenderOverlay { background: rgba(15, 23, 42, 0.90); "
            "border: 1px solid #38bdf8; border-radius: 16px; }"
        )
        try:
            wa = qt_enum(Qt, "WidgetAttribute", "WA_TransparentForMouseEvents")
            self._map_render_overlay.setAttribute(wa, True)
        except Exception:
            pass
        hl = QHBoxLayout(self._map_render_overlay)
        hl.setContentsMargins(14, 7, 14, 7)
        hl.setSpacing(8)
        if QProgressBar is not None:
            bar = QProgressBar(self._map_render_overlay)
            bar.setRange(0, 0)
            bar.setFixedSize(46, 10)
            bar.setTextVisible(False)
            bar.setStyleSheet(
                "QProgressBar { background: rgba(148,163,184,0.25); border: none; border-radius: 5px; }"
                "QProgressBar::chunk { background: #38bdf8; border-radius: 5px; }"
            )
            hl.addWidget(bar)
        self._map_render_label = QLabel(tr("map_rendering_layers", self.lang), self._map_render_overlay)
        self._map_render_label.setStyleSheet(
            "color: #f8fafc; font-weight: 600; font-size: 11px; background: transparent;"
        )
        hl.addWidget(self._map_render_label)
        self._map_render_overlay.hide()

    def _position_map_render_overlay(self) -> None:
        if getattr(self, "_map_render_overlay", None) is None:
            return
        try:
            self._map_render_overlay.adjustSize()
            ow = max(180, int(self._map_render_overlay.width()))
            oh = max(32, int(self._map_render_overlay.height()))
            x = max(8, (int(self.width()) - ow) // 2)
            y = max(48, (int(self.height()) - oh) // 2)
            self._map_render_overlay.setGeometry(x, y, ow, oh)
            self._map_render_overlay.raise_()
        except Exception:
            pass

    def _set_map_rendering(self, active: bool) -> None:
        ov = getattr(self, "_map_render_overlay", None)
        if ov is None:
            return
        if self._map_render_label is not None:
            try:
                self._map_render_label.setText(tr("map_rendering_layers", self.lang))
            except Exception:
                pass
        if active:
            self._position_map_render_overlay()
            try:
                ov.show()
                ov.raise_()
            except Exception:
                pass
            if self._map_render_safety_timer is None and hasattr(QtCore, "QTimer"):
                try:
                    tmr = QtCore.QTimer(self)
                    tmr.setSingleShot(True)
                    tmr.setInterval(12000)
                    tmr.timeout.connect(lambda: self._set_map_rendering(False))
                    self._map_render_safety_timer = tmr
                except Exception:
                    pass
            if self._map_render_safety_timer is not None:
                try:
                    self._map_render_safety_timer.start()
                except Exception:
                    pass
        else:
            if self._map_render_safety_timer is not None:
                try:
                    self._map_render_safety_timer.stop()
                except Exception:
                    pass
            try:
                ov.hide()
            except Exception:
                pass

    def resizeEvent(self, ev) -> None:  # type: ignore[override]
        if hasattr(super(), "resizeEvent"):
            super().resizeEvent(ev)
        self._position_map_render_overlay()

    def set_drop_highlight(self, active: bool) -> None:
        if active:
            self.setStyleSheet("DashboardMapWidget { border: 2px dashed #38bdf8; border-radius: 6px; }")
        else:
            self.setStyleSheet("")

    def _init_qgis_canvas(self) -> None:
        try:
            from qgis.core import QgsCoordinateReferenceSystem
            from qgis.gui import QgsMapCanvas

            canvas = QgsMapCanvas(self)
            canvas.setCanvasColor(QColor(ThemeManager.colors_for_widget(self)["card_surface"]))
            canvas.setDestinationCrs(QgsCoordinateReferenceSystem("EPSG:3301"))
            canvas.enableAntiAliasing(True)
            for fn, val in (
                ("setCachingEnabled", True),
                ("setParallelRenderingEnabled", True),
                ("setPreviewJobsEnabled", True),
            ):
                if hasattr(canvas, fn):
                    try:
                        getattr(canvas, fn)(val)
                    except Exception:
                        pass
            canvas.setAcceptDrops(False)
            try:
                if hasattr(canvas, "viewport") and canvas.viewport():
                    canvas.viewport().setAcceptDrops(False)
            except Exception:
                pass
            try:
                from qgis.gui import QgsMapToolPan

                self._pan_tool = QgsMapToolPan(canvas)
                canvas.setMapTool(self._pan_tool)
            except Exception:
                self._pan_tool = None

            if hasattr(QtCore, "QTimer") and hasattr(canvas, "extentsChanged"):
                timer = QtCore.QTimer(self)
                timer.setSingleShot(True)
                timer.setInterval(180)
                timer.timeout.connect(self._emit_canvas_extent)
                self._extent_debounce_timer = timer
                canvas.extentsChanged.connect(self._schedule_extent_emit)

            if hasattr(canvas, "renderStarting"):
                try:
                    canvas.renderStarting.connect(lambda: self._set_map_rendering(True))
                except Exception:
                    pass
            if hasattr(canvas, "mapCanvasRefreshed"):
                try:
                    canvas.mapCanvasRefreshed.connect(lambda: self._set_map_rendering(False))
                except Exception:
                    pass

            self._canvas = canvas
            self._map_holder.addWidget(canvas, 1)
            self._position_map_render_overlay()
            self.apply_scroll_sensitivity()
            self.sync_layers_and_zoom(force_layers=True)
        except Exception:
            fallback = QFrame(self)
            fallback.setObjectName("MapFallback")
            fl = QVBoxLayout(fallback)
            self._lbl_fallback = QLabel(
                tr("map_fallback_hint", self.lang, bm=self.config.map_basemap or "MA-HALLKAART")
            )
            self._lbl_fallback.setWordWrap(True)
            self._lbl_fallback.setAlignment(qt_enum(Qt, "AlignmentFlag", "AlignCenter"))
            self._lbl_fallback.setProperty("role", "muted")
            self._lbl_fallback.setContentsMargins(12, 12, 12, 12)
            fl.addWidget(self._lbl_fallback)
            self._map_holder.addWidget(fallback, 1)

    def _schedule_extent_emit(self) -> None:
        if self._extent_debounce_timer is not None:
            self._extent_debounce_timer.start()
        else:
            self._emit_canvas_extent()

    def apply_scroll_sensitivity(self, sensitivity: Optional[int] = None) -> None:
        """Apply wheel zoom smoothness factor to the embedded QGIS map canvas (#2)."""
        sens = max(
            1,
            min(
                100,
                int(
                    (
                        sensitivity
                        if sensitivity is not None
                        else getattr(self.config, "map_scroll_sensitivity", 35)
                    )
                    or 35
                ),
            ),
        )
        self.config.map_scroll_sensitivity = sens
        if self._canvas is not None and hasattr(self._canvas, "setWheelFactor"):
            try:
                factor = 1.06 + ((float(sens) / 100.0) ** 1.2) * 0.94
                self._canvas.setWheelFactor(float(factor))
            except Exception:
                pass

    def _compute_effective_zoom_and_scale(self) -> Tuple[int, float]:
        """Compute HTML-equivalent Estonia zoom (0..14) and scale denominator for this canvas."""
        ma_res = [
            4000.0, 2000.0, 1000.0, 500.0, 250.0, 125.0, 62.5,
            31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625,
        ]
        if self._canvas is None:
            z = int(self.config.map_zoom) if self.config.map_zoom is not None else 7
            z = max(0, min(14, z))
            return z, float(ma_res[z] * 3779.52756)
        try:
            raw_scale = float(self._canvas.scale()) if hasattr(self._canvas, "scale") else 0.0
            est_res = float(self._canvas.mapUnitsPerPixel()) if hasattr(self._canvas, "mapUnitsPerPixel") else 0.0
            cfg_w = max(120.0, float(getattr(self.config, "layout_w", 0) or (self._canvas.width() or 540.0)))
            canvas_w = max(120.0, float(self._canvas.width() or cfg_w))
            ratio = canvas_w / cfg_w
            is_geo = False
            try:
                if hasattr(self._canvas, "mapSettings"):
                    dest_crs = self._canvas.mapSettings().destinationCrs()
                    is_geo = bool(getattr(dest_crs, "isGeographic", lambda: False)())
            except Exception:
                is_geo = False
            if est_res > 0 and not is_geo:
                eff_res = est_res * ratio
                eff_scale = eff_res * 3779.52756
            else:
                eff_scale = (raw_scale * ratio) if raw_scale > 0 else 500000.0
                eff_res = eff_scale / 3779.52756
            eff_z = min(range(len(ma_res)), key=lambda zi: abs(ma_res[zi] - eff_res))
            return int(eff_z), float(eff_scale)
        except Exception:
            return 7, 500000.0

    def _format_scale_hover_info(self, eff_z: int, scale_val: float) -> str:
        s_rounded = int(round(scale_val / 100.0) * 100) if scale_val >= 1000 else max(100, int(round(scale_val)))
        scale_str = f"1:{s_rounded:,}".replace(",", " ")
        detail_txt = "1:1 Detail" if scale_val <= 55000 else ("LOD-2" if scale_val <= 250000 else ("LOD-1" if scale_val <= 750000 else "LOD-0"))
        span_txt = "~360 × 240 km"
        try:
            if self._canvas is not None and hasattr(self._canvas, "extent"):
                ext = self._canvas.extent()
                if ext and not ext.isEmpty():
                    dest_crs = self._canvas.mapSettings().destinationCrs()
                    w, h = float(ext.width()), float(ext.height())
                    if getattr(dest_crs, "isGeographic", lambda: False)():
                        cen = ext.center()
                        km_x = w * 111.32 * max(0.2, math.cos(math.radians(float(cen.y()))))
                        km_y = h * 110.57
                    else:
                        km_x, km_y = w / 1000.0, h / 1000.0
                    if km_x > 0 and km_y > 0:
                        span_txt = f"~{km_x:.1f} × {km_y:.1f} km" if km_x >= 10 else f"~{km_x * 1000:.0f} × {km_y * 1000:.0f} m"
        except Exception:
            pass
        return tr(
            "map_scale_hover_info",
            self.lang,
            scale=scale_str,
            zoom_txt=f"Z={eff_z}",
            span_txt=span_txt,
            detail_txt=detail_txt,
        )

    def _update_scale_label(self) -> None:
        btn = getattr(self, "btn_scale", None) or getattr(self, "lbl_scale", None)
        if btn is None:
            return
        try:
            eff_z, eff_scale = self._compute_effective_zoom_and_scale()
            scale_val = eff_scale if eff_scale > 0 else (
                float(self._canvas.scale()) if (self._canvas is not None and hasattr(self._canvas, "scale")) else 500000.0
            )
            if scale_val > 0:
                s_rounded = int(round(scale_val / 100.0) * 100) if scale_val >= 1000 else int(round(scale_val))
                scale_str = f"1:{s_rounded:,}".replace(",", " ")
                btn.setText(f"{tr('map_scale_lbl', self.lang).format(scale=scale_str)} · Z={eff_z} ▾")
                btn.setToolTip(self._format_scale_hover_info(eff_z, scale_val))
        except Exception:
            pass

    def set_map_scale(self, scale_denom: float, fit_estonia: bool = False) -> None:
        """Zoom the Design Mode map canvas cleanly to an Estonian overview or explicit 1:N scale."""
        if self._canvas is None:
            return
        try:
            target_scale = max(250.0, min(15_000_000.0, float(scale_denom or 500000.0)))
            if fit_estonia:
                from qgis.core import (
                    QgsCoordinateReferenceSystem,
                    QgsCoordinateTransform,
                    QgsProject,
                    QgsRectangle,
                )

                wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                dest_crs = self._canvas.mapSettings().destinationCrs()
                rect = QgsRectangle(21.65, 57.48, 28.25, 59.70)
                if dest_crs.isValid() and dest_crs != wgs84:
                    rect = QgsCoordinateTransform(wgs84, dest_crs, QgsProject.instance()).transformBoundingBox(rect)
                self._canvas.setExtent(rect)
            else:
                from qgis.core import QgsRectangle

                ext = self._canvas.extent()
                canvas_w = max(120.0, float(self._canvas.width() if hasattr(self._canvas, "width") else 540.0))
                canvas_h = max(80.0, float(self._canvas.height() if hasattr(self._canvas, "height") else 380.0))
                cfg_w = max(120.0, float(getattr(self.config, "layout_w", 0) or canvas_w))
                target_res = target_scale / 3779.52756
                is_geo = False
                try:
                    if hasattr(self._canvas, "mapSettings"):
                        dest_crs = self._canvas.mapSettings().destinationCrs()
                        is_geo = bool(getattr(dest_crs, "isGeographic", lambda: False)())
                except Exception:
                    is_geo = False
                if not ext.isEmpty() and not is_geo:
                    cen = ext.center()
                    aspect = canvas_h / max(1.0, canvas_w)
                    half_w = cfg_w * target_res * 0.5
                    half_h = half_w * aspect
                    self._canvas.setExtent(
                        QgsRectangle(cen.x() - half_w, cen.y() - half_h, cen.x() + half_w, cen.y() + half_h)
                    )
                elif hasattr(self._canvas, "zoomScale"):
                    ratio = canvas_w / cfg_w
                    self._canvas.zoomScale(target_scale / max(0.2, ratio))
            if hasattr(self._canvas, "refresh"):
                self._canvas.refresh()
            self._update_scale_label()
            self._emit_canvas_extent()
        except Exception:
            pass

    def _show_scale_menu(self) -> None:
        menu_cls = getattr(QtWidgets, "QMenu", None)
        btn = getattr(self, "btn_scale", None)
        if menu_cls is None or btn is None:
            return
        lang = self.lang or "et"
        menu = menu_cls(self)
        hdr = menu.addAction(tr("map_scale_menu_title", lang))
        hdr.setEnabled(False)
        menu.addSeparator()
        presets: List[Tuple[str, float, bool]] = [
            (tr("map_scale_preset_estonia", lang), 1_500_000.0, True),
            (tr("map_scale_preset_county", lang), 500_000.0, False),
            (tr("map_scale_preset_municipality", lang), 200_000.0, False),
            (tr("map_scale_preset_local", lang), 50_000.0, False),
            (tr("map_scale_preset_detail", lang), 25_000.0, False),
            (tr("map_scale_preset_cadastre", lang), 10_000.0, False),
            (tr("map_scale_preset_closeup", lang), 5_000.0, False),
        ]
        for label, s_val, is_est in presets:
            act = menu.addAction(label)
            act.triggered.connect(lambda _c=False, sv=s_val, fe=is_est: self.set_map_scale(sv, fit_estonia=fe))
        menu.addSeparator()
        act_manual = menu.addAction(tr("map_scale_manual_btn", lang))

        def _prompt_manual() -> None:
            inp_cls = getattr(QtWidgets, "QInputDialog", None)
            if inp_cls is None:
                return
            _z, cur_s = self._compute_effective_zoom_and_scale()
            default_txt = str(max(500, int(round(cur_s))))
            raw, ok = inp_cls.getText(
                self,
                tr("map_scale_menu_title", lang),
                tr("map_scale_manual_prompt", lang),
                text=default_txt,
            )
            if not ok or not str(raw or "").strip():
                return
            cleaned = (
                re.sub(r"^\s*1\s*:\s*", "", str(raw).strip())
                .replace("\u00a0", "")
                .replace("\u202f", "")
                .replace(" ", "")
                .replace(",", "")
            )
            try:
                val = float(cleaned)
                if val > 0:
                    self.set_map_scale(val, fit_estonia=False)
            except Exception:
                pass

        act_manual.triggered.connect(_prompt_manual)
        gpos = btn.mapToGlobal(QPoint(0, btn.height())) if hasattr(btn, "mapToGlobal") else QtGui.QCursor.pos()
        exec_menu(menu, gpos)

    def _emit_canvas_extent(self) -> None:
        self._update_scale_label()
        self.apply_configured_layer_styles(update_renderer=False)
        if self._canvas is None or not self.on_extent_changed:
            return
        try:
            ext = self._canvas.extent()
            if ext.isEmpty():
                return
            crs = self._canvas.mapSettings().destinationCrs()
            self.on_extent_changed(ext, crs)
        except Exception:
            pass

    def current_canvas_extent(self) -> Tuple[Optional[Any], Optional[Any]]:
        if self._canvas is None:
            return None, None
        try:
            ext = self._canvas.extent()
            if ext.isEmpty():
                return None, None
            return ext, self._canvas.mapSettings().destinationCrs()
        except Exception:
            return None, None

    def _on_basemap_changed(self, _idx: int) -> None:
        bm = str(self.cb_basemap.currentData() or "MA-HALLKAART")
        self.config.map_basemap = bm
        if hasattr(self, "_lbl_fallback"):
            self._lbl_fallback.setText(tr("map_fallback_hint", self.lang, bm=bm))
        self.sync_layers_and_zoom(force_layers=True)
        if self.on_edit_saved:
            self.on_edit_saved()

    def _dashboard_cfg(self) -> Optional[Any]:
        if callable(getattr(self, "dashboard_config_provider", None)):
            try:
                return self.dashboard_config_provider()
            except Exception:
                return None
        return None

    def _is_sync_main_canvas(self) -> bool:
        dcfg = self._dashboard_cfg()
        return str(getattr(dcfg, "canvas_sync_mode", "dashboard_only") or "dashboard_only") == "sync_main_canvas"

    def _resolve_layer(self, lname: str) -> Optional[Any]:
        name = str(lname or "").strip()
        if not name:
            return None
        if callable(getattr(self, "layer_resolver", None)):
            try:
                lyr = self.layer_resolver(name)
                if lyr is not None:
                    return lyr
            except Exception:
                pass
        if getattr(self, "layer_resolver", None) is None or self._is_sync_main_canvas():
            try:
                from qgis.core import QgsProject

                found = QgsProject.instance().mapLayersByName(name)
                if found:
                    return found[0]
            except Exception:
                pass
        return None

    def _populate_layer_order_list(self, lw: DragFieldListWidget) -> None:
        lw.blockSignals(True)
        lw.clear()
        current = list(self.config.map_layers or [])
        if not current and self.config.layer_name:
            current = [self.config.layer_name]
        candidates = list(current)
        bm_titles = {b[1] for b in MAAAMET_BASEMAPS}
        dcfg = self._dashboard_cfg()
        if dcfg is not None:
            for ds in getattr(dcfg, "data_sources", []) or []:
                if ds.name and not getattr(ds, "is_basemap", False) and ds.name not in bm_titles and ds.name not in candidates:
                    candidates.append(ds.name)
        for ln in list((getattr(self, "_records_cache", None) or {}).keys()):
            if ln and ln not in bm_titles and ln not in candidates:
                candidates.append(ln)
        if self._is_sync_main_canvas():
            try:
                from qgis.core import QgsProject

                for lyr in QgsProject.instance().mapLayers().values():
                    ln = lyr.name()
                    if ln and ln not in bm_titles and ln not in candidates:
                        candidates.append(ln)
            except Exception:
                pass

        check_flag = qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable")
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        unchecked_st = qt_enum(Qt, "CheckState", "Unchecked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        cur_set = set(current)
        styles_map = getattr(self.config, "map_layer_styles", {}) or {}
        for name in candidates:
            it = QListWidgetItem(name)
            it.setData(role, name)
            it.setFlags(it.flags() | check_flag)
            st_vis = (styles_map.get(name, {}) or {}).get("visible") if isinstance(styles_map.get(name), dict) else None
            is_checked = (st_vis is True) if st_vis is not None else (name in cur_set or not cur_set)
            if cur_set and st_vis is None:
                is_checked = name in cur_set
            it.setCheckState(checked_st if is_checked else unchecked_st)
            lw.addItem(it)
        lw.blockSignals(False)

    def _refresh_inline_layers_list(self) -> None:
        self._populate_layer_order_list(self.inline_layers_list)
        if self.inline_layers_list.count() > 0 and self.inline_layers_list.currentRow() < 0:
            self.inline_layers_list.setCurrentRow(0)
        cur = self.inline_layers_list.currentItem()
        if cur is not None:
            self._populate_inline_style_for_layer(cur.text())

    def _on_layers_dialog_closed(self) -> None:
        if hasattr(self, "btn_layers"):
            self.btn_layers.blockSignals(True)
            self.btn_layers.setChecked(False)
            self.btn_layers.blockSignals(False)

    def _toggle_layers_panel(self) -> None:
        show = bool(self.btn_layers.isChecked())
        # Keep persisted initial state minimized by default across exports and reloads
        self.config.map_layer_panel_collapsed = True
        if show:
            self._refresh_inline_layers_list()
            try:
                dlg_w = max(560, int(self.layers_panel.width() or 650))
                dlg_h = max(380, int(self.layers_panel.height() or 440))
                gpos = (
                    self.btn_layers.mapToGlobal(QPoint(0, self.btn_layers.height() + 4))
                    if hasattr(self.btn_layers, "mapToGlobal")
                    else QPoint(120, 120)
                )
                sx, sy = int(gpos.x()), int(gpos.y())
                if QGuiApplication is not None and hasattr(QGuiApplication, "primaryScreen"):
                    scr = QGuiApplication.primaryScreen()
                    if scr is not None and hasattr(scr, "availableGeometry"):
                        ag = scr.availableGeometry()
                        if ag is not None and int(ag.width()) > 200 and int(ag.height()) > 200:
                            dlg_w = min(dlg_w, int(ag.width()) - 24)
                            dlg_h = min(dlg_h, int(ag.height()) - 24)
                            self.layers_panel.resize(dlg_w, dlg_h)
                            sx = max(int(ag.left()) + 8, min(sx, int(ag.right()) - dlg_w - 8))
                            sy = max(int(ag.top()) + 8, min(sy, int(ag.bottom()) - dlg_h - 8))
                self.layers_panel.move(sx, sy)
            except Exception:
                pass
            self.layers_panel.show()
            if hasattr(self.layers_panel, "raise_"):
                self.layers_panel.raise_()
        else:
            self.layers_panel.hide()

    def _on_user_reordered_inline_layers(self) -> None:
        self.config.map_layers_custom_order = True
        self._apply_inline_layer_order()

    def _move_inline_layer(self, delta: int) -> None:
        self.config.map_layers_custom_order = True
        self.inline_layers_list.move_selected(delta)
        self._apply_inline_layer_order()

    def _on_inline_layer_selection_changed(self, cur: Any, _prev: Any = None) -> None:
        if cur is not None:
            self._populate_inline_style_for_layer(cur.text())

    def _on_inline_halo_changed(self, val: int) -> None:
        if hasattr(self, "lbl_style_halo_val"):
            self.lbl_style_halo_val.setText(f"{int(val)}%")
        self._apply_inline_style()

    def _fields_for_inline_layer(self, lname: str) -> List[str]:
        fields: List[str] = []
        if callable(getattr(self, "layer_fields_provider", None)):
            try:
                fields = list((self.layer_fields_provider() or {}).get(lname, []) or [])
            except Exception:
                fields = []
        if not fields:
            lyr_obj = self._resolve_layer(lname)
            if lyr_obj is not None and hasattr(lyr_obj, "fields"):
                try:
                    fields = [f.name() for f in lyr_obj.fields()]
                except Exception:
                    fields = []
        return [str(fn) for fn in fields if fn and not str(fn).startswith("_")]

    def _populate_inline_lbl_combo(self, combo: Any, fields: List[str], selected: str = "") -> None:
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(tr("lbl_no_labels", self.lang), "")
        for fn in fields:
            combo.addItem(fn, fn)
        sel = str(selected or "").strip()
        if sel:
            idx = combo.findData(sel)
            if idx < 0:
                combo.addItem(sel, sel)
                idx = combo.findData(sel)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        combo.blockSignals(False)

    def _clear_inline_extra_label_rows(self) -> None:
        for rw, _cb in list(getattr(self, "_inline_extra_lbl_rows", []) or []):
            self.inline_extra_fields_lay.removeWidget(rw)
            rw.deleteLater()
        self._inline_extra_lbl_rows = []
        if hasattr(self, "btn_inline_add_lbl_field"):
            self.btn_inline_add_lbl_field.setEnabled(True)

    def _add_inline_extra_label_row(self, selected: str = "", loading: bool = False) -> None:
        rows = getattr(self, "_inline_extra_lbl_rows", [])
        if len(rows) >= 2:
            return
        lname = str(getattr(self, "_style_edit_layer", "") or "").strip()
        fields = self._fields_for_inline_layer(lname) if lname else []
        rw = QWidget()
        rh = QHBoxLayout(rw)
        rh.setContentsMargins(0, 0, 0, 0)
        rh.setSpacing(6)
        n_line = 3 + len(rows)
        cb = QComboBox()
        self._populate_inline_lbl_combo(cb, fields, selected)
        cb.currentIndexChanged.connect(lambda _i: self._apply_inline_style())
        btn_rm = QPushButton("✕")
        btn_rm.setFixedWidth(24)
        btn_rm.clicked.connect(lambda _c=False, r_w=rw: self._remove_inline_extra_label_row(r_w))
        rh.addWidget(QLabel(tr("lbl_label_field_extra", self.lang, n=n_line)))
        rh.addWidget(cb, 1)
        rh.addWidget(btn_rm)
        self.inline_extra_fields_lay.addWidget(rw)
        rows.append((rw, cb))
        self._inline_extra_lbl_rows = rows
        if hasattr(self, "btn_inline_add_lbl_field"):
            self.btn_inline_add_lbl_field.setEnabled(len(rows) < 2)
        if not loading:
            self._apply_inline_style()

    def _remove_inline_extra_label_row(self, rw: Any) -> None:
        rows = [(w, cb) for (w, cb) in (getattr(self, "_inline_extra_lbl_rows", []) or []) if w is not rw]
        self._inline_extra_lbl_rows = rows
        self.inline_extra_fields_lay.removeWidget(rw)
        rw.deleteLater()
        if hasattr(self, "btn_inline_add_lbl_field"):
            self.btn_inline_add_lbl_field.setEnabled(len(rows) < 2)
        self._apply_inline_style()

    def _collect_inline_label_fields(self) -> List[str]:
        out: List[str] = []
        combos = [self.cb_style_label, self.cb_style_label_2] + [cb for _, cb in (getattr(self, "_inline_extra_lbl_rows", []) or [])]
        for cb in combos:
            val = str(cb.currentData() or "").strip()
            if val and val not in out:
                out.append(val)
        return out

    def _populate_inline_style_for_layer(self, layer_name: str) -> None:
        lname = str(layer_name or "").strip()
        if not lname:
            return
        self._style_edit_layer = lname
        self.lbl_style_target.setText(f"🎨 {lname}")
        st = dict((self.config.map_layer_styles or {}).get(lname, {}) or {})
        fill_col = str(st.get("color") or OgcConnector.default_layer_color_for_name(lname) or "#38bdf8")
        border_col = str(st.get("border_color") or fill_col)
        op_pct = int(round(max(0.05, min(1.0, float(st.get("opacity", 0.45)))) * 100))
        outline_only = bool(st.get("outline_only", False))
        stroke_w = float(st.get("stroke_width", 1.5))

        self.btn_style_fill.setProperty("_chosen_color", fill_col)
        self.btn_style_fill.setStyleSheet(
            f"background-color: {fill_col}; color: #0f172a; font-weight: 700; border-radius: 4px; padding: 2px 7px;"
        )
        self.btn_style_border.setProperty("_chosen_color", border_col)
        self.btn_style_border.setStyleSheet(
            f"border: 2px solid {border_col}; font-weight: 700; border-radius: 4px; padding: 2px 7px;"
        )

        lbl_col = str(st.get("label_color") or "#0f172a")
        self.btn_style_lbl_color.setProperty("_chosen_color", lbl_col)
        self.btn_style_lbl_color.setStyleSheet(
            f"background-color: {lbl_col}; color: #ffffff; font-weight: 700; border-radius: 4px; padding: 2px 5px;"
        )

        halo_op = int(
            st["label_halo_opacity"]
            if st.get("label_halo_opacity") is not None
            else (90 if st.get("label_halo", True) else 0)
        )
        halo_op = max(0, min(100, halo_op))

        inline_ctrls = (
            self.sp_style_opacity,
            self.chk_style_outline_only,
            self.sp_style_width,
            self.cb_style_cat,
            self.sp_style_min_zoom,
            self.cb_style_label,
            self.cb_style_label_2,
            self.sp_style_lbl_size,
            self.sl_style_lbl_halo,
            self.cb_style_lbl_pos,
            self.sp_style_lbl_zoom,
        )
        for w in inline_ctrls:
            w.blockSignals(True)
        try:
            self.sp_style_opacity.setValue(op_pct)
            self.chk_style_outline_only.setChecked(outline_only)
            if hasattr(self.sp_style_width, "setValue"):
                self.sp_style_width.setValue(stroke_w)
            self.sp_style_min_zoom.setValue(max(0, min(14, int(st.get("min_zoom", 0) or 0))))
            self.sp_style_lbl_size.setValue(max(3, min(24, int(st.get("label_size", 10) or 10))))
            self.sl_style_lbl_halo.setValue(halo_op)
            if hasattr(self, "lbl_style_halo_val"):
                self.lbl_style_halo_val.setText(f"{halo_op}%")
            idx_lp = self.cb_style_lbl_pos.findData(str(st.get("label_position") or "center").strip())
            self.cb_style_lbl_pos.setCurrentIndex(idx_lp if idx_lp >= 0 else 0)
            self.sp_style_lbl_zoom.setValue(max(0, min(18, int(st.get("label_min_zoom", 0) or 0))))
            fields = self._fields_for_inline_layer(lname)
            self.cb_style_cat.clear()
            self.cb_style_cat.addItem(tr("style_mode_single", self.lang), "")
            for fn in fields:
                self.cb_style_cat.addItem(fn, fn)
            cat_field = str(st.get("style_field") or ((st.get("legend_fields") or [""])[0] if st.get("legend_fields") else ""))
            if cat_field:
                idx_c = self.cb_style_cat.findData(cat_field)
                if idx_c >= 0:
                    self.cb_style_cat.setCurrentIndex(idx_c)
            raw_lbl_fields = [str(f).strip() for f in (st.get("label_fields") or []) if str(f or "").strip()]
            if not raw_lbl_fields and str(st.get("label_field") or "").strip():
                raw_lbl_fields = [str(st.get("label_field") or "").strip()]
            for lf in raw_lbl_fields:
                if lf not in fields:
                    fields.append(lf)
            self._populate_inline_lbl_combo(self.cb_style_label, fields, raw_lbl_fields[0] if len(raw_lbl_fields) > 0 else "")
            self._populate_inline_lbl_combo(self.cb_style_label_2, fields, raw_lbl_fields[1] if len(raw_lbl_fields) > 1 else "")
            self._clear_inline_extra_label_rows()
            for ef in raw_lbl_fields[2:4]:
                self._add_inline_extra_label_row(ef, loading=True)
        finally:
            for w in inline_ctrls:
                w.blockSignals(False)

    def _pick_inline_fill_color(self) -> None:
        if QColorDialog is None:
            return
        cur = str(self.btn_style_fill.property("_chosen_color") or "#38bdf8")
        col = QColorDialog.getColor(QColor(cur), self, tr("style_fill", self.lang))
        if col.isValid():
            self.btn_style_fill.setProperty("_chosen_color", col.name())
            self.btn_style_fill.setStyleSheet(
                f"background-color: {col.name()}; color: #0f172a; font-weight: 700; border-radius: 4px; padding: 2px 7px;"
            )
            self._apply_inline_style()

    def _pick_inline_border_color(self) -> None:
        if QColorDialog is None:
            return
        cur = str(self.btn_style_border.property("_chosen_color") or "#38bdf8")
        col = QColorDialog.getColor(QColor(cur), self, tr("style_border", self.lang))
        if col.isValid():
            self.btn_style_border.setProperty("_chosen_color", col.name())
            self.btn_style_border.setStyleSheet(
                f"border: 2px solid {col.name()}; font-weight: 700; border-radius: 4px; padding: 2px 7px;"
            )
            self._apply_inline_style()

    def _pick_inline_label_color(self) -> None:
        if QColorDialog is None:
            return
        cur = str(self.btn_style_lbl_color.property("_chosen_color") or "#0f172a")
        col = QColorDialog.getColor(QColor(cur), self, tr("lbl_label_color", self.lang))
        if col.isValid():
            self.btn_style_lbl_color.setProperty("_chosen_color", col.name())
            self.btn_style_lbl_color.setStyleSheet(
                f"background-color: {col.name()}; color: #ffffff; font-weight: 700; border-radius: 4px; padding: 2px 5px;"
            )
            self._apply_inline_style()

    def _apply_inline_style(self) -> None:
        lname = str(getattr(self, "_style_edit_layer", "") or "").strip()
        if not lname:
            return
        if not isinstance(getattr(self.config, "map_layer_styles", None), dict):
            self.config.map_layer_styles = {}
        st = dict(self.config.map_layer_styles.get(lname, {}) or {})
        fill_col = str(self.btn_style_fill.property("_chosen_color") or st.get("color") or "#38bdf8")
        border_col = str(self.btn_style_border.property("_chosen_color") or fill_col)
        op = round(max(5, min(100, float(self.sp_style_opacity.value()))) / 100.0, 2)
        outline_only = bool(self.chk_style_outline_only.isChecked())
        stroke_w = float(self.sp_style_width.value()) if hasattr(self.sp_style_width, "value") else 1.5
        cat_field = str(self.cb_style_cat.currentData() or "")
        lbl_fields = self._collect_inline_label_fields()
        halo_op = max(0, min(100, int(self.sl_style_lbl_halo.value())))

        st["color"] = fill_col
        st["border_color"] = border_col
        st["opacity"] = op
        st["outline_only"] = outline_only
        st["stroke_width"] = stroke_w
        st["min_zoom"] = max(0, min(14, int(self.sp_style_min_zoom.value())))
        st["label_fields"] = lbl_fields
        st["label_field"] = lbl_fields[0] if lbl_fields else ""
        st["label_size"] = max(3, min(24, int(self.sp_style_lbl_size.value())))
        st["label_color"] = str(self.btn_style_lbl_color.property("_chosen_color") or st.get("label_color") or "#0f172a")
        st["label_halo_opacity"] = halo_op
        st["label_halo"] = halo_op > 0
        st["label_multi_row"] = False
        st["label_position"] = str(self.cb_style_lbl_pos.currentData() or "center")
        st["label_min_zoom"] = max(0, min(18, int(self.sp_style_lbl_zoom.value())))
        if cat_field:
            st["style_mode"] = "category"
            st["style_field"] = cat_field
            st["legend_fields"] = [cat_field]
        else:
            st["style_mode"] = "single"
            st["style_field"] = ""
            st["legend_fields"] = []
        self.config.map_layer_styles[lname] = st
        self.apply_configured_layer_styles()
        if self._canvas is not None:
            try:
                self._canvas.refresh()
            except Exception:
                pass
        if self.on_edit_saved:
            self.on_edit_saved()

    def _apply_inline_layer_order(self) -> None:
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        if not isinstance(getattr(self.config, "map_layer_styles", None), dict):
            self.config.map_layer_styles = {}
        ordered: List[str] = []
        for i in range(self.inline_layers_list.count()):
            it = self.inline_layers_list.item(i)
            if it is not None:
                lname = it.text()
                is_vis = it.checkState() == checked_st
                st = dict(self.config.map_layer_styles.get(lname, {}) or {})
                st["visible"] = is_vis
                self.config.map_layer_styles[lname] = st
                if is_vis:
                    ordered.append(lname)
        self.config.map_layers = ordered
        if ordered:
            self.config.layer_name = ordered[0]
        self.sync_layers_and_zoom(force_layers=True)
        if self.on_edit_saved:
            self.on_edit_saved()

    def _open_layer_order_dialog(self) -> None:
        QDialogCls = getattr(QtWidgets, "QDialog", None)
        if QDialogCls is None:
            return
        dlg = QDialogCls(self)
        dlg.setWindowTitle(tr("map_layers_title", self.lang))
        dlg.setMinimumSize(360, 320)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(6)

        hint = QLabel(tr("map_layers_hint", self.lang))
        hint.setWordWrap(True)
        hint.setProperty("role", "muted")
        lay.addWidget(hint)

        lw = DragFieldListWidget(role_mode="layer_order", lang=self.lang)
        self._populate_layer_order_list(lw)

        btn_row = QHBoxLayout()
        btn_up = QPushButton(tr("btn_move_up", self.lang))
        btn_up.clicked.connect(lambda: lw.move_selected(-1))
        btn_dn = QPushButton(tr("btn_move_down", self.lang))
        btn_dn.clicked.connect(lambda: lw.move_selected(1))
        btn_row.addWidget(btn_up)
        btn_row.addWidget(btn_dn)
        btn_row.addStretch()
        lay.addLayout(btn_row)
        lay.addWidget(lw, 1)

        footer = QHBoxLayout()
        footer.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", self.lang))
        btn_cancel.clicked.connect(dlg.reject)
        btn_ok = QPushButton(tr("btn_save", self.lang))
        btn_ok.setProperty("btnRole", "primary")
        btn_ok.clicked.connect(dlg.accept)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_ok)
        lay.addLayout(footer)

        from .qt_compat import exec_dialog
        if exec_dialog(dlg):
            checked_st = qt_enum(Qt, "CheckState", "Checked")
            if not isinstance(getattr(self.config, "map_layer_styles", None), dict):
                self.config.map_layer_styles = {}
            ordered = []
            for i in range(lw.count()):
                it = lw.item(i)
                lname = it.text()
                is_vis = it.checkState() == checked_st
                st = dict(self.config.map_layer_styles.get(lname, {}) or {})
                st["visible"] = is_vis
                self.config.map_layer_styles[lname] = st
                if is_vis:
                    ordered.append(lname)
            self.config.map_layers = ordered
            if ordered:
                self.config.layer_name = ordered[0]
            if self.layers_panel.isVisible():
                self._refresh_inline_layers_list()
            self.sync_layers_and_zoom(force_layers=True)
            if self.on_edit_saved:
                self.on_edit_saved()

    def zoom_to_selection_or_layers(self) -> None:
        if self._canvas is None:
            return
        try:
            from qgis.core import QgsCoordinateTransform, QgsProject, QgsRectangle

            proj = QgsProject.instance()
            dest_crs = self._canvas.mapSettings().destinationCrs()
            wanted = list(self.config.map_layers or [])
            if not wanted and self.config.layer_name:
                wanted = [self.config.layer_name]

            comb: Optional[Any] = None
            for lname in wanted:
                lyr = self._resolve_layer(lname)
                if lyr is None:
                    continue
                ext = lyr.boundingBoxOfSelected() if hasattr(lyr, "selectedFeatureCount") and lyr.selectedFeatureCount() > 0 else lyr.extent()
                if ext.isEmpty():
                    continue
                if hasattr(lyr, "crs") and lyr.crs() != dest_crs:
                    try:
                        ext = QgsCoordinateTransform(lyr.crs(), dest_crs, proj).transformBoundingBox(ext)
                    except Exception:
                        pass
                if comb is None:
                    comb = QgsRectangle(ext)
                else:
                    comb.combineExtentWith(ext)
            if comb is not None and not comb.isEmpty():
                comb.scale(1.08)
                self._canvas.setExtent(comb)
                self._canvas.refresh()
                return
        except Exception:
            pass
        self.sync_layers_and_zoom(force_layers=True)

    def zoom_to_feature_ids(
        self,
        layer_name: str,
        feature_ids: List[Any],
        fallback_points: Optional[List[Tuple[float, float]]] = None,
    ) -> None:
        """Zoom embedded QGIS canvas smoothly to the matching feature IDs or WGS84 points."""
        if self._canvas is None:
            return
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsFeatureRequest,
                QgsProject,
                QgsRectangle,
            )

            proj = QgsProject.instance()
            dest_crs = self._canvas.mapSettings().destinationCrs()
            comb: Optional[Any] = None

            int_fids: List[int] = []
            for tfid in (feature_ids or [])[:600]:
                try:
                    int_fids.append(int(tfid))
                except (TypeError, ValueError):
                    pass

            lyr = self._resolve_layer(layer_name) if layer_name else None
            if lyr is not None and int_fids:
                req = QgsFeatureRequest().setFilterFids(int_fids)
                for feat in lyr.getFeatures(req):
                    if feat.hasGeometry() and not feat.geometry().isEmpty():
                        bb = feat.geometry().boundingBox()
                        if comb is None:
                            comb = QgsRectangle(bb)
                        else:
                            comb.combineExtentWith(bb)
                if comb is not None and not comb.isEmpty() and hasattr(lyr, "crs") and lyr.crs() != dest_crs:
                    comb = QgsCoordinateTransform(lyr.crs(), dest_crs, proj).transformBoundingBox(comb)

            if (comb is None or comb.isEmpty()) and fallback_points:
                # Normalize (lat, lon) pairs used across DashboardDockWidget / HTML exporter
                pts = []
                for a, b in fallback_points:
                    if a is None or b is None:
                        continue
                    fa, fb = float(a), float(b)
                    # Estonia latitude is ~57..60, longitude ~21..29
                    if fa > 45.0 and fb < 40.0:
                        lon_v, lat_v = fb, fa
                    else:
                        lon_v, lat_v = fa, fb
                    pts.append((lon_v, lat_v))
                if pts:
                    xs = [p[0] for p in pts]
                    ys = [p[1] for p in pts]
                    wgs_rect = QgsRectangle(min(xs), min(ys), max(xs), max(ys))
                    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                    comb = (
                        QgsCoordinateTransform(wgs84, dest_crs, proj).transformBoundingBox(wgs_rect)
                        if dest_crs != wgs84
                        else wgs_rect
                    )

            if comb is not None and not comb.isEmpty():
                pad_x = max(comb.width() * 0.14, 300.0 if not dest_crs.isGeographic() else 0.004)
                pad_y = max(comb.height() * 0.14, 300.0 if not dest_crs.isGeographic() else 0.004)
                zoom_rect = QgsRectangle(
                    comb.xMinimum() - pad_x,
                    comb.yMinimum() - pad_y,
                    comb.xMaximum() + pad_x,
                    comb.yMaximum() + pad_y,
                )
                self._canvas.setExtent(zoom_rect)
                self._canvas.refresh()
        except Exception:
            pass

    def sync_layers_and_zoom(self, force_layers: bool = True) -> None:
        if self._canvas is None:
            return
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsProject,
                QgsRasterLayer,
                QgsRectangle,
            )

            proj = QgsProject.instance()
            wanted = list(self.config.map_layers or [])
            if not wanted and self.config.layer_name:
                wanted = [self.config.layer_name]
            if not getattr(self.config, "map_layers_custom_order", False) and len(wanted) > 1:
                layer_stats: Dict[str, Any] = {}
                layer_geom_types: Dict[str, str] = {}
                for ln in wanted:
                    lyr_w = self._resolve_layer(ln)
                    if lyr_w is not None and hasattr(lyr_w, "featureCount"):
                        try:
                            fc = int(lyr_w.featureCount())
                            layer_stats[ln] = {"feature_count": fc if fc >= 0 else 10**6}
                            if hasattr(lyr_w, "geometryType"):
                                g_str = str(lyr_w.geometryType()).lower()
                                layer_geom_types[ln] = "point" if "0" in g_str or "point" in g_str else ("line" if "1" in g_str or "line" in g_str else "polygon")
                        except Exception:
                            pass
                wanted = OgcConnector.sort_layers_automatically(
                    wanted, layer_stats=layer_stats, layer_geom_types=layer_geom_types
                )
            bm_id = self.config.map_basemap or "MA-HALLKAART"
            layers_key = (tuple(wanted), bm_id, self._is_sync_main_canvas())

            layers_changed = bool(force_layers or layers_key != self._last_layers_key)
            if layers_changed:
                layers_to_show: List[Any] = []
                for lname in wanted:
                    lyr = self._resolve_layer(lname)
                    if lyr is not None:
                        layers_to_show.append(lyr)

                bm_def = next((m for m in MAAAMET_BASEMAPS if m[0] == bm_id), MAAAMET_BASEMAPS[0])
                wms_layers_param = "EESTIFOTO,HYBRID" if bm_def[0] == "HYBRID" else bm_def[0]
                bm_ds = DataSourceConfig(
                    name=bm_def[1],
                    source_type="wms",
                    url=bm_def[2],
                    typename_or_layers=wms_layers_param,
                    image_format=bm_def[3],
                    crs="EPSG:3301",
                    version="1.1.1",
                    is_basemap=True,
                )
                existing_bm = proj.mapLayersByName(bm_def[1])
                if existing_bm:
                    self._basemap_layer = existing_bm[0]
                else:
                    uri = OgcConnector.build_qgis_wms_uri(bm_ds)
                    wms = QgsRasterLayer(uri, bm_def[1], "wms")
                    if wms.isValid():
                        self._basemap_layer = wms

                if self._basemap_layer is not None:
                    layers_to_show.append(self._basemap_layer)

                self._canvas.setLayers(layers_to_show)
                self._last_layers_key = layers_key

            if self._canvas.extent().isEmpty():
                wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                dest_crs = QgsCoordinateReferenceSystem("EPSG:3301")
                hb = list(getattr(self.config, "map_home_bounds", []) or [])
                init_ext = None
                if len(hb) == 4:
                    south, west, north, east = [float(v) for v in hb]
                    rect_hb = QgsRectangle(west, south, east, north)
                    init_ext = QgsCoordinateTransform(wgs84, dest_crs, proj).transformBoundingBox(rect_hb)
                if init_ext is None or init_ext.isEmpty():
                    try:
                        import qgis.utils
                        main_iface = getattr(qgis.utils, "iface", None)
                        main_canvas = main_iface.mapCanvas() if main_iface and hasattr(main_iface, "mapCanvas") else None
                        if main_canvas is not None:
                            m_ext = main_canvas.extent()
                            m_crs = main_canvas.mapSettings().destinationCrs()
                            if m_ext and not m_ext.isEmpty():
                                tr_ext = (
                                    QgsCoordinateTransform(m_crs, dest_crs, proj).transformBoundingBox(m_ext)
                                    if (m_crs.isValid() and m_crs != dest_crs)
                                    else QgsRectangle(m_ext)
                                )
                                if 100.0 < tr_ext.width() <= 600000.0 and 100.0 < tr_ext.height() <= 600000.0:
                                    init_ext = tr_ext
                    except Exception:
                        pass
                if init_ext is None or init_ext.isEmpty():
                    rect_est = QgsRectangle(21.65, 57.48, 28.25, 59.70)
                    init_ext = QgsCoordinateTransform(wgs84, dest_crs, proj).transformBoundingBox(rect_est)
                self._canvas.setExtent(init_ext)
            if layers_changed:
                if hasattr(self._canvas, "mapCanvasRefreshed"):
                    self._set_map_rendering(True)
                self._canvas.refresh()
                self.apply_configured_layer_styles()
            self._update_scale_label()
        except Exception:
            pass

    @staticmethod
    def _apply_dashboard_labeling(
        lyr: Any,
        label_field: str,
        style_cfg: Optional[Dict[str, Any]] = None,
        width_scale_factor: float = 1.0,
    ) -> None:
        if lyr is None or not hasattr(lyr, "setLabelsEnabled"):
            return
        cfg = style_cfg if isinstance(style_cfg, dict) else {}
        raw_fields = [str(f).strip() for f in (cfg.get("label_fields") or []) if str(f or "").strip()]
        clean_single = str(label_field or "").strip()
        if not raw_fields and clean_single:
            raw_fields = [clean_single]
        if not raw_fields:
            try:
                lyr.setLabelsEnabled(False)
            except Exception:
                pass
            return
        lbl_size = max(3, min(24, int(cfg.get("label_size", 10) or 10)))
        lbl_color_hex = str(cfg.get("label_color") or "#0f172a").strip()
        halo_op = int(
            cfg["label_halo_opacity"]
            if cfg.get("label_halo_opacity") is not None
            else (90 if cfg.get("label_halo", True) else 0)
        )
        halo_op = max(0, min(100, halo_op))
        lbl_halo = halo_op > 0
        lbl_multi = bool(cfg.get("label_multi_row", False)) if len(raw_fields) == 1 else False
        lbl_pos = str(cfg.get("label_position") or "center").strip()
        lbl_zoom = max(0, min(18, int(cfg.get("label_min_zoom", 0) or 0)))
        try:
            import qgis.core as qgis_core
            from qgis.core import (
                QgsPalLayerSettings,
                QgsTextBufferSettings,
                QgsTextFormat,
                QgsVectorLayerSimpleLabeling,
            )

            QgisCls = getattr(qgis_core, "Qgis", None)
            QgsWkbTypesCls = getattr(qgis_core, "QgsWkbTypes", None)

            def _resolve_label_placement(*names: str) -> Any:
                lp_enum = getattr(QgisCls, "LabelPlacement", None) if QgisCls is not None else None
                for nm in names:
                    if lp_enum is not None and hasattr(lp_enum, nm):
                        return getattr(lp_enum, nm)
                    if hasattr(QgsPalLayerSettings, nm):
                        return getattr(QgsPalLayerSettings, nm)
                return None

            geom_kind = "polygon"
            if hasattr(lyr, "geometryType"):
                try:
                    gt = lyr.geometryType()
                    gt_poly = getattr(getattr(QgisCls, "GeometryType", None), "Polygon", None) if QgisCls is not None else None
                    gt_line = getattr(getattr(QgisCls, "GeometryType", None), "Line", None) if QgisCls is not None else None
                    gt_pt = getattr(getattr(QgisCls, "GeometryType", None), "Point", None) if QgisCls is not None else None
                    wkb_poly = getattr(QgsWkbTypesCls, "PolygonGeometry", None) if QgsWkbTypesCls is not None else None
                    wkb_line = getattr(QgsWkbTypesCls, "LineGeometry", None) if QgsWkbTypesCls is not None else None
                    wkb_pt = getattr(QgsWkbTypesCls, "PointGeometry", None) if QgsWkbTypesCls is not None else None
                    if gt in (gt_pt, wkb_pt) or str(gt).lower().endswith("point"):
                        geom_kind = "point"
                    elif gt in (gt_line, wkb_line) or str(gt).lower().endswith("line"):
                        geom_kind = "line"
                    elif gt in (gt_poly, wkb_poly) or str(gt).lower().endswith("polygon"):
                        geom_kind = "polygon"
                    elif isinstance(gt, int):
                        geom_kind = "point" if gt == 0 else ("line" if gt == 1 else "polygon")
                except Exception:
                    geom_kind = "polygon"

            pal = QgsPalLayerSettings()
            if len(raw_fields) > 1:
                quoted = ", ".join('"' + f.replace('"', '""') + '"' for f in raw_fields)
                pal.fieldName = (
                    f"array_to_string(array_filter(array({quoted}), "
                    "@element IS NOT NULL AND to_string(@element) != ''), '\\n')"
                )
                pal.isExpression = True
            else:
                pal.fieldName = raw_fields[0]
                pal.isExpression = False
            pal.enabled = True
            fmt = QgsTextFormat()
            fmt.setSize(lbl_size)
            txt_col = QColor(lbl_color_hex)
            if txt_col.isValid():
                fmt.setColor(txt_col)
            else:
                txt_col = QColor("#0f172a")
                fmt.setColor(txt_col)

            buf = QgsTextBufferSettings()
            buf.setEnabled(lbl_halo)
            buf.setSize(1.2)
            lum = (0.299 * txt_col.redF()) + (0.587 * txt_col.greenF()) + (0.114 * txt_col.blueF())
            if hasattr(buf, "setOpacity"):
                buf.setOpacity(float(halo_op) / 100.0)
            buf_col = QColor("#0f172a" if lum > 0.65 else "#ffffff")
            if hasattr(buf_col, "setAlpha"):
                buf_col.setAlpha(int(round(255.0 * float(halo_op) / 100.0)))
            buf.setColor(buf_col)
            fmt.setBuffer(buf)

            if lbl_pos in ("outside_line", "outside_callout"):
                if geom_kind == "point":
                    pl_val = _resolve_label_placement("AroundPoint")
                    if pl_val is not None:
                        pal.placement = pl_val
                    if hasattr(pal, "dist"):
                        pal.dist = 4.0
                elif geom_kind == "line":
                    pl_val = _resolve_label_placement("Line")
                    if pl_val is not None:
                        pal.placement = pl_val
                    if hasattr(pal, "dist"):
                        pal.dist = 3.0
                else:
                    pl_val = _resolve_label_placement("OutsidePolygons", "AroundPoint")
                    if pl_val is not None:
                        pal.placement = pl_val
                    if hasattr(pal, "dist"):
                        pal.dist = 4.5
                try:
                    from qgis.core import QgsSimpleLineCallout

                    co = QgsSimpleLineCallout()
                    co.setEnabled(True)
                    if hasattr(co, "setMinimumLength"):
                        co.setMinimumLength(1.5)
                    if hasattr(pal, "setCallout"):
                        pal.setCallout(co)
                except Exception:
                    pass
                if lbl_pos == "outside_callout":
                    try:
                        from qgis.core import QgsTextBackgroundSettings

                        bg = QgsTextBackgroundSettings()
                        bg.setEnabled(True)
                        shape_rect = getattr(
                            getattr(QgsTextBackgroundSettings, "ShapeType", None),
                            "ShapeRectangle",
                            getattr(QgsTextBackgroundSettings, "ShapeRectangle", None),
                        )
                        if shape_rect is not None and hasattr(bg, "setType"):
                            bg.setType(shape_rect)
                        qsizef_cls = getattr(QtCore, "QSizeF", None)
                        if qsizef_cls is not None:
                            if hasattr(bg, "setSize"):
                                bg.setSize(qsizef_cls(1.5, 0.8))
                            if hasattr(bg, "setRadii"):
                                bg.setRadii(qsizef_cls(1.5, 1.5))
                        if hasattr(bg, "setFillColor"):
                            bg.setFillColor(QColor(15, 23, 42, 230) if lum > 0.65 else QColor(255, 255, 255, 235))
                        if hasattr(bg, "setStrokeColor"):
                            bg.setStrokeColor(QColor("#475569" if lum > 0.65 else "#94a3b8"))
                        if hasattr(bg, "setStrokeWidth"):
                            bg.setStrokeWidth(0.35)
                        if hasattr(fmt, "setBackground"):
                            fmt.setBackground(bg)
                    except Exception:
                        pass
            else:
                if geom_kind == "point":
                    pl_val = _resolve_label_placement("OverPoint", "AroundPoint")
                elif geom_kind == "line":
                    pl_val = _resolve_label_placement("Line")
                else:
                    pl_val = _resolve_label_placement("Horizontal", "Free")
                if pl_val is not None:
                    pal.placement = pl_val
                try:
                    from qgis.core import QgsTextBackgroundSettings

                    bg_off = QgsTextBackgroundSettings()
                    bg_off.setEnabled(False)
                    if hasattr(fmt, "setBackground"):
                        fmt.setBackground(bg_off)
                except Exception:
                    pass

            pal.setFormat(fmt)

            if lbl_multi:
                if hasattr(pal, "autoWrapLength"):
                    pal.autoWrapLength = 18
                if hasattr(pal, "wrapChar"):
                    pal.wrapChar = "|"

            if lbl_zoom > 0:
                ma_res = [
                    4000.0, 2000.0, 1000.0, 500.0, 250.0, 125.0, 62.5,
                    31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625,
                ]
                res = ma_res[min(14, lbl_zoom)] / (2 ** max(0, lbl_zoom - 14))
                min_scale = float(res * 3779.52756 * 1.15 * max(0.5, float(width_scale_factor or 1.0)))
                pal.scaleVisibility = True
                pal.minimumScale = min_scale
                pal.maximumScale = 0

            lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            lyr.setLabelsEnabled(True)
        except Exception:
            pass

    def apply_configured_layer_styles(self, update_renderer: bool = True) -> None:
        styles = getattr(self.config, "map_layer_styles", {}) or {}
        sync_main = self._is_sync_main_canvas()
        target_names: List[str] = list(styles.keys())
        if not sync_main:
            for ml in list(self.config.map_layers or []) + ([self.config.layer_name] if self.config.layer_name else []):
                if ml and ml not in styles and ml not in target_names:
                    target_names.append(ml)
        if not target_names:
            return
        try:
            from qgis.core import (
                QgsCategorizedSymbolRenderer,
                QgsProject,
                QgsRendererCategory,
                QgsSingleSymbolRenderer,
                QgsSymbol,
            )
        except ImportError:
            return
        ma_res = [
            4000.0, 2000.0, 1000.0, 500.0, 250.0, 125.0, 62.5,
            31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625,
        ]
        cfg_w = max(320.0, float(getattr(self.config, "layout_w", 0) or 0))
        if not getattr(self.config, "layout_w", 0):
            cfg_w = max(320.0, float(self._canvas.width() if (self._canvas and hasattr(self._canvas, "width")) else 540.0) or 540.0)
        canvas_w = max(160.0, float(self._canvas.width() if (self._canvas and hasattr(self._canvas, "width")) else cfg_w) or cfg_w)
        width_scale_factor = cfg_w / canvas_w

        for lname in target_names:
            st = styles.get(lname, {})
            if not isinstance(st, dict):
                st = {}
            lyr = self._resolve_layer(lname)
            if lyr is None:
                continue
            try:
                min_z = max(0, min(14, int(st.get("min_zoom", 0) or 0)))
                scale_changed = False
                if hasattr(lyr, "setScaleBasedVisibility"):
                    was_enabled = bool(lyr.hasScaleBasedVisibility()) if hasattr(lyr, "hasScaleBasedVisibility") else None
                    if min_z > 0:
                        html_max_scale = ma_res[min_z] * 3779.52756 * 1.15
                        max_scale = float(html_max_scale * width_scale_factor)
                        old_min = float(lyr.minimumScale()) if hasattr(lyr, "minimumScale") else -1.0
                        if was_enabled is not True or abs(old_min - max_scale) > max(1.0, max_scale * 0.01):
                            lyr.setMinimumScale(max_scale)
                            lyr.setMaximumScale(0)
                            lyr.setScaleBasedVisibility(True)
                            scale_changed = True
                    else:
                        if was_enabled is True:
                            lyr.setScaleBasedVisibility(False)
                            scale_changed = True
                if not update_renderer:
                    if scale_changed and hasattr(lyr, "triggerRepaint"):
                        lyr.triggerRepaint()
                    continue

                first_lbl_field = str(
                    st.get("label_field")
                    or ((st.get("label_fields") or [""])[0] if isinstance(st.get("label_fields"), list) and st.get("label_fields") else "")
                    or ""
                )
                if not sync_main:
                    self._apply_dashboard_labeling(
                        lyr,
                        first_lbl_field,
                        style_cfg=st,
                        width_scale_factor=width_scale_factor,
                    )
                elif first_lbl_field:
                    self._apply_dashboard_labeling(
                        lyr,
                        first_lbl_field,
                        style_cfg=st,
                        width_scale_factor=width_scale_factor,
                    )

                mode = str(st.get("style_mode") or "auto")
                cat_fields = [str(f).strip() for f in (st.get("legend_fields") or []) if str(f).strip()]
                if not cat_fields and st.get("style_field"):
                    cat_fields = [str(st["style_field"]).strip()]
                opacity = max(0.05, min(1.0, float(st.get("opacity", 0.45))))

                def _apply_symbol_style(sym_obj: Any, fill_hex: str, border_hex: Optional[str] = None) -> None:
                    if sym_obj is None:
                        return
                    f_col = QColor(fill_hex)
                    if outline_only_flag:
                        f_col.setAlpha(0)
                    else:
                        f_col.setAlphaF(opacity)
                    sym_obj.setColor(f_col)
                    if hasattr(sym_obj, "symbolLayerCount") and sym_obj.symbolLayerCount() > 0:
                        sl0 = sym_obj.symbolLayer(0)
                        b_col = QColor(border_hex or fill_hex)
                        if hasattr(sl0, "setStrokeColor"):
                            sl0.setStrokeColor(b_col)
                        if hasattr(sl0, "setStrokeWidth") and stroke_w_val is not None:
                            sl0.setStrokeWidth(float(stroke_w_val) * 0.26)

                outline_only_flag = bool(st.get("outline_only", False))
                stroke_w_val = st.get("stroke_width")
                explicit_border = str(st.get("border_color") or "").strip()

                if mode == "category" and cat_fields and hasattr(lyr, "setRenderer"):
                    cat_field = (
                        cat_fields[0]
                        if len(cat_fields) == 1
                        else ("concat(" + ", ' | ', ".join(f'coalesce(to_string("{f}"), \'\')' for f in cat_fields) + ")")
                    )
                    # Collect distinct non-null values cleanly without capping at 24 or downloading full geometries:
                    # 1) cached dashboard records in RAM, 2) C++ QgsVectorLayer.uniqueValues, 3) attribute-only scan.
                    seen_by_str: Dict[str, Any] = {}
                    def _is_nullish(v: Any) -> bool:
                        if v is None:
                            return True
                        if "NULL" in repr(v) and type(v).__name__ in ("QVariant", "QPyNullVariant"):
                            return True
                        return str(v).strip() == ""

                    cached_rows = (getattr(self, "_records_cache", None) or {}).get(lname) or []
                    if cached_rows:
                        for row in cached_rows:
                            if not isinstance(row, dict):
                                continue
                            if len(cat_fields) == 1:
                                raw_v = row.get(cat_fields[0])
                                if not _is_nullish(raw_v):
                                    seen_by_str.setdefault(str(raw_v), raw_v)
                            else:
                                parts = [row.get(f) for f in cat_fields]
                                if all(not _is_nullish(p) for p in parts):
                                    joined = " | ".join(str(p) for p in parts)
                                    seen_by_str.setdefault(joined, joined)

                    if not seen_by_str and len(cat_fields) == 1 and hasattr(lyr, "fields") and hasattr(lyr, "uniqueValues"):
                        try:
                            fidx = lyr.fields().indexOf(cat_fields[0])
                            if fidx >= 0:
                                for raw_v in list(lyr.uniqueValues(fidx, 300) or []):
                                    if not _is_nullish(raw_v):
                                        seen_by_str.setdefault(str(raw_v), raw_v)
                        except Exception:
                            pass

                    if not seen_by_str and hasattr(lyr, "getFeatures"):
                        try:
                            from qgis.core import QgsFeatureRequest

                            req = QgsFeatureRequest()
                            if hasattr(QgsFeatureRequest, "NoGeometry"):
                                req.setFlags(QgsFeatureRequest.NoGeometry)
                            if hasattr(lyr, "fields") and hasattr(req, "setSubsetOfAttributes"):
                                idxs = [lyr.fields().indexOf(f) for f in cat_fields if lyr.fields().indexOf(f) >= 0]
                                if idxs:
                                    req.setSubsetOfAttributes(idxs)
                            for ft in lyr.getFeatures(req):
                                parts = [ft[f] for f in cat_fields]
                                if len(cat_fields) == 1:
                                    raw_v = parts[0]
                                    if not _is_nullish(raw_v):
                                        seen_by_str.setdefault(str(raw_v), raw_v)
                                elif all(not _is_nullish(p) for p in parts):
                                    joined = " | ".join(str(p) for p in parts)
                                    seen_by_str.setdefault(joined, joined)
                        except Exception:
                            pass

                    vals_items = [seen_by_str[k] for k in sorted(seen_by_str.keys())[:256]]
                    pal = (
                        PALETTES["emerald"]
                        + PALETTES["forest"]
                        + PALETTES["ocean"]
                        + PALETTES["amber"]
                        + PALETTES["rose"]
                        + PALETTES["corporate"]
                    )
                    cats = []
                    for idx_v, val in enumerate(vals_items):
                        sym = QgsSymbol.defaultSymbol(lyr.geometryType())
                        if idx_v < len(pal):
                            c_hex = pal[idx_v]
                        else:
                            hue = (idx_v * 137) % 360
                            qc = QColor()
                            qc.setHsl(hue, 185, 130)
                            c_hex = qc.name()
                        _apply_symbol_style(sym, c_hex, explicit_border or c_hex)
                        cats.append(QgsRendererCategory(val, sym, str(val)))

                    # Always append catch-all ("All other values", value=None) so remaining / NULL / dynamic WFS
                    # features are NEVER hidden from the map canvas in categorized mode!
                    else_sym = QgsSymbol.defaultSymbol(lyr.geometryType())
                    fallback_hex = str(st.get("color") or "#64748b")
                    _apply_symbol_style(else_sym, fallback_hex, explicit_border or fallback_hex)
                    cats.append(QgsRendererCategory(None, else_sym, tr("cat_other", self.lang)))

                    if cats:
                        lyr.setRenderer(QgsCategorizedSymbolRenderer(cat_field, cats))
                        if hasattr(lyr, "triggerRepaint"):
                            lyr.triggerRepaint()
                        continue

                if (
                    (mode == "single" or not cat_fields)
                    and (st.get("color") or st.get("border_color") or st.get("outline_only") or not sync_main)
                    and hasattr(lyr, "renderer")
                    and hasattr(lyr, "geometryType")
                ):
                    rend = lyr.renderer()
                    sym = rend.symbol() if (rend and hasattr(rend, "symbol")) else None
                    is_cat_rend = hasattr(rend, "categories") if rend is not None else False
                    if (sym is None or is_cat_rend or (not sync_main and rend is not None)) and hasattr(lyr, "setRenderer"):
                        sym = QgsSymbol.defaultSymbol(lyr.geometryType())
                        if sym is not None:
                            lyr.setRenderer(QgsSingleSymbolRenderer(sym))
                    if sym is not None:
                        fill_hex = str(st.get("color") or OgcConnector.default_layer_color_for_name(lname) or "#38bdf8")
                        _apply_symbol_style(sym, fill_hex, explicit_border or fill_hex)
                        if hasattr(lyr, "triggerRepaint"):
                            lyr.triggerRepaint()
            except Exception:
                continue

    def _open_style_legend_dialog(self) -> None:
        from .dialogs import MapLegendDialog
        from .qt_compat import exec_dialog

        fields_map: Dict[str, List[str]] = {}
        dcfg = self._dashboard_cfg()
        sync_main = self._is_sync_main_canvas()
        if sync_main:
            try:
                from qgis.core import QgsProject

                for lyr in QgsProject.instance().mapLayers().values():
                    if hasattr(lyr, "fields"):
                        fields_map[lyr.name()] = [f.name() for f in lyr.fields()]
            except Exception:
                pass
        else:
            for lname in list(self.config.map_layers or []) + ([self.config.layer_name] if self.config.layer_name else []):
                if not lname:
                    continue
                lyr = self._resolve_layer(lname)
                if lyr is not None and hasattr(lyr, "fields"):
                    try:
                        fields_map[lname] = [f.name() for f in lyr.fields()]
                    except Exception:
                        pass
        if callable(getattr(self, "layer_fields_provider", None)):
            try:
                extra = self.layer_fields_provider() or {}
                for k, v in extra.items():
                    if k and k not in fields_map:
                        fields_map[k] = list(v or [])
                    elif k and v:
                        for fn in v:
                            if fn not in fields_map[k]:
                                fields_map[k].append(fn)
            except Exception:
                pass
        dlg = MapLegendDialog(
            self.config,
            layer_fields_map=fields_map,
            lang=self.lang,
            parent=self,
            dashboard=dcfg,
        )
        if exec_dialog(dlg):
            self.apply_configured_layer_styles()
            if self._canvas is not None:
                try:
                    self._canvas.refresh()
                except Exception:
                    pass
            if self.on_edit_saved:
                self.on_edit_saved()

    def set_current_view_as_home(self) -> None:
        """Store current QGIS map canvas bounds, center & EPSG:3301 zoom as dashboard/map Home View (#1)."""
        saved_ok = False
        if self._canvas is not None:
            try:
                from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject

                ext = self._canvas.extent()
                if not ext.isEmpty():
                    center = ext.center()
                    src_crs = self._canvas.mapSettings().destinationCrs()
                    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
                    ext_wgs = ext
                    if src_crs.isValid() and src_crs != wgs84:
                        xf = QgsCoordinateTransform(src_crs, wgs84, QgsProject.instance())
                        center = xf.transform(center)
                        ext_wgs = xf.transformBoundingBox(ext)

                    self.config.map_home_bounds = [
                        round(float(ext_wgs.yMinimum()), 6),
                        round(float(ext_wgs.xMinimum()), 6),
                        round(float(ext_wgs.yMaximum()), 6),
                        round(float(ext_wgs.xMaximum()), 6),
                    ]
                    self.config.map_center_lat = round(float(center.y()), 6)
                    self.config.map_center_lon = round(float(center.x()), 6)

                    # Accurate EPSG:3301 Maa-amet tile zoom level (0..14)
                    est_res = float(self._canvas.mapUnitsPerPixel()) if hasattr(self._canvas, "mapUnitsPerPixel") else 250.0
                    ma_res = [4000, 2000, 1000, 500, 250, 125, 62.5, 31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625]
                    best_z = min(range(len(ma_res)), key=lambda zi: abs(ma_res[zi] - est_res))
                    self.config.map_zoom = int(best_z)
                    saved_ok = True
            except Exception:
                pass

        # Show unmistakable visual feedback even outside QGIS GUI or in headless click tests
        if hasattr(self, "btn_set_home") and self.btn_set_home is not None:
            self.btn_set_home.setText("✓")
            self.btn_set_home.setToolTip(tr("home_view_saved", self.lang))
            self.btn_set_home.setStyleSheet(
                "background: #10b981; color: #04131c; font-weight: 800; border-radius: 4px;"
            )
            qtimer_cls = getattr(QtCore, "QTimer", None)
            if qtimer_cls is not None and hasattr(qtimer_cls, "singleShot"):
                def _restore_btn() -> None:
                    try:
                        self.btn_set_home.setText("📍")
                        self.btn_set_home.setToolTip(tr("btn_set_home_view", self.lang))
                        self.btn_set_home.setStyleSheet("")
                    except RuntimeError:
                        pass
                qtimer_cls.singleShot(1800, _restore_btn)

        if saved_ok or self._canvas is None:
            if callable(getattr(self, "on_home_view_saved", None)):
                self.on_home_view_saved()
            if self.on_edit_saved:
                self.on_edit_saved()

    def reset_to_home_view(self) -> None:
        """Reset QGIS canvas back to configured home bounds / center / zoom (or Estonia full view) (#1)."""
        if self._canvas is None:
            return
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsPointXY,
                QgsProject,
                QgsRectangle,
            )

            src_wgs = QgsCoordinateReferenceSystem("EPSG:4326")
            dst_crs = self._canvas.mapSettings().destinationCrs()
            hb = list(getattr(self.config, "map_home_bounds", []) or [])
            if len(hb) == 4:
                south, west, north, east = [float(v) for v in hb]
                rect = QgsRectangle(west, south, east, north)
                if dst_crs.isValid() and dst_crs != src_wgs:
                    rect = QgsCoordinateTransform(src_wgs, dst_crs, QgsProject.instance()).transformBoundingBox(rect)
                self._canvas.setExtent(rect)
                self._canvas.refresh()
                return

            lat = float(self.config.map_center_lat or getattr(self, "_default_center_lat", 58.758) or 58.758)
            lon = float(self.config.map_center_lon or getattr(self, "_default_center_lon", 23.825) or 23.825)
            zoom_v = int(self.config.map_zoom if self.config.map_zoom is not None else 3)
            pt = QgsPointXY(lon, lat)
            if dst_crs.isValid() and dst_crs != src_wgs:
                pt = QgsCoordinateTransform(src_wgs, dst_crs, QgsProject.instance()).transform(pt)
            ma_res = [4000, 2000, 1000, 500, 250, 125, 62.5, 31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625]
            res_m = ma_res[max(0, min(len(ma_res) - 1, zoom_v))]
            cw = max(320, int(self._canvas.width() or 540))
            ch = max(240, int(self._canvas.height() or 380))
            if not dst_crs.isGeographic():
                half_w = (cw * res_m) * 0.5
                half_h = (ch * res_m) * 0.5
            else:
                half_w = max(0.004, (cw * res_m) / 222000.0)
                half_h = max(0.002, (ch * res_m) / 222000.0)
            rect = QgsRectangle(pt.x() - half_w, pt.y() - half_h, pt.x() + half_w, pt.y() + half_h)
            self._canvas.setExtent(rect)
            self._canvas.refresh()
        except Exception:
            self.sync_layers_and_zoom(force_layers=False)

    def _on_address_text_changed(self, text: str = "") -> None:
        if getattr(self, "_addr_suppress_change", False):
            return
        q = (text if isinstance(text, str) else self.ed_addr_search.text()).strip()
        timer = getattr(self, "_addr_timer", None)
        if len(q) < 2:
            self._addr_seq = int(getattr(self, "_addr_seq", 0)) + 1
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass
            self.list_addr_results.clear()
            self.list_addr_results.hide()
            return
        if timer is not None:
            try:
                timer.start()
                return
            except Exception:
                pass
        self._search_address()

    def clear_address_search(self) -> None:
        self._addr_seq = int(getattr(self, "_addr_seq", 0)) + 1
        timer = getattr(self, "_addr_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
        self._addr_suppress_change = True
        try:
            self.ed_addr_search.clear()
        finally:
            self._addr_suppress_change = False
        self.list_addr_results.clear()
        self.list_addr_results.hide()
        if self._addr_rubber_band is not None and self._canvas is not None:
            try:
                self._canvas.scene().removeItem(self._addr_rubber_band)
            except Exception:
                pass
            self._addr_rubber_band = None
        if self.filter_bus is not None:
            self.filter_bus.clear_filter(f"{self.config.id}__addr")

    def _search_address(self) -> None:
        timer = getattr(self, "_addr_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
        query = self.ed_addr_search.text().strip()
        self._addr_seq = int(getattr(self, "_addr_seq", 0)) + 1
        req_seq = self._addr_seq
        if len(query) < 2:
            self.list_addr_results.clear()
            self.list_addr_results.hide()
            return
        self.list_addr_results.clear()
        self.list_addr_results.addItem(tr("addr_searching", self.lang))
        self.list_addr_results.show()

        def _worker() -> None:
            try:
                results = search_estonian_address(query, limit=8)
            except Exception:
                results = []

            relay = getattr(self, "_addr_relay", None)
            if relay is not None and hasattr(relay, "results_ready"):
                try:
                    relay.results_ready.emit((id(relay), req_seq, results))
                    return
                except RuntimeError:
                    return

            def _deliver() -> None:
                self._populate_address_results(results, req_seq=req_seq)

            qtimer_cls = getattr(QtCore, "QTimer", None)
            if qtimer_cls is not None and hasattr(qtimer_cls, "singleShot"):
                try:
                    # Three-arg form targets the receiver QObject's GUI thread instead of the worker thread
                    qtimer_cls.singleShot(0, self, _deliver)
                    return
                except TypeError:
                    pass
            _deliver()

        threading.Thread(target=_worker, daemon=True).start()

    def _populate_address_results(
        self,
        results: List[Dict[str, Any]],
        req_seq: Optional[int] = None,
    ) -> None:
        if req_seq is not None and req_seq != getattr(self, "_addr_seq", req_seq):
            return
        if len(self.ed_addr_search.text().strip()) < 2:
            self.list_addr_results.clear()
            self.list_addr_results.hide()
            return
        self.list_addr_results.clear()
        if not results:
            self.list_addr_results.addItem(tr("addr_no_results", self.lang))
            self.list_addr_results.show()
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for cand in results:
            tag = f"[{cand['type']}] " if cand.get("type") else ""
            it = QListWidgetItem(f"{tag}{cand.get('label', '')}")
            it.setData(role, cand)
            self.list_addr_results.addItem(it)
        self.list_addr_results.show()

    def _on_address_item_clicked(self, item: Any) -> None:
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        cand = item.data(role) if item is not None else None
        if not isinstance(cand, dict):
            return
        self._addr_seq = int(getattr(self, "_addr_seq", 0)) + 1
        timer = getattr(self, "_addr_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
        self._addr_suppress_change = True
        try:
            self.ed_addr_search.setText(str(cand.get("label") or ""))
        finally:
            self._addr_suppress_change = False
        self.list_addr_results.hide()

        # Emit full spatial filter onto FilterBus so In-Aadress/Kataster selection filters connected widgets (#15)
        if self.filter_bus is not None:
            geom_wgs, bbox_wgs = _cand_to_wgs84_geom_and_bbox(cand)
            if geom_wgs or bbox_wgs:
                lbl_short = str(cand.get("katastritunnus") or cand.get("label") or "Aadress")[:32]
                self.filter_bus.set_filter(
                    ActiveFilter(
                        source_id=f"{self.config.id}__addr",
                        layer_name="__spatial__",
                        field_name="kataster" if cand.get("katastritunnus") else "aadress",
                        filter_type="spatial_geom",
                        bbox=bbox_wgs,
                        geometry=geom_wgs,
                        display_label=f"📍 {lbl_short}",
                        page_id=str(getattr(self.config, "page_id", "page_1") or "page_1"),
                        is_global=True,
                    )
                )

        if self._canvas is None:
            return
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem,
                QgsCoordinateTransform,
                QgsGeometry,
                QgsPointXY,
                QgsProject,
                QgsRectangle,
                QgsWkbTypes,
            )

            proj = QgsProject.instance()
            dst_crs = self._canvas.mapSettings().destinationCrs()
            lest = QgsCoordinateReferenceSystem("EPSG:3301")
            wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
            rect = None
            bbox = cand.get("bbox_3301")
            if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
                r = QgsRectangle(float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]))
                rect = QgsCoordinateTransform(lest, dst_crs, proj).transformBoundingBox(r) if dst_crs != lest else r
            elif cand.get("lon") is not None and cand.get("lat") is not None:
                pt = QgsPointXY(float(cand["lon"]), float(cand["lat"]))
                if dst_crs != wgs84:
                    pt = QgsCoordinateTransform(wgs84, dst_crs, proj).transform(pt)
                d = 120.0 if not dst_crs.isGeographic() else 0.002
                rect = QgsRectangle(pt.x() - d, pt.y() - d, pt.x() + d, pt.y() + d)

            if rect is not None and not rect.isEmpty():
                rect.scale(1.25)
                self._canvas.setExtent(rect)

            if self._addr_rubber_band is not None:
                try:
                    self._canvas.scene().removeItem(self._addr_rubber_band)
                except Exception:
                    pass
                self._addr_rubber_band = None

            try:
                from qgis.gui import QgsRubberBand

                if cand.get("x_3301") is not None and cand.get("y_3301") is not None:
                    rb = QgsRubberBand(self._canvas, QgsWkbTypes.PointGeometry)
                    rb.setColor(QColor("#f97316"))
                    rb.setWidth(5)
                    pt_hl = QgsPointXY(float(cand["x_3301"]), float(cand["y_3301"]))
                    if dst_crs != lest:
                        pt_hl = QgsCoordinateTransform(lest, dst_crs, proj).transform(pt_hl)
                    rb.addPoint(pt_hl, True)
                    self._addr_rubber_band = rb
            except Exception:
                pass
            self._canvas.refresh()
        except Exception:
            pass

    def refresh_data(self, records: Any, _filter_bus: FilterBus) -> None:
        if isinstance(records, dict):
            self._records_cache = dict(records)
        self.sync_layers_and_zoom(force_layers=False)


class ImageLogoWidget(QFrame):
    """Resizable widget rendering an organization logo, emblem, or reference picture."""

    def __init__(
        self,
        config: WidgetConfig,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.lang = lang
        self._raw_pixmap: Optional[Any] = None

        self.setSizePolicy(
            qt_enum(QSizePolicy, "Policy", "Expanding"),
            qt_enum(QSizePolicy, "Policy", "Expanding"),
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)

        self.lbl_img = QLabel("")
        self.lbl_img.setAlignment(qt_enum(Qt, "AlignmentFlag", "AlignCenter"))
        self.lbl_img.setMinimumHeight(40)
        lay.addWidget(self.lbl_img, 1)

        self.lbl_caption = QLabel("")
        self.lbl_caption.setAlignment(qt_enum(Qt, "AlignmentFlag", "AlignCenter"))
        self.lbl_caption.setWordWrap(True)
        self.lbl_caption.setProperty("role", "muted")
        lay.addWidget(self.lbl_caption)

        self.reload_image()

    def reload_image(self) -> None:
        if getattr(self.config, "image_transparent_bg", False):
            self.setStyleSheet("ImageLogoWidget { background: transparent; border: none; }")
        else:
            self.setStyleSheet("")

        cap = str(getattr(self.config, "image_caption", "") or "").strip()
        self.lbl_caption.setText(cap)
        self.lbl_caption.setVisible(bool(cap))

        self._raw_pixmap = None
        data_uri = str(getattr(self.config, "image_data_uri", "") or "").strip()
        src = str(getattr(self.config, "image_source", "") or "").strip()
        if QPixmap is not None:
            if data_uri.startswith("data:") and "," in data_uri:
                try:
                    raw = base64.b64decode(data_uri.split(",", 1)[1])
                    pm = QPixmap()
                    if pm.loadFromData(raw) and not pm.isNull():
                        self._raw_pixmap = pm
                except Exception:
                    self._raw_pixmap = None
            elif src and os.path.isfile(src):
                try:
                    pm = QPixmap(src)
                    if not pm.isNull():
                        self._raw_pixmap = pm
                except Exception:
                    self._raw_pixmap = None
        self._apply_scaled_pixmap()

    def _apply_scaled_pixmap(self) -> None:
        if self._raw_pixmap is not None:
            mode_name = "KeepAspectRatioByExpanding" if getattr(self.config, "image_fit", "contain") == "cover" else "KeepAspectRatio"
            aspect = qt_enum(Qt, "AspectRatioMode", mode_name)
            smooth = qt_enum(Qt, "TransformationMode", "SmoothTransformation")
            w = max(48, self.lbl_img.width() or (self.width() - 12) or 220)
            h = max(36, self.lbl_img.height() or (self.height() - 28) or 120)
            self.lbl_img.setPixmap(self._raw_pixmap.scaled(w, h, aspect, smooth))
        else:
            src = str(getattr(self.config, "image_source", "") or "").strip()
            self.lbl_img.setText(src if src.startswith(("http://", "https://")) else tr("img_placeholder", self.lang))

    def resizeEvent(self, event: Any) -> None:
        super().resizeEvent(event)
        self._apply_scaled_pixmap()

    def mousePressEvent(self, event: Any) -> None:
        link = str(getattr(self.config, "image_link_url", "") or "").strip()
        if link and QDesktopServices is not None and event.button() == qt_enum(Qt, "MouseButton", "LeftButton"):
            try:
                QUrl = getattr(QtCore, "QUrl", None)
                if QUrl is not None:
                    QDesktopServices.openUrl(QUrl(link))
            except Exception:
                pass
        super().mousePressEvent(event)


class KpiCardWidget(QFrame):
    """Conservation Summary Metric Card displaying area/budget/count and goal progress."""

    def __init__(
        self,
        config: WidgetConfig,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.lang = lang

        self.setSizePolicy(
            qt_enum(QSizePolicy, "Policy", "Expanding"),
            qt_enum(QSizePolicy, "Policy", "Expanding"),
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(4)

        self.lbl_value = QLabel("0")
        self.lbl_value.setProperty("role", "kpiValue")
        layout.addWidget(self.lbl_value)

        self.lbl_meta = QLabel(f"0 {tr('records', lang)}")
        self.lbl_meta.setProperty("role", "muted")
        layout.addWidget(self.lbl_meta)
        layout.addStretch()

    def refresh_data(
        self, records: List[Dict[str, Any]], filter_bus: FilterBus, lang: str = "et"
    ) -> None:
        self.lang = lang
        res = Aggregator.compute_kpi(records, self.config, filter_bus)
        self.lbl_value.setText(res["formatted"])
        meta = f"{res['row_count']:,} / {res['total_count']:,} {tr('records', lang)}"
        if res["delta_pct"] is not None:
            pct = res["delta_pct"]
            sign = "+" if pct >= 0 else ""
            meta += f"  |  {sign}{pct:.1f}% {tr('vs_target', lang)}"
        self.lbl_meta.setText(meta)


class ExpressionCardWidget(QFrame):
    """QGIS-style UI Expression Card evaluating formulas dynamically on filter/data updates."""

    def __init__(
        self,
        config: WidgetConfig,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.lang = lang

        self.setSizePolicy(
            qt_enum(QSizePolicy, "Policy", "Expanding"),
            qt_enum(QSizePolicy, "Policy", "Expanding"),
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)

        self.lbl_value = QLabel("—")
        self.lbl_value.setProperty("role", "kpiValue")
        self.lbl_value.setWordWrap(True)
        layout.addWidget(self.lbl_value)

        self.prog_bar = QProgressBar() if QProgressBar is not None else None
        if self.prog_bar is not None:
            self.prog_bar.setRange(0, 100)
            if hasattr(self.prog_bar, "setFixedHeight"):
                self.prog_bar.setFixedHeight(14)
            if hasattr(self.prog_bar, "setFormat"):
                self.prog_bar.setFormat("%p%")
            self.prog_bar.hide()
            layout.addWidget(self.prog_bar)

        self.lbl_subtext = QLabel("")
        self.lbl_subtext.setProperty("role", "muted")
        self.lbl_subtext.setWordWrap(True)
        layout.addWidget(self.lbl_subtext)
        layout.addStretch()

    def refresh_data(
        self,
        records: List[Dict[str, Any]],
        filter_bus: FilterBus,
        lang: str = "et",
        all_records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        widget_resolver: Optional[Any] = None,
    ) -> None:
        from ..core.expression_engine import (
            evaluate_dashboard_expression,
            resolve_expression_accent_color,
        )

        self.lang = lang
        layer_name = str(getattr(self.config, "layer_name", "") or "")
        all_by_layer = all_records_by_layer or {}
        if not records and layer_name and layer_name in all_by_layer:
            records = all_by_layer.get(layer_name, [])

        exclude_id = self.config.id if getattr(self.config, "ignore_self_filter", True) else None
        filtered_rows = (
            filter_bus.filter_records(
                records,
                layer_name=layer_name,
                exclude_source_id=exclude_id,
                target_widget_id=self.config.id,
            )
            if filter_bus
            else list(records or [])
        )

        def _cross_filter_fn(lname: str, raw_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            if not filter_bus:
                return list(raw_rows or [])
            return filter_bus.filter_records(
                raw_rows,
                layer_name=lname,
                exclude_source_id=exclude_id,
                target_widget_id=self.config.id,
            )

        dec = max(0, int(getattr(self.config, "decimals", 1) if getattr(self.config, "decimals", None) is not None else 1))
        expr = str(getattr(self.config, "expression", "") or "").strip() or "count()"
        res = evaluate_dashboard_expression(
            expr,
            filtered_rows,
            all_records_by_layer=all_by_layer,
            layer_name=layer_name,
            total_count=len(records or []),
            filter_count=len(filter_bus.active_filters()) if filter_bus else 0,
            filter_fn=_cross_filter_fn,
            widget_resolver=widget_resolver,
            fallback_agg=str(getattr(self.config, "aggregation", "sum") or "sum"),
            decimals=dec,
            prefix=str(getattr(self.config, "prefix", "") or ""),
            suffix=str(getattr(self.config, "suffix", "") or ""),
        )
        disp_mode = str(getattr(self.config, "expression_display", "auto") or "auto").lower()
        accent = resolve_expression_accent_color(self.config, res)
        self._resolved_accent_color = accent

        parent_w = self.parent() if hasattr(self, "parent") else None
        for _ in range(4):
            if parent_w is None:
                break
            if hasattr(parent_w, "set_accent_color"):
                try:
                    parent_w.set_accent_color(accent)
                except Exception:
                    pass
                break
            parent_w = parent_w.parent() if hasattr(parent_w, "parent") else None

        if not res["ok"]:
            self.lbl_value.setText("⚠ " + (res["error"][:72] or "Syntax error"))
            self.lbl_value.setStyleSheet("font-size: 13px; color: #f87171;")
        else:
            val_txt = str(res["formatted"] or "—")
            if disp_mode == "text" or (not res["is_numeric"] and len(val_txt) > 14):
                self.lbl_value.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {accent};" if getattr(self.config, "expression_color_mode", "fixed") != "fixed" else "font-size: 16px; font-weight: 700;")
            else:
                self.lbl_value.setStyleSheet(f"color: {accent};" if getattr(self.config, "expression_color_mode", "fixed") != "fixed" else "")
            self.lbl_value.setText(val_txt)

        if self.prog_bar is not None:
            tgt = getattr(self.config, "target_value", None)
            num_val = float(res["value"]) if (res["ok"] and res["is_numeric"] and res["value"] is not None) else None
            show_prog = False
            pct_val = 0
            if num_val is not None:
                if tgt is not None and float(tgt) > 0:
                    pct_val = max(0, min(100, int(round((num_val / float(tgt)) * 100.0))))
                    show_prog = (disp_mode == "progress") or (disp_mode != "text")
                elif disp_mode == "progress":
                    pct_val = max(0, min(100, int(round(num_val))))
                    show_prog = True
            self.prog_bar.setVisible(show_prog)
            if show_prog:
                self.prog_bar.setValue(pct_val)
                self.prog_bar.setStyleSheet(
                    "QProgressBar { background: rgba(148,163,184,0.22); border: none; border-radius: 7px; text-align: center; font-size: 10px; font-weight: 700; }"
                    f"QProgressBar::chunk {{ background: {accent}; border-radius: 7px; }}"
                )

        sub_expr = str(getattr(self.config, "expression_subtext", "") or "").strip()
        if sub_expr:
            sub_res = evaluate_dashboard_expression(
                sub_expr,
                filtered_rows,
                all_records_by_layer=all_by_layer,
                layer_name=layer_name,
                total_count=len(records or []),
                filter_count=len(filter_bus.active_filters()) if filter_bus else 0,
                filter_fn=_cross_filter_fn,
                widget_resolver=widget_resolver,
                fallback_agg=str(getattr(self.config, "aggregation", "sum") or "sum"),
                decimals=dec,
            )
            self.lbl_subtext.setText(str(sub_res["formatted"]) if sub_res["ok"] else str(sub_res["error"]))
        else:
            self.lbl_subtext.setText(f"{len(filtered_rows):,} / {len(records or []):,} {tr('records', lang)}")


class _PieWedgeRegion:
    """Polar hit-test region for an interactive pie or donut wedge."""

    def __init__(
        self,
        cx: float,
        cy: float,
        r_inner: float,
        r_outer: float,
        start_deg: float,
        span_deg: float,
    ) -> None:
        self.cx = float(cx)
        self.cy = float(cy)
        self.r_inner = max(0.0, float(r_inner))
        self.r_outer = max(0.0, float(r_outer))
        self.start_deg = float(start_deg)
        self.span_deg = float(span_deg)

    def contains(self, pos: Any) -> bool:
        if pos is None:
            return False
        px = float(pos.x()) if hasattr(pos, "x") else float(pos[0])
        py = float(pos.y()) if hasattr(pos, "y") else float(pos[1])
        dx = px - self.cx
        dy = -(py - self.cy)  # Qt screen Y points downward; Qt pie angles sweep CCW from 3 o'clock
        dist = math.hypot(dx, dy)
        if dist < self.r_inner or dist > self.r_outer:
            return False
        if abs(self.span_deg) >= 359.99:
            return True
        if abs(self.span_deg) < 1e-4:
            return False
        ang = math.degrees(math.atan2(dy, dx)) % 360.0
        if self.span_deg < 0.0:
            diff = (self.start_deg - ang) % 360.0
            return 0.0 <= diff <= abs(self.span_deg)
        diff = (ang - self.start_deg) % 360.0
        return 0.0 <= diff <= self.span_deg


class InteractiveChartCanvas(QWidget):
    """Custom QPainter canvas for interactive Bar, Horizontal Bar, Line, Pie/Donut, and Scatter plots."""

    def __init__(
        self,
        config: WidgetConfig,
        filter_bus: FilterBus,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.filter_bus = filter_bus
        self.lang = lang
        self.series: List[Tuple[str, float]] = []
        self.multi_series: Optional[Dict[str, Any]] = None
        self.scatter_points: List[Dict[str, Any]] = []
        self._hit_regions: List[Tuple[Any, str, str]] = []
        self.setMouseTracking(True)
        self.setMinimumHeight(140)
        self.setSizePolicy(
            qt_enum(QSizePolicy, "Policy", "Expanding"),
            qt_enum(QSizePolicy, "Policy", "Expanding"),
        )

    def set_data(
        self,
        series: List[Tuple[str, float]],
        scatter_points: Optional[List[Dict[str, Any]]] = None,
        lang: str = "et",
        multi_series: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.series = series
        self.multi_series = multi_series
        self.scatter_points = scatter_points or []
        self.lang = lang
        self.update()

    def paintEvent(self, _event: Any) -> None:
        painter = QPainter(self)
        painter.setRenderHint(qt_enum(QPainter, "RenderHint", "Antialiasing"))
        rect = self.rect()
        tc = ThemeManager.colors_for_widget(self)
        self._tc = tc
        painter.fillRect(rect, QColor(tc["bg_panel"]))

        self._hit_regions.clear()
        wtype = self.config.widget_type
        has_multi = bool(self.multi_series and (self.multi_series.get("categories") or []))

        if wtype == "scatter":
            self._paint_scatter(painter, rect)
        elif not self.series and not has_multi:
            painter.setPen(QColor(tc["text_muted"]))
            painter.drawText(
                rect,
                qt_enum(Qt, "AlignmentFlag", "AlignCenter"),
                tr("no_matching", self.lang),
            )
        elif wtype == "pie":
            self._paint_pie(painter, rect)
        elif wtype == "line":
            if has_multi:
                self._paint_multi_lines(painter, rect)
            else:
                self._paint_line(painter, rect)
        else:
            if has_multi:
                self._paint_multi_bars(painter, rect)
            else:
                self._paint_bars(painter, rect)

    def _palette_colors(self) -> List[str]:
        pal_key = str(getattr(self.config, "color_palette", "") or "emerald").strip().lower()
        if pal_key == "single":
            base = QColor(self.config.primary_color or "#34d399")
            return [base.name(), base.darker(120).name(), base.lighter(120).name(), base.darker(145).name(), base.lighter(135).name()]
        return PALETTES.get(pal_key, PALETTES["emerald"])

    def _series_item_color(self, idx: int) -> QColor:
        pal_key = str(getattr(self.config, "color_palette", "") or "").strip().lower()
        if pal_key == "single":
            return QColor(self.config.primary_color or "#34d399")
        pal = self._palette_colors()
        return QColor(pal[idx % len(pal)])

    def _paint_bars(self, painter: QPainter, rect: Any) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        selected_vals = set(str(v) for v in self.filter_bus.get_selected_values(self.config.id))
        max_val = max((abs(v) for _, v in self.series), default=1.0) or 1.0
        muted = QColor(tc["chart_muted"])

        margin_left, margin_right, margin_top, margin_bottom = 56, 20, 12, 34
        plot_w = max(40, rect.width() - margin_left - margin_right)
        plot_h = max(40, rect.height() - margin_top - margin_bottom)
        n = len(self.series)

        painter.setFont(QFont("Segoe UI", 8))

        if self.config.horizontal:
            bar_h = max(10.0, min(28.0, (plot_h / max(1, n)) * 0.72))
            step_y = plot_h / max(1, n)
            for idx, (cat, val) in enumerate(self.series):
                y = margin_top + idx * step_y + (step_y - bar_h) / 2.0
                w = (abs(val) / max_val) * plot_w
                bar_rect = QRectF(margin_left + 30, y, max(3.0, w - 30), bar_h)
                is_sel = (not selected_vals) or (cat in selected_vals)
                painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
                painter.setBrush(QBrush(self._series_item_color(idx) if is_sel else muted))
                painter.drawRoundedRect(bar_rect, 3, 3)

                painter.setPen(QColor(tc["text_secondary"]))
                lbl = cat[:12] + "…" if len(cat) > 13 else cat
                painter.drawText(
                    QRectF(4, y, margin_left + 22, bar_h),
                    qt_enum(Qt, "AlignmentFlag", "AlignVCenter") | qt_enum(Qt, "AlignmentFlag", "AlignRight"),
                    lbl,
                )
                self._hit_regions.append((bar_rect, cat, f"{cat}: {val:,.2f}"))
        else:
            bar_w = max(12.0, min(46.0, (plot_w / max(1, n)) * 0.68))
            step_x = plot_w / max(1, n)
            for idx, (cat, val) in enumerate(self.series):
                x = margin_left + idx * step_x + (step_x - bar_w) / 2.0
                h = (abs(val) / max_val) * plot_h
                y = margin_top + plot_h - h
                bar_rect = QRectF(x, y, bar_w, max(3.0, h))
                is_sel = (not selected_vals) or (cat in selected_vals)
                painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
                painter.setBrush(QBrush(self._series_item_color(idx) if is_sel else muted))
                painter.drawRoundedRect(bar_rect, 3, 3)

                painter.setPen(QColor(tc["text_secondary"]))
                lbl = cat[:9] + "…" if len(cat) > 10 else cat
                painter.drawText(
                    QRectF(margin_left + idx * step_x, margin_top + plot_h + 4, step_x, 26),
                    qt_enum(Qt, "AlignmentFlag", "AlignTop") | qt_enum(Qt, "AlignmentFlag", "AlignHCenter"),
                    lbl,
                )
                self._hit_regions.append((bar_rect, cat, f"{cat}: {val:,.2f}"))

    def _paint_line(self, painter: QPainter, rect: Any) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        max_val = max((v for _, v in self.series), default=1.0) or 1.0
        min_val = min((v for _, v in self.series), default=0.0)
        if max_val == min_val:
            max_val += 1.0

        margin_left, margin_right, margin_top, margin_bottom = 48, 20, 14, 34
        plot_w = max(40, rect.width() - margin_left - margin_right)
        plot_h = max(40, rect.height() - margin_top - margin_bottom)
        n = len(self.series)

        primary = self._series_item_color(0)
        painter.setPen(QPen(primary, 2.4))

        pts: List[QPointF] = []
        for idx, (_cat, val) in enumerate(self.series):
            px = margin_left + (idx / max(1, n - 1)) * plot_w if n > 1 else margin_left + plot_w / 2
            py = margin_top + plot_h - ((val - min_val) / (max_val - min_val)) * plot_h
            pts.append(QPointF(px, py))

        if len(pts) >= 2:
            path = QPainterPath(pts[0])
            for p in pts[1:]:
                path.lineTo(p)
            painter.drawPath(path)

        painter.setFont(QFont("Segoe UI", 8))
        for idx, (pt, (cat, val)) in enumerate(zip(pts, self.series)):
            painter.setBrush(QBrush(primary))
            painter.setPen(QPen(QColor(tc["card_surface"]), 1.5))
            hit_rect = QRectF(pt.x() - 6, pt.y() - 6, 12, 12)
            painter.drawEllipse(QRectF(pt.x() - 4, pt.y() - 4, 8, 8))
            self._hit_regions.append((hit_rect, cat, f"{cat}: {val:,.2f}"))

            if n <= 8 or idx % max(1, n // 6) == 0:
                painter.setPen(QColor(tc["text_secondary"]))
                lbl = cat[:8] + "…" if len(cat) > 9 else cat
                painter.drawText(
                    QRectF(pt.x() - 28, margin_top + plot_h + 4, 56, 24),
                    qt_enum(Qt, "AlignmentFlag", "AlignTop") | qt_enum(Qt, "AlignmentFlag", "AlignHCenter"),
                    lbl,
                )

    def _paint_series_legend(self, painter: QPainter, rect: Any, series_names: List[str], colors: List[str]) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        painter.setFont(QFont("Segoe UI", 8))
        x_cur = 12.0
        for s_idx, sname in enumerate(series_names[:6]):
            lbl = sname[:14] + "…" if len(sname) > 15 else sname
            need_w = 16.0 + max(24.0, len(lbl) * 6.0 + 10.0)
            if x_cur + need_w > rect.width() - 8:
                break
            col = QColor(colors[s_idx % len(colors)])
            painter.setBrush(QBrush(col))
            painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
            painter.drawRoundedRect(QRectF(x_cur, 6.0, 9.0, 9.0), 2, 2)
            painter.setPen(QColor(tc["text_secondary"]))
            painter.drawText(
                QRectF(x_cur + 12.0, 3.0, need_w - 12.0, 15.0),
                qt_enum(Qt, "AlignmentFlag", "AlignVCenter") | qt_enum(Qt, "AlignmentFlag", "AlignLeft"),
                lbl,
            )
            x_cur += need_w + 6.0

    def _paint_multi_bars(self, painter: QPainter, rect: Any) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        ms = self.multi_series or {}
        cats = list(ms.get("categories") or [])
        series_names = list(ms.get("series_names") or [])
        matrix = ms.get("matrix") or {}
        raw_matrix = ms.get("raw_matrix") or matrix
        stack_mode = str(ms.get("stack_mode") or "group")
        if not cats or not series_names:
            return
        colors = self._palette_colors()
        self._paint_series_legend(painter, rect, series_names, colors)
        selected_vals = set(str(v) for v in self.filter_bus.get_selected_values(self.config.id))

        if stack_mode in ("stack", "percent"):
            max_val = 100.0 if stack_mode == "percent" else max(
                (sum(max(0.0, float(matrix.get(c, {}).get(s, 0.0))) for s in series_names) for c in cats),
                default=1.0,
            ) or 1.0
        else:
            max_val = max(
                (abs(float(matrix.get(c, {}).get(s, 0.0))) for c in cats for s in series_names),
                default=1.0,
            ) or 1.0

        margin_left, margin_right, margin_top, margin_bottom = 56, 20, 24, 34
        plot_w = max(40, rect.width() - margin_left - margin_right)
        plot_h = max(40, rect.height() - margin_top - margin_bottom)
        n = len(cats)
        m = max(1, len(series_names))
        painter.setFont(QFont("Segoe UI", 8))

        if self.config.horizontal:
            step_y = plot_h / max(1, n)
            is_stacked = stack_mode in ("stack", "percent")
            bar_h = max(8.0, min(26.0, step_y * (0.72 if is_stacked else 0.78 / m)))
            for idx, cat in enumerate(cats):
                is_sel = (not selected_vals) or (cat in selected_vals)
                cat_map = matrix.get(cat, {})
                raw_map = raw_matrix.get(cat, {})
                painter.setPen(QColor(tc["text_secondary"]))
                lbl = cat[:12] + "…" if len(cat) > 13 else cat
                painter.drawText(
                    QRectF(4, margin_top + idx * step_y, margin_left + 22, step_y),
                    qt_enum(Qt, "AlignmentFlag", "AlignVCenter") | qt_enum(Qt, "AlignmentFlag", "AlignRight"),
                    lbl,
                )
                x_cursor = float(margin_left + 30)
                usable_w = max(20.0, plot_w - 30.0)
                for s_idx, sname in enumerate(series_names):
                    val = float(cat_map.get(sname, 0.0))
                    raw_val = float(raw_map.get(sname, val))
                    w = (max(0.0, val) / max_val) * usable_w
                    if w <= 0.0 and raw_val == 0.0:
                        continue
                    col = QColor(colors[s_idx % len(colors)])
                    if not is_sel:
                        col.setAlpha(90)
                    if is_stacked:
                        y = margin_top + idx * step_y + (step_y - bar_h) / 2.0
                        bar_rect = QRectF(x_cursor, y, max(2.0, w), bar_h)
                        x_cursor += w
                    else:
                        total_grp_h = bar_h * m
                        y = margin_top + idx * step_y + (step_y - total_grp_h) / 2.0 + s_idx * bar_h
                        bar_rect = QRectF(margin_left + 30.0, y, max(2.0, w), max(4.0, bar_h - 1.0))
                    painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
                    painter.setBrush(QBrush(col))
                    painter.drawRoundedRect(bar_rect, 2, 2)
                    unit = "%" if stack_mode == "percent" else ""
                    tip = f"{cat} · {sname}: {val:,.1f}{unit}" if stack_mode == "percent" else f"{cat} · {sname}: {raw_val:,.2f}"
                    self._hit_regions.append((bar_rect, cat, tip))
        else:
            step_x = plot_w / max(1, n)
            is_stacked = stack_mode in ("stack", "percent")
            bar_w = max(8.0, min(42.0, (step_x * 0.72) if is_stacked else (step_x * 0.76) / m))
            for idx, cat in enumerate(cats):
                is_sel = (not selected_vals) or (cat in selected_vals)
                cat_map = matrix.get(cat, {})
                raw_map = raw_matrix.get(cat, {})
                y_cursor = float(margin_top + plot_h)
                for s_idx, sname in enumerate(series_names):
                    val = float(cat_map.get(sname, 0.0))
                    raw_val = float(raw_map.get(sname, val))
                    h = (max(0.0, val) / max_val) * plot_h
                    if h <= 0.0 and raw_val == 0.0:
                        continue
                    col = QColor(colors[s_idx % len(colors)])
                    if not is_sel:
                        col.setAlpha(90)
                    if is_stacked:
                        x = margin_left + idx * step_x + (step_x - bar_w) / 2.0
                        y_cursor -= h
                        bar_rect = QRectF(x, y_cursor, bar_w, max(2.0, h))
                    else:
                        total_grp_w = bar_w * m
                        x = margin_left + idx * step_x + (step_x - total_grp_w) / 2.0 + s_idx * bar_w
                        bar_rect = QRectF(x, margin_top + plot_h - h, max(4.0, bar_w - 1.0), max(2.0, h))
                    painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
                    painter.setBrush(QBrush(col))
                    painter.drawRoundedRect(bar_rect, 2, 2)
                    tip = f"{cat} · {sname}: {val:,.1f}%" if stack_mode == "percent" else f"{cat} · {sname}: {raw_val:,.2f}"
                    self._hit_regions.append((bar_rect, cat, tip))

                painter.setPen(QColor(tc["text_secondary"]))
                lbl = cat[:9] + "…" if len(cat) > 10 else cat
                painter.drawText(
                    QRectF(margin_left + idx * step_x, margin_top + plot_h + 4, step_x, 26),
                    qt_enum(Qt, "AlignmentFlag", "AlignTop") | qt_enum(Qt, "AlignmentFlag", "AlignHCenter"),
                    lbl,
                )

    def _paint_multi_lines(self, painter: QPainter, rect: Any) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        ms = self.multi_series or {}
        cats = list(ms.get("categories") or [])
        series_names = list(ms.get("series_names") or [])
        matrix = ms.get("matrix") or {}
        if not cats or not series_names:
            return
        colors = self._palette_colors()
        self._paint_series_legend(painter, rect, series_names, colors)

        all_vals = [float(matrix.get(c, {}).get(s, 0.0)) for c in cats for s in series_names]
        max_val = max(all_vals, default=1.0) or 1.0
        min_val = min(all_vals, default=0.0)
        if max_val == min_val:
            max_val += 1.0

        margin_left, margin_right, margin_top, margin_bottom = 48, 20, 24, 34
        plot_w = max(40, rect.width() - margin_left - margin_right)
        plot_h = max(40, rect.height() - margin_top - margin_bottom)
        n = len(cats)

        for s_idx, sname in enumerate(series_names):
            col = QColor(colors[s_idx % len(colors)])
            painter.setPen(QPen(col, 2.2))
            pts: List[QPointF] = []
            for idx, cat in enumerate(cats):
                val = float(matrix.get(cat, {}).get(sname, 0.0))
                px = margin_left + (idx / max(1, n - 1)) * plot_w if n > 1 else margin_left + plot_w / 2.0
                py = margin_top + plot_h - ((val - min_val) / (max_val - min_val)) * plot_h
                pts.append(QPointF(px, py))
            if len(pts) >= 2:
                path = QPainterPath(pts[0])
                for p in pts[1:]:
                    path.lineTo(p)
                painter.drawPath(path)
            for idx, (pt, cat) in enumerate(zip(pts, cats)):
                val = float(matrix.get(cat, {}).get(sname, 0.0))
                painter.setBrush(QBrush(col))
                painter.setPen(QPen(QColor(tc["card_surface"]), 1.2))
                hit_rect = QRectF(pt.x() - 6, pt.y() - 6, 12, 12)
                painter.drawEllipse(QRectF(pt.x() - 4, pt.y() - 4, 8, 8))
                self._hit_regions.append((hit_rect, cat, f"{cat} · {sname}: {val:,.2f}"))

        painter.setFont(QFont("Segoe UI", 8))
        for idx, cat in enumerate(cats):
            if n <= 8 or idx % max(1, n // 6) == 0:
                px = margin_left + (idx / max(1, n - 1)) * plot_w if n > 1 else margin_left + plot_w / 2.0
                painter.setPen(QColor(tc["text_secondary"]))
                lbl = cat[:8] + "…" if len(cat) > 9 else cat
                painter.drawText(
                    QRectF(px - 28, margin_top + plot_h + 4, 56, 24),
                    qt_enum(Qt, "AlignmentFlag", "AlignTop") | qt_enum(Qt, "AlignmentFlag", "AlignHCenter"),
                    lbl,
                )

    def _paint_pie(self, painter: QPainter, rect: Any) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        weights = [max(0.0, float(v or 0.0)) for _, v in self.series]
        raw_total = sum(weights)
        if raw_total > 0.0:
            draw_weights = weights
            draw_total = raw_total
        else:
            draw_weights = [1.0 for _ in self.series]
            draw_total = float(max(1, len(self.series)))
        colors = self._palette_colors()
        selected_vals = set(str(v) for v in self.filter_bus.get_selected_values(self.config.id))

        diameter = max(60.0, min(rect.width() * 0.50, rect.height() - 24))
        pie_left = 14.0
        pie_top = (rect.height() - diameter) / 2.0
        pie_cx = pie_left + diameter / 2.0
        pie_cy = pie_top + diameter / 2.0
        pie_rect = QRectF(pie_left, pie_top, diameter, diameter)
        r_outer = diameter / 2.0
        r_inner = (diameter * 0.48) / 2.0 if self.config.donut else 0.0

        start_deg = 90.0
        for idx, (cat, val) in enumerate(self.series):
            span_deg = -(draw_weights[idx] / draw_total) * 360.0
            pct = (weights[idx] / raw_total) * 100.0 if raw_total > 0.0 else 0.0
            color = QColor(colors[idx % len(colors)])
            if selected_vals and cat not in selected_vals:
                color.setAlpha(90)
            painter.setBrush(QBrush(color))
            painter.setPen(QPen(QColor(tc["bg_panel"]), 1.5))
            painter.drawPie(pie_rect, int(start_deg * 16), int(span_deg * 16))
            self._hit_regions.append(
                (
                    _PieWedgeRegion(pie_cx, pie_cy, r_inner, r_outer, start_deg, span_deg),
                    cat,
                    f"{cat}: {val:,.2f} ({pct:.1f}%)",
                )
            )
            start_deg += span_deg

        if self.config.donut:
            hole = diameter * 0.48
            hole_rect = QRectF(
                pie_rect.center().x() - hole / 2.0,
                pie_rect.center().y() - hole / 2.0,
                hole,
                hole,
            )
            painter.setBrush(QBrush(QColor(tc["bg_panel"])))
            painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
            painter.drawEllipse(hole_rect)

        leg_x = pie_rect.right() + 14
        leg_y = 14.0
        painter.setFont(QFont("Segoe UI", 8))
        for idx, (cat, val) in enumerate(self.series[:8]):
            pct = (weights[idx] / raw_total) * 100.0 if raw_total > 0.0 else 0.0
            swatch_rect = QRectF(leg_x, leg_y + idx * 21, 11, 11)
            row_rect = QRectF(leg_x, leg_y + idx * 21 - 2, max(60.0, rect.width() - leg_x - 8), 18)
            painter.setBrush(QBrush(QColor(colors[idx % len(colors)])))
            painter.setPen(qt_enum(Qt, "PenStyle", "NoPen"))
            painter.drawRoundedRect(swatch_rect, 2, 2)

            painter.setPen(QColor(tc["text_main"]))
            lbl = cat[:14] + "…" if len(cat) > 15 else cat
            painter.drawText(
                QRectF(leg_x + 16, leg_y + idx * 21 - 2, max(40.0, rect.width() - leg_x - 22), 16),
                qt_enum(Qt, "AlignmentFlag", "AlignVCenter") | qt_enum(Qt, "AlignmentFlag", "AlignLeft"),
                f"{lbl} ({pct:.0f}%)",
            )
            self._hit_regions.append((row_rect, cat, f"{cat}: {val:,.2f} ({pct:.1f}%)"))

    def _paint_scatter(self, painter: QPainter, rect: Any) -> None:
        tc = getattr(self, "_tc", None) or ThemeManager.colors_for_widget(self)
        if not self.scatter_points:
            painter.setPen(QColor(tc["text_muted"]))
            painter.drawText(rect, qt_enum(Qt, "AlignmentFlag", "AlignCenter"), tr("no_matching", self.lang))
            return

        xs = [p["x"] for p in self.scatter_points]
        ys = [p["y"] for p in self.scatter_points]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        if max_x == min_x:
            max_x += 1.0
        if max_y == min_y:
            max_y += 1.0

        margin_left, margin_right, margin_top, margin_bottom = 44, 18, 14, 28
        plot_w = max(40, rect.width() - margin_left - margin_right)
        plot_h = max(40, rect.height() - margin_top - margin_bottom)

        for idx_pt, pt in enumerate(self.scatter_points):
            px = margin_left + ((pt["x"] - min_x) / (max_x - min_x)) * plot_w
            py = margin_top + plot_h - ((pt["y"] - min_y) / (max_y - min_y)) * plot_h
            dot_rect = QRectF(px - 5, py - 5, 10, 10)
            painter.setBrush(QBrush(self._series_item_color(idx_pt)))
            painter.setPen(QPen(QColor(tc["card_surface"]), 1.2))
            painter.drawEllipse(dot_rect)
            self._hit_regions.append((dot_rect, pt["label"], f"{pt['label']}: ({pt['x']:,.2f}, {pt['y']:,.2f})"))

    def mouseMoveEvent(self, event: Any) -> None:
        pos = mouse_pos_f(event)
        for region, _, tip in self._hit_regions:
            if hasattr(region, "contains") and region.contains(pos):
                QToolTip.showText(mouse_global_pos(event), tip, self)
                self.setCursor(qt_enum(Qt, "CursorShape", "PointingHandCursor"))
                return
        self.setCursor(qt_enum(Qt, "CursorShape", "ArrowCursor"))

    def mousePressEvent(self, event: Any) -> None:
        left_btn = qt_enum(Qt, "MouseButton", "LeftButton")
        ctrl_mod = qt_enum(Qt, "KeyboardModifier", "ControlModifier")
        if not self.config.enable_cross_filter or event.button() != left_btn:
            return
        pos = mouse_pos_f(event)
        multi = bool(event.modifiers() & ctrl_mod)
        for region, cat_label, _ in self._hit_regions:
            if hasattr(region, "contains") and region.contains(pos):
                if cat_label != "Other":
                    self.filter_bus.toggle_category_value(
                        source_id=self.config.id,
                        layer_name=self.config.layer_name,
                        field_name=self.config.category_field,
                        value=cat_label,
                        multi=multi,
                        page_id=str(getattr(self.config, "page_id", "page_1") or "page_1"),
                    )
                return


class InteractiveChartWidget(QFrame):
    """Interactive QPainter Chart panel rendered inside a ResizableCardFrame."""

    def __init__(
        self,
        config: WidgetConfig,
        filter_bus: FilterBus,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.filter_bus = filter_bus
        self.lang = lang

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 6)
        layout.setSpacing(2)

        self.lbl_hint = QLabel(f"ⓘ {tr('click_to_filter', lang)}")
        self.lbl_hint.setProperty("role", "mutedTiny")
        self.lbl_hint.setStyleSheet(
            "background: transparent; border: none; color: #8A8886; "
            "font-style: italic; font-size: 10px; padding: 0px;"
        )
        self.lbl_hint.setContentsMargins(2, 0, 0, 0)
        layout.addWidget(self.lbl_hint)

        self.canvas = InteractiveChartCanvas(self.config, self.filter_bus, lang=lang, parent=self)
        layout.addWidget(self.canvas, 1)

    def refresh_data(
        self, records: List[Dict[str, Any]], filter_bus: FilterBus, lang: str = "et"
    ) -> None:
        self.lang = lang
        self.lbl_hint.setText(f"ⓘ {tr('click_to_filter', lang)}")
        if self.config.widget_type == "scatter":
            pts = Aggregator.compute_scatter(records, self.config, filter_bus)
            self.canvas.set_data([], pts, lang=lang, multi_series=None)
        elif (
            self.config.widget_type in ("bar", "line")
            and str(getattr(self.config, "secondary_field", "") or "").strip()
        ):
            ms = Aggregator.compute_multi_series(records, self.config, filter_bus)
            self.canvas.set_data([], [], lang=lang, multi_series=ms)
        else:
            series = Aggregator.compute_series(records, self.config, filter_bus)
            self.canvas.set_data(series, [], lang=lang, multi_series=None)


class DataTableWidget(QFrame):
    """Searchable detail & Excel-style Pivot table with computed Area/aggregates, Transpose & inline header rename."""

    def __init__(
        self,
        config: WidgetConfig,
        lang: str = "et",
        on_row_selected: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_config_changed: Optional[Callable[[], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.lang = lang
        self.on_row_selected = on_row_selected
        self.on_config_changed = on_config_changed
        self._raw_records: List[Dict[str, Any]] = []
        self._filter_bus: Optional[FilterBus] = None
        self._current_rows: List[Dict[str, Any]] = []
        self._col_alias_specs: List[Tuple[str, str, Optional[int]]] = []
        self._header_editor: Optional[Any] = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        bar = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(tr("search_table", lang))
        self.search_input.textChanged.connect(self._render_table)
        bar.addWidget(self.search_input, 1)

        self.btn_transpose = QPushButton("⇄")
        self.btn_transpose.setCheckable(True)
        self.btn_transpose.setProperty("btnRole", "miniStep")
        self.btn_transpose.setChecked(bool(getattr(config, "table_transpose", False)))
        self.btn_transpose.setToolTip(tr("tbl_transpose", lang))
        self.btn_transpose.setFixedSize(28, 24)
        self.btn_transpose.clicked.connect(self._toggle_transpose)
        bar.addWidget(self.btn_transpose)

        self.lbl_count = QLabel("")
        self.lbl_count.setProperty("role", "muted")
        bar.addWidget(self.lbl_count)
        layout.addLayout(bar)

        self.table = QTableWidget()
        self.table.setEditTriggers(qt_enum(QAbstractItemView, "EditTrigger", "NoEditTriggers"))
        self.table.setSelectionBehavior(qt_enum(Qt, "SelectionBehavior", "SelectRows") if hasattr(Qt, "SelectionBehavior") else qt_enum(QAbstractItemView, "SelectionBehavior", "SelectRows"))
        if hasattr(QAbstractItemView, "SelectionMode") or hasattr(QAbstractItemView, "ExtendedSelection"):
            try:
                self.table.setSelectionMode(qt_enum(QAbstractItemView, "SelectionMode", "ExtendedSelection"))
            except Exception:
                pass
        self.table.setStyleSheet(
            "QTableWidget::item:selected { background-color: rgba(56, 189, 248, 0.28); font-weight: 600; }"
        )
        self._selected_detail_fids: set = set()
        hdr = self.table.horizontalHeader()
        if hasattr(hdr, "setSectionResizeMode"):
            hdr.setSectionResizeMode(qt_enum(QHeaderView, "ResizeMode", "Interactive"))
        if hasattr(hdr, "setToolTip"):
            hdr.setToolTip(tr("tbl_header_edit_tip", lang))
        if hasattr(hdr, "sectionDoubleClicked") and hasattr(hdr.sectionDoubleClicked, "connect"):
            hdr.sectionDoubleClicked.connect(self._on_header_double_clicked)
        ctx_policy = qt_enum(Qt, "ContextMenuPolicy", "CustomContextMenu")
        if ctx_policy is not None and hasattr(hdr, "setContextMenuPolicy") and hasattr(hdr, "customContextMenuRequested"):
            try:
                hdr.setContextMenuPolicy(ctx_policy)
                hdr.customContextMenuRequested.connect(self._on_header_context_menu)
            except Exception:
                pass
        self.table.cellClicked.connect(self._handle_cell_click)
        layout.addWidget(self.table, 1)

    def _compute_col_alias_specs(self, headers: List[str], is_pivot: bool) -> List[Tuple[str, str, Optional[int]]]:
        """Map each visible column index to `(alias_key, default_label, pivot_val_index_or_None)`."""
        is_transposed = bool(getattr(self.config, "table_transpose", False))
        specs: List[Tuple[str, str, Optional[int]]] = []
        if is_transposed:
            return [(h, h, None) for h in headers]
        if is_pivot:
            p_rows = list(getattr(self.config, "pivot_rows", []) or [])
            p_cols = list(getattr(self.config, "pivot_cols", []) or [])
            p_vals = list(getattr(self.config, "pivot_values", []) or [])
            dim_count = len(p_rows) if p_rows else (1 if headers else 0)
            for idx, hdr in enumerate(headers):
                if idx < dim_count:
                    rf = p_rows[idx] if idx < len(p_rows) else hdr
                    specs.append((rf, friendly_field_label(rf, self.lang) if rf else hdr, None))
                elif not p_cols and (idx - dim_count) < len(p_vals):
                    pidx = idx - dim_count
                    sp = p_vals[pidx]
                    fld = str(sp.get("field") or "")
                    agg = str(sp.get("agg") or "sum")
                    specs.append((f"{agg}:{fld}", hdr, pidx))
                else:
                    specs.append((hdr, hdr, None))
            return specs

        cols = list(getattr(self.config, "table_columns", []) or [])
        if not cols and self._current_rows:
            cols = [k for k in self._current_rows[0].keys() if not str(k).startswith("_")][:8]
        for idx, hdr in enumerate(headers):
            raw_col = cols[idx] if idx < len(cols) else hdr
            specs.append((raw_col, friendly_field_label(raw_col, self.lang), None))
        return specs

    def rename_column(self, col_idx: int, new_label: str) -> bool:
        """Persist a custom display name (or clear to restore default) for table column `col_idx`."""
        if col_idx < 0 or col_idx >= len(self._col_alias_specs):
            return False
        alias_key, default_lbl, pivot_idx = self._col_alias_specs[col_idx]
        cleaned = str(new_label or "").strip()
        if not isinstance(getattr(self.config, "field_aliases", None), dict):
            self.config.field_aliases = {}

        if not cleaned or cleaned == default_lbl:
            self.config.field_aliases.pop(alias_key, None)
            if pivot_idx is not None and 0 <= pivot_idx < len(getattr(self.config, "pivot_values", []) or []):
                self.config.pivot_values[pivot_idx].pop("label", None)
        else:
            self.config.field_aliases[alias_key] = cleaned
            if pivot_idx is not None and 0 <= pivot_idx < len(getattr(self.config, "pivot_values", []) or []):
                self.config.pivot_values[pivot_idx]["label"] = cleaned

        self._render_table()
        if self.on_config_changed:
            try:
                self.on_config_changed()
            except Exception:
                pass
        return True

    def reset_column_name(self, col_idx: int) -> bool:
        return self.rename_column(col_idx, "")

    def _on_header_double_clicked(self, col_idx: int) -> None:
        self._start_inline_header_edit(col_idx)

    def _on_header_context_menu(self, pos: Any) -> None:
        hdr = self.table.horizontalHeader()
        col_idx = hdr.logicalIndexAt(pos) if hasattr(hdr, "logicalIndexAt") else -1
        if col_idx < 0 or col_idx >= len(self._col_alias_specs):
            return
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            self._start_inline_header_edit(col_idx)
            return
        menu = QMenuCls(self)
        act_rename = menu.addAction(tr("ctx_rename_col", self.lang))
        act_reset = menu.addAction(tr("ctx_reset_col", self.lang))
        gpos = hdr.mapToGlobal(pos) if hasattr(hdr, "mapToGlobal") else pos
        chosen = exec_menu(menu, gpos)
        if chosen == act_rename:
            self._start_inline_header_edit(col_idx)
        elif chosen == act_reset:
            self.reset_column_name(col_idx)

    def _start_inline_header_edit(self, col_idx: int) -> None:
        if col_idx < 0 or col_idx >= len(self._col_alias_specs):
            return
        alias_key, default_lbl, _pidx = self._col_alias_specs[col_idx]
        cur_item = self.table.horizontalHeaderItem(col_idx) if hasattr(self.table, "horizontalHeaderItem") else None
        cur_txt = cur_item.text() if cur_item is not None and hasattr(cur_item, "text") else (
            (self.config.field_aliases or {}).get(alias_key) or default_lbl
        )
        hdr = self.table.horizontalHeader()
        can_inline = (
            hasattr(hdr, "sectionViewportPosition")
            and hasattr(hdr, "sectionSize")
            and hasattr(hdr, "height")
            and int(hdr.sectionSize(col_idx) or 0) > 20
        )
        if can_inline:
            if self._header_editor is not None:
                try:
                    self._header_editor.deleteLater()
                except Exception:
                    pass
                self._header_editor = None
            parent_w = hdr.viewport() if hasattr(hdr, "viewport") and hdr.viewport() is not None else hdr
            ed = QLineEdit(parent_w)
            ed.setText(str(cur_txt or ""))
            if hasattr(ed, "selectAll"):
                ed.selectAll()
            ed.setStyleSheet(
                "QLineEdit { background: #0f172a; color: #f8fafc; border: 2px solid #38bdf8; "
                "border-radius: 3px; padding: 1px 4px; font-weight: 600; }"
            )
            x = int(hdr.sectionViewportPosition(col_idx))
            w = max(72, int(hdr.sectionSize(col_idx)))
            h = max(22, int(hdr.height()))
            ed.setGeometry(x, 0, w, h)
            committed = {"done": False}

            def _commit() -> None:
                if committed["done"]:
                    return
                committed["done"] = True
                new_val = ed.text() if hasattr(ed, "text") else ""
                try:
                    ed.hide()
                    ed.deleteLater()
                except Exception:
                    pass
                self._header_editor = None
                self.rename_column(col_idx, new_val)

            class _EscFilter(QtCore.QObject):
                def eventFilter(self_f, obj, ev):  # type: ignore[override]
                    ev_type = ev.type() if hasattr(ev, "type") else None
                    key_press = qt_enum(QtCore.QEvent, "Type", "KeyPress") if hasattr(QtCore, "QEvent") else None
                    esc_key = qt_enum(Qt, "Key", "Key_Escape")
                    if key_press is not None and ev_type == key_press and hasattr(ev, "key") and ev.key() == esc_key:
                        committed["done"] = True
                        try:
                            ed.hide()
                            ed.deleteLater()
                        except Exception:
                            pass
                        self._header_editor = None
                        return True
                    return False

            filt = _EscFilter(ed)
            ed.installEventFilter(filt)
            ed.editingFinished.connect(_commit)
            ed.show()
            if hasattr(ed, "setFocus"):
                ed.setFocus()
            self._header_editor = ed
            return

        # Dialog fallback if inline header geometry is unavailable
        QDialogCls = getattr(QtWidgets, "QDialog", None)
        QDBB = getattr(QtWidgets, "QDialogButtonBox", None)
        if QDialogCls is None:
            return
        dlg = QDialogCls(self)
        dlg.setWindowTitle(tr("tbl_rename_col_title", self.lang))
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(tr("tbl_rename_col_prompt", self.lang, field=default_lbl)))
        ed_dlg = QLineEdit(str(cur_txt or ""))
        lay.addWidget(ed_dlg)
        if QDBB is not None:
            btns = QDBB(qt_enum(QDBB, "StandardButton", "Ok") | qt_enum(QDBB, "StandardButton", "Cancel"))
            btns.accepted.connect(dlg.accept)
            btns.rejected.connect(dlg.reject)
            lay.addWidget(btns)
        if exec_dialog(dlg):
            self.rename_column(col_idx, ed_dlg.text())

    def _toggle_transpose(self) -> None:
        self.config.table_transpose = self.btn_transpose.isChecked()
        self._render_table()

    def refresh_data(
        self, records: List[Dict[str, Any]], filter_bus: FilterBus, lang: str = "et"
    ) -> None:
        self.lang = lang
        self._raw_records = list(records)
        self._filter_bus = filter_bus
        self.search_input.setPlaceholderText(tr("search_table", lang))
        self.btn_transpose.setToolTip(tr("tbl_transpose", lang))
        self.btn_transpose.setChecked(bool(getattr(self.config, "table_transpose", False)))
        hdr = self.table.horizontalHeader()
        if hasattr(hdr, "setToolTip"):
            hdr.setToolTip(tr("tbl_header_edit_tip", lang))
        self._current_rows = filter_bus.filter_records(records, layer_name=self.config.layer_name)
        self._render_table()

    def _render_table(self) -> None:
        query = self.search_input.text().strip().lower()
        mode = getattr(self.config, "table_mode", "detail") or "detail"
        is_pivot = (
            mode == "pivot"
            or bool(getattr(self.config, "pivot_rows", None))
            or bool(getattr(self.config, "pivot_values", None))
        )

        if is_pivot:
            headers, table_rows = Aggregator.compute_table(
                self._raw_records,
                self.config,
                self._filter_bus,
                lang=self.lang,
            )
            if query:
                table_rows = [
                    r for r in table_rows
                    if any(query in str(v).lower() for v in r.values() if v is not None)
                ]
            self.lbl_count.setText(f"{len(table_rows)} {tr('records', self.lang)}")
            self._col_alias_specs = self._compute_col_alias_specs(headers, is_pivot=True)
            self.table.setColumnCount(len(headers))
            self.table.setHorizontalHeaderLabels(headers)
            user_role = qt_enum(Qt, "ItemDataRole", "UserRole")
            display_rows = table_rows[:250]
            self.table.setRowCount(len(display_rows))
            p_rows = getattr(self.config, "pivot_rows", []) or []
            row_key_field = p_rows[0] if p_rows else (self.config.category_field or "")
            is_transposed = bool(getattr(self.config, "table_transpose", False))
            total_lbl = tr("tbl_pivot_total", self.lang)
            dec = int(self.config.decimals if self.config.decimals is not None else 1)

            active_sel_vals: set = set()
            if self._filter_bus is not None:
                for sid_cand in (self.config.id, f"tbl_{self.config.id}"):
                    active_sel_vals.update(str(v) for v in self._filter_bus.get_selected_values(sid_cand))

            hl_brush = QBrush(QColor(56, 189, 248, 72))
            bold_font = QFont()
            bold_font.setBold(True)

            for r_idx, row_dict in enumerate(display_rows):
                first_val = str(row_dict.get(headers[0], "")) if headers else ""
                is_total = (not is_transposed) and (first_val == total_lbl)
                meta: Dict[str, Any] = {}
                if (not is_transposed) and (not is_total) and row_key_field and headers:
                    meta = {"_filter_field": row_key_field, "_filter_value": first_val}
                is_row_selected = bool(active_sel_vals and (first_val in active_sel_vals))
                for c_idx, hdr in enumerate(headers):
                    cell = row_dict.get(hdr, "")
                    if isinstance(cell, float):
                        txt = f"{cell:,.{dec}f}"
                    elif cell is None:
                        txt = ""
                    else:
                        txt = str(cell)
                    item = QTableWidgetItem(txt)
                    item.setData(user_role, meta)
                    if is_row_selected:
                        item.setBackground(hl_brush)
                        item.setFont(bold_font)
                    self.table.setItem(r_idx, c_idx, item)
                if is_row_selected:
                    try:
                        self.table.selectRow(r_idx)
                    except Exception:
                        pass
            return

        rows = self._current_rows
        if query:
            rows = [
                r for r in rows
                if any(query in str(v).lower() for k, v in r.items() if not k.startswith("_") and v is not None)
            ]

        self.lbl_count.setText(f"{len(rows)} {tr('records', self.lang)}")
        headers, table_rows = Aggregator.compute_table(
            rows,
            self.config,
            None,
            lang=self.lang,
        )
        if not headers and rows:
            raw_cols = [k for k in rows[0].keys() if not str(k).startswith("_")][:8]
            aliases = dict(getattr(self.config, "field_aliases", None) or {})
            headers = [friendly_field_label(k, self.lang, aliases=aliases) for k in raw_cols]
            table_rows = [
                {
                    **{hk: r[hk] for hk in ("_feature_id", "_lat", "_lon", "_bbox") if hk in r},
                    **{h: r.get(k, "") for k, h in zip(raw_cols, headers)},
                }
                for r in rows[:200]
            ]

        self._col_alias_specs = self._compute_col_alias_specs(headers, is_pivot=False)
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)

        user_role = qt_enum(Qt, "ItemDataRole", "UserRole")
        display_rows = table_rows[:200]
        self.table.setRowCount(len(display_rows))
        is_transposed = bool(getattr(self.config, "table_transpose", False))
        dec = int(self.config.decimals if self.config.decimals is not None else 1)
        hl_brush = QBrush(QColor(56, 189, 248, 72))
        bold_font = QFont()
        bold_font.setBold(True)
        for r_idx, row_dict in enumerate(display_rows):
            src_row = row_dict if not is_transposed else {}
            row_fid = src_row.get("_feature_id")
            is_row_selected = row_fid is not None and str(row_fid) in self._selected_detail_fids
            for c_idx, hdr in enumerate(headers):
                val = row_dict.get(hdr, "") if isinstance(row_dict, dict) else ""
                if isinstance(val, float):
                    txt = f"{val:,.{dec}f}"
                elif val is None:
                    txt = ""
                else:
                    txt = str(val)
                item = QTableWidgetItem(txt)
                item.setData(user_role, src_row)
                if is_row_selected:
                    item.setBackground(hl_brush)
                    item.setFont(bold_font)
                self.table.setItem(r_idx, c_idx, item)
            if is_row_selected:
                try:
                    self.table.selectRow(r_idx)
                except Exception:
                    pass

    def clear_selection(self) -> None:
        self._selected_detail_fids.clear()
        try:
            self.table.clearSelection()
        except Exception:
            pass
        self._render_table()

    def _handle_cell_click(self, row_idx: int, _col_idx: int) -> None:
        item = self.table.item(row_idx, 0)
        if not item:
            return
        row_data = item.data(qt_enum(Qt, "ItemDataRole", "UserRole"))
        if isinstance(row_data, dict):
            rfid = row_data.get("_feature_id")
            if rfid is not None:
                sfid = str(rfid)
                if sfid in self._selected_detail_fids:
                    self._selected_detail_fids.discard(sfid)
                else:
                    self._selected_detail_fids.add(sfid)
            if self.on_row_selected:
                self.on_row_selected(row_data)
