# -*- coding: utf-8 -*-
"""
PyQt6 (QGIS 4.0 / 4.2+) and PyQt5 (QGIS 3.44+) compatibility helpers.
Handles scoped Qt6 enums, QAction namespace movement (QtGui vs QtWidgets),
QDialog.exec(), and Qt6 QMouseEvent.position() / globalPosition().
"""

from typing import Any

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
except ImportError:
    try:
        from PyQt6 import QtCore, QtGui, QtWidgets  # type: ignore
    except ImportError:
        from PyQt5 import QtCore, QtGui, QtWidgets  # type: ignore

QAction = getattr(QtGui, "QAction", None) or getattr(QtWidgets, "QAction")


def qt_enum(owner: Any, group_name: str, member_name: str) -> Any:
    """Resolve a Qt enum cleanly across both PyQt6 (scoped) and PyQt5 (unscoped)."""
    group = getattr(owner, group_name, None)
    if group is not None and hasattr(group, member_name):
        return getattr(group, member_name)
    return getattr(owner, member_name)


def exec_dialog(dialog: Any) -> int:
    """Execute a QDialog modally across both Qt6 (exec()) and Qt5 (exec() / exec_())."""
    fn = getattr(dialog, "exec", None) or getattr(dialog, "exec_")
    return int(fn())


def exec_menu(menu: Any, global_pos: Any) -> Any:
    """Execute a QMenu at global_pos across both Qt6 (exec()) and Qt5 (exec() / exec_())."""
    fn = getattr(menu, "exec", None) or getattr(menu, "exec_")
    return fn(global_pos)


def mouse_pos_f(event: Any) -> Any:
    """Return local QPointF for a QMouseEvent on both Qt6 (position()) and Qt5 (pos())."""
    if hasattr(event, "position"):
        return event.position()
    return QtCore.QPointF(event.pos())


def mouse_global_pos(event: Any) -> Any:
    """Return global QPoint for QToolTip across Qt6 (globalPosition()) and Qt5 (globalPos())."""
    if hasattr(event, "globalPosition"):
        return event.globalPosition().toPoint()
    return event.globalPos()
