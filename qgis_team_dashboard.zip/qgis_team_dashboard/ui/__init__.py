# -*- coding: utf-8 -*-
"""Interactive PyQt UI components, dialogs, and dockable dashboard studio for QGIS Desktop."""
