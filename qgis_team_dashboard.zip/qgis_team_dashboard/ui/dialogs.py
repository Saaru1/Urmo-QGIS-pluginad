# -*- coding: utf-8 -*-
"""
Modern Configuration Dialogs for QGIS Team Dashboard (Qt5 & Qt6 compatible).
- ServerSettingsDialog: Configure custom WFS/WMS servers + AuthCfg and test GetCapabilities.
- WidgetEditorDialog: Visual tile selector for Map View, Summary Card, Charts, and Table,
  with lazy WFS DescribeFeatureType schema discovery and Estonian conservation unit presets.
- SlicerEditorDialog: Localized slicer/filter card configurator.
- DataSourceJoinDialog: Sources, Excel/CSV portable joins, and OGC service discovery.
- SharePointCatalogDialog: Team template catalog + optional package installer.
"""

import base64
import copy
import mimetypes
import os
from typing import Any, Callable, Dict, List, Optional, Tuple

from .qt_compat import QAction, QtCore, QtGui, QtWidgets, exec_dialog, exec_menu, qt_enum

Qt = QtCore.Qt
QButtonGroup = QtWidgets.QButtonGroup
QCheckBox = QtWidgets.QCheckBox
QColorDialog = QtWidgets.QColorDialog
QComboBox = QtWidgets.QComboBox
QDialog = QtWidgets.QDialog
QDialogButtonBox = QtWidgets.QDialogButtonBox
QDoubleSpinBox = QtWidgets.QDoubleSpinBox
QFileDialog = QtWidgets.QFileDialog
QFormLayout = QtWidgets.QFormLayout
QFrame = QtWidgets.QFrame
QGridLayout = QtWidgets.QGridLayout
QGroupBox = QtWidgets.QGroupBox
QHBoxLayout = QtWidgets.QHBoxLayout
QLabel = QtWidgets.QLabel
QLineEdit = QtWidgets.QLineEdit
QListWidget = QtWidgets.QListWidget
QListWidgetItem = QtWidgets.QListWidgetItem
QMenu = QtWidgets.QMenu
QMessageBox = QtWidgets.QMessageBox
QPlainTextEdit = getattr(QtWidgets, "QPlainTextEdit", QtWidgets.QLineEdit)
QPushButton = QtWidgets.QPushButton
QScrollArea = QtWidgets.QScrollArea
QSlider = QtWidgets.QSlider
QSpinBox = QtWidgets.QSpinBox
QTabWidget = QtWidgets.QTabWidget
QTableWidget = getattr(QtWidgets, "QTableWidget", QtWidgets.QListWidget)
QTableWidgetItem = getattr(QtWidgets, "QTableWidgetItem", QtWidgets.QListWidgetItem)
QVBoxLayout = QtWidgets.QVBoxLayout
QWidget = QtWidgets.QWidget

QPoint = QtCore.QPoint
QPointF = getattr(QtCore, "QPointF", QtCore.QPoint)
QRectF = getattr(QtCore, "QRectF", QtCore.QRect)
QBrush = QtGui.QBrush
QColor = QtGui.QColor
QPainter = getattr(QtGui, "QPainter", None)
QPainterPath = getattr(QtGui, "QPainterPath", None)
QPen = QtGui.QPen
QPolygonF = getattr(QtGui, "QPolygonF", list)
QGuiApplication = getattr(QtGui, "QGuiApplication", None)


def _apply_laptop_friendly_bounds(
    dlg: Any,
    pref_w: int,
    pref_h: int,
    min_w: int = 440,
    min_h: int = 340,
) -> None:
    """Keep dialogs minimizable/maximizable and within smaller laptop screen bounds."""
    sw, sh = 1366, 768
    try:
        if QGuiApplication is not None and hasattr(QGuiApplication, "primaryScreen"):
            scr = QGuiApplication.primaryScreen()
            if scr is not None and hasattr(scr, "availableGeometry"):
                ag = scr.availableGeometry()
                if ag is not None and int(ag.width()) > 200 and int(ag.height()) > 200:
                    sw, sh = int(ag.width()), int(ag.height())
    except Exception:
        pass
    safe_min_w = min(int(min_w), max(320, sw - 48))
    safe_min_h = min(int(min_h), max(260, sh - 64))
    if hasattr(dlg, "setMinimumSize"):
        dlg.setMinimumSize(safe_min_w, safe_min_h)
    if hasattr(dlg, "resize"):
        dlg.resize(
            max(safe_min_w, min(int(pref_w), sw - 36)),
            max(safe_min_h, min(int(pref_h), sh - 48)),
        )

from ..connectors.catalog_manager import LocalCatalogManager
from ..connectors.excel_connector import ExcelConnector
from ..connectors.ogc_connector import ESTONIAN_OGC_PRESETS, OgcConnector
from ..connectors.path_resolver import PortablePathResolver
from ..connectors.sharepoint_connector import SharePointConnector
from ..core.aggregator import CALC_AREA_FIELD, CALC_COUNT_FIELD, friendly_field_label
from ..core.dependency_manager import DependencyManager
from ..core.expression_engine import (
    EXPRESSION_TEMPLATES,
    compute_dashboard_widget_ref,
    evaluate_dashboard_expression,
    expression_to_blocks,
)
from ..core.i18n import tr
from ..core.persistence import DashboardPersistenceManager
from ..core.schema import (
    DashboardConfig,
    DashboardPageConfig,
    DataSourceConfig,
    JoinConfig,
    SlicerConfig,
    WidgetConfig,
    WidgetConnectionConfig,
    group_slicer_panes,
    suggest_widget_titles,
)
from .theme import ThemeManager
from .widgets import DragFieldListWidget, MAAAMET_BASEMAPS


def _populate_target_connection_list(
    list_widget: QListWidget,
    dashboard: Optional[DashboardConfig],
    source_id: str,
    selected_targets: Optional[List[str]],
    lang: str = "et",
) -> None:
    """Populate a checkable list of target widgets + Map ('__map__') for Model Connections."""
    list_widget.clear()
    if dashboard is None:
        return
    linked = set(selected_targets or [])
    for conn in getattr(dashboard, "widget_connections", []) or []:
        if getattr(conn, "enabled", True) and conn.source_id == source_id and conn.target_id:
            linked.add(conn.target_id)

    role = qt_enum(Qt, "ItemDataRole", "UserRole")
    checked = qt_enum(Qt, "CheckState", "Checked")
    unchecked = qt_enum(Qt, "CheckState", "Unchecked")
    flag_chk = qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable")
    flag_en = qt_enum(Qt, "ItemFlag", "ItemIsEnabled")

    map_item = QListWidgetItem(f"🗺️ {tr('map_widget_title', lang)}")
    map_item.setData(role, "__map__")
    map_item.setFlags(flag_en | flag_chk)
    map_item.setCheckState(checked if "__map__" in linked else unchecked)
    list_widget.addItem(map_item)

    type_icons = {
        "map": "🗺️",
        "kpi": "🔢",
        "bar": "📊",
        "pie": "🥧",
        "line": "📈",
        "scatter": "🔵",
        "table": "📋",
    }
    for w in getattr(dashboard, "widgets", []) or []:
        if w.id == source_id:
            continue
        wtitle = w.title_en if (lang == "en" and getattr(w, "title_en", "")) else w.title
        icon = type_icons.get(w.widget_type, "📊")
        layer_sfx = f" ({w.layer_name})" if w.layer_name else ""
        it = QListWidgetItem(f"{icon} {wtitle}{layer_sfx}")
        it.setData(role, w.id)
        it.setFlags(flag_en | flag_chk)
        it.setCheckState(checked if w.id in linked else unchecked)
        list_widget.addItem(it)


def _save_target_connection_list(
    list_widget: QListWidget,
    dashboard: Optional[DashboardConfig],
    source_id: str,
) -> List[str]:
    """Read checked target IDs from `list_widget` and sync `dashboard.widget_connections`."""
    role = qt_enum(Qt, "ItemDataRole", "UserRole")
    checked = qt_enum(Qt, "CheckState", "Checked")
    selected: List[str] = []
    for idx in range(list_widget.count()):
        it = list_widget.item(idx)
        if it is not None and it.checkState() == checked:
            tid = str(it.data(role) or "")
            if tid and tid != source_id and tid not in selected:
                selected.append(tid)

    if dashboard is not None:
        existing_actions = {
            c.target_id: (c.action or "filter_and_zoom")
            for c in getattr(dashboard, "widget_connections", []) or []
            if c.source_id == source_id
        }
        dashboard.widget_connections = [
            c
            for c in getattr(dashboard, "widget_connections", []) or []
            if c.source_id != source_id
        ]
        for tid in selected:
            dashboard.widget_connections.append(
                WidgetConnectionConfig(
                    id=f"conn_{source_id}_{tid}",
                    source_id=source_id,
                    target_id=tid,
                    action=existing_actions.get(tid, "filter_and_zoom"),
                    enabled=True,
                )
            )
        dashboard.sync_widget_connections()
    return selected


def _lookup_fields_lazy(
    layer_name: str,
    layer_fields_map: Dict[str, List[str]],
    dashboard: Optional[DashboardConfig] = None,
    catalog_manager: Optional[LocalCatalogManager] = None,
    allow_network: bool = False,
) -> List[str]:
    """Resolve field names for a layer without downloading full geometries."""
    if not layer_name or layer_name == "*":
        return []
    if layer_fields_map.get(layer_name):
        return list(layer_fields_map[layer_name])

    qgis_schemas = DashboardPersistenceManager.list_qgis_project_layer_schemas()
    if qgis_schemas.get(layer_name):
        layer_fields_map[layer_name] = list(qgis_schemas[layer_name])
        return list(qgis_schemas[layer_name])

    # Check Excel sheet headers locally if configured on dashboard
    if dashboard:
        for ds in dashboard.data_sources:
            if ds.name == layer_name and ds.source_type in ("excel", "csv"):
                try:
                    recs = ExcelConnector.read_records(
                        PortablePathResolver.resolve(ds.portable_path),
                        ds.sheet_name,
                        max_rows=5,
                    )
                    if recs:
                        cols = [k for k in recs[0].keys() if not str(k).startswith("_")]
                        layer_fields_map[layer_name] = cols
                        return cols
                except Exception:
                    pass

    if not allow_network:
        return []

    # Try DescribeFeatureType (lightweight XSD only, zero features fetched)
    url = ""
    typename = layer_name
    if dashboard:
        for ds in dashboard.data_sources:
            if ds.name == layer_name or ds.typename_or_layers == layer_name:
                url = ds.url
                typename = ds.typename_or_layers or layer_name
                break
    if not url and catalog_manager:
        for srv in catalog_manager.get_servers():
            for lyr in srv.get("layers", []):
                if lyr.get("name") == layer_name or lyr.get("title") == layer_name:
                    url = srv.get("url", "")
                    typename = lyr.get("name", layer_name)
                    break
            if url:
                break

    if url and typename:
        cols = OgcConnector.describe_wfs_fields(url, typename, timeout=8)
        if cols:
            layer_fields_map[layer_name] = cols
            return cols
    return []


ESTONIAN_WFS_SERVER_PRESETS: List[Dict[str, str]] = [
    {
        "name": "EELIS (Avalik / Keskkonnaagentuur)",
        "type": "wfs",
        "url": "https://gsavalik.envir.ee/geoserver/eelis/ows",
        "crs": "EPSG:3301",
    },
    {
        "name": "EELIS (Sisemine / Keskkonnaagentuur)",
        "type": "wfs",
        "url": "https://gsa.envir.ee/geoserver/eelis/wfs",
        "crs": "EPSG:3301",
    },
    {
        "name": "PRIA Pärandniidud (Avalik)",
        "type": "wfs",
        "url": "https://kls.pria.ee/geoserver/pria_avalik/wfs",
        "crs": "EPSG:3301",
    },
    {
        "name": "Maa- ja Ruumiamet Kataster",
        "type": "wfs",
        "url": "https://gsavalik.envir.ee/geoserver/kataster/wfs",
        "crs": "EPSG:3301",
    },
    {
        "name": "Maa- ja Ruumiamet ETAK",
        "type": "wfs",
        "url": "https://gsavalik.envir.ee/geoserver/etak/wfs",
        "crs": "EPSG:3301",
    },
]


class ServerSettingsDialog(QDialog):
    """Add or edit a WFS/WMS service connection in the persistent local catalog."""

    def __init__(
        self,
        catalog_mgr: Optional[LocalCatalogManager] = None,
        server_entry: Optional[Dict[str, Any]] = None,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.catalog_mgr = catalog_mgr
        self.lang = lang
        self.server_entry = dict(server_entry or {})
        self.saved_server_name: str = ""
        self.result_entry: Optional[Dict[str, Any]] = None
        self.last_layer_count: Optional[int] = None

        self.setWindowTitle(tr("dlg_server_title", lang))
        self.setMinimumWidth(500)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        hdr = QLabel(
            f"<b>{tr('dlg_server_title', lang)}</b><br>"
            "<span style='color:#94a3b8;font-size:11px;'>"
            + (
                "Vali Eesti WFS/WMS mall või sisesta oma teenuse URL, CRS ja autentimine."
                if lang == "et"
                else "Pick an Estonian WFS/WMS preset or enter your own service URL, CRS, and auth."
            )
            + "</span>"
        )
        hdr.setWordWrap(True)
        layout.addWidget(hdr)

        form = QFormLayout()
        form.setSpacing(8)

        self.cb_preset = QComboBox()
        self.cb_preset.addItem(
            "— Kohandatud teenus —" if lang == "et" else "— Custom service —",
            None,
        )
        for preset in ESTONIAN_WFS_SERVER_PRESETS:
            self.cb_preset.addItem(preset["name"], preset)

        self.ed_name = QLineEdit(self.server_entry.get("name", ""))
        self.ed_name.setPlaceholderText("nt. Maa- ja Ruumiamet Kataster WFS")

        self.cb_type = QComboBox()
        self.cb_type.addItem("WFS (Vektorkihid)", "wfs")
        self.cb_type.addItem("WMS (Aluskaardid / Raster)", "wms")
        stype = (self.server_entry.get("type") or "wfs").lower()
        idx_t = self.cb_type.findData(stype)
        if idx_t >= 0:
            self.cb_type.setCurrentIndex(idx_t)

        self.ed_url = QLineEdit(self.server_entry.get("url", ""))
        self.ed_url.setPlaceholderText("https://gsavalik.envir.ee/geoserver/eelis/ows")

        self.ed_crs = QLineEdit(self.server_entry.get("crs", "EPSG:3301"))

        self.cb_authcfg = QComboBox()
        self.cb_authcfg.setEditable(True)
        self.cb_authcfg.addItem("")
        try:
            from qgis.core import QgsApplication  # type: ignore

            auth_mgr = QgsApplication.authManager()
            for cid in sorted(auth_mgr.configIds()):
                self.cb_authcfg.addItem(str(cid))
        except Exception:
            pass
        if self.server_entry.get("authcfg"):
            self.cb_authcfg.setCurrentText(str(self.server_entry["authcfg"]))

        self.chk_basemap = QCheckBox(tr("lbl_is_basemap", lang))
        self.chk_basemap.setChecked(bool(self.server_entry.get("is_basemap", False)))

        form.addRow(tr("lbl_srv_preset", lang), self.cb_preset)
        form.addRow(tr("lbl_srv_name", lang), self.ed_name)
        form.addRow(tr("lbl_srv_type", lang), self.cb_type)
        form.addRow(tr("lbl_srv_url", lang), self.ed_url)
        form.addRow(tr("lbl_crs", lang), self.ed_crs)
        form.addRow(tr("lbl_srv_authcfg", lang), self.cb_authcfg)
        form.addRow("", self.chk_basemap)
        layout.addLayout(form)

        preset_sig = getattr(self.cb_preset, "currentIndexChanged", None)
        if preset_sig is not None and hasattr(preset_sig, "connect"):
            preset_sig.connect(self._on_preset_changed)

        test_row = QHBoxLayout()
        self.btn_test = QPushButton(tr("btn_test_srv", lang))
        self.btn_test.clicked.connect(self._test_connection)
        self.lbl_test_status = QLabel("")
        self.lbl_test_status.setWordWrap(True)
        test_row.addWidget(self.btn_test)
        test_row.addWidget(self.lbl_test_status, 1)
        layout.addLayout(test_row)

        btns = QHBoxLayout()
        btns.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", lang))
        btn_cancel.clicked.connect(self.reject)
        btn_save = QPushButton(tr("btn_save", lang))
        btn_save.setProperty("btnRole", "primary")
        btn_save.clicked.connect(self._on_save)
        btns.addWidget(btn_cancel)
        btns.addWidget(btn_save)
        layout.addLayout(btns)

    def _on_preset_changed(self, _idx: int = 0) -> None:
        preset = self.cb_preset.currentData() if hasattr(self.cb_preset, "currentData") else None
        if not isinstance(preset, dict):
            return
        self.ed_name.setText(preset.get("name", ""))
        self.ed_url.setText(preset.get("url", ""))
        self.ed_crs.setText(preset.get("crs", "EPSG:3301"))
        stype = (preset.get("type") or "wfs").lower()
        idx_t = self.cb_type.findData(stype)
        if idx_t >= 0:
            self.cb_type.setCurrentIndex(idx_t)

    def _test_connection(self) -> None:
        url = self.ed_url.text().strip()
        stype = str(self.cb_type.currentData() or "wfs")
        if not url:
            return
        self.lbl_test_status.setText("⏳ ...")
        QtWidgets.QApplication.processEvents()
        try:
            layers = OgcConnector.discover_layers(url, service_type=stype, timeout=12)
            self.last_layer_count = len(layers)
            self.lbl_test_status.setStyleSheet("color: #34d399; font-weight: 600;")
            msg = (
                f"✓ Ühendus toimib! Leitud {len(layers)} kihti."
                if self.lang == "et"
                else f"✓ Connected! Found {len(layers)} layers."
            )
            self.lbl_test_status.setText(msg)
        except Exception as exc:
            self.lbl_test_status.setStyleSheet("color: #f87171;")
            self.lbl_test_status.setText(f"✗ {exc}")

    def _on_save(self) -> None:
        name = self.ed_name.text().strip()
        url = self.ed_url.text().strip()
        if not name or not url:
            QMessageBox.warning(
                self,
                tr("dlg_server_title", self.lang),
                "Palun sisesta nii teenuse nimi kui URL."
                if self.lang == "et"
                else "Please enter both server name and URL.",
            )
            return
        stype = str(self.cb_type.currentData() or "wfs")
        crs = self.ed_crs.text().strip() or "EPSG:3301"
        authcfg = self.cb_authcfg.currentText().strip()
        is_bm = self.chk_basemap.isChecked()
        entry: Dict[str, Any] = {
            "name": name,
            "url": url,
            "type": stype,
            "crs": crs,
            "authcfg": authcfg,
            "is_basemap": is_bm,
            "layers": list(self.server_entry.get("layers") or []),
        }
        if self.last_layer_count is not None:
            entry["layer_count"] = self.last_layer_count
        self.result_entry = entry
        if self.catalog_mgr is not None:
            old_name = str(self.server_entry.get("name") or "").strip()
            if old_name and old_name != name:
                try:
                    self.catalog_mgr.remove_server(old_name)
                except Exception:
                    pass
            self.catalog_mgr.add_or_update_server(
                name=name,
                url=url,
                service_type=stype,
                crs=crs,
                authcfg=authcfg,
                is_basemap=is_bm,
            )
        self.saved_server_name = name
        self.accept()


class SlicerEditorDialog(QDialog):
    """Localized dialog for configuring a resizable Filter / Slicer card."""

    def __init__(
        self,
        slicer_cfg: SlicerConfig,
        available_layers: List[str],
        layer_fields_map: Dict[str, List[str]],
        lang: str = "et",
        catalog_manager: Optional[LocalCatalogManager] = None,
        dashboard: Optional[DashboardConfig] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.slicer_cfg = slicer_cfg
        self.layer_fields_map = layer_fields_map
        self.lang = lang
        self.catalog_manager = catalog_manager
        self.dashboard = dashboard

        self.setWindowTitle(tr("dlg_slicer_title", lang))
        self.setMinimumWidth(480)
        self.setStyleSheet(ThemeManager.get_stylesheet())
        self._title_user_edited = bool(getattr(slicer_cfg, "title_custom", False)) or bool(
            slicer_cfg.title and slicer_cfg.title not in ("Kategooria filter", "Uus filter", tr("btn_add_slicer", lang))
        )
        self._panes_data: List[Dict[str, Any]] = [
            dict(p) for p in (getattr(slicer_cfg, "panes", None) or []) if isinstance(p, dict)
        ]

        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(8)

        self.ed_title_et = QLineEdit(slicer_cfg.title or "")
        _te_sig = getattr(self.ed_title_et, "textEdited", None)
        if _te_sig is not None and hasattr(_te_sig, "connect"):
            _te_sig.connect(lambda _t: setattr(self, "_title_user_edited", True))
        self.ed_title_en = QLineEdit(slicer_cfg.title_en or "")

        # Suggested concise title chips (#11)
        sug_wrap = QWidget()
        sug_lay = QHBoxLayout(sug_wrap)
        sug_lay.setContentsMargins(0, 0, 0, 0)
        sug_lay.setSpacing(4)
        self._slicer_sug_layout = sug_lay
        self._slicer_sug_buttons: List[QPushButton] = []

        self.cb_layer = QComboBox()
        self.cb_layer.setEditable(True)
        for lyr in available_layers:
            self.cb_layer.addItem(lyr)
        if slicer_cfg.layer_name and self.cb_layer.findText(slicer_cfg.layer_name) < 0:
            self.cb_layer.addItem(slicer_cfg.layer_name)
        if slicer_cfg.layer_name:
            self.cb_layer.setCurrentText(slicer_cfg.layer_name)

        field_row = QHBoxLayout()
        self.cb_field = QComboBox()
        self.cb_field.setEditable(True)
        self.btn_probe = QPushButton("🔍")
        self.btn_probe.setToolTip(
            "Uuri kihi välju (DescribeFeatureType)" if lang == "et" else "Inspect layer schema"
        )
        self.btn_probe.clicked.connect(lambda: self._populate_fields(network=True))
        field_row.addWidget(self.cb_field, 1)
        field_row.addWidget(self.btn_probe)

        self.cb_slicer_type = QComboBox()
        self.cb_slicer_type.addItem(tr("slicer_type_category", lang), "category")
        self.cb_slicer_type.addItem(tr("slicer_type_numeric", lang), "numeric_range")
        self.cb_slicer_type.addItem(tr("slicer_type_date", lang), "date_range")
        idx_type = self.cb_slicer_type.findData(getattr(slicer_cfg, "slicer_type", "category") or "category")
        if idx_type >= 0:
            self.cb_slicer_type.setCurrentIndex(idx_type)

        self.lbl_style_row = QLabel(tr("lbl_slicer_style", lang))
        self.cb_style = QComboBox()
        self.cb_style.addItem(tr("slicer_style_chips", lang), "chips")
        self.cb_style.addItem(tr("slicer_style_list", lang), "list")
        idx_st = self.cb_style.findData(getattr(slicer_cfg, "display_mode", "chips") or "chips")
        if idx_st >= 0:
            self.cb_style.setCurrentIndex(idx_st)

        self.chk_search = QCheckBox(tr("lbl_slicer_search", lang))
        self.chk_search.setChecked(bool(getattr(slicer_cfg, "show_search", True)))

        self.chk_multi = QCheckBox(
            "Luba mitu valikut korraga" if lang == "et" else "Allow multiple selections"
        )
        self.chk_multi.setChecked(slicer_cfg.multi_select)

        self.chk_cascade = QCheckBox(tr("chk_slicer_cascade", lang))
        self.chk_cascade.setChecked(bool(getattr(slicer_cfg, "cascade_filters", True)))

        self.cb_page = QComboBox()
        pages_list = list(getattr(dashboard, "pages", []) or []) if dashboard else []
        if not pages_list:
            pages_list = [DashboardPageConfig()]
        for pg in pages_list:
            pg_lbl = pg.title_en if (lang == "en" and pg.title_en) else pg.title
            self.cb_page.addItem(f"{pg.icon} {pg_lbl}", pg.id)
        idx_pg = self.cb_page.findData(getattr(slicer_cfg, "page_id", "page_1") or "page_1")
        if idx_pg >= 0:
            self.cb_page.setCurrentIndex(idx_pg)

        self.chk_global = QCheckBox(tr("global_atlas_filter", lang))
        self.chk_global.setChecked(bool(getattr(slicer_cfg, "is_global", False)))

        form.addRow(tr("lbl_slicer_title", lang), self.ed_title_et)
        form.addRow(tr("lbl_title_suggestions", lang), sug_wrap)
        form.addRow(tr("lbl_w_title_en", lang), self.ed_title_en)
        form.addRow(tr("lbl_slicer_type", lang), self.cb_slicer_type)
        form.addRow(tr("lbl_slicer_layer", lang), self.cb_layer)
        form.addRow(tr("lbl_slicer_field", lang), field_row)
        form.addRow(self.lbl_style_row, self.cb_style)
        form.addRow("", self.chk_search)
        form.addRow("", self.chk_multi)
        form.addRow("", self.chk_cascade)
        form.addRow(tr("lbl_page_assign", lang), self.cb_page)
        form.addRow("", self.chk_global)
        self.cb_slicer_type.currentIndexChanged.connect(lambda _i: self._sync_slicer_type_controls())
        self._sync_slicer_type_controls()
        layout.addLayout(form)

        # Multi-Pane Filter Builder (#15)
        panes_grp = QGroupBox(tr("lbl_multi_panes", lang))
        p_lay = QVBoxLayout(panes_grp)
        p_lay.setSpacing(5)
        p_btns = QHBoxLayout()
        btn_add_fp = QPushButton(tr("btn_add_field_pane", lang))
        btn_add_fp.clicked.connect(self._add_field_pane)
        btn_add_ap = QPushButton(tr("btn_add_addr_pane", lang))
        btn_add_ap.clicked.connect(self._add_address_pane)
        btn_rm_p = QPushButton(tr("btn_remove", lang))
        btn_rm_p.clicked.connect(self._remove_selected_pane)
        p_btns.addWidget(btn_add_fp)
        p_btns.addWidget(btn_add_ap)
        p_btns.addWidget(btn_rm_p)
        p_btns.addStretch()
        p_lay.addLayout(p_btns)
        self.list_panes = QListWidget()
        self.list_panes.setMaximumHeight(82)
        p_lay.addWidget(self.list_panes)
        self.chk_merge_shared = QCheckBox(tr("chk_merge_shared_fields", lang))
        self.chk_merge_shared.setChecked(bool(getattr(slicer_cfg, "merge_shared_fields", True)))
        self.chk_merge_shared.toggled.connect(lambda _c: self._refresh_panes_list())
        p_lay.addWidget(self.chk_merge_shared)
        self.lbl_merge_preview = QLabel("")
        self.lbl_merge_preview.setProperty("role", "mutedTiny")
        self.lbl_merge_preview.setWordWrap(True)
        self.lbl_merge_preview.hide()
        p_lay.addWidget(self.lbl_merge_preview)
        layout.addWidget(panes_grp)
        self._refresh_panes_list()

        lbl_conns = QLabel(tr("lbl_linked_targets", lang))
        layout.addWidget(lbl_conns)
        self.list_targets = QListWidget()
        self.list_targets.setMaximumHeight(105)
        _populate_target_connection_list(
            self.list_targets,
            self.dashboard,
            slicer_cfg.id,
            getattr(slicer_cfg, "connected_target_ids", []),
            lang=lang,
        )
        layout.addWidget(self.list_targets)

        self.cb_layer.currentTextChanged.connect(lambda _txt: self._populate_fields(network=False))
        self.cb_layer.currentTextChanged.connect(lambda _txt: self._refresh_title_suggestions())
        self.cb_field.currentTextChanged.connect(lambda _txt: self._refresh_title_suggestions())
        self._populate_fields(network=False)
        if slicer_cfg.field_name:
            self.cb_field.setCurrentText(slicer_cfg.field_name)
        self._refresh_title_suggestions()

        btns = QHBoxLayout()
        btns.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", lang))
        btn_cancel.clicked.connect(self.reject)
        btn_save = QPushButton(tr("btn_save", lang))
        btn_save.setProperty("btnRole", "primary")
        btn_save.clicked.connect(self._on_save)
        btns.addWidget(btn_cancel)
        btns.addWidget(btn_save)
        layout.addLayout(btns)

    def _populate_fields(self, network: bool = False) -> None:
        lyr = self.cb_layer.currentText().strip()
        cur = self.cb_field.currentText().strip()
        cols = _lookup_fields_lazy(
            lyr,
            self.layer_fields_map,
            dashboard=self.dashboard,
            catalog_manager=self.catalog_manager,
            allow_network=network,
        )
        self.cb_field.blockSignals(True)
        self.cb_field.clear()
        for c in cols:
            self.cb_field.addItem(c)
        if cur:
            self.cb_field.setCurrentText(cur)
        elif cols and not self.slicer_cfg.field_name:
            self.cb_field.setCurrentIndex(0)
        self.cb_field.blockSignals(False)

    def _refresh_title_suggestions(self) -> None:
        while self._slicer_sug_layout.count():
            it = self._slicer_sug_layout.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        suggestions = suggest_widget_titles(
            "slicer",
            layer_name=self.cb_layer.currentText().strip(),
            dimension_field=self.cb_field.currentText().strip(),
            lang=self.lang,
        )
        if not getattr(self, "_title_user_edited", False) and suggestions:
            self.ed_title_et.setText(suggestions[0])
        for sug in suggestions:
            btn = QPushButton(sug)
            btn.setProperty("btnRole", "chip")
            btn.setStyleSheet("font-size: 10px; padding: 2px 7px;")
            btn.clicked.connect(lambda _c=False, s=sug: (setattr(self, "_title_user_edited", True), self.ed_title_et.setText(s)))
            self._slicer_sug_layout.addWidget(btn)
        self._slicer_sug_layout.addStretch()

    def _add_field_pane(self) -> None:
        lyr = self.cb_layer.currentText().strip()
        fld = self.cb_field.currentText().strip()
        if not lyr or not fld:
            return
        self._panes_data.append(
            {
                "id": f"pane_{len(self._panes_data) + 1}",
                "pane_type": "field",
                "title": f"{fld} ({lyr})" if len(lyr) <= 18 else fld,
                "layer_name": lyr,
                "field_name": fld,
                "display_mode": str(self.cb_style.currentData() or "list"),
                "multi_select": bool(self.chk_multi.isChecked()),
            }
        )
        self._refresh_panes_list()

    def _add_address_pane(self) -> None:
        self._panes_data.append(
            {
                "id": f"pane_{len(self._panes_data) + 1}",
                "pane_type": "address",
                "title": "Aadress / Kataster" if self.lang == "et" else "Address / Cadastral",
                "layer_name": "__spatial__",
                "field_name": "kataster",
                "display_mode": "search",
                "multi_select": False,
            }
        )
        self._refresh_panes_list()

    def _remove_selected_pane(self) -> None:
        row = self.list_panes.currentRow()
        if 0 <= row < len(self._panes_data):
            self._panes_data.pop(row)
            self._refresh_panes_list()

    def _refresh_panes_list(self) -> None:
        self.list_panes.clear()
        for idx, p in enumerate(self._panes_data):
            tag = "📍 In-Aadress" if p.get("pane_type") == "address" else f"🔍 {p.get('layer_name')} · {p.get('field_name')}"
            self.list_panes.addItem(f"{idx + 1}. {p.get('title', '')} [{tag}]")
        if hasattr(self, "lbl_merge_preview"):
            grouped = group_slicer_panes(
                self._panes_data,
                merge_shared_fields=bool(getattr(self, "chk_merge_shared", None) and self.chk_merge_shared.isChecked()),
                fallback_display_mode=str(self.cb_style.currentData() or "list"),
                fallback_multi_select=bool(self.chk_multi.isChecked()),
            )
            merged_titles = [g.get("title", "") for g in grouped if g.get("merged")]
            if merged_titles:
                self.lbl_merge_preview.setText(tr("slicer_merged_preview", self.lang, summary=", ".join(merged_titles)))
                self.lbl_merge_preview.show()
            else:
                self.lbl_merge_preview.clear()
                self.lbl_merge_preview.hide()

    def _sync_slicer_type_controls(self) -> None:
        is_cat = str(self.cb_slicer_type.currentData() or "category") == "category"
        self.lbl_style_row.setVisible(is_cat)
        self.cb_style.setVisible(is_cat)
        self.chk_search.setVisible(is_cat)
        self.chk_multi.setVisible(is_cat)
        self.chk_cascade.setVisible(is_cat)

    def _on_save(self) -> None:
        self.slicer_cfg.title = self.ed_title_et.text().strip() or self.cb_field.currentText().strip() or "Filter"
        self.slicer_cfg.title_en = self.ed_title_en.text().strip() or self.slicer_cfg.title
        self.slicer_cfg.title_custom = bool(getattr(self, "_title_user_edited", False))
        self.slicer_cfg.slicer_type = str(self.cb_slicer_type.currentData() or "category")
        self.slicer_cfg.layer_name = self.cb_layer.currentText().strip()
        self.slicer_cfg.field_name = self.cb_field.currentText().strip()
        self.slicer_cfg.multi_select = self.chk_multi.isChecked()
        self.slicer_cfg.cascade_filters = self.chk_cascade.isChecked()
        self.slicer_cfg.display_mode = str(self.cb_style.currentData() or "chips")
        self.slicer_cfg.show_search = self.chk_search.isChecked()
        self.slicer_cfg.page_id = str(self.cb_page.currentData() or "page_1")
        self.slicer_cfg.is_global = bool(self.chk_global.isChecked())
        self.slicer_cfg.panes = [dict(p) for p in self._panes_data]
        self.slicer_cfg.merge_shared_fields = bool(self.chk_merge_shared.isChecked())
        self.slicer_cfg.connected_target_ids = _save_target_connection_list(
            self.list_targets, self.dashboard, self.slicer_cfg.id
        )
        if self._panes_data and self.slicer_cfg.layout_w < 360:
            self.slicer_cfg.layout_w = max(420, 210 * len(self._panes_data))
        if self._panes_data and self.slicer_cfg.layout_h < 220:
            self.slicer_cfg.layout_h = 240
        elif self.slicer_cfg.slicer_type == "category" and self.slicer_cfg.display_mode == "list" and self.slicer_cfg.layout_h < 200:
            self.slicer_cfg.layout_h = 220
        elif self.slicer_cfg.slicer_type in ("numeric_range", "date_range") and self.slicer_cfg.layout_h < 120:
            self.slicer_cfg.layout_h = 125
        self.accept()


class WidgetEditorDialog(QDialog):
    """
    Modern Widget Configurator with visual tile selector (Map View, Summary Card,
    Charts, Data Table), EST/ENG localized fields, conservation unit presets,
    and lazy WFS DescribeFeatureType schema discovery.
    """

    WIDGET_TILES: List[Tuple[str, str, str]] = [
        ("map", "🗺️", "wtype_map"),
        ("kpi", "🌿", "wtype_summary"),
        ("expression", "fx", "wtype_expression"),
        ("bar", "📊", "wtype_bar"),
        ("pie", "🥧", "wtype_pie"),
        ("line", "📈", "wtype_line"),
        ("scatter", "🔵", "wtype_scatter"),
        ("table", "📋", "wtype_table"),
        ("image", "🖼️", "wtype_image"),
    ]

    def __init__(
        self,
        widget_cfg: WidgetConfig,
        available_layers: List[str],
        layer_fields_map: Dict[str, List[str]],
        lang: str = "et",
        catalog_manager: Optional[LocalCatalogManager] = None,
        dashboard: Optional[DashboardConfig] = None,
        records_by_layer: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        persistence: Any = None,
        filter_bus: Any = None,
        on_hydrate_layers: Optional[Callable[[List[str]], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.widget_cfg = widget_cfg
        self.available_layers = list(available_layers)
        self.layer_fields_map = layer_fields_map
        self.lang = lang
        self.catalog_manager = catalog_manager
        self.dashboard = dashboard
        self.records_by_layer = records_by_layer or {}
        self.persistence = persistence
        self.filter_bus = filter_bus
        self.on_hydrate_layers = on_hydrate_layers
        self._selected_type = widget_cfg.widget_type or "bar"
        self._selected_color = widget_cfg.primary_color or "#34d399"
        self._expression_blocks: List[Dict[str, Any]] = copy.deepcopy(list(getattr(widget_cfg, "expression_blocks", None) or []))
        self._expression_color_mode: str = str(getattr(widget_cfg, "expression_color_mode", "fixed") or "fixed")
        self._expression_threshold_ok = getattr(widget_cfg, "expression_threshold_ok", None)
        self._expression_threshold_warn = getattr(widget_cfg, "expression_threshold_warn", None)
        self._expression_rules: List[Dict[str, Any]] = copy.deepcopy(list(getattr(widget_cfg, "expression_rules", None) or []))
        self._expr_blocks_source_expr: str = str(getattr(widget_cfg, "expression", "") or "").strip()
        self._field_aliases: Dict[str, str] = {
            str(k): str(v)
            for k, v in (getattr(widget_cfg, "field_aliases", None) or {}).items()
            if str(v or "").strip()
        }

        self.setWindowTitle(tr("dlg_widget_title", lang))
        _apply_laptop_friendly_bounds(self, 680, 620, min_w=480, min_h=400)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 14, 16, 14)
        root.setSpacing(12)

        # 1. Visual Widget Type Selector Tiles
        sec_type_lbl = QLabel(f"<b>{tr('sec_widget_type', lang)}</b>")
        root.addWidget(sec_type_lbl)

        tile_frame = QFrame()
        tile_grid = QGridLayout(tile_frame)
        tile_grid.setContentsMargins(0, 0, 0, 0)
        tile_grid.setSpacing(8)
        self._type_group = QButtonGroup(self)
        self._type_group.setExclusive(True)
        self._tile_buttons: Dict[str, QPushButton] = {}

        for idx, (wtype, icon_txt, i18n_key) in enumerate(self.WIDGET_TILES):
            btn = QPushButton(f"{icon_txt}\n{tr(i18n_key, lang)}")
            btn.setProperty("btnRole", "tile")
            btn.setCheckable(True)
            btn.setMinimumHeight(60)
            btn.setChecked(wtype == self._selected_type)
            btn.clicked.connect(lambda _chk, wt=wtype: self._on_type_selected(wt))
            self._type_group.addButton(btn)
            self._tile_buttons[wtype] = btn
            tile_grid.addWidget(btn, idx // 5, idx % 5)
        root.addWidget(tile_frame)

        # 2. Scrollable Properties Container
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_inner = QWidget()
        props_layout = QVBoxLayout(scroll_inner)
        props_layout.setContentsMargins(2, 4, 6, 4)
        props_layout.setSpacing(10)

        # General Group
        self.grp_general = QGroupBox(tr("sec_widget_props", lang))
        g_form = QFormLayout(self.grp_general)
        g_form.setSpacing(8)

        self._title_user_edited = bool(getattr(widget_cfg, "title_custom", False)) or bool(
            widget_cfg.title and widget_cfg.title not in ("Uus vidin", tr("btn_add_widget", lang))
        )
        self._overlays_custom_ordered = bool(getattr(widget_cfg, "map_layers_custom_order", False))

        self.ed_title_et = QLineEdit(widget_cfg.title or "")
        self.ed_title_et.setPlaceholderText(
            "nt. Kaitstavate elupaikade pindala" if lang == "et" else "e.g. Protected habitat area"
        )
        _te_sig = getattr(self.ed_title_et, "textEdited", None)
        if _te_sig is not None and hasattr(_te_sig, "connect"):
            _te_sig.connect(lambda _t: setattr(self, "_title_user_edited", True))
        self.ed_title_en = QLineEdit(widget_cfg.title_en or "")

        # Auto-title & clickable concise suggestion chips (#11)
        sug_widget = QWidget()
        self._w_sug_layout = QHBoxLayout(sug_widget)
        self._w_sug_layout.setContentsMargins(0, 0, 0, 0)
        self._w_sug_layout.setSpacing(4)

        self.cb_page = QComboBox()
        self.cb_drill_page = QComboBox()
        self.cb_drill_page.addItem("—" if lang == "et" else "(None)", "")
        pages_list = list(getattr(dashboard, "pages", []) or []) if dashboard else []
        if not pages_list:
            pages_list = [DashboardPageConfig()]
        for pg in pages_list:
            pg_lbl = pg.title_en if (lang == "en" and pg.title_en) else pg.title
            self.cb_page.addItem(f"{pg.icon} {pg_lbl}", pg.id)
            self.cb_drill_page.addItem(f"↪ {pg.icon} {pg_lbl}", pg.id)
        idx_wpg = self.cb_page.findData(getattr(widget_cfg, "page_id", "page_1") or "page_1")
        if idx_wpg >= 0:
            self.cb_page.setCurrentIndex(idx_wpg)
        idx_dr = self.cb_drill_page.findData(getattr(widget_cfg, "drill_to_page_id", "") or "")
        if idx_dr >= 0:
            self.cb_drill_page.setCurrentIndex(idx_dr)

        self.cb_widget_border = QComboBox()
        for bs_key, bs_lbl in (
            ("default", "Vaikimisi" if lang == "et" else "Default"),
            ("subtle", "Peen (Subtle)" if lang == "et" else "Subtle"),
            ("accent", "Esiletõstetud (Accent)" if lang == "et" else "Accent"),
            ("none", "Ilma piirjooneta" if lang == "et" else "Borderless"),
        ):
            self.cb_widget_border.addItem(bs_lbl, bs_key)
        idx_wbs = self.cb_widget_border.findData(getattr(widget_cfg, "border_style", "default") or "default")
        if idx_wbs >= 0:
            self.cb_widget_border.setCurrentIndex(idx_wbs)

        layer_row = QHBoxLayout()
        self.cb_layer = QComboBox()
        self.cb_layer.setEditable(True)
        merged_layers: List[str] = []
        for lyr in self.available_layers:
            if lyr and lyr not in merged_layers:
                merged_layers.append(lyr)
        if self.dashboard:
            for ds in self.dashboard.data_sources:
                if ds.name and ds.name not in merged_layers:
                    merged_layers.append(ds.name)
        for lyr in merged_layers:
            self.cb_layer.addItem(lyr)
        if widget_cfg.layer_name and self.cb_layer.findText(widget_cfg.layer_name) < 0:
            self.cb_layer.addItem(widget_cfg.layer_name)
        if widget_cfg.layer_name:
            self.cb_layer.setCurrentText(widget_cfg.layer_name)

        self.btn_inspect = QPushButton("🔍 " + ("Väljad" if lang == "et" else "Fields"))
        self.btn_inspect.setToolTip(
            "Päri kihi skeem (WFS DescribeFeatureType) ilma andmeid alla laadimata"
            if lang == "et"
            else "Inspect field schema via WFS DescribeFeatureType without loading geometries"
        )
        self.btn_inspect.clicked.connect(lambda: self._populate_fields(allow_network=True))
        layer_row.addWidget(self.cb_layer, 1)
        layer_row.addWidget(self.btn_inspect)

        g_form.addRow(tr("lbl_w_title_et", lang), self.ed_title_et)
        g_form.addRow(tr("lbl_title_suggestions", lang), sug_widget)
        g_form.addRow(tr("lbl_w_title_en", lang), self.ed_title_en)
        self.lbl_layer_row = QLabel(tr("lbl_w_layer", lang))
        g_form.addRow(self.lbl_layer_row, layer_row)
        g_form.addRow(tr("lbl_page_assign", lang), self.cb_page)
        g_form.addRow(tr("drill_to_page", lang), self.cb_drill_page)
        g_form.addRow(tr("widget_border_style_label", lang), self.cb_widget_border)
        props_layout.addWidget(self.grp_general)

        # Map Settings Group (shown when wtype == "map")
        self.grp_map = QGroupBox(tr("wtype_map", lang))
        m_form = QFormLayout(self.grp_map)
        self.cb_basemap = QComboBox()
        for bm_id, bm_lbl, _url, _fmt in MAAAMET_BASEMAPS:
            self.cb_basemap.addItem(bm_lbl, bm_id)
        idx_bm = self.cb_basemap.findData(widget_cfg.map_basemap or "MA-HALLKAART")
        if idx_bm >= 0:
            self.cb_basemap.setCurrentIndex(idx_bm)

        self.list_overlays = DragFieldListWidget(
            role_mode="layer_order",
            lang=lang,
            on_order_changed=lambda: setattr(self, "_overlays_custom_ordered", True),
        )
        self.list_overlays.setMinimumHeight(130)
        self.list_overlays.setMaximumHeight(220)
        ordered_existing = [x for x in (widget_cfg.map_layers or []) if x]
        existing_overlays = set(ordered_existing)
        overlay_candidates: List[str] = list(ordered_existing)
        for name in merged_layers:
            if name and name not in overlay_candidates:
                overlay_candidates.append(name)
        if self.catalog_manager:
            for srv in self.catalog_manager.get_servers():
                if (srv.get("service_type") or srv.get("type")) == "wfs":
                    for lyr in srv.get("layers", [])[:35]:
                        name = lyr.get("name", "")
                        if name and name not in overlay_candidates:
                            overlay_candidates.append(name)
        role_u = qt_enum(Qt, "ItemDataRole", "UserRole")
        styles_map = getattr(widget_cfg, "map_layer_styles", {}) or {}
        for name in overlay_candidates:
            it = QListWidgetItem(name)
            it.setData(role_u, name)
            it.setFlags(it.flags() | qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable"))
            st_vis = (styles_map.get(name, {}) or {}).get("visible") if isinstance(styles_map.get(name), dict) else None
            if st_vis is False:
                checked = False
            elif st_vis is True:
                checked = True
            else:
                explicit_target = existing_overlays or ({widget_cfg.layer_name} if widget_cfg.layer_name else set())
                checked = (name in explicit_target) if explicit_target else (name in self.available_layers)
            it.setCheckState(
                qt_enum(Qt, "CheckState", "Checked" if checked else "Unchecked")
            )
            self.list_overlays.addItem(it)

        m_form.addRow(tr("lbl_map_basemap", lang), self.cb_basemap)
        ov_wrap = QWidget()
        ov_v = QVBoxLayout(ov_wrap)
        ov_v.setContentsMargins(0, 0, 0, 0)
        ov_v.setSpacing(4)
        ov_btns = QHBoxLayout()
        ov_hint = QLabel(tr("map_layers_hint", lang))
        ov_hint.setWordWrap(True)
        ov_hint.setStyleSheet("font-size: 10px; color: #94a3b8;")
        btn_ov_up = QPushButton(tr("btn_move_up", lang))
        btn_ov_up.clicked.connect(lambda: (setattr(self, "_overlays_custom_ordered", True), self.list_overlays.move_selected(-1)))
        btn_ov_dn = QPushButton(tr("btn_move_down", lang))
        btn_ov_dn.clicked.connect(lambda: (setattr(self, "_overlays_custom_ordered", True), self.list_overlays.move_selected(1)))
        self.btn_map_style_legend = QPushButton(tr("btn_map_style_legend", lang))
        self.btn_map_style_legend.clicked.connect(self._open_map_style_legend_dialog)
        ov_btns.addWidget(ov_hint, 1)
        ov_btns.addWidget(btn_ov_up)
        ov_btns.addWidget(btn_ov_dn)
        ov_btns.addWidget(self.btn_map_style_legend)
        ov_v.addLayout(ov_btns)
        ov_v.addWidget(self.list_overlays)
        m_form.addRow(tr("map_layers_title", lang), ov_wrap)

        scroll_row = QHBoxLayout()
        scroll_row.setSpacing(6)
        lbl_prec = QLabel(tr("scroll_precise", lang))
        lbl_prec.setProperty("role", "mutedTiny")
        self.sl_map_scroll_sens = QSlider(qt_enum(Qt, "Orientation", "Horizontal"))
        self.sl_map_scroll_sens.setRange(1, 100)
        init_sens = max(1, min(100, int(getattr(widget_cfg, "map_scroll_sensitivity", 35) or 35)))
        self.sl_map_scroll_sens.setValue(init_sens)
        self.sl_map_scroll_sens.setToolTip(tr("tip_map_scroll_smoothness", lang))
        lbl_fast = QLabel(tr("scroll_fast", lang))
        lbl_fast.setProperty("role", "mutedTiny")
        self.lbl_map_scroll_val = QLabel(f"{init_sens}%")
        self.lbl_map_scroll_val.setMinimumWidth(36)
        self.sl_map_scroll_sens.valueChanged.connect(
            lambda val: self.lbl_map_scroll_val.setText(f"{int(val)}%")
        )
        scroll_row.addWidget(lbl_prec)
        scroll_row.addWidget(self.sl_map_scroll_sens, 1)
        scroll_row.addWidget(lbl_fast)
        scroll_row.addWidget(self.lbl_map_scroll_val)
        m_form.addRow(tr("lbl_map_scroll_smoothness", lang), scroll_row)

        props_layout.addWidget(self.grp_map)

        # Data & Aggregation Group (shown for kpi, bar, pie, line, scatter)
        self.grp_data = QGroupBox(
            "Andmeväljad ja arvutus" if lang == "et" else "Data Fields & Aggregation"
        )
        d_form = QFormLayout(self.grp_data)

        self.lbl_cat = QLabel(tr("lbl_w_cat_field", lang))
        self.cb_category = QComboBox()
        self.cb_category.setEditable(True)

        self.lbl_val = QLabel(tr("lbl_w_val_field", lang))
        self.cb_value = QComboBox()
        self.cb_value.setEditable(True)

        self.cb_agg = QComboBox()
        agg_labels = {
            "sum": tr("agg_sum", lang),
            "count": tr("agg_count", lang),
            "distinct_count": tr("agg_distinct", lang),
            "avg": tr("agg_avg", lang),
            "min": tr("agg_min", lang),
            "max": tr("agg_max", lang),
            "median": tr("agg_median", lang),
        }
        for agg_key, agg_lbl in agg_labels.items():
            self.cb_agg.addItem(agg_lbl, agg_key)
        idx_agg = self.cb_agg.findData(widget_cfg.aggregation or "sum")
        if idx_agg >= 0:
            self.cb_agg.setCurrentIndex(idx_agg)

        self.lbl_series = QLabel(tr("lbl_chart_series_field", lang))
        self.cb_series = QComboBox()
        self.cb_series.setEditable(True)

        self.sp_decimals = QSpinBox()
        self.sp_decimals.setRange(0, 4)
        self.sp_decimals.setValue(int(widget_cfg.decimals if widget_cfg.decimals is not None else 1))

        self.lbl_agg = QLabel(tr("lbl_w_agg", lang))
        d_form.addRow(self.lbl_cat, self.cb_category)
        d_form.addRow(self.lbl_val, self.cb_value)
        d_form.addRow(self.lbl_series, self.cb_series)
        d_form.addRow(self.lbl_agg, self.cb_agg)
        d_form.addRow("Komakohad" if lang == "et" else "Decimals", self.sp_decimals)
        props_layout.addWidget(self.grp_data)

        # Summary Card ("kpi") Formatting Group (no corporate KPI wording)
        self.grp_summary = QGroupBox(tr("wtype_summary", lang))
        s_form = QFormLayout(self.grp_summary)
        self.ed_prefix = QLineEdit(widget_cfg.prefix or "")
        self.ed_prefix.setPlaceholderText("valikuline eesliide")

        sfx_row = QHBoxLayout()
        self.ed_suffix = QLineEdit(widget_cfg.suffix or "")
        self.ed_suffix.setPlaceholderText("nt.  ha,  tk,  €")
        sfx_row.addWidget(self.ed_suffix, 1)
        for unit in (" ha", " tk", " €", " %"):
            ubtn = QPushButton(unit.strip())
            ubtn.setMaximumWidth(42)
            ubtn.clicked.connect(lambda _c, u=unit: self.ed_suffix.setText(u))
            sfx_row.addWidget(ubtn)

        self.ed_target = QLineEdit("" if widget_cfg.target_value is None else str(widget_cfg.target_value))
        self.ed_target.setPlaceholderText(
            "nt. 1500 (valikuline sihttase)" if lang == "et" else "e.g. 1500 (optional target)"
        )

        s_form.addRow(tr("lbl_w_prefix", lang), self.ed_prefix)
        s_form.addRow(tr("lbl_w_suffix", lang), sfx_row)
        s_form.addRow(tr("lbl_w_target", lang), self.ed_target)
        props_layout.addWidget(self.grp_summary)

        # Chart Options Group
        self.grp_chart = QGroupBox(
            "Graafiku välimus" if lang == "et" else "Chart Appearance"
        )
        c_form = QFormLayout(self.grp_chart)
        self.chk_horizontal = QCheckBox(tr("lbl_w_horizontal", lang))
        self.chk_horizontal.setChecked(widget_cfg.horizontal)
        self.chk_donut = QCheckBox(tr("lbl_w_donut", lang))
        self.chk_donut.setChecked(widget_cfg.donut)
        self.lbl_stack_mode = QLabel(tr("lbl_chart_stack_mode", lang))
        self.cb_stack_mode = QComboBox()
        self.cb_stack_mode.addItem(tr("stack_group", lang), "group")
        self.cb_stack_mode.addItem(tr("stack_stack", lang), "stack")
        self.cb_stack_mode.addItem(tr("stack_percent", lang), "percent")
        idx_sm = self.cb_stack_mode.findData(getattr(widget_cfg, "chart_stack_mode", "group") or "group")
        if idx_sm >= 0:
            self.cb_stack_mode.setCurrentIndex(idx_sm)
        self.lbl_sort_by = QLabel(tr("lbl_chart_sort", lang))
        self.cb_sort_by = QComboBox()
        self.cb_sort_by.addItem(tr("sort_value_desc", lang), "value_desc")
        self.cb_sort_by.addItem(tr("sort_value_asc", lang), "value_asc")
        self.cb_sort_by.addItem(tr("sort_category_asc", lang), "category_asc")
        idx_sb = self.cb_sort_by.findData(getattr(widget_cfg, "sort_by", "value_desc") or "value_desc")
        if idx_sb >= 0:
            self.cb_sort_by.setCurrentIndex(idx_sb)
        self.lbl_top_n = QLabel(tr("lbl_chart_top_n", lang))
        self.sp_top_n = QSpinBox()
        self.sp_top_n.setRange(1, 100)
        self.sp_top_n.setValue(max(1, int(getattr(widget_cfg, "top_n", 15) or 15)))
        self.cb_palette = QComboBox()
        for pal_key in ("single", "emerald", "forest", "meadow", "ocean", "amber", "earth", "rose", "corporate"):
            self.cb_palette.addItem(tr(f"palette_{pal_key}", lang), pal_key)
        init_pal = str(getattr(widget_cfg, "color_palette", "") or "emerald").strip().lower()
        idx_pal = self.cb_palette.findData(init_pal)
        if idx_pal < 0:
            idx_pal = self.cb_palette.findData("emerald")
        if idx_pal >= 0:
            self.cb_palette.setCurrentIndex(idx_pal)

        self._palette_swatches_row = QWidget()
        sw_lay = QHBoxLayout(self._palette_swatches_row)
        sw_lay.setContentsMargins(0, 2, 0, 2)
        sw_lay.setSpacing(4)
        self._palette_swatch_labels: List[QLabel] = []
        for _ in range(6):
            sw = QLabel("")
            sw.setFixedSize(22, 14)
            sw_lay.addWidget(sw)
            self._palette_swatch_labels.append(sw)
        sw_lay.addStretch()

        self.lbl_chart_color_hint = QLabel(tr("lbl_chart_color_hint", lang))
        self.lbl_chart_color_hint.setWordWrap(True)
        self.lbl_chart_color_hint.setStyleSheet("font-size: 10px; color: #94a3b8;")

        c_form.addRow("", self.chk_horizontal)
        c_form.addRow("", self.chk_donut)
        c_form.addRow(self.lbl_stack_mode, self.cb_stack_mode)
        c_form.addRow(self.lbl_sort_by, self.cb_sort_by)
        c_form.addRow(self.lbl_top_n, self.sp_top_n)
        c_form.addRow(tr("lbl_chart_color_scheme", lang), self.cb_palette)
        c_form.addRow("", self._palette_swatches_row)
        c_form.addRow("", self.lbl_chart_color_hint)
        props_layout.addWidget(self.grp_chart)

        # QGIS-Style UI Expression Widget Builder Group
        self.grp_expression = QGroupBox(tr("sec_expr_builder", lang))
        ex_v = QVBoxLayout(self.grp_expression)
        ex_v.setSpacing(6)

        lego_bar = QHBoxLayout()
        lego_bar.setSpacing(8)
        self.btn_open_lego_designer = QPushButton(tr("btn_open_lego_designer", lang))
        self.btn_open_lego_designer.setProperty("btnRole", "primary")
        self.btn_open_lego_designer.clicked.connect(self._open_lego_designer)
        self._lbl_lego_hint = QLabel(
            "Ehita avaldis lohistades plokke kõigist kihtidest, Exceli tabelitest ja vidinatest."
            if lang == "et"
            else "Build expressions by dragging blocks across all layers, tables, and widgets."
        )
        self._lbl_lego_hint.setWordWrap(True)
        self._lbl_lego_hint.setStyleSheet("font-size: 11px; color: #94a3b8;")
        lego_bar.addWidget(self.btn_open_lego_designer)
        lego_bar.addWidget(self._lbl_lego_hint, 1)
        ex_v.addLayout(lego_bar)

        # Quick template chips
        tpl_row = QHBoxLayout()
        tpl_row.setSpacing(4)
        tpl_lbl = QLabel(f"<b>{tr('lbl_expr_templates', lang)}</b>")
        tpl_row.addWidget(tpl_lbl)
        for tpl in EXPRESSION_TEMPLATES:
            tbtn = QPushButton(tpl["title_en"] if lang == "en" else tpl["title_et"])
            tbtn.setProperty("btnRole", "chip")
            tbtn.setToolTip(tpl["desc_en"] if lang == "en" else tpl["desc_et"])
            tbtn.clicked.connect(lambda _c=False, t=tpl: self._apply_expr_template(t))
            tpl_row.addWidget(tbtn)
        tpl_row.addStretch()
        ex_v.addLayout(tpl_row)

        ex_v.addWidget(QLabel(f"<b>{tr('lbl_expr_main', lang)}</b>"))
        init_expr = str(getattr(widget_cfg, "expression", "") or "").strip() or 'sum($area)'
        self.ed_expr = QPlainTextEdit(init_expr)
        if hasattr(self.ed_expr, "setMaximumHeight"):
            self.ed_expr.setMaximumHeight(74)
        if hasattr(self.ed_expr, "setPlaceholderText"):
            self.ed_expr.setPlaceholderText('sum("area_ha", "pohityyp" = \'7230\')')
        ex_v.addWidget(self.ed_expr)

        # Live preview banner
        self.lbl_expr_preview = QLabel("")
        self.lbl_expr_preview.setWordWrap(True)
        self.lbl_expr_preview.setStyleSheet(
            "background: rgba(15, 23, 42, 0.45); border: 1px solid #334155; "
            "border-radius: 6px; padding: 5px 8px; font-size: 12px;"
        )
        ex_v.addWidget(self.lbl_expr_preview)

        # Subtext + Display Style row
        ex_opts_form = QFormLayout()
        ex_opts_form.setSpacing(5)
        self.ed_expr_sub = QLineEdit(str(getattr(widget_cfg, "expression_subtext", "") or ""))
        self.ed_expr_sub.setPlaceholderText(
            "nt. format_number($count, 0) || ' / ' || format_number(@total_count, 0) || ' objekti'"
            if lang == "et"
            else "e.g. format_number($count, 0) || ' of ' || format_number(@total_count, 0)"
        )
        self.cb_expr_display = QComboBox()
        for dk, lk in (
            ("auto", "expr_disp_auto"),
            ("metric", "expr_disp_metric"),
            ("progress", "expr_disp_progress"),
            ("text", "expr_disp_text"),
        ):
            self.cb_expr_display.addItem(tr(lk, lang), dk)
        idx_edisp = self.cb_expr_display.findData(getattr(widget_cfg, "expression_display", "auto") or "auto")
        if idx_edisp >= 0:
            self.cb_expr_display.setCurrentIndex(idx_edisp)
        ex_opts_form.addRow(tr("lbl_expr_subtext", lang), self.ed_expr_sub)
        ex_opts_form.addRow(tr("lbl_expr_display", lang), self.cb_expr_display)
        ex_v.addLayout(ex_opts_form)
        props_layout.addWidget(self.grp_expression)

        # Visual Table & Excel-style Pivot Designer Group
        self.grp_table = QGroupBox(tr("tbl_designer_title", lang))
        t_vbox = QVBoxLayout(self.grp_table)
        t_vbox.setSpacing(8)

        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel(tr("tbl_mode_lbl", lang)))
        self.cb_table_mode = QComboBox()
        self.cb_table_mode.addItem(tr("tbl_mode_pivot", lang), "pivot")
        self.cb_table_mode.addItem(tr("tbl_mode_detail", lang), "detail")
        init_mode = getattr(widget_cfg, "table_mode", "") or (
            "pivot" if (getattr(widget_cfg, "pivot_rows", None) or getattr(widget_cfg, "pivot_values", None)) else "detail"
        )
        idx_tm = self.cb_table_mode.findData(init_mode)
        if idx_tm >= 0:
            self.cb_table_mode.setCurrentIndex(idx_tm)
        self.cb_table_mode.currentIndexChanged.connect(self._on_table_mode_changed)
        mode_row.addWidget(self.cb_table_mode, 1)

        self.chk_tbl_transpose = QCheckBox(tr("tbl_transpose", lang))
        self.chk_tbl_transpose.setChecked(bool(getattr(widget_cfg, "table_transpose", False)))
        self.chk_tbl_totals = QCheckBox(tr("tbl_show_totals", lang))
        self.chk_tbl_totals.setChecked(bool(getattr(widget_cfg, "table_show_totals", True)))
        mode_row.addWidget(self.chk_tbl_transpose)
        mode_row.addWidget(self.chk_tbl_totals)
        self.btn_tbl_aliases = QPushButton(tr("tbl_col_names_btn", lang))
        self.btn_tbl_aliases.clicked.connect(self._open_batch_column_names_dialog)
        mode_row.addWidget(self.btn_tbl_aliases)
        t_vbox.addLayout(mode_row)

        designer_cols = QHBoxLayout()
        designer_cols.setSpacing(10)

        # Left column: Searchable Available Fields (+ virtual Calculate Area & Count)
        avail_col = QVBoxLayout()
        avail_col.setSpacing(4)
        avail_col.addWidget(QLabel(f"<b>{tr('tbl_avail_fields', lang)}</b>"))
        self.ed_tbl_field_search = QLineEdit()
        self.ed_tbl_field_search.setPlaceholderText(tr("ph_slicer_search", lang))
        self.ed_tbl_field_search.textChanged.connect(self._filter_table_available_fields)
        avail_col.addWidget(self.ed_tbl_field_search)
        self.list_tbl_avail = DragFieldListWidget(role_mode="source", lang=lang)
        self.list_tbl_avail.setMinimumHeight(180)
        self.list_tbl_avail.itemDoubleClicked.connect(self._on_avail_field_double_clicked)
        avail_col.addWidget(self.list_tbl_avail, 1)

        lbl_drag_hint = QLabel(tr("tbl_drag_hint", lang))
        lbl_drag_hint.setWordWrap(True)
        lbl_drag_hint.setStyleSheet("font-size: 10px; color: #94a3b8;")
        avail_col.addWidget(lbl_drag_hint)

        btn_quick_area = QPushButton("+ " + tr("tbl_calc_area", lang))
        btn_quick_area.setToolTip(tr("tbl_calc_hint", lang))
        btn_quick_area.clicked.connect(lambda: self._add_calculated_metric(CALC_AREA_FIELD, "sum"))
        avail_col.addWidget(btn_quick_area)
        designer_cols.addLayout(avail_col, 5)

        # Right column: switches between Detail Column Builder & Pivot Zones
        right_col = QVBoxLayout()
        right_col.setSpacing(6)

        # Detail columns sub-panel
        self.tbl_detail_box = QFrame()
        det_lay = QVBoxLayout(self.tbl_detail_box)
        det_lay.setContentsMargins(0, 0, 0, 0)
        det_lay.setSpacing(4)
        det_lay.addWidget(QLabel(f"<b>{tr('tbl_selected_cols', lang)}</b>"))
        det_btns = QHBoxLayout()
        btn_det_add = QPushButton(tr("tbl_add_col", lang))
        btn_det_add.clicked.connect(self._add_selected_detail_col)
        btn_det_rem = QPushButton(tr("tbl_remove_btn", lang))
        btn_det_rem.clicked.connect(lambda: self._remove_list_item(self.list_tbl_cols))
        btn_det_up = QPushButton("↑")
        btn_det_up.setMaximumWidth(34)
        btn_det_up.clicked.connect(lambda: self._move_list_item(self.list_tbl_cols, -1))
        btn_det_dn = QPushButton("↓")
        btn_det_dn.setMaximumWidth(34)
        btn_det_dn.clicked.connect(lambda: self._move_list_item(self.list_tbl_cols, 1))
        btn_det_ren = QPushButton(tr("tbl_rename_col", lang))
        btn_det_ren.clicked.connect(lambda: self._rename_selected_list_field(self.list_tbl_cols))
        det_btns.addWidget(btn_det_add)
        det_btns.addWidget(btn_det_rem)
        det_btns.addWidget(btn_det_up)
        det_btns.addWidget(btn_det_dn)
        det_btns.addWidget(btn_det_ren)
        det_lay.addLayout(det_btns)
        self.list_tbl_cols = DragFieldListWidget(
            role_mode="pivot_zone",
            lang=lang,
            on_field_dropped=self._drop_detail_col,
            context_menu_cb=lambda it, pos: self._on_table_field_context_menu(self.list_tbl_cols, it, pos),
        )
        self.list_tbl_cols.setMinimumHeight(165)
        self.list_tbl_cols.itemDoubleClicked.connect(lambda _it: self._remove_list_item(self.list_tbl_cols))
        det_lay.addWidget(self.list_tbl_cols, 1)
        right_col.addWidget(self.tbl_detail_box)

        # Pivot / Cross-tab sub-panel
        self.tbl_pivot_box = QFrame()
        piv_lay = QVBoxLayout(self.tbl_pivot_box)
        piv_lay.setContentsMargins(0, 0, 0, 0)
        piv_lay.setSpacing(6)

        # Spatial Pivot Intersection Option (cross-layer ha / overlay)
        spatial_row = QHBoxLayout()
        spatial_row.setSpacing(6)
        self.chk_spatial_pivot = QCheckBox(tr("spatial_pivot_enable", lang))
        self.chk_spatial_pivot.setToolTip(tr("spatial_pivot_tip", lang))
        init_sp_join = (getattr(widget_cfg, "spatial_join_layer", "") or "").strip()
        self.chk_spatial_pivot.setChecked(bool(init_sp_join))
        self.cb_spatial_layer = QComboBox()
        self.cb_spatial_layer.setToolTip(tr("spatial_pivot_tip", lang))
        for idx_l in range(self.cb_layer.count()):
            ln = self.cb_layer.itemText(idx_l).strip()
            if ln and ln != "*":
                self.cb_spatial_layer.addItem(ln, ln)
        if init_sp_join:
            if self.cb_spatial_layer.findText(init_sp_join) < 0:
                self.cb_spatial_layer.addItem(init_sp_join, init_sp_join)
            self.cb_spatial_layer.setCurrentText(init_sp_join)
        self.cb_spatial_layer.setEnabled(bool(init_sp_join))
        self.chk_spatial_pivot.toggled.connect(self._on_spatial_pivot_toggled)
        self.cb_spatial_layer.currentTextChanged.connect(lambda _txt: self._populate_fields(allow_network=False))
        spatial_row.addWidget(self.chk_spatial_pivot)
        spatial_row.addWidget(self.cb_spatial_layer, 1)
        piv_lay.addLayout(spatial_row)

        # Calculate Bar (Sum, Count, Distinct, Avg, Min, Max, Median)
        calc_bar = QHBoxLayout()
        calc_bar.setSpacing(4)
        calc_lbl = QLabel(f"<b>{tr('tbl_calculate_btn', lang)}:</b>")
        self.cb_pivot_agg = QComboBox()
        for agg_key, agg_lbl in agg_labels.items():
            self.cb_pivot_agg.addItem(agg_lbl, agg_key)
        btn_add_calc = QPushButton("+ " + tr("tbl_pivot_vals", lang))
        btn_add_calc.setProperty("btnRole", "primary")
        btn_add_calc.clicked.connect(self._add_selected_pivot_value)
        calc_bar.addWidget(calc_lbl)
        calc_bar.addWidget(self.cb_pivot_agg, 1)
        calc_bar.addWidget(btn_add_calc)
        piv_lay.addLayout(calc_bar)

        piv_grid = QGridLayout()
        piv_grid.setSpacing(6)

        # Rows box
        btn_add_row = QPushButton(tr("tbl_add_row", lang))
        btn_add_row.clicked.connect(self._add_selected_pivot_row)
        btn_rem_row = QPushButton("−")
        btn_rem_row.setMaximumWidth(30)
        btn_rem_row.clicked.connect(lambda: self._remove_list_item(self.list_pivot_rows))
        row_hdr = QHBoxLayout()
        row_hdr.addWidget(QLabel(f"<b>{tr('tbl_pivot_rows', lang)}</b>"), 1)
        row_hdr.addWidget(btn_add_row)
        row_hdr.addWidget(btn_rem_row)
        piv_grid.addLayout(row_hdr, 0, 0)
        self.list_pivot_rows = DragFieldListWidget(
            role_mode="pivot_zone",
            lang=lang,
            on_field_dropped=lambda f, _l, r: self._drop_pivot_dim(self.list_pivot_rows, f, r),
            context_menu_cb=lambda it, pos: self._on_table_field_context_menu(self.list_pivot_rows, it, pos),
        )
        self.list_pivot_rows.setMaximumHeight(92)
        self.list_pivot_rows.itemDoubleClicked.connect(lambda _it: self._remove_list_item(self.list_pivot_rows))
        piv_grid.addWidget(self.list_pivot_rows, 1, 0)

        # Columns box
        btn_add_pcol = QPushButton(tr("tbl_add_col_pivot", lang))
        btn_add_pcol.clicked.connect(self._add_selected_pivot_col)
        btn_rem_pcol = QPushButton("−")
        btn_rem_pcol.setMaximumWidth(30)
        btn_rem_pcol.clicked.connect(lambda: self._remove_list_item(self.list_pivot_cols))
        pcol_hdr = QHBoxLayout()
        pcol_hdr.addWidget(QLabel(f"<b>{tr('tbl_pivot_cols', lang)}</b>"), 1)
        pcol_hdr.addWidget(btn_add_pcol)
        pcol_hdr.addWidget(btn_rem_pcol)
        piv_grid.addLayout(pcol_hdr, 0, 1)
        self.list_pivot_cols = DragFieldListWidget(
            role_mode="pivot_zone",
            lang=lang,
            on_field_dropped=lambda f, _l, r: self._drop_pivot_dim(self.list_pivot_cols, f, r),
            context_menu_cb=lambda it, pos: self._on_table_field_context_menu(self.list_pivot_cols, it, pos),
        )
        self.list_pivot_cols.setMaximumHeight(92)
        self.list_pivot_cols.itemDoubleClicked.connect(lambda _it: self._remove_list_item(self.list_pivot_cols))
        piv_grid.addWidget(self.list_pivot_cols, 1, 1)

        # Values box
        btn_rem_val = QPushButton("−")
        btn_rem_val.setMaximumWidth(30)
        btn_rem_val.clicked.connect(lambda: self._remove_list_item(self.list_pivot_vals))
        val_hdr = QHBoxLayout()
        val_hdr.addWidget(QLabel(f"<b>{tr('tbl_pivot_vals', lang)}</b>"), 1)
        val_hdr.addWidget(btn_rem_val)
        piv_grid.addLayout(val_hdr, 2, 0, 1, 2)
        self.list_pivot_vals = DragFieldListWidget(
            role_mode="pivot_zone",
            lang=lang,
            on_field_dropped=self._drop_pivot_val,
            context_menu_cb=self._on_pivot_val_context_menu,
        )
        self.list_pivot_vals.setMaximumHeight(92)
        self.list_pivot_vals.itemDoubleClicked.connect(lambda _it: self._remove_list_item(self.list_pivot_vals))
        piv_grid.addWidget(self.list_pivot_vals, 3, 0, 1, 2)

        piv_lay.addLayout(piv_grid)
        right_col.addWidget(self.tbl_pivot_box)
        designer_cols.addLayout(right_col, 7)

        t_vbox.addLayout(designer_cols)
        self._load_initial_table_design()
        self._on_table_mode_changed()
        props_layout.addWidget(self.grp_table)

        # Logo / Picture Widget Group
        self.grp_image = QGroupBox(tr("wtype_image", lang))
        img_form = QFormLayout(self.grp_image)
        img_src_row = QHBoxLayout()
        self.ed_img_source = QLineEdit(str(getattr(widget_cfg, "image_source", "") or ""))
        self.ed_img_source.setPlaceholderText("https://... / C:\\logo.png")
        self.btn_browse_img = QPushButton(tr("btn_browse_img", lang))
        self.btn_browse_img.clicked.connect(self._browse_image_file)
        img_src_row.addWidget(self.ed_img_source, 1)
        img_src_row.addWidget(self.btn_browse_img)
        self._image_data_uri = str(getattr(widget_cfg, "image_data_uri", "") or "")

        self.cb_img_fit = QComboBox()
        self.cb_img_fit.addItem(tr("img_fit_contain", lang), "contain")
        self.cb_img_fit.addItem(tr("img_fit_cover", lang), "cover")
        idx_fit = self.cb_img_fit.findData(getattr(widget_cfg, "image_fit", "contain") or "contain")
        if idx_fit >= 0:
            self.cb_img_fit.setCurrentIndex(idx_fit)

        self.ed_img_caption = QLineEdit(str(getattr(widget_cfg, "image_caption", "") or ""))
        self.ed_img_link = QLineEdit(str(getattr(widget_cfg, "image_link_url", "") or ""))
        self.ed_img_link.setPlaceholderText("https://...")
        self.chk_img_transparent = QCheckBox(tr("lbl_img_transparent", lang))
        self.chk_img_transparent.setChecked(bool(getattr(widget_cfg, "image_transparent_bg", False)))

        img_form.addRow(tr("lbl_img_source", lang), img_src_row)
        img_form.addRow(tr("lbl_img_fit", lang), self.cb_img_fit)
        img_form.addRow(tr("lbl_img_caption", lang), self.ed_img_caption)
        img_form.addRow(tr("lbl_img_link", lang), self.ed_img_link)
        img_form.addRow("", self.chk_img_transparent)
        props_layout.addWidget(self.grp_image)

        # Common Styling Row (Accent color + Cross-filter)
        self.common_box = QFrame()
        common_row = QHBoxLayout(self.common_box)
        common_row.setContentsMargins(4, 4, 4, 4)
        self._common_color_wrap = QWidget()
        cc_lay = QHBoxLayout(self._common_color_wrap)
        cc_lay.setContentsMargins(0, 0, 12, 0)
        cc_lay.setSpacing(6)
        self.btn_color = QPushButton(tr("lbl_w_color", lang))
        self.lbl_color_swatch = QLabel("  ")
        self.lbl_color_swatch.setFixedSize(26, 22)
        self._update_color_swatch()
        self.btn_color.clicked.connect(self._pick_color)
        cc_lay.addWidget(self.btn_color)
        cc_lay.addWidget(self.lbl_color_swatch)

        self.chk_cross = QCheckBox(tr("lbl_w_cross", lang))
        self.chk_cross.setChecked(widget_cfg.enable_cross_filter)

        common_row.addWidget(self._common_color_wrap)
        common_row.addWidget(self.chk_cross, 1)
        props_layout.addWidget(self.common_box)

        lbl_w_conns = QLabel(tr("lbl_linked_targets", lang))
        props_layout.addWidget(lbl_w_conns)
        self.list_targets = QListWidget()
        self.list_targets.setMaximumHeight(110)
        _populate_target_connection_list(
            self.list_targets,
            self.dashboard,
            widget_cfg.id,
            getattr(widget_cfg, "connected_target_ids", []),
            lang=lang,
        )
        props_layout.addWidget(self.list_targets)
        props_layout.addStretch()

        scroll.setWidget(scroll_inner)
        root.addWidget(scroll, 1)

        # Footer Save / Cancel
        footer = QHBoxLayout()
        footer.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", lang))
        btn_cancel.clicked.connect(self.reject)
        btn_save = QPushButton(tr("btn_save", lang))
        btn_save.setProperty("btnRole", "primary")
        btn_save.clicked.connect(self._on_accept)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_save)
        root.addLayout(footer)

        self.cb_layer.currentTextChanged.connect(lambda _txt: self._populate_fields(allow_network=False))
        self.cb_layer.currentTextChanged.connect(lambda _txt: self._refresh_widget_title_suggestions())
        self.cb_layer.currentTextChanged.connect(lambda _txt: self._update_expr_live_preview())
        self.cb_category.currentTextChanged.connect(lambda _txt: self._refresh_widget_title_suggestions())
        self.cb_value.currentTextChanged.connect(lambda _txt: self._refresh_widget_title_suggestions())
        self.cb_series.currentIndexChanged.connect(lambda _i: self._sync_chart_color_controls())
        self.cb_palette.currentIndexChanged.connect(lambda _i: self._sync_chart_color_controls())
        self.cb_agg.currentIndexChanged.connect(lambda _i: self._refresh_widget_title_suggestions())
        if hasattr(self.ed_expr, "textChanged"):
            self.ed_expr.textChanged.connect(self._update_expr_live_preview)
        self.ed_expr_sub.textChanged.connect(lambda _t: self._update_expr_live_preview())
        self.sp_decimals.valueChanged.connect(lambda _v: self._update_expr_live_preview())
        self.ed_prefix.textChanged.connect(lambda _t: self._update_expr_live_preview())
        self.ed_suffix.textChanged.connect(lambda _t: self._update_expr_live_preview())
        self._populate_fields(allow_network=False)
        if widget_cfg.category_field:
            self.cb_category.setCurrentText(widget_cfg.category_field)
        if widget_cfg.value_field:
            if widget_cfg.value_field == CALC_AREA_FIELD:
                idx_calc = self.cb_value.findData(CALC_AREA_FIELD)
                if idx_calc >= 0:
                    self.cb_value.setCurrentIndex(idx_calc)
            else:
                self.cb_value.setCurrentText(widget_cfg.value_field)
        if getattr(widget_cfg, "secondary_field", ""):
            self.cb_series.setCurrentText(widget_cfg.secondary_field)

        self._apply_type_visibility(self._selected_type)
        self._update_expr_live_preview()
        self._refresh_widget_title_suggestions()

    def _update_color_swatch(self) -> None:
        self.lbl_color_swatch.setStyleSheet(
            f"background: {self._selected_color}; border-radius: 5px; border: 1px solid #475569;"
        )

    def _pick_color(self) -> None:
        col = QColorDialog.getColor(QtGui.QColor(self._selected_color), self)
        if col.isValid():
            self._selected_color = col.name()
            self._update_color_swatch()

    def _browse_image_file(self) -> None:
        path, _flt = QFileDialog.getOpenFileName(
            self,
            tr("lbl_img_source", self.lang),
            "",
            "Images (*.png *.jpg *.jpeg *.svg *.webp *.gif *.bmp);;All files (*.*)",
        )
        if not path:
            return
        self.ed_img_source.setText(path)
        try:
            with open(path, "rb") as fh:
                raw = fh.read()
            mime, _enc = mimetypes.guess_type(path)
            if not mime or not mime.startswith("image/"):
                mime = "image/png"
            b64 = base64.b64encode(raw).decode("ascii")
            self._image_data_uri = f"data:{mime};base64,{b64}"
        except Exception:
            pass

    def _on_type_selected(self, wtype: str) -> None:
        self._selected_type = wtype
        self._apply_type_visibility(wtype)
        self._refresh_widget_title_suggestions()

    def _refresh_widget_title_suggestions(self) -> None:
        lay = getattr(self, "_w_sug_layout", None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        suggestions = suggest_widget_titles(
            self._selected_type or "bar",
            layer_name=self.cb_layer.currentText().strip() if hasattr(self, "cb_layer") else "",
            dimension_field=self.cb_category.currentText().strip() if hasattr(self, "cb_category") else "",
            value_field=self._combo_field_value(self.cb_value) if hasattr(self, "cb_value") else "",
            aggregation=str(self.cb_agg.currentData() or "sum") if hasattr(self, "cb_agg") else "sum",
            lang=self.lang,
        )
        if not getattr(self, "_title_user_edited", False) and suggestions:
            self.ed_title_et.setText(suggestions[0])
        for sug in suggestions:
            btn = QPushButton(sug)
            btn.setProperty("btnRole", "chip")
            btn.setStyleSheet("font-size: 10px; padding: 2px 7px;")
            btn.clicked.connect(lambda _c=False, s=sug: (setattr(self, "_title_user_edited", True), self.ed_title_et.setText(s)))
            lay.addWidget(btn)
        lay.addStretch()

    def _sync_chart_color_controls(self) -> None:
        from .widgets import PALETTES

        wtype = self._selected_type or "bar"
        is_chart = wtype in ("bar", "pie", "line", "scatter")
        if not is_chart:
            self._palette_swatches_row.setVisible(False)
            self._common_color_wrap.setVisible(wtype != "image")
            return

        ser_val = self._combo_field_value(self.cb_series)
        if ser_val == tr("series_none", self.lang):
            ser_val = ""
        requires_multi = (wtype == "pie") or (wtype in ("bar", "line") and bool(ser_val))

        cur_pal = str(self.cb_palette.currentData() or "emerald").strip().lower()
        idx_single = self.cb_palette.findData("single")
        if requires_multi and cur_pal == "single":
            idx_em = self.cb_palette.findData("emerald")
            if idx_em >= 0:
                self.cb_palette.blockSignals(True)
                self.cb_palette.setCurrentIndex(idx_em)
                self.cb_palette.blockSignals(False)
                cur_pal = "emerald"

        if idx_single >= 0:
            mdl = self.cb_palette.model()
            if mdl is not None and hasattr(mdl, "item"):
                it_single = mdl.item(idx_single)
                if it_single is not None and hasattr(it_single, "setEnabled"):
                    it_single.setEnabled(not requires_multi)

        is_single = (cur_pal == "single") and not requires_multi
        self._palette_swatches_row.setVisible(not is_single)
        self._common_color_wrap.setVisible(is_single)
        if not is_single:
            cols = PALETTES.get(cur_pal, PALETTES["emerald"])
            for idx_sw, lbl_sw in enumerate(getattr(self, "_palette_swatch_labels", []) or []):
                c_hex = cols[idx_sw % len(cols)]
                lbl_sw.setStyleSheet(f"background: {c_hex}; border-radius: 3px; border: 1px solid #475569;")
            self._selected_color = cols[0]
            self._update_color_swatch()

    def _apply_expr_template(self, tpl: Dict[str, str]) -> None:
        if hasattr(self.ed_expr, "setPlainText"):
            self.ed_expr.setPlainText(tpl.get("expr", ""))
        else:
            self.ed_expr.setText(tpl.get("expr", ""))
        if tpl.get("subtext"):
            self.ed_expr_sub.setText(tpl["subtext"])
        self._update_expr_live_preview()

    @staticmethod
    def _parse_opt_float(raw: str) -> Optional[float]:
        s = str(raw or "").strip().replace(",", ".")
        if not s:
            return None
        try:
            return float(s)
        except ValueError:
            return None

    def _open_lego_designer(self) -> None:
        from .expression_lego import ExpressionDesignerDialog

        draft = WidgetConfig.from_dict(self.widget_cfg.to_dict())
        draft.widget_type = "expression"
        draft.title = self.ed_title_et.text().strip() or draft.title
        draft.layer_name = self.cb_layer.currentText().strip()
        draft.expression = (
            self.ed_expr.toPlainText().strip() if hasattr(self.ed_expr, "toPlainText") else self.ed_expr.text().strip()
        )
        draft.expression_subtext = self.ed_expr_sub.text().strip()
        draft.expression_display = str(self.cb_expr_display.currentData() or "auto")
        draft.decimals = int(self.sp_decimals.value())
        draft.prefix = self.ed_prefix.text()
        draft.suffix = self.ed_suffix.text()
        draft.target_value = self._parse_opt_float(self.ed_target.text())
        draft.primary_color = self._selected_color
        draft.expression_blocks = copy.deepcopy(self._expression_blocks)
        draft.expression_color_mode = self._expression_color_mode
        draft.expression_threshold_ok = self._expression_threshold_ok
        draft.expression_threshold_warn = self._expression_threshold_warn
        draft.expression_rules = copy.deepcopy(self._expression_rules)

        dash_ctx = self.dashboard if self.dashboard is not None else DashboardConfig(title="")
        dlg = ExpressionDesignerDialog(
            draft,
            dash_ctx,
            persistence=self.persistence,
            filter_bus=self.filter_bus,
            on_hydrate_layers=self.on_hydrate_layers,
            lang=self.lang,
            records_by_layer=self.records_by_layer,
            parent=self,
        )
        if exec_dialog(dlg):
            if draft.title:
                self.ed_title_et.setText(draft.title)
                self._title_user_edited = True
            if draft.layer_name:
                if self.cb_layer.findText(draft.layer_name) < 0:
                    self.cb_layer.addItem(draft.layer_name, draft.layer_name)
                self.cb_layer.setCurrentText(draft.layer_name)
            if hasattr(self.ed_expr, "setPlainText"):
                self.ed_expr.setPlainText(draft.expression or "")
            else:
                self.ed_expr.setText(draft.expression or "")
            self.ed_expr_sub.setText(draft.expression_subtext or "")
            idx_ed = self.cb_expr_display.findData(draft.expression_display or "auto")
            if idx_ed >= 0:
                self.cb_expr_display.setCurrentIndex(idx_ed)
            self.sp_decimals.setValue(int(draft.decimals if draft.decimals is not None else 1))
            self.ed_prefix.setText(draft.prefix or "")
            self.ed_suffix.setText(draft.suffix or "")
            self.ed_target.setText("" if draft.target_value is None else str(draft.target_value))
            self._selected_color = draft.primary_color or self._selected_color
            self._update_color_swatch()
            self._expression_blocks = copy.deepcopy(list(draft.expression_blocks or []))
            self._expression_color_mode = str(draft.expression_color_mode or "fixed")
            self._expression_threshold_ok = draft.expression_threshold_ok
            self._expression_threshold_warn = draft.expression_threshold_warn
            self._expression_rules = copy.deepcopy(list(draft.expression_rules or []))
            self._expr_blocks_source_expr = str(draft.expression or "").strip()
            self._update_expr_live_preview()

    def _update_expr_live_preview(self) -> None:
        if not hasattr(self, "lbl_expr_preview") or (self._selected_type or "bar") != "expression":
            return
        expr_txt = self.ed_expr.toPlainText().strip() if hasattr(self.ed_expr, "toPlainText") else self.ed_expr.text().strip()
        lname = self.cb_layer.currentText().strip()
        recs_map = dict(getattr(self.persistence, "layer_records_cache", {}) or {})
        recs_map.update(self.records_by_layer or {})
        recs = recs_map.get(lname, [])

        def _w_resolver(ref_key: str, mode: str = "value") -> float:
            if self.dashboard is None:
                return 0.0
            return compute_dashboard_widget_ref(ref_key, self.dashboard, recs_map, self.filter_bus, mode=mode, visited={self.widget_cfg.id})

        res = evaluate_dashboard_expression(
            expr_txt or "count()",
            recs,
            all_records_by_layer=recs_map,
            layer_name=lname,
            total_count=len(recs),
            widget_resolver=_w_resolver,
            fallback_agg=str(self.cb_agg.currentData() or "sum"),
            decimals=int(self.sp_decimals.value()),
            prefix=self.ed_prefix.text(),
            suffix=self.ed_suffix.text(),
        )
        if res["ok"]:
            sub_txt = self.ed_expr_sub.text().strip()
            extra = ""
            if sub_txt:
                sr = evaluate_dashboard_expression(
                    sub_txt,
                    recs,
                    all_records_by_layer=recs_map,
                    layer_name=lname,
                    total_count=len(recs),
                    widget_resolver=_w_resolver,
                    decimals=int(self.sp_decimals.value()),
                )
                if sr["ok"]:
                    extra = f"  |  <i>{sr['formatted']}</i>"
            self.lbl_expr_preview.setText(
                f"<span style='color:#34d399;font-weight:700;'>{tr('expr_ok_status', self.lang)}</span> <b>{res['formatted']}</b>{extra}"
            )
        else:
            self.lbl_expr_preview.setText(
                f"<span style='color:#f87171;font-weight:700;'>{tr('expr_err_prefix', self.lang)}</span> {res['error']}"
            )

    def _apply_type_visibility(self, wtype: str) -> None:
        is_map = wtype == "map"
        is_summary = wtype == "kpi"
        is_expr = wtype == "expression"
        is_table = wtype == "table"
        is_image = wtype == "image"
        is_chart = wtype in ("bar", "pie", "line", "scatter")

        self.grp_map.setVisible(is_map)
        self.btn_inspect.setVisible(not is_map and not is_image)
        if hasattr(self, "cb_layer"):
            self.cb_layer.setEnabled(not is_image)
        self.grp_data.setVisible(is_summary or is_expr or is_chart)
        self.lbl_cat.setVisible(is_chart)
        self.cb_category.setVisible(is_chart)
        self.lbl_val.setVisible(is_summary or is_chart)
        self.cb_value.setVisible(is_summary or is_chart)
        show_series = wtype in ("bar", "line")
        self.lbl_series.setVisible(show_series)
        self.cb_series.setVisible(show_series)
        self.lbl_agg.setText(tr("lbl_expr_fallback_agg", self.lang) if is_expr else tr("lbl_w_agg", self.lang))
        self.grp_summary.setVisible(is_summary or is_expr)
        self.grp_chart.setVisible(is_chart)
        self.grp_expression.setVisible(is_expr)
        self.chk_horizontal.setVisible(wtype == "bar")
        self.chk_donut.setVisible(wtype == "pie")
        self.lbl_stack_mode.setVisible(wtype == "bar")
        self.cb_stack_mode.setVisible(wtype == "bar")
        show_sort_top = wtype in ("bar", "pie", "line")
        self.lbl_sort_by.setVisible(show_sort_top)
        self.cb_sort_by.setVisible(show_sort_top)
        self.lbl_top_n.setVisible(show_sort_top)
        self.sp_top_n.setVisible(show_sort_top)
        self.grp_table.setVisible(is_table)
        self.grp_image.setVisible(is_image)
        self.common_box.setVisible(not is_image)
        self.chk_cross.setVisible(not is_expr and not is_summary and not is_image)
        self._sync_chart_color_controls()
        if is_expr:
            self._update_expr_live_preview()

    def _on_table_mode_changed(self) -> None:
        mode = str(self.cb_table_mode.currentData() or "detail")
        is_pivot = mode == "pivot"
        self.tbl_detail_box.setVisible(not is_pivot)
        self.tbl_pivot_box.setVisible(is_pivot)

    def _make_field_item(self, field_name: str, label: Optional[str] = None) -> QListWidgetItem:
        default_lbl = friendly_field_label(field_name, self.lang)
        alias = str(self._field_aliases.get(field_name) or "").strip()
        disp = label or (f"{alias} [{default_lbl}]" if alias else default_lbl)
        it = QListWidgetItem(disp)
        it.setData(qt_enum(Qt, "ItemDataRole", "UserRole"), field_name)
        return it

    def _make_pivot_val_item(self, field_name: str, agg: str, label: Optional[str] = None) -> QListWidgetItem:
        agg_lbl = tr(f"agg_{agg}" if agg != "distinct_count" else "agg_distinct", self.lang)
        short_agg = agg_lbl.split(" (")[0]
        base_lbl = friendly_field_label(field_name, self.lang)
        metric_key = f"{agg}:{field_name}"
        custom_lbl = str(label or self._field_aliases.get(metric_key) or "").strip()
        payload: Dict[str, str] = {"field": field_name, "agg": agg}
        if custom_lbl:
            payload["label"] = custom_lbl
            disp = f"{custom_lbl} [{short_agg}: {base_lbl}]"
        else:
            disp = f"{short_agg}: {base_lbl}"
        it = QListWidgetItem(disp)
        it.setData(qt_enum(Qt, "ItemDataRole", "UserRole"), payload)
        return it

    def _refresh_table_list_item_labels(self) -> None:
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for lw in (self.list_tbl_cols, self.list_pivot_rows, self.list_pivot_cols):
            for i in range(lw.count()):
                it = lw.item(i)
                fname = str(it.data(role) or it.text())
                default_lbl = friendly_field_label(fname, self.lang)
                alias = str(self._field_aliases.get(fname) or "").strip()
                it.setText(f"{alias} [{default_lbl}]" if alias else default_lbl)
        for i in range(self.list_pivot_vals.count()):
            it = self.list_pivot_vals.item(i)
            data = it.data(role)
            if isinstance(data, dict) and data.get("field"):
                fname = str(data["field"])
                agg = str(data.get("agg") or "sum")
                metric_key = f"{agg}:{fname}"
                custom_lbl = str(self._field_aliases.get(metric_key) or data.get("label") or "").strip()
                if custom_lbl:
                    data["label"] = custom_lbl
                else:
                    data.pop("label", None)
                it.setData(role, data)
                agg_lbl = tr(f"agg_{agg}" if agg != "distinct_count" else "agg_distinct", self.lang)
                short_agg = agg_lbl.split(" (")[0]
                base_lbl = friendly_field_label(fname, self.lang)
                it.setText(f"{custom_lbl} [{short_agg}: {base_lbl}]" if custom_lbl else f"{short_agg}: {base_lbl}")

    def rename_table_column(self, alias_key: str, new_label: str) -> None:
        """Set or clear a custom column display name for detail or pivot fields."""
        cleaned = str(new_label or "").strip()
        if cleaned:
            self._field_aliases[alias_key] = cleaned
        else:
            self._field_aliases.pop(alias_key, None)
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        if ":" in alias_key:
            agg_part, fld_part = alias_key.split(":", 1)
            for i in range(self.list_pivot_vals.count()):
                it = self.list_pivot_vals.item(i)
                data = it.data(role)
                if isinstance(data, dict) and str(data.get("field") or "") == fld_part and str(data.get("agg") or "sum") == agg_part:
                    if cleaned:
                        data["label"] = cleaned
                    else:
                        data.pop("label", None)
                    it.setData(role, data)
        self._refresh_table_list_item_labels()

    def _prompt_column_alias(self, alias_key: str, default_lbl: str, current_alias: str = "") -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle(tr("tbl_rename_col_title", self.lang))
        dlg.setStyleSheet(ThemeManager.get_stylesheet())
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(tr("tbl_rename_col_prompt", self.lang, field=default_lbl)))
        ed = QLineEdit(current_alias or default_lbl)
        if hasattr(ed, "selectAll"):
            ed.selectAll()
        lay.addWidget(ed)
        btn_row = QHBoxLayout()
        btn_reset = QPushButton(tr("tbl_rename_col_reset", self.lang))

        def _do_reset() -> None:
            ed.setText("")
            dlg.accept()

        btn_reset.clicked.connect(_do_reset)
        btn_row.addWidget(btn_reset)
        btn_row.addStretch()
        dbb = QDialogButtonBox(
            qt_enum(QDialogButtonBox, "StandardButton", "Ok")
            | qt_enum(QDialogButtonBox, "StandardButton", "Cancel")
        )
        dbb.accepted.connect(dlg.accept)
        dbb.rejected.connect(dlg.reject)
        btn_row.addWidget(dbb)
        lay.addLayout(btn_row)
        if exec_dialog(dlg):
            typed = ed.text().strip()
            self.rename_table_column(alias_key, "" if typed == default_lbl else typed)

    def _rename_selected_list_field(self, lw: QListWidget) -> None:
        it = lw.currentItem() if hasattr(lw, "currentItem") else None
        if it is None:
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        fname = str(it.data(role) or it.text())
        default_lbl = friendly_field_label(fname, self.lang)
        self._prompt_column_alias(fname, default_lbl, str(self._field_aliases.get(fname) or ""))

    def _on_table_field_context_menu(self, lw: QListWidget, item: QListWidgetItem, global_pos: Any) -> None:
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None or item is None:
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        fname = str(item.data(role) or item.text())
        default_lbl = friendly_field_label(fname, self.lang)
        menu = QMenuCls(self)
        act_rename = menu.addAction(tr("ctx_rename_col", self.lang))
        act_reset = menu.addAction(tr("ctx_reset_col", self.lang))
        menu.addSeparator()
        act_rm = menu.addAction(tr("ctx_remove", self.lang))
        chosen = exec_menu(menu, global_pos)
        if chosen == act_rename:
            self._prompt_column_alias(fname, default_lbl, str(self._field_aliases.get(fname) or ""))
        elif chosen == act_reset:
            self.rename_table_column(fname, "")
        elif chosen == act_rm:
            row = lw.row(item)
            if row >= 0:
                lw.takeItem(row)

    def _open_batch_column_names_dialog(self) -> None:
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        entries: List[Tuple[str, str, str]] = []
        mode = str(self.cb_table_mode.currentData() or "detail")
        if mode == "pivot":
            for lw in (self.list_pivot_rows, self.list_pivot_cols):
                for i in range(lw.count()):
                    fname = str(lw.item(i).data(role) or lw.item(i).text())
                    if fname and not any(e[0] == fname for e in entries):
                        entries.append((fname, friendly_field_label(fname, self.lang), str(self._field_aliases.get(fname) or "")))
            for i in range(self.list_pivot_vals.count()):
                data = self.list_pivot_vals.item(i).data(role)
                if isinstance(data, dict) and data.get("field"):
                    fname = str(data["field"])
                    agg = str(data.get("agg") or "sum")
                    mkey = f"{agg}:{fname}"
                    agg_lbl = tr(f"agg_{agg}" if agg != "distinct_count" else "agg_distinct", self.lang).split(" (")[0]
                    def_lbl = f"{agg_lbl}: {friendly_field_label(fname, self.lang)}"
                    cur = str(self._field_aliases.get(mkey) or data.get("label") or "")
                    entries.append((mkey, def_lbl, cur))
        else:
            for i in range(self.list_tbl_cols.count()):
                fname = str(self.list_tbl_cols.item(i).data(role) or self.list_tbl_cols.item(i).text())
                if fname:
                    entries.append((fname, friendly_field_label(fname, self.lang), str(self._field_aliases.get(fname) or "")))
            if not entries:
                for i in range(self.list_tbl_avail.count()):
                    fname = str(self.list_tbl_avail.item(i).data(role) or self.list_tbl_avail.item(i).text())
                    if fname and not fname.startswith("__calc_"):
                        entries.append((fname, friendly_field_label(fname, self.lang), str(self._field_aliases.get(fname) or "")))

        dlg = QDialog(self)
        dlg.setWindowTitle(tr("tbl_rename_col_title", self.lang))
        dlg.setMinimumWidth(460)
        dlg.setStyleSheet(ThemeManager.get_stylesheet())
        lay = QVBoxLayout(dlg)
        tbl = QTableWidget(len(entries), 2)
        if hasattr(tbl, "setHorizontalHeaderLabels"):
            tbl.setHorizontalHeaderLabels([tr("tbl_col_orig", self.lang), tr("tbl_col_custom", self.lang)])
        if hasattr(tbl, "horizontalHeader") and hasattr(tbl.horizontalHeader(), "setStretchLastSection"):
            tbl.horizontalHeader().setStretchLastSection(True)
        readonly_flag = qt_enum(Qt, "ItemFlag", "ItemIsEnabled") | qt_enum(Qt, "ItemFlag", "ItemIsSelectable")
        for r_idx, (akey, def_lbl, cur_alias) in enumerate(entries):
            orig_item = QTableWidgetItem(def_lbl)
            if hasattr(orig_item, "setFlags") and readonly_flag is not None:
                orig_item.setFlags(readonly_flag)
            if hasattr(orig_item, "setData"):
                orig_item.setData(role, akey)
            alias_item = QTableWidgetItem(cur_alias)
            tbl.setItem(r_idx, 0, orig_item)
            tbl.setItem(r_idx, 1, alias_item)
        lay.addWidget(tbl)
        dbb = QDialogButtonBox(
            qt_enum(QDialogButtonBox, "StandardButton", "Ok")
            | qt_enum(QDialogButtonBox, "StandardButton", "Cancel")
        )
        dbb.accepted.connect(dlg.accept)
        dbb.rejected.connect(dlg.reject)
        lay.addWidget(dbb)
        if exec_dialog(dlg):
            for r_idx, (akey, def_lbl, _) in enumerate(entries):
                ed_item = tbl.item(r_idx, 1)
                val = ed_item.text().strip() if ed_item is not None and hasattr(ed_item, "text") else ""
                self.rename_table_column(akey, "" if val == def_lbl else val)

    def _load_initial_table_design(self) -> None:
        self.list_tbl_cols.clear()
        for col in (self.widget_cfg.table_columns or []):
            self.list_tbl_cols.addItem(self._make_field_item(col))

        self.list_pivot_rows.clear()
        init_rows = list(getattr(self.widget_cfg, "pivot_rows", []) or [])
        if not init_rows and self.widget_cfg.category_field and getattr(self.widget_cfg, "table_mode", "detail") == "pivot":
            init_rows = [self.widget_cfg.category_field]
        for rf in init_rows:
            self.list_pivot_rows.addItem(self._make_field_item(rf))

        self.list_pivot_cols.clear()
        for cf in (getattr(self.widget_cfg, "pivot_cols", []) or []):
            self.list_pivot_cols.addItem(self._make_field_item(cf))

        self.list_pivot_vals.clear()
        init_vals = list(getattr(self.widget_cfg, "pivot_values", []) or [])
        if not init_vals and getattr(self.widget_cfg, "table_mode", "detail") == "pivot":
            vf = self.widget_cfg.value_field or CALC_AREA_FIELD
            init_vals = [{"field": vf, "agg": self.widget_cfg.aggregation or "sum"}]
        for spec in init_vals:
            if isinstance(spec, dict) and spec.get("field"):
                self.list_pivot_vals.addItem(
                    self._make_pivot_val_item(
                        str(spec["field"]),
                        str(spec.get("agg") or "sum"),
                        label=str(spec.get("label") or "").strip() or None,
                    )
                )

    def _open_map_style_legend_dialog(self) -> None:
        checked_val = qt_enum(Qt, "CheckState", "Checked")
        overlays: List[str] = []
        for idx in range(self.list_overlays.count()):
            it = self.list_overlays.item(idx)
            if it is not None and it.checkState() == checked_val:
                overlays.append(it.text())
        if overlays:
            self.widget_cfg.map_layers = overlays
        dlg = MapLegendDialog(
            self.widget_cfg,
            layer_fields_map=self.layer_fields_map,
            lang=self.lang,
            parent=self,
            catalog_manager=self.catalog_manager,
            dashboard=self.dashboard,
            available_layers=[self.list_overlays.item(i).text() for i in range(self.list_overlays.count())],
        )
        exec_dialog(dlg)

    def _current_avail_field(self) -> Optional[str]:
        it = self.list_tbl_avail.currentItem()
        if it is None:
            return None
        val = it.data(qt_enum(Qt, "ItemDataRole", "UserRole"))
        return str(val) if val else it.text().strip()

    def _filter_table_available_fields(self, text: str) -> None:
        needle = (text or "").strip().lower()
        for i in range(self.list_tbl_avail.count()):
            it = self.list_tbl_avail.item(i)
            key = str(it.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or "").lower()
            visible = (not needle) or (needle in it.text().lower()) or (needle in key)
            it.setHidden(not visible)

    def _list_has_field(self, lw: QListWidget, field_name: str) -> bool:
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for i in range(lw.count()):
            if str(lw.item(i).data(role) or lw.item(i).text()) == field_name:
                return True
        return False

    def _on_spatial_pivot_toggled(self, checked: bool) -> None:
        self.cb_spatial_layer.setEnabled(bool(checked))
        self._populate_fields(allow_network=False)

    def _drop_detail_col(self, fname: str, _label: str, row: int) -> None:
        if fname and not self._list_has_field(self.list_tbl_cols, fname):
            pos = max(0, min(self.list_tbl_cols.count(), row))
            self.list_tbl_cols.insertItem(pos, self._make_field_item(fname))

    def _drop_pivot_dim(self, lw: QListWidget, fname: str, row: int) -> None:
        if fname and fname not in (CALC_AREA_FIELD, CALC_COUNT_FIELD) and not self._list_has_field(lw, fname):
            pos = max(0, min(lw.count(), row))
            lw.insertItem(pos, self._make_field_item(fname))

    def _drop_pivot_val(self, fname: str, _label: str, row: int) -> None:
        if not fname:
            return
        idx_pm = self.cb_table_mode.findData("pivot")
        if idx_pm >= 0 and str(self.cb_table_mode.currentData()) != "pivot":
            self.cb_table_mode.setCurrentIndex(idx_pm)
        agg = "count" if fname == CALC_COUNT_FIELD else str(self.cb_pivot_agg.currentData() or "sum")
        pos = max(0, min(self.list_pivot_vals.count(), row))
        self.list_pivot_vals.insertItem(pos, self._make_pivot_val_item(fname, agg))

    def _on_pivot_val_context_menu(self, item: QListWidgetItem, global_pos: Any) -> None:
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None or item is None:
            return
        menu = QMenuCls(self)
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        data = item.data(role)
        fname = str(data.get("field") if isinstance(data, dict) else (data or item.text()))
        cur_agg = str(data.get("agg") or "sum") if isinstance(data, dict) else "sum"
        cur_lbl = str(data.get("label") or "") if isinstance(data, dict) else ""
        agg_actions: Dict[Any, str] = {}
        sub = menu.addMenu(tr("ctx_set_agg", self.lang))
        for i in range(self.cb_pivot_agg.count()):
            akey = str(self.cb_pivot_agg.itemData(i) or "sum")
            albl = self.cb_pivot_agg.itemText(i)
            act = sub.addAction(albl)
            agg_actions[act] = akey
        act_rename = menu.addAction(tr("ctx_rename_col", self.lang))
        act_reset = menu.addAction(tr("ctx_reset_col", self.lang))
        menu.addSeparator()
        act_rm = menu.addAction(tr("ctx_remove", self.lang))
        chosen = exec_menu(menu, global_pos)
        if chosen is None:
            return
        row = self.list_pivot_vals.row(item)
        if chosen == act_rename:
            mkey = f"{cur_agg}:{fname}"
            agg_lbl = tr(f"agg_{cur_agg}" if cur_agg != "distinct_count" else "agg_distinct", self.lang).split(" (")[0]
            def_lbl = f"{agg_lbl}: {friendly_field_label(fname, self.lang)}"
            self._prompt_column_alias(mkey, def_lbl, str(self._field_aliases.get(mkey) or cur_lbl))
        elif chosen == act_reset:
            self.rename_table_column(f"{cur_agg}:{fname}", "")
        elif chosen == act_rm and row >= 0:
            self.list_pivot_vals.takeItem(row)
        elif chosen in agg_actions and row >= 0:
            new_agg = agg_actions[chosen]
            self.list_pivot_vals.takeItem(row)
            self.list_pivot_vals.insertItem(row, self._make_pivot_val_item(fname, new_agg, label=cur_lbl or None))

    def _add_selected_detail_col(self) -> None:
        fname = self._current_avail_field()
        if fname and not self._list_has_field(self.list_tbl_cols, fname):
            self.list_tbl_cols.addItem(self._make_field_item(fname))

    def _add_selected_pivot_row(self) -> None:
        fname = self._current_avail_field()
        if fname and fname not in (CALC_AREA_FIELD, CALC_COUNT_FIELD):
            if not self._list_has_field(self.list_pivot_rows, fname):
                self.list_pivot_rows.addItem(self._make_field_item(fname))

    def _add_selected_pivot_col(self) -> None:
        fname = self._current_avail_field()
        if fname and fname not in (CALC_AREA_FIELD, CALC_COUNT_FIELD):
            if not self._list_has_field(self.list_pivot_cols, fname):
                self.list_pivot_cols.addItem(self._make_field_item(fname))

    def _add_calculated_metric(self, fname: str, agg: str) -> None:
        idx_pm = self.cb_table_mode.findData("pivot")
        if idx_pm >= 0 and str(self.cb_table_mode.currentData()) != "pivot":
            self.cb_table_mode.setCurrentIndex(idx_pm)
        self.list_pivot_vals.addItem(self._make_pivot_val_item(fname, agg))

    def _add_selected_pivot_value(self) -> None:
        agg = str(self.cb_pivot_agg.currentData() or "sum")
        fname = self._current_avail_field()
        if not fname:
            fname = CALC_COUNT_FIELD if agg == "count" else CALC_AREA_FIELD
        self._add_calculated_metric(fname, agg)

    def _on_avail_field_double_clicked(self, item: QListWidgetItem) -> None:
        fname = str(item.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or item.text().strip())
        if not fname:
            return
        if str(self.cb_table_mode.currentData() or "detail") == "pivot":
            if fname in (CALC_AREA_FIELD, CALC_COUNT_FIELD):
                self._add_calculated_metric(
                    fname, "count" if fname == CALC_COUNT_FIELD else str(self.cb_pivot_agg.currentData() or "sum")
                )
            elif self.list_pivot_rows.count() == 0:
                self._add_selected_pivot_row()
            else:
                self._add_calculated_metric(fname, str(self.cb_pivot_agg.currentData() or "sum"))
        else:
            self._add_selected_detail_col()

    @staticmethod
    def _remove_list_item(lw: QListWidget) -> None:
        row = lw.currentRow()
        if row >= 0:
            lw.takeItem(row)

    @staticmethod
    def _move_list_item(lw: QListWidget, delta: int) -> None:
        row = lw.currentRow()
        new_row = row + delta
        if row < 0 or new_row < 0 or new_row >= lw.count():
            return
        item = lw.takeItem(row)
        lw.insertItem(new_row, item)
        lw.setCurrentRow(new_row)

    @staticmethod
    def _combo_field_value(combo: QComboBox) -> str:
        txt = combo.currentText().strip()
        idx = combo.currentIndex()
        if idx >= 0 and combo.itemText(idx).strip() == txt:
            data = combo.itemData(idx)
            if data:
                return str(data)
        if txt == CALC_AREA_FIELD or "arvuta pindala" in txt.lower() or "calculate area" in txt.lower():
            return CALC_AREA_FIELD
        if txt == CALC_COUNT_FIELD:
            return CALC_COUNT_FIELD
        return txt

    def _populate_fields(self, allow_network: bool = False) -> None:
        layer_name = self.cb_layer.currentText().strip()
        cur_cat = self.cb_category.currentText().strip()
        cur_val = self._combo_field_value(self.cb_value)
        cur_ser = self._combo_field_value(self.cb_series)
        if cur_ser == tr("series_none", self.lang):
            cur_ser = ""
        cols = _lookup_fields_lazy(
            layer_name,
            self.layer_fields_map,
            dashboard=self.dashboard,
            catalog_manager=self.catalog_manager,
            allow_network=allow_network,
        )

        # Populate Category ComboBox
        self.cb_category.blockSignals(True)
        self.cb_category.clear()
        self.cb_category.addItem("")
        for c in cols:
            self.cb_category.addItem(c)
        if cur_cat:
            self.cb_category.setCurrentText(cur_cat)
        self.cb_category.blockSignals(False)

        # Populate Value ComboBox (including virtual geometry Area ha)
        self.cb_value.blockSignals(True)
        self.cb_value.clear()
        self.cb_value.addItem("")
        self.cb_value.addItem(tr("tbl_calc_area", self.lang), CALC_AREA_FIELD)
        for c in cols:
            self.cb_value.addItem(c, c)
        if cur_val == CALC_AREA_FIELD:
            idx_a = self.cb_value.findData(CALC_AREA_FIELD)
            if idx_a >= 0:
                self.cb_value.setCurrentIndex(idx_a)
        elif cur_val:
            self.cb_value.setCurrentText(cur_val)
        self.cb_value.blockSignals(False)

        # Populate optional Series Split ComboBox
        self.cb_series.blockSignals(True)
        self.cb_series.clear()
        self.cb_series.addItem(tr("series_none", self.lang), "")
        for c in cols:
            self.cb_series.addItem(c, c)
        if cur_ser:
            idx_ser = self.cb_series.findData(cur_ser)
            if idx_ser >= 0:
                self.cb_series.setCurrentIndex(idx_ser)
            else:
                self.cb_series.setCurrentText(cur_ser)
        self.cb_series.blockSignals(False)

        # Populate Visual Table / Pivot Designer Available Fields List
        self.list_tbl_avail.clear()
        self.list_tbl_avail.addItem(self._make_field_item(CALC_AREA_FIELD))
        self.list_tbl_avail.addItem(self._make_field_item(CALC_COUNT_FIELD))
        for c in cols:
            if c not in (CALC_AREA_FIELD, CALC_COUNT_FIELD):
                self.list_tbl_avail.addItem(self._make_field_item(c))

        if getattr(self, "chk_spatial_pivot", None) and self.chk_spatial_pivot.isChecked():
            join_lname = self.cb_spatial_layer.currentText().strip()
            if join_lname and join_lname != layer_name:
                join_cols = _lookup_fields_lazy(
                    join_lname,
                    self.layer_fields_map,
                    dashboard=self.dashboard,
                    catalog_manager=self.catalog_manager,
                    allow_network=allow_network,
                )
                for jc in join_cols:
                    if not str(jc).startswith("_"):
                        prefixed = f"[{join_lname}] {jc}"
                        self.list_tbl_avail.addItem(self._make_field_item(prefixed, f"🌐 [{join_lname}] {jc}"))
        self._filter_table_available_fields(self.ed_tbl_field_search.text())

    def _on_accept(self) -> None:
        wtype = self._selected_type or "bar"
        self.widget_cfg.widget_type = wtype

        default_title = tr("map_widget_title", self.lang) if wtype == "map" else (
            self.ed_title_et.text().strip() or self.cb_layer.currentText().strip() or "Vidin"
        )
        self.widget_cfg.title = self.ed_title_et.text().strip() or default_title
        self.widget_cfg.title_en = self.ed_title_en.text().strip() or self.widget_cfg.title
        self.widget_cfg.title_custom = bool(getattr(self, "_title_user_edited", False))
        self.widget_cfg.layer_name = self.cb_layer.currentText().strip()
        self.widget_cfg.page_id = str(self.cb_page.currentData() or "page_1")
        self.widget_cfg.drill_to_page_id = str(self.cb_drill_page.currentData() or "")
        self.widget_cfg.border_style = str(self.cb_widget_border.currentData() or "default")

        if wtype == "map":
            self.widget_cfg.map_basemap = str(self.cb_basemap.currentData() or "MA-HALLKAART")
            if not isinstance(getattr(self.widget_cfg, "map_layer_styles", None), dict):
                self.widget_cfg.map_layer_styles = {}
            overlays: List[str] = []
            checked_val = qt_enum(Qt, "CheckState", "Checked")
            for idx in range(self.list_overlays.count()):
                it = self.list_overlays.item(idx)
                lname = it.text()
                is_vis = it.checkState() == checked_val
                st = dict(self.widget_cfg.map_layer_styles.get(lname, {}) or {})
                st["visible"] = is_vis
                self.widget_cfg.map_layer_styles[lname] = st
                if is_vis:
                    overlays.append(lname)
            self.widget_cfg.map_layers = overlays
            self.widget_cfg.map_layers_custom_order = bool(getattr(self, "_overlays_custom_ordered", False))
            if hasattr(self, "sl_map_scroll_sens"):
                self.widget_cfg.map_scroll_sensitivity = max(1, min(100, int(self.sl_map_scroll_sens.value())))
            if self.widget_cfg.layout_w < 360:
                self.widget_cfg.layout_w = 560
            if self.widget_cfg.layout_h < 280:
                self.widget_cfg.layout_h = 390
        elif wtype == "kpi":
            if self.widget_cfg.layout_w > 360:
                self.widget_cfg.layout_w = 240
            if self.widget_cfg.layout_h > 200:
                self.widget_cfg.layout_h = 135
        elif wtype == "expression":
            if hasattr(self.ed_expr, "toPlainText"):
                expr_val = self.ed_expr.toPlainText().strip()
            else:
                expr_val = self.ed_expr.text().strip()
            self.widget_cfg.expression = expr_val
            if expr_val != self._expr_blocks_source_expr:
                parsed_blks, ok_ll = expression_to_blocks(expr_val, default_layer=self.cb_layer.currentText().strip())
                self._expression_blocks = parsed_blks if ok_ll else []
            self.widget_cfg.expression_blocks = copy.deepcopy(self._expression_blocks)
            self.widget_cfg.expression_color_mode = self._expression_color_mode
            self.widget_cfg.expression_threshold_ok = self._expression_threshold_ok
            self.widget_cfg.expression_threshold_warn = self._expression_threshold_warn
            self.widget_cfg.expression_rules = copy.deepcopy(self._expression_rules)
            self.widget_cfg.expression_subtext = self.ed_expr_sub.text().strip()
            self.widget_cfg.expression_display = str(self.cb_expr_display.currentData() or "auto")
            if self.widget_cfg.layout_w > 460:
                self.widget_cfg.layout_w = 280
            if self.widget_cfg.layout_h > 240:
                self.widget_cfg.layout_h = 150
        elif wtype == "table":
            if self.widget_cfg.layout_w < 420:
                self.widget_cfg.layout_w = 540
            if self.widget_cfg.layout_h < 240:
                self.widget_cfg.layout_h = 300
        elif wtype == "image":
            img_src = self.ed_img_source.text().strip()
            self.widget_cfg.image_source = img_src
            if img_src and os.path.isfile(img_src) and not self._image_data_uri:
                try:
                    with open(img_src, "rb") as fh:
                        raw = fh.read()
                    mime, _enc = mimetypes.guess_type(img_src)
                    if not mime or not mime.startswith("image/"):
                        mime = "image/png"
                    self._image_data_uri = f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"
                except Exception:
                    pass
            elif img_src.startswith(("http://", "https://", "data:image/")):
                if img_src.startswith("data:image/"):
                    self._image_data_uri = img_src
                elif not os.path.isfile(img_src):
                    self._image_data_uri = ""
            self.widget_cfg.image_data_uri = self._image_data_uri
            self.widget_cfg.image_fit = str(self.cb_img_fit.currentData() or "contain")
            self.widget_cfg.image_caption = self.ed_img_caption.text().strip()
            self.widget_cfg.image_link_url = self.ed_img_link.text().strip()
            self.widget_cfg.image_transparent_bg = self.chk_img_transparent.isChecked()
            if self.widget_cfg.layout_w > 460:
                self.widget_cfg.layout_w = 280
            if self.widget_cfg.layout_h > 300:
                self.widget_cfg.layout_h = 180

        self.widget_cfg.category_field = self.cb_category.currentText().strip()
        self.widget_cfg.value_field = self._combo_field_value(self.cb_value)
        ser_txt = self._combo_field_value(self.cb_series)
        if ser_txt == tr("series_none", self.lang):
            ser_txt = ""
        self.widget_cfg.secondary_field = ser_txt
        self.widget_cfg.aggregation = str(self.cb_agg.currentData() or "sum")
        self.widget_cfg.decimals = int(self.sp_decimals.value())
        self.widget_cfg.prefix = self.ed_prefix.text()
        self.widget_cfg.suffix = self.ed_suffix.text()

        tgt_raw = self.ed_target.text().strip().replace(",", ".")
        if tgt_raw:
            try:
                self.widget_cfg.target_value = float(tgt_raw)
            except ValueError:
                self.widget_cfg.target_value = None
        else:
            self.widget_cfg.target_value = None

        self.widget_cfg.horizontal = self.chk_horizontal.isChecked()
        self.widget_cfg.donut = self.chk_donut.isChecked()
        self.widget_cfg.chart_stack_mode = str(self.cb_stack_mode.currentData() or "group")
        self.widget_cfg.sort_by = str(self.cb_sort_by.currentData() or "value_desc")
        self.widget_cfg.top_n = max(1, int(self.sp_top_n.value()))
        self.widget_cfg.color_palette = str(self.cb_palette.currentData() or "emerald")
        self.widget_cfg.primary_color = self._selected_color
        self.widget_cfg.enable_cross_filter = self.chk_cross.isChecked()
        self.widget_cfg.connected_target_ids = _save_target_connection_list(
            self.list_targets, self.dashboard, self.widget_cfg.id
        )

        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        self.widget_cfg.table_mode = str(self.cb_table_mode.currentData() or "detail")
        self.widget_cfg.spatial_join_layer = (
            self.cb_spatial_layer.currentText().strip()
            if getattr(self, "chk_spatial_pivot", None) and self.chk_spatial_pivot.isChecked()
            else ""
        )
        self.widget_cfg.table_transpose = self.chk_tbl_transpose.isChecked()
        self.widget_cfg.table_show_totals = self.chk_tbl_totals.isChecked()
        self.widget_cfg.table_columns = [
            str(self.list_tbl_cols.item(i).data(role) or self.list_tbl_cols.item(i).text())
            for i in range(self.list_tbl_cols.count())
        ]
        self.widget_cfg.pivot_rows = [
            str(self.list_pivot_rows.item(i).data(role) or self.list_pivot_rows.item(i).text())
            for i in range(self.list_pivot_rows.count())
        ]
        self.widget_cfg.pivot_cols = [
            str(self.list_pivot_cols.item(i).data(role) or self.list_pivot_cols.item(i).text())
            for i in range(self.list_pivot_cols.count())
        ]
        piv_vals: List[Dict[str, str]] = []
        for i in range(self.list_pivot_vals.count()):
            data = self.list_pivot_vals.item(i).data(role)
            if isinstance(data, dict) and data.get("field"):
                spec_out: Dict[str, str] = {
                    "field": str(data["field"]),
                    "agg": str(data.get("agg") or "sum"),
                }
                lbl = str(
                    self._field_aliases.get(f"{spec_out['agg']}:{spec_out['field']}")
                    or data.get("label")
                    or ""
                ).strip()
                if lbl:
                    spec_out["label"] = lbl
                piv_vals.append(spec_out)
        self.widget_cfg.pivot_values = piv_vals
        self.widget_cfg.field_aliases = {
            str(k): str(v).strip()
            for k, v in (self._field_aliases or {}).items()
            if str(v or "").strip()
        }
        self.accept()


class DataSourceJoinDialog(QDialog):
    """Dialog for configuring Data Sources (WFS, WMS, Excel, SharePoint) and Excel Attribute Joins."""

    def __init__(
        self,
        dashboard: DashboardConfig,
        project_dir: Optional[str] = None,
        lang: str = "",
        catalog_manager: Optional[LocalCatalogManager] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.project_dir = project_dir
        self.lang = lang or getattr(dashboard, "language", "et") or "et"
        self.catalog_manager = catalog_manager
        self._discovered_layers: List[Dict[str, str]] = []

        self.setWindowTitle(tr("dlg_sources_title", self.lang))
        _apply_laptop_friendly_bounds(self, 760, 560, min_w=480, min_h=380)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)

        tab_sources = QWidget()
        tab_joins = QWidget()
        tab_discovery = QWidget()
        tabs.addTab(tab_sources, tr("tab_sources", self.lang))
        tabs.addTab(tab_joins, tr("tab_joins", self.lang))
        tabs.addTab(tab_discovery, tr("grp_discovery", self.lang))

        self._build_sources_tab(tab_sources)
        self._build_joins_tab(tab_joins)
        self._build_discovery_tab(tab_discovery)

        btn_box = QDialogButtonBox(
            qt_enum(QDialogButtonBox, "StandardButton", "Ok")
            | qt_enum(QDialogButtonBox, "StandardButton", "Cancel")
        )
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)

        self._refresh_lists()

    def _build_sources_tab(self, parent_widget: QWidget) -> None:
        hl = QHBoxLayout(parent_widget)

        left = QVBoxLayout()
        left.addWidget(QLabel(f"<b>{tr('lbl_configured_sources', self.lang)}</b>"))
        self.source_list = DragFieldListWidget(
            role_mode="sources",
            lang=self.lang,
            on_remove_row=self._remove_source_at_row,
        )
        self.source_list.currentRowChanged.connect(self._on_source_selected)
        left.addWidget(self.source_list)

        btn_row = QHBoxLayout()
        self.btn_add_src = QPushButton(tr("btn_add_source", self.lang))
        self.btn_add_src.clicked.connect(self._add_source)
        self.btn_del_src = QPushButton(tr("btn_remove", self.lang))
        self.btn_del_src.clicked.connect(self._remove_source)
        btn_row.addWidget(self.btn_add_src)
        btn_row.addWidget(self.btn_del_src)
        left.addLayout(btn_row)
        hl.addLayout(left, 1)

        right_grp = QGroupBox(tr("grp_source_details", self.lang))
        form = QFormLayout(right_grp)

        self.ed_name = QLineEdit()
        self.cb_type = QComboBox()
        self.cb_type.addItems(["wfs", "wms", "excel", "csv", "sharepoint_list", "qgis_layer"])
        self.ed_url = QLineEdit()
        self.ed_typename = QLineEdit()
        self.ed_crs = QLineEdit("EPSG:3301")

        self.cb_auth_mode = QComboBox()
        self.cb_auth_mode.addItems(["none", "qgis_authcfg", "bearer_env", "basic", "msal_graph"])
        self.ed_authcfg = QLineEdit()
        self.ed_authcfg.setPlaceholderText("QGIS AuthCfg ID")

        excel_row = QHBoxLayout()
        self.ed_excel_path = QLineEdit()
        self.ed_excel_path.setPlaceholderText("${PROJECT_DIR}/data/niidud.xlsx")
        self.btn_browse_xl = QPushButton(tr("btn_browse_excel", self.lang))
        self.btn_browse_xl.clicked.connect(self._browse_excel)
        excel_row.addWidget(self.ed_excel_path)
        excel_row.addWidget(self.btn_browse_xl)

        self.cb_sheet = QComboBox()
        self.cb_sheet.setEditable(True)

        self.cb_ingest = QComboBox()
        self.cb_ingest.addItems(["table_join", "spatial_xy", "spatial_wkt"])

        xy_row = QHBoxLayout()
        self.ed_x_field = QLineEdit()
        self.ed_x_field.setPlaceholderText("X / Lon veerg")
        self.ed_y_field = QLineEdit()
        self.ed_y_field.setPlaceholderText("Y / Lat veerg")
        xy_row.addWidget(self.ed_x_field)
        xy_row.addWidget(self.ed_y_field)

        self.chk_basemap = QCheckBox(tr("lbl_is_basemap", self.lang))

        self.ed_sp_web_url = QLineEdit()
        self.ed_sp_web_url.setPlaceholderText("https://.../sites/.../Shared%20Documents/data.xlsx")

        self.cb_data_state = QComboBox()
        self.cb_data_state.addItem(tr("data_state_auto", self.lang, state="LIVE"), "auto")
        self.cb_data_state.addItem(tr("data_state_live", self.lang), "live")
        self.cb_data_state.addItem(tr("data_state_static", self.lang), "static")
        for sig in (
            self.cb_type.currentTextChanged,
            self.ed_url.textChanged,
            self.ed_excel_path.textChanged,
            self.ed_sp_web_url.textChanged,
        ):
            sig.connect(lambda _v="": self._update_auto_state_label())

        self.btn_apply_src = QPushButton(tr("btn_apply_source", self.lang))
        self.btn_apply_src.setProperty("btnRole", "primary")
        self.btn_apply_src.clicked.connect(self._apply_source_changes)

        form.addRow(tr("lbl_source_name", self.lang), self.ed_name)
        form.addRow(tr("lbl_source_type", self.lang), self.cb_type)
        form.addRow(tr("lbl_ogc_url", self.lang), self.ed_url)
        form.addRow(tr("lbl_ogc_typename", self.lang), self.ed_typename)
        form.addRow(tr("lbl_crs", self.lang), self.ed_crs)
        form.addRow(tr("lbl_auth_mode", self.lang), self.cb_auth_mode)
        form.addRow(tr("lbl_authcfg", self.lang), self.ed_authcfg)
        form.addRow(tr("lbl_excel_path", self.lang), excel_row)
        form.addRow(tr("lbl_sp_web_url", self.lang), self.ed_sp_web_url)
        form.addRow(tr("lbl_sheet", self.lang), self.cb_sheet)
        form.addRow(tr("lbl_ingest_mode", self.lang), self.cb_ingest)
        form.addRow(tr("lbl_xy_cols", self.lang), xy_row)
        form.addRow(tr("lbl_data_state", self.lang), self.cb_data_state)
        form.addRow("", self.chk_basemap)
        form.addRow(self.btn_apply_src)

        hl.addWidget(right_grp, 2)

    def _build_joins_tab(self, parent_widget: QWidget) -> None:
        vl = QVBoxLayout(parent_widget)
        vl.addWidget(QLabel(f"<b>{tr('lbl_configured_joins', self.lang)}</b>"))
        self.join_list = DragFieldListWidget(
            role_mode="joins",
            lang=self.lang,
            on_remove_row=self._remove_join_at_row,
        )
        vl.addWidget(self.join_list)

        grp = QGroupBox(tr("grp_create_join", self.lang))
        form = QFormLayout(grp)

        self.cb_join_excel = QComboBox()
        self.cb_join_target = QComboBox()
        self.ed_src_key = QLineEdit("elupaik_kood")
        self.ed_tgt_key = QLineEdit("kood")
        self.ed_prefix = QLineEdit("xl_")

        form.addRow(tr("lbl_join_excel", self.lang), self.cb_join_excel)
        form.addRow(tr("lbl_join_target", self.lang), self.cb_join_target)
        form.addRow(tr("lbl_join_src_key", self.lang), self.ed_src_key)
        form.addRow(tr("lbl_join_tgt_key", self.lang), self.ed_tgt_key)
        form.addRow(tr("lbl_join_prefix", self.lang), self.ed_prefix)

        row_btns = QHBoxLayout()
        btn_add_j = QPushButton(tr("btn_add_join", self.lang))
        btn_add_j.setProperty("btnRole", "primary")
        btn_add_j.clicked.connect(self._add_join)
        btn_del_j = QPushButton(tr("btn_remove_join", self.lang))
        btn_del_j.clicked.connect(self._remove_join)
        row_btns.addWidget(btn_add_j)
        row_btns.addWidget(btn_del_j)
        form.addRow(row_btns)
        vl.addWidget(grp)

    def _build_discovery_tab(self, parent_widget: QWidget) -> None:
        vl = QVBoxLayout(parent_widget)
        grp = QGroupBox(tr("grp_discovery", self.lang))
        form = QFormLayout(grp)

        self.cb_disc_preset = QComboBox()
        self.cb_disc_preset.addItem("EELIS Looduskaitse WFS (gsavalik.envir.ee)", "eelis_wfs")
        self.cb_disc_preset.addItem("PRIA Pärandniidud WFS (kls.pria.ee)", "pria_plk_wfs")
        self.cb_disc_preset.addItem("Maa- ja Ruumiamet Hallkaart WMS", "maaamet_hallkaart_wms")
        self.cb_disc_preset.addItem("Maa- ja Ruumiamet Põhikaart WMS", "maaamet_kaart_wms")
        self.cb_disc_preset.addItem("Maa- ja Ruumiamet Ortofoto (EESTIFOTO) WMS", "maaamet_ortofoto_wms")
        self.cb_disc_preset.addItem("Maa- ja Ruumiamet Hübriidkaart WMS", "maaamet_hybrid_wms")
        self.cb_disc_preset.currentIndexChanged.connect(self._on_preset_changed)

        self.ed_disc_url = QLineEdit("https://gsavalik.envir.ee/geoserver/eelis/ows")
        self.cb_disc_type = QComboBox()
        self.cb_disc_type.addItems(["wfs", "wms"])

        top_row = QHBoxLayout()
        self.btn_discover = QPushButton(tr("btn_discover", self.lang))
        self.btn_discover.setProperty("btnRole", "primary")
        self.btn_discover.clicked.connect(self._discover_service_layers)
        self.ed_disc_filter = QLineEdit()
        self.ed_disc_filter.setPlaceholderText(tr("ph_filter_layers", self.lang))
        self.ed_disc_filter.textChanged.connect(self._filter_discovered_list)
        top_row.addWidget(self.btn_discover)
        top_row.addWidget(self.ed_disc_filter, 1)

        form.addRow("Eesti teenuse mall" if self.lang == "et" else "Preset", self.cb_disc_preset)
        form.addRow(tr("lbl_ogc_url", self.lang), self.ed_disc_url)
        form.addRow(tr("lbl_source_type", self.lang), self.cb_disc_type)
        form.addRow(top_row)
        vl.addWidget(grp)

        self.disc_list = QListWidget()
        vl.addWidget(self.disc_list, 1)

        bottom_row = QHBoxLayout()
        self.lbl_disc_status = QLabel("")
        self.btn_add_disc = QPushButton(tr("btn_use_layer", self.lang))
        self.btn_add_disc.clicked.connect(self._add_discovered_layer)
        bottom_row.addWidget(self.lbl_disc_status, 1)
        bottom_row.addWidget(self.btn_add_disc)
        vl.addLayout(bottom_row)

        # Pre-populate cached EELIS layers immediately if available
        if self.catalog_manager:
            for srv in self.catalog_manager.get_servers():
                if "eelis" in srv.get("url", "").lower() and srv.get("layers"):
                    self._discovered_layers = list(srv["layers"])
                    self._filter_discovered_list()
                    break

    def _on_preset_changed(self) -> None:
        key = self.cb_disc_preset.currentData()
        preset = ESTONIAN_OGC_PRESETS.get(key)
        if not preset:
            return
        self.ed_disc_url.setText(preset.get("url", ""))
        self.cb_disc_type.setCurrentText(preset.get("source_type", "wfs"))

    def _discover_service_layers(self) -> None:
        url = self.ed_disc_url.text().strip()
        stype = self.cb_disc_type.currentText().strip()
        if not url:
            return
        self.lbl_disc_status.setText("⏳ GetCapabilities...")
        QtWidgets.QApplication.processEvents()
        try:
            self._discovered_layers = OgcConnector.discover_layers(url, service_type=stype, timeout=15)
            self._filter_discovered_list()
            self.lbl_disc_status.setText(
                f"Leitud {len(self._discovered_layers)} kihti"
                if self.lang == "et"
                else f"Discovered {len(self._discovered_layers)} layers"
            )
        except Exception as exc:
            self.lbl_disc_status.setText(f"✗ {exc}")

    def _filter_discovered_list(self) -> None:
        query = self.ed_disc_filter.text().strip().lower()
        self.disc_list.clear()
        for item in self._discovered_layers:
            name = item.get("name", "")
            title = item.get("title", name)
            if query and query not in name.lower() and query not in title.lower():
                continue
            li = QListWidgetItem(f"{title}  [{name}]")
            li.setData(qt_enum(Qt, "ItemDataRole", "UserRole"), item)
            self.disc_list.addItem(li)

    def _add_discovered_layer(self) -> None:
        item = self.disc_list.currentItem()
        if not item:
            return
        meta = item.data(qt_enum(Qt, "ItemDataRole", "UserRole")) or {}
        typename = meta.get("name", "")
        title = meta.get("title", typename) or typename
        stype = self.cb_disc_type.currentText().strip()
        ds = DataSourceConfig(
            name=title,
            source_type=stype,
            url=self.ed_disc_url.text().strip(),
            typename_or_layers=typename,
            crs="EPSG:3301",
            is_basemap=(stype == "wms"),
            restrict_to_bbox=OgcConnector.is_massive_layer(title, typename),
        )
        self.dashboard.data_sources.append(ds)
        self._refresh_lists()
        self.lbl_disc_status.setText(f"✓ {title}")

    def _browse_excel(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            tr("btn_browse_excel", self.lang),
            self.project_dir or os.path.expanduser("~"),
            "Excel & CSV (*.xlsx *.xlsm *.csv);;All Files (*.*)",
        )
        if path:
            self.ed_excel_path.setText(PortablePathResolver.tokenize(path, project_dir=self.project_dir))
            sheets = ExcelConnector.list_sheets(path)
            self.cb_sheet.clear()
            self.cb_sheet.addItems(sheets)

    def _update_auto_state_label(self) -> None:
        if not hasattr(self, "cb_data_state"):
            return
        probe = DataSourceConfig(
            source_type=self.cb_type.currentText(),
            url=self.ed_url.text().strip(),
            sharepoint_site_url=self.ed_url.text().strip(),
            portable_path=self.ed_excel_path.text().strip(),
            sharepoint_web_url=self.ed_sp_web_url.text().strip(),
            data_state="auto",
        )
        eff = probe.effective_data_state(for_browser_export=False).upper()
        self.cb_data_state.setItemText(0, tr("data_state_auto", self.lang, state=eff))

    def _refresh_lists(self) -> None:
        self.source_list.clear()
        self.cb_join_excel.clear()
        self.cb_join_target.clear()
        for ds in self.dashboard.data_sources:
            eff = ds.effective_data_state(for_browser_export=True).upper()
            badge = "STATIC WFS" if ds.is_designer_pinned_static() else eff
            self.source_list.addItem(f"[{ds.source_type.upper()} · {badge}] {ds.name}")
            if ds.source_type in ("excel", "csv", "sharepoint_list"):
                self.cb_join_excel.addItem(ds.name, ds.id)
            else:
                self.cb_join_target.addItem(ds.name, ds.id)

        self.join_list.clear()
        src_map = {ds.id: ds.name for ds in self.dashboard.data_sources}
        for j in self.dashboard.joins:
            sname = src_map.get(j.source_table_id, j.source_table_id)
            tname = src_map.get(j.target_layer_id, j.target_layer_id)
            self.join_list.addItem(f"{sname} ({j.source_key_field}) -> {tname} ({j.target_key_field})")

    def _on_source_selected(self, row: int) -> None:
        if row < 0 or row >= len(self.dashboard.data_sources):
            return
        ds = self.dashboard.data_sources[row]
        self.ed_name.setText(ds.name)
        self.cb_type.setCurrentText(ds.source_type)
        self.ed_url.setText(ds.url or ds.sharepoint_site_url)
        self.ed_typename.setText(ds.typename_or_layers or ds.sharepoint_drive_or_list)
        self.ed_crs.setText(ds.crs)
        self.cb_auth_mode.setCurrentText(ds.auth_mode)
        self.ed_authcfg.setText(ds.authcfg_id)
        self.ed_excel_path.setText(ds.portable_path or ds.sharepoint_item_path)
        self.ed_sp_web_url.setText(getattr(ds, "sharepoint_web_url", "") or "")
        self.cb_sheet.setCurrentText(ds.sheet_name)
        self.cb_ingest.setCurrentText(ds.ingestion_mode)
        self.ed_x_field.setText(ds.x_field)
        self.ed_y_field.setText(ds.y_field)
        self.chk_basemap.setChecked(ds.is_basemap)
        idx_st = self.cb_data_state.findData(str(getattr(ds, "data_state", "auto") or "auto").lower())
        if idx_st >= 0:
            self.cb_data_state.setCurrentIndex(idx_st)
        self._update_auto_state_label()

    def _add_source(self) -> None:
        ds = DataSourceConfig(name=f"Andmeallikas {len(self.dashboard.data_sources) + 1}")
        self.dashboard.data_sources.append(ds)
        self._refresh_lists()
        self.source_list.setCurrentRow(len(self.dashboard.data_sources) - 1)

    def _remove_source_at_row(self, row: int) -> None:
        if 0 <= row < len(self.dashboard.data_sources):
            del self.dashboard.data_sources[row]
            self._refresh_lists()

    def _remove_source(self) -> None:
        self._remove_source_at_row(self.source_list.currentRow())

    def _apply_source_changes(self) -> None:
        row = self.source_list.currentRow()
        if row < 0 or row >= len(self.dashboard.data_sources):
            return
        ds = self.dashboard.data_sources[row]
        ds.name = self.ed_name.text().strip() or ds.name
        ds.source_type = self.cb_type.currentText()
        if ds.source_type == "sharepoint_list":
            ds.sharepoint_site_url = self.ed_url.text().strip()
            ds.sharepoint_drive_or_list = self.ed_typename.text().strip()
        else:
            ds.url = self.ed_url.text().strip()
            ds.typename_or_layers = self.ed_typename.text().strip()
        ds.crs = self.ed_crs.text().strip() or "EPSG:3301"
        ds.auth_mode = self.cb_auth_mode.currentText()
        ds.authcfg_id = self.ed_authcfg.text().strip()
        ds.portable_path = self.ed_excel_path.text().strip()
        ds.sharepoint_web_url = self.ed_sp_web_url.text().strip()
        ds.sheet_name = self.cb_sheet.currentText().strip()
        ds.ingestion_mode = self.cb_ingest.currentText()
        ds.x_field = self.ed_x_field.text().strip()
        ds.y_field = self.ed_y_field.text().strip()
        ds.is_basemap = self.chk_basemap.isChecked()
        ds.data_state = str(self.cb_data_state.currentData() or "auto")
        self._refresh_lists()
        self.source_list.setCurrentRow(row)

    def _add_join(self) -> None:
        src_id = self.cb_join_excel.currentData()
        tgt_id = self.cb_join_target.currentData()
        if not src_id or not tgt_id:
            return
        self.dashboard.joins.append(
            JoinConfig(
                source_table_id=str(src_id),
                target_layer_id=str(tgt_id),
                source_key_field=self.ed_src_key.text().strip(),
                target_key_field=self.ed_tgt_key.text().strip(),
                join_prefix=self.ed_prefix.text().strip(),
            )
        )
        self._refresh_lists()

    def _remove_join_at_row(self, row: int) -> None:
        if 0 <= row < len(self.dashboard.joins):
            del self.dashboard.joins[row]
            self._refresh_lists()

    def _remove_join(self) -> None:
        self._remove_join_at_row(self.join_list.currentRow())


class SharePointCatalogDialog(QDialog):
    """Browse shared SharePoint synced `.qdash.json` templates & manage Excel/OAuth packages."""

    def __init__(
        self,
        dashboard: DashboardConfig,
        on_template_loaded: Callable[[DashboardConfig], None],
        project_dir: Optional[str] = None,
        lang: str = "",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.on_template_loaded = on_template_loaded
        self.project_dir = project_dir
        self.lang = lang or getattr(dashboard, "language", "et") or "et"

        self.setWindowTitle(tr("dlg_sp_title", self.lang))
        _apply_laptop_friendly_bounds(self, 680, 500, min_w=460, min_h=360)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        layout = QVBoxLayout(self)

        sp_grp = QGroupBox(tr("grp_sp_folder", self.lang))
        sp_form = QFormLayout(sp_grp)
        folder_row = QHBoxLayout()
        self.ed_catalog_path = QLineEdit(dashboard.catalog.local_sync_folder)
        btn_browse_dir = QPushButton(tr("btn_browse_folder", self.lang))
        btn_browse_dir.clicked.connect(self._browse_folder)
        btn_refresh = QPushButton(tr("btn_refresh", self.lang))
        btn_refresh.clicked.connect(self._refresh_catalog)
        folder_row.addWidget(self.ed_catalog_path)
        folder_row.addWidget(btn_browse_dir)
        folder_row.addWidget(btn_refresh)

        self.lbl_resolved_dir = QLabel("")
        sp_form.addRow(tr("lbl_sp_path", self.lang), folder_row)
        sp_form.addRow(tr("lbl_sp_resolved", self.lang), self.lbl_resolved_dir)
        layout.addWidget(sp_grp)

        layout.addWidget(QLabel(f"<b>{tr('lbl_sp_templates', self.lang)}</b>"))
        self.tpl_list = QListWidget()
        layout.addWidget(self.tpl_list, 1)

        tpl_btns = QHBoxLayout()
        btn_load = QPushButton(tr("btn_load_tpl", self.lang))
        btn_load.setProperty("btnRole", "primary")
        btn_load.clicked.connect(self._load_selected)
        btn_publish = QPushButton(tr("btn_pub_tpl", self.lang))
        btn_publish.clicked.connect(self._publish_current)
        btn_import = QPushButton(tr("btn_import_tpl", self.lang))
        btn_import.clicked.connect(self._import_external)
        tpl_btns.addWidget(btn_load)
        tpl_btns.addWidget(btn_publish)
        tpl_btns.addWidget(btn_import)
        layout.addLayout(tpl_btns)

        dep_grp = QGroupBox(tr("grp_deps", self.lang))
        dep_layout = QVBoxLayout(dep_grp)
        self.lbl_deps = QLabel("")
        dep_btns = QHBoxLayout()
        btn_check = QPushButton(tr("btn_check_deps", self.lang))
        btn_check.clicked.connect(self._refresh_dep_status)
        self.btn_install = QPushButton("Install Missing (openpyxl / msal / requests)")
        self.btn_install.clicked.connect(self._install_deps)
        dep_btns.addWidget(btn_check)
        dep_btns.addWidget(self.btn_install)
        dep_layout.addWidget(self.lbl_deps)
        dep_layout.addLayout(dep_btns)
        layout.addWidget(dep_grp)

        self._refresh_catalog()
        self._refresh_dep_status()

    def _browse_folder(self) -> None:
        d = QFileDialog.getExistingDirectory(
            self,
            tr("btn_browse_folder", self.lang),
            os.path.expanduser("~"),
        )
        if d:
            portable = PortablePathResolver.tokenize(d, project_dir=self.project_dir)
            self.ed_catalog_path.setText(portable)
            self.dashboard.catalog.local_sync_folder = portable
            self._refresh_catalog()

    def _refresh_catalog(self) -> None:
        raw = self.ed_catalog_path.text().strip()
        self.dashboard.catalog.local_sync_folder = raw
        sp = SharePointConnector(self.dashboard.catalog)
        resolved = sp.resolve_catalog_dir(project_dir=self.project_dir)
        self.lbl_resolved_dir.setText(resolved)
        self.tpl_list.clear()
        self._templates = sp.list_local_templates(project_dir=self.project_dir)
        for tpl in self._templates:
            tpl_name = tpl.get("name", tpl.get("filename", ""))
            tpl_ver = tpl.get("version", tpl.get("updated_at", "")[:10])
            self.tpl_list.addItem(f"{tpl['title']}  [{tpl_name}]  ({tpl_ver})")

    def _load_selected(self) -> None:
        row = self.tpl_list.currentRow()
        if row < 0 or row >= len(getattr(self, "_templates", [])):
            return
        tpl_path = self._templates[row]["path"]
        try:
            cfg = SharePointConnector.load_template_from_file(tpl_path, project_dir=self.project_dir)
            self.on_template_loaded(cfg)
            self.accept()
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _publish_current(self) -> None:
        raw = self.ed_catalog_path.text().strip()
        self.dashboard.catalog.local_sync_folder = raw
        sp = SharePointConnector(self.dashboard.catalog)
        out = sp.save_template_to_catalog(self.dashboard, project_dir=self.project_dir)
        self._refresh_catalog()
        QMessageBox.information(
            self,
            tr("dlg_sp_title", self.lang),
            f"{'Avaldatud' if self.lang == 'et' else 'Published'}:\n{out}",
        )

    def _import_external(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            tr("btn_import_tpl", self.lang),
            self.project_dir or os.path.expanduser("~"),
            "QGIS Dashboard Template (*.qdash.json *.json)",
        )
        if path:
            cfg = SharePointConnector.load_template_from_file(path, project_dir=self.project_dir)
            self.on_template_loaded(cfg)
            self.accept()

    def _refresh_dep_status(self) -> None:
        status = DependencyManager.check_status()
        parts = [f"{pkg}: {'OK' if ok else 'Puudu'}" for pkg, ok in status.items()]
        self.lbl_deps.setText("  |  ".join(parts))

    def _install_deps(self) -> None:
        missing = DependencyManager.missing_packages()
        if not missing:
            self._refresh_dep_status()
            return
        self.btn_install.setEnabled(False)
        self.btn_install.setText("⏳ ...")
        QtWidgets.QApplication.processEvents()
        ok, msg = DependencyManager.install_missing()
        self.btn_install.setEnabled(True)
        self.btn_install.setText("Install Missing (openpyxl / msal / requests)")
        self._refresh_dep_status()
        if ok:
            QMessageBox.information(self, "OK", msg)
        else:
            QMessageBox.warning(self, "Error", msg)


class DashboardSettingsDialog(QDialog):
    """Configure dashboard title, subtitle, default language, theme, artboard size, and map/WFS options."""

    def __init__(
        self,
        dashboard: DashboardConfig,
        lang: Optional[str] = None,
        initial_tab: int = 0,
        catalog_manager: Optional[LocalCatalogManager] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.catalog_manager = catalog_manager
        self.catalog_changed: bool = False
        self.lang = lang or getattr(dashboard, "language", "et") or "et"
        self._initial_wfs_names: List[str] = []
        self._wfs_entries: List[Dict[str, Any]] = []
        self._initial_wfs_snapshot: List[Tuple[str, str, str, str]] = []
        self.setWindowTitle(tr("dlg_settings_title", self.lang))
        _apply_laptop_friendly_bounds(self, 560, 460, min_w=440, min_h=360)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        tabs = QTabWidget()
        self.tabs = tabs
        layout.addWidget(tabs, 1)

        # ---- Tab 1: General & Titles ----
        tab_gen = QWidget()
        gen_form = QFormLayout(tab_gen)
        gen_form.setSpacing(8)
        self.ed_title_et = QLineEdit(str(getattr(dashboard, "title", "") or ""))
        self.ed_title_en = QLineEdit(str(getattr(dashboard, "title_en", "") or ""))
        self.ed_sub_et = QLineEdit(str(getattr(dashboard, "subtitle", "") or ""))
        self.ed_sub_en = QLineEdit(str(getattr(dashboard, "subtitle_en", "") or ""))
        self.cb_lang = QComboBox()
        self.cb_lang.addItem("Eesti keel (EST)", "et")
        self.cb_lang.addItem("English (ENG)", "en")
        idx_l = self.cb_lang.findData(getattr(dashboard, "language", "et") or "et")
        if idx_l >= 0:
            self.cb_lang.setCurrentIndex(idx_l)

        self.cb_export_mode = QComboBox()
        self.cb_export_mode.addItem(tr("export_mode_compact", self.lang), "compact_single")
        self.cb_export_mode.addItem(tr("export_mode_sidecar", self.lang), "sidecar")
        idx_em = self.cb_export_mode.findData(getattr(dashboard, "export_mode", "compact_single") or "compact_single")
        if idx_em >= 0:
            self.cb_export_mode.setCurrentIndex(idx_em)

        self.cb_export_format = QComboBox()
        self.cb_export_format.addItem(tr("export_fmt_html", self.lang), "html")
        self.cb_export_format.addItem(tr("export_fmt_aspx", self.lang), "aspx")
        idx_ef = self.cb_export_format.findData(str(getattr(dashboard, "export_format", "html") or "html").lower())
        if idx_ef >= 0:
            self.cb_export_format.setCurrentIndex(idx_ef)

        self.cb_package_layers = QComboBox()
        self.cb_package_layers.addItem(tr("export_pkg_bundled", self.lang), True)
        self.cb_package_layers.addItem(tr("export_pkg_live_only", self.lang), False)
        idx_pkg = self.cb_package_layers.findData(bool(getattr(dashboard, "package_layers_in_export", True)))
        if idx_pkg >= 0:
            self.cb_package_layers.setCurrentIndex(idx_pkg)

        self.cb_export_tier = QComboBox()
        self.cb_export_tier.addItem(tr("export_tier_full", self.lang), "full")
        self.cb_export_tier.addItem(tr("export_tier_medium", self.lang), "medium")
        self.cb_export_tier.addItem(tr("export_tier_minimal", self.lang), "minimal")
        idx_tier = self.cb_export_tier.findData(str(getattr(dashboard, "export_tier", "full") or "full").lower())
        if idx_tier >= 0:
            self.cb_export_tier.setCurrentIndex(idx_tier)

        self.chk_open_after_export = QCheckBox(tr("export_open_after_label", self.lang))
        self.chk_open_after_export.setChecked(bool(getattr(dashboard, "open_after_export", False)))

        gen_form.addRow(tr("sett_title_et", self.lang), self.ed_title_et)
        gen_form.addRow(tr("sett_title_en", self.lang), self.ed_title_en)
        gen_form.addRow(tr("sett_sub_et", self.lang), self.ed_sub_et)
        gen_form.addRow(tr("sett_sub_en", self.lang), self.ed_sub_en)
        gen_form.addRow(tr("sett_default_lang", self.lang), self.cb_lang)
        gen_form.addRow(tr("export_fmt_label", self.lang), self.cb_export_format)
        gen_form.addRow(tr("export_mode_label", self.lang), self.cb_export_mode)
        gen_form.addRow(tr("export_pkg_label", self.lang), self.cb_package_layers)
        gen_form.addRow(tr("export_tier_label", self.lang), self.cb_export_tier)
        gen_form.addRow("", self.chk_open_after_export)
        tabs.addTab(tab_gen, tr("sett_tab_general", self.lang))

        # ---- Tab 2: Appearance & Artboard ----
        tab_app = QWidget()
        app_form = QFormLayout(tab_app)
        app_form.setSpacing(8)
        self.cb_theme = QComboBox()
        self.cb_theme.addItem(tr("sett_theme_auto", self.lang), "auto")
        self.cb_theme.addItem(tr("sett_theme_dark", self.lang), "dark")
        self.cb_theme.addItem(tr("sett_theme_light", self.lang), "light")
        idx_t = self.cb_theme.findData(getattr(dashboard, "theme", "auto") or "auto")
        if idx_t >= 0:
            self.cb_theme.setCurrentIndex(idx_t)

        self.sp_canvas_w = QSpinBox()
        self.sp_canvas_w.setRange(480, 3840)
        self.sp_canvas_w.setSingleStep(40)
        self.sp_canvas_w.setValue(int(getattr(dashboard, "canvas_width", 1280) or 1280))

        self.sp_canvas_h = QSpinBox()
        self.sp_canvas_h.setRange(360, 2160)
        self.sp_canvas_h.setSingleStep(40)
        self.sp_canvas_h.setValue(int(getattr(dashboard, "canvas_height", 760) or 760))

        self.chk_border = QCheckBox(tr("design_border", self.lang))
        self.chk_border.setChecked(bool(getattr(dashboard, "show_design_border", True)))

        self.cb_border_style = QComboBox()
        for bstyle, bkey in (
            ("none", "border_none"),
            ("solid", "border_solid"),
            ("dashed", "border_dashed"),
            ("dotted", "border_dotted"),
            ("double", "border_double"),
            ("shadow", "border_shadow"),
        ):
            self.cb_border_style.addItem(tr(bkey, self.lang), bstyle)
        idx_bs = self.cb_border_style.findData(getattr(dashboard, "canvas_border_style", "dashed") or "dashed")
        if idx_bs >= 0:
            self.cb_border_style.setCurrentIndex(idx_bs)

        bcol_row = QHBoxLayout()
        self._canvas_border_color = str(getattr(dashboard, "canvas_border_color", "#38bdf8") or "#38bdf8")
        self.ed_border_color = QLineEdit(self._canvas_border_color)
        self.btn_border_color = QPushButton("🎨")
        self.btn_border_color.setMaximumWidth(36)
        self.btn_border_color.clicked.connect(self._pick_canvas_border_color)
        bcol_row.addWidget(self.ed_border_color, 1)
        bcol_row.addWidget(self.btn_border_color)

        self.sp_border_width = QSpinBox()
        self.sp_border_width.setRange(1, 12)
        self.sp_border_width.setValue(int(getattr(dashboard, "canvas_border_width", 2) or 2))

        self.sp_border_radius = QSpinBox()
        self.sp_border_radius.setRange(0, 32)
        self.sp_border_radius.setValue(int(getattr(dashboard, "canvas_border_radius", 10) if getattr(dashboard, "canvas_border_radius", None) is not None else 10))

        self.chk_grid = QCheckBox(tr("design_grid", self.lang))
        self.chk_grid.setChecked(bool(getattr(dashboard, "show_grid", True)))
        self.cb_grid_step = QComboBox()
        for step_px in (10, 20, 25, 40):
            self.cb_grid_step.addItem(f"{step_px}px", step_px)
        idx_gs = self.cb_grid_step.findData(int(getattr(dashboard, "grid_size", 20) or 20))
        if idx_gs >= 0:
            self.cb_grid_step.setCurrentIndex(idx_gs)
        self.chk_snap = QCheckBox(tr("design_snap", self.lang))
        self.chk_snap.setChecked(bool(getattr(dashboard, "snap_to_grid", True)))
        self.chk_dissolve_borders = QCheckBox(tr("dissolve_borders_label", self.lang))
        self.chk_dissolve_borders.setChecked(bool(getattr(dashboard, "dissolve_adjacent_borders", True)))

        self.cb_widget_border_style = QComboBox()
        for bs_key, bs_lbl in (
            ("default", "Vaikimisi" if self.lang == "et" else "Default"),
            ("subtle", "Peen (Subtle)" if self.lang == "et" else "Subtle"),
            ("accent", "Esiletõstetud (Accent)" if self.lang == "et" else "Accent"),
            ("none", "Ilma piirjooneta" if self.lang == "et" else "Borderless"),
        ):
            self.cb_widget_border_style.addItem(bs_lbl, bs_key)
        idx_wbs = self.cb_widget_border_style.findData(getattr(dashboard, "widget_border_style", "default") or "default")
        if idx_wbs >= 0:
            self.cb_widget_border_style.setCurrentIndex(idx_wbs)

        app_form.addRow(tr("sett_theme", self.lang), self.cb_theme)
        app_form.addRow(tr("sett_canvas_w", self.lang), self.sp_canvas_w)
        app_form.addRow(tr("sett_canvas_h", self.lang), self.sp_canvas_h)
        app_form.addRow("", self.chk_border)
        app_form.addRow(tr("sett_border_style", self.lang), self.cb_border_style)
        app_form.addRow(tr("sett_border_color", self.lang), bcol_row)
        app_form.addRow(tr("sett_border_width", self.lang), self.sp_border_width)
        app_form.addRow(tr("sett_border_radius", self.lang), self.sp_border_radius)
        app_form.addRow("", self.chk_dissolve_borders)
        app_form.addRow(tr("widget_border_style_label", self.lang), self.cb_widget_border_style)
        app_form.addRow("", self.chk_grid)
        app_form.addRow(tr("grid_density_label", self.lang) + ":", self.cb_grid_step)
        app_form.addRow("", self.chk_snap)
        tabs.addTab(tab_app, tr("sett_tab_appearance", self.lang))

        # ---- Tab 3: Map & WFS Catalog ----
        tab_map = QWidget()
        map_lay = QVBoxLayout(tab_map)
        map_lay.setSpacing(10)
        sync_form = QFormLayout()
        sync_form.setSpacing(6)
        self.cb_canvas_sync_mode = QComboBox()
        self.cb_canvas_sync_mode.addItem(tr("sync_mode_dashboard_only", self.lang), "dashboard_only")
        self.cb_canvas_sync_mode.addItem(tr("sync_mode_main_canvas", self.lang), "sync_main_canvas")
        idx_csm = self.cb_canvas_sync_mode.findData(
            str(getattr(dashboard, "canvas_sync_mode", "dashboard_only") or "dashboard_only")
        )
        if idx_csm >= 0:
            self.cb_canvas_sync_mode.setCurrentIndex(idx_csm)
        sync_form.addRow(tr("canvas_sync_mode_label", self.lang), self.cb_canvas_sync_mode)
        map_lay.addLayout(sync_form)

        self.chk_extent = QCheckBox(tr("sett_extent_filter", self.lang))
        self.chk_extent.setChecked(bool(getattr(dashboard, "filter_by_map_extent", False)))
        self.chk_auto_zoom = QCheckBox(tr("sett_auto_zoom", self.lang))
        self.chk_auto_zoom.setChecked(bool(getattr(dashboard, "auto_zoom_on_filter", True)))
        self.chk_auto_home_clear = QCheckBox(tr("sett_auto_home_clear", self.lang))
        self.chk_auto_home_clear.setChecked(bool(getattr(dashboard, "auto_home_on_filter_clear", True)))
        map_lay.addWidget(self.chk_extent)
        map_lay.addWidget(self.chk_auto_zoom)
        map_lay.addWidget(self.chk_auto_home_clear)

        live_group = QGroupBox(tr("sett_live_group", self.lang))
        live_form = QFormLayout(live_group)
        live_form.setSpacing(6)
        self.cb_html_data_mode = QComboBox()
        self.cb_html_data_mode.addItem(tr("data_mode_cached", self.lang), "cached")
        self.cb_html_data_mode.addItem(tr("data_mode_hybrid", self.lang), "hybrid")
        self.cb_html_data_mode.addItem(tr("data_mode_live", self.lang), "live")
        idx_dm = self.cb_html_data_mode.findData(str(getattr(dashboard, "html_data_mode", "cached") or "cached").lower())
        if idx_dm >= 0:
            self.cb_html_data_mode.setCurrentIndex(idx_dm)

        self.sp_live_max_features = QSpinBox()
        self.sp_live_max_features.setRange(0, 1000000)
        self.sp_live_max_features.setSingleStep(5000)
        self.sp_live_max_features.setSpecialValueText("Piiramatu" if str(self.lang).startswith("et") else "Unlimited")
        self.sp_live_max_features.setValue(int(getattr(dashboard, "html_live_max_features", 0) or 0))

        self.sp_auto_refresh_sec = QSpinBox()
        self.sp_auto_refresh_sec.setRange(0, 3600)
        self.sp_auto_refresh_sec.setSingleStep(30)
        self.sp_auto_refresh_sec.setValue(int(getattr(dashboard, "html_auto_refresh_seconds", 0) or 0))

        live_form.addRow(tr("sett_data_mode", self.lang), self.cb_html_data_mode)
        live_form.addRow(tr("sett_live_max_features", self.lang), self.sp_live_max_features)
        live_form.addRow(tr("sett_auto_refresh_sec", self.lang), self.sp_auto_refresh_sec)
        map_lay.addWidget(live_group)

        wfs_group = QGroupBox(tr("sett_wfs_group", self.lang))
        wfs_lay = QVBoxLayout(wfs_group)
        wfs_lay.setSpacing(8)

        lbl_wfs_hint = QLabel(tr("sett_wfs_hint", self.lang))
        lbl_wfs_hint.setWordWrap(True)
        lbl_wfs_hint.setProperty("role", "muted")
        wfs_lay.addWidget(lbl_wfs_hint)

        wfs_btn_bar = QHBoxLayout()
        wfs_btn_bar.setSpacing(6)
        self.btn_add_wfs = QPushButton(tr("sett_wfs_add", self.lang))
        self.btn_add_wfs.setProperty("btnRole", "primary")
        self.btn_add_wfs.clicked.connect(self._on_add_wfs_clicked)

        self.btn_quick_wfs = QPushButton(tr("sett_wfs_presets", self.lang))
        self.btn_quick_wfs.clicked.connect(self._on_quick_presets_clicked)

        self.btn_edit_wfs = QPushButton(tr("sett_wfs_edit", self.lang))
        self.btn_edit_wfs.clicked.connect(self._on_edit_wfs_clicked)

        self.btn_test_wfs = QPushButton(tr("sett_wfs_test", self.lang))
        self.btn_test_wfs.clicked.connect(self._on_test_wfs_clicked)

        self.btn_remove_wfs = QPushButton(tr("sett_wfs_remove", self.lang))
        self.btn_remove_wfs.clicked.connect(self.remove_selected_wfs_service)

        wfs_btn_bar.addWidget(self.btn_add_wfs)
        wfs_btn_bar.addWidget(self.btn_quick_wfs)
        wfs_btn_bar.addWidget(self.btn_edit_wfs)
        wfs_btn_bar.addWidget(self.btn_test_wfs)
        wfs_btn_bar.addWidget(self.btn_remove_wfs)
        wfs_btn_bar.addStretch()
        wfs_lay.addLayout(wfs_btn_bar)

        self.list_wfs_services = QListWidget()
        self.list_wfs_services.setMinimumHeight(170)
        for sig_name, slot in (
            ("currentRowChanged", self._on_wfs_selection_changed),
            ("itemSelectionChanged", self._on_wfs_selection_changed),
            ("itemDoubleClicked", lambda _it: self._on_edit_wfs_clicked()),
        ):
            sig = getattr(self.list_wfs_services, sig_name, None)
            if sig is not None and hasattr(sig, "connect"):
                sig.connect(slot)
        wfs_lay.addWidget(self.list_wfs_services, 1)

        self.lbl_wfs_status = QLabel("")
        self.lbl_wfs_status.setWordWrap(True)
        self.lbl_wfs_status.setProperty("role", "muted")
        wfs_lay.addWidget(self.lbl_wfs_status)

        map_lay.addWidget(wfs_group, 1)
        self._load_initial_wfs_entries()
        self._refresh_wfs_list(select_idx=0 if self._wfs_entries else -1)

        tabs.addTab(tab_map, tr("sett_tab_map", self.lang))
        if tabs.count() > 0:
            tabs.setCurrentIndex(max(0, min(tabs.count() - 1, int(initial_tab or 0))))

        footer = QHBoxLayout()
        footer.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", self.lang))
        btn_cancel.clicked.connect(self.reject)
        btn_save = QPushButton(tr("btn_save", self.lang))
        btn_save.setProperty("btnRole", "primary")
        btn_save.clicked.connect(self._on_save)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_save)
        layout.addLayout(footer)

    @staticmethod
    def _normalize_wfs_url(url: str) -> str:
        return str(url or "").strip().rstrip("/")

    def _wfs_snapshot(self) -> List[Tuple[str, str, str, str]]:
        return [
            (
                str(e.get("name") or "").strip(),
                self._normalize_wfs_url(e.get("url") or ""),
                str(e.get("crs") or "EPSG:3301").strip(),
                str(e.get("authcfg") or "").strip(),
            )
            for e in self._wfs_entries
        ]

    def _load_initial_wfs_entries(self) -> None:
        self._wfs_entries = []
        self._initial_wfs_names = []
        seen_urls = set()

        if self.catalog_manager is not None:
            try:
                cat = self.catalog_manager.load_or_initialize() or {}
            except Exception:
                cat = {}
            for srv in cat.get("servers", []) or []:
                stype = str(srv.get("type") or srv.get("service_type") or "wfs").lower()
                if stype != "wfs":
                    continue
                url = str(srv.get("url") or "").strip()
                norm = self._normalize_wfs_url(url)
                if not url or norm in seen_urls:
                    continue
                seen_urls.add(norm)
                name = str(srv.get("name") or norm).strip()
                self._initial_wfs_names.append(name)
                layers_list = list(srv.get("layers") or [])
                self._wfs_entries.append(
                    {
                        "name": name,
                        "url": url,
                        "type": "wfs",
                        "crs": str(srv.get("crs") or "EPSG:3301"),
                        "authcfg": str(srv.get("authcfg") or ""),
                        "is_basemap": False,
                        "layers": layers_list,
                        "layer_count": len(layers_list) if layers_list else None,
                    }
                )

        preset_by_url = {
            self._normalize_wfs_url(p["url"]): p for p in ESTONIAN_WFS_SERVER_PRESETS
        }
        for raw_url in getattr(self.dashboard, "wfs_catalog_urls", []) or []:
            url = str(raw_url or "").strip()
            norm = self._normalize_wfs_url(url)
            if not url or norm in seen_urls:
                continue
            seen_urls.add(norm)
            preset = preset_by_url.get(norm)
            name = preset["name"] if preset else (norm.split("//", 1)[-1].split("?")[0] or url)
            self._wfs_entries.append(
                {
                    "name": name,
                    "url": url,
                    "type": "wfs",
                    "crs": "EPSG:3301",
                    "authcfg": "",
                    "is_basemap": False,
                    "layers": [],
                    "layer_count": None,
                }
            )
        self._initial_wfs_snapshot = self._wfs_snapshot()

    def _format_wfs_row_label(self, entry: Dict[str, Any]) -> str:
        prefix = "🔒 " if entry.get("authcfg") else ""
        name = str(entry.get("name") or entry.get("url") or "")
        url = str(entry.get("url") or "")
        cnt = entry.get("layer_count")
        cnt_tag = ""
        if cnt is not None:
            cnt_tag = f" ({cnt} kihti)" if self.lang == "et" else f" ({cnt} layers)"
        return f"{prefix}{name}{cnt_tag} — {url}"

    def _refresh_wfs_list(self, select_idx: int = -1) -> None:
        self.list_wfs_services.clear()
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for idx, entry in enumerate(self._wfs_entries):
            item = QListWidgetItem(self._format_wfs_row_label(entry))
            if hasattr(item, "setData"):
                item.setData(role, dict(entry))
            if hasattr(item, "setToolTip"):
                item.setToolTip(
                    f"{entry.get('name', '')}\n{entry.get('url', '')}\nCRS: {entry.get('crs', 'EPSG:3301')}"
                )
            self.list_wfs_services.addItem(item)
        if 0 <= select_idx < len(self._wfs_entries) and hasattr(self.list_wfs_services, "setCurrentRow"):
            self.list_wfs_services.setCurrentRow(select_idx)
        self._on_wfs_selection_changed()

    def _selected_wfs_index(self) -> int:
        row = self.list_wfs_services.currentRow() if hasattr(self.list_wfs_services, "currentRow") else -1
        if 0 <= row < len(self._wfs_entries):
            return int(row)
        return -1

    def _on_wfs_selection_changed(self, *_args: Any) -> None:
        idx = self._selected_wfs_index()
        has_sel = idx >= 0
        for btn in (self.btn_edit_wfs, self.btn_test_wfs, self.btn_remove_wfs):
            if hasattr(btn, "setEnabled"):
                btn.setEnabled(has_sel)
        if has_sel:
            entry = self._wfs_entries[idx]
            auth_txt = entry.get("authcfg") or ("puudub" if self.lang == "et" else "none")
            self.lbl_wfs_status.setStyleSheet("")
            self.lbl_wfs_status.setText(
                f"{entry.get('url', '')} | CRS: {entry.get('crs', 'EPSG:3301')} | Auth: {auth_txt}"
            )
        else:
            self.lbl_wfs_status.setText("")

    def add_wfs_service(self, entry: Dict[str, Any]) -> bool:
        """Add or update a WFS server entry in the settings table and select it."""
        url = str(entry.get("url") or "").strip()
        if not url:
            return False
        norm = self._normalize_wfs_url(url)
        clean_entry = {
            "name": str(entry.get("name") or url).strip(),
            "url": url,
            "type": str(entry.get("type") or "wfs").lower(),
            "crs": str(entry.get("crs") or "EPSG:3301"),
            "authcfg": str(entry.get("authcfg") or ""),
            "is_basemap": False,
            "layers": list(entry.get("layers") or []),
            "layer_count": entry.get("layer_count"),
        }
        for i, existing in enumerate(self._wfs_entries):
            if self._normalize_wfs_url(existing.get("url") or "") == norm:
                self._wfs_entries[i].update(clean_entry)
                self._refresh_wfs_list(select_idx=i)
                return True
        self._wfs_entries.append(clean_entry)
        self._refresh_wfs_list(select_idx=len(self._wfs_entries) - 1)
        return True

    def _on_add_wfs_clicked(self) -> None:
        dlg = ServerSettingsDialog(catalog_mgr=None, server_entry=None, lang=self.lang, parent=self)
        if exec_dialog(dlg) and dlg.result_entry:
            self.add_wfs_service(dlg.result_entry)

    def _on_quick_presets_clicked(self) -> None:
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            for preset in ESTONIAN_WFS_SERVER_PRESETS:
                self.add_wfs_service(preset)
            return
        existing_urls = {self._normalize_wfs_url(e.get("url") or "") for e in self._wfs_entries}
        menu = QMenuCls(self)
        for preset in ESTONIAN_WFS_SERVER_PRESETS:
            is_added = self._normalize_wfs_url(preset["url"]) in existing_urls
            prefix = "✓ " if is_added else "+ "
            act = menu.addAction(f"{prefix}{preset['name']}")
            if act is not None and hasattr(act, "triggered"):
                act.triggered.connect(lambda _chk=False, p=preset: self.add_wfs_service(p))
        pos = None
        if hasattr(self.btn_quick_wfs, "mapToGlobal") and hasattr(self.btn_quick_wfs, "rect"):
            pos = self.btn_quick_wfs.mapToGlobal(self.btn_quick_wfs.rect().bottomLeft())
        exec_menu(menu, pos)

    def _on_edit_wfs_clicked(self) -> None:
        idx = self._selected_wfs_index()
        if idx < 0:
            return
        dlg = ServerSettingsDialog(
            catalog_mgr=None,
            server_entry=self._wfs_entries[idx],
            lang=self.lang,
            parent=self,
        )
        if exec_dialog(dlg) and dlg.result_entry:
            self._wfs_entries[idx] = dict(dlg.result_entry)
            self._refresh_wfs_list(select_idx=idx)

    def _on_test_wfs_clicked(self) -> None:
        idx = self._selected_wfs_index()
        if idx < 0:
            return
        entry = self._wfs_entries[idx]
        url = str(entry.get("url") or "").strip()
        if not url:
            return
        self.lbl_wfs_status.setStyleSheet("")
        self.lbl_wfs_status.setText("⏳ ...")
        if hasattr(QtWidgets, "QApplication") and hasattr(QtWidgets.QApplication, "processEvents"):
            QtWidgets.QApplication.processEvents()
        try:
            layers = OgcConnector.discover_layers(url, service_type=str(entry.get("type") or "wfs"), timeout=12)
            entry["layer_count"] = len(layers)
            self._refresh_wfs_list(select_idx=idx)
            self.lbl_wfs_status.setStyleSheet("color: #34d399; font-weight: 600;")
            self.lbl_wfs_status.setText(
                f"✓ Ühendus toimib! Leitud {len(layers)} kihti."
                if self.lang == "et"
                else f"✓ Connected! Found {len(layers)} layers."
            )
        except Exception as exc:
            self.lbl_wfs_status.setStyleSheet("color: #f87171;")
            self.lbl_wfs_status.setText(f"✗ {exc}")

    def remove_selected_wfs_service(self) -> bool:
        """Remove the currently selected WFS service from the list."""
        idx = self._selected_wfs_index()
        if idx < 0:
            return False
        self._wfs_entries.pop(idx)
        next_idx = min(idx, len(self._wfs_entries) - 1)
        self._refresh_wfs_list(select_idx=next_idx)
        return True

    def _pick_canvas_border_color(self) -> None:
        col = QColorDialog.getColor(QtGui.QColor(self.ed_border_color.text().strip() or "#38bdf8"), self)
        if col.isValid():
            self.ed_border_color.setText(col.name())

    def apply_to_config(self) -> DashboardConfig:
        title_et = self.ed_title_et.text().strip() or self.ed_title_en.text().strip() or "Minu töölaud"
        title_en = self.ed_title_en.text().strip() or title_et
        self.dashboard.title = title_et
        self.dashboard.title_en = title_en
        self.dashboard.subtitle = self.ed_sub_et.text().strip()
        self.dashboard.subtitle_en = self.ed_sub_en.text().strip()
        self.dashboard.language = str(self.cb_lang.currentData() or "et")
        self.dashboard.export_format = str(self.cb_export_format.currentData() or "html")
        self.dashboard.export_mode = str(self.cb_export_mode.currentData() or "compact_single")
        self.dashboard.package_layers_in_export = bool(self.cb_package_layers.currentData() if self.cb_package_layers.currentData() is not None else True)
        self.dashboard.export_tier = str(self.cb_export_tier.currentData() or "full")
        self.dashboard.open_after_export = bool(self.chk_open_after_export.isChecked())
        self.dashboard.canvas_sync_mode = str(self.cb_canvas_sync_mode.currentData() or "dashboard_only")
        self.dashboard.theme = str(self.cb_theme.currentData() or "auto")
        old_w = int(getattr(self.dashboard, "canvas_width", 1280) or 1280)
        old_h = int(getattr(self.dashboard, "canvas_height", 760) or 760)
        new_w = int(self.sp_canvas_w.value())
        new_h = int(self.sp_canvas_h.value())
        if (new_w, new_h) != (old_w, old_h):
            self.dashboard.canvas_preset = "custom"
        self.dashboard.canvas_width = new_w
        self.dashboard.canvas_height = new_h
        self.dashboard.show_design_border = bool(self.chk_border.isChecked())
        self.dashboard.canvas_border_style = str(self.cb_border_style.currentData() or "dashed")
        self.dashboard.canvas_border_color = self.ed_border_color.text().strip() or "#38bdf8"
        self.dashboard.canvas_border_width = int(self.sp_border_width.value())
        self.dashboard.canvas_border_radius = int(self.sp_border_radius.value())
        self.dashboard.dissolve_adjacent_borders = bool(self.chk_dissolve_borders.isChecked())
        self.dashboard.widget_border_style = str(self.cb_widget_border_style.currentData() or "default")
        self.dashboard.show_grid = bool(self.chk_grid.isChecked())
        if hasattr(self, "cb_grid_step"):
            self.dashboard.grid_size = int(self.cb_grid_step.currentData() or 20)
        self.dashboard.snap_to_grid = bool(self.chk_snap.isChecked())
        self.dashboard.filter_by_map_extent = bool(self.chk_extent.isChecked())
        self.dashboard.auto_zoom_on_filter = bool(self.chk_auto_zoom.isChecked())
        self.dashboard.auto_home_on_filter_clear = bool(self.chk_auto_home_clear.isChecked())
        self.dashboard.html_data_mode = str(self.cb_html_data_mode.currentData() or "cached")
        self.dashboard.html_live_max_features = int(self.sp_live_max_features.value())
        self.dashboard.html_auto_refresh_seconds = int(self.sp_auto_refresh_sec.value())

        urls: List[str] = []
        seen_urls = set()
        for entry in self._wfs_entries:
            u = str(entry.get("url") or "").strip()
            norm = self._normalize_wfs_url(u)
            if u and norm not in seen_urls:
                seen_urls.add(norm)
                urls.append(u)
        self.dashboard.wfs_catalog_urls = urls

        if self.catalog_manager is not None and self._wfs_snapshot() != self._initial_wfs_snapshot:
            current_names = {str(e.get("name") or "").strip() for e in self._wfs_entries}
            for old_name in self._initial_wfs_names:
                if old_name and old_name not in current_names:
                    try:
                        self.catalog_manager.remove_server(old_name)
                    except Exception:
                        pass
            for entry in self._wfs_entries:
                try:
                    self.catalog_manager.add_or_update_server(
                        name=str(entry.get("name") or entry.get("url") or ""),
                        url=str(entry.get("url") or ""),
                        service_type=str(entry.get("type") or "wfs"),
                        crs=str(entry.get("crs") or "EPSG:3301"),
                        authcfg=str(entry.get("authcfg") or ""),
                        is_basemap=bool(entry.get("is_basemap", False)),
                    )
                except Exception:
                    pass
            self.catalog_changed = True
        return self.dashboard

    def _on_save(self) -> None:
        self.apply_to_config()
        self.accept()


class _ModelDesignerCanvas(QWidget):
    """QGIS Model Designer-style graphical node & Bezier connection canvas."""

    NODE_W = 190
    NODE_H = 48
    PORT_R = 6

    def __init__(
        self,
        dashboard: DashboardConfig,
        connections: List[WidgetConnectionConfig],
        lang: str = "et",
        on_changed: Optional[Callable[[], None]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.connections = connections
        self.lang = lang
        self.on_changed = on_changed
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self._swimlanes: List[Dict[str, Any]] = []
        self.selected_pair: Optional[Tuple[str, str]] = None
        self._dragging_node: Optional[str] = None
        self._drag_offset = QPointF(0, 0)
        self._wiring_source: Optional[str] = None
        self._wire_cursor = QPointF(0, 0)
        self._selected_close_rect: Optional[Any] = None
        self.setMinimumSize(680, 340)
        self.setMouseTracking(True)
        try:
            self.setFocusPolicy(qt_enum(Qt, "FocusPolicy", "StrongFocus"))
        except Exception:
            pass
        self.rebuild_nodes()

    def _page_meta_map(self) -> Dict[str, Tuple[str, str]]:
        palette = ["#0078D4", "#10B981", "#F59E0B", "#A855F7", "#EC4899", "#06B6D4"]
        out: Dict[str, Tuple[str, str]] = {}
        pages = list(getattr(self.dashboard, "pages", []) or [])
        for idx, pg in enumerate(pages):
            ptitle = pg.title_en if (self.lang == "en" and getattr(pg, "title_en", "")) else pg.title
            col = str(getattr(pg, "color", "") or palette[idx % len(palette)])
            out[pg.id] = (f"{getattr(pg, 'icon', '📄')} {ptitle}", col)
        return out

    def _node_items(self) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        pmeta = self._page_meta_map()
        multi_pages = len(pmeta) > 1
        first_page_id = next(iter(pmeta.keys()), "page_1")
        for s in self.dashboard.slicers:
            title = s.title_en if (self.lang == "en" and getattr(s, "title_en", "")) else s.title
            pid = getattr(s, "page_id", first_page_id) or first_page_id
            p_lbl, p_col = pmeta.get(pid, ("📄 Leht 1", "#38bdf8"))
            is_glob = bool(getattr(s, "is_global", False))
            badge = "🌐 Atlas" if is_glob else (p_lbl if multi_pages else "")
            items.append({
                "id": s.id,
                "label": f"🔍 {title}",
                "sub": f"{s.layer_name} · {s.field_name}".strip(" ·"),
                "kind": "slicer",
                "can_source": True,
                "can_target": False,
                "layer": s.layer_name,
                "page_id": pid,
                "is_global": is_glob,
                "page_badge": badge,
                "page_color": "#f59e0b" if is_glob else p_col,
                "multi_pages": multi_pages or is_glob,
            })
        has_map_widget = any(w.widget_type == "map" for w in self.dashboard.widgets)
        icons = {"map": "🗺️", "kpi": "🔢", "bar": "📊", "pie": "🥧", "line": "📈", "scatter": "🔵", "table": "📋"}
        for w in self.dashboard.widgets:
            title = w.title_en if (self.lang == "en" and getattr(w, "title_en", "")) else w.title
            pid = getattr(w, "page_id", first_page_id) or first_page_id
            p_lbl, p_col = pmeta.get(pid, ("📄 Leht 1", "#38bdf8"))
            items.append({
                "id": w.id,
                "label": f"{icons.get(w.widget_type, '📊')} {title}",
                "sub": w.layer_name or w.widget_type.upper(),
                "kind": w.widget_type,
                "can_source": w.widget_type in ("bar", "pie", "line", "scatter", "table"),
                "can_target": True,
                "layer": w.layer_name,
                "page_id": pid,
                "is_global": False,
                "page_badge": p_lbl if multi_pages else "",
                "page_color": p_col,
                "multi_pages": multi_pages,
            })
        if not has_map_widget or any(c.target_id == "__map__" for c in self.connections):
            p_lbl, p_col = next(iter(pmeta.values()), ("📄 Leht 1", "#22c55e"))
            items.append({
                "id": "__map__",
                "label": f"🗺️ {tr('map_widget_title', self.lang)}",
                "sub": "Leaflet / QGIS",
                "kind": "map",
                "can_source": False,
                "can_target": True,
                "layer": "",
                "page_id": first_page_id,
                "is_global": False,
                "page_badge": p_lbl if multi_pages else "",
                "page_color": p_col,
                "multi_pages": multi_pages,
            })
        return items

    def _update_canvas_bounds(self, min_w: int = 720, min_h: int = 340) -> Tuple[int, int]:
        max_r = float(min_w)
        max_b = float(min_h)
        for n in self.nodes.values():
            max_r = max(max_r, float(n.get("x", 0.0)) + float(self.NODE_W) + 120.0)
            max_b = max(max_b, float(n.get("y", 0.0)) + float(self.NODE_H) + 80.0)
        for sw in self._swimlanes:
            max_r = max(max_r, float(sw.get("x", 0.0)) + float(sw.get("w", 0.0)) + 40.0)
            max_b = max(max_b, float(sw.get("y", 0.0)) + float(sw.get("h", 0.0)) + 40.0)
        req_w = max(min_w, int(round(max_r)))
        req_h = max(min_h, int(round(max_b)))
        self.setMinimumSize(req_w, req_h)
        if hasattr(self, "resize"):
            self.resize(req_w, req_h)
        return req_w, req_h

    def auto_organize_layout(self) -> None:
        """Arrange nodes into clean Atlas / per-page swimlanes with zero overlap (#15)."""
        items = list(self.nodes.values())
        if not items:
            self._swimlanes = []
            self._update_canvas_bounds()
            self.update()
            return
        pmeta = self._page_meta_map()
        pages = list(getattr(self.dashboard, "pages", []) or [])
        multi_pages = len(pages) > 1 or any(bool(n.get("is_global")) for n in items)
        self._swimlanes = []

        if not multi_pages:
            slicers = [n for n in items if n["kind"] == "slicer"]
            mid = [n for n in items if n["kind"] not in ("slicer", "map")]
            maps = [n for n in items if n["kind"] == "map"]
            max_per_col = 6
            for idx, n in enumerate(slicers):
                col = idx // max_per_col
                row = idx % max_per_col
                n["x"] = 24.0 + col * (self.NODE_W + 24.0)
                n["y"] = 22.0 + row * 66.0
            slicer_cols = max(1, (len(slicers) + max_per_col - 1) // max_per_col)
            mid_x0 = 24.0 + slicer_cols * (self.NODE_W + 40.0)
            for idx, n in enumerate(mid):
                col = idx // max_per_col
                row = idx % max_per_col
                n["x"] = mid_x0 + col * (self.NODE_W + 24.0)
                n["y"] = 22.0 + row * 66.0
            mid_cols = max(1, (len(mid) + max_per_col - 1) // max_per_col) if mid else 0
            map_x0 = mid_x0 + mid_cols * (self.NODE_W + 40.0)
            for idx, n in enumerate(maps):
                n["x"] = map_x0
                n["y"] = 22.0 + idx * 66.0
            self._update_canvas_bounds()
            self.update()
            return

        cur_y = 14.0
        globals_list = [n for n in items if n["kind"] == "slicer" and n.get("is_global")]
        if globals_list:
            per_row = 3
            rows_cnt = max(1, (len(globals_list) + per_row - 1) // per_row)
            lane_h = 34.0 + rows_cnt * 62.0
            lane_w = max(680.0, 24.0 + min(len(globals_list), per_row) * (self.NODE_W + 28.0) + 16.0)
            for idx, n in enumerate(globals_list):
                r = idx // per_row
                c = idx % per_row
                n["x"] = 28.0 + c * (self.NODE_W + 28.0)
                n["y"] = cur_y + 30.0 + r * 62.0
            self._swimlanes.append({
                "label": "🌐 Atlas (" + ("Globaalsed filtrid" if self.lang == "et" else "Global Filters") + ")",
                "color": "#f59e0b",
                "x": 12.0,
                "y": cur_y,
                "w": lane_w,
                "h": lane_h,
            })
            cur_y += lane_h + 14.0

        placed_ids = {n["id"] for n in globals_list}
        page_order = [pg.id for pg in pages]
        for n in items:
            if n["id"] not in placed_ids and n.get("page_id") not in page_order:
                page_order.append(str(n.get("page_id") or "page_1"))

        for pid in page_order:
            p_nodes = [n for n in items if n["id"] not in placed_ids and str(n.get("page_id") or "") == pid]
            if not p_nodes:
                continue
            p_lbl, p_col = pmeta.get(pid, (f"📄 {pid}", "#38bdf8"))
            p_slicers = [n for n in p_nodes if n["kind"] == "slicer"]
            p_mid = [n for n in p_nodes if n["kind"] not in ("slicer", "map")]
            p_maps = [n for n in p_nodes if n["kind"] == "map"]

            max_per_col = 4
            s_cols = max(1, (len(p_slicers) + max_per_col - 1) // max_per_col) if p_slicers else 0
            m_cols = max(1, (len(p_mid) + max_per_col - 1) // max_per_col) if p_mid else 0
            mp_cols = max(1, (len(p_maps) + max_per_col - 1) // max_per_col) if p_maps else 0

            x_cursor = 28.0
            for idx, n in enumerate(p_slicers):
                c = idx // max_per_col
                r = idx % max_per_col
                n["x"] = x_cursor + c * (self.NODE_W + 22.0)
                n["y"] = cur_y + 32.0 + r * 62.0
            if s_cols:
                x_cursor += s_cols * (self.NODE_W + 34.0)

            for idx, n in enumerate(p_mid):
                c = idx // max_per_col
                r = idx % max_per_col
                n["x"] = x_cursor + c * (self.NODE_W + 22.0)
                n["y"] = cur_y + 32.0 + r * 62.0
            if m_cols:
                x_cursor += m_cols * (self.NODE_W + 34.0)

            for idx, n in enumerate(p_maps):
                c = idx // max_per_col
                r = idx % max_per_col
                n["x"] = x_cursor + c * (self.NODE_W + 22.0)
                n["y"] = cur_y + 32.0 + r * 62.0
            if mp_cols:
                x_cursor += mp_cols * (self.NODE_W + 22.0)

            lane_rows = max(
                1,
                min(max_per_col, len(p_slicers)) if p_slicers else 0,
                min(max_per_col, len(p_mid)) if p_mid else 0,
                min(max_per_col, len(p_maps)) if p_maps else 0,
            )
            lane_h = 38.0 + lane_rows * 62.0
            lane_w = max(680.0, x_cursor + 12.0)
            self._swimlanes.append({
                "label": p_lbl,
                "color": p_col,
                "x": 12.0,
                "y": cur_y,
                "w": lane_w,
                "h": lane_h,
            })
            for n in p_nodes:
                placed_ids.add(n["id"])
            cur_y += lane_h + 14.0

        self._update_canvas_bounds()
        self.update()

    def rebuild_nodes(self) -> None:
        old_pos = {nid: (n["x"], n["y"]) for nid, n in self.nodes.items()}
        self.nodes.clear()
        items = self._node_items()
        slicers = [it for it in items if it["kind"] == "slicer"]
        mid = [it for it in items if it["kind"] not in ("slicer", "map")]
        maps = [it for it in items if it["kind"] == "map"]

        def _place_col(col_items: List[Dict[str, Any]], x_pos: float) -> None:
            for idx, it in enumerate(col_items):
                px, py = old_pos.get(it["id"], (x_pos, 22.0 + idx * 66.0))
                it["x"] = px
                it["y"] = py
                self.nodes[it["id"]] = it

        _place_col(slicers, 26.0)
        _place_col(mid, 255.0)
        _place_col(maps, 490.0)
        if not old_pos and len(getattr(self.dashboard, "pages", []) or []) > 1:
            self.auto_organize_layout()
            return
        self._update_canvas_bounds()
        self.update()

    def _port_in_pos(self, nid: str) -> QPointF:
        n = self.nodes[nid]
        return QPointF(n["x"], n["y"] + self.NODE_H * 0.5)

    def _port_out_pos(self, nid: str) -> QPointF:
        n = self.nodes[nid]
        return QPointF(n["x"] + self.NODE_W, n["y"] + self.NODE_H * 0.5)

    @staticmethod
    def _cubic_pt(p0: QPointF, c1: QPointF, c2: QPointF, p1: QPointF, t: float) -> QPointF:
        mt = 1.0 - t
        x = mt ** 3 * p0.x() + 3 * mt ** 2 * t * c1.x() + 3 * mt * t ** 2 * c2.x() + t ** 3 * p1.x()
        y = mt ** 3 * p0.y() + 3 * mt ** 2 * t * c1.y() + 3 * mt * t ** 2 * c2.y() + t ** 3 * p1.y()
        return QPointF(x, y)

    def _hit_port_out(self, pt: QPointF) -> Optional[str]:
        for nid, n in self.nodes.items():
            if not n.get("can_source"):
                continue
            p = self._port_out_pos(nid)
            if abs(pt.x() - p.x()) <= 11 and abs(pt.y() - p.y()) <= 11:
                return nid
        return None

    def _hit_port_in(self, pt: QPointF, exclude: Optional[str] = None) -> Optional[str]:
        for nid, n in self.nodes.items():
            if nid == exclude or not n.get("can_target"):
                continue
            p = self._port_in_pos(nid)
            if abs(pt.x() - p.x()) <= 14 and abs(pt.y() - p.y()) <= 14:
                return nid
            if (n["x"] <= pt.x() <= n["x"] + self.NODE_W) and (n["y"] <= pt.y() <= n["y"] + self.NODE_H):
                return nid
        return None

    def _hit_node(self, pt: QPointF) -> Optional[str]:
        for nid in reversed(list(self.nodes.keys())):
            n = self.nodes[nid]
            if n["x"] <= pt.x() <= n["x"] + self.NODE_W and n["y"] <= pt.y() <= n["y"] + self.NODE_H:
                return nid
        return None

    def _hit_wire(self, pt: QPointF) -> Optional[Tuple[str, str]]:
        for conn in self.connections:
            if not getattr(conn, "enabled", True):
                continue
            if conn.source_id not in self.nodes or conn.target_id not in self.nodes:
                continue
            p0 = self._port_out_pos(conn.source_id)
            p1 = self._port_in_pos(conn.target_id)
            dx = max(48.0, abs(p1.x() - p0.x()) * 0.45)
            c1 = QPointF(p0.x() + dx, p0.y())
            c2 = QPointF(p1.x() - dx, p1.y())
            for step in range(1, 20):
                bp = self._cubic_pt(p0, c1, c2, p1, step / 20.0)
                if abs(bp.x() - pt.x()) <= 8 and abs(bp.y() - pt.y()) <= 8:
                    return (conn.source_id, conn.target_id)
        return None

    def paintEvent(self, _event: Any) -> None:
        if QPainter is None:
            return
        p = QPainter(self)
        try:
            aa = qt_enum(QPainter, "RenderHint", "Antialiasing")
            if aa is not None:
                p.setRenderHint(aa)
        except Exception:
            pass

        w = self.width()
        h = self.height()
        p.fillRect(0, 0, w, h, QColor("#0b1220"))

        # Subtle dot grid matching QGIS Model Designer
        p.setPen(QPen(QColor(148, 163, 184, 38), 1))
        for gx in range(16, w, 24):
            for gy in range(16, h, 24):
                p.drawPoint(gx, gy)

        # Page / Atlas swimlane guides (#15)
        for sw in getattr(self, "_swimlanes", []) or []:
            col = QColor(str(sw.get("color") or "#38bdf8"))
            fill = QColor(col)
            fill.setAlpha(18)
            border = QColor(col)
            border.setAlpha(95)
            p.setBrush(QBrush(fill))
            p.setPen(QPen(border, 1))
            sw_r = QRectF(float(sw["x"]), float(sw["y"]), max(float(sw["w"]), float(w - 24)), float(sw["h"]))
            p.drawRoundedRect(sw_r, 8, 8)
            p.setPen(QPen(col, 1))
            p.drawText(QRectF(float(sw["x"]) + 10.0, float(sw["y"]) + 4.0, 420.0, 20.0), 0, str(sw.get("label") or ""))

        action_colors = {
            "filter_and_zoom": QColor("#38bdf8"),
            "filter": QColor("#22c55e"),
            "zoom_only": QColor("#f59e0b"),
        }

        def _draw_wire(p0: QPointF, p1: QPointF, col: QColor, selected: bool = False, dashed: bool = False) -> None:
            dx = max(48.0, abs(p1.x() - p0.x()) * 0.45)
            c1 = QPointF(p0.x() + dx, p0.y())
            c2 = QPointF(p1.x() - dx, p1.y())
            if QPainterPath is not None:
                path = QPainterPath(p0)
                path.cubicTo(c1, c2, p1)
                pen = QPen(col, 3.2 if selected else 2.2)
                if dashed:
                    dash_st = qt_enum(Qt, "PenStyle", "DashLine")
                    if dash_st is not None:
                        pen.setStyle(dash_st)
                p.setPen(pen)
                p.setBrush(qt_enum(Qt, "BrushStyle", "NoBrush"))
                p.drawPath(path)
            else:
                p.setPen(QPen(col, 2))
                p.drawLine(p0.toPoint(), p1.toPoint())

            # Arrowhead at p1
            p.setBrush(QBrush(col))
            p.setPen(QPen(col, 1))
            tri = QPolygonF([
                p1,
                QPointF(p1.x() - 9, p1.y() - 5),
                QPointF(p1.x() - 9, p1.y() + 5),
            ])
            p.drawPolygon(tri)

            if selected:
                mid = self._cubic_pt(p0, c1, c2, p1, 0.5)
                cr = QRectF(mid.x() - 9.0, mid.y() - 9.0, 18.0, 18.0)
                self._selected_close_rect = cr
                p.setBrush(QBrush(QColor("#ef4444")))
                p.setPen(QPen(QColor("#ffffff"), 1.5))
                p.drawEllipse(cr)
                align_c = qt_enum(Qt, "AlignmentFlag", "AlignCenter")
                p.drawText(cr, align_c, "×")

        self._selected_close_rect = None
        for conn in self.connections:
            if not getattr(conn, "enabled", True):
                continue
            if conn.source_id not in self.nodes or conn.target_id not in self.nodes:
                continue
            col = action_colors.get(conn.action or "filter_and_zoom", QColor("#38bdf8"))
            is_sel = self.selected_pair == (conn.source_id, conn.target_id)
            if is_sel:
                col = QColor("#f43f5e")
            _draw_wire(self._port_out_pos(conn.source_id), self._port_in_pos(conn.target_id), col, selected=is_sel)

        if self._wiring_source and self._wiring_source in self.nodes:
            _draw_wire(self._port_out_pos(self._wiring_source), self._wire_cursor, QColor("#38bdf8"), dashed=True)

        kind_accents = {
            "slicer": QColor("#38bdf8"),
            "map": QColor("#22c55e"),
            "table": QColor("#a855f7"),
            "kpi": QColor("#f59e0b"),
        }
        elide_right = qt_enum(Qt, "TextElideMode", "ElideRight")
        for nid, n in self.nodes.items():
            x, y = float(n["x"]), float(n["y"])
            rect = QRectF(x, y, self.NODE_W, self.NODE_H)
            accent = kind_accents.get(n["kind"], QColor("#60a5fa"))
            page_col_hex = str(n.get("page_color") or "")
            border_col = QColor(page_col_hex) if (n.get("multi_pages") and page_col_hex) else accent

            p.setBrush(QBrush(QColor("#1e293b")))
            p.setPen(QPen(border_col, 2.0))
            p.drawRoundedRect(rect, 8, 8)

            # Top accent bar tinted by page color when multiple pages exist (#18)
            p.setBrush(QBrush(border_col))
            p.setPen(QPen(border_col, 1))
            p.drawRoundedRect(QRectF(x, y, self.NODE_W, 5), 3, 3)

            badge = str(n.get("page_badge") or "").strip()
            title_w = self.NODE_W - (76 if badge else 20)
            p.setPen(QPen(QColor("#f8fafc"), 1))
            lbl = n["label"]
            max_ch = 16 if badge else 23
            if len(lbl) > max_ch:
                lbl = lbl[:max_ch - 1] + "…"
            p.drawText(QRectF(x + 10, y + 7, title_w, 20), 0, lbl)

            if badge:
                b_txt = badge[:11] + "…" if len(badge) > 12 else badge
                b_rect = QRectF(x + self.NODE_W - 68, y + 7, 60, 15)
                b_fill = QColor(border_col)
                b_fill.setAlpha(45)
                p.setBrush(QBrush(b_fill))
                p.setPen(QPen(border_col, 1))
                p.drawRoundedRect(b_rect, 4, 4)
                p.setPen(QPen(QColor("#f8fafc"), 1))
                align_c = qt_enum(Qt, "AlignmentFlag", "AlignCenter")
                p.drawText(b_rect, align_c, b_txt)

            p.setPen(QPen(QColor("#94a3b8"), 1))
            sub = n["sub"]
            if len(sub) > 25:
                sub = sub[:24] + "…"
            p.drawText(QRectF(x + 10, y + 26, self.NODE_W - 20, 18), 0, sub)

            if n.get("can_target"):
                pi = self._port_in_pos(nid)
                p.setBrush(QBrush(QColor("#0f172a")))
                p.setPen(QPen(accent, 2))
                p.drawEllipse(pi, self.PORT_R, self.PORT_R)

            if n.get("can_source"):
                po = self._port_out_pos(nid)
                p.setBrush(QBrush(accent))
                p.setPen(QPen(QColor("#f8fafc"), 1.5))
                p.drawEllipse(po, self.PORT_R, self.PORT_R)
        p.end()

    def mousePressEvent(self, event: Any) -> None:
        try:
            pos = event.position() if hasattr(event, "position") else QPointF(event.x(), event.y())
        except Exception:
            pos = QPointF(0, 0)
        if self.selected_pair and self._selected_close_rect is not None and self._selected_close_rect.contains(pos):
            self.dashboard.remove_connection(str(self.selected_pair[0]), str(self.selected_pair[1]))
            self.selected_pair = None
            self.connections[:] = list(self.dashboard.widget_connections)
            if self.on_changed:
                self.on_changed()
            self.update()
            return
        src_port = self._hit_port_out(pos)
        if src_port:
            self._wiring_source = src_port
            self._wire_cursor = pos
            self.update()
            return
        nid = self._hit_node(pos)
        if nid:
            self._dragging_node = nid
            self._drag_offset = QPointF(pos.x() - self.nodes[nid]["x"], pos.y() - self.nodes[nid]["y"])
            self.selected_pair = None
            self.update()
            return
        self.selected_pair = self._hit_wire(pos)
        if self.on_changed:
            self.on_changed()
        self.update()

    def mouseMoveEvent(self, event: Any) -> None:
        try:
            pos = event.position() if hasattr(event, "position") else QPointF(event.x(), event.y())
        except Exception:
            pos = QPointF(0, 0)
        if self._wiring_source:
            self._wire_cursor = pos
            self.update()
            return
        if self._dragging_node and self._dragging_node in self.nodes:
            nx = max(12.0, pos.x() - self._drag_offset.x())
            ny = max(12.0, pos.y() - self._drag_offset.y())
            self.nodes[self._dragging_node]["x"] = nx
            self.nodes[self._dragging_node]["y"] = ny
            self._update_canvas_bounds()
            self.update()

    def mouseReleaseEvent(self, event: Any) -> None:
        try:
            pos = event.position() if hasattr(event, "position") else QPointF(event.x(), event.y())
        except Exception:
            pos = QPointF(0, 0)
        if self._wiring_source:
            tgt = self._hit_port_in(pos, exclude=self._wiring_source)
            if tgt:
                self.dashboard.add_or_update_connection(self._wiring_source, tgt, action="filter_and_zoom")
                self.connections[:] = list(self.dashboard.widget_connections)
                self.selected_pair = (self._wiring_source, tgt)
                if self.on_changed:
                    self.on_changed()
            self._wiring_source = None
            self.update()
            return
        self._dragging_node = None

    def keyPressEvent(self, event: Any) -> None:
        try:
            del_k = qt_enum(Qt, "Key", "Key_Delete")
            bk_k = qt_enum(Qt, "Key", "Key_Backspace")
            if event.key() in (del_k, bk_k) and self.selected_pair:
                self.dashboard.remove_connection(str(self.selected_pair[0]), str(self.selected_pair[1]))
                self.selected_pair = None
                self.connections[:] = list(self.dashboard.widget_connections)
                if self.on_changed:
                    self.on_changed()
                self.update()
                event.accept()
                return
        except Exception:
            pass
        super().keyPressEvent(event)

    def contextMenuEvent(self, event: Any) -> None:
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            return
        try:
            pos = event.pos()
            pt = QPointF(pos.x(), pos.y())
        except Exception:
            return
        hit_pair = self._hit_wire(pt) or self.selected_pair
        if not hit_pair:
            return
        self.selected_pair = hit_pair
        self.update()
        src_id, tgt_id = str(hit_pair[0]), str(hit_pair[1])
        menu = QMenuCls(self)
        edit_menu = menu.addMenu(tr("ctx_edit_settings", self.lang))
        act_fz = edit_menu.addAction(tr("conn_act_filter_zoom", self.lang))
        act_f = edit_menu.addAction(tr("conn_act_filter", self.lang))
        act_z = edit_menu.addAction(tr("conn_act_zoom", self.lang))
        act_rm = menu.addAction(tr("ctx_remove", self.lang))
        chosen = exec_menu(menu, event.globalPos())
        if chosen in (act_fz, act_f, act_z):
            new_act = "filter_and_zoom" if chosen == act_fz else ("filter" if chosen == act_f else "zoom_only")
            self.dashboard.add_or_update_connection(src_id, tgt_id, action=new_act)
            self.connections[:] = list(self.dashboard.widget_connections)
            if self.on_changed:
                self.on_changed()
            self.update()
        elif chosen == act_rm:
            self.dashboard.remove_connection(src_id, tgt_id)
            self.selected_pair = None
            self.connections[:] = list(self.dashboard.widget_connections)
            if self.on_changed:
                self.on_changed()
            self.update()


class WidgetConnectionsDialog(QDialog):
    """QGIS Model Designer-style visual graph & rule editor for connecting filters, widgets, and maps."""

    def __init__(
        self,
        dashboard: DashboardConfig,
        focus_node_id: Optional[str] = None,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.dashboard.sync_widget_connections()
        self.focus_node_id = focus_node_id
        self.lang = lang
        self._work_connections: List[WidgetConnectionConfig] = [
            WidgetConnectionConfig(
                id=c.id,
                source_id=c.source_id,
                target_id=c.target_id,
                action=c.action or "filter_and_zoom",
                enabled=bool(getattr(c, "enabled", True)),
            )
            for c in dashboard.widget_connections
        ]
        # Backup original connections in case user clicks Cancel
        self._orig_connections = list(self._work_connections)

        self.setWindowTitle(tr("dlg_model_conns_title", lang))
        _apply_laptop_friendly_bounds(self, 820, 620, min_w=480, min_h=380)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        root = QVBoxLayout(self)
        root.setSpacing(10)

        hint = QLabel(tr("lbl_model_canvas_hint", lang))
        hint.setWordWrap(True)
        root.addWidget(hint)

        pages_list = list(getattr(self.dashboard, "pages", []) or [])
        if len(pages_list) > 1:
            pg_legend = QHBoxLayout()
            pg_legend.setSpacing(6)
            for idx_p, pg in enumerate(pages_list):
                ptitle = pg.title_en if (lang == "en" and pg.title_en) else pg.title
                pcol = pg.color or "#38bdf8"
                pill = QLabel(f"{pg.icon} {ptitle}")
                pill.setStyleSheet(
                    f"background: rgba(15,23,42,0.75); border: 1px solid {pcol}; "
                    f"border-left: 4px solid {pcol}; border-radius: 5px; padding: 2px 8px; font-size: 11px;"
                )
                pg_legend.addWidget(pill)
            atlas_pill = QLabel("🌐 Atlas")
            atlas_pill.setStyleSheet(
                "background: rgba(245,158,11,0.12); border: 1px solid #f59e0b; "
                "border-radius: 5px; padding: 2px 8px; font-size: 11px; color: #fbbf24;"
            )
            pg_legend.addWidget(atlas_pill)
            pg_legend.addStretch()
            root.addLayout(pg_legend)

        self.canvas = _ModelDesignerCanvas(
            self.dashboard,
            self.dashboard.widget_connections,
            lang=lang,
            on_changed=self._refresh_list,
        )
        self.canvas_scroll = QScrollArea()
        self.canvas_scroll.setWidgetResizable(False)
        self.canvas_scroll.setWidget(self.canvas)
        root.addWidget(self.canvas_scroll, 1)

        # Quick add bar
        ctrl = QHBoxLayout()
        self.cb_source = QComboBox()
        self.cb_target = QComboBox()
        self.cb_action = QComboBox()
        self.cb_action.addItem(tr("conn_act_filter_zoom", lang), "filter_and_zoom")
        self.cb_action.addItem(tr("conn_act_filter", lang), "filter")
        self.cb_action.addItem(tr("conn_act_zoom", lang), "zoom_only")

        self.btn_add = QPushButton(tr("btn_add_widget_conn", lang))
        self.btn_add.setProperty("btnRole", "primary")
        self.btn_add.clicked.connect(self._on_add_connection)

        self.btn_auto_organize = QPushButton(tr("btn_auto_organize_atlas", lang))
        self.btn_auto_organize.clicked.connect(self.canvas.auto_organize_layout)

        self.btn_auto = QPushButton(tr("btn_auto_connect_all", lang))
        self._auto_menu = QMenu(self.btn_auto)
        for mode_id, lbl_key in (
            ("per_page_match", "autoconn_per_page_match"),
            ("per_page_all", "autoconn_per_page_all"),
            ("active_page_match", "autoconn_active_page_match"),
            ("all_pages_match", "autoconn_all_pages_match"),
            ("all_legacy", "autoconn_all_legacy"),
        ):
            act_m = QAction(tr(lbl_key, lang), self._auto_menu)
            act_m.triggered.connect(lambda _c=False, m=mode_id: self.auto_connect_matching(mode=m))
            self._auto_menu.addAction(act_m)
        self.btn_auto.setMenu(self._auto_menu)

        self.btn_remove = QPushButton(tr("btn_remove", lang))
        self.btn_remove.clicked.connect(self._on_remove_selected)

        ctrl.addWidget(QLabel(tr("lbl_conn_source", lang)))
        ctrl.addWidget(self.cb_source, 1)
        ctrl.addWidget(QLabel("→"))
        ctrl.addWidget(QLabel(tr("lbl_conn_target", lang)))
        ctrl.addWidget(self.cb_target, 1)
        ctrl.addWidget(QLabel(tr("lbl_conn_action", lang)))
        ctrl.addWidget(self.cb_action)
        ctrl.addWidget(self.btn_add)
        root.addLayout(ctrl)

        self.list_conns = DragFieldListWidget(
            role_mode="connections",
            lang=lang,
            on_remove_row=self._remove_connection_at_row,
            context_menu_cb=self._on_conn_list_context_menu,
        )
        self.list_conns.setMaximumHeight(135)
        self.list_conns.currentRowChanged.connect(self._on_list_row_selected)
        root.addWidget(self.list_conns)

        footer = QHBoxLayout()
        footer.addWidget(self.btn_auto)
        footer.addWidget(self.btn_auto_organize)
        footer.addWidget(self.btn_remove)
        footer.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", lang))
        btn_cancel.clicked.connect(self._on_cancel)
        btn_save = QPushButton(tr("btn_save", lang))
        btn_save.setProperty("btnRole", "primary")
        btn_save.clicked.connect(self.accept)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_save)
        root.addLayout(footer)

        self._populate_combos()
        self._refresh_list()

    def _populate_combos(self) -> None:
        self.cb_source.clear()
        self.cb_target.clear()
        for nid, n in self.canvas.nodes.items():
            badge = f" [{n['page_badge']}]" if n.get("page_badge") else ""
            disp = f"{n['label']}{badge}"
            if n.get("can_source"):
                self.cb_source.addItem(disp, nid)
            if n.get("can_target"):
                self.cb_target.addItem(disp, nid)
        if self.focus_node_id:
            idx = self.cb_source.findData(self.focus_node_id)
            if idx >= 0:
                self.cb_source.setCurrentIndex(idx)

    def _node_label(self, nid: str) -> str:
        n = self.canvas.nodes.get(nid)
        if not n:
            return nid
        badge = f" [{n['page_badge']}]" if n.get("page_badge") else ""
        return f"{n['label']}{badge}"

    def _action_label(self, act: str) -> str:
        mapping = {
            "filter_and_zoom": tr("conn_act_filter_zoom", self.lang),
            "filter": tr("conn_act_filter", self.lang),
            "zoom_only": tr("conn_act_zoom", self.lang),
        }
        return mapping.get(act, act)

    def _refresh_list(self) -> None:
        self.list_conns.clear()
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for c in self.dashboard.widget_connections:
            if not getattr(c, "enabled", True):
                continue
            txt = f"{self._node_label(c.source_id)}   →   {self._node_label(c.target_id)}   [{self._action_label(c.action)}]"
            it = QListWidgetItem(txt)
            it.setData(role, (c.source_id, c.target_id))
            self.list_conns.addItem(it)

    def _on_add_connection(self) -> None:
        src = str(self.cb_source.currentData() or "")
        tgt = str(self.cb_target.currentData() or "")
        act = str(self.cb_action.currentData() or "filter_and_zoom")
        if src and tgt and src != tgt:
            self.dashboard.add_or_update_connection(src, tgt, action=act)
            self.canvas.connections[:] = list(self.dashboard.widget_connections)
            self.canvas.update()
            self._refresh_list()

    def _layers_match(self, src_layer: str, tgt_widget: Any) -> bool:
        src = str(src_layer or "").strip().lower()
        if not src or src == "*":
            return True
        if tgt_widget is None:
            return True
        tgt_layers: set = set()
        for ml in (getattr(tgt_widget, "map_layers", []) or []):
            if ml:
                tgt_layers.add(str(ml).strip().lower())
        if getattr(tgt_widget, "layer_name", ""):
            ln_val = str(tgt_widget.layer_name).strip().lower()
            if ln_val and (ln_val != "*" or not tgt_layers):
                tgt_layers.add(ln_val)
        if getattr(tgt_widget, "spatial_join_layer", ""):
            tgt_layers.add(str(tgt_widget.spatial_join_layer).strip().lower())
        tgt_layers.discard("")
        if not tgt_layers or "*" in tgt_layers:
            return True
        if src in tgt_layers:
            return True
        for j in (getattr(self.dashboard, "joins", []) or []):
            ll = str(getattr(j, "left_layer", "") or "").strip().lower()
            rl = str(getattr(j, "right_layer", "") or "").strip().lower()
            if (ll == src and rl in tgt_layers) or (rl == src and ll in tgt_layers):
                return True
        return False

    def auto_connect_matching(self, mode: str = "per_page_match") -> int:
        """Connect slicers and cross-filtering widgets according to the selected page & layer scope (#16)."""
        mode_clean = str(mode or "per_page_match").strip().lower()
        if isinstance(mode, bool):
            mode_clean = "per_page_match"
        added = 0
        pages = list(getattr(self.dashboard, "pages", []) or [])
        first_page_id = pages[0].id if pages else "page_1"
        active_page_id = str(getattr(self.dashboard, "active_page_id", "") or first_page_id)

        map_widgets = [w for w in self.dashboard.widgets if w.widget_type == "map"]
        data_targets = [w for w in self.dashboard.widgets if w.widget_type not in ("map", "image")]
        sources: List[Tuple[str, str, str, bool, bool]] = []
        for s in self.dashboard.slicers:
            sources.append((
                s.id,
                str(getattr(s, "layer_name", "") or ""),
                str(getattr(s, "page_id", first_page_id) or first_page_id),
                bool(getattr(s, "is_global", False)),
                True,
            ))
        for w in self.dashboard.widgets:
            if w.widget_type in ("bar", "pie", "line", "scatter", "table") and getattr(w, "enable_cross_filter", True):
                sources.append((
                    w.id,
                    str(getattr(w, "layer_name", "") or ""),
                    str(getattr(w, "page_id", first_page_id) or first_page_id),
                    False,
                    False,
                ))

        def _scope_allows(src_pid: str, src_global: bool, tgt_pid: str) -> bool:
            if mode_clean in ("all_pages_match", "all_legacy"):
                return True
            if mode_clean == "active_page_match":
                return (src_pid == active_page_id or src_global) and tgt_pid == active_page_id
            # per_page_match / per_page_all
            return src_global or (src_pid == tgt_pid)

        need_layer_match = mode_clean in ("per_page_match", "active_page_match", "all_pages_match")

        targets: List[Tuple[str, Optional[WidgetConfig], str, str]] = []
        if map_widgets:
            for mw in map_widgets:
                targets.append((
                    mw.id,
                    mw,
                    str(getattr(mw, "page_id", first_page_id) or first_page_id),
                    "filter_and_zoom",
                ))
        else:
            targets.append(("__map__", None, first_page_id, "filter_and_zoom"))
        for dw in data_targets:
            targets.append((
                dw.id,
                dw,
                str(getattr(dw, "page_id", first_page_id) or first_page_id),
                "filter",
            ))

        for src_id, src_layer, src_pid, src_global, _is_sl in sources:
            for tgt_id, tgt_obj, tgt_pid, act in targets:
                if src_id == tgt_id:
                    continue
                if not _scope_allows(src_pid, src_global, tgt_pid):
                    continue
                if need_layer_match and not self._layers_match(src_layer, tgt_obj):
                    continue
                if not self.dashboard.is_connected(src_id, tgt_id):
                    self.dashboard.add_or_update_connection(src_id, tgt_id, action=act)
                    added += 1

        self.canvas.connections[:] = list(self.dashboard.widget_connections)
        self.canvas.update()
        self._refresh_list()
        return added

    def _on_list_row_selected(self, row: int) -> None:
        if row < 0 or row >= self.list_conns.count():
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        it = self.list_conns.item(row)
        pair = it.data(role) if it is not None else None
        if isinstance(pair, (tuple, list)) and len(pair) == 2:
            self.canvas.selected_pair = (str(pair[0]), str(pair[1]))
            self.canvas.update()

    def _remove_connection_pair(self, pair: Tuple[str, str]) -> None:
        self.dashboard.remove_connection(str(pair[0]), str(pair[1]))
        if self.canvas.selected_pair == (str(pair[0]), str(pair[1])):
            self.canvas.selected_pair = None
        self.canvas.connections[:] = list(self.dashboard.widget_connections)
        self.canvas.update()
        self._refresh_list()

    def _remove_connection_at_row(self, row: int) -> None:
        if row < 0 or row >= self.list_conns.count():
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        it = self.list_conns.item(row)
        pair = it.data(role) if it is not None else None
        if isinstance(pair, (tuple, list)) and len(pair) == 2:
            self._remove_connection_pair((str(pair[0]), str(pair[1])))

    def _on_remove_selected(self) -> None:
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        pair = None
        if self.canvas.selected_pair:
            pair = self.canvas.selected_pair
        if not pair:
            it = self.list_conns.currentItem()
            if it is None and self.list_conns.selectedItems():
                it = self.list_conns.selectedItems()[0]
            if it is not None:
                pair = it.data(role)
        if not pair and self.list_conns.count() > 0:
            it = self.list_conns.item(0)
            if it is not None:
                pair = it.data(role)
        if isinstance(pair, (tuple, list)) and len(pair) == 2:
            self._remove_connection_pair((str(pair[0]), str(pair[1])))

    def _on_conn_list_context_menu(self, item: Any, global_pos: Any) -> None:
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        pair = item.data(role) if item is not None else None
        if not isinstance(pair, (tuple, list)) or len(pair) != 2:
            return
        src_id, tgt_id = str(pair[0]), str(pair[1])
        QMenuCls = getattr(QtWidgets, "QMenu", None)
        if QMenuCls is None:
            return
        menu = QMenuCls(self)
        edit_menu = menu.addMenu(tr("ctx_edit_settings", self.lang))
        act_fz = edit_menu.addAction(tr("conn_act_filter_zoom", self.lang))
        act_f = edit_menu.addAction(tr("conn_act_filter", self.lang))
        act_z = edit_menu.addAction(tr("conn_act_zoom", self.lang))
        act_rm = menu.addAction(tr("ctx_remove", self.lang))
        chosen = exec_menu(menu, global_pos)
        if chosen in (act_fz, act_f, act_z):
            new_act = "filter_and_zoom" if chosen == act_fz else ("filter" if chosen == act_f else "zoom_only")
            self.dashboard.add_or_update_connection(src_id, tgt_id, action=new_act)
            self.canvas.connections[:] = list(self.dashboard.widget_connections)
            self.canvas.update()
            self._refresh_list()
        elif chosen == act_rm:
            self._remove_connection_pair((src_id, tgt_id))

    def _on_cancel(self) -> None:
        self.dashboard.widget_connections = list(self._orig_connections)
        self.dashboard.sync_widget_connections()
        self.reject()


class MapLegendDialog(QDialog):
    """
    Dedicated Map Legend & Layer Style Configurator:
    - Drag-and-drop legend layer ordering & visibility toggles
    - Multi-field legend category checklist (always open/enabled) + primary dropdown
    - Automatic uniform styling when no category fields are selected
    """

    def __init__(
        self,
        widget_cfg: WidgetConfig,
        layer_fields_map: Optional[Dict[str, List[str]]] = None,
        lang: str = "et",
        parent: Optional[QWidget] = None,
        catalog_manager: Optional[LocalCatalogManager] = None,
        dashboard: Optional[DashboardConfig] = None,
        available_layers: Optional[List[str]] = None,
    ) -> None:
        super().__init__(parent)
        self.widget_cfg = widget_cfg
        self.layer_fields_map = dict(layer_fields_map or {})
        self.lang = lang or "et"
        self.catalog_manager = catalog_manager
        self.dashboard = dashboard
        self.available_layers: List[str] = [str(x) for x in (available_layers or []) if str(x or "").strip()]
        self._working_styles: Dict[str, Dict[str, Any]] = {
            k: dict(v)
            for k, v in (getattr(widget_cfg, "map_layer_styles", {}) or {}).items()
            if isinstance(v, dict)
        }
        self._current_layer: str = ""
        self._current_color: str = "#10b981"
        self._current_label_color: str = "#0f172a"
        self._loading_layer = False
        self._extra_label_rows: List[Tuple[QWidget, QComboBox]] = []

        self.setWindowTitle(tr("dlg_legend_title", self.lang))
        _apply_laptop_friendly_bounds(self, 780, 560, min_w=540, min_h=400)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(8)

        hint = QLabel(tr("dlg_legend_hint", self.lang))
        hint.setWordWrap(True)
        hint.setProperty("role", "muted")
        root.addWidget(hint)

        # Global Legend Header Controls
        top_row = QHBoxLayout()
        top_row.setSpacing(10)
        self.chk_show_legend = QCheckBox(tr("lbl_map_show_legend", self.lang))
        self.chk_show_legend.setChecked(bool(getattr(widget_cfg, "map_show_legend", True)))
        self.chk_collapsed = QCheckBox(tr("lbl_legend_collapsed", self.lang))
        self.chk_collapsed.setChecked(bool(getattr(widget_cfg, "map_legend_collapsed", False)))
        self.ed_legend_title = QLineEdit(str(getattr(widget_cfg, "map_legend_title", "") or ""))
        self.ed_legend_title.setPlaceholderText(tr("html_legend_title", self.lang))
        top_row.addWidget(self.chk_show_legend)
        top_row.addWidget(self.chk_collapsed)
        top_row.addWidget(QLabel(tr("lbl_map_legend_title", self.lang)))
        top_row.addWidget(self.ed_legend_title, 1)
        root.addLayout(top_row)

        body = QHBoxLayout()
        body.setSpacing(10)

        # Left Pane: Drag-and-Drop Layer Ordering in Legend
        left_col = QVBoxLayout()
        left_col.setSpacing(6)
        left_col.addWidget(QLabel(f"<b>{tr('lbl_legend_layers_order', self.lang)}</b>"))
        ord_btns = QHBoxLayout()
        btn_up = QPushButton("↑")
        btn_up.setMaximumWidth(34)
        btn_dn = QPushButton("↓")
        btn_dn.setMaximumWidth(34)
        ord_btns.addWidget(btn_up)
        ord_btns.addWidget(btn_dn)
        ord_btns.addStretch()
        left_col.addLayout(ord_btns)

        self.list_legend_layers = DragFieldListWidget(role_mode="layer_order", lang=self.lang)
        self.list_legend_layers.setMinimumWidth(190)
        btn_up.clicked.connect(lambda: self.list_legend_layers.move_selected(-1))
        btn_dn.clicked.connect(lambda: self.list_legend_layers.move_selected(1))
        self.list_legend_layers.currentRowChanged.connect(self._on_layer_row_selected)
        self.list_legend_layers.itemChanged.connect(self._on_layer_check_changed)
        left_col.addWidget(self.list_legend_layers, 1)
        body.addLayout(left_col, 4)

        # Right Pane: Tabbed Scrollable Symbology/Legend + Multi-Field Labels (#4, #5)
        right_wrap = QWidget()
        right_wrap_lay = QVBoxLayout(right_wrap)
        right_wrap_lay.setContentsMargins(0, 0, 0, 0)
        right_wrap_lay.setSpacing(6)

        hdr_lyr = QHBoxLayout()
        hdr_lyr.setSpacing(6)
        hdr_lyr.addWidget(QLabel(f"<b>{tr('lbl_style_layer', self.lang)}</b>"))
        self.lbl_active_layer = QLabel("—")
        self.lbl_active_layer.setProperty("role", "accent")
        hdr_lyr.addWidget(self.lbl_active_layer, 1)
        right_wrap_lay.addLayout(hdr_lyr)

        self.tabs_right = QTabWidget()
        right_wrap_lay.addWidget(self.tabs_right, 1)

        # ---- Tab 1: Style & Legend ----
        style_scroll = QScrollArea()
        style_scroll.setWidgetResizable(True)
        style_scroll.setFrameShape(qt_enum(QFrame, "Shape", "NoFrame"))
        style_page = QWidget()
        style_lay = QVBoxLayout(style_page)
        style_lay.setContentsMargins(8, 8, 8, 8)
        style_lay.setSpacing(8)
        form = QFormLayout()
        form.setSpacing(6)

        self.ed_legend_label = QLineEdit()
        self.ed_legend_label.textChanged.connect(self._save_current_layer_ui)

        self.cb_style_mode = QComboBox()
        self.cb_style_mode.addItem(tr("style_mode_auto", self.lang), "auto")
        self.cb_style_mode.addItem(tr("style_mode_single", self.lang), "single")
        self.cb_style_mode.addItem(tr("style_mode_category", self.lang), "category")
        self.cb_style_mode.currentIndexChanged.connect(self._save_current_layer_ui)

        col_row = QHBoxLayout()
        self.btn_color = QPushButton("🎨")
        self.btn_color.setMaximumWidth(36)
        self.btn_color.clicked.connect(self._pick_layer_color)
        self.lbl_color_preview = QLabel("  ")
        self.lbl_color_preview.setFixedSize(26, 22)
        self.ed_color_hex = QLineEdit("#10b981")
        self.ed_color_hex.textChanged.connect(self._on_hex_edited)
        col_row.addWidget(self.btn_color)
        col_row.addWidget(self.lbl_color_preview)
        col_row.addWidget(self.ed_color_hex, 1)

        num_grid = QGridLayout()
        num_grid.setSpacing(6)
        self.sp_opacity = QSpinBox()
        self.sp_opacity.setRange(5, 100)
        self.sp_opacity.setSingleStep(5)
        self.sp_opacity.setValue(45)
        self.sp_opacity.valueChanged.connect(self._save_current_layer_ui)

        self.sp_stroke = QDoubleSpinBox()
        self.sp_stroke.setRange(0.5, 8.0)
        self.sp_stroke.setSingleStep(0.5)
        self.sp_stroke.setValue(1.8)
        self.sp_stroke.valueChanged.connect(self._save_current_layer_ui)

        self.sp_min_zoom = QSpinBox()
        self.sp_min_zoom.setRange(0, 14)
        self.sp_min_zoom.setValue(0)
        self.sp_min_zoom.setToolTip(tr("style_min_zoom_tip", self.lang))
        self.sp_min_zoom.valueChanged.connect(self._save_current_layer_ui)

        num_grid.addWidget(QLabel(tr("lbl_style_opacity", self.lang)), 0, 0)
        num_grid.addWidget(self.sp_opacity, 0, 1)
        num_grid.addWidget(QLabel(tr("lbl_style_stroke", self.lang)), 0, 2)
        num_grid.addWidget(self.sp_stroke, 0, 3)
        num_grid.addWidget(QLabel(tr("style_min_zoom", self.lang)), 1, 0)
        num_grid.addWidget(self.sp_min_zoom, 1, 1)

        self.cb_style_field = QComboBox()
        self.cb_style_field.setEditable(True)
        self.cb_style_field.setEnabled(True)
        self.cb_style_field.currentTextChanged.connect(self._on_primary_field_changed)

        form.addRow(tr("lbl_style_legend_label", self.lang), self.ed_legend_label)
        form.addRow(tr("lbl_style_mode", self.lang), self.cb_style_mode)
        form.addRow(tr("lbl_style_color", self.lang), col_row)
        form.addRow("", num_grid)
        form.addRow(tr("lbl_style_field", self.lang), self.cb_style_field)
        style_lay.addLayout(form)

        style_lay.addWidget(QLabel(f"<b>{tr('lbl_legend_fields', self.lang)}</b>"))
        self.list_legend_fields = QListWidget()
        self.list_legend_fields.setMinimumHeight(120)
        self.list_legend_fields.itemChanged.connect(self._on_field_checklist_changed)
        style_lay.addWidget(self.list_legend_fields, 1)

        fld_hint = QLabel(tr("lbl_legend_fields_hint", self.lang))
        fld_hint.setWordWrap(True)
        fld_hint.setProperty("role", "mutedTiny")
        style_lay.addWidget(fld_hint)
        style_scroll.setWidget(style_page)
        self.tabs_right.addTab(style_scroll, tr("tab_layer_style", self.lang))

        # ---- Tab 2: Labels (Multi-Field + Min Size 3 + Halo Opacity) ----
        lbl_scroll = QScrollArea()
        lbl_scroll.setWidgetResizable(True)
        lbl_scroll.setFrameShape(qt_enum(QFrame, "Shape", "NoFrame"))
        lbl_page = QWidget()
        lbl_lay = QVBoxLayout(lbl_page)
        lbl_lay.setContentsMargins(8, 8, 8, 8)
        lbl_lay.setSpacing(8)
        l_form = QFormLayout()
        l_form.setSpacing(8)

        self.cb_label_field = QComboBox()
        self.cb_label_field.currentIndexChanged.connect(lambda _i: self._save_current_layer_ui())
        self.cb_label_field_2 = QComboBox()
        self.cb_label_field_2.currentIndexChanged.connect(lambda _i: self._save_current_layer_ui())

        self.extra_fields_host = QWidget()
        self.extra_fields_layout = QVBoxLayout(self.extra_fields_host)
        self.extra_fields_layout.setContentsMargins(0, 0, 0, 0)
        self.extra_fields_layout.setSpacing(4)

        self.btn_add_label_field = QPushButton(tr("btn_add_label_field", self.lang))
        self.btn_add_label_field.clicked.connect(lambda: self._add_extra_label_field_row(""))
        add_fld_row = QHBoxLayout()
        add_fld_row.addWidget(self.btn_add_label_field)
        add_fld_row.addStretch()

        size_col_row = QHBoxLayout()
        size_col_row.setSpacing(8)
        self.sp_label_size = QSpinBox()
        self.sp_label_size.setRange(3, 24)
        self.sp_label_size.setValue(10)
        self.sp_label_size.setToolTip(tr("tip_label_size", self.lang))
        self.sp_label_size.valueChanged.connect(self._save_current_layer_ui)
        self.btn_label_color = QPushButton("")
        self.btn_label_color.setFixedSize(28, 22)
        self.btn_label_color.clicked.connect(self._pick_label_color)
        self._update_label_color_swatch()
        size_col_row.addWidget(self.sp_label_size)
        size_col_row.addWidget(QLabel(tr("lbl_label_color", self.lang)))
        size_col_row.addWidget(self.btn_label_color)
        size_col_row.addStretch()

        halo_row = QHBoxLayout()
        halo_row.setSpacing(6)
        self.sl_halo_opacity = QSlider(qt_enum(Qt, "Orientation", "Horizontal"))
        self.sl_halo_opacity.setRange(0, 100)
        self.sl_halo_opacity.setValue(90)
        self.sl_halo_opacity.setToolTip(tr("tip_label_halo", self.lang))
        self.lbl_halo_opacity_val = QLabel("90%")
        self.lbl_halo_opacity_val.setMinimumWidth(36)
        self.sl_halo_opacity.valueChanged.connect(self._on_halo_slider_changed)
        halo_row.addWidget(self.sl_halo_opacity, 1)
        halo_row.addWidget(self.lbl_halo_opacity_val)

        self.cb_label_position = QComboBox()
        self.cb_label_position.addItem(tr("lbl_pos_center", self.lang), "center")
        self.cb_label_position.addItem(tr("lbl_pos_outside_line", self.lang), "outside_line")
        self.cb_label_position.addItem(tr("lbl_pos_outside_callout", self.lang), "outside_callout")
        self.cb_label_position.currentIndexChanged.connect(lambda _i: self._save_current_layer_ui())

        self.sp_label_min_zoom = QSpinBox()
        self.sp_label_min_zoom.setRange(0, 18)
        self.sp_label_min_zoom.setValue(0)
        self.sp_label_min_zoom.valueChanged.connect(self._save_current_layer_ui)

        l_form.addRow(tr("lbl_label_field_1", self.lang), self.cb_label_field)
        l_form.addRow(tr("lbl_label_field_2", self.lang), self.cb_label_field_2)
        l_form.addRow("", self.extra_fields_host)
        l_form.addRow("", add_fld_row)
        l_form.addRow(tr("lbl_label_size", self.lang), size_col_row)
        l_form.addRow(tr("lbl_halo_opacity", self.lang), halo_row)
        l_form.addRow(tr("lbl_label_position", self.lang), self.cb_label_position)
        l_form.addRow(tr("lbl_label_min_zoom", self.lang), self.sp_label_min_zoom)
        lbl_lay.addLayout(l_form)
        lbl_lay.addStretch(1)
        lbl_scroll.setWidget(lbl_page)
        self.tabs_right.addTab(lbl_scroll, tr("tab_layer_labels", self.lang))

        body.addWidget(right_wrap, 7)
        root.addLayout(body, 1)

        footer = QHBoxLayout()
        footer.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", self.lang))
        btn_cancel.clicked.connect(self.reject)
        btn_save = QPushButton(tr("btn_save", self.lang))
        btn_save.setProperty("btnRole", "primary")
        btn_save.clicked.connect(self._on_accept)
        footer.addWidget(btn_cancel)
        footer.addWidget(btn_save)
        root.addLayout(footer)

        self._populate_layers()

    def _on_halo_slider_changed(self, val: int) -> None:
        if hasattr(self, "lbl_halo_opacity_val"):
            self.lbl_halo_opacity_val.setText(f"{int(val)}%")
        self._save_current_layer_ui()

    def _populate_label_combo(self, combo: QComboBox, cols: List[str], selected: str = "") -> None:
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(tr("lbl_no_labels", self.lang), "")
        for c in cols:
            combo.addItem(c, c)
        sel = str(selected or "").strip()
        if sel:
            if combo.findData(sel) < 0:
                combo.addItem(sel, sel)
            combo.setCurrentIndex(combo.findData(sel))
        combo.blockSignals(False)

    def _clear_extra_label_rows(self) -> None:
        for row_w, _cb in list(self._extra_label_rows):
            self.extra_fields_layout.removeWidget(row_w)
            row_w.deleteLater()
        self._extra_label_rows.clear()
        self._sync_add_label_field_btn()

    def _sync_add_label_field_btn(self) -> None:
        if hasattr(self, "btn_add_label_field"):
            self.btn_add_label_field.setEnabled(len(self._extra_label_rows) < 2)

    def _add_extra_label_field_row(self, selected: str = "") -> None:
        if len(self._extra_label_rows) >= 2:
            return
        cols = self._fields_for_layer(self._current_layer) if self._current_layer else []
        row_w = QWidget()
        row_h = QHBoxLayout(row_w)
        row_h.setContentsMargins(0, 0, 0, 0)
        row_h.setSpacing(6)
        n_line = 3 + len(self._extra_label_rows)
        lbl = QLabel(tr("lbl_label_field_extra", self.lang, n=n_line))
        cb = QComboBox()
        self._populate_label_combo(cb, cols, selected)
        cb.currentIndexChanged.connect(lambda _i: self._save_current_layer_ui())
        btn_rm = QPushButton("✕")
        btn_rm.setFixedWidth(26)
        btn_rm.clicked.connect(lambda _checked=False, rw=row_w: self._remove_extra_label_field_row(rw))
        row_h.addWidget(lbl)
        row_h.addWidget(cb, 1)
        row_h.addWidget(btn_rm)
        self.extra_fields_layout.addWidget(row_w)
        self._extra_label_rows.append((row_w, cb))
        self._sync_add_label_field_btn()
        if not self._loading_layer:
            self._save_current_layer_ui()

    def _remove_extra_label_field_row(self, row_w: QWidget) -> None:
        self._extra_label_rows = [(w, cb) for (w, cb) in self._extra_label_rows if w is not row_w]
        self.extra_fields_layout.removeWidget(row_w)
        row_w.deleteLater()
        self._sync_add_label_field_btn()
        self._save_current_layer_ui()

    def _collect_label_fields_from_ui(self) -> List[str]:
        out: List[str] = []
        for cb in [self.cb_label_field, self.cb_label_field_2] + [c for _, c in self._extra_label_rows]:
            val = str(cb.currentData() or "").strip()
            if val and val not in out:
                out.append(val)
        return out

    def _collect_candidate_layers(self) -> List[str]:
        ordered: List[str] = []
        for src_list in (
            list(getattr(self.widget_cfg, "map_legend_layers", []) or []),
            list(getattr(self.widget_cfg, "map_layers", []) or []),
            self.available_layers,
        ):
            for ln in src_list:
                if ln and ln not in ordered:
                    ordered.append(ln)
        if self.widget_cfg.layer_name and self.widget_cfg.layer_name not in ordered:
            ordered.append(self.widget_cfg.layer_name)
        bm_titles = {b[1] for b in MAAAMET_BASEMAPS}
        if self.dashboard is not None:
            for ds in getattr(self.dashboard, "data_sources", []) or []:
                if ds.name and not getattr(ds, "is_basemap", False) and ds.name not in bm_titles and ds.name not in ordered:
                    ordered.append(ds.name)
        for ln in self.layer_fields_map.keys():
            if ln and ln not in bm_titles and ln not in ordered:
                ordered.append(ln)
        for ln in self._working_styles.keys():
            if ln and ln not in ordered:
                ordered.append(ln)
        sync_main = (
            str(getattr(self.dashboard, "canvas_sync_mode", "dashboard_only") or "dashboard_only")
            == "sync_main_canvas"
        )
        if sync_main:
            try:
                from qgis.core import QgsProject

                for lyr in QgsProject.instance().mapLayers().values():
                    ln = lyr.name()
                    if ln and ln not in bm_titles and ln not in ordered:
                        ordered.append(ln)
            except Exception:
                pass
        return ordered

    def _populate_layers(self) -> None:
        self.list_legend_layers.blockSignals(True)
        self.list_legend_layers.clear()
        chk_flag = qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable")
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        unchecked_st = qt_enum(Qt, "CheckState", "Unchecked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")

        layers = self._collect_candidate_layers()
        active_map_layers = set(self.widget_cfg.map_layers or ([self.widget_cfg.layer_name] if self.widget_cfg.layer_name else []))
        for ln in layers:
            st = self._working_styles.get(ln) or {}
            show = bool(st.get("show_in_legend", True if (not active_map_layers or ln in active_map_layers) else False))
            it = QListWidgetItem(ln)
            it.setData(role, ln)
            it.setFlags(it.flags() | chk_flag)
            it.setCheckState(checked_st if show else unchecked_st)
            self.list_legend_layers.addItem(it)
        self.list_legend_layers.blockSignals(False)
        if self.list_legend_layers.count() > 0:
            self.list_legend_layers.setCurrentRow(0)
            self._load_layer_into_editor(layers[0])

    def _fields_for_layer(self, lname: str) -> List[str]:
        cols = list(_lookup_fields_lazy(
            lname,
            self.layer_fields_map,
            dashboard=self.dashboard,
            catalog_manager=self.catalog_manager,
            allow_network=False,
        ))
        try:
            from qgis.core import QgsProject

            for lyr in QgsProject.instance().mapLayersByName(lname):
                if hasattr(lyr, "fields"):
                    for f in lyr.fields():
                        fn = f.name()
                        if fn and fn not in cols:
                            cols.append(fn)
        except Exception:
            pass
        return [c for c in cols if not str(c).startswith("_")]

    def _on_layer_row_selected(self, row: int) -> None:
        if row < 0 or row >= self.list_legend_layers.count():
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        it = self.list_legend_layers.item(row)
        lname = str(it.data(role) or it.text()) if it is not None else ""
        if lname:
            self._load_layer_into_editor(lname)

    def _on_layer_check_changed(self, item: Any) -> None:
        if self._loading_layer or item is None:
            return
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        lname = str(item.data(role) or item.text())
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        st = dict(self._working_styles.get(lname) or {})
        st["show_in_legend"] = item.checkState() == checked_st
        self._working_styles[lname] = st

    def _load_layer_into_editor(self, lname: str) -> None:
        self._loading_layer = True
        self._current_layer = lname
        self.lbl_active_layer.setText(lname)
        st = dict(self._working_styles.get(lname) or {})
        self._current_color = str(st.get("color") or "#10b981")

        self.ed_legend_label.blockSignals(True)
        self.ed_legend_label.setText(str(st.get("legend_label") or lname))
        self.ed_legend_label.blockSignals(False)

        self.ed_color_hex.blockSignals(True)
        self.ed_color_hex.setText(self._current_color)
        self.ed_color_hex.blockSignals(False)
        self._update_color_swatch()

        self.sp_opacity.blockSignals(True)
        self.sp_opacity.setValue(int(round(float(st.get("opacity", 0.45)) * 100)))
        self.sp_opacity.blockSignals(False)

        self.sp_stroke.blockSignals(True)
        self.sp_stroke.setValue(float(st.get("stroke_width", 1.8)))
        self.sp_stroke.blockSignals(False)

        self.sp_min_zoom.blockSignals(True)
        self.sp_min_zoom.setValue(max(0, min(14, int(st.get("min_zoom", 0) or 0))))
        self.sp_min_zoom.blockSignals(False)

        cols = self._fields_for_layer(lname)
        selected_fields: List[str] = list(st.get("legend_fields") or [])
        primary = str(st.get("style_field") or "")
        if primary and primary not in selected_fields:
            selected_fields.insert(0, primary)
        for sf in selected_fields:
            if sf and sf not in cols:
                cols.append(sf)

        self.cb_style_field.blockSignals(True)
        self.cb_style_field.clear()
        self.cb_style_field.addItem("")
        for c in cols:
            self.cb_style_field.addItem(c)
        self.cb_style_field.setCurrentText(primary or (selected_fields[0] if selected_fields else ""))
        self.cb_style_field.setEnabled(True)
        self.cb_style_field.blockSignals(False)

        raw_lbl_fields = [str(f).strip() for f in (st.get("label_fields") or []) if str(f or "").strip()]
        if not raw_lbl_fields and str(st.get("label_field") or "").strip():
            raw_lbl_fields = [str(st.get("label_field") or "").strip()]
        for lf in raw_lbl_fields:
            if lf not in cols:
                cols.append(lf)

        self._populate_label_combo(self.cb_label_field, cols, raw_lbl_fields[0] if len(raw_lbl_fields) > 0 else "")
        self._populate_label_combo(self.cb_label_field_2, cols, raw_lbl_fields[1] if len(raw_lbl_fields) > 1 else "")
        self._clear_extra_label_rows()
        for extra_f in raw_lbl_fields[2:4]:
            self._add_extra_label_field_row(extra_f)

        self._current_label_color = str(st.get("label_color") or "#0f172a")
        self._update_label_color_swatch()
        halo_op = int(
            st["label_halo_opacity"]
            if st.get("label_halo_opacity") is not None
            else (90 if st.get("label_halo", True) else 0)
        )
        halo_op = max(0, min(100, halo_op))
        for lw in (self.sp_label_size, self.sl_halo_opacity, self.cb_label_position, self.sp_label_min_zoom):
            lw.blockSignals(True)
        try:
            self.sp_label_size.setValue(max(3, min(24, int(st.get("label_size", 10) or 10))))
            self.sl_halo_opacity.setValue(halo_op)
            if hasattr(self, "lbl_halo_opacity_val"):
                self.lbl_halo_opacity_val.setText(f"{halo_op}%")
            pos_val = str(st.get("label_position") or "center").strip()
            idx_pos = self.cb_label_position.findData(pos_val)
            self.cb_label_position.setCurrentIndex(idx_pos if idx_pos >= 0 else 0)
            self.sp_label_min_zoom.setValue(max(0, min(18, int(st.get("label_min_zoom", 0) or 0))))
        finally:
            for lw in (self.sp_label_size, self.sl_halo_opacity, self.cb_label_position, self.sp_label_min_zoom):
                lw.blockSignals(False)

        chk_flag = qt_enum(Qt, "ItemFlag", "ItemIsUserCheckable")
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        unchecked_st = qt_enum(Qt, "CheckState", "Unchecked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        sel_set = set(selected_fields)

        self.list_legend_fields.blockSignals(True)
        self.list_legend_fields.clear()
        for c in cols:
            fit = QListWidgetItem(c)
            fit.setData(role, c)
            fit.setFlags(fit.flags() | chk_flag)
            fit.setCheckState(checked_st if c in sel_set else unchecked_st)
            self.list_legend_fields.addItem(fit)
        self.list_legend_fields.blockSignals(False)

        mode = str(st.get("style_mode") or ("category" if selected_fields else "auto"))
        if mode == "category" and not selected_fields:
            mode = "single" if st.get("color") else "auto"
        idx_m = self.cb_style_mode.findData(mode)
        self.cb_style_mode.blockSignals(True)
        if idx_m >= 0:
            self.cb_style_mode.setCurrentIndex(idx_m)
        self.cb_style_mode.blockSignals(False)
        self._loading_layer = False

    def _update_color_swatch(self) -> None:
        self.lbl_color_preview.setStyleSheet(
            f"background: {self._current_color}; border-radius: 4px; border: 1px solid #475569;"
        )

    def _update_label_color_swatch(self) -> None:
        if hasattr(self, "btn_label_color"):
            self.btn_label_color.setStyleSheet(
                f"background: {self._current_label_color}; border-radius: 4px; border: 1px solid #475569;"
            )

    def _pick_label_color(self) -> None:
        col = QColorDialog.getColor(QtGui.QColor(self._current_label_color), self)
        if col.isValid():
            self._current_label_color = col.name()
            self._update_label_color_swatch()
            self._save_current_layer_ui()

    def _pick_layer_color(self) -> None:
        col = QColorDialog.getColor(QtGui.QColor(self._current_color), self)
        if col.isValid():
            self._current_color = col.name()
            self.ed_color_hex.setText(self._current_color)
            self._update_color_swatch()
            idx_s = self.cb_style_mode.findData("single")
            if not self._selected_legend_fields() and idx_s >= 0:
                self.cb_style_mode.setCurrentIndex(idx_s)
            self._save_current_layer_ui()

    def _on_hex_edited(self, txt: str) -> None:
        if txt.strip().startswith("#") and len(txt.strip()) in (4, 7):
            self._current_color = txt.strip()
            self._update_color_swatch()
        self._save_current_layer_ui()

    def _selected_legend_fields(self) -> List[str]:
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        out: List[str] = []
        for i in range(self.list_legend_fields.count()):
            fit = self.list_legend_fields.item(i)
            if fit is not None and fit.checkState() == checked_st:
                fn = str(fit.data(role) or fit.text()).strip()
                if fn and fn not in out:
                    out.append(fn)
        primary = self.cb_style_field.currentText().strip()
        if primary and primary not in out:
            out.insert(0, primary)
        return out

    def _on_primary_field_changed(self, txt: str) -> None:
        if self._loading_layer:
            return
        fn = txt.strip()
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        if fn:
            self.list_legend_fields.blockSignals(True)
            for i in range(self.list_legend_fields.count()):
                fit = self.list_legend_fields.item(i)
                if fit is not None and str(fit.data(role) or fit.text()) == fn:
                    fit.setCheckState(checked_st)
            self.list_legend_fields.blockSignals(False)
            idx_c = self.cb_style_mode.findData("category")
            if idx_c >= 0:
                self.cb_style_mode.setCurrentIndex(idx_c)
        elif not self._selected_legend_fields():
            idx_s = self.cb_style_mode.findData("single")
            if idx_s >= 0:
                self.cb_style_mode.setCurrentIndex(idx_s)
        self._save_current_layer_ui()

    def _on_field_checklist_changed(self, _item: Any) -> None:
        if self._loading_layer:
            return
        fields = self._selected_legend_fields()
        self.cb_style_field.blockSignals(True)
        if not fields:
            self.cb_style_field.setCurrentText("")
        elif self.cb_style_field.currentText().strip() not in fields:
            self.cb_style_field.setCurrentText(fields[0])
        self.cb_style_field.blockSignals(False)

        target_mode = "category" if fields else "single"
        idx_m = self.cb_style_mode.findData(target_mode)
        if idx_m >= 0:
            self.cb_style_mode.blockSignals(True)
            self.cb_style_mode.setCurrentIndex(idx_m)
            self.cb_style_mode.blockSignals(False)
        self._save_current_layer_ui()

    def _save_current_layer_ui(self, *_args: Any) -> None:
        if self._loading_layer or not self._current_layer:
            return
        fields = self._selected_legend_fields()
        mode = str(self.cb_style_mode.currentData() or "single")
        if not fields:
            # Uniform style automatically applied when no category field is selected
            mode = "single"
        elif mode == "auto":
            mode = "category"
        checked_st = qt_enum(Qt, "CheckState", "Checked")
        show_in_leg = True
        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        for i in range(self.list_legend_layers.count()):
            it = self.list_legend_layers.item(i)
            if it is not None and str(it.data(role) or it.text()) == self._current_layer:
                show_in_leg = it.checkState() == checked_st
                break
        lbl_fields = self._collect_label_fields_from_ui()
        halo_op = max(0, min(100, int(self.sl_halo_opacity.value())))
        prev_style = dict(self._working_styles.get(self._current_layer, {}) or {})
        prev_style.update(
            {
                "style_mode": mode,
                "color": self.ed_color_hex.text().strip() or self._current_color,
                "opacity": round(float(self.sp_opacity.value()) / 100.0, 2),
                "stroke_width": float(self.sp_stroke.value()),
                "min_zoom": max(0, min(14, int(self.sp_min_zoom.value()))),
                "style_field": fields[0] if fields else "",
                "style_fields": fields,
                "legend_fields": fields,
                "label_fields": lbl_fields,
                "label_field": lbl_fields[0] if lbl_fields else "",
                "label_size": max(3, min(24, int(self.sp_label_size.value()))),
                "label_color": str(self._current_label_color or "#0f172a"),
                "label_halo_opacity": halo_op,
                "label_halo": halo_op > 0,
                "label_multi_row": False,
                "label_position": str(self.cb_label_position.currentData() or "center"),
                "label_min_zoom": max(0, min(18, int(self.sp_label_min_zoom.value()))),
                "legend_label": self.ed_legend_label.text().strip() or self._current_layer,
                "show_in_legend": show_in_leg,
            }
        )
        self._working_styles[self._current_layer] = prev_style

    def _on_accept(self) -> None:
        self._save_current_layer_ui()
        self.widget_cfg.map_show_legend = bool(self.chk_show_legend.isChecked())
        self.widget_cfg.map_legend_collapsed = bool(self.chk_collapsed.isChecked())
        self.widget_cfg.map_legend_title = self.ed_legend_title.text().strip()

        role = qt_enum(Qt, "ItemDataRole", "UserRole")
        ordered_legend_layers: List[str] = []
        for i in range(self.list_legend_layers.count()):
            it = self.list_legend_layers.item(i)
            if it is not None:
                ln = str(it.data(role) or it.text()).strip()
                if ln and ln not in ordered_legend_layers:
                    ordered_legend_layers.append(ln)
        self.widget_cfg.map_legend_layers = ordered_legend_layers
        self.widget_cfg.map_layer_styles = self._working_styles
        self.accept()


MapStyleLegendDialog = MapLegendDialog


class ExportDashboardDialog(QDialog):
    """Export options dialog for SharePoint (.aspx) / HTML, sidecar split, layer packaging, and complexity tier."""

    def __init__(
        self,
        dashboard: DashboardConfig,
        lang: str = "et",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.dashboard = dashboard
        self.lang = lang or getattr(dashboard, "language", "et") or "et"
        self.setWindowTitle(tr("dlg_export_title", self.lang))
        _apply_laptop_friendly_bounds(self, 610, 365, min_w=460, min_h=290)
        self.setStyleSheet(ThemeManager.get_stylesheet())

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        form = QFormLayout()
        form.setSpacing(8)

        self.cb_format = QComboBox()
        self.cb_format.addItem(tr("export_fmt_html", self.lang), "html")
        self.cb_format.addItem(tr("export_fmt_aspx", self.lang), "aspx")
        idx_fmt = self.cb_format.findData(str(getattr(dashboard, "export_format", "html") or "html").lower())
        if idx_fmt >= 0:
            self.cb_format.setCurrentIndex(idx_fmt)

        self.cb_structure = QComboBox()
        self.cb_structure.addItem(tr("export_mode_compact", self.lang), "compact_single")
        self.cb_structure.addItem(tr("export_mode_sidecar", self.lang), "sidecar")
        idx_st = self.cb_structure.findData(str(getattr(dashboard, "export_mode", "compact_single") or "compact_single"))
        if idx_st >= 0:
            self.cb_structure.setCurrentIndex(idx_st)

        self.cb_package_layers = QComboBox()
        self.cb_package_layers.addItem(tr("export_pkg_bundled", self.lang), True)
        self.cb_package_layers.addItem(tr("export_pkg_live_only", self.lang), False)
        idx_pkg = self.cb_package_layers.findData(bool(getattr(dashboard, "package_layers_in_export", True)))
        if idx_pkg >= 0:
            self.cb_package_layers.setCurrentIndex(idx_pkg)

        self.cb_tier = QComboBox()
        self.cb_tier.addItem(tr("export_tier_full", self.lang), "full")
        self.cb_tier.addItem(tr("export_tier_medium", self.lang), "medium")
        self.cb_tier.addItem(tr("export_tier_minimal", self.lang), "minimal")
        idx_tier = self.cb_tier.findData(str(getattr(dashboard, "export_tier", "full") or "full").lower())
        if idx_tier >= 0:
            self.cb_tier.setCurrentIndex(idx_tier)

        self.lbl_tier_hint = QLabel("")
        self.lbl_tier_hint.setWordWrap(True)
        self.lbl_tier_hint.setProperty("role", "muted")

        def _sync_tier_hint() -> None:
            tk = str(self.cb_tier.currentData() or "full").lower()
            self.lbl_tier_hint.setText(tr(f"export_tier_hint_{tk}", self.lang))

        self.cb_tier.currentIndexChanged.connect(_sync_tier_hint)
        _sync_tier_hint()

        self.chk_open_after_export = QCheckBox(tr("export_open_after_label", self.lang))
        self.chk_open_after_export.setChecked(bool(getattr(dashboard, "open_after_export", False)))

        form.addRow(tr("export_fmt_label", self.lang), self.cb_format)
        form.addRow(tr("export_mode_label", self.lang), self.cb_structure)
        form.addRow(tr("export_pkg_label", self.lang), self.cb_package_layers)
        form.addRow(tr("export_tier_label", self.lang), self.cb_tier)
        form.addRow("", self.lbl_tier_hint)

        self.cb_default_page: Optional[QComboBox] = None
        pages_list = list(getattr(dashboard, "pages", []) or [])
        if len(pages_list) > 1:
            self.cb_default_page = QComboBox()
            for pg in pages_list:
                pg_lbl = pg.title_en if self.lang == "en" and pg.title_en else pg.title
                icon_txt = f"{pg.icon} " if getattr(pg, "icon", "") else ""
                self.cb_default_page.addItem(f"{icon_txt}{pg_lbl}".strip(), pg.id)
            cur_def = str(getattr(dashboard, "default_page_id", "") or "").strip()
            idx_dp = self.cb_default_page.findData(cur_def) if cur_def else 0
            if idx_dp >= 0:
                self.cb_default_page.setCurrentIndex(idx_dp)
            form.addRow(tr("export_default_page_label", self.lang), self.cb_default_page)

        form.addRow("", self.chk_open_after_export)
        layout.addLayout(form)

        hint = QLabel(tr("export_sharepoint_hint", self.lang))
        hint.setWordWrap(True)
        hint.setProperty("role", "muted")
        layout.addWidget(hint)
        layout.addStretch()

        btns = QHBoxLayout()
        btns.addStretch()
        btn_cancel = QPushButton(tr("btn_cancel", self.lang))
        btn_cancel.clicked.connect(self.reject)
        btn_ok = QPushButton(tr("btn_export_do", self.lang))
        btn_ok.setProperty("btnRole", "primary")
        btn_ok.clicked.connect(self._on_accept)
        btns.addWidget(btn_cancel)
        btns.addWidget(btn_ok)
        layout.addLayout(btns)

    def _on_accept(self) -> None:
        self.dashboard.export_format = str(self.cb_format.currentData() or "html")
        self.dashboard.export_mode = str(self.cb_structure.currentData() or "compact_single")
        pkg = bool(self.cb_package_layers.currentData() if self.cb_package_layers.currentData() is not None else True)
        self.dashboard.package_layers_in_export = pkg
        self.dashboard.html_data_mode = "cached" if pkg else "live"
        self.dashboard.export_tier = str(self.cb_tier.currentData() or "full")
        if self.cb_default_page is not None:
            self.dashboard.default_page_id = str(self.cb_default_page.currentData() or "")
        self.dashboard.open_after_export = bool(self.chk_open_after_export.isChecked())
        self.accept()

