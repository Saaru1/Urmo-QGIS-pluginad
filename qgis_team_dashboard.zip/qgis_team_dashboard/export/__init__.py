# -*- coding: utf-8 -*-
"""Standalone interactive HTML5 dashboard exporter for SharePoint and Microsoft Teams."""
