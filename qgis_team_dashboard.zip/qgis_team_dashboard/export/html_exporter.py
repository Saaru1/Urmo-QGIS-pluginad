# -*- coding: utf-8 -*-
"""
HTML5 Interactive Dashboard Compiler for QGIS Team Dashboard.
Compiles a DashboardConfig, live OGC WFS/WMS descriptors, and read-only Excel join
tables into a self-contained HTML application ready for SharePoint or Microsoft Teams.
"""

import base64
from datetime import datetime
import gzip
import html as _html_lib
import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

from ..connectors.catalog_manager import DEFAULT_CATALOG_SERVERS, LocalCatalogManager
from ..connectors.ogc_connector import OgcConnector
from ..connectors.path_resolver import PortablePathResolver
from ..core.i18n import get_translations_bundle, tr
from ..core.schema import DashboardConfig
from ..ui.theme import ThemeManager


class HtmlDashboardExporter:
    """Compiles a DashboardConfig and hydrated records into an interactive HTML5 dashboard."""

    _VENDOR_ASSETS_CACHE: Optional[Tuple[str, str]] = None
    _BASEMAP_SNAPSHOT_CACHE: Dict[Tuple[str, str, Tuple[float, ...]], str] = {}

    @classmethod
    def _fetch_wms_data_uri(
        cls,
        wms_url: str,
        layer_name: str,
        fmt: str,
        bbox_3301: Tuple[float, float, float, float],
        width_px: int,
        height_px: int,
        timeout_sec: float = 5.0,
    ) -> str:
        """Fetch an EPSG:3301 WMS GetMap image, JPEG-compress via QImage when available, and return data URI."""
        bbox_key = tuple(round(float(v), 1) for v in bbox_3301)
        cache_key = (wms_url, layer_name, bbox_key)
        cached = cls._BASEMAP_SNAPSHOT_CACHE.get(cache_key)
        if cached:
            return cached

        import urllib.parse
        import urllib.request

        params = urllib.parse.urlencode(
            {
                "SERVICE": "WMS",
                "VERSION": "1.1.1",
                "REQUEST": "GetMap",
                "LAYERS": layer_name,
                "STYLES": "",
                "SRS": "EPSG:3301",
                "BBOX": f"{bbox_3301[0]:.1f},{bbox_3301[1]:.1f},{bbox_3301[2]:.1f},{bbox_3301[3]:.1f}",
                "WIDTH": str(int(width_px)),
                "HEIGHT": str(int(height_px)),
                "FORMAT": fmt,
            }
        )
        req_url = f"{wms_url}{'&' if '?' in wms_url else '?'}{params}"
        req = urllib.request.Request(req_url, headers={"User-Agent": "GeoDash-QGIS/1.6"})
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            raw_bytes = resp.read()
        if not raw_bytes or raw_bytes.lstrip()[:1] == b"<":
            return ""

        out_mime = "image/jpeg" if "jpeg" in fmt.lower() else "image/png"
        out_bytes = raw_bytes
        try:
            from qgis.PyQt import QtCore, QtGui

            img = QtGui.QImage.fromData(raw_bytes)
            if not img.isNull():
                buf = QtCore.QBuffer()
                open_mode = (
                    QtCore.QIODevice.OpenModeFlag.WriteOnly
                    if hasattr(QtCore.QIODevice, "OpenModeFlag")
                    else QtCore.QIODevice.WriteOnly
                )
                if buf.open(open_mode) and img.save(buf, "JPEG", 78):
                    jpg_bytes = bytes(buf.data())
                    if jpg_bytes:
                        out_bytes = jpg_bytes
                        out_mime = "image/jpeg"
        except Exception:
            pass

        data_uri = f"data:{out_mime};base64,{base64.b64encode(out_bytes).decode('ascii')}"
        cls._BASEMAP_SNAPSHOT_CACHE[cache_key] = data_uri
        return data_uri

    @classmethod
    def _fetch_packaged_basemap_bundle(
        cls,
        config: DashboardConfig,
        ogc_descriptors: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """
        Embed an EPSG:3301 Maa-amet GetMap snapshot (`data:image/jpeg;base64,...`) when
        packaging offline/SharePoint HTML so CSP-sandboxed iframes still display a basemap.
        """
        if os.environ.get("QT_QPA_PLATFORM") == "offscreen" and not os.environ.get("QDASH_FORCE_FETCH_BASEMAP"):
            return None

        widgets = getattr(config, "widgets", []) or []
        def_pg = str(getattr(config, "default_page_id", "") or "").strip()
        map_w = (
            next((w for w in widgets if getattr(w, "widget_type", "") == "map" and def_pg and str(getattr(w, "page_id", "") or "") == def_pg), None)
            or next((w for w in widgets if getattr(w, "widget_type", "") == "map"), None)
        )
        desired = str((getattr(map_w, "map_basemap", "") if map_w else "") or getattr(config, "map_basemap", "") or "MA-HALLKAART").strip()
        if desired == "MA-FOTOKAART":
            desired = "EESTIFOTO"
        if not desired or desired == "cir_ngr":
            desired = "MA-HALLKAART"

        wms_url = "https://kaart.maaamet.ee/wms/hallkaart"
        wms_layer = "MA-HALLKAART"
        wms_fmt = "image/png"
        if desired == "MA-KAART":
            wms_url = "https://kaart.maaamet.ee/wms/kaart"
            wms_layer = "MA-KAART"
        elif desired == "EESTIFOTO":
            wms_url = "https://kaart.maaamet.ee/wms/fotokaart"
            wms_layer = "EESTIFOTO"
            wms_fmt = "image/jpeg"

        for svc in ogc_descriptors or []:
            if not isinstance(svc, dict) or svc.get("type") != "wms" or not svc.get("is_basemap"):
                continue
            lyr = str(svc.get("layers") or "").strip()
            if lyr == "MA-FOTOKAART":
                lyr = "EESTIFOTO"
            if lyr == desired and svc.get("url"):
                wms_url = "https://kaart.maaamet.ee/wms/fotokaart" if lyr == "EESTIFOTO" else str(svc["url"])
                wms_layer = lyr
                wms_fmt = "image/jpeg" if lyr == "EESTIFOTO" else str(svc.get("format") or "image/png")
                break

        ov_bbox = (365000.0, 6375000.0, 740000.0, 6635000.0)
        try:
            ov_uri = cls._fetch_wms_data_uri(wms_url, wms_layer, wms_fmt, ov_bbox, 1280, 888, timeout_sec=5.0)
        except Exception:
            return None
        if not ov_uri:
            return None

        home_uri = ""
        home_bbox_3301: Optional[List[float]] = None
        raw_hb = (getattr(map_w, "map_home_bounds", None) if map_w else None) or getattr(config, "map_home_bounds", None)
        if isinstance(raw_hb, (list, tuple)) and len(raw_hb) == 4:
            try:
                s_lat, w_lon, n_lat, e_lon = [float(v) for v in raw_hb]
                from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsProject

                xf = QgsCoordinateTransform(
                    QgsCoordinateReferenceSystem("EPSG:4326"),
                    QgsCoordinateReferenceSystem("EPSG:3301"),
                    QgsProject.instance(),
                )
                p_sw = xf.transform(QgsPointXY(w_lon, s_lat))
                p_ne = xf.transform(QgsPointXY(e_lon, n_lat))
                x1, x2 = min(p_sw.x(), p_ne.x()), max(p_sw.x(), p_ne.x())
                y1, y2 = min(p_sw.y(), p_ne.y()), max(p_sw.y(), p_ne.y())
                dx, dy = x2 - x1, y2 - y1
                if 50.0 < dx < 310000.0 and 50.0 < dy < 215000.0:
                    pad_x, pad_y = dx * 0.12, dy * 0.12
                    hb = (x1 - pad_x, y1 - pad_y, x2 + pad_x, y2 + pad_y)
                    aspect = (hb[2] - hb[0]) / max(1.0, (hb[3] - hb[1]))
                    if aspect >= 1.0:
                        w_px = 1100
                        h_px = max(256, min(1100, int(round(1100 / aspect))))
                    else:
                        h_px = 1100
                        w_px = max(256, min(1100, int(round(1100 * aspect))))
                    home_uri = cls._fetch_wms_data_uri(wms_url, wms_layer, wms_fmt, hb, w_px, h_px, timeout_sec=5.0)
                    if home_uri:
                        home_bbox_3301 = [round(v, 2) for v in hb]
            except Exception:
                home_uri = ""
                home_bbox_3301 = None

        return {
            "wms_url": wms_url,
            "layer": wms_layer,
            "bbox_3301": list(ov_bbox),
            "data_uri": ov_uri,
            "home_bbox_3301": home_bbox_3301,
            "home_data_uri": home_uri,
        }

    @classmethod
    def _get_favicon_data_uri(cls) -> str:
        """Load plugin icon.svg as an XHTML-safe data URI for HTML browser tab favicons."""
        try:
            import urllib.parse

            icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icon.svg")
            if not os.path.exists(icon_path):
                return ""
            with open(icon_path, "r", encoding="utf-8") as fh:
                svg_txt = fh.read().strip()
            if not svg_txt:
                return ""
            return "data:image/svg+xml," + urllib.parse.quote(svg_txt, safe="")
        except Exception:
            return ""

    @classmethod
    def _get_inlined_vendor_assets(cls) -> Tuple[str, str]:
        """Load and cache local Leaflet/Proj4/Proj4Leaflet assets for CSP-safe offline/SharePoint HTML."""
        if cls._VENDOR_ASSETS_CACHE is not None:
            return cls._VENDOR_ASSETS_CACHE
        vdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor")
        with open(os.path.join(vdir, "leaflet.css"), "r", encoding="utf-8") as fh:
            raw_css = fh.read()
        js_parts: List[str] = []
        for fn in ("leaflet.js", "proj4.js", "proj4leaflet.js"):
            with open(os.path.join(vdir, fn), "r", encoding="utf-8") as fh:
                js_parts.append(fh.read())
        safe_css = re.sub(r"</style", "<\\/style", raw_css, flags=re.IGNORECASE).replace("]]>", "]] >")
        safe_js = re.sub(r"</script", "<\\/script", "\n;\n".join(js_parts), flags=re.IGNORECASE).replace("]]>", "]]\\u003e")
        cls._VENDOR_ASSETS_CACHE = (safe_css, safe_js)
        return cls._VENDOR_ASSETS_CACHE

    @staticmethod
    def _compress_layer_records(
        layer_records: Dict[str, List[Dict[str, Any]]],
        min_rows_for_gzip: int = 250,
    ) -> Dict[str, Any]:
        """
        Convert heavy per-feature record lists (>= min_rows_for_gzip rows) into
        Columnar + Gzip + Base64 payloads (#16), shrinking 70+ MB of repeated JSON
        keys down to ~5–9 MB while keeping small layers synchronous for instant load.
        """
        compressed: Dict[str, Any] = {}
        for lname, rows in (layer_records or {}).items():
            if not isinstance(rows, list) or not rows:
                compressed[lname] = []
                continue
            if len(rows) < int(min_rows_for_gzip):
                compressed[lname] = rows
                continue
            col_set: List[str] = []
            seen_cols = set()
            for r in rows:
                if not isinstance(r, dict):
                    continue
                for k in r.keys():
                    if k not in seen_cols:
                        seen_cols.add(k)
                        col_set.append(k)
            compact_rows: List[List[Any]] = []
            for r in rows:
                if not isinstance(r, dict):
                    continue
                row_vals = []
                for k in col_set:
                    v = r.get(k)
                    if isinstance(v, float):
                        v = round(v, 5)
                    row_vals.append(v)
                compact_rows.append(row_vals)
            payload_obj = {"cols": col_set, "rows": compact_rows}
            raw_bytes = json.dumps(payload_obj, default=str, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
            gz_bytes = gzip.compress(raw_bytes, compresslevel=6)
            compressed[lname] = {
                "__format__": "qdash_cols_gzip_b64",
                "count": len(compact_rows),
                "data": base64.b64encode(gz_bytes).decode("ascii"),
            }
        return compressed

    @staticmethod
    def _deduplicate_initial_geojson(
        initial_geojson: Optional[Dict[str, Any]],
        vector_pyramids: Optional[Dict[str, Any]],
        min_features_to_dedup: int = 250,
    ) -> Dict[str, Any]:
        """Avoid embedding large duplicate GeoJSON when vector_pyramids already stores compressed LOD geometries (#16)."""
        out: Dict[str, Any] = {}
        pyramids = vector_pyramids or {}
        for lname, fc in (initial_geojson or {}).items():
            vp = pyramids.get(lname)
            feats = (fc or {}).get("features") if isinstance(fc, dict) else None
            has_pyramid = isinstance(vp, dict) and bool((vp.get("lod1") or {}).get("data_b64"))
            if has_pyramid and isinstance(feats, list) and len(feats) >= int(min_features_to_dedup):
                out[lname] = {"type": "FeatureCollection", "features": []}
            else:
                out[lname] = fc
        return out

    @staticmethod
    def _sanitize_wms_services(ogc_descriptors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Keep Maa-amet Hallkaart, Põhikaart, EESTIFOTO Ortofoto, and HYBRID; remove CIR (#8)."""
        cleaned: List[Dict[str, Any]] = []
        for svc in ogc_descriptors:
            if not isinstance(svc, dict):
                continue
            if svc.get("type") == "wms":
                lyrs = str(svc.get("layers") or "")
                if lyrs == "cir_ngr":
                    continue
                if lyrs == "MA-FOTOKAART":
                    svc = dict(svc)
                    svc["layers"] = "EESTIFOTO"
                    svc["format"] = "image/jpeg"
                    svc["url"] = "https://kaart.maaamet.ee/wms/fotokaart"
            cleaned.append(svc)
        return cleaned

    @staticmethod
    def _build_export_data_catalog(
        config: DashboardConfig,
        ogc_descriptors: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Assemble comprehensive WFS/WMS servers + seeded Estonian layers for the HTML Data Catalog."""
        servers: List[Dict[str, Any]] = []
        seen_keys: set = set()
        raw_servers: List[Dict[str, Any]] = []
        try:
            raw_servers = LocalCatalogManager().get_servers()
        except Exception:
            raw_servers = []
        if not raw_servers:
            raw_servers = list(DEFAULT_CATALOG_SERVERS)

        for srv in raw_servers:
            if not isinstance(srv, dict):
                continue
            url = str(srv.get("url") or "").strip()
            stype = str(srv.get("service_type") or srv.get("type") or "wfs").lower()
            is_base = bool(srv.get("is_basemap", False))
            if not url or (stype == "wms" and is_base):
                continue
            key = (stype, url.lower())
            seen_keys.add(key)
            layers = [
                {
                    "name": str(l.get("name") or "").strip(),
                    "title": str(l.get("title") or l.get("name") or "").strip(),
                    "service_type": str(l.get("service_type") or stype).lower(),
                    "crs": str(l.get("crs") or srv.get("crs") or "EPSG:3301"),
                }
                for l in (srv.get("layers") or [])
                if isinstance(l, dict) and str(l.get("name") or "").strip()
            ]
            servers.append(
                {
                    "name": str(srv.get("name") or url),
                    "service_type": stype,
                    "url": url,
                    "crs": str(srv.get("crs") or "EPSG:3301"),
                    "layers": layers,
                }
            )

        for svc in ogc_descriptors:
            if not isinstance(svc, dict) or svc.get("is_basemap"):
                continue
            url = str(svc.get("url") or "").strip()
            stype = str(svc.get("type") or "wfs").lower()
            tname = str(svc.get("typename") or svc.get("layers") or svc.get("name") or "").strip()
            title = str(svc.get("name") or tname).strip()
            if not url or not tname:
                continue
            key = (stype, url.lower())
            if key in seen_keys:
                for ex in servers:
                    if ex["service_type"] == stype and ex["url"].lower() == url.lower():
                        if not any(l["name"] == tname for l in ex["layers"]):
                            ex["layers"].append(
                                {"name": tname, "title": title, "service_type": stype, "crs": "EPSG:3301"}
                            )
                        break
            else:
                seen_keys.add(key)
                servers.append(
                    {
                        "name": title or url,
                        "service_type": stype,
                        "url": url,
                        "crs": "EPSG:3301",
                        "layers": [{"name": tname, "title": title, "service_type": stype, "crs": "EPSG:3301"}],
                    }
                )
        return servers

    @classmethod
    def export_to_file(
        cls,
        config: DashboardConfig,
        layer_records: Dict[str, List[Dict[str, Any]]],
        excel_records_by_id: Dict[str, List[Dict[str, Any]]],
        output_path: str,
        project_dir: Optional[str] = None,
        initial_geojson: Optional[Dict[str, Any]] = None,
        layer_stats: Optional[Dict[str, Any]] = None,
        vector_pyramids: Optional[Dict[str, Any]] = None,
        has_preview_api: bool = False,
        preview_cache_rev: int = 1,
        spatial_relations: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Compile and write the standalone HTML dashboard (and optional sidecar file) to output_path."""
        resolved_out = PortablePathResolver.resolve(output_path, project_dir=project_dir)
        os.makedirs(os.path.dirname(os.path.abspath(resolved_out)), exist_ok=True)
        if resolved_out.lower().endswith(".aspx") and getattr(config, "export_format", "html") != "aspx":
            config.export_format = "aspx"
        sidecar_rel = ""
        sidecar_payload: Optional[Dict[str, Any]] = None
        if getattr(config, "export_mode", "compact_single") == "sidecar":
            stem = os.path.splitext(resolved_out)[0]
            sidecar_path = f"{stem}.qdash.data.js"
            sidecar_rel = os.path.basename(sidecar_path)
            sidecar_obj: Dict[str, Any] = {}
            html_content, sidecar_obj = cls._compile_html_with_sidecar(
                config=config,
                layer_records=layer_records,
                excel_records_by_id=excel_records_by_id,
                initial_geojson=initial_geojson,
                layer_stats=layer_stats,
                vector_pyramids=vector_pyramids,
                has_preview_api=has_preview_api,
                preview_cache_rev=preview_cache_rev,
                sidecar_filename=sidecar_rel,
                spatial_relations=spatial_relations,
            )
            sc_json = (
                json.dumps(sidecar_obj, default=str, separators=(",", ":"))
                .replace("<", "\\u003c")
                .replace(">", "\\u003e")
                .replace("&", "\\u0026")
            )
            with open(sidecar_path, "w", encoding="utf-8") as sfh:
                sfh.write(f"window.__QDASH_SIDECAR__ = {sc_json};\n")
        else:
            html_content = cls.compile_html(
                config=config,
                layer_records=layer_records,
                excel_records_by_id=excel_records_by_id,
                initial_geojson=initial_geojson,
                layer_stats=layer_stats,
                vector_pyramids=vector_pyramids,
                has_preview_api=has_preview_api,
                preview_cache_rev=preview_cache_rev,
                spatial_relations=spatial_relations,
            )
        with open(resolved_out, "w", encoding="utf-8") as fh:
            fh.write(html_content)
        return resolved_out

    @classmethod
    def compile_html(
        cls,
        config: DashboardConfig,
        layer_records: Dict[str, List[Dict[str, Any]]],
        excel_records_by_id: Dict[str, List[Dict[str, Any]]],
        initial_geojson: Optional[Dict[str, Any]] = None,
        layer_stats: Optional[Dict[str, Any]] = None,
        vector_pyramids: Optional[Dict[str, Any]] = None,
        has_preview_api: bool = False,
        preview_cache_rev: int = 1,
        spatial_relations: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Generate the complete standalone HTML string for the dashboard."""
        html_str, _sc = cls._compile_html_with_sidecar(
            config=config,
            layer_records=layer_records,
            excel_records_by_id=excel_records_by_id,
            initial_geojson=initial_geojson,
            layer_stats=layer_stats,
            vector_pyramids=vector_pyramids,
            has_preview_api=has_preview_api,
            preview_cache_rev=preview_cache_rev,
            sidecar_filename="",
            spatial_relations=spatial_relations,
        )
        return html_str

    @classmethod
    def _compile_html_with_sidecar(
        cls,
        config: DashboardConfig,
        layer_records: Dict[str, List[Dict[str, Any]]],
        excel_records_by_id: Dict[str, List[Dict[str, Any]]],
        initial_geojson: Optional[Dict[str, Any]] = None,
        layer_stats: Optional[Dict[str, Any]] = None,
        vector_pyramids: Optional[Dict[str, Any]] = None,
        has_preview_api: bool = False,
        preview_cache_rev: int = 1,
        sidecar_filename: str = "",
        spatial_relations: Optional[List[Dict[str, Any]]] = None,
    ) -> Tuple[str, Dict[str, Any]]:
        """Compile HTML plus optional heavy sidecar payload (#16)."""
        exported_at = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        ds_by_name: Dict[str, Any] = {
            str(ds.name): ds for ds in (getattr(config, "data_sources", []) or []) if getattr(ds, "name", "")
        }
        ogc_descriptors: List[Dict[str, Any]] = []
        for ds in config.data_sources:
            if ds.source_type in ("wfs", "wms"):
                desc = OgcConnector.build_browser_descriptor(ds)
                desc["data_state"] = str(getattr(ds, "data_state", "auto") or "auto")
                desc["effective_state"] = ds.effective_data_state(for_browser_export=True)
                desc["designer_pinned_static"] = ds.is_designer_pinned_static()
                desc["sharepoint_web_url"] = str(getattr(ds, "sharepoint_web_url", "") or "")
                desc["packaged_at"] = exported_at
                ogc_descriptors.append(desc)
        ogc_descriptors = cls._sanitize_wms_services(ogc_descriptors)

        lang = "en" if str(getattr(config, "language", "et")).lower().startswith("en") else "et"
        init_title = (config.title_en if lang == "en" and getattr(config, "title_en", "") else config.title)
        init_subtitle = (
            config.subtitle_en if lang == "en" and getattr(config, "subtitle_en", "") else config.subtitle
        )
        wfs_catalog_urls = list(getattr(config, "wfs_catalog_urls", None) or [])
        default_eelis_url = wfs_catalog_urls[0] if wfs_catalog_urls else "https://gsavalik.envir.ee/geoserver/eelis/ows"

        resolved_theme = ThemeManager.resolve_mode(getattr(config, "theme", "auto"))
        dash_dict = config.to_dict()
        dash_dict["theme"] = resolved_theme
        for ds_d in dash_dict.get("data_sources", []) or []:
            if not isinstance(ds_d, dict):
                continue
            ds_obj = ds_by_name.get(str(ds_d.get("name") or ""))
            if ds_obj is not None:
                ds_d["data_state"] = str(getattr(ds_obj, "data_state", "auto") or "auto")
                ds_d["effective_state"] = ds_obj.effective_data_state(for_browser_export=True)
                ds_d["designer_pinned_static"] = ds_obj.is_designer_pinned_static()
                ds_d["sharepoint_web_url"] = str(getattr(ds_obj, "sharepoint_web_url", "") or "")
                ds_d["packaged_at"] = exported_at
        pkg_layers = bool(getattr(config, "package_layers_in_export", True))
        is_aspx = str(getattr(config, "export_format", "html") or "html").lower() == "aspx"
        export_tier = str(getattr(config, "export_tier", "full") or "full").strip().lower()
        if export_tier not in ("full", "medium", "minimal"):
            export_tier = "full"
        dash_dict["export_tier"] = export_tier
        dash_dict["auto_home_on_filter_clear"] = bool(getattr(config, "auto_home_on_filter_clear", True))
        wfs_layer_names = {
            str(s.get("name") or "")
            for s in ogc_descriptors
            if isinstance(s, dict) and s.get("type") == "wfs" and s.get("geojson_url")
        }
        live_strip_names = {
            str(ds.name)
            for ds in (getattr(config, "data_sources", []) or [])
            if getattr(ds, "name", "")
            and not getattr(ds, "is_basemap", False)
            and ds.effective_data_state(for_browser_export=True) == "live"
            and (
                str(getattr(ds, "source_type", "")).lower() == "wfs"
                or str(getattr(ds, "sharepoint_web_url", "") or "").strip().lower().startswith(("http://", "https://"))
                or str(getattr(ds, "source_type", "")).lower() == "sharepoint_list"
            )
        }

        data_catalog = cls._build_export_data_catalog(config, ogc_descriptors) if export_tier == "full" else []
        merged_layer_records = dict(layer_records or {})
        excel_map = excel_records_by_id or {}
        for ds in getattr(config, "data_sources", []) or []:
            if ds.name and ds.name not in merged_layer_records and ds.id in excel_map:
                merged_layer_records[ds.name] = excel_map[ds.id]

        if not pkg_layers:
            for w_ln in live_strip_names:
                if w_ln in merged_layer_records:
                    merged_layer_records[w_ln] = []
            initial_geojson_use: Optional[Dict[str, Any]] = {
                k: v for k, v in (initial_geojson or {}).items() if k not in live_strip_names
            }
            vector_pyramids_use: Dict[str, Any] = {
                k: v for k, v in (vector_pyramids or {}).items() if k not in live_strip_names
            }
            spatial_relations_use: List[Dict[str, Any]] = [
                r
                for r in (spatial_relations or [])
                if isinstance(r, dict)
                and r.get("layer_a") not in live_strip_names
                and r.get("layer_b") not in live_strip_names
            ]
            if live_strip_names:
                dash_dict["html_data_mode"] = "live"
            dash_dict["package_layers_in_export"] = False
        else:
            initial_geojson_use = initial_geojson
            vector_pyramids_use = vector_pyramids or {}
            spatial_relations_use = list(spatial_relations or [])
            dash_dict["package_layers_in_export"] = True

        compressed_records = cls._compress_layer_records(merged_layer_records)
        dedup_geojson = cls._deduplicate_initial_geojson(initial_geojson_use, vector_pyramids_use)
        packaged_basemap = (
            cls._fetch_packaged_basemap_bundle(config, ogc_descriptors)
            if (pkg_layers and not has_preview_api)
            else None
        )
        sidecar_data: Dict[str, Any] = {}

        if sidecar_filename:
            sidecar_data = {
                "initial_layer_records": compressed_records,
                "initial_geojson": dedup_geojson,
                "vector_pyramids": vector_pyramids_use,
                "spatial_relations": spatial_relations_use,
                "excel_tables": excel_records_by_id,
                "packaged_basemap": packaged_basemap,
            }
            bundle = {
                "dashboard": dash_dict,
                "i18n": get_translations_bundle(),
                "default_eelis_wfs_url": default_eelis_url,
                "data_catalog": data_catalog,
                "ogc_services": ogc_descriptors,
                "initial_layer_records": {},
                "initial_geojson": {},
                "layer_stats": layer_stats or {},
                "vector_pyramids": {},
                "spatial_relations": [],
                "packaged_basemap": None,
                "has_preview_api": bool(has_preview_api),
                "preview_cache_rev": int(preview_cache_rev or 1),
                "excel_tables": {},
                "exported_at": exported_at,
                "expects_sidecar": True,
                "sidecar_filename": sidecar_filename,
            }
            sidecar_tag = f'<script src="{_html_lib.escape(sidecar_filename, quote=True)}"></script>'
        else:
            bundle = {
                "dashboard": dash_dict,
                "i18n": get_translations_bundle(),
                "default_eelis_wfs_url": default_eelis_url,
                "data_catalog": data_catalog,
                "ogc_services": ogc_descriptors,
                "initial_layer_records": compressed_records,
                "initial_geojson": dedup_geojson,
                "layer_stats": layer_stats or {},
                "vector_pyramids": vector_pyramids_use,
                "spatial_relations": spatial_relations_use,
                "packaged_basemap": packaged_basemap,
                "has_preview_api": bool(has_preview_api),
                "preview_cache_rev": int(preview_cache_rev or 1),
                "excel_tables": excel_records_by_id,
                "exported_at": exported_at,
                "expects_sidecar": False,
                "sidecar_filename": "",
            }
            sidecar_tag = ""

        vendor_css, vendor_js = cls._get_inlined_vendor_assets()

        bundle_json = (
            json.dumps(bundle, default=str, separators=(",", ":"))
            .replace("<", "\\u003c")
            .replace(">", "\\u003e")
            .replace("&", "\\u0026")
            .replace("]]>", "]]\\u003e")
        )
        init_title_esc = _html_lib.escape(str(init_title or ""), quote=True)
        init_subtitle_esc = _html_lib.escape(str(init_subtitle or ""), quote=True)
        favicon_uri = cls._get_favicon_data_uri()
        favicon_tag = (
            f'\n  <link rel="icon" type="image/svg+xml" href="{favicon_uri}" />'
            if favicon_uri
            else ""
        )
        sharepoint_meta = (
            '\n  <meta name="ProgId" content="SharePoint.WebPartPage.Document" />'
            '\n  <meta http-equiv="X-UA-Compatible" content="IE=edge" />'
            if is_aspx
            else ""
        )

        html_out = f"""<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="{lang}" data-theme="{resolved_theme}">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />{sharepoint_meta}
  <title>{init_title_esc} — GeoDash</title>{favicon_tag}
  <script>//<![CDATA[
    (function installXhtmlDomBootstrap() {{
      if (typeof document === 'undefined') return;
      const XHTML_NS = 'http://www.w3.org/1999/xhtml';
      const isXmlDoc = /xml/i.test(String(document.contentType || ''))
        || (typeof document.createElement === 'function' && typeof document.createElementNS === 'function' && !document.createElement('div').style);
      if (!isXmlDoc) return;
      try {{
        if (typeof document.createElementNS === 'function') {{
          const origCreate = document.createElement.bind(document);
          document.createElement = function(tagName, options) {{
            try {{
              return document.createElementNS(XHTML_NS, String(tagName || 'div').toLowerCase());
            }} catch (_e) {{
              return origCreate(tagName, options);
            }}
          }};
        }}
        if (!document.head) {{
          try {{
            Object.defineProperty(document, 'head', {{
              configurable: true,
              get: function() {{ return document.getElementsByTagName('head')[0] || document.documentElement; }}
            }});
          }} catch (_eh) {{}}
        }}
        if (!document.body) {{
          try {{
            Object.defineProperty(document, 'body', {{
              configurable: true,
              get: function() {{ return document.getElementsByTagName('body')[0] || null; }}
            }});
          }} catch (_eb) {{}}
        }}
        if (typeof Element !== 'undefined') {{
          const desc = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML')
            || (typeof HTMLElement !== 'undefined' ? Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'innerHTML') : null);
          if (desc && typeof desc.set === 'function') {{
            const origSet = desc.set;
            const parseHtmlNodes = (htmlStr) => {{
              const parsed = new DOMParser().parseFromString('<!DOCTYPE html><html><body>' + String(htmlStr ?? '') + '</body></html>', 'text/html');
              return (parsed && parsed.body) ? Array.from(parsed.body.childNodes || []) : [];
            }};
            const patchedDesc = {{
              configurable: true,
              get: desc.get,
              set: function(val) {{
                try {{
                  return origSet.call(this, val);
                }} catch (_xmlErr) {{
                  while (this.firstChild) this.removeChild(this.firstChild);
                  const nodes = parseHtmlNodes(val);
                  for (let i = 0; i < nodes.length; i++) {{
                    this.appendChild(document.importNode(nodes[i], true));
                  }}
                }}
              }}
            }};
            try {{ Object.defineProperty(Element.prototype, 'innerHTML', patchedDesc); }} catch (_e1) {{}}
            if (typeof HTMLElement !== 'undefined') {{
              try {{ Object.defineProperty(HTMLElement.prototype, 'innerHTML', patchedDesc); }} catch (_e2) {{}}
            }}
            if (typeof Element.prototype.insertAdjacentHTML === 'function') {{
              const origIns = Element.prototype.insertAdjacentHTML;
              Element.prototype.insertAdjacentHTML = function(pos, htmlStr) {{
                try {{
                  return origIns.call(this, pos, htmlStr);
                }} catch (_xmlErr) {{
                  const frag = document.createDocumentFragment();
                  const nodes = parseHtmlNodes(htmlStr);
                  for (let i = 0; i < nodes.length; i++) frag.appendChild(document.importNode(nodes[i], true));
                  const p = String(pos || '').toLowerCase();
                  if (p === 'beforebegin' && this.parentNode) this.parentNode.insertBefore(frag, this);
                  else if (p === 'afterbegin') this.insertBefore(frag, this.firstChild);
                  else if (p === 'beforeend') this.appendChild(frag);
                  else if (p === 'afterend' && this.parentNode) this.parentNode.insertBefore(frag, this.nextSibling);
                }}
              }};
            }}
          }}
        }}
      }} catch (_bootErr) {{}}
    }})();
  //]]></script>
  <style>/*<![CDATA[*/
{vendor_css}
  /*]]>*/</style>
  <script>//<![CDATA[
{vendor_js}
    (function configureInlineLeafletDefaults() {{
      try {{
        if (typeof L !== 'undefined' && L.Icon && L.Icon.Default) {{
          const pinUri = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="25" height="41" viewBox="0 0 25 41"><path fill="#0ea5e9" stroke="#0f172a" stroke-width="1.5" d="M12.5 1C6.2 1 1 6.2 1 12.5c0 8.6 11.5 26.8 11.5 26.8S24 21.1 24 12.5C24 6.2 18.8 1 12.5 1z"/><circle cx="12.5" cy="12.5" r="4.5" fill="#ffffff"/></svg>');
          L.Icon.Default.mergeOptions({{ iconUrl: pinUri, iconRetinaUrl: pinUri, shadowUrl: '' }});
        }}
      }} catch (_iconErr) {{}}
    }})();
    window.__onPlotlyLoaded = function() {{
      if (typeof renderWidgetsOnly === 'function') {{
        try {{ renderWidgetsOnly(); }} catch (_e) {{}}
      }}
    }};
  //]]></script>
  <script async="async" src="https://cdn.plot.ly/plotly-2.32.0.min.js" onload="if(typeof window.__onPlotlyLoaded==='function')window.__onPlotlyLoaded()"></script>
  {sidecar_tag}
  <style>/*<![CDATA[*/
    :root {{
      --bg-primary: #0f172a;
      --bg-secondary: #1e293b;
      --bg-card: #1e293b;
      --bg-hover: #334155;
      --text-primary: #f8fafc;
      --text-secondary: #94a3b8;
      --border-color: #334155;
      --accent: #38bdf8;
      --accent-emerald: #34d399;
      --accent-amber: #fbbf24;
      --accent-rose: #f43f5e;
    }}
    html[data-theme="light"] {{
      --bg-primary: #f8fafc;
      --bg-secondary: #ffffff;
      --bg-card: #ffffff;
      --bg-hover: #e0f2fe;
      --text-primary: #0f172a;
      --text-secondary: #475569;
      --border-color: #dbe4ee;
      --accent: #0284c7;
      --accent-emerald: #059669;
      --accent-amber: #d97706;
      --accent-rose: #e11d48;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
      background: var(--bg-primary);
      color: var(--text-primary);
      min-height: 100vh;
      width: 100%;
      max-width: 100vw;
      overflow-x: hidden;
      display: flex;
      flex-direction: column;
    }}
    header {{
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
      padding: 12px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
      width: 100%;
      max-width: 100%;
      box-sizing: border-box;
    }}
    header > div:first-child {{
      min-width: 0;
      max-width: 100%;
    }}
    .brand-title {{ font-size: 1.15rem; font-weight: 700; display: flex; align-items: center; flex-wrap: wrap; gap: 10px; max-width: 100%; }}
    .brand-subtitle {{ font-size: 0.82rem; color: var(--text-secondary); }}
    .status-pill {{
      font-size: 0.75rem;
      padding: 4px 10px;
      border-radius: 999px;
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid var(--accent);
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 5px;
    }}
    .status-pill.status-pill-live {{
      background: rgba(16, 185, 129, 0.16);
      color: var(--accent-emerald);
      border-color: var(--accent-emerald);
    }}
    .status-pill.status-pill-cached {{
      background: rgba(251, 191, 36, 0.16);
      color: var(--accent-amber);
      border-color: var(--accent-amber);
    }}
    .status-pill.status-pill-checking {{
      background: rgba(56, 189, 248, 0.16);
      color: var(--accent);
      border-color: var(--accent);
    }}
    .status-pill.status-pill-warn {{
      background: rgba(245, 158, 11, 0.18);
      color: #f59e0b;
      border-color: #f59e0b;
    }}
    .status-pill.status-pill-error {{
      background: rgba(239, 68, 68, 0.18);
      color: #f87171;
      border-color: #ef4444;
    }}
    .status-pill.status-pill-partial {{
      background: rgba(14, 165, 233, 0.16);
      color: #0284c7;
      border-color: rgba(14, 165, 233, 0.72);
    }}
    html[data-theme="dark"] .status-pill.status-pill-partial {{
      color: #38bdf8;
    }}
    .spatial-unavailable-notice {{
      padding: 8px 11px;
      border-radius: 7px;
      background: rgba(245, 158, 11, 0.14);
      border: 1px solid rgba(245, 158, 11, 0.45);
      color: #d97706;
      font-size: 0.77rem;
      line-height: 1.35;
      margin-top: 6px;
    }}
    .toolbar-actions {{
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: nowrap;
      flex: 0 1 auto;
      max-width: 100%;
      min-width: 0;
      overflow-x: auto;
      overflow-y: hidden;
      -webkit-overflow-scrolling: touch;
      scrollbar-width: auto;
      scrollbar-color: var(--accent) var(--bg-panel);
      padding-bottom: 6px;
    }}
    .toolbar-actions::-webkit-scrollbar {{
      height: 9px;
    }}
    .toolbar-actions::-webkit-scrollbar-track {{
      background: var(--bg-panel);
      border: 1px solid var(--border-color);
      border-radius: 5px;
    }}
    .toolbar-actions::-webkit-scrollbar-thumb {{
      background: var(--text-secondary);
      border-radius: 5px;
      min-width: 36px;
    }}
    .toolbar-actions::-webkit-scrollbar-thumb:hover {{
      background: var(--accent);
    }}
    .toolbar-actions > button {{
      flex-shrink: 0;
      white-space: nowrap;
    }}
    button, select, input {{
      background: var(--bg-primary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 0.82rem;
      cursor: pointer;
    }}
    button:hover {{ background: var(--bg-hover); border-color: var(--accent); }}
    button.active {{ background: var(--accent); color: #0f172a; font-weight: 600; }}
    .html-refresh-bar {{
      display: none;
      align-items: center;
      gap: 8px;
      padding: 3px 10px;
      border-radius: 999px;
      background: rgba(56, 189, 248, 0.14);
      border: 1px solid rgba(56, 189, 248, 0.45);
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--text-primary);
      max-width: 100%;
    }}
    .html-refresh-track {{
      display: inline-block;
      width: 84px;
      height: 6px;
      border-radius: 999px;
      background: rgba(148, 163, 184, 0.28);
      overflow: hidden;
      flex-shrink: 0;
    }}
    .html-refresh-fill {{
      display: block;
      height: 100%;
      width: 0%;
      border-radius: 999px;
      background: linear-gradient(90deg, #38bdf8, #34d399);
      transition: width 0.18s ease;
    }}
    .slicer-bar {{
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
      padding: 10px 20px;
      display: flex;
      align-items: center;
      gap: 16px;
      flex-wrap: wrap;
    }}
    .slicer-group {{ display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }}
    .slicer-label {{ font-size: 0.78rem; font-weight: 600; color: var(--text-secondary); text-transform: uppercase; }}
    .slicer-range-row {{ display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }}
    .slicer-range-input {{ border: 1px solid var(--border-color); border-radius: 6px; padding: 4px 6px; font-size: 0.82rem; background: var(--bg-primary); color: var(--text-primary); max-width: 120px; }}
    .slicer-range-btn {{ border: 1px solid var(--border-color); border-radius: 6px; padding: 4px 8px; font-size: 0.78rem; cursor: pointer; background: var(--bg-primary); color: var(--text-primary); }}
    .slicer-range-btn-primary {{ background: var(--accent); color: #0f172a; border-color: var(--accent); font-weight: 600; }}
    .chip {{
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 0.76rem;
      border: 1px solid var(--border-color);
      background: var(--bg-primary);
      cursor: pointer;
      user-select: none;
    }}
    .chip.selected {{
      background: var(--accent);
      color: #0f172a;
      border-color: var(--accent);
      font-weight: 600;
    }}
    .slicer-list-box {{
      display: flex;
      flex-direction: column;
      flex: 1 1 0;
      min-height: 60px;
      min-width: 0;
      width: 100%;
      box-sizing: border-box;
      gap: 4px;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      padding: 6px;
      overflow: hidden;
    }}
    .slicer-search {{
      width: auto;
      min-width: 140px;
      min-height: 26px;
      flex-shrink: 0;
      box-sizing: border-box;
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 5px;
      padding: 4px 8px;
      font-size: 0.76rem;
    }}
    .slicer-list-box .slicer-search,
    .workspace.freeform .slicer-search {{
      width: 100%;
      min-width: 0;
    }}
    .slicer-list-scroll {{
      flex: 1 1 auto;
      min-height: 28px;
      max-height: 150px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }}
    .slicer-list-item {{
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.76rem;
      padding: 2px 4px;
      border-radius: 4px;
      cursor: pointer;
    }}
    .slicer-list-item:hover {{ background: var(--bg-hover); }}
    .slicer-subpane .slicer-list-box {{ border: none; padding: 2px 0; min-height: 70px; }}
    .slicer-subpane .slicer-list-scroll {{ max-height: none; flex: 1 1 auto; min-height: 60px; }}
    .pivot-total-row td {{ font-weight: 700; border-top: 2px solid var(--accent); }}
    .btn-mini-icon {{
      padding: 2px 7px;
      font-size: 0.78rem;
      border-radius: 5px;
    }}
    .workspace-scroll {{
      flex: 1;
      width: 100%;
      min-width: 0;
      overflow: auto;
    }}
    body.iframe-embedded header {{
      padding: 8px 12px;
      gap: 6px;
    }}
    body.iframe-embedded .toolbar-actions {{
      flex-wrap: wrap;
      overflow-x: visible;
      gap: 5px;
      padding-bottom: 0;
    }}
    @media (max-width: 1220px) {{
      .toolbar-actions {{
        flex-wrap: wrap;
        overflow-x: visible;
        gap: 6px;
        padding-bottom: 0;
      }}
      .toolbar-actions > button {{
        padding: 5px 9px;
        font-size: 0.78rem;
      }}
    }}
    body.iframe-embedded .workspace-scroll {{
      overflow-x: hidden;
      padding: 4px 6px;
      box-sizing: border-box;
    }}
    body.iframe-fluid-grid .workspace.freeform {{
      display: grid !important;
      grid-template-columns: repeat(12, minmax(0, 1fr));
      gap: 10px;
      width: 100% !important;
      height: auto !important;
      margin: 0 !important;
      padding: 2px !important;
      border: none !important;
      box-shadow: none !important;
      background: transparent !important;
    }}
    body.iframe-fluid-grid .workspace.freeform .freeform-card {{
      position: static !important;
      left: auto !important;
      top: auto !important;
      width: auto !important;
      min-width: 0 !important;
      max-width: 100% !important;
    }}
    body.iframe-fluid-grid .workspace.freeform #map-card {{
      grid-column: 1 / -1;
      height: clamp(340px, 52vh, 500px) !important;
      min-height: 320px !important;
    }}
    body.iframe-fluid-grid .workspace.freeform .slicer-group.freeform-card {{
      height: auto !important;
      max-height: 300px !important;
    }}
    body.iframe-fluid-grid .workspace.freeform .kpi-card {{
      height: auto !important;
      min-height: 112px;
    }}
    body.iframe-fluid-grid .workspace.freeform .widget-card {{
      height: 310px !important;
      min-height: 240px;
    }}
    body.iframe-fluid-grid .workspace.freeform .table-card {{
      height: 320px !important;
    }}
    .workspace {{
      flex: 1;
      display: grid;
      grid-template-columns: 42% 58%;
      gap: 14px;
      padding: 14px;
      min-height: calc(100vh - 120px);
    }}
    .workspace.freeform {{
      display: block;
      position: relative;
      margin: 12px auto;
      padding: 0;
      min-height: 0;
      border: 1px dashed var(--border-color);
      border-radius: 10px;
      background: rgba(15, 23, 42, 0.25);
    }}
    html[data-theme="light"] .workspace.freeform {{
      background: #ffffff;
      box-shadow: 0 2px 12px rgba(15, 23, 42, 0.05);
    }}
    html[data-theme="light"] .freeform-card,
    html[data-theme="light"] .kpi-card,
    html[data-theme="light"] .widget-card,
    html[data-theme="light"] .map-card {{
      box-shadow: 0 1px 4px rgba(15, 23, 42, 0.06);
    }}
    .map-scale-btn {{
      color: #93c5fd;
      background: rgba(15, 23, 42, 0.72);
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 2px 8px;
      font-size: 0.74rem;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      flex-shrink: 0;
    }}
    .map-scale-btn:hover {{
      border-color: var(--accent);
      background: rgba(56, 189, 248, 0.16);
    }}
    .map-scale-menu {{
      position: fixed;
      z-index: 3000;
      min-width: 265px;
      max-width: min(320px, 92vw);
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      padding: 6px;
      box-shadow: 0 12px 28px rgba(0, 0, 0, 0.35);
      display: none;
      flex-direction: column;
      gap: 3px;
    }}
    .map-scale-menu-hdr {{
      font-size: 0.72rem;
      font-weight: 700;
      color: var(--text-secondary);
      padding: 4px 8px 6px 8px;
      border-bottom: 1px solid var(--border-color);
      margin-bottom: 2px;
    }}
    .map-scale-preset-btn {{
      width: 100%;
      text-align: left;
      background: transparent;
      border: 1px solid transparent;
      border-radius: 6px;
      padding: 5px 8px;
      font-size: 0.76rem;
      color: var(--text-primary);
      cursor: pointer;
    }}
    .map-scale-preset-btn:hover {{
      background: var(--bg-hover);
      border-color: var(--accent);
    }}
    .map-scale-manual-row {{
      display: flex;
      align-items: center;
      gap: 5px;
      padding: 6px 4px 2px 4px;
      border-top: 1px solid var(--border-color);
      margin-top: 3px;
      font-size: 0.76rem;
    }}
    .map-scale-manual-row input {{
      flex: 1;
      min-width: 85px;
      padding: 4px 7px;
      font-size: 0.76rem;
    }}
    html[data-theme="light"] #map-scale-badge {{
      color: #0369a1 !important;
      background: #e0f2fe !important;
      border-color: #bae6fd !important;
    }}
    .workspace.freeform .freeform-card {{
      position: absolute !important;
      margin: 0 !important;
      min-height: 0 !important;
      box-sizing: border-box;
    }}
    .workspace.freeform .widget-card.freeform-card {{
      overflow: hidden;
      resize: none;
      display: flex;
      flex-direction: column;
    }}
    .workspace.freeform .table-wrapper {{
      max-height: none !important;
      flex: 1 1 0;
      min-height: 0;
      overflow: auto;
    }}
    .workspace.freeform .plot-container {{
      min-height: 0;
      flex: 1 1 0;
    }}
    .workspace.freeform .slicer-group.freeform-card {{
      flex-direction: column;
      flex-wrap: nowrap;
      align-items: stretch;
      gap: 5px;
      padding: 8px 10px;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      overflow-y: auto;
      overflow-x: hidden;
    }}
    .workspace.freeform .slicer-list-scroll,
    .workspace.freeform .slicer-chips-scroll {{
      max-height: none;
    }}
    @media (max-width: 1100px) {{
      .workspace:not(.freeform) {{ grid-template-columns: 1fr; }}
    }}
    .map-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      resize: none;
      min-height: 460px;
    }}
    .card-header {{
      padding: 10px 14px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 8px;
      flex-shrink: 0;
      font-size: 0.88rem;
      font-weight: 600;
    }}
    #map-canvas {{ flex: 1; width: 100%; min-height: 420px; }}
    .leaflet-container {{
      background-color: #0b1528;
      background-image: linear-gradient(to right, rgba(148,163,184,0.08) 1px, transparent 1px),
                        linear-gradient(to bottom, rgba(148,163,184,0.08) 1px, transparent 1px);
      background-size: 32px 32px;
    }}
    html[data-theme="light"] .leaflet-container {{
      background-color: #eef4f8;
      background-image: linear-gradient(to right, rgba(51,65,85,0.07) 1px, transparent 1px),
                        linear-gradient(to bottom, rgba(51,65,85,0.07) 1px, transparent 1px);
      background-size: 32px 32px;
    }}
    .slicer-label,
    .slicer-select,
    .slicer-count-meta {{
      flex-shrink: 0;
    }}
    .slicer-select {{
      width: 100%;
      box-sizing: border-box;
      background: var(--bg-primary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 0.78rem;
    }}
    .slicer-chips-scroll {{
      display: flex;
      flex: 1 1 auto;
      min-height: 28px;
      gap: 6px;
      flex-wrap: wrap;
      align-content: flex-start;
      max-height: 150px;
      overflow-y: auto;
      padding: 2px 0;
    }}
    .slicer-count-meta {{
      font-size: 0.70rem;
      color: var(--text-secondary);
      text-align: right;
    }}
    .map-layers-drawer {{
      position: fixed;
      z-index: 3100;
      width: min(740px, 94vw);
      max-height: min(82vh, 660px);
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      box-shadow: 0 16px 40px rgba(2, 6, 23, 0.55);
      padding: 12px 14px;
      overflow: hidden;
      display: none;
      flex-direction: column;
      gap: 10px;
    }}
    .layers-drawer-hdr {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding-bottom: 6px;
      border-bottom: 1px solid rgba(148, 163, 184, 0.22);
      font-size: 0.84rem;
      font-weight: 700;
      flex-shrink: 0;
    }}
    .layers-drawer-grid {{
      display: grid;
      grid-template-columns: minmax(210px, 0.88fr) minmax(280px, 1.35fr);
      gap: 12px;
      min-height: 0;
      flex: 1 1 auto;
      overflow: hidden;
    }}
    .layers-drawer-left,
    .layers-drawer-right {{
      min-height: 0;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 6px;
      padding-right: 2px;
    }}
    @media (max-width: 720px) {{
      .layers-drawer-grid {{
        grid-template-columns: 1fr;
        overflow-y: auto;
      }}
      .layers-drawer-left,
      .layers-drawer-right {{
        overflow-y: visible;
      }}
    }}
    .layer-style-tabs {{
      display: flex;
      gap: 6px;
      border-bottom: 1px solid var(--border-color);
      padding-bottom: 6px;
      margin-bottom: 2px;
    }}
    .layer-style-tab-btn {{
      padding: 4px 10px;
      font-size: 0.76rem;
      font-weight: 600;
      border-radius: 6px;
      background: var(--bg-primary);
      color: var(--text-secondary);
      border: 1px solid var(--border-color);
      cursor: pointer;
    }}
    .layer-style-tab-btn.active {{
      background: var(--accent);
      color: #0f172a;
      border-color: var(--accent);
    }}
    .style-panel-grid {{
      display: grid;
      grid-template-columns: minmax(110px, auto) 1fr;
      gap: 7px 10px;
      align-items: center;
    }}
    .map-layers-hint {{
      font-size: 0.72rem;
      color: var(--text-secondary);
      margin-bottom: 2px;
    }}
    .map-layer-row {{
      display: flex;
      align-items: center;
      gap: 8px;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 0.78rem;
    }}
    .map-layer-row label {{
      display: flex;
      align-items: center;
      gap: 6px;
      flex: 1;
      cursor: pointer;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}
    .map-layer-order-btns {{
      display: flex;
      gap: 4px;
    }}
    .map-layer-order-btns button {{
      padding: 1px 7px;
      font-size: 0.74rem;
      border-radius: 4px;
    }}
    .widgets-panel {{
      display: flex;
      flex-direction: column;
      gap: 14px;
      overflow-y: auto;
    }}
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 12px;
    }}
    .kpi-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-left: 4px solid var(--accent);
      border-radius: 10px;
      padding: 14px 16px;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }}
    .kpi-title {{ font-size: 0.78rem; color: var(--text-secondary); text-transform: uppercase; font-weight: 600; }}
    .kpi-value {{ font-size: 1.65rem; font-weight: 700; color: var(--text-primary); }}
    .kpi-meta {{ font-size: 0.75rem; color: var(--text-secondary); display: flex; justify-content: space-between; }}
    .charts-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 14px;
    }}
    .widget-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      resize: none;
      min-height: 290px;
    }}
    .widget-card.table-card {{
      grid-column: 1 / -1;
    }}
    .plot-container {{ flex: 1; width: 100%; min-height: 245px; }}
    .table-wrapper {{
      overflow-x: auto;
      max-height: 380px;
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
    }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.8rem; }}
    th, td {{
      padding: 8px 10px;
      border-bottom: 1px solid var(--border-color);
      text-align: left;
      white-space: nowrap;
    }}
    th {{ background: var(--bg-primary); color: var(--text-secondary); position: sticky; top: 0; }}
    tr:hover td {{ background: var(--bg-hover); cursor: pointer; }}
    .map-legend {{
      background: rgba(15, 23, 42, 0.90);
      color: #f8fafc;
      padding: 7px 10px;
      border-radius: 8px;
      border: 1px solid #334155;
      font-size: 0.74rem;
      line-height: 1.5;
      max-width: 270px;
      max-height: 290px;
      overflow-y: auto;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.28);
    }}
    html[data-theme="light"] .map-legend {{
      background: rgba(255, 255, 255, 0.95);
      color: #0f172a;
      border-color: #cbd5e1;
      box-shadow: 0 3px 10px rgba(15, 23, 42, 0.10);
    }}
    .legend-hdr {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 4px;
    }}
    .panel-right-toggle-btn {{
      background: transparent;
      border: 1px solid rgba(148, 163, 184, 0.45);
      color: inherit;
      border-radius: 5px;
      padding: 1px 6px;
      font-size: 0.72rem;
      font-weight: 700;
      cursor: pointer;
      line-height: 1.35;
    }}
    .panel-right-toggle-btn:hover {{
      background: rgba(56, 189, 248, 0.18);
      border-color: var(--accent);
    }}
    .leaflet-right-collapsed {{
      width: auto !important;
      min-width: 0 !important;
      padding: 4px 8px !important;
      max-height: none !important;
      overflow: visible !important;
    }}
    .leaflet-control-layers-collapse-bar {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      font-size: 0.75rem;
      font-weight: 700;
      padding-bottom: 4px;
      margin-bottom: 4px;
      border-bottom: 1px solid rgba(148, 163, 184, 0.3);
    }}
    .leaflet-right-collapsed .leaflet-control-layers-collapse-bar {{
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
    }}
    .leaflet-right-collapsed .leaflet-control-layers-list {{
      display: none !important;
    }}
    .leaflet-layer-remove-btn {{
      background: transparent;
      border: 1px solid rgba(244, 63, 94, 0.45);
      color: #f43f5e;
      border-radius: 4px;
      padding: 0 5px;
      font-size: 0.72rem;
      font-weight: 700;
      line-height: 1.25;
      cursor: pointer;
      margin-left: auto;
    }}
    .leaflet-layer-remove-btn:hover {{
      background: rgba(244, 63, 94, 0.16);
    }}
    .map-layer-order-btns button.remove-btn {{
      color: #f43f5e;
      border-color: rgba(244, 63, 94, 0.45);
    }}
    .html-busy-pill {{
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(2, 132, 199, 0.16);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.45);
      border-radius: 999px;
      padding: 2px 10px;
      font-size: 0.74rem;
      font-weight: 600;
      margin-left: 8px;
    }}
    .busy-spin {{
      width: 11px;
      height: 11px;
      border: 2px solid rgba(56, 189, 248, 0.25);
      border-top-color: var(--accent);
      border-radius: 50%;
      display: inline-block;
      animation: qdashSpin 0.8s linear infinite;
    }}
    @keyframes qdashSpin {{
      to {{ transform: rotate(360deg); }}
    }}
    #map-card, .map-card {{
      position: relative;
    }}
    .map-render-loader {{
      position: absolute;
      top: 64px;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 1200;
      display: none;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      background: rgba(15, 23, 42, 0.14);
    }}
    .map-render-loader.active {{
      display: flex;
    }}
    .map-render-card {{
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 10px 18px;
      border-radius: 999px;
      background: rgba(15, 23, 42, 0.90);
      color: #f8fafc;
      border: 1px solid rgba(56, 189, 248, 0.55);
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.36);
      font-size: 0.84rem;
      font-weight: 600;
    }}
    .map-render-spinner {{
      width: 16px;
      height: 16px;
      border: 2.5px solid rgba(56, 189, 248, 0.28);
      border-top-color: var(--accent);
      border-radius: 50%;
      animation: qdashSpin 0.75s linear infinite;
    }}
    .map-addr-bar {{
      position: relative;
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: var(--bg-primary);
      border-bottom: 1px solid var(--border-color);
      font-size: 0.78rem;
    }}
    .map-addr-bar input {{
      flex: 1;
      min-width: 160px;
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 4px 9px;
      font-size: 0.78rem;
    }}
    .map-addr-results {{
      position: absolute;
      left: 14px;
      right: 14px;
      top: 100%;
      z-index: 1200;
      background: var(--bg-card);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.24);
      max-height: 220px;
      overflow-y: auto;
      display: none;
    }}
    .map-addr-item {{
      padding: 6px 10px;
      border-bottom: 1px solid var(--border-color);
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      gap: 8px;
      font-size: 0.76rem;
    }}
    .map-addr-item:hover {{
      background: var(--bg-hover);
    }}
    .image-widget-card .image-body {{
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 8px;
      overflow: hidden;
    }}
    .image-widget-card img {{
      max-width: 100%;
      max-height: 100%;
      width: 100%;
      height: 100%;
      border-radius: 6px;
      display: block;
    }}
    .image-widget-transparent {{
      background: transparent !important;
      border-color: transparent !important;
      box-shadow: none !important;
    }}
    .image-caption {{
      font-size: 0.75rem;
      color: var(--text-secondary);
      text-align: center;
      margin-top: 4px;
    }}
    .leaflet-home-btn {{
      background: #ffffff;
      color: #0f172a;
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      font-size: 15px;
      cursor: pointer;
      display: block;
      text-decoration: none;
      font-weight: 700;
    }}
    .leaflet-home-btn:hover {{
      background: #e0f2fe;
    }}
    .legend-dot {{
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 2px;
      margin-right: 6px;
      vertical-align: middle;
      box-sizing: border-box;
      flex-shrink: 0;
    }}
    .legend-dot-outline {{
      background: transparent !important;
      border-width: 2px;
      border-style: solid;
    }}
    .legend-empty {{
      font-size: 0.72rem;
      color: var(--text-secondary);
      opacity: 0.85;
      padding: 2px 0;
    }}
    /* Orderly 3-row Map Card Top Chrome & Comprehensive Andmekataloog */
    .card-header.map-title-row {{
      flex-wrap: nowrap;
      padding: 8px 12px;
      gap: 10px;
    }}
    .map-title-text {{
      flex: 1;
      min-width: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    .map-hdr-actions {{
      display: flex;
      align-items: center;
      gap: 6px;
      flex-shrink: 0;
    }}
    .map-sub-bar {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 5px 12px;
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
      flex-shrink: 0;
      flex-wrap: wrap;
    }}
    .map-telemetry-group {{
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
      flex-wrap: nowrap;
    }}
    .map-count-pill {{
      color: var(--text-secondary);
      font-size: 0.74rem;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    .btn-catalog-toggle {{
      border-color: rgba(56, 189, 248, 0.42);
      background: rgba(56, 189, 248, 0.10);
      color: var(--accent);
      font-weight: 600;
      white-space: nowrap;
      flex-shrink: 0;
    }}
    .btn-catalog-toggle.active {{
      background: var(--accent);
      color: #0f172a;
      border-color: var(--accent);
    }}
    .map-catalog-drawer {{
      background: var(--bg-primary);
      border-bottom: 1px solid var(--border-color);
      padding: 8px 12px;
      display: flex;
      flex-direction: column;
      gap: 7px;
      max-height: 295px;
      overflow: hidden;
      flex-shrink: 0;
      font-size: 0.77rem;
    }}
    .cat-controls-row {{
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }}
    .cat-controls-row input {{
      flex: 1 1 160px;
      min-width: 120px;
      padding: 4px 8px;
      font-size: 0.76rem;
    }}
    .cat-controls-row select {{
      flex: 0 1 165px;
      min-width: 110px;
      padding: 4px 7px;
      font-size: 0.76rem;
    }}
    .cat-controls-meta {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      font-size: 0.71rem;
      color: var(--text-secondary);
    }}
    .cat-add-panel {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      padding: 8px 10px;
      display: none;
      flex-direction: column;
      gap: 6px;
    }}
    .cat-add-tabs {{
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
    }}
    .cat-add-row {{
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }}
    .cat-add-row input,
    .cat-add-row select {{
      flex: 1 1 130px;
      min-width: 90px;
      padding: 4px 7px;
      font-size: 0.75rem;
    }}
    .cat-list-scroll {{
      flex: 1 1 auto;
      min-height: 90px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding-right: 2px;
    }}
    .cat-group-hdr {{
      font-size: 0.71rem;
      font-weight: 700;
      color: var(--text-secondary);
      text-transform: uppercase;
      letter-spacing: 0.03em;
      padding: 4px 2px 2px 2px;
      border-bottom: 1px solid var(--border-color);
      margin-top: 2px;
    }}
    .cat-item-row {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 4px 8px;
    }}
    .cat-item-main {{
      min-width: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 1px;
    }}
    .cat-item-title {{
      font-weight: 600;
      color: var(--text-primary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    .cat-item-sub {{
      font-size: 0.69rem;
      color: var(--text-secondary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    .cat-type-pill {{
      font-size: 0.65rem;
      font-weight: 700;
      padding: 1px 5px;
      border-radius: 4px;
      background: rgba(56, 189, 248, 0.14);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.30);
      flex-shrink: 0;
    }}
    /* Subtle chart filter hint (#12) */
    .chart-hint {{
      font-size: 0.72rem;
      color: var(--text-secondary);
      opacity: 0.72;
      font-style: italic;
      background: transparent;
      border: none;
      padding: 0;
      user-select: none;
    }}
    /* Table row selection highlighting (#12) */
    tr.selected-row td {{
      background: rgba(56, 189, 248, 0.24) !important;
      color: var(--text-primary);
      font-weight: 700;
    }}
    tr.selected-row td:first-child {{
      box-shadow: inset 3px 0 0 var(--accent);
    }}
    .btn-clear-widget {{
      padding: 1px 7px;
      font-size: 0.72rem;
      color: #f59e0b;
      border: 1px solid rgba(245, 158, 11, 0.48);
      border-radius: 5px;
      background: rgba(245, 158, 11, 0.10);
      cursor: pointer;
    }}
    .btn-clear-widget:hover {{ background: rgba(245, 158, 11, 0.22); }}
    /* Connected active-filter badge inside widget header / strip (#14) */
    .widget-filter-badge {{
      display: inline-flex;
      align-items: center;
      flex-shrink: 0;
      gap: 4px;
      padding: 2px 8px;
      font-size: 0.70rem;
      font-weight: 600;
      line-height: 1.3;
      border-radius: 999px;
      background: rgba(56, 189, 248, 0.14);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.35);
      max-width: 100%;
      white-space: normal;
      word-break: break-word;
      overflow-wrap: anywhere;
      box-sizing: border-box;
    }}
    .card-filter-strip {{
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px;
      padding: 4px 12px 6px 12px;
      border-bottom: 1px solid var(--border-color);
      background: rgba(56, 189, 248, 0.05);
      flex-shrink: 0;
    }}
    .kpi-card .widget-filter-badge {{
      align-self: flex-start;
    }}
    .workspace.freeform .kpi-card.freeform-card {{
      padding: 8px 12px;
      gap: 3px;
      justify-content: space-between;
      overflow-y: auto;
    }}
    .workspace.freeform .kpi-card.freeform-card .kpi-title {{
      font-size: 0.72rem;
      line-height: 1.2;
    }}
    .workspace.freeform .kpi-card.freeform-card .kpi-value {{
      font-size: 1.38rem;
      line-height: 1.15;
    }}
    .workspace.freeform .kpi-card.freeform-card .kpi-meta {{
      font-size: 0.70rem;
      line-height: 1.15;
      flex-shrink: 0;
    }}
    .expr-subtext {{
      font-size: 0.76rem;
      color: var(--text-secondary);
      line-height: 1.3;
      word-break: break-word;
    }}
    .expr-progress-track {{
      width: 100%;
      height: 10px;
      border-radius: 999px;
      background: rgba(148, 163, 184, 0.22);
      overflow: hidden;
      margin: 2px 0;
    }}
    .expr-progress-fill {{
      height: 100%;
      border-radius: 999px;
      background: var(--accent-emerald);
      transition: width 0.2s ease;
    }}
    /* Global Active Filters Banner (#14) */
    .active-filters-bar {{
      display: none;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px;
      padding: 6px 20px;
      background: rgba(56, 189, 248, 0.08);
      border-bottom: 1px solid rgba(56, 189, 248, 0.25);
      font-size: 0.78rem;
    }}
    .active-filters-bar.visible {{ display: flex; }}
    .active-filter-chip {{
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(56, 189, 248, 0.16);
      color: var(--text-primary);
      border: 1px solid rgba(56, 189, 248, 0.45);
      border-radius: 999px;
      padding: 2px 9px;
      font-size: 0.74rem;
      font-weight: 600;
      cursor: pointer;
    }}
    @media (hover: hover) {{
      .active-filter-chip:hover {{ background: rgba(244, 63, 94, 0.22); border-color: var(--accent-rose); }}
    }}
    .map-feature-label {{
      background: rgba(255, 255, 255, 0.9);
      color: #0f172a;
      border: 1px solid rgba(15, 23, 42, 0.28);
      border-radius: 3px;
      padding: 1px 5px;
      font-size: 10px;
      font-weight: 700;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.22);
      white-space: pre-line;
      text-align: center;
    }}
    .map-feature-label.map-feature-label-no-halo {{
      background: transparent !important;
      border-color: transparent !important;
      box-shadow: none !important;
      text-shadow: none !important;
    }}
    .qdash-label-svg {{
      position: absolute;
      top: 0;
      left: 0;
      pointer-events: none;
      overflow: visible;
    }}
    .qdash-map-label {{
      position: absolute;
      pointer-events: none;
      white-space: pre-line;
      text-align: center;
      font-weight: 700;
      line-height: 1.18;
      user-select: none;
      box-sizing: border-box;
      transform-origin: top left;
    }}
    .qdash-map-label-box {{
      background: rgba(255, 255, 255, 0.92);
      border: 1px solid rgba(15, 23, 42, 0.34);
      border-radius: 4px;
      padding: 2px 5px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.22);
    }}
    .qdash-map-label-box.qdash-map-label-darkbox {{
      background: rgba(15, 23, 42, 0.88);
      border-color: rgba(148, 163, 184, 0.45);
    }}
    .qdash-map-label-plain {{
      background: transparent !important;
      border: none !important;
      padding: 0 2px;
      box-shadow: none !important;
    }}
    .status-pill {{
      cursor: pointer;
    }}
    .live-status-menu {{
      position: fixed;
      z-index: 4200;
      min-width: 310px;
      max-width: 440px;
      max-height: 70vh;
      overflow-y: auto;
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      box-shadow: 0 14px 32px rgba(0, 0, 0, 0.38);
      padding: 10px 12px;
      font-size: 0.78rem;
    }}
    .live-status-menu-hdr {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: 700;
      padding-bottom: 6px;
      margin-bottom: 6px;
      border-bottom: 1px solid var(--border-color);
    }}
    .live-status-row {{
      display: flex;
      flex-direction: column;
      gap: 3px;
      padding: 6px 0;
      border-bottom: 1px dashed rgba(148, 163, 184, 0.22);
    }}
    .live-status-row:last-child {{ border-bottom: none; }}
    .live-status-sec-hdr {{
      font-size: 0.70rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      color: var(--accent);
      padding: 6px 0 3px 0;
      margin-top: 2px;
      border-bottom: 1px solid rgba(56, 189, 248, 0.25);
    }}
    .live-status-page-tag {{
      display: inline-block;
      font-size: 0.68rem;
      font-weight: 600;
      padding: 1px 6px;
      border-radius: 999px;
      background: rgba(148, 163, 184, 0.16);
      color: var(--text-secondary);
      margin-left: 4px;
      vertical-align: middle;
    }}
    .btn-layer-refresh {{
      padding: 1px 7px;
      font-size: 0.74rem;
      font-weight: 700;
      border-radius: 6px;
      border: 1px solid var(--border-color);
      background: var(--bg-primary);
      color: var(--text-primary);
      cursor: pointer;
      line-height: 1.35;
    }}
    .btn-layer-refresh:hover:not(:disabled) {{
      border-color: var(--accent);
      color: var(--accent);
    }}
    .btn-layer-refresh:disabled {{
      opacity: 0.55;
      cursor: wait;
    }}
    .refresh-scope-menu {{
      position: fixed;
      z-index: 4250;
      min-width: 245px;
      max-width: 340px;
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      box-shadow: 0 14px 32px rgba(0, 0, 0, 0.38);
      padding: 6px;
      display: none;
      flex-direction: column;
      gap: 3px;
      font-size: 0.79rem;
    }}
    .refresh-scope-item {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      width: 100%;
      text-align: left;
      padding: 6px 9px;
      border-radius: 7px;
      border: 1px solid transparent;
      background: transparent;
      color: var(--text-primary);
      cursor: pointer;
      font-size: 0.78rem;
    }}
    .refresh-scope-item:hover:not(:disabled) {{
      background: rgba(56, 189, 248, 0.14);
      border-color: rgba(56, 189, 248, 0.35);
    }}
    .refresh-scope-item.is-active-page {{
      font-weight: 700;
      background: rgba(56, 189, 248, 0.12);
      border-color: rgba(56, 189, 248, 0.35);
    }}
    .refresh-scope-item:disabled {{
      opacity: 0.55;
      cursor: not-allowed;
    }}
    .refresh-scope-meta {{
      font-size: 0.70rem;
      opacity: 0.78;
      white-space: nowrap;
    }}
    .refresh-scope-sep {{
      height: 1px;
      background: var(--border-color);
      margin: 3px 4px;
    }}
    .dev-log-drawer {{
      position: fixed;
      right: 14px;
      bottom: 14px;
      width: min(560px, calc(100vw - 28px));
      height: min(360px, 54vh);
      z-index: 4500;
      background: rgba(15, 23, 42, 0.97);
      color: #e2e8f0;
      border: 1px solid #38bdf8;
      border-radius: 10px;
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.55);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 11px;
    }}
    .dev-log-hdr {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      padding: 7px 10px;
      background: #1e293b;
      border-bottom: 1px solid #334155;
      font-weight: 700;
    }}
    .dev-log-body {{
      flex: 1;
      overflow-y: auto;
      padding: 6px 10px;
      line-height: 1.45;
    }}
    .dev-log-line {{ padding: 2px 0; border-bottom: 1px solid rgba(148,163,184,0.1); word-break: break-word; }}
    .dev-log-err {{ color: #fb7185; }}
    .dev-log-warn {{ color: #fbbf24; }}
    .dev-log-net {{ color: #38bdf8; }}
    /* Multidash / Dash-Atlas Pages Bar (#18) */
    .dashboard-pages-bar {{
      display: none;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
      padding: 6px 20px;
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
    }}
    .dashboard-pages-bar.visible {{ display: flex; }}
    .page-tab-btn {{
      padding: 4px 12px;
      border-radius: 6px;
      font-size: 0.80rem;
      font-weight: 600;
      border: 1px solid var(--border-color);
      background: var(--bg-primary);
      color: var(--text-primary);
      cursor: pointer;
    }}
    .page-tab-btn.active {{
      color: #ffffff;
    }}
    /* Layer drag reorder & inline style editor (#2, #4) */
    .map-layer-row[draggable="true"] {{ cursor: grab; }}
    .map-layer-row.drag-over {{ border-color: var(--accent); background: var(--bg-hover); }}
    .map-layer-style-panel {{
      margin-top: 6px;
      padding: 10px 12px;
      border-radius: 8px;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-size: 0.75rem;
    }}
    .style-panel-row {{
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px 12px;
    }}
    .style-panel-row + .style-panel-row {{
      padding-top: 6px;
      border-top: 1px solid rgba(148, 163, 184, 0.18);
    }}
    .map-layer-style-panel label {{ display: inline-flex; align-items: center; gap: 5px; color: var(--text-secondary); white-space: nowrap; }}
    .map-layer-style-panel input[type="number"] {{
      padding: 3px 6px !important;
      width: 64px !important;
      min-width: 60px;
      text-align: center;
      box-sizing: border-box;
      font-size: 0.78rem;
      line-height: 1.2;
    }}
    .map-layer-style-panel input[type="color"] {{
      padding: 1px 2px !important;
      width: 34px;
      height: 26px;
      cursor: pointer;
    }}
    .map-layer-style-panel input[type="range"] {{
      padding: 0 !important;
      width: 76px;
    }}
    .map-layer-style-panel select {{
      padding: 3px 8px !important;
      font-size: 0.76rem;
      max-width: 195px;
    }}
    .style-val-chip {{
      font-size: 0.72rem;
      font-weight: 600;
      color: var(--text-primary);
      min-width: 30px;
    }}
    /* Multi-Pane Slicer Container (#15) */
    .slicer-multi-panes {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      width: 100%;
      flex: 1 1 auto;
      min-height: 0;
      overflow-x: hidden;
      overflow-y: auto;
    }}
    .slicer-subpane {{
      flex: 1 1 180px;
      min-width: 150px;
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding: 6px 8px;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 7px;
      min-height: 120px;
    }}
    .slicer-subpane-hdr {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.73rem;
      font-weight: 700;
      color: var(--text-secondary);
    }}
    /* Mobile View & Sticky Quick Widget Nav (#3) */
    .mobile-nav-bar {{
      display: none;
      position: sticky;
      top: 0;
      z-index: 1500;
      align-items: center;
      gap: 6px;
      padding: 6px 8px;
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
      overflow-x: auto;
    }}
    .mobile-nav-arrow {{
      min-width: 38px;
      min-height: 36px;
      padding: 5px 10px;
      font-size: 1.08rem;
      line-height: 1;
      font-weight: 700;
      border-radius: 8px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }}
    .mobile-nav-pills {{
      position: relative;
      display: flex;
      align-items: center;
      gap: 6px;
      flex: 1;
      min-width: 0;
      overflow-x: auto;
      white-space: nowrap;
      scrollbar-width: none;
      scroll-behavior: smooth;
      padding: 0 6px;
    }}
    .mobile-nav-pills::-webkit-scrollbar {{
      display: none;
    }}
    .mobile-nav-pill {{
      flex-shrink: 0;
      max-width: 175px;
      overflow: hidden;
      text-overflow: ellipsis;
      padding: 5px 11px;
      border-radius: 999px;
      font-size: 0.76rem;
      border: 1px solid var(--border-color);
      background: var(--bg-primary);
      color: var(--text-primary);
      cursor: pointer;
    }}
    .mobile-nav-pill.active {{
      background: var(--accent);
      color: #0f172a;
      border-color: var(--accent);
      font-weight: 700;
    }}
    body.mobile-view {{
      height: 100vh;
      height: 100dvh;
      max-height: 100vh;
      max-height: 100dvh;
      padding-bottom: env(safe-area-inset-bottom, 0px);
      overflow: hidden;
    }}
    body.mobile-view .mobile-nav-bar {{
      display: flex;
      flex-shrink: 0;
    }}
    body.mobile-view .workspace-scroll {{
      flex: 1 1 0;
      min-height: 0;
      overflow-y: auto;
      overflow-x: hidden;
      -webkit-overflow-scrolling: touch;
      scroll-padding-bottom: 72px;
      scrollbar-width: none;
      -ms-overflow-style: none;
    }}
    body.mobile-view .workspace-scroll::-webkit-scrollbar {{
      width: 0;
      height: 0;
    }}
    .mobile-scroll-rail {{
      display: none;
      position: fixed;
      right: 2px;
      top: 108px;
      bottom: calc(14px + env(safe-area-inset-bottom, 0px));
      width: 14px;
      z-index: 1600;
      border-radius: 999px;
      background: rgba(148, 163, 184, 0.14);
      touch-action: none;
      user-select: none;
    }}
    body.mobile-view .mobile-scroll-rail.visible {{
      display: block;
    }}
    .mobile-scroll-blob {{
      position: absolute;
      left: 2px;
      right: 2px;
      top: 0;
      min-height: 40px;
      border-radius: 999px;
      background: rgba(56, 189, 248, 0.58);
      border: 1px solid rgba(248, 250, 252, 0.45);
      box-shadow: 0 2px 6px rgba(15, 23, 42, 0.35);
      cursor: grab;
      touch-action: none;
      transition: background 0.15s ease, transform 0.12s ease;
    }}
    .mobile-scroll-rail.dragging .mobile-scroll-blob {{
      background: rgba(56, 189, 248, 0.92);
      transform: scaleX(1.18);
      cursor: grabbing;
    }}
    body.mobile-view .workspace.freeform,
    body.mobile-view #workspace-main.workspace,
    body.mobile-view .workspace {{
      display: flex !important;
      flex-direction: column !important;
      align-items: stretch !important;
      width: 100% !important;
      max-width: 100% !important;
      height: auto !important;
      min-height: 0 !important;
      padding: 8px 18px calc(76px + env(safe-area-inset-bottom, 0px)) 8px !important;
      margin: 0 !important;
      gap: 10px !important;
      border: none !important;
      box-shadow: none !important;
      transform: none !important;
      overflow: visible !important;
    }}
    body.mobile-view .workspace.freeform .freeform-card,
    body.mobile-view .workspace .freeform-card,
    body.mobile-view .freeform-card {{
      position: static !important;
      left: auto !important;
      right: auto !important;
      top: auto !important;
      bottom: auto !important;
      width: 100% !important;
      max-width: 100% !important;
      min-width: 0 !important;
      height: auto !important;
      min-height: 100px !important;
      resize: none !important;
      margin: 0 !important;
      flex-shrink: 0 !important;
      scroll-margin-top: 56px;
    }}
    body.mobile-view .workspace.freeform .kpi-card.freeform-card,
    body.mobile-view .kpi-card {{
      min-height: 92px !important;
      height: auto !important;
      padding: 12px 14px !important;
    }}
    body.mobile-view .workspace.freeform .widget-card.freeform-card:not(.table-card) {{
      min-height: 310px !important;
      height: auto !important;
    }}
    body.mobile-view .workspace.freeform .widget-card.table-card.freeform-card {{
      min-height: 260px !important;
      max-height: 430px !important;
    }}
    body.mobile-view .plot-container {{
      flex: none !important;
      width: 100% !important;
      height: 270px !important;
      min-height: 240px !important;
    }}
    body.mobile-view #map-card,
    body.mobile-view .workspace.freeform #map-card.freeform-card {{
      min-height: 330px !important;
      height: auto !important;
    }}
    body.mobile-view #map-canvas {{
      flex: none !important;
      min-height: 250px !important;
      height: 48vh !important;
      max-height: 440px !important;
    }}
    body.mobile-view #map-canvas.mobile-scroll-locked {{
      touch-action: pan-y !important;
    }}
    body.mobile-view .workspace.freeform .slicer-group.freeform-card {{
      min-height: 270px !important;
      max-height: 400px !important;
      height: auto !important;
      padding: 10px 12px !important;
      gap: 6px !important;
      overflow: visible !important;
    }}
    body.mobile-view .slicer-list-box {{
      min-height: 162px !important;
      padding: 6px 8px !important;
    }}
    body.mobile-view .slicer-list-scroll {{
      min-height: 112px !important;
      max-height: 196px !important;
      gap: 4px !important;
      -webkit-overflow-scrolling: touch;
    }}
    body.mobile-view .slicer-list-item {{
      min-height: 28px;
      padding: 4px 6px;
      font-size: 0.86rem;
    }}
    body.mobile-view .slicer-chips-scroll {{
      min-height: 92px !important;
      max-height: 170px !important;
      -webkit-overflow-scrolling: touch;
    }}
    body.mobile-view .slicer-multi-panes {{
      flex-direction: column !important;
      overflow-y: auto !important;
    }}
    body.mobile-view .slicer-search,
    body.mobile-view #map-addr-input,
    body.mobile-view #map-catalog-search,
    body.mobile-view .cat-controls-row input {{
      font-size: 16px;
      min-height: 36px;
    }}
    body.mobile-view .table-wrapper {{
      max-height: 340px !important;
      -webkit-overflow-scrolling: touch;
    }}
    body.mobile-view header {{
      padding: 8px 10px;
      gap: 6px;
      flex-shrink: 0;
    }}
    body.mobile-view .brand-title {{
      font-size: 0.96rem;
      flex-wrap: wrap;
      gap: 6px;
    }}
    body.mobile-view .toolbar-actions {{
      width: 100%;
      flex-wrap: nowrap;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      gap: 5px;
      padding-bottom: 4px;
      scrollbar-width: thin;
      scrollbar-color: var(--accent) var(--bg-panel);
    }}
    body.mobile-view .toolbar-actions > button {{
      flex-shrink: 0;
      padding: 5px 9px;
      font-size: 0.76rem;
      white-space: nowrap;
    }}
    body.mobile-view .card-header {{
      padding: 7px 10px;
      flex-wrap: wrap;
      gap: 5px;
    }}
    body.mobile-view .map-sub-bar,
    body.mobile-view .map-catalog-drawer,
    body.mobile-view .map-addr-bar {{
      padding: 6px 10px;
    }}
    .mobile-focus-flash {{
      box-shadow: 0 0 0 2px var(--accent), 0 8px 24px rgba(56, 189, 248, 0.30) !important;
      transition: box-shadow 0.25s ease;
    }}
    @media (orientation: landscape) and (max-height: 540px) {{
      body.mobile-view header {{
        padding: 5px 10px;
        gap: 4px;
      }}
      body.mobile-view .brand-subtitle {{
        display: none;
      }}
      body.mobile-view #map-card,
      body.mobile-view .workspace.freeform #map-card.freeform-card {{
        min-height: 255px !important;
      }}
      body.mobile-view #map-canvas {{
        height: 55vh !important;
        min-height: 200px !important;
        max-height: 310px !important;
      }}
      body.mobile-view .workspace.freeform .widget-card.freeform-card:not(.table-card) {{
        min-height: 255px !important;
      }}
      body.mobile-view .plot-container {{
        height: 215px !important;
        min-height: 190px !important;
      }}
    }}
    /* Adjacent Border Dissolve (#5) */
    .dissolve-adj-top {{ border-top-width: 0 !important; border-top-left-radius: 0 !important; border-top-right-radius: 0 !important; }}
    .dissolve-adj-bottom {{ border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; }}
    .dissolve-adj-left {{ border-left-width: 0 !important; border-top-left-radius: 0 !important; border-bottom-left-radius: 0 !important; }}
    .dissolve-adj-right {{ border-top-right-radius: 0 !important; border-bottom-right-radius: 0 !important; }}
    /* Map Window Controls (#5) */
    .map-card.map-minimized {{
      min-height: 44px !important;
      height: 44px !important;
      overflow: hidden !important;
    }}
    .map-card.map-minimized .map-sub-bar,
    .map-card.map-minimized .map-addr-bar,
    .map-card.map-minimized #map-filter-strip,
    .map-card.map-minimized #map-layers-drawer,
    .map-card.map-minimized #map-catalog-drawer,
    .map-card.map-minimized #map-canvas,
    .map-card.map-minimized #map-render-loader {{
      display: none !important;
    }}
    .map-card.map-minimized .card-header.map-title-row {{
      border-bottom: none;
    }}
    .workspace.workspace-map-minimized:not(.freeform) {{
      grid-template-columns: 1fr !important;
      grid-template-rows: auto 1fr;
    }}
    .workspace.workspace-map-maximized:not(.freeform) {{
      grid-template-columns: 1fr !important;
    }}
    .map-maximized-hidden {{
      display: none !important;
    }}
    .workspace.workspace-map-maximized #map-card {{
      min-height: 540px !important;
      height: calc(100vh - 130px) !important;
      width: 100% !important;
    }}
    /* Settings Popover Menu (#6) */
    .settings-popover {{
      position: fixed;
      top: 58px;
      right: 16px;
      z-index: 3200;
      width: 296px;
      max-width: min(310px, 94vw);
      max-height: calc(100vh - 80px);
      overflow-y: auto;
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      box-shadow: 0 12px 32px rgba(2, 6, 23, 0.45);
      padding: 10px 12px;
      display: none;
      flex-direction: column;
      gap: 10px;
      font-size: 0.8rem;
    }}
    .settings-popover.open {{
      display: flex;
    }}
    .settings-sec {{
      display: flex;
      flex-direction: column;
      gap: 6px;
      padding-top: 8px;
      border-top: 1px solid rgba(148, 163, 184, 0.18);
    }}
    .settings-sec:first-child {{
      padding-top: 0;
      border-top: none;
    }}
    .settings-sec-hdr {{
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      color: var(--text-secondary);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }}
    .settings-scope-row {{
      display: flex;
      gap: 4px;
    }}
    .settings-scope-btn {{
      flex: 1;
      padding: 4px 6px;
      font-size: 0.72rem;
      border-radius: 5px;
    }}
    .settings-export-list {{
      display: flex;
      flex-direction: column;
      gap: 5px;
    }}
    .settings-menu-btn {{
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      font-size: 0.79rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
    }}
    .settings-check-row {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 0.79rem;
      color: var(--text-primary);
      cursor: pointer;
      padding: 3px 2px;
    }}
    .settings-check-row input[type="checkbox"] {{
      width: 15px;
      height: 15px;
      margin: 0;
      padding: 0;
      flex-shrink: 0;
    }}
    /* Export Tiers (#10) */
    body[data-export-tier="medium"] .map-addr-bar,
    body[data-export-tier="medium"] #btn-map-catalog,
    body[data-export-tier="medium"] #map-catalog-drawer,
    body[data-export-tier="medium"] #opt-row-extent,
    body[data-export-tier="medium"] #btn-dev-log,
    body[data-export-tier="medium"] #dev-log-drawer {{
      display: none !important;
    }}
    body[data-export-tier="minimal"] .map-addr-bar,
    body[data-export-tier="minimal"] #btn-map-catalog,
    body[data-export-tier="minimal"] #map-catalog-drawer,
    body[data-export-tier="minimal"] #opt-row-extent,
    body[data-export-tier="minimal"] #btn-dev-log,
    body[data-export-tier="minimal"] #dev-log-drawer,
    body[data-export-tier="minimal"] #btn-map-layers,
    body[data-export-tier="minimal"] #map-layers-drawer,
    body[data-export-tier="minimal"] .map-sub-bar,
    body[data-export-tier="minimal"] #settings-export-group {{
      display: none !important;
    }}
    html[data-theme="light"] body[data-export-tier="minimal"] {{
      background: #ffffff;
    }}
    body[data-export-tier="minimal"].iframe-embedded,
    html[data-theme="light"] body[data-export-tier="minimal"].iframe-embedded {{
      background: transparent;
    }}
    body[data-export-tier="minimal"] header {{
      background: transparent;
      border-bottom: none;
      padding: 6px 14px;
      gap: 8px;
    }}
    body[data-export-tier="minimal"] .slicer-bar {{
      background: transparent;
      border-bottom: none;
      padding: 4px 14px;
    }}
    body[data-export-tier="minimal"] .workspace,
    body[data-export-tier="minimal"] .workspace.freeform {{
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }}
    body[data-export-tier="minimal"] .map-card,
    body[data-export-tier="minimal"] .widget-card,
    body[data-export-tier="minimal"] .kpi-card,
    body[data-export-tier="minimal"] .workspace.freeform .slicer-group.freeform-card {{
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
      border-radius: 0 !important;
    }}
    body[data-export-tier="minimal"] .card-header {{
      background: transparent;
      border-bottom: none;
      padding: 6px 4px 4px 4px;
    }}
    body[data-export-tier="minimal"] #map-canvas {{
      border-radius: 6px;
      overflow: hidden;
    }}
    body[data-export-tier="minimal"] .table-wrapper {{
      border-radius: 4px;
    }}
    /* Conclusive Async Progress Overlay (#9) */
    .dash-loading-overlay {{
      position: fixed;
      inset: 0;
      z-index: 4200;
      background: rgba(15, 23, 42, 0.62);
      backdrop-filter: blur(2px);
      display: none;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }}
    html[data-theme="light"] .dash-loading-overlay {{
      background: rgba(241, 245, 249, 0.72);
    }}
    .dash-loading-card {{
      width: min(390px, 92vw);
      background: var(--bg-secondary);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 16px 18px;
      box-shadow: 0 16px 40px rgba(2, 6, 23, 0.45);
      display: flex;
      flex-direction: column;
      gap: 9px;
    }}
    .dash-loading-hdr {{
      display: flex;
      align-items: center;
      gap: 10px;
      font-weight: 700;
      font-size: 0.92rem;
    }}
    .dash-loading-spin {{
      width: 16px;
      height: 16px;
      border-radius: 50%;
      border: 2.5px solid rgba(56, 189, 248, 0.25);
      border-top-color: var(--accent);
      animation: qdashSpin 0.8s linear infinite;
      flex-shrink: 0;
    }}
    @keyframes qdashSpin {{
      to {{ transform: rotate(360deg); }}
    }}
    .dash-loading-detail {{
      font-size: 0.77rem;
      color: var(--text-secondary);
      min-height: 16px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}
    .dash-loader-track {{
      width: 100%;
      height: 7px;
      border-radius: 999px;
      background: rgba(148, 163, 184, 0.24);
      overflow: hidden;
    }}
    .dash-loader-bar {{
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, var(--accent), #34d399);
      transition: width 0.14s ease-out;
    }}
    .dash-loader-pct {{
      font-size: 0.72rem;
      color: var(--text-secondary);
      text-align: right;
      font-variant-numeric: tabular-nums;
    }}
  /*]]>*/</style>
</head>
<body data-export-tier="{export_tier}">
  <div id="dash-loading-overlay" class="dash-loading-overlay" style="display:none;" aria-live="polite">
    <div class="dash-loading-card">
      <div class="dash-loading-hdr">
        <span class="dash-loading-spin"></span>
        <span id="dash-loader-title">{tr("loader_stage_unpack", lang)}</span>
      </div>
      <div id="dash-loader-detail" class="dash-loading-detail"></div>
      <div class="dash-loader-track"><div id="dash-loader-bar" class="dash-loader-bar"></div></div>
      <div id="dash-loader-pct" class="dash-loader-pct">0%</div>
    </div>
  </div>
  <header>
    <div>
      <div class="brand-title">
        <span id="brand-title-text">{init_title_esc}</span>
        <span id="live-status" class="status-pill status-pill-checking" onclick="toggleLiveStatusMenu(event)" title="{_html_lib.escape(tr('status_cached_desc', lang) + ' | ' + tr('status_live_desc', lang), quote=True)}">{tr("html_live_ready", lang)}</span>
        <button type="button" id="btn-refresh-live" class="btn-mini-icon" onclick="onRefreshLiveButtonClick(event)" title="{tr("html_refresh_live_tip", lang)}" style="display:none;">{tr("html_refresh_live_btn", lang)}</button>
        <span id="html-refresh-bar" class="html-refresh-bar" style="display:none;"><span id="html-refresh-text">0%</span><span class="html-refresh-track"><span id="html-refresh-fill" class="html-refresh-fill"></span></span></span>
        <span id="html-busy-pill" class="html-busy-pill" style="display:none;"><span class="busy-spin"></span><span id="html-busy-text">{tr("html_loading_msg", lang)}</span></span>
      </div>
      <div id="brand-subtitle-text" class="brand-subtitle">{init_subtitle_esc}</div>
    </div>
    <div class="toolbar-actions">
      <button type="button" id="btn-reset-filters" onclick="clearAllFilters()">{tr("html_reset_filters", lang)}</button>
      <button type="button" id="btn-mobile-view" onclick="toggleMobileView()">{tr("mobile_view_btn", lang)}</button>
      <button type="button" id="btn-settings-menu" onclick="toggleSettingsMenu(event)">{tr("settings_menu_btn", lang)}</button>
    </div>
  </header>
  <div id="settings-popover" class="settings-popover" style="display:none;">
    <div id="settings-export-group" class="settings-sec">
      <div class="settings-sec-hdr"><span id="lbl-settings-export">{tr("settings_export_sec", lang)}</span></div>
      <div class="settings-scope-row">
        <button type="button" id="btn-scope-dash" class="settings-scope-btn active" onclick="setExportImageScope('dashboard')">{tr("export_scope_dash", lang)}</button>
        <button type="button" id="btn-scope-map" class="settings-scope-btn" onclick="setExportImageScope('map')">{tr("export_scope_map", lang)}</button>
      </div>
      <div class="settings-export-list">
        <button type="button" id="btn-download-gpkg" class="settings-menu-btn" onclick="closeSettingsMenu(); downloadMapViewportGeoPackage();">{tr("btn_download_gpkg", lang)}</button>
        <button type="button" id="btn-export-png" class="settings-menu-btn" onclick="closeSettingsMenu(); exportDashboardImage('png');">{tr("btn_export_png", lang)}</button>
        <button type="button" id="btn-export-jpg" class="settings-menu-btn" onclick="closeSettingsMenu(); exportDashboardImage('jpeg');">{tr("btn_export_jpg", lang)}</button>
      </div>
    </div>
    <div class="settings-sec">
      <div class="settings-sec-hdr"><span id="lbl-settings-behavior">{tr("settings_behavior_sec", lang)}</span></div>
      <div id="opt-row-extent">
        <button type="button" id="btn-extent-filter" class="settings-menu-btn" onclick="toggleExtentFilter()">{tr("html_extent_off", lang)}</button>
      </div>
      <label class="settings-check-row" for="chk-opt-autohome">
        <input type="checkbox" id="chk-opt-autohome" checked="checked" onchange="toggleAutoHomeOnClear(this.checked)" />
        <span id="lbl-opt-autohome">{tr("opt_auto_home_clear", lang)}</span>
      </label>
      <div style="display:flex;flex-direction:column;gap:4px;padding:3px 2px;">
        <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.78rem;">
          <span id="lbl-map-scroll-smoothness">{tr("lbl_map_scroll_smoothness", lang)}</span>
          <span id="val-map-scroll-smoothness" class="style-val-chip">35%</span>
        </div>
        <input type="range" id="rng-map-scroll-smoothness" min="1" max="100" value="35" oninput="setMapScrollSensitivity(this.value)" style="width:100%;padding:0;" />
      </div>
      <button type="button" id="btn-reset-dashboard" class="settings-menu-btn" onclick="closeSettingsMenu(); resetDashboardToHome();">{tr("html_reset_dashboard", lang)}</button>
    </div>
    <div class="settings-sec">
      <div class="settings-sec-hdr"><span id="lbl-settings-display">{tr("settings_display_sec", lang)}</span></div>
      <button type="button" id="btn-theme-toggle" class="settings-menu-btn" onclick="toggleTheme()">{tr("html_toggle_theme", lang)}</button>
      <button type="button" id="btn-lang" class="settings-menu-btn" onclick="toggleLanguage()">{tr("lang_toggle", lang)}</button>
      <button type="button" id="btn-dev-log" class="settings-menu-btn" onclick="closeSettingsMenu(); toggleDevLogDrawer();">{tr("dev_log_btn", lang)}</button>
    </div>
  </div>
  <div id="live-status-menu" class="live-status-menu" style="display:none;"></div>
  <div id="refresh-scope-menu" class="refresh-scope-menu" style="display:none;"></div>
  <div id="dev-log-drawer" class="dev-log-drawer" style="display:none;">
    <div class="dev-log-hdr">
      <span id="dev-log-title">{tr("dev_log_title", lang)}</span>
      <span style="display:flex;gap:5px;align-items:center;">
        <button type="button" id="btn-dev-cancel-wfs" class="btn-mini-icon" onclick="cancelActiveWfsRefresh()" style="display:none;background:#be123c;color:#fff;border-color:#fb7185;">{tr("dev_log_cancel_refresh", lang)}</button>
        <button type="button" id="btn-dev-copy" class="btn-mini-icon" onclick="copyDevLog()">{tr("dev_log_copy", lang)}</button>
        <button type="button" id="btn-dev-clear" class="btn-mini-icon" onclick="clearDevLog()">{tr("dev_log_clear", lang)}</button>
        <button type="button" class="btn-mini-icon" onclick="toggleDevLogDrawer(false)">✕</button>
      </span>
    </div>
    <div id="dev-log-body" class="dev-log-body"></div>
  </div>
  <div id="map-layers-drawer" class="map-layers-drawer" style="display:none;"></div>

  <nav id="dashboard-pages-bar" class="dashboard-pages-bar"></nav>
  <section id="active-filters-bar" class="active-filters-bar"></section>
  <div id="mobile-nav-bar" class="mobile-nav-bar">
    <button type="button" id="btn-mobile-prev" class="btn-mini-icon mobile-nav-arrow" onclick="stepMobileWidget(-1)">◀</button>
    <div id="mobile-nav-pills" class="mobile-nav-pills"></div>
    <button type="button" id="btn-mobile-next" class="btn-mini-icon mobile-nav-arrow" onclick="stepMobileWidget(1)">▶</button>
    <button type="button" id="btn-mobile-map-lock" class="btn-mini-icon" onclick="toggleMobileMapTouchLock()" title="{tr("mobile_map_lock_tip", lang)}">{tr("mobile_map_unlock", lang)}</button>
    <button type="button" id="btn-mobile-fit" class="btn-mini-icon" onclick="toggleMobileFitOverview()">{tr("mobile_fit_btn", lang)}</button>
  </div>

  <section id="slicer-bar" class="slicer-bar"></section>

  <div class="workspace-scroll">
  <main id="workspace-main" class="workspace">
    <div id="map-card" class="map-card">
      <div class="card-header map-title-row">
        <span id="map-header-title" class="map-title-text" title="{init_title_esc}">{tr("html_map_header", lang)}</span>
        <div class="map-hdr-actions">
          <button type="button" id="btn-reset-home" class="btn-mini-icon" onclick="resetMapHomeView()" title="{tr("html_reset_home", lang)}">{tr("html_reset_home", lang)}</button>
          <button type="button" id="btn-map-layers" class="btn-mini-icon" onclick="toggleMapLayersPanel()">{tr("html_map_layers_btn", lang)}</button>
          <button type="button" id="btn-map-minimize" class="btn-mini-icon" onclick="toggleMapMinimize()" title="{tr("map_minimize_tip", lang)}">—</button>
          <button type="button" id="btn-map-maximize" class="btn-mini-icon" onclick="toggleMapMaximize()" title="{tr("map_maximize_tip", lang)}">⛶</button>
        </div>
      </div>
      <div class="map-sub-bar">
        <div class="map-telemetry-group">
          <button type="button" id="map-scale-badge" class="map-scale-btn" onclick="toggleMapScaleMenu(event)">1:500 000 ▾</button>
          <span id="feature-count-badge" class="map-count-pill">0</span>
        </div>
        <button type="button" id="btn-map-catalog" class="btn-mini-icon btn-catalog-toggle" onclick="toggleMapCatalogPanel()">{tr("html_catalog_btn", lang)}</button>
      </div>
      <div class="map-addr-bar">
        <input id="map-addr-input" type="search" placeholder="{tr("addr_search_ph", lang)}" oninput="scheduleAddressSearchHtml()" onkeydown="if(event.key==='Enter'){{event.preventDefault();searchEstonianAddressHtml(false);}}" />
        <button id="btn-addr-search" class="btn-mini-icon" onclick="searchEstonianAddressHtml(false)">{tr("addr_search_btn", lang)}</button>
        <button id="btn-addr-clear" class="btn-mini-icon" onclick="clearAddressSearchResult()" title="{tr("addr_clear", lang)}">✕</button>
        <div id="map-addr-results" class="map-addr-results"></div>
      </div>
      <div id="map-filter-strip" class="card-filter-strip" style="display:none;"><span id="map-filter-badge" class="widget-filter-badge"></span></div>
      <div id="map-catalog-drawer" class="map-catalog-drawer" style="display:none;"></div>
      <div id="map-canvas"></div>
      <div id="map-render-loader" class="map-render-loader" aria-live="polite">
        <div class="map-render-card">
          <span class="map-render-spinner"></span>
          <span id="map-render-loader-text">{tr("map_rendering_layers", lang)}</span>
        </div>
      </div>
    </div>

    <div id="widgets-panel" class="widgets-panel">
      <div id="kpi-grid" class="kpi-grid"></div>
      <div id="charts-grid" class="charts-grid"></div>
    </div>
  </main>
  </div>
  <div id="mobile-scroll-rail" class="mobile-scroll-rail" aria-hidden="true"><div id="mobile-scroll-blob" class="mobile-scroll-blob"></div></div>

  <script>//<![CDATA[
    const BUNDLE = {bundle_json};
    if (window.__QDASH_SIDECAR__) {{
      const sc = window.__QDASH_SIDECAR__;
      if (sc.initial_layer_records) BUNDLE.initial_layer_records = sc.initial_layer_records;
      if (sc.initial_geojson) BUNDLE.initial_geojson = sc.initial_geojson;
      if (sc.vector_pyramids) BUNDLE.vector_pyramids = sc.vector_pyramids;
      if (sc.spatial_relations) BUNDLE.spatial_relations = sc.spatial_relations;
      if (sc.excel_tables) BUNDLE.excel_tables = sc.excel_tables;
      if (sc.packaged_basemap) BUNDLE.packaged_basemap = sc.packaged_basemap;
    }}
    const DASHBOARD = BUNDLE.dashboard;
    const I18N = BUNDLE.i18n || {{}};
    const LAYER_RECORDS = {{}};
    const LAYER_GEOMETRIES = {{}};
    const LAYER_GEOM_BBOXES = {{}};
    const LAYER_GEOM_TYPES = {{}};
    const LAYER_GEOM_LOD = {{}};
    const LAYER_STATS = BUNDLE.layer_stats || {{}};
    const VECTOR_PYRAMIDS = BUNDLE.vector_pyramids || {{}};
    const SPATIAL_RELATIONS = new Map();
    const LAYER_COMPLETENESS = {{}};
    const LAYER_PYRAMID_LOD1 = {{}};
    const LOD1_UNPACKING = {{}};
    const FEATURE_FETCH_INFLIGHT = {{}};
    const FETCH_ABORT_CONTROLLERS = {{}};
    const LAYER_LAST_MISSING_KEY = {{}};
    const LAYER_FETCH_COOLDOWN = {{}};
    const HAS_PREVIEW_API = Boolean(BUNDLE.has_preview_api);
    let VIEWPORT_REFRESH_TIMER = null;
    let EXTENT_REFRESH_TIMER = null;
    let MAP_RENDER_SHOW_TIMER = null;
    let IS_MAP_INTERACTING = false;
    let LAST_RENDER_VIEWPORT = null;
    const VIEWPORT_REFRESH_DEBOUNCE_MS = 1150;
    const EXTENT_REFRESH_DEBOUNCE_MS = 1050;
    const MAP_RENDER_LOADER_DELAY_MS = 520;
    let IS_PROGRAMMATIC_MOVE = false;
    let HOME_MAP_VIEW = null;
    let LEGEND_COLLAPSED = false;
    let LAYER_CONTROL_COLLAPSED = true;  // Layer list-menu starts minimized (#6)
    let ACTIVE_STYLE_LAYER = '';
    let ACTIVE_LAYER_STYLE_TAB = 'style';  // 'style' | 'labels'
    let DRAG_LAYER_NAME = '';
    const _PAGES_LIST = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
    const _FIRST_PAGE_ID = (_PAGES_LIST[0] && _PAGES_LIST[0].id) || 'page_1';
    const DEFAULT_PAGE_ID = (DASHBOARD.default_page_id && _PAGES_LIST.some(p => p.id === DASHBOARD.default_page_id))
      ? DASHBOARD.default_page_id
      : _FIRST_PAGE_ID;
    let _URL_PAGE_ID = '';
    try {{
      const _sp = (typeof window !== 'undefined' && window.location && typeof URLSearchParams !== 'undefined')
        ? new URLSearchParams(window.location.search || '')
        : null;
      const _qp = _sp ? String(_sp.get('page') || '').trim() : '';
      if (_qp && _PAGES_LIST.some(p => p.id === _qp)) _URL_PAGE_ID = _qp;
    }} catch (_qpErr) {{}}
    let MAP_SCROLL_SENSITIVITY = Math.max(1, Math.min(100, Number(DASHBOARD.map_scroll_sensitivity || 35)));
    let ACTIVE_PAGE_ID = _URL_PAGE_ID || DEFAULT_PAGE_ID;
    const MAP_WIDGET_STATES = {{}};
    let ACTIVE_MAP_STATE_KEY = '';
    const EXTRA_LABEL_SLOTS = {{}};

    function getActiveMapWidget() {{
      const maps = (DASHBOARD.widgets || []).filter(w => w && w.widget_type === 'map');
      if (!maps.length) return null;
      const pgMatch = maps.find(w => !w.page_id || String(w.page_id) === String(ACTIVE_PAGE_ID || _FIRST_PAGE_ID));
      if (pgMatch) return pgMatch;
      const hasAnyPaged = maps.some(w => Boolean(w.page_id));
      return hasAnyPaged ? null : maps[0];
    }}

    function _mapWidgetStateKey(mw) {{
      return (mw && mw.id) ? String(mw.id) : '__default_map__';
    }}

    function _allConfiguredLayerNames() {{
      const set = new Set([
        ...Object.keys(LAYER_RECORDS),
        ...Object.keys(BUNDLE.initial_layer_records || {{}}),
        ...Object.keys(BUNDLE.initial_geojson || {{}}),
        ...Object.keys(VECTOR_PYRAMIDS || {{}}),
        ...(BUNDLE.ogc_services || []).filter(s => s && s.type === 'wfs' && s.name).map(s => s.name)
      ]);
      (DASHBOARD.widgets || []).forEach(w => {{
        if (w && w.widget_type === 'map') {{
          if (w.layer_name && w.layer_name !== '*') set.add(w.layer_name);
          (Array.isArray(w.map_layers) ? w.map_layers : []).forEach(ln => {{
            if (ln && ln !== '*') set.add(ln);
          }});
        }}
      }});
      return Array.from(set);
    }}

    function _computeInitialVisibilityForWidget(mw, layerNames) {{
      const explicitList = (mw && Array.isArray(mw.map_layers) && mw.map_layers.length > 0)
        ? new Set(mw.map_layers)
        : ((mw && mw.layer_name && mw.layer_name !== '*') ? new Set([mw.layer_name]) : null);
      const styles = (mw && mw.map_layer_styles) || {{}};
      const vis = {{}};
      (layerNames || []).forEach(ln => {{
        const st = styles[ln];
        if (st && st.visible === false) vis[ln] = false;
        else if (st && st.visible === true) vis[ln] = true;
        else if (explicitList !== null) vis[ln] = explicitList.has(ln);
        else vis[ln] = true;
      }});
      return vis;
    }}

    function _buildInitialHomeViewForWidget(mw) {{
      const hasOwnBounds = mw && Array.isArray(mw.map_home_bounds) && mw.map_home_bounds.length === 4;
      const hasOwnCenter = mw && mw.map_center_lat !== null && mw.map_center_lat !== undefined && mw.map_center_lon !== null && mw.map_center_lon !== undefined;
      const rawHomeBounds = hasOwnBounds
        ? mw.map_home_bounds
        : ((!mw || !mw.page_id || String(mw.page_id) === String(_FIRST_PAGE_ID)) && Array.isArray(DASHBOARD.map_home_bounds) && DASHBOARD.map_home_bounds.length === 4
            ? DASHBOARD.map_home_bounds
            : null);
      const lat = Number((hasOwnCenter ? mw.map_center_lat : null) || DASHBOARD.map_center_lat || 58.758);
      const lon = Number((hasOwnCenter ? mw.map_center_lon : null) || DASHBOARD.map_center_lon || 23.825);
      const rawZoom = (mw && mw.map_zoom !== undefined && mw.map_zoom !== null) ? mw.map_zoom : DASHBOARD.map_zoom;
      const zoom = (rawZoom !== undefined && rawZoom !== null) ? Math.min(14, Number(rawZoom)) : 7;
      return {{
        lat,
        lon,
        zoom,
        bounds: rawHomeBounds ? rawHomeBounds.map(Number) : null,
        hasExplicitView: Boolean(hasOwnBounds || hasOwnCenter || (rawHomeBounds && rawHomeBounds.length === 4))
      }};
    }}

    function _getOrInitMapWidgetState(mw) {{
      const key = _mapWidgetStateKey(mw);
      if (!MAP_WIDGET_STATES[key]) {{
        const allL = _allConfiguredLayerNames();
        const vis = _computeInitialVisibilityForWidget(mw, allL);
        const initOrd = (mw && Array.isArray(mw.map_layers) && mw.map_layers.length)
          ? mw.map_layers.slice()
          : ((mw && mw.layer_name && mw.layer_name !== '*') ? [mw.layer_name] : null);
        let bmId = (mw && mw.map_basemap) || 'MA-HALLKAART';
        if (bmId === 'MA-FOTOKAART') bmId = 'EESTIFOTO';
        if (bmId === 'cir_ngr') bmId = 'MA-HALLKAART';
        const hv = _buildInitialHomeViewForWidget(mw);
        MAP_WIDGET_STATES[key] = {{
          key,
          mapWidget: mw || null,
          visibility: vis,
          customOrder: initOrd ? initOrd.slice() : null,
          initialOrder: initOrd ? initOrd.slice() : null,
          localStyles: {{}},
          homeView: hv,
          basemapId: bmId,
          legendCollapsed: Boolean(mw && mw.map_legend_collapsed),
          scrollSens: Math.max(1, Math.min(100, Number((mw && mw.map_scroll_sensitivity) || DASHBOARD.map_scroll_sensitivity || 35))),
          lastView: null,
          hasExplicitView: hv.hasExplicitView
        }};
      }}
      return MAP_WIDGET_STATES[key];
    }}

    function _saveActiveMapWidgetState() {{
      if (!ACTIVE_MAP_STATE_KEY || !MAP_WIDGET_STATES[ACTIVE_MAP_STATE_KEY]) return;
      const st = MAP_WIDGET_STATES[ACTIVE_MAP_STATE_KEY];
      st.visibility = Object.assign({{}}, MAP_LAYER_VISIBILITY);
      st.customOrder = Array.isArray(CUSTOM_MAP_LAYERS) ? CUSTOM_MAP_LAYERS.slice() : null;
      st.localStyles = JSON.parse(JSON.stringify(LOCAL_LAYER_STYLES || {{}}));
      st.legendCollapsed = Boolean(LEGEND_COLLAPSED);
      st.scrollSens = MAP_SCROLL_SENSITIVITY;
      if (map && typeof map.getCenter === 'function' && typeof map.getZoom === 'function') {{
        const c = map.getCenter();
        if (c && Number.isFinite(Number(c.lat)) && Number.isFinite(Number(c.lng))) {{
          st.lastView = {{ lat: Number(c.lat), lng: Number(c.lng), zoom: Number(map.getZoom()) }};
        }}
      }}
    }}

    function applyMapScrollSensitivity(val) {{
      const sens = Math.max(1, Math.min(100, Number(val || 35)));
      MAP_SCROLL_SENSITIVITY = sens;
      const pxPerZoom = Math.round(480 - (sens / 100) * 400);
      const zDelta = sens <= 40 ? 0.25 : (sens <= 75 ? 0.5 : 1);
      const decel = Math.round(1800 + (sens / 100) * 2400);
      if (map && map.options) {{
        map.options.wheelPxPerZoomLevel = pxPerZoom;
        map.options.zoomDelta = zDelta;
        map.options.wheelDebounceTime = 60;
        map.options.inertia = true;
        map.options.inertiaDeceleration = decel;
      }}
      const rng = (typeof document !== 'undefined' && document.getElementById) ? document.getElementById('rng-map-scroll-smoothness') : null;
      if (rng) rng.value = String(sens);
      const valEl = (typeof document !== 'undefined' && document.getElementById) ? document.getElementById('val-map-scroll-smoothness') : null;
      if (valEl) valEl.textContent = `${{sens}}%`;
    }}

    function setMapScrollSensitivity(val) {{
      applyMapScrollSensitivity(val);
      if (ACTIVE_MAP_STATE_KEY && MAP_WIDGET_STATES[ACTIVE_MAP_STATE_KEY]) {{
        MAP_WIDGET_STATES[ACTIVE_MAP_STATE_KEY].scrollSens = MAP_SCROLL_SENSITIVITY;
      }}
      saveDashboardSessionState();
    }}

    function _activateMapWidgetState(mw) {{
      const st = _getOrInitMapWidgetState(mw);
      ACTIVE_MAP_STATE_KEY = st.key;
      Object.keys(MAP_LAYER_VISIBILITY).forEach(k => delete MAP_LAYER_VISIBILITY[k]);
      const allL = _allConfiguredLayerNames();
      allL.forEach(ln => {{
        if (st.visibility[ln] !== undefined) MAP_LAYER_VISIBILITY[ln] = Boolean(st.visibility[ln]);
        else {{
          const mwLayers = (mw && Array.isArray(mw.map_layers) && mw.map_layers.length) ? mw.map_layers : null;
          MAP_LAYER_VISIBILITY[ln] = mwLayers ? mwLayers.includes(ln) : true;
        }}
      }});
      CUSTOM_MAP_LAYERS = Array.isArray(st.customOrder) ? st.customOrder.slice() : null;
      INITIAL_LAYER_ORDER = Array.isArray(st.initialOrder) ? st.initialOrder.slice() : null;
      Object.keys(LOCAL_LAYER_STYLES).forEach(k => delete LOCAL_LAYER_STYLES[k]);
      Object.assign(LOCAL_LAYER_STYLES, JSON.parse(JSON.stringify(st.localStyles || {{}})));
      if (st.homeView) HOME_MAP_VIEW = Object.assign({{}}, st.homeView);
      LEGEND_COLLAPSED = Boolean(st.legendCollapsed);
      applyMapScrollSensitivity(st.scrollSens);
      const activeNames = orderedMapLayerNames();
      if (ACTIVE_STYLE_LAYER && !activeNames.includes(ACTIVE_STYLE_LAYER)) {{
        ACTIVE_STYLE_LAYER = '';
      }}
      return st;
    }}
    const EXPORT_TIER = String((DASHBOARD && DASHBOARD.export_tier) || 'full').trim().toLowerCase();
    let AUTO_HOME_ON_FILTER_CLEAR = (DASHBOARD && DASHBOARD.auto_home_on_filter_clear !== false);
    let MAP_WINDOW_MODE = 'normal';  // 'normal' | 'minimized' | 'maximized'
    let EXPORT_IMAGE_SCOPE = 'dashboard';  // 'dashboard' | 'map'
    let _FILTER_RENDER_SEQ = 0;
    let _PREV_ACTIVE_FILTER_COUNT = 0;
    let ACTIVE_RENDERED_LABELS = [];
    const LAYER_RENDERED_FEATURES = {{}};
    function isEmbeddedIframe() {{
      try {{
        return (typeof window !== 'undefined') && (
          window.self !== window.top || Boolean(window.frameElement)
        );
      }} catch (_e) {{
        return true;
      }}
    }}
    const IS_EMBEDDED_IFRAME = isEmbeddedIframe();

    function detectMobileDeviceViewport() {{
      if (typeof window === 'undefined') return false;
      const w = Number(window.innerWidth || 0);
      const h = Number(window.innerHeight || 0);
      const isCoarse = (typeof window.matchMedia === 'function')
        ? Boolean(window.matchMedia('(pointer: coarse)').matches)
        : false;
      const narrowCutoff = (IS_EMBEDDED_IFRAME && !isCoarse) ? 540 : 860;
      if (w > 0 && w <= narrowCutoff) return true;
      if (isCoarse && ((w > 0 && w <= 1024) || (h > 0 && Math.min(w || 9999, h) <= 560))) return true;
      if (w > 0 && h > 0 && w <= 1024 && h <= 540) return true;
      return false;
    }}
    let MOBILE_VIEW_OVERRIDE = null;
    let MOBILE_VIEW_ENABLED = detectMobileDeviceViewport();
    let MOBILE_FIT_OVERVIEW = false;
    let MOBILE_MAP_LOCKED = false;
    let MOBILE_FOCUS_IDX = 0;
    let ADDRESS_RESULT_LAYER = null;
    let LAST_ADDRESS_RESULTS = [];
    let ACTIVE_BUSY_OPS = 0;
    let LAST_INTERACTED_FILTER_SOURCE = null;

    function _yieldToBrowser() {{
      return new Promise(resolve => {{
        if (typeof requestAnimationFrame === 'function') {{
          requestAnimationFrame(() => setTimeout(resolve, 0));
        }} else {{
          setTimeout(resolve, 0);
        }}
      }});
    }}

    function showDashboardLoader(title, detail, pct) {{
      if (typeof document === 'undefined') return;
      const ov = document.getElementById('dash-loading-overlay');
      const tEl = document.getElementById('dash-loader-title');
      const dEl = document.getElementById('dash-loader-detail');
      const bEl = document.getElementById('dash-loader-bar');
      const pEl = document.getElementById('dash-loader-pct');
      const clamped = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
      if (tEl && title !== undefined) tEl.textContent = String(title || '');
      if (dEl && detail !== undefined) dEl.textContent = String(detail || '');
      if (bEl && bEl.style) bEl.style.width = `${{clamped}}%`;
      if (pEl) pEl.textContent = `${{clamped}}%`;
      if (ov && ov.style) ov.style.display = 'flex';
    }}

    function hideDashboardLoader() {{
      if (typeof document === 'undefined') return;
      const ov = document.getElementById('dash-loading-overlay');
      if (ov && ov.style) ov.style.display = 'none';
    }}

    async function _b64ToUint8ArrayAsync(b64) {{
      const s = String(b64 || '');
      const CHUNK_CHARS = 262144; // multiple of 4
      if (s.length <= CHUNK_CHARS * 2) {{
        const bin = atob(s);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return bytes;
      }}
      const parts = [];
      let totalBytes = 0;
      let lastYield = Date.now();
      for (let off = 0; off < s.length; off += CHUNK_CHARS) {{
        const bin = atob(s.slice(off, off + CHUNK_CHARS));
        const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        parts.push(arr);
        totalBytes += arr.length;
        if ((Date.now() - lastYield) >= 22) {{
          await _yieldToBrowser();
          lastYield = Date.now();
        }}
      }}
      const out = new Uint8Array(totalBytes);
      let pos = 0;
      for (let pi = 0; pi < parts.length; pi++) {{
        out.set(parts[pi], pos);
        pos += parts[pi].length;
      }}
      return out;
    }}

    function _expandColumnarRecords(parsed) {{
      const cols = (parsed && parsed.cols) || [];
      const rws = (parsed && parsed.rows) || [];
      const recs = new Array(rws.length);
      for (let ri = 0; ri < rws.length; ri++) {{
        const arr = rws[ri];
        const obj = {{}};
        for (let ci = 0; ci < cols.length; ci++) {{
          obj[cols[ci]] = arr[ci];
        }}
        recs[ri] = obj;
      }}
      return recs;
    }}

    async function _expandColumnarRecordsAsync(parsed, onPct) {{
      const cols = (parsed && parsed.cols) || [];
      const rws = (parsed && parsed.rows) || [];
      const n = rws.length;
      if (n <= 3000) return _expandColumnarRecords(parsed);
      const recs = new Array(n);
      let lastYield = Date.now();
      for (let ri = 0; ri < n; ri++) {{
        const arr = rws[ri];
        const obj = {{}};
        for (let ci = 0; ci < cols.length; ci++) {{
          obj[cols[ci]] = arr[ci];
        }}
        recs[ri] = obj;
        if ((ri & 511) === 0 && (Date.now() - lastYield) >= 22) {{
          if (typeof onPct === 'function') onPct(ri / n);
          await _yieldToBrowser();
          lastYield = Date.now();
        }}
      }}
      if (typeof onPct === 'function') onPct(1);
      return recs;
    }}

    function hydrateInitialLayerRecordsSync() {{
      const rawMap = BUNDLE.initial_layer_records || {{}};
      for (const [ln, val] of Object.entries(rawMap)) {{
        if (Array.isArray(val)) {{
          LAYER_RECORDS[ln] = val.slice();
        }} else if (val && typeof val === 'object' && val.__format__ === 'qdash_cols') {{
          const recs = _expandColumnarRecords(val);
          LAYER_RECORDS[ln] = recs;
          rawMap[ln] = recs;
        }} else if (val && typeof val === 'object' && val.__format__ === 'qdash_cols_gzip_b64' && val.data) {{
          if (typeof require === 'function' && typeof Buffer !== 'undefined') {{
            try {{
              const zlib = require('zlib');
              const txt = zlib.gunzipSync(Buffer.from(val.data, 'base64')).toString('utf-8');
              const recs = _expandColumnarRecords(JSON.parse(txt));
              LAYER_RECORDS[ln] = recs;
              rawMap[ln] = recs;
            }} catch (_zErr) {{}}
          }}
        }}
      }}
      const exMap = BUNDLE.excel_tables || {{}};
      for (const ds of (DASHBOARD.data_sources || [])) {{
        if (ds && ds.name && !LAYER_RECORDS[ds.name] && ds.id && Array.isArray(exMap[ds.id])) {{
          LAYER_RECORDS[ds.name] = exMap[ds.id].slice();
        }}
      }}
    }}
    hydrateInitialLayerRecordsSync();

    async function unpackCompressedLayerRecords(onProgress) {{
      const rawMap = BUNDLE.initial_layer_records || {{}};
      const entries = Object.entries(rawMap);
      const totalEnt = Math.max(1, entries.length);
      for (let ei = 0; ei < entries.length; ei++) {{
        const [ln, val] = entries[ei];
        if (typeof onProgress === 'function') onProgress(ln, ei / totalEnt);
        if (Array.isArray(val)) {{
          LAYER_RECORDS[ln] = val.slice();
        }} else if (val && typeof val === 'object' && val.__format__ === 'qdash_cols') {{
          const recs = await _expandColumnarRecordsAsync(val, frac => {{
            if (typeof onProgress === 'function') onProgress(ln, (ei + frac) / totalEnt);
          }});
          LAYER_RECORDS[ln] = recs;
          rawMap[ln] = recs;
        }} else if (val && typeof val === 'object' && val.__format__ === 'qdash_cols_gzip_b64' && val.data) {{
          try {{
            let parsed = null;
            if (typeof DecompressionStream !== 'undefined') {{
              const bytes = await _b64ToUint8ArrayAsync(val.data);
              const ds = new DecompressionStream('gzip');
              const stream = new Blob([bytes]).stream().pipeThrough(ds);
              const txt = await new Response(stream).text();
              parsed = JSON.parse(txt);
            }} else if (typeof require === 'function' && typeof Buffer !== 'undefined') {{
              const zlib = require('zlib');
              const txt = zlib.gunzipSync(Buffer.from(val.data, 'base64')).toString('utf-8');
              parsed = JSON.parse(txt);
            }}
            const recs = parsed ? await _expandColumnarRecordsAsync(parsed, frac => {{
              if (typeof onProgress === 'function') onProgress(ln, (ei + frac) / totalEnt);
            }}) : [];
            LAYER_RECORDS[ln] = recs;
            rawMap[ln] = recs;
          }} catch (err) {{
            console.warn('Failed to decompress columnar records for', ln, err);
            LAYER_RECORDS[ln] = LAYER_RECORDS[ln] || [];
          }}
        }}
      }}
      const exMap = BUNDLE.excel_tables || {{}};
      for (const ds of (DASHBOARD.data_sources || [])) {{
        if (ds && ds.name && !LAYER_RECORDS[ds.name] && ds.id && Array.isArray(exMap[ds.id])) {{
          LAYER_RECORDS[ds.name] = exMap[ds.id].slice();
        }}
      }}
    }}

    function beginBusyOp(label) {{
      ACTIVE_BUSY_OPS += 1;
      const pill = document.getElementById('html-busy-pill');
      const txt = document.getElementById('html-busy-text');
      if (txt) txt.textContent = label || (typeof t === 'function' ? t('html_loading_msg') : 'Updating...');
      if (pill) pill.style.display = 'inline-flex';
    }}

    function endBusyOp() {{
      ACTIVE_BUSY_OPS = Math.max(0, ACTIVE_BUSY_OPS - 1);
      if (ACTIVE_BUSY_OPS === 0) {{
        const pill = document.getElementById('html-busy-pill');
        if (pill) pill.style.display = 'none';
      }}
    }}

    let MAP_RENDER_OPS = 0;
    let MAP_RENDER_IS_ACTIVE = false;
    let MAP_RENDER_HIDE_TIMER = null;
    let MAP_RENDER_SAFETY_TIMER = null;
    const MAP_TILE_SOURCE_STATE = {{}};

    function _syncMapRenderLoaderDOM() {{
      MAP_RENDER_IS_ACTIVE = MAP_RENDER_OPS > 0;
      const el = document.getElementById('map-render-loader');
      if (!el) return;
      if (MAP_RENDER_IS_ACTIVE) {{
        el.classList.add('active');
      }} else {{
        el.classList.remove('active');
      }}
    }}

    function beginMapRenderLoader(label) {{
      if (MAP_RENDER_HIDE_TIMER) {{
        clearTimeout(MAP_RENDER_HIDE_TIMER);
        MAP_RENDER_HIDE_TIMER = null;
      }}
      MAP_RENDER_OPS += 1;
      const txt = document.getElementById('map-render-loader-text');
      if (txt) txt.textContent = label || (typeof t === 'function' ? t('map_rendering_layers') : 'Rendering map layers...');
      const opts = arguments.length > 1 ? (arguments[1] || {{}}) : {{}};
      const alreadyActive = MAP_RENDER_IS_ACTIVE;
      if (opts.immediateShow || alreadyActive) {{
        if (MAP_RENDER_SHOW_TIMER) {{
          clearTimeout(MAP_RENDER_SHOW_TIMER);
          MAP_RENDER_SHOW_TIMER = null;
        }}
        _syncMapRenderLoaderDOM();
      }} else if (!MAP_RENDER_SHOW_TIMER) {{
        MAP_RENDER_SHOW_TIMER = setTimeout(() => {{
          MAP_RENDER_SHOW_TIMER = null;
          if (MAP_RENDER_OPS > 0 && !IS_MAP_INTERACTING) _syncMapRenderLoaderDOM();
        }}, MAP_RENDER_LOADER_DELAY_MS);
      }}
      if (MAP_RENDER_SAFETY_TIMER) clearTimeout(MAP_RENDER_SAFETY_TIMER);
      MAP_RENDER_SAFETY_TIMER = setTimeout(() => {{
        MAP_RENDER_OPS = 0;
        if (MAP_RENDER_SHOW_TIMER) {{
          clearTimeout(MAP_RENDER_SHOW_TIMER);
          MAP_RENDER_SHOW_TIMER = null;
        }}
        Object.keys(MAP_TILE_SOURCE_STATE).forEach(k => {{ MAP_TILE_SOURCE_STATE[k] = false; }});
        _syncMapRenderLoaderDOM();
      }}, 14000);
    }}

    function endMapRenderLoader(immediate) {{
      MAP_RENDER_OPS = Math.max(0, MAP_RENDER_OPS - 1);
      if (MAP_RENDER_OPS === 0) {{
        if (MAP_RENDER_SHOW_TIMER) {{
          clearTimeout(MAP_RENDER_SHOW_TIMER);
          MAP_RENDER_SHOW_TIMER = null;
        }}
        if (MAP_RENDER_SAFETY_TIMER) {{
          clearTimeout(MAP_RENDER_SAFETY_TIMER);
          MAP_RENDER_SAFETY_TIMER = null;
        }}
        if (immediate) {{
          _syncMapRenderLoaderDOM();
        }} else {{
          if (MAP_RENDER_HIDE_TIMER) clearTimeout(MAP_RENDER_HIDE_TIMER);
          MAP_RENDER_HIDE_TIMER = setTimeout(() => {{
            MAP_RENDER_HIDE_TIMER = null;
            if (MAP_RENDER_OPS === 0) _syncMapRenderLoaderDOM();
          }}, 140);
        }}
      }}
    }}

    function _setTileSourceLoading(sourceKey, isLoading, label) {{
      const key = String(sourceKey || '');
      const prev = Boolean(MAP_TILE_SOURCE_STATE[key]);
      const next = Boolean(isLoading);
      if (prev === next) return;
      MAP_TILE_SOURCE_STATE[key] = next;
      if (next) beginMapRenderLoader(label);
      else endMapRenderLoader(false);
    }}

    const _WMS_TILE_ERROR_LOGGED = {{}};
    const _PACKAGED_BASEMAP_OVERLAYS = [];

    function _isFramedSandboxEnv() {{
      try {{
        if (!isEmbeddedIframe()) return false;
        const orig = (typeof window !== 'undefined' && window.origin !== undefined) ? String(window.origin || '') : '';
        return orig === 'null' || orig.includes('-files.sharepoint.com');
      }} catch (_e) {{
        return true;
      }}
    }}

    function ensurePackagedBasemapOverlay(reason) {{
      if (_PACKAGED_BASEMAP_OVERLAYS.length > 0) return true;
      const pb = (typeof BUNDLE !== 'undefined' && BUNDLE) ? BUNDLE.packaged_basemap : null;
      if (!pb || !pb.data_uri || !map || typeof L === 'undefined' || typeof L.imageOverlay !== 'function') {{
        return false;
      }}
      const addOne = (uri, bb3301, zIdx) => {{
        if (!uri || !Array.isArray(bb3301) || bb3301.length !== 4) return false;
        const sw = _toWgs84Coord(bb3301[0], bb3301[1]);
        const ne = _toWgs84Coord(bb3301[2], bb3301[3]);
        if (!sw || !ne) return false;
        let paneName = 'tilePane';
        if (typeof map.getPane === 'function' && typeof map.createPane === 'function') {{
          let pEl = map.getPane('packagedBasemapPane');
          if (!pEl) {{
            pEl = map.createPane('packagedBasemapPane');
            if (pEl && pEl.style) {{
              pEl.style.zIndex = '150';
              pEl.style.pointerEvents = 'none';
            }}
          }}
          if (pEl) paneName = 'packagedBasemapPane';
        }}
        const ov = L.imageOverlay(uri, [sw, ne], {{
          opacity: 1.0,
          interactive: false,
          pane: paneName,
          zIndex: zIdx || 1
        }});
        ov.addTo(map);
        _PACKAGED_BASEMAP_OVERLAYS.push(ov);
        return true;
      }};
      const mounted = addOne(pb.data_uri, pb.bbox_3301, 1);
      if (pb.home_data_uri && pb.home_bbox_3301) {{
        addOne(pb.home_data_uri, pb.home_bbox_3301, 2);
      }}
      if (mounted) {{
        devLog('INFO', 'MAP', `Using packaged Maa-amet basemap snapshot (${{String(reason || 'fallback')}}).`);
      }}
      return mounted;
    }}

    function attachMapLayerLoaderEvents(layerObj, sourceKey, label) {{
      if (!layerObj || typeof layerObj.on !== 'function' || layerObj.__qdashLoaderAttached) return;
      layerObj.__qdashLoaderAttached = true;
      layerObj.on('loading', () => _setTileSourceLoading(sourceKey, true, label));
      layerObj.on('load', () => _setTileSourceLoading(sourceKey, false, label));
      layerObj.on('tileerror', () => {{
        _setTileSourceLoading(sourceKey, false, label);
        const errKey = String(sourceKey || label || 'wms');
        if (!_WMS_TILE_ERROR_LOGGED[errKey]) {{
          _WMS_TILE_ERROR_LOGGED[errKey] = true;
          devLog('WARN', 'MAP', `WMS tile blocked or unreachable (${{label || errKey}}); vector layers remain active.`);
        }}
        if (errKey.startsWith('basemap:')) {{
          ensurePackagedBasemapOverlay('live WMS blocked by CSP/offline');
        }} else if (errKey.startsWith('wfs_wms:')) {{
          const lyrName = errKey.slice(8);
          if (lyrName && LAYER_WMS_OVERLAYS[lyrName]) {{
            const blockedWms = LAYER_WMS_OVERLAYS[lyrName];
            delete LAYER_WMS_OVERLAYS[lyrName];
            IS_SYNCING_MAP_LAYERS += 1;
            try {{
              if (map && typeof map.hasLayer === 'function' && map.hasLayer(blockedWms) && typeof map.removeLayer === 'function') {{
                map.removeLayer(blockedWms);
              }}
            }} finally {{
              IS_SYNCING_MAP_LAYERS -= 1;
            }}
            if (typeof scheduleMapRender === 'function') scheduleMapRender({{ skipAutoZoom: true }});
          }}
        }}
      }});
      layerObj.on('error', () => _setTileSourceLoading(sourceKey, false, label));
      layerObj.on('remove', () => _setTileSourceLoading(sourceKey, false, label));
    }}

    function scheduleMapRender(opts) {{
      const options = opts || {{}};
      beginMapRenderLoader(options.label);
      const run = () => {{
        try {{
          if (typeof renderMapFeatures === 'function') renderMapFeatures(options);
        }} finally {{
          endMapRenderLoader(false);
        }}
      }};
      if (typeof requestAnimationFrame === 'function') {{
        requestAnimationFrame(() => setTimeout(run, 0));
      }} else {{
        run();
      }}
    }}

    function _pointWgs84BufferGeom(lat, lon, dLat, dLon) {{
      const dy = Number(dLat || 0.00035);
      const dx = Number(dLon || 0.00065);
      const bb = [lon - dx, lat - dy, lon + dx, lat + dy];
      return {{
        bbox: bb,
        geometry: {{
          type: 'Polygon',
          coordinates: [[[bb[0], bb[1]], [bb[2], bb[1]], [bb[2], bb[3]], [bb[0], bb[3]], [bb[0], bb[1]]]]
        }}
      }};
    }}

    function resetMapHomeView() {{
      if (!map || !HOME_MAP_VIEW) return;
      const hb = HOME_MAP_VIEW.bounds;
      if (Array.isArray(hb) && hb.length === 4 && hb.every(v => Number.isFinite(Number(v)))) {{
        safeFitBounds([[Number(hb[0]), Number(hb[1])], [Number(hb[2]), Number(hb[3])]], {{ padding: [6, 6], maxZoom: 14, refreshAfterZoom: true }});
        return;
      }}
      safeSetView([HOME_MAP_VIEW.lat, HOME_MAP_VIEW.lon], HOME_MAP_VIEW.zoom);
    }}

    let ADDR_SEARCH_TIMER = null;
    let ADDR_SEARCH_SEQ = 0;

    function clearAddressSearchResult() {{
      if (ADDR_SEARCH_TIMER) {{
        clearTimeout(ADDR_SEARCH_TIMER);
        ADDR_SEARCH_TIMER = null;
      }}
      ADDR_SEARCH_SEQ += 1;
      const inp = document.getElementById('map-addr-input');
      const box = document.getElementById('map-addr-results');
      if (inp) inp.value = '';
      if (box) {{
        box.innerHTML = '';
        box.style.display = 'none';
      }}
      if (ADDRESS_RESULT_LAYER && map && map.hasLayer && map.hasLayer(ADDRESS_RESULT_LAYER)) {{
        map.removeLayer(ADDRESS_RESULT_LAYER);
      }}
      ADDRESS_RESULT_LAYER = null;
      LAST_ADDRESS_RESULTS = [];
      delete ACTIVE_FILTERS['__map_addr__'];
      if (LAST_INTERACTED_FILTER_SOURCE === '__map_addr__') LAST_INTERACTED_FILTER_SOURCE = null;
      saveDashboardSessionState();
      if (typeof buildSlicers === 'function') buildSlicers();
      if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
      if (typeof triggerRenderWithBusyFeedback === 'function') {{
        triggerRenderWithBusyFeedback({{ skipAutoZoom: true }});
      }} else if (typeof renderAll === 'function') {{
        renderAll({{ skipAutoZoom: true }});
      }}
    }}

    function _toWgs84Coord(x, y) {{
      const nx = Number(x);
      const ny = Number(y);
      if (!isFinite(nx) || !isFinite(ny)) return null;
      if (Math.abs(nx) <= 180 && Math.abs(ny) <= 90) {{
        // In GeoJSON [lon, lat], longitude for Estonia is ~21..28 and latitude ~57..60
        if (nx > 45 && ny < 45) return [nx, ny];
        return [ny, nx];
      }}
      let estX = nx;
      let estY = ny;
      if (estX > 3000000 && estY < 1000000) {{
        estX = ny;
        estY = nx;
      }}
      if (typeof proj4 !== 'undefined') {{
        try {{
          const estProj = '+proj=lcc +lat_1=59.33333333333334 +lat_2=58 +lat_0=57.51755393055556 +lon_0=24 +x_0=500000 +y_0=6375000 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs';
          const out = proj4(estProj, 'WGS84', [estX, estY]);
          if (out && isFinite(out[0]) && isFinite(out[1])) {{
            return [out[1], out[0]];
          }}
        }} catch (_e) {{}}
      }}
      return null;
    }}

    function _convertEstGeomToWgs84(geom) {{
      if (!geom) return null;
      let parsed = geom;
      if (typeof parsed === 'string' && parsed.trim().startsWith('{{')) {{
        try {{ parsed = JSON.parse(parsed); }} catch (_e) {{ return null; }}
      }}
      if (!parsed || !parsed.coordinates) return null;
      const convPt = pt => {{
        if (!Array.isArray(pt) || pt.length < 2) return pt;
        const px = Number(pt[0]);
        const py = Number(pt[1]);
        if (Math.abs(px) <= 180 && Math.abs(py) <= 90) {{
          return (px > 45 && py < 45) ? [py, px] : [px, py];
        }}
        const ll = _toWgs84Coord(px, py);
        return ll ? [ll[1], ll[0]] : [px, py];
      }};
      const convRings = rings => (rings || []).map(r => (r || []).map(convPt));
      if (parsed.type === 'Point') return {{ type: 'Point', coordinates: convPt(parsed.coordinates) }};
      if (parsed.type === 'LineString') return {{ type: 'LineString', coordinates: (parsed.coordinates || []).map(convPt) }};
      if (parsed.type === 'MultiLineString') return {{ type: 'MultiLineString', coordinates: convRings(parsed.coordinates) }};
      if (parsed.type === 'Polygon') return {{ type: 'Polygon', coordinates: convRings(parsed.coordinates) }};
      if (parsed.type === 'MultiPolygon') return {{ type: 'MultiPolygon', coordinates: (parsed.coordinates || []).map(convRings) }};
      return null;
    }}

    function selectEstonianAddressCandidate(idx) {{
      if (ADDR_SEARCH_TIMER) {{
        clearTimeout(ADDR_SEARCH_TIMER);
        ADDR_SEARCH_TIMER = null;
      }}
      ADDR_SEARCH_SEQ += 1;
      const item = LAST_ADDRESS_RESULTS[Number(idx)];
      if (!item || !map) return;
      const box = document.getElementById('map-addr-results');
      if (box) box.style.display = 'none';
      const inp = document.getElementById('map-addr-input');
      const dispLabel = item.display_name || item.label || item.ipikkaadress || '';
      if (inp) inp.value = dispLabel;
      if (ADDRESS_RESULT_LAYER && map.hasLayer && map.hasLayer(ADDRESS_RESULT_LAYER)) {{
        map.removeLayer(ADDRESS_RESULT_LAYER);
      }}
      let targetLatLon = null;
      if (item.lat !== undefined && item.lon !== undefined && item.lat !== null && item.lon !== null) {{
        targetLatLon = [Number(item.lat), Number(item.lon)];
      }} else if (item.x_3301 !== undefined && item.y_3301 !== undefined && item.x_3301 !== null && item.y_3301 !== null) {{
        targetLatLon = _toWgs84Coord(item.x_3301, item.y_3301);
      }} else if (item.viitepunkt_b !== undefined && item.viitepunkt_l !== undefined) {{
        targetLatLon = [Number(item.viitepunkt_b), Number(item.viitepunkt_l)];
      }} else if (item.viitepunkt_x !== undefined && item.viitepunkt_y !== undefined) {{
        targetLatLon = _toWgs84Coord(item.viitepunkt_x, item.viitepunkt_y);
      }}
      const geomWgs = item.geometry ? _convertEstGeomToWgs84(item.geometry) : null;
      const grp = L.featureGroup ? L.featureGroup().addTo(map) : L.layerGroup().addTo(map);
      if (geomWgs && typeof L.geoJSON === 'function') {{
        const gl = L.geoJSON(geomWgs, {{ style: {{ color: '#f97316', fillColor: '#fb923c', weight: 3, fillOpacity: 0.25 }} }});
        grp.addLayer(gl);
      }}
      if (!targetLatLon && Array.isArray(item.bbox_3301) && item.bbox_3301.length === 4) {{
        targetLatLon = _toWgs84Coord((item.bbox_3301[0] + item.bbox_3301[2]) / 2, (item.bbox_3301[1] + item.bbox_3301[3]) / 2);
      }}
      if (targetLatLon && typeof L.circleMarker === 'function') {{
        const mk = L.circleMarker(targetLatLon, {{ radius: 8, color: '#ef4444', fillColor: '#fef08a', weight: 3, fillOpacity: 0.9 }});
        if (mk.bindPopup) mk.bindPopup(`<b>${{dispLabel}}</b><br/><span style="opacity:0.8">${{item.type_label || item.type || ''}}</span>`);
        grp.addLayer(mk);
        if (mk.openPopup) mk.openPopup();
      }}
      ADDRESS_RESULT_LAYER = grp;
      if (geomWgs && grp.getBounds && grp.getBounds().isValid && grp.getBounds().isValid()) {{
        safeFitBounds(grp.getBounds(), {{ padding: [45, 45], maxZoom: 13 }});
      }} else if (targetLatLon) {{
        safeSetView(targetLatLon, 12);
      }}
      let spatialGeom = geomWgs;
      let spatialBbox = geomWgs ? geomBbox(geomWgs) : null;
      if (!spatialGeom && Array.isArray(item.bbox_3301) && item.bbox_3301.length === 4) {{
        const sw = _toWgs84Coord(item.bbox_3301[0], item.bbox_3301[1]);
        const ne = _toWgs84Coord(item.bbox_3301[2], item.bbox_3301[3]);
        if (sw && ne) {{
          spatialBbox = [Math.min(sw[1], ne[1]), Math.min(sw[0], ne[0]), Math.max(sw[1], ne[1]), Math.max(sw[0], ne[0])];
          spatialGeom = _bboxToPolyGeom(spatialBbox);
        }}
      }}
      if (!spatialGeom && targetLatLon) {{
        const buf = _pointWgs84BufferGeom(targetLatLon[0], targetLatLon[1]);
        spatialGeom = buf.geometry;
        spatialBbox = buf.bbox;
      }}
      if (spatialGeom || spatialBbox) {{
        ACTIVE_FILTERS['__map_addr__'] = {{
          layer_name: '__spatial__',
          field_name: 'address',
          type: 'spatial_geom',
          geometry: spatialGeom,
          bbox: spatialBbox,
          display_label: dispLabel || t('addr_search_btn'),
          is_global: true
        }};
        LAST_INTERACTED_FILTER_SOURCE = '__map_addr__';
        saveDashboardSessionState();
        if (typeof buildSlicers === 'function') buildSlicers();
        if (typeof renderAll === 'function') renderAll({{ skipAutoZoom: true }});
      }}
    }}

    function scheduleAddressSearchHtml() {{
      if (ADDR_SEARCH_TIMER) {{
        clearTimeout(ADDR_SEARCH_TIMER);
        ADDR_SEARCH_TIMER = null;
      }}
      const inp = document.getElementById('map-addr-input');
      const box = document.getElementById('map-addr-results');
      const query = inp ? String(inp.value || '').trim() : '';
      if (query.length < 2) {{
        ADDR_SEARCH_SEQ += 1;
        if (box) {{
          box.innerHTML = '';
          box.style.display = 'none';
        }}
        return;
      }}
      ADDR_SEARCH_TIMER = setTimeout(() => {{
        ADDR_SEARCH_TIMER = null;
        searchEstonianAddressHtml(true);
      }}, 240);
    }}

    async function searchEstonianAddressHtml(silentBusy = false) {{
      if (ADDR_SEARCH_TIMER) {{
        clearTimeout(ADDR_SEARCH_TIMER);
        ADDR_SEARCH_TIMER = null;
      }}
      const inp = document.getElementById('map-addr-input');
      const box = document.getElementById('map-addr-results');
      const query = inp ? String(inp.value || '').trim() : '';
      if (!query || query.length < 2) {{
        ADDR_SEARCH_SEQ += 1;
        if (box) box.style.display = 'none';
        return;
      }}
      const reqSeq = ++ADDR_SEARCH_SEQ;
      if (!silentBusy) beginBusyOp(t('addr_searching'));
      if (box && (!silentBusy || box.style.display !== 'block')) {{
        box.innerHTML = `<div class="map-addr-item"><span>${{t('addr_searching')}}</span></div>`;
        box.style.display = 'block';
      }}
      try {{
        let rawList = [];
        try {{
          const params = new URLSearchParams({{
            address: query,
            features: 'EHITISHOONE,KATASTRIYKSUS,TANAV,EHAK,VAIKEKOHT',
            results: '10',
            unik: '0',
            geometry: '1'
          }});
          const resp = await fetch('https://inaadress.maaamet.ee/inaadress/gazetteer?' + params.toString());
          if (resp.ok) {{
            const data = await resp.json();
            if (Array.isArray(data && data.addresses)) rawList = data.addresses;
          }}
        }} catch (_corsErr) {{}}
        if (!rawList.length && HAS_PREVIEW_API) {{
          const pResp = await fetch('/api/address?q=' + encodeURIComponent(query));
          if (pResp.ok) {{
            const pData = await pResp.json();
            const pItems = pData ? (pData.addresses || pData.results) : null;
            if (Array.isArray(pItems)) rawList = pItems;
          }}
        }}
        if (reqSeq !== ADDR_SEARCH_SEQ) return;
        LAST_ADDRESS_RESULTS = rawList.map(a => {{
          const name = a.display_name || a.label || a.ipikkaadress || a.pikkaadress || a.taisaadress || a.aadress || '';
          const tLbl = a.type_label || a.type || a.liikVal || a.liik || '';
          return Object.assign({{}}, a, {{ display_name: name, type_label: tLbl }});
        }}).filter(a => a.display_name);
        if (!box) return;
        if (!LAST_ADDRESS_RESULTS.length) {{
          box.innerHTML = `<div class="map-addr-item"><span>${{t('addr_no_results')}}</span></div>`;
          box.style.display = 'block';
          return;
        }}
        box.innerHTML = LAST_ADDRESS_RESULTS.map((r, i) =>
          `<div class="map-addr-item" onclick="selectEstonianAddressCandidate(${{i}})"><span>${{r.display_name}}</span><span style="opacity:0.65;white-space:nowrap;">${{r.type_label || ''}}</span></div>`
        ).join('');
        box.style.display = 'block';
      }} finally {{
        if (!silentBusy) endBusyOp();
      }}
    }}
    const LAYER_OVERLAYS = {{}};
    const LAYER_WMS_OVERLAYS = {{}};
    const LAYER_CANVAS_RENDERERS = {{}};
    const BASE_MAP_LAYERS = {{}};
    const BASE_MAP_LAYERS_BY_ID = {{}};
    const STATIC_WMS_OVERLAYS = {{}};
    const _LAYER_CONTROL_TRACKED = new Set();

    function ensureLayerOverlaysInitialized() {{
      if (typeof L === 'undefined' || !L || typeof L.layerGroup !== 'function') return;
      const allNames = _allConfiguredLayerNames();
      allNames.forEach(ln => {{
        if (!ln) return;
        if (!LAYER_OVERLAYS[ln]) {{
          LAYER_OVERLAYS[ln] = L.layerGroup();
        }}
        if (!HAS_PREVIEW_API && !_isFramedSandboxEnv() && !LAYER_WMS_OVERLAYS[ln]) {{
          const svc = (BUNDLE.ogc_services || []).find(s => s.name === ln && s.type === 'wfs');
          const wmsUrl = svc ? deriveGeoServerWmsUrl(svc.url) : '';
          if (wmsUrl && svc && svc.typename && typeof L.tileLayer !== 'undefined' && typeof L.tileLayer.wms === 'function') {{
            const stCfgWms = getMapLayerStyleCfg(ln);
            const wmsMinZ = (stCfgWms && Number(stCfgWms.min_zoom) > 0) ? Math.max(0, Number(stCfgWms.min_zoom)) : 0;
            LAYER_WMS_OVERLAYS[ln] = L.tileLayer.wms(wmsUrl, {{
              version: '1.1.1',
              layers: svc.typename,
              format: 'image/png',
              transparent: true,
              opacity: 0.85,
              minZoom: wmsMinZ,
              attribution: _deriveWmsAttribution(wmsUrl, ln)
            }});
            attachMapLayerLoaderEvents(LAYER_WMS_OVERLAYS[ln], 'wfs_wms:' + ln, ln + ' (WMS)');
          }}
        }}
      }});
    }}

    function syncActiveMapLayersAndControl(stateObj, opts) {{
      ensureLayerOverlaysInitialized();
      const mw = (stateObj && stateObj.mapWidget) ? stateObj.mapWidget : getActiveMapWidget();
      const mapHdr = document.getElementById('map-header-title');
      if (mapHdr) {{
        const titleTxt = (mw ? localizedTitle(mw) : '') || t('html_map_header');
        mapHdr.textContent = titleTxt;
        mapHdr.title = titleTxt;
      }}
      const activeNames = orderedMapLayerNames();
      const activeSet = new Set(activeNames);
      if (map) {{
        IS_SYNCING_MAP_LAYERS += 1;
        try {{
          if (stateObj && stateObj.basemapId && BASE_MAP_LAYERS_BY_ID[stateObj.basemapId]) {{
            const targetBm = BASE_MAP_LAYERS_BY_ID[stateObj.basemapId];
            Object.values(BASE_MAP_LAYERS).forEach(bl => {{
              if (bl && bl !== targetBm && map.hasLayer && map.hasLayer(bl)) map.removeLayer(bl);
            }});
            if (targetBm && map.hasLayer && !map.hasLayer(targetBm)) targetBm.addTo(map);
            DEFAULT_BASEMAP_LAYER = targetBm;
          }}
          Object.entries(LAYER_OVERLAYS).forEach(([ln, grp]) => {{
            if (!grp || activeSet.has(ln)) return;
            if (map.hasLayer && map.hasLayer(grp)) map.removeLayer(grp);
            if (LAYER_WMS_OVERLAYS[ln] && map.hasLayer && map.hasLayer(LAYER_WMS_OVERLAYS[ln])) {{
              map.removeLayer(LAYER_WMS_OVERLAYS[ln]);
            }}
            if (layerControl && _LAYER_CONTROL_TRACKED.has(ln)) {{
              if (typeof layerControl.removeLayer === 'function') layerControl.removeLayer(grp);
              _LAYER_CONTROL_TRACKED.delete(ln);
            }}
          }});
          activeNames.forEach(ln => {{
            const grp = LAYER_OVERLAYS[ln];
            if (!grp) return;
            if (layerControl && !_LAYER_CONTROL_TRACKED.has(ln)) {{
              if (typeof layerControl.addOverlay === 'function') layerControl.addOverlay(grp, ln);
              _LAYER_CONTROL_TRACKED.add(ln);
            }}
            if (MAP_LAYER_VISIBILITY[ln] !== false) {{
              if (map.hasLayer && !map.hasLayer(grp)) grp.addTo(map);
            }} else {{
              if (map.hasLayer && map.hasLayer(grp)) map.removeLayer(grp);
              if (LAYER_WMS_OVERLAYS[ln] && map.hasLayer && map.hasLayer(LAYER_WMS_OVERLAYS[ln])) {{
                map.removeLayer(LAYER_WMS_OVERLAYS[ln]);
              }}
            }}
          }});
        }} finally {{
          IS_SYNCING_MAP_LAYERS -= 1;
        }}
        if (layerControl && typeof layerControl._update === 'function') layerControl._update();
        syncLeafletLayerControlActions();
      }}
      if (opts && opts.applyViewport && map && stateObj) {{
        if (stateObj.lastView && Number.isFinite(Number(stateObj.lastView.lat)) && Number.isFinite(Number(stateObj.lastView.lng))) {{
          safeSetView([Number(stateObj.lastView.lat), Number(stateObj.lastView.lng)], Number(stateObj.lastView.zoom));
        }} else if (stateObj.homeView && Array.isArray(stateObj.homeView.bounds) && stateObj.homeView.bounds.length === 4 && stateObj.homeView.bounds.every(v => Number.isFinite(Number(v)))) {{
          safeFitBounds(
            [[Number(stateObj.homeView.bounds[0]), Number(stateObj.homeView.bounds[1])], [Number(stateObj.homeView.bounds[2]), Number(stateObj.homeView.bounds[3])]],
            {{ padding: [6, 6], maxZoom: 14, animate: false }}
          );
        }} else if (stateObj.hasExplicitView && stateObj.homeView) {{
          safeSetView([Number(stateObj.homeView.lat), Number(stateObj.homeView.lon)], Number(stateObj.homeView.zoom));
        }} else {{
          let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
          activeNames.forEach(ln => {{
            if (MAP_LAYER_VISIBILITY[ln] === false) return;
            const bbMap = LAYER_GEOM_BBOXES[ln];
            if (bbMap) {{
              Object.values(bbMap).forEach(bb => {{
                if (Array.isArray(bb) && bb.length === 4) {{
                  if (bb[0] < minX) minX = bb[0];
                  if (bb[1] < minY) minY = bb[1];
                  if (bb[2] > maxX) maxX = bb[2];
                  if (bb[3] > maxY) maxY = bb[3];
                }}
              }});
            }}
            const recs = LAYER_RECORDS[ln];
            if (Array.isArray(recs)) {{
              for (let i = 0; i < recs.length; i++) {{
                const r = recs[i];
                const bb = (r && Array.isArray(r._bbox) && r._bbox.length === 4)
                  ? r._bbox
                  : ((r && r._feature_id !== undefined) ? getFeatureBbox(ln, String(r._feature_id)) : null);
                if (Array.isArray(bb) && bb.length === 4) {{
                  if (bb[0] < minX) minX = bb[0];
                  if (bb[1] < minY) minY = bb[1];
                  if (bb[2] > maxX) maxX = bb[2];
                  if (bb[3] > maxY) maxY = bb[3];
                }}
              }}
            }}
          }});
          if (Number.isFinite(minX) && Number.isFinite(minY) && Number.isFinite(maxX) && Number.isFinite(maxY) && minX <= maxX && minY <= maxY) {{
            if (Math.abs(maxX - minX) < 1e-6 && Math.abs(maxY - minY) < 1e-6) {{
              safeSetView([(minY + maxY) * 0.5, (minX + maxX) * 0.5], 10);
            }} else {{
              safeFitBounds([[minY, minX], [maxY, maxX]], {{ padding: [18, 18], maxZoom: 12, animate: false }});
            }}
          }} else if (stateObj.homeView) {{
            safeSetView([Number(stateObj.homeView.lat), Number(stateObj.homeView.lon)], Number(stateObj.homeView.zoom));
          }}
        }}
      }}
    }}
    let DEFAULT_BASEMAP_LAYER = null;
    let HYBRID_LAYER_REF = null;
    let INITIAL_HYBRID_ENABLED = false;
    let INITIAL_LAYER_ORDER = null;
    const INITIAL_OGC_SERVICES = JSON.parse(JSON.stringify(BUNDLE.ogc_services || []));
    const INITIAL_DATA_LAYER_NAMES = new Set(Object.keys(BUNDLE.initial_layer_records || {{}}));
    const DYNAMIC_ADDED_LAYERS = new Set();
    let IS_SYNCING_MAP_LAYERS = 0;
    let PREVIEW_WMS_OVERLAY = null;
    let PREVIEW_WMS_RUN_OVERLAYS = [];
    let PREVIEW_WMS_KEY = '';
    let PREVIEW_WMS_REV = '';
    let vectorCanvasRenderer = null;
    const EXCEL_TABLES = BUNDLE.excel_tables || {{}};
    const ACTIVE_FILTERS = {{}};
    const SLICER_SEARCH_QUERIES = {{}};

    Object.entries(LAYER_STATS).forEach(([ln, st]) => {{
      if (st && st.geom_type && !LAYER_GEOM_TYPES[ln]) {{
        LAYER_GEOM_TYPES[ln] = st.geom_type;
      }}
    }});

    const PYRAMID_TYPE_MAP = {{
      P: 'Point',
      MP: 'MultiPoint',
      L: 'LineString',
      ML: 'MultiLineString',
      G: 'Polygon',
      MG: 'MultiPolygon'
    }};

    function decodePackedEntry(entry) {{
      if (!entry || !Array.isArray(entry) || entry.length < 3) return null;
      const gtype = PYRAMID_TYPE_MAP[entry[0]] || entry[0];
      if (!gtype) return null;
      return {{ type: gtype, coordinates: entry[2] }};
    }}

    const ESTONIA_RESOLUTIONS = [4000, 2000, 1000, 500, 250, 125, 62.5, 31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625];

    function computeMapScaleDenominator() {{
      if (!map) return 500000;
      try {{
        if (typeof map.getSize === 'function' && typeof map.getBounds === 'function' && typeof map.distance === 'function') {{
          const sz = map.getSize();
          const b = map.getBounds();
          if (sz && sz.x > 20 && b && b.isValid && b.isValid()) {{
            const midLat = (b.getNorth() + b.getSouth()) * 0.5;
            const metersAcross = map.distance([midLat, b.getWest()], [midLat, b.getEast()]);
            if (Number.isFinite(metersAcross) && metersAcross > 0) {{
              const mpp = metersAcross / sz.x;
              return Math.max(100, Math.round(mpp * 3779.52756));
            }}
          }}
        }}
      }} catch (_e) {{}}
      const zRaw = (typeof map.getZoom === 'function' && Number.isFinite(Number(map.getZoom())))
        ? Math.max(0, Math.min(14, Number(map.getZoom())))
        : 7;
      const res = 4000 / Math.pow(2, zRaw);
      return Math.max(100, Math.round(res * 3779.52756));
    }}

    function targetLodForScale(scaleDenom) {{
      if (!Number.isFinite(scaleDenom) || scaleDenom <= 0) return 2;
      if (scaleDenom > 750000) return 0;
      if (scaleDenom > 250000) return 1;
      if (scaleDenom > 55000) return 2;
      return 3;
    }}

    function formatScaleText(scaleDenom) {{
      const s = Math.max(100, Number(scaleDenom || 500000));
      const step = s >= 50000 ? 1000 : (s >= 5000 ? 100 : 50);
      const rounded = Math.round(s / step) * step;
      return '1:' + rounded.toString().replace(/\\B(?=(\\d{{3}})+(?!\\d))/g, ' ');
    }}

    const _ESTONIA_SCALE_PRESETS = [
      {{ labelKey: 'map_scale_preset_estonia', scale: 1500000, fitEstonia: true }},
      {{ labelKey: 'map_scale_preset_county', scale: 500000, fitEstonia: false }},
      {{ labelKey: 'map_scale_preset_municipality', scale: 200000, fitEstonia: false }},
      {{ labelKey: 'map_scale_preset_local', scale: 50000, fitEstonia: false }},
      {{ labelKey: 'map_scale_preset_detail', scale: 25000, fitEstonia: false }},
      {{ labelKey: 'map_scale_preset_cadastre', scale: 10000, fitEstonia: false }},
      {{ labelKey: 'map_scale_preset_closeup', scale: 5000, fitEstonia: false }},
    ];

    function _computeViewportSpanText() {{
      try {{
        if (map && typeof map.getBounds === 'function' && typeof map.distance === 'function') {{
          const b = map.getBounds();
          if (b && b.isValid && b.isValid()) {{
            const midLat = (b.getNorth() + b.getSouth()) * 0.5;
            const midLon = (b.getEast() + b.getWest()) * 0.5;
            const wM = map.distance([midLat, b.getWest()], [midLat, b.getEast()]);
            const hM = map.distance([b.getSouth(), midLon], [b.getNorth(), midLon]);
            if (Number.isFinite(wM) && Number.isFinite(hM) && wM > 0 && hM > 0) {{
              return (wM >= 10000)
                ? `~${{(wM / 1000).toFixed(1)}} × ${{(hM / 1000).toFixed(1)}} km`
                : `~${{Math.round(wM)}} × ${{Math.round(hM)}} m`;
            }}
          }}
        }}
      }} catch (_e) {{}}
      return '~360 × 240 km';
    }}

    function updateMapScaleBadge(scaleDenom, lod, opts) {{
      const el = document.getElementById('map-scale-badge');
      if (!el) return;
      const options = opts || {{}};
      const lbl = CURR_LANG === 'en' ? 'Scale' : 'Mõõtkava';
      const zRaw = (map && typeof map.getZoom === 'function' && Number.isFinite(Number(map.getZoom())))
        ? Number(map.getZoom())
        : 7;
      const zTxt = Math.abs(zRaw - Math.round(zRaw)) < 0.08 ? String(Math.round(zRaw)) : zRaw.toFixed(1);
      let lodTxt = `LOD-${{lod}}`;
      if (lod >= 3) {{
        if (options.hasExactDetail === true) {{
          lodTxt = '1:1 Detail';
        }} else {{
          const dispLod = Number.isFinite(Number(options.actualLod)) ? Math.max(0, Math.min(2, Number(options.actualLod))) : 1;
          lodTxt = options.fetchingUpgrade ? `LOD-${{dispLod}} (1:1…)` : `LOD-${{dispLod}}`;
        }}
      }}
      const scaleTxt = formatScaleText(scaleDenom);
      el.textContent = `${{lbl}}: ${{scaleTxt}} · Z=${{zTxt}} · ${{lodTxt}} ▾`;
      el.title = t('map_scale_hover_info', {{
        scale: scaleTxt,
        zoom_txt: `Z=${{zTxt}}`,
        span_txt: _computeViewportSpanText(),
        detail_txt: lodTxt,
      }});
    }}

    function _ensureMapScaleMenuEl() {{
      let menu = document.getElementById('map-scale-menu');
      if (!menu && document.body && typeof document.createElement === 'function') {{
        menu = document.createElement('div');
        menu.id = 'map-scale-menu';
        menu.className = 'map-scale-menu';
        document.body.appendChild(menu);
      }}
      return menu;
    }}

    function closeMapScaleMenu() {{
      const menu = document.getElementById('map-scale-menu');
      if (menu) menu.style.display = 'none';
    }}

    function renderMapScaleMenu() {{
      const menu = _ensureMapScaleMenuEl();
      if (!menu) return;
      menu.innerHTML = '';
      const hdr = document.createElement('div');
      hdr.className = 'map-scale-menu-hdr';
      hdr.textContent = t('map_scale_menu_title');
      menu.appendChild(hdr);
      _ESTONIA_SCALE_PRESETS.forEach(p => {{
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'map-scale-preset-btn';
        btn.textContent = t(p.labelKey);
        btn.onclick = () => {{
          closeMapScaleMenu();
          applyMapScalePreset(p.scale, p.fitEstonia);
        }};
        menu.appendChild(btn);
      }});
      const row = document.createElement('div');
      row.className = 'map-scale-manual-row';
      const prefix = document.createElement('span');
      prefix.textContent = '1:';
      prefix.style.fontWeight = '700';
      const inp = document.createElement('input');
      inp.id = 'map-scale-manual-input';
      inp.type = 'text';
      inp.placeholder = t('map_scale_manual_ph');
      inp.value = String(Math.max(500, Math.round(computeMapScaleDenominator() / 100) * 100));
      inp.onkeydown = (e) => {{
        if (e.key === 'Enter') {{
          e.preventDefault();
          applyManualMapScale();
        }} else if (e.key === 'Escape') {{
          closeMapScaleMenu();
        }}
      }};
      const goBtn = document.createElement('button');
      goBtn.type = 'button';
      goBtn.className = 'btn-mini-icon';
      goBtn.textContent = t('map_scale_manual_apply');
      goBtn.onclick = () => applyManualMapScale();
      row.appendChild(prefix);
      row.appendChild(inp);
      row.appendChild(goBtn);
      menu.appendChild(row);
    }}

    function toggleMapScaleMenu(ev) {{
      if (ev && typeof ev.stopPropagation === 'function') ev.stopPropagation();
      const menu = _ensureMapScaleMenuEl();
      const btn = document.getElementById('map-scale-badge');
      if (!menu || !btn) return;
      const isOpen = menu.style.display === 'flex';
      if (isOpen) {{
        closeMapScaleMenu();
        return;
      }}
      renderMapScaleMenu();
      menu.style.display = 'flex';
      if (typeof btn.getBoundingClientRect === 'function') {{
        const rect = btn.getBoundingClientRect();
        const winW = (typeof window !== 'undefined' && window.innerWidth) ? window.innerWidth : 1200;
        const winH = (typeof window !== 'undefined' && window.innerHeight) ? window.innerHeight : 800;
        const leftPos = Math.max(8, Math.min(rect.left, winW - 285));
        const topPos = Math.max(8, Math.min(rect.bottom + 6, winH - 320));
        menu.style.left = leftPos + 'px';
        menu.style.top = topPos + 'px';
      }}
    }}

    function applyMapScalePreset(scaleDenom, fitEstonia) {{
      if (!map) return;
      if (fitEstonia && typeof safeFitBounds === 'function') {{
        safeFitBounds([[57.48, 21.65], [59.70, 28.25]], {{ padding: [10, 10], maxZoom: 14, refreshAfterZoom: true }});
        return;
      }}
      const targetScale = Math.max(250, Math.min(15000000, Number(scaleDenom) || 500000));
      const targetRes = targetScale / 3779.52756;
      let targetZoom = Math.log2(4000 / targetRes);
      if (map.options && map.options.crs && typeof map.options.crs.zoom === 'function') {{
        const crsZoom = Number(map.options.crs.zoom(1 / targetRes));
        if (Number.isFinite(crsZoom)) targetZoom = crsZoom;
      }}
      targetZoom = Math.max(0, Math.min(14, targetZoom));
      if (typeof map.setView === 'function' && typeof map.getCenter === 'function') {{
        map.setView(map.getCenter(), targetZoom, {{ animate: false }});
      }} else if (typeof map.setZoom === 'function') {{
        map.setZoom(targetZoom, {{ animate: false }});
      }}
      const sNow = computeMapScaleDenominator();
      updateMapScaleBadge(sNow, targetLodForScale(sNow));
      if (typeof scheduleMapRender === 'function') {{
        scheduleMapRender({{ skipAutoZoom: true }});
      }}
    }}

    function applyManualMapScale() {{
      const inp = document.getElementById('map-scale-manual-input');
      if (!inp) return;
      const raw = String(inp.value || '').trim().replace(/^1\\s*:\\s*/i, '').replace(/[\\s,]+/g, '');
      const val = Number(raw);
      if (Number.isFinite(val) && val > 0) {{
        closeMapScaleMenu();
        applyMapScalePreset(val, false);
      }}
    }}

    function buildDynamicViewportGrid(records, cellDeg, viewBox) {{
      const cells = {{}};
      const step = Math.max(0.002, Number(cellDeg || 0.008));
      for (let i = 0; i < records.length; i++) {{
        const r = records[i];
        const lon = Number(r._lon);
        const lat = Number(r._lat);
        if (!Number.isFinite(lon) || !Number.isFinite(lat)) continue;
        if (viewBox && (lon < viewBox[0] || lon > viewBox[2] || lat < viewBox[1] || lat > viewBox[3])) continue;
        const ix = Math.floor(lon / step);
        const iy = Math.floor(lat / step);
        const k = `${{ix}}_${{iy}}`;
        if (!cells[k]) {{
          cells[k] = {{
            x0: ix * step, y0: iy * step, x1: (ix + 1) * step, y1: (iy + 1) * step,
            count: 0, area: 0, sample: r
          }};
        }}
        cells[k].count++;
        cells[k].area += Number(r._geom_area_ha || r.area_ha || 0);
      }}
      const feats = Object.values(cells).slice(0, 1800).map(c => ({{
        type: 'Feature',
        properties: Object.assign({{}}, c.sample, {{ count: c.count, area_ha: Math.round(c.area * 10) / 10 }}),
        geometry: {{
          type: 'Polygon',
          coordinates: [[[c.x0, c.y0], [c.x1, c.y0], [c.x1, c.y1], [c.x0, c.y1], [c.x0, c.y0]]]
        }}
      }}));
      return {{ type: 'FeatureCollection', features: feats }};
    }}

    const _RECORD_BBOX_INDEX = {{}};

    function _getRecordByFid(layerName, fidStr) {{
      const recs = LAYER_RECORDS[layerName];
      if (!Array.isArray(recs)) return null;
      if (!_RECORD_BBOX_INDEX['__rec__' + layerName]) {{
        const rm = new Map();
        for (let i = 0; i < recs.length; i++) {{
          const r = recs[i];
          if (r && r._feature_id !== undefined && r._feature_id !== null) {{
            rm.set(String(r._feature_id), r);
          }}
        }}
        _RECORD_BBOX_INDEX['__rec__' + layerName] = rm;
      }}
      return _RECORD_BBOX_INDEX['__rec__' + layerName].get(fidStr) || null;
    }}

    function _resolveLegacyLod1Key(layerName, fidStr, packedMap) {{
      if (!packedMap) return null;
      if (packedMap[fidStr]) return fidStr;
      const s = String(fidStr || '');
      const dotIdx = s.lastIndexOf('.');
      if (dotIdx <= 0) return null;
      const tail = s.slice(dotIdx + 1);
      if (!/^-?\\d+$/.test(tail)) return null;
      const row = _getRecordByFid(layerName, s);
      const rbb = (row && Array.isArray(row._bbox) && row._bbox.length === 4) ? row._bbox.map(Number) : null;
      const nTail = Number(tail);
      const candidates = [tail, String(nTail + 1), String(nTail - 1)];
      for (let ci = 0; ci < candidates.length; ci++) {{
        const ck = candidates[ci];
        const entry = packedMap[ck];
        if (!entry) continue;
        if (!rbb || !Array.isArray(entry[1])) return ck;
        const pbb = entry[1];
        if (Math.abs(pbb[0] - rbb[0]) <= 0.004 && Math.abs(pbb[1] - rbb[1]) <= 0.004 &&
            Math.abs(pbb[2] - rbb[2]) <= 0.004 && Math.abs(pbb[3] - rbb[3]) <= 0.004) {{
          return ck;
        }}
      }}
      return null;
    }}

    function getFeatureGeometry(layerName, fidStr) {{
      const exact = (LAYER_GEOMETRIES[layerName] || {{}})[fidStr];
      if (exact) return exact;
      const packedMap = LAYER_PYRAMID_LOD1[layerName];
      const pKey = _resolveLegacyLod1Key(layerName, fidStr, packedMap);
      if (pKey && packedMap[pKey]) {{
        const g = decodePackedEntry(packedMap[pKey]);
        if (g) {{
          if (!LAYER_GEOMETRIES[layerName]) LAYER_GEOMETRIES[layerName] = {{}};
          if (!LAYER_GEOM_LOD[layerName]) LAYER_GEOM_LOD[layerName] = {{}};
          LAYER_GEOMETRIES[layerName][fidStr] = g;
          if (!LAYER_GEOM_LOD[layerName][fidStr]) LAYER_GEOM_LOD[layerName][fidStr] = 1;
          if (packedMap[pKey][1]) {{
            if (!LAYER_GEOM_BBOXES[layerName]) LAYER_GEOM_BBOXES[layerName] = {{}};
            LAYER_GEOM_BBOXES[layerName][fidStr] = packedMap[pKey][1];
          }}
          return g;
        }}
      }}
      return null;
    }}

    function getFeatureBbox(layerName, fidStr) {{
      const cached = (LAYER_GEOM_BBOXES[layerName] || {{}})[fidStr];
      if (cached) return cached;
      const packedMap = LAYER_PYRAMID_LOD1[layerName];
      const pKey = _resolveLegacyLod1Key(layerName, fidStr, packedMap);
      if (pKey && packedMap[pKey] && Array.isArray(packedMap[pKey][1])) {{
        return packedMap[pKey][1];
      }}
      const exact = (LAYER_GEOMETRIES[layerName] || {{}})[fidStr];
      if (exact && typeof geomBbox === 'function') {{
        const bb = geomBbox(exact);
        if (bb) {{
          if (!LAYER_GEOM_BBOXES[layerName]) LAYER_GEOM_BBOXES[layerName] = {{}};
          LAYER_GEOM_BBOXES[layerName][fidStr] = bb;
        }}
        return bb;
      }}
      if (!_RECORD_BBOX_INDEX[layerName] && Array.isArray(LAYER_RECORDS[layerName])) {{
        const idxMap = new Map();
        const recs = LAYER_RECORDS[layerName];
        for (let i = 0; i < recs.length; i++) {{
          const r = recs[i];
          if (r && r._feature_id !== undefined && r._feature_id !== null && Array.isArray(r._bbox) && r._bbox.length === 4) {{
            idxMap.set(String(r._feature_id), r._bbox.map(Number));
          }}
        }}
        _RECORD_BBOX_INDEX[layerName] = idxMap;
      }}
      const recMap = _RECORD_BBOX_INDEX[layerName];
      if (recMap && recMap.has(fidStr)) {{
        return recMap.get(fidStr);
      }}
      return null;
    }}

    function bboxIntersects(bb, viewBox) {{
      if (!bb || !viewBox) return true;
      return !(bb[2] < viewBox[0] || bb[0] > viewBox[2] || bb[3] < viewBox[1] || bb[1] > viewBox[3]);
    }}

    function _hashFidList(fids) {{
      let h = 2166136261;
      for (let i = 0; i < fids.length; i++) {{
        const s = String(fids[i]);
        for (let j = 0; j < s.length; j++) {{
          h ^= s.charCodeAt(j);
          h = Math.imul(h, 16777619);
        }}
        h ^= 44;
        h = Math.imul(h, 16777619);
      }}
      return (h >>> 0).toString(36);
    }}

    function escapeHtml(val) {{
      if (val === null || val === undefined) return '';
      return String(val)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }}

    function safeFitBounds(boundsOrPoints, opts) {{
      if (!map || !boundsOrPoints) return;
      const options = Object.assign({{ padding: [32, 32], maxZoom: 14, animate: false }}, opts || {{}});
      if (options.animate === undefined) options.animate = false;
      IS_PROGRAMMATIC_MOVE = true;
      try {{
        map.fitBounds(boundsOrPoints, options);
      }} finally {{
        setTimeout(() => {{
          IS_PROGRAMMATIC_MOVE = false;
          if (options.refreshAfterZoom && typeof renderMapFeatures === 'function') {{
            renderMapFeatures({{ skipAutoZoom: true, fromAsyncFetch: true }});
          }}
        }}, 160);
      }}
    }}

    function safeSetView(center, zoom, opts) {{
      if (!map || !center) return;
      const options = Object.assign({{ animate: false }}, opts || {{}});
      IS_PROGRAMMATIC_MOVE = true;
      try {{
        map.setView(center, zoom, options);
      }} finally {{
        setTimeout(() => {{
          IS_PROGRAMMATIC_MOVE = false;
          if (typeof syncZoomVisibilityImmediate === 'function') syncZoomVisibilityImmediate();
          if (typeof renderMapFeatures === 'function') {{
            renderMapFeatures({{ skipAutoZoom: true, fromAsyncFetch: true }});
          }}
        }}, 140);
      }}
    }}

    function _currentViewportSnapshot() {{
      if (!map || typeof map.getBounds !== 'function') return null;
      const mb = map.getBounds();
      if (!mb || typeof mb.isValid !== 'function' || !mb.isValid()) return null;
      const sDenom = computeMapScaleDenominator();
      const lod = targetLodForScale(sDenom);
      const zoomNow = typeof map.getZoom === 'function' ? Number(map.getZoom()) : 7;
      const w = Number(mb.getWest()), s = Number(mb.getSouth()), e = Number(mb.getEast()), n = Number(mb.getNorth());
      const zoomVis = {{}};
      if (typeof orderedMapLayerNames === 'function' && typeof isLayerVisibleAtZoom === 'function') {{
        orderedMapLayerNames().forEach(ln => {{
          zoomVis[ln] = isLayerVisibleAtZoom(ln, zoomNow, sDenom);
        }});
      }}
      return {{
        lod,
        zoom: zoomNow,
        scale: sDenom,
        zoomVis,
        bbox: [w, s, e, n],
        cLon: (w + e) * 0.5,
        cLat: (s + n) * 0.5,
        spanLon: Math.max(1e-6, Math.abs(e - w)),
        spanLat: Math.max(1e-6, Math.abs(n - s)),
      }};
    }}

    function _allVisibleLayersSelfManagedAtLod(lod, scaleDenom) {{
      if (EXTENT_FILTER_ENABLED || Object.keys(ACTIVE_FILTERS).length > 0) return false;
      const visible = orderedMapLayerNames().filter(ln => MAP_LAYER_VISIBILITY[ln] !== false);
      if (!visible.length) return false;
      return visible.every(ln => {{
        const st = LAYER_STATS[ln] || {{}};
        const rows = LAYER_RECORDS[ln] || [];
        const isLarge = rows.length > 2500 || Number(st.feature_count || 0) > 2500;
        if (!isLarge) return false;
        const vp = VECTOR_PYRAMIDS[ln];
        const hasLod0 = Boolean(vp && vp.lod0 && Array.isArray(vp.lod0.features) && vp.lod0.features.length > 0);
        if (lod === 0 && hasLod0) return true;
        if (
          HAS_PREVIEW_API
          && st.has_qgis_layer === true
          && typeof L !== 'undefined'
          && L.tileLayer
          && typeof L.tileLayer.wms === 'function'
          && lod >= 1
          && scaleDenom > 55000
          && (scaleDenom <= 750000 || !hasLod0)
        ) {{
          return true;
        }}
        return false;
      }});
    }}

    function shouldSkipMinorViewportRefresh() {{
      const cur = _currentViewportSnapshot();
      const prev = LAST_RENDER_VIEWPORT;
      if (!cur || !prev) return false;
      if (cur.lod !== prev.lod) return false;
      if (Math.floor(cur.zoom) !== Math.floor(prev.zoom)) return false;
      if (cur.zoomVis && prev.zoomVis) {{
        for (const ln of Object.keys(cur.zoomVis)) {{
          if (cur.zoomVis[ln] !== prev.zoomVis[ln]) return false;
        }}
      }}
      if (_allVisibleLayersSelfManagedAtLod(cur.lod, cur.scale)) return true;
      const dLon = Math.abs(cur.cLon - prev.cLon) / Math.max(cur.spanLon, prev.spanLon);
      const dLat = Math.abs(cur.cLat - prev.cLat) / Math.max(cur.spanLat, prev.spanLat);
      if (cur.lod >= 3) {{
        return Math.abs(cur.zoom - prev.zoom) <= 0.35 && dLon < 0.10 && dLat < 0.10;
      }}
      if (Math.abs(cur.zoom - prev.zoom) > 0.85) return false;
      return dLon < 0.26 && dLat < 0.26;
    }}

    function scheduleMapRefreshOnViewport() {{
      if (VIEWPORT_REFRESH_TIMER) clearTimeout(VIEWPORT_REFRESH_TIMER);
      VIEWPORT_REFRESH_TIMER = setTimeout(() => {{
        VIEWPORT_REFRESH_TIMER = null;
        if (IS_MAP_INTERACTING) return;
        scheduleMapRender({{ skipAutoZoom: true }});
      }}, VIEWPORT_REFRESH_DEBOUNCE_MS);
    }}

    function scheduleExtentFilterRefresh() {{
      if (EXTENT_REFRESH_TIMER) clearTimeout(EXTENT_REFRESH_TIMER);
      EXTENT_REFRESH_TIMER = setTimeout(() => {{
        EXTENT_REFRESH_TIMER = null;
        if (IS_MAP_INTERACTING) return;
        renderAll({{ skipAutoZoom: true }});
      }}, EXTENT_REFRESH_DEBOUNCE_MS);
    }}

    async function unpackLod1Pyramid(layerName) {{
      if (LAYER_PYRAMID_LOD1[layerName]) return LAYER_PYRAMID_LOD1[layerName];
      if (LOD1_UNPACKING[layerName]) return LOD1_UNPACKING[layerName];
      const vp = VECTOR_PYRAMIDS[layerName];
      const lod1 = vp && vp.lod1;
      if (!lod1 || !lod1.data_b64) return null;

      LOD1_UNPACKING[layerName] = (async () => {{
        try {{
          if (typeof DecompressionStream === 'undefined') return null;
          const bytes = await _b64ToUint8ArrayAsync(lod1.data_b64);
          const ds = new DecompressionStream('gzip');
          const stream = new Blob([bytes]).stream().pipeThrough(ds);
          const jsonText = await new Response(stream).text();
          const packed = JSON.parse(jsonText);
          LAYER_PYRAMID_LOD1[layerName] = packed;
          if (!LAYER_GEOM_TYPES[layerName] && packed) {{
            const firstKey = Object.keys(packed)[0];
            if (firstKey && packed[firstKey] && packed[firstKey][0]) {{
              LAYER_GEOM_TYPES[layerName] = PYRAMID_TYPE_MAP[packed[firstKey][0]] || '';
            }}
          }}
          return packed;
        }} catch (err) {{
          console.warn('LOD-1 pyramid decode error for', layerName, err);
          return null;
        }} finally {{
          delete LOD1_UNPACKING[layerName];
        }}
      }})();
      return LOD1_UNPACKING[layerName];
    }}

    function findLiveWfsService(layerName) {{
      if (!layerName) return null;
      return (BUNDLE.ogc_services || []).find(s => s && s.type === 'wfs' && s.name === layerName && s.geojson_url) || null;
    }}

    function _computeWfsFetchBbox(layerName, fids, viewBbox) {{
      if (Array.isArray(fids) && fids.length > 0 && Array.isArray(LAYER_RECORDS[layerName])) {{
        const fidSet = new Set(fids.map(String));
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        let hit = false;
        const recs = LAYER_RECORDS[layerName];
        for (let i = 0; i < recs.length; i++) {{
          const r = recs[i];
          if (!r || !fidSet.has(String(r._feature_id))) continue;
          const bb = Array.isArray(r._bbox) && r._bbox.length === 4 ? r._bbox.map(Number) : getFeatureBbox(layerName, String(r._feature_id));
          if (bb && bb.length === 4 && bb.every(Number.isFinite)) {{
            minX = Math.min(minX, bb[0]); minY = Math.min(minY, bb[1]);
            maxX = Math.max(maxX, bb[2]); maxY = Math.max(maxY, bb[3]);
            hit = true;
          }} else if (r._lon !== undefined && r._lat !== undefined) {{
            const x = Number(r._lon), y = Number(r._lat);
            if (Number.isFinite(x) && Number.isFinite(y)) {{
              minX = Math.min(minX, x); minY = Math.min(minY, y);
              maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
              hit = true;
            }}
          }}
        }}
        if (hit) {{
          const spanX = maxX - minX, spanY = maxY - minY;
          if ((spanX <= 0.85 && spanY <= 0.85) || !Array.isArray(viewBbox) || viewBbox.length !== 4) {{
            return [minX - 0.004, minY - 0.004, maxX + 0.004, maxY + 0.004];
          }}
        }}
      }}
      return (Array.isArray(viewBbox) && viewBbox.length === 4) ? viewBbox : null;
    }}

    function _buildWfsBboxUrl(wfsSvc, bboxWgs84, maxFeatures) {{
      if (!wfsSvc || !wfsSvc.geojson_url) return '';
      const rawUrl = String(wfsSvc.geojson_url);
      const isAbs = /^https?:/i.test(rawUrl);
      const parsed = new URL(rawUrl, isAbs ? undefined : 'https://placeholder.local');
      if (parsed.searchParams.has('version') && String(parsed.searchParams.get('version')).startsWith('1.')) {{
        parsed.searchParams.set('maxFeatures', String(maxFeatures || 2500));
      }} else {{
        parsed.searchParams.set('count', String(maxFeatures || 2500));
      }}
      parsed.searchParams.set('srsName', 'EPSG:4326');
      parsed.searchParams.set('outputFormat', 'application/json');
      if (Array.isArray(bboxWgs84) && bboxWgs84.length === 4) {{
        const w = bboxWgs84[0].toFixed(5), s = bboxWgs84[1].toFixed(5);
        const e = bboxWgs84[2].toFixed(5), n = bboxWgs84[3].toFixed(5);
        parsed.searchParams.set('bbox', `${{s}},${{w}},${{n}},${{e}},urn:ogc:def:crs:EPSG::4326`);
      }}
      return isAbs ? parsed.toString() : (parsed.pathname + parsed.search + parsed.hash);
    }}

    async function requestMissingFeatures(layerName, opts) {{
      const options = opts || {{}};
      const reqLod = Number.isFinite(options.lod) ? Number(options.lod) : 2;
      const scaleDenom = Number.isFinite(options.scale) ? Math.round(options.scale) : 120000;
      const vp = VECTOR_PYRAMIDS[layerName];
      if (vp && vp.lod1 && vp.lod1.data_b64 && !LAYER_PYRAMID_LOD1[layerName]) {{
        beginMapRenderLoader(t('map_rendering_layers'));
        try {{
          const unpacked = await unpackLod1Pyramid(layerName);
          if (unpacked && typeof renderMapFeatures === 'function') {{
            if (typeof _clearCrossLayerCaches === 'function') _clearCrossLayerCaches();
            renderMapFeatures({{
              skipAutoZoom: Boolean(options.skipAutoZoom),
              forceZoom: Boolean(options.forceZoom),
              fromAsyncFetch: true
            }});
            if (typeof renderWidgetsOnly === 'function') renderWidgetsOnly();
          }}
        }} finally {{
          endMapRenderLoader(false);
        }}
      }}
      const wfsSvc = HAS_PREVIEW_API ? null : findLiveWfsService(layerName);
      if (!HAS_PREVIEW_API && !wfsSvc) return;
      if (!HAS_PREVIEW_API && (IS_WFS_REFRESHING || ACTIVE_WFS_SERVICE_FETCH[layerName])) {{
        devLog('INFO', 'WFS', `Skipped viewport BBOX fetch for ${{layerName}} while full refresh is in flight.`);
        return;
      }}
      if (!HAS_PREVIEW_API && typeof isWfsServicePinnedStatic === 'function' && isWfsServicePinnedStatic(wfsSvc)) {{
        return;
      }}

      const fids = Array.isArray(options.fids) ? options.fids.map(String).filter(Boolean) : [];
      const bbox = Array.isArray(options.bbox) ? options.bbox : null;
      const hasCompactViewBbox = Boolean(
        !HAS_PREVIEW_API
        && reqLod >= 3
        && bbox
        && bbox.length === 4
        && (Number(bbox[2]) - Number(bbox[0])) <= 0.85
        && (Number(bbox[3]) - Number(bbox[1])) <= 0.85
      );
      const fetchBbox = HAS_PREVIEW_API
        ? bbox
        : (hasCompactViewBbox ? bbox : _computeWfsFetchBbox(layerName, fids, bbox));
      if (!HAS_PREVIEW_API && !fetchBbox) return;
      const zoom = Number.isFinite(options.zoom) ? Math.round(options.zoom) : 12;

      const fidKeyPart = fids.length
        ? `fids:${{fids.length}}:${{_hashFidList(fids)}}`
        : '';
      const keyBbox = fetchBbox || bbox;
      const bboxKeyPart = (keyBbox && keyBbox.length === 4)
        ? `bbox:${{keyBbox.map(v => Number(v).toFixed(3)).join(',')}}|z${{zoom}}`
        : '';
      const key = (fidKeyPart || bboxKeyPart)
        ? `${{layerName}}|${{[fidKeyPart, bboxKeyPart].filter(Boolean).join('|')}}|lod${{reqLod}}`
        : '';
      const nowMs = Date.now();
      if (
        !key
        || FEATURE_FETCH_INFLIGHT[key]
        || LAYER_LAST_MISSING_KEY[layerName] === key
        || (LAYER_FETCH_COOLDOWN[key] && nowMs < LAYER_FETCH_COOLDOWN[key])
      ) return;
      FEATURE_FETCH_INFLIGHT[key] = true;

      beginMapRenderLoader(t('map_rendering_layers'));
      try {{
        if (FETCH_ABORT_CONTROLLERS[layerName]) {{
          try {{ FETCH_ABORT_CONTROLLERS[layerName].abort(); }} catch (_ab) {{}}
        }}
        const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        if (controller) FETCH_ABORT_CONTROLLERS[layerName] = controller;
        let fetchUrl = '';
        const fetchOpts = {{}};
        if (controller) fetchOpts.signal = controller.signal;
        if (HAS_PREVIEW_API) {{
          const params = new URLSearchParams();
          params.set('layer', layerName);
          params.set('zoom', String(zoom));
          params.set('lod', String(reqLod));
          params.set('scale', String(scaleDenom));
          params.set('max', '4500');
          if (fids.length) {{
            params.set('fids', fids.slice(0, 1200).join(','));
          }}
          if (bbox && bbox.length === 4) {{
            params.set('bbox', bbox.map(v => Number(v).toFixed(5)).join(','));
          }}
          fetchUrl = '/api/features?' + params.toString();
        }} else {{
          fetchUrl = _buildWfsBboxUrl(wfsSvc, fetchBbox, reqLod >= 3 ? 5000 : 2500);
          fetchOpts.headers = {{ 'Accept': 'application/json' }};
          if (wfsSvc.with_credentials) fetchOpts.credentials = 'include';
        }}
        const resp = await fetch(fetchUrl, fetchOpts);
        if (!resp.ok) {{
          LAYER_FETCH_COOLDOWN[key] = Date.now() + 1500;
          return;
        }}
        const fc = await resp.json();
        if (fc && Array.isArray(fc.features) && fc.features.length > 0) {{
          LAYER_LAST_MISSING_KEY[layerName] = key;
          delete LAYER_FETCH_COOLDOWN[key];
          const hadRows = Array.isArray(LAYER_RECORDS[layerName]) && LAYER_RECORDS[layerName].length > 0;
          ingestGeoJsonFeatures(layerName, fc.features, {{
            mergeExisting: true,
            matchExistingOnly: (!HAS_PREVIEW_API && hadRows),
            lod: reqLod
          }});
          if (reqLod >= 3 && typeof LAYER_COMPLETENESS !== 'undefined') delete LAYER_COMPLETENESS[layerName];
          if (typeof _clearCrossLayerCaches === 'function') _clearCrossLayerCaches();
          if (typeof renderMapFeatures === 'function') {{
            renderMapFeatures({{
              skipAutoZoom: Boolean(options.skipAutoZoom),
              forceZoom: Boolean(options.forceZoom),
              fromAsyncFetch: true
            }});
          }}
          if (typeof renderWidgetsOnly === 'function') {{
            renderWidgetsOnly();
          }}
        }} else {{
          LAYER_FETCH_COOLDOWN[key] = Date.now() + 1500;
        }}
      }} catch (err) {{
        LAYER_FETCH_COOLDOWN[key] = Date.now() + 1200;
        if (!err || err.name !== 'AbortError') {{
          console.warn('Feature request failed for', layerName, err);
        }}
      }} finally {{
        delete FEATURE_FETCH_INFLIGHT[key];
        endMapRenderLoader(false);
      }}
    }}
    const EELIS_CATALOG = [
      {{ name: 'eelis:kr_kaitseala', title: 'KKR Kaitsealad (rahvuspargid, loodus- ja maastikukaitsealad)' }},
      {{ name: 'eelis:natura_elupaik', title: 'Natura 2000 elupaigad' }},
      {{ name: 'eelis:plk', title: 'EELIS Poollooduslikud kooslused (pärandniidud)' }},
      {{ name: 'eelis:kr_loodusala', title: 'Natura 2000 loodusalad' }},
      {{ name: 'eelis:kr_linnuala', title: 'Natura 2000 linnualad' }},
      {{ name: 'eelis:kr_hoiuala', title: 'Hoiualad' }},
      {{ name: 'eelis:kr_hooldatav_skv', title: 'Püsielupaigad (hooldatavad)' }},
      {{ name: 'eelis:kr_voorliik', title: 'Võõrliikide leiukohad' }},
      {{ name: 'eelis:kr_vep', title: 'Vääriselupaigad (VEP)' }}
    ];
    let LANG = (DASHBOARD.language && String(DASHBOARD.language).toLowerCase().startsWith('en')) ? 'en' : 'et';
    let CURR_LANG = LANG;
    let LIVE_STATUS_STATE = {{ key: 'html_live_ready', vars: {{}} }};
    let EELIS_CAPS_LOADED = false;
    let EELIS_CAPS_COUNT = EELIS_CATALOG.length;
    let EXTENT_FILTER_ENABLED = Boolean(DASHBOARD.filter_by_map_extent);
    const MAP_LAYER_VISIBILITY = {{}};
    let CUSTOM_MAP_LAYERS = null;
    let map = null;
    let layerControl = null;
    let legendControl = null;

    function t(key, vars) {{
      const table = I18N[LANG] || I18N.et || {{}};
      let tpl = table[key] || (I18N.en && I18N.en[key]) || key;
      if (vars) {{
        Object.entries(vars).forEach(([k, v]) => {{
          tpl = tpl.replaceAll('{{' + k + '}}', String(v));
        }});
      }}
      return tpl;
    }}

    function localizedTitle(item) {{
      if (!item) return '';
      return (LANG === 'en' && item.title_en) ? item.title_en : (item.title || '');
    }}

    const LAYER_LIVE_INFO = {{}};
    let AUTO_REFRESH_TIMER = null;
    const EXPORTED_AT_STAMP = String((typeof BUNDLE !== 'undefined' && BUNDLE && BUNDLE.exported_at) ? BUNDLE.exported_at : '');
    let LIVE_SESSION_STAMP = EXPORTED_AT_STAMP;
    let HAS_LIVE_REFRESHED = false;
    let IS_WFS_REFRESHING = false;
    const ACTIVE_WFS_SERVICE_FETCH = {{}};
    let WFS_REFRESH_ABORT_CONTROLLER = null;
    const UNLOCKED_STATIC_WFS = new Set();
    const DEV_LOG_ENTRIES = [];
    let DEV_LOG_OPEN = false;

    function devLog(level, category, message, detail) {{
      try {{
        const ts = _formatLiveTimeStamp(new Date()).split(' ').pop() || '';
        const line = {{
          ts,
          level: String(level || 'INFO').toUpperCase(),
          category: String(category || 'APP').toUpperCase(),
          message: String(message || ''),
          detail: detail ? String(detail) : ''
        }};
        DEV_LOG_ENTRIES.push(line);
        if (DEV_LOG_ENTRIES.length > 250) DEV_LOG_ENTRIES.shift();
        if (DEV_LOG_OPEN) renderDevLogDrawer();
      }} catch (_logErr) {{}}
    }}

    function _syncDevLogCancelBtn() {{
      const btn = document.getElementById('btn-dev-cancel-wfs');
      if (btn && btn.style) {{
        btn.style.display = IS_WFS_REFRESHING ? 'inline-flex' : 'none';
      }}
    }}

    function renderDevLogDrawer() {{
      const body = document.getElementById('dev-log-body');
      const ttl = document.getElementById('dev-log-title');
      if (ttl) ttl.textContent = t('dev_log_title');
      const btnCopy = document.getElementById('btn-dev-copy');
      if (btnCopy) btnCopy.textContent = t('dev_log_copy');
      const btnClr = document.getElementById('btn-dev-clear');
      if (btnClr) btnClr.textContent = t('dev_log_clear');
      const btnCan = document.getElementById('btn-dev-cancel-wfs');
      if (btnCan) btnCan.textContent = t('dev_log_cancel_refresh');
      _syncDevLogCancelBtn();
      if (!body) return;
      if (!DEV_LOG_ENTRIES.length) {{
        body.innerHTML = `<div style="opacity:0.65;padding:6px 0;">${{escapeHtml(t('dev_log_empty'))}}</div>`;
        return;
      }}
      body.innerHTML = DEV_LOG_ENTRIES.slice(-160).map(it => {{
        const cls = it.level === 'ERROR'
          ? 'dev-log-line dev-log-err'
          : (it.level === 'WARN' ? 'dev-log-line dev-log-warn' : (it.level === 'NET' ? 'dev-log-line dev-log-net' : 'dev-log-line'));
        const det = it.detail ? ` <span style="opacity:0.75;">${{escapeHtml(it.detail)}}</span>` : '';
        return `<div class="${{cls}}">[${{escapeHtml(it.ts)}}] <b>[${{escapeHtml(it.category)}}]</b> ${{escapeHtml(it.message)}}${{det}}</div>`;
      }}).join('');
      body.scrollTop = body.scrollHeight || 0;
    }}

    function toggleDevLogDrawer(forceState) {{
      DEV_LOG_OPEN = (typeof forceState === 'boolean') ? forceState : !DEV_LOG_OPEN;
      const drawer = document.getElementById('dev-log-drawer');
      if (drawer && drawer.style) {{
        drawer.style.display = DEV_LOG_OPEN ? 'flex' : 'none';
      }}
      if (DEV_LOG_OPEN) renderDevLogDrawer();
    }}

    function clearDevLog() {{
      DEV_LOG_ENTRIES.length = 0;
      renderDevLogDrawer();
    }}

    function copyDevLog() {{
      const txt = DEV_LOG_ENTRIES.map(it => `[${{it.ts}}] [${{it.level}}/${{it.category}}] ${{it.message}}${{it.detail ? ' | ' + it.detail : ''}}`).join('\\n');
      if (typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {{
        navigator.clipboard.writeText(txt).catch(() => {{}});
      }}
      const btn = document.getElementById('btn-dev-copy');
      if (btn) {{
        btn.textContent = t('dev_log_copied');
        setTimeout(() => {{ if (btn) btn.textContent = t('dev_log_copy'); }}, 1400);
      }}
    }}

    function cancelActiveWfsRefresh() {{
      if (WFS_REFRESH_ABORT_CONTROLLER && typeof WFS_REFRESH_ABORT_CONTROLLER.abort === 'function') {{
        devLog('WARN', 'WFS', 'User cancelled active WFS refresh.');
        try {{ WFS_REFRESH_ABORT_CONTROLLER.abort(); }} catch (_abErr) {{}}
      }}
    }}

    function _getDataSourceMeta(layerName) {{
      const ds = (DASHBOARD.data_sources || []).find(d => d && d.name === layerName);
      const ogc = (BUNDLE.ogc_services || []).find(s => s && s.name === layerName);
      return {{ ds, ogc }};
    }}

    function isWfsServicePinnedStatic(svcOrName) {{
      const name = typeof svcOrName === 'string' ? svcOrName : (svcOrName && svcOrName.name ? String(svcOrName.name) : '');
      if (!name || UNLOCKED_STATIC_WFS.has(name)) return false;
      const {{ ds, ogc }} = _getDataSourceMeta(name);
      const cand = typeof svcOrName === 'object' ? svcOrName : null;
      const pinned = Boolean((cand && cand.designer_pinned_static) || (ogc && ogc.designer_pinned_static) || (ds && ds.designer_pinned_static));
      const eff = String((cand && cand.effective_state) || (ogc && ogc.effective_state) || (ds && ds.effective_state) || '').toLowerCase();
      return pinned || (eff === 'static' && Boolean((cand && cand.geojson_url) || (ogc && ogc.geojson_url)));
    }}

    const LAYER_REFRESHING = new Set();

    function _allStatusLayerNames() {{
      const names = [];
      const add = ln => {{
        const s = String(ln || '').trim();
        if (s && s !== '*' && !names.includes(s)) names.push(s);
      }};
      (DASHBOARD.data_sources || []).forEach(d => {{
        if (d && d.name && !d.is_basemap) add(d.name);
      }});
      (BUNDLE.ogc_services || []).forEach(s => {{
        if (s && s.type === 'wfs' && s.name) add(s.name);
      }});
      Object.keys(LAYER_RECORDS).forEach(add);
      Object.keys(LAYER_LIVE_INFO || {{}}).forEach(add);
      return names;
    }}

    function isLayerRefreshableLive(layerName) {{
      const ln = String(layerName || '').trim();
      if (!ln) return false;
      const {{ ds, ogc }} = _getDataSourceMeta(ln);
      const isWfs = Boolean(ogc && ogc.type === 'wfs' && ogc.geojson_url);
      if (isWfs) return !isWfsServicePinnedStatic(ogc || ln);
      return Boolean(
        ds && ds.sharepoint_web_url && /^https?:/i.test(String(ds.sharepoint_web_url))
        && String(ds.effective_state || 'live').toLowerCase() === 'live'
      );
    }}

    function getLayerPagesMap() {{
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      const firstPid = (pages[0] && pages[0].id) ? String(pages[0].id) : 'page_1';
      const byLayer = {{}};
      const addRef = (ln, pid) => {{
        const s = String(ln || '').trim();
        if (!s || s === '*') return;
        if (!byLayer[s]) byLayer[s] = new Set();
        byLayer[s].add(String(pid || firstPid));
      }};
      const allKnown = _allStatusLayerNames();
      const scanExpr = (txt, pid) => {{
        const s = String(txt || '');
        if (!s) return;
        allKnown.forEach(kn => {{
          if (kn && (s.includes(`"${{kn}}"`) || s.includes(`'${{kn}}'`) || s.includes(`(${{kn}}`))) {{
            addRef(kn, pid);
          }}
        }});
      }};
      const activeId = String(ACTIVE_PAGE_ID || firstPid);
      if (typeof orderedMapLayerNames === 'function') {{
        (orderedMapLayerNames() || []).forEach(ln => addRef(ln, activeId));
      }}
      (DASHBOARD.widgets || []).forEach(w => {{
        if (!w) return;
        const pid = String(w.page_id || firstPid);
        addRef(w.layer_name, pid);
        addRef(w.spatial_join_layer, pid);
        if (Array.isArray(w.map_layers)) {{
          w.map_layers.forEach(ml => addRef(ml, pid));
        }}
        if (w.expression) scanExpr(w.expression, pid);
        if (w.expression_subtext) scanExpr(w.expression_subtext, pid);
        if (Array.isArray(w.expression_blocks)) {{
          w.expression_blocks.forEach(b => scanExpr(JSON.stringify(b || ''), pid));
        }}
      }});
      (DASHBOARD.slicers || []).forEach(sl => {{
        if (!sl || !sl.layer_name || sl.layer_name === '*') return;
        addRef(sl.layer_name, String(sl.page_id || firstPid));
      }});
      const dsById = {{}};
      (DASHBOARD.data_sources || []).forEach(d => {{ if (d && d.id && d.name) dsById[d.id] = d.name; }});
      (DASHBOARD.joins || []).forEach(j => {{
        if (!j) return;
        const srcNm = dsById[j.source_table_id] || j.source_table_id || '';
        const tgtNm = dsById[j.target_layer_id] || j.target_layer_id || '';
        const pSet = new Set([...(byLayer[srcNm] || []), ...(byLayer[tgtNm] || [])]);
        pSet.forEach(pid => {{
          if (srcNm) addRef(srcNm, pid);
          if (tgtNm) addRef(tgtNm, pid);
        }});
      }});
      return byLayer;
    }}

    function getPageLayerNames(pageId) {{
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      if (pages.length <= 1) return _allStatusLayerNames();
      const pid = String(pageId || ACTIVE_PAGE_ID || (pages[0] && pages[0].id) || 'page_1');
      const byLayer = getLayerPagesMap();
      const allNames = _allStatusLayerNames();
      return allNames.filter(ln => byLayer[ln] && byLayer[ln].has(pid));
    }}

    function getRefreshableLayersForPage(pageId) {{
      return getPageLayerNames(pageId).filter(ln => isLayerRefreshableLive(ln));
    }}

    function _getPageDisplayTitle(pg) {{
      if (!pg) return '';
      return (CURR_LANG === 'en' && pg.title_en) ? pg.title_en : (pg.title || pg.id || '');
    }}

    function closeRefreshScopeMenu() {{
      const menu = document.getElementById('refresh-scope-menu');
      if (menu && menu.style) menu.style.display = 'none';
    }}

    function renderRefreshScopeMenu() {{
      const menu = document.getElementById('refresh-scope-menu');
      if (!menu) return;
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      if (pages.length <= 1) {{
        closeRefreshScopeMenu();
        return;
      }}
      const activeId = String(ACTIVE_PAGE_ID || (pages[0] && pages[0].id) || 'page_1');
      const ordered = pages.filter(p => p && p.id === activeId).concat(pages.filter(p => p && p.id !== activeId));
      const parts = ordered.map(pg => {{
        const liveList = getRefreshableLayersForPage(pg.id);
        const liveCnt = liveList.length;
        const isAct = pg.id === activeId;
        const pgTitle = escapeHtml(_getPageDisplayTitle(pg));
        const cntMeta = liveCnt === 0
          ? escapeHtml(t('refresh_menu_page_static'))
          : escapeHtml(liveCnt === 1 ? t('refresh_menu_page_layer_one') : t('refresh_menu_page_layers', {{ n: liveCnt }}));
        const actTag = isAct ? ` <span class="live-status-page-tag">${{escapeHtml(t('refresh_menu_current_badge'))}}</span>` : '';
        const jsonPid = JSON.stringify(String(pg.id)).replace(/"/g, '&quot;');
        return `<button type="button" class="refresh-scope-item${{isAct ? ' is-active-page' : ''}}" data-refresh-page="${{escapeHtml(pg.id)}}" onclick="refreshDashboardPageData(${{jsonPid}})"${{(liveCnt === 0 || IS_WFS_REFRESHING) ? ' disabled="disabled"' : ''}}><span>↻ ${{pgTitle}}${{actTag}}</span><span class="refresh-scope-meta">${{cntMeta}}</span></button>`;
      }});
      const allLiveCnt = _allStatusLayerNames().filter(ln => isLayerRefreshableLive(ln)).length;
      const allLbl = allLiveCnt > 0
        ? t('refresh_menu_all_pages_count', {{ n: allLiveCnt }})
        : t('refresh_menu_all_pages');
      parts.push('<div class="refresh-scope-sep"></div>');
      parts.push(`<button type="button" class="refresh-scope-item" data-refresh-page="__all__" onclick="refreshDashboardPageData(null)"${{(allLiveCnt === 0 || IS_WFS_REFRESHING) ? ' disabled="disabled"' : ''}}><span>↻ ${{escapeHtml(allLbl)}}</span><span class="refresh-scope-meta"></span></button>`);
      menu.innerHTML = parts.join('');
    }}

    function onRefreshLiveButtonClick(ev) {{
      if (ev && ev.stopPropagation) ev.stopPropagation();
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      if (pages.length <= 1) {{
        closeRefreshScopeMenu();
        refreshLiveWfs({{ force: true, forceFull: true }});
        return;
      }}
      const menu = document.getElementById('refresh-scope-menu');
      if (!menu || !menu.style) {{
        refreshLiveWfs({{ force: true, forceFull: true }});
        return;
      }}
      const willOpen = (menu.style.display === 'none' || !menu.style.display);
      if (!willOpen) {{
        closeRefreshScopeMenu();
        return;
      }}
      const statusMenu = document.getElementById('live-status-menu');
      if (statusMenu && statusMenu.style) statusMenu.style.display = 'none';
      menu.onclick = e => {{ if (e && e.stopPropagation) e.stopPropagation(); }};
      renderRefreshScopeMenu();
      const btn = document.getElementById('btn-refresh-live');
      if (btn && typeof btn.getBoundingClientRect === 'function') {{
        const r = btn.getBoundingClientRect();
        const winW = (typeof window !== 'undefined' && Number(window.innerWidth)) ? Number(window.innerWidth) : 1200;
        menu.style.top = `${{Math.max(8, Math.round(r.bottom + 6))}}px`;
        menu.style.left = `${{Math.max(8, Math.min(winW - 280, Math.round(r.left)))}}px`;
      }}
      menu.style.display = 'flex';
    }}

    function refreshDashboardPageData(pageId) {{
      closeRefreshScopeMenu();
      if (!pageId) {{
        return refreshLiveWfs({{ force: true, forceFull: true }});
      }}
      const liveLayers = getRefreshableLayersForPage(String(pageId));
      if (!liveLayers.length) return Promise.resolve(0);
      return refreshLiveWfs({{ force: true, forceFull: true, onlyLayers: liveLayers }});
    }}

    async function refreshSingleLayerFromStatus(layerName, ev) {{
      if (ev && ev.stopPropagation) ev.stopPropagation();
      const ln = String(layerName || '').trim();
      if (!ln) return 0;
      if (IS_WFS_REFRESHING || LAYER_REFRESHING.has(ln)) return 0;
      LAYER_REFRESHING.add(ln);
      renderLiveStatusMenu();
      try {{
        return await refreshLiveWfs({{ force: true, forceFull: true, onlyLayer: ln }});
      }} finally {{
        LAYER_REFRESHING.delete(ln);
        renderLiveStatusMenu();
        if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
      }}
    }}

    function toggleLiveStatusMenu(ev) {{
      if (ev && ev.stopPropagation) ev.stopPropagation();
      closeRefreshScopeMenu();
      const menu = document.getElementById('live-status-menu');
      if (!menu || !menu.style) return;
      const willOpen = (menu.style.display === 'none' || !menu.style.display);
      if (!willOpen) {{
        menu.style.display = 'none';
        return;
      }}
      menu.onclick = e => {{ if (e && e.stopPropagation) e.stopPropagation(); }};
      renderLiveStatusMenu();
      const pill = document.getElementById('live-status');
      if (pill && typeof pill.getBoundingClientRect === 'function') {{
        const r = pill.getBoundingClientRect();
        menu.style.top = `${{Math.max(8, Math.round(r.bottom + 6))}}px`;
        menu.style.left = `${{Math.max(8, Math.min((typeof window !== 'undefined' ? (window.innerWidth || 900) : 900) - 340, Math.round(r.left)))}}px`;
      }}
      menu.style.display = 'block';
    }}

    function unlockStaticWfsSource(layerName) {{
      const ln = String(layerName || '').trim();
      if (!ln) return;
      const msg = t('confirm_unlock_static_wfs', {{ name: ln, time: EXPORTED_AT_STAMP || '-' }});
      const ok = (typeof window !== 'undefined' && typeof window.confirm === 'function') ? window.confirm(msg) : true;
      if (!ok) return;
      UNLOCKED_STATIC_WFS.add(ln);
      devLog('INFO', 'SOURCE', `End-user unlocked designer-static WFS layer: ${{ln}}`);
      renderLiveStatusMenu();
      refreshLiveWfs({{ force: true, forceFull: true, onlyLayer: ln }});
    }}

    function _renderStatusLayerRow(ln, extraPageLabels) {{
      const {{ ds, ogc }} = _getDataSourceMeta(ln);
      const isWfs = Boolean(ogc && ogc.type === 'wfs' && ogc.geojson_url);
      const pinnedStaticWfs = isWfs && isWfsServicePinnedStatic(ln);
      const canRefresh = isLayerRefreshableLive(ln);
      const isRefreshingRow = LAYER_REFRESHING.has(ln);
      const effState = String((ogc && ogc.effective_state) || (ds && ds.effective_state) || (isWfs ? 'live' : 'static')).toLowerCase();
      const stInfo = LAYER_LIVE_INFO[ln] || {{}};
      const cnt = Array.isArray(LAYER_RECORDS[ln]) ? LAYER_RECORDS[ln].length : 0;
      let badgeText = t('status_source_static');
      let stampText = EXPORTED_AT_STAMP || '-';
      if (isRefreshingRow) {{
        badgeText = t('status_layer_refreshing');
        stampText = stInfo.refreshed_at || LIVE_SESSION_STAMP || EXPORTED_AT_STAMP || '-';
      }} else if (pinnedStaticWfs) {{
        badgeText = t('status_source_static_wfs');
      }} else if (isWfs || effState === 'live' || stInfo.status) {{
        if (stInfo.status === 'live_failed') {{
          badgeText = t('status_source_failed');
          stampText = stInfo.refreshed_at || LIVE_SESSION_STAMP || EXPORTED_AT_STAMP || '-';
        }} else if (stInfo.status === 'live_incomplete' || stInfo.countMismatch) {{
          badgeText = t('status_source_incomplete', {{ loaded: (stInfo.attemptedLoaded !== undefined ? stInfo.attemptedLoaded : (stInfo.loaded || cnt)), total: stInfo.totalFeatures || cnt }});
          stampText = stInfo.refreshed_at || LIVE_SESSION_STAMP || EXPORTED_AT_STAMP || '-';
        }} else if (stInfo.status === 'retained_snapshot') {{
          badgeText = t('status_source_retained_snapshot');
          stampText = EXPORTED_AT_STAMP || '-';
        }} else if (stInfo.status === 'live' || stInfo.status === 'live_partial' || stInfo.status === 'live_streamed') {{
          badgeText = t('status_source_live');
          stampText = stInfo.refreshed_at || LIVE_SESSION_STAMP || EXPORTED_AT_STAMP || '-';
        }} else {{
          badgeText = t('status_source_live_cached');
        }}
      }}
      const safeLn = escapeHtml(ln);
      const jsonLn = JSON.stringify(ln).replace(/"/g, '&quot;');
      const pgTags = (Array.isArray(extraPageLabels) && extraPageLabels.length)
        ? extraPageLabels.map(lbl => `<span class="live-status-page-tag">${{escapeHtml(lbl)}}</span>`).join('')
        : '';
      const unlockBtn = pinnedStaticWfs
        ? `<div><button type="button" class="btn-mini-icon" onclick="unlockStaticWfsSource(${{jsonLn}})">${{escapeHtml(t('btn_unlock_static_wfs'))}}</button></div>`
        : '';
      const refLayerBtn = canRefresh
        ? `<button type="button" class="btn-layer-refresh" data-refresh-layer="${{safeLn}}" onclick="refreshSingleLayerFromStatus(${{jsonLn}}, event)" title="${{escapeHtml(t('btn_refresh_single_layer_tip'))}}"${{(isRefreshingRow || IS_WFS_REFRESHING) ? ' disabled="disabled"' : ''}}>${{isRefreshingRow ? '⏳' : '↻'}}</button>`
        : '';
      return `<div class="live-status-row" data-status-layer="${{safeLn}}"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center;"><span style="min-width:0;overflow-wrap:anywhere;"><b>${{safeLn}}</b>${{pgTags}}</span><span style="display:flex;align-items:center;gap:6px;flex-shrink:0;"><span style="opacity:0.8;">${{cnt}}</span>${{refLayerBtn}}</span></div><div style="opacity:0.85;">${{escapeHtml(badgeText)}} · ${{escapeHtml(stampText)}}</div>${{unlockBtn}}</div>`;
    }}

    function renderLiveStatusMenu() {{
      const menu = document.getElementById('live-status-menu');
      if (!menu) return;
      const names = _allStatusLayerNames();
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      const isMultiPage = pages.length > 1;
      const activeId = String(ACTIVE_PAGE_ID || (pages[0] && pages[0].id) || 'page_1');
      const activePgObj = pages.find(p => p && p.id === activeId) || pages[0];
      const activePgTitle = _getPageDisplayTitle(activePgObj) || activeId;

      let html = `<div class="live-status-menu-hdr"><span>${{escapeHtml(t('status_menu_title'))}}</span><button type="button" class="btn-mini-icon" onclick="document.getElementById('live-status-menu').style.display='none'">✕</button></div>`;
      if (!names.length) {{
        html += `<div style="opacity:0.75;padding:4px 0;">—</div>`;
      }} else if (isMultiPage) {{
        const byLayer = getLayerPagesMap();
        const activeSet = new Set(getPageLayerNames(activeId));
        const activeRows = names.filter(ln => activeSet.has(ln));
        const otherRows = names.filter(ln => !activeSet.has(ln));
        const pgTitleMap = {{}};
        pages.forEach(p => {{ if (p && p.id) pgTitleMap[p.id] = _getPageDisplayTitle(p); }});
        html += `<div class="live-status-sec-hdr">${{escapeHtml(t('status_menu_active_page_hdr', {{ title: activePgTitle }}))}}</div>`;
        html += activeRows.length
          ? activeRows.map(ln => _renderStatusLayerRow(ln, [])).join('')
          : `<div style="opacity:0.72;padding:4px 0;">—</div>`;
        if (otherRows.length) {{
          html += `<div class="live-status-sec-hdr">${{escapeHtml(t('status_menu_other_pages_hdr'))}}</div>`;
          html += otherRows.map(ln => {{
            const pids = byLayer[ln] ? Array.from(byLayer[ln]) : [];
            const pLabels = pids.map(pid => pgTitleMap[pid] || pid);
            return _renderStatusLayerRow(ln, pLabels);
          }}).join('');
        }}
      }} else {{
        html += names.map(ln => _renderStatusLayerRow(ln, [])).join('');
      }}
      if (EXPORT_TIER !== 'minimal') {{
        html += `<div style="display:flex;justify-content:space-between;gap:6px;padding-top:8px;margin-top:4px;border-top:1px solid var(--border-color);"><button type="button" class="btn-mini-icon" onclick="toggleDevLogDrawer()">${{escapeHtml(t('dev_log_btn'))}}</button></div>`;
      }}
      menu.innerHTML = html;
    }}

    function _formatLiveTimeStamp(dt) {{
      const d = dt instanceof Date ? dt : new Date();
      const dd = String(d.getDate()).padStart(2, '0');
      const mo = String(d.getMonth() + 1).padStart(2, '0');
      const yy = d.getFullYear();
      const hh = String(d.getHours()).padStart(2, '0');
      const mm = String(d.getMinutes()).padStart(2, '0');
      const ss = String(d.getSeconds()).padStart(2, '0');
      return `${{dd}}.${{mo}}.${{yy}} ${{hh}}:${{mm}}:${{ss}}`;
    }}

    function _parseDisplayStampToDate(stampStr) {{
      const s = String(stampStr || '').trim();
      const m = /^(\\d{{2}})\\.(\\d{{2}})\\.(\\d{{4}})(?:\\s+(\\d{{2}}):(\\d{{2}})(?::(\\d{{2}}))?)?/.exec(s);
      if (m) {{
        const dd = Number(m[1]), mo = Number(m[2]) - 1, yy = Number(m[3]);
        const hh = Number(m[4] || 0), mi = Number(m[5] || 0), ss = Number(m[6] || 0);
        const dt = new Date(yy, mo, dd, hh, mi, ss);
        if (!isNaN(dt.getTime())) return dt;
      }}
      const iso = /^(\\d{{4}})-(\\d{{2}})-(\\d{{2}})/.exec(s);
      if (iso) {{
        const dt2 = new Date(s);
        if (!isNaN(dt2.getTime())) return dt2;
      }}
      return null;
    }}

    function _formatFilenameTimestamp(stampStr) {{
      const d = _parseDisplayStampToDate(stampStr) || new Date();
      const yy = d.getFullYear();
      const mo = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const hh = String(d.getHours()).padStart(2, '0');
      const mi = String(d.getMinutes()).padStart(2, '0');
      return `${{yy}}-${{mo}}-${{dd}}_${{hh}}-${{mi}}`;
    }}

    function _formatLiveStatusTooltip() {{
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      const activeId = String(ACTIVE_PAGE_ID || (pages[0] && pages[0].id) || 'page_1');
      const activePgObj = pages.find(p => p && p.id === activeId);
      const clickHint = t('html_status_click_hint');
      const base = clickHint + '\\n' + t('status_live_desc') + ' | ' + t('status_cached_desc');
      const pgLine = (pages.length > 1 && activePgObj)
        ? `\\n${{t('status_menu_active_page_hdr', {{ title: _getPageDisplayTitle(activePgObj) }})}}`
        : '';
      const pkgLine = EXPORTED_AT_STAMP ? `\\n${{t('status_packaged_at')}}: ${{EXPORTED_AT_STAMP}}` : '';
      const refLine = (HAS_LIVE_REFRESHED && LIVE_SESSION_STAMP) ? `\\nLive refreshed: ${{LIVE_SESSION_STAMP}}` : '';
      const stampLine = pgLine + pkgLine + refLine;
      const scopeLayers = (pages.length > 1) ? getPageLayerNames(activeId) : _allStatusLayerNames();
      const layerSet = new Set(scopeLayers);
      const entries = Object.entries(LAYER_LIVE_INFO || {{}}).filter(([ln]) => !layerSet.size || layerSet.has(ln));
      if (!entries.length) return base + stampLine;
      const lines = entries.map(([ln, info]) => {{
        const st = info || {{}};
        const cntTxt = st.totalFeatures
          ? `${{st.loaded || 0}}/${{st.totalFeatures}}`
          : `${{st.loaded || (LAYER_RECORDS[ln] ? LAYER_RECORDS[ln].length : 0)}}`;
        const tsTxt = st.refreshed_at ? ` · ${{st.refreshed_at}}` : '';
        return `- ${{ln}}: ${{cntTxt}} (${{st.label || st.status || 'cached'}}${{tsTxt}})`;
      }});
      return base + stampLine + '\\n' + lines.join('\\n');
    }}

    function computeActivePageLiveStatus() {{
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      const activeId = String(ACTIVE_PAGE_ID || (pages[0] && pages[0].id) || 'page_1');
      const activeLayers = (pages.length > 1) ? getPageLayerNames(activeId) : _allStatusLayerNames();
      const activeLive = activeLayers.filter(ln => isLayerRefreshableLive(ln));
      const anyActiveRefreshing = activeLayers.some(ln => LAYER_REFRESHING.has(ln)) || (IS_WFS_REFRESHING && !LAYER_REFRESHING.size);
      if (anyActiveRefreshing) {{
        const hadAll = activeLive.length > 0 && activeLive.every(ln => Array.isArray(LAYER_RECORDS[ln]) && LAYER_RECORDS[ln].length > 0);
        return {{
          key: hadAll ? 'html_wfs_checking' : 'html_loading_wfs',
          vars: {{}},
          stamp: ''
        }};
      }}
      if (!activeLive.length) {{
        return {{
          key: 'html_cached_snapshot',
          vars: {{}},
          stamp: EXPORTED_AT_STAMP || LIVE_SESSION_STAMP || ''
        }};
      }}
      let liveOk = 0;
      let partialCap = 0;
      let mismatchInfo = null;
      let failed = 0;
      let cached = 0;
      let latestStamp = '';
      let latestTs = 0;
      activeLive.forEach(ln => {{
        const st = LAYER_LIVE_INFO[ln] || {{}};
        const sCode = String(st.status || '').toLowerCase();
        if (st.countMismatch || sCode === 'live_incomplete') {{
          mismatchInfo = mismatchInfo || {{
            loaded: Number(st.attemptedLoaded !== undefined ? st.attemptedLoaded : (st.loaded || 0)),
            total: Number(st.totalFeatures || st.loaded || 0)
          }};
        }} else if (sCode === 'live' || sCode === 'live_streamed') {{
          liveOk++;
          const rs = String(st.refreshed_at || '');
          const dt = rs ? _parseDisplayStampToDate(rs) : null;
          const ms = dt ? dt.getTime() : 0;
          if (ms >= latestTs && rs) {{
            latestTs = ms;
            latestStamp = rs;
          }}
        }} else if (sCode === 'live_partial') {{
          partialCap++;
        }} else if (sCode === 'live_failed' || sCode === 'retained_snapshot' || Boolean(st.failed)) {{
          failed++;
        }} else {{
          cached++;
        }}
      }});
      if (mismatchInfo) {{
        return {{ key: 'html_wfs_incomplete', vars: mismatchInfo, stamp: latestStamp || LIVE_SESSION_STAMP || '' }};
      }}
      if (liveOk === activeLive.length) {{
        return {{
          key: 'html_wfs_connected',
          vars: {{ count: liveOk, total: activeLive.length }},
          stamp: latestStamp || LIVE_SESSION_STAMP || ''
        }};
      }}
      if (partialCap > 0 && liveOk === 0 && failed === 0 && cached === 0) {{
        const rawCapVal = Number(DASHBOARD.html_live_max_features || 0);
        return {{
          key: 'html_live_partial',
          vars: {{ count: 0, total: activeLive.length, cap: rawCapVal > 0 ? rawCapVal : 2500 }},
          stamp: latestStamp || LIVE_SESSION_STAMP || ''
        }};
      }}
      if (liveOk > 0 || (failed > 0 && cached > 0)) {{
        return {{
          key: 'html_status_partial_refresh',
          vars: {{ done: liveOk, total: activeLive.length }},
          stamp: ''
        }};
      }}
      if (failed === activeLive.length) {{
        return {{ key: 'html_wfs_failed', vars: {{}}, stamp: LIVE_SESSION_STAMP || '' }};
      }}
      return {{
        key: 'html_cached_snapshot',
        vars: {{}},
        stamp: EXPORTED_AT_STAMP || ''
      }};
    }}

    function syncLiveStatusPillFromState() {{
      const st = computeActivePageLiveStatus();
      setLiveStatus(st.key, Object.assign({{}}, st.vars || {{}}, {{ _stampOverride: st.stamp }}));
    }}

    function setLiveStatus(key, vars) {{
      const vObj = Object.assign({{}}, vars || {{}});
      const stampOverride = (vObj._stampOverride !== undefined) ? String(vObj._stampOverride || '') : null;
      delete vObj._stampOverride;
      LIVE_STATUS_STATE = {{ key, vars: vObj }};
      const isLiveOk = (key === 'html_wfs_connected');
      const isPartial = (key === 'html_status_partial_refresh');
      const isWarn = (key === 'html_wfs_incomplete' || key === 'html_live_partial');
      const isError = (key === 'html_wfs_failed');
      const showStamp = (isLiveOk || isWarn || isError || key === 'html_cached_snapshot');
      const el = document.getElementById('live-status');
      if (el) {{
        const hasLiveWfs = _allStatusLayerNames().some(ln => isLayerRefreshableLive(ln));
        const isPackagedInit = (
          key === 'html_cached_snapshot'
          && Boolean(EXPORTED_AT_STAMP)
          && (stampOverride === null ? (!HAS_LIVE_REFRESHED && (!DASHBOARD || DASHBOARD.package_layers_in_export !== false || !hasLiveWfs)) : (stampOverride === EXPORTED_AT_STAMP))
        );
        const baseText = isPackagedInit ? t('html_packaged_snapshot') : t(key, vObj);
        const activeStamp = (stampOverride !== null)
          ? stampOverride
          : ((key === 'html_cached_snapshot' && !HAS_LIVE_REFRESHED && EXPORTED_AT_STAMP) ? EXPORTED_AT_STAMP : LIVE_SESSION_STAMP);
        const labelWithStamp = (showStamp && activeStamp) ? `${{baseText}} · ${{activeStamp}}` : baseText;
        el.textContent = labelWithStamp + ' ▾';
        if (el.classList) {{
          el.classList.remove('status-pill-live', 'status-pill-cached', 'status-pill-checking', 'status-pill-warn', 'status-pill-error', 'status-pill-partial');
          if (isLiveOk) {{
            el.classList.add('status-pill-live');
          }} else if (isPartial) {{
            el.classList.add('status-pill-partial');
          }} else if (isWarn) {{
            el.classList.add('status-pill-warn');
          }} else if (isError) {{
            el.classList.add('status-pill-error');
          }} else if (key === 'html_cached_snapshot') {{
            el.classList.add('status-pill-cached');
          }} else {{
            el.classList.add('status-pill-checking');
          }}
        }}
        el.title = _formatLiveStatusTooltip();
      }}
      const refBtn = document.getElementById('btn-refresh-live');
      if (refBtn) {{
        const hasRefreshable = (BUNDLE.ogc_services || []).some(s => s.type === 'wfs' && s.geojson_url)
          || (DASHBOARD.data_sources || []).some(d => d && d.sharepoint_web_url && /^https?:/i.test(String(d.sharepoint_web_url)));
        refBtn.style.display = hasRefreshable ? 'inline-flex' : 'none';
        refBtn.disabled = Boolean(IS_WFS_REFRESHING);
        refBtn.style.opacity = IS_WFS_REFRESHING ? '0.65' : '';
        const hasMultiPg = Array.isArray(DASHBOARD.pages) && DASHBOARD.pages.length > 1;
        const baseRefTxt = t('html_refresh_live_btn');
        refBtn.textContent = (hasMultiPg && !baseRefTxt.endsWith('▾')) ? `${{baseRefTxt}} ▾` : baseRefTxt;
        refBtn.title = t('html_refresh_live_tip');
      }}
      const devBtn = document.getElementById('btn-dev-log');
      if (devBtn) devBtn.textContent = t('dev_log_btn');
      _syncDevLogCancelBtn();
      const menuEl = document.getElementById('live-status-menu');
      if (menuEl && menuEl.style && menuEl.style.display === 'block') {{
        renderLiveStatusMenu();
      }}
      const refMenuEl = document.getElementById('refresh-scope-menu');
      if (refMenuEl && refMenuEl.style && refMenuEl.style.display !== 'none') {{
        renderRefreshScopeMenu();
      }}
    }}

    const CATEGORY_PALETTE = ['#10b981', '#38bdf8', '#f59e0b', '#a855f7', '#ef4444', '#14b8a6', '#ec4899', '#6366f1'];

    function hashCategoryColor(val) {{
      const s = String(val ?? '');
      let h = 0;
      for (let i = 0; i < s.length; i++) h = ((h * 31) + s.charCodeAt(i)) >>> 0;
      return CATEGORY_PALETTE[h % CATEGORY_PALETTE.length];
    }}

    const LOCAL_LAYER_STYLES = {{}};

    function getMapLayerStyleCfg(layerName) {{
      let mapWidget = getActiveMapWidget();
      let styles = (mapWidget && mapWidget.map_layer_styles) || null;
      if (!styles || !styles[layerName]) {{
        const fallbackMw = (DASHBOARD.widgets || []).find(w => w && w.widget_type === 'map' && w.map_layer_styles && w.map_layer_styles[layerName]);
        if (fallbackMw) styles = fallbackMw.map_layer_styles;
      }}
      const base = (styles && styles[layerName]) || null;
      const loc = LOCAL_LAYER_STYLES[layerName] || null;
      if (!base && !loc) return null;
      return Object.assign({{}}, base || {{}}, loc || {{}});
    }}

    function deriveGeoServerWmsUrl(wfsUrl) {{
      if (!wfsUrl || typeof wfsUrl !== 'string') return '';
      if (/\\/wfs(\\?|$)/i.test(wfsUrl)) return wfsUrl.replace(/\\/wfs(\\?|$)/i, '/wms$1');
      if (/\\/ows(\\?|$)/i.test(wfsUrl)) return wfsUrl;
      return '';
    }}

    function ensureLayerPane(layerName, idx, totalCount) {{
      if (!map || typeof map.createPane !== 'function') return undefined;
      const paneName = 'qdash_lyr_' + Math.max(0, Number(idx || 0));
      let pane = (typeof map.getPane === 'function') ? map.getPane(paneName) : null;
      if (!pane) {{
        pane = map.createPane(paneName);
      }}
      if (pane && pane.style) {{
        const total = Math.max(1, Number(totalCount || 1));
        const revRank = Math.max(0, total - 1 - Math.max(0, Number(idx || 0)));
        const z = total <= 1 ? 450 : (405 + Math.round((revRank / (total - 1)) * 85));
        pane.style.zIndex = String(z);
      }}
      return paneName;
    }}

    function getLayerCanvasRenderer(layerName, paneName) {{
      if (typeof L === 'undefined' || typeof L.canvas !== 'function') return vectorCanvasRenderer || undefined;
      if (!paneName) return vectorCanvasRenderer || undefined;
      const cur = LAYER_CANVAS_RENDERERS[layerName];
      if (cur && cur._qdashPane === paneName) return cur;
      if (cur && typeof cur.remove === 'function') {{
        try {{ cur.remove(); }} catch (_rm) {{}}
      }}
      const next = L.canvas({{ padding: 0.5, pane: paneName }});
      if (next) next._qdashPane = paneName;
      LAYER_CANVAS_RENDERERS[layerName] = next;
      return next;
    }}

    function maxScaleForMinZoom(minZoomVal) {{
      const minZ = Number(minZoomVal || 0);
      if (!Number.isFinite(minZ) || minZ <= 0) return 0;
      const zIdx = Math.max(0, Math.min(ESTONIA_RESOLUTIONS.length - 1, Math.round(minZ)));
      const res = ESTONIA_RESOLUTIONS[zIdx] || 15.625;
      return Math.round(res * 3779.52756 * 1.15);
    }}

    function isLayerVisibleAtZoom(ln, zoomVal, scaleDenom) {{
      const stCfg = getMapLayerStyleCfg(ln);
      const minZ = (stCfg && Number(stCfg.min_zoom) > 0) ? Number(stCfg.min_zoom) : 0;
      if (minZ <= 0) return true;
      const hasZoom = zoomVal !== undefined && zoomVal !== null && Number.isFinite(Number(zoomVal));
      const zNum = hasZoom ? Number(zoomVal) : null;
      if (zNum !== null && zNum < minZ) return false;
      let effScale = (scaleDenom !== undefined && scaleDenom !== null && Number.isFinite(Number(scaleDenom)))
        ? Number(scaleDenom)
        : null;
      if (effScale === null && map && typeof map.getZoom === 'function') {{
        const curZ = Number(map.getZoom());
        if (!hasZoom || zNum === curZ) {{
          effScale = computeMapScaleDenominator();
        }}
      }}
      if (effScale !== null && effScale > maxScaleForMinZoom(minZ)) return false;
      return true;
    }}

    function syncZoomVisibilityImmediate() {{
      if (!map) return;
      const z = (typeof map.getZoom === 'function') ? Number(map.getZoom()) : 7;
      const sDenom = computeMapScaleDenominator();
      const lnames = orderedMapLayerNames();
      let needRenderOnReveal = false;
      IS_SYNCING_MAP_LAYERS += 1;
      try {{
        lnames.forEach(ln => {{
          const grp = LAYER_OVERLAYS[ln];
          const wms = LAYER_WMS_OVERLAYS[ln];
          const userVis = MAP_LAYER_VISIBILITY[ln] !== false;
          const zoomVis = isLayerVisibleAtZoom(ln, z, sDenom);
          if (!userVis || !zoomVis) {{
            if (grp && typeof grp.clearLayers === 'function') grp.clearLayers();
            if (!userVis && grp && typeof map.hasLayer === 'function' && map.hasLayer(grp)) map.removeLayer(grp);
            if (wms && typeof map.hasLayer === 'function' && map.hasLayer(wms)) map.removeLayer(wms);
          }} else if (grp) {{
            if (typeof map.hasLayer === 'function' && !map.hasLayer(grp)) grp.addTo(map);
            const stCfgZ = getMapLayerStyleCfg(ln);
            const isZoomGated = Boolean(stCfgZ && Number(stCfgZ.min_zoom) > 0);
            const hasGrpContent = (typeof grp.getLayers === 'function') ? grp.getLayers().length > 0 : false;
            const hasWmsContent = Boolean(wms && typeof map.hasLayer === 'function' && map.hasLayer(wms));
            if (isZoomGated && !hasGrpContent && !hasWmsContent) needRenderOnReveal = true;
          }}
        }});
      }} finally {{
        IS_SYNCING_MAP_LAYERS -= 1;
      }}
      if (needRenderOnReveal && !IS_PROGRAMMATIC_MOVE && typeof scheduleMapRender === 'function') {{
        scheduleMapRender({{ skipAutoZoom: true }});
      }}
      if (typeof updateMapLegend === 'function') updateMapLegend();
    }}

    function computeInitialLayerVisibility(layerNames) {{
      const mapWidget = getActiveMapWidget();
      return _computeInitialVisibilityForWidget(mapWidget, layerNames);
    }}

    function _canLayerUsePreviewTile(ln, targetLod, scaleDenom, hasAnyFilter) {{
      const curZoom = (map && typeof map.getZoom === 'function') ? Number(map.getZoom()) : 7;
      if (!HAS_PREVIEW_API || hasAnyFilter || MAP_LAYER_VISIBILITY[ln] === false || !isLayerVisibleAtZoom(ln, curZoom)) return false;
      const st = LAYER_STATS[ln] || {{}};
      const rows = LAYER_RECORDS[ln] || [];
      const isLarge = Number(st.feature_count || rows.length || 0) > 2500;
      if (!isLarge || st.has_qgis_layer !== true) return false;
      if (typeof L === 'undefined' || !L.tileLayer || typeof L.tileLayer.wms !== 'function') return false;
      const vp = VECTOR_PYRAMIDS[ln];
      const hasLod0Vec = Boolean(vp && vp.lod0 && Array.isArray(vp.lod0.features) && vp.lod0.features.length > 0);
      const hasLod0Overview = !EXTENT_FILTER_ENABLED && hasLod0Vec;
      return Boolean(
        targetLod >= 1
        && scaleDenom > 55000
        && (scaleDenom <= 750000 || !hasLod0Overview)
      );
    }}

    function _clearPreviewWmsRunOverlays() {{
      _setTileSourceLoading('preview_wms', false);
      if (map) {{
        IS_SYNCING_MAP_LAYERS += 1;
        try {{
          (PREVIEW_WMS_RUN_OVERLAYS || []).forEach(ov => {{
            if (ov && map.hasLayer(ov)) map.removeLayer(ov);
          }});
          if (PREVIEW_WMS_OVERLAY && map.hasLayer(PREVIEW_WMS_OVERLAY)) {{
            map.removeLayer(PREVIEW_WMS_OVERLAY);
          }}
        }} finally {{
          IS_SYNCING_MAP_LAYERS -= 1;
        }}
      }}
      PREVIEW_WMS_RUN_OVERLAYS = [];
      PREVIEW_WMS_OVERLAY = null;
      PREVIEW_WMS_KEY = '';
    }}

    function updatePreviewWmsOverlay(layerNames, scaleDenom) {{
      if (!HAS_PREVIEW_API || !map || typeof L === 'undefined') return;
      const canUseTileLayer = Boolean(L.tileLayer && typeof L.tileLayer.wms === 'function');
      if (!canUseTileLayer && typeof L.imageOverlay !== 'function') return;

      const hasAnyFilter = Object.keys(ACTIVE_FILTERS).length > 0;
      const targetLod = typeof targetLodForScale === 'function' ? targetLodForScale(scaleDenom) : 1;

      if (canUseTileLayer) {{
        // Preserve exact layerNames[0]=top draw order even when large raster layers are interleaved with vector layers
        const runs = [];
        let curRun = null;
        layerNames.forEach((ln, idx) => {{
          if (_canLayerUsePreviewTile(ln, targetLod, scaleDenom, hasAnyFilter)) {{
            const paneName = ensureLayerPane(ln, idx, layerNames.length);
            if (!curRun) {{
              curRun = {{ layers: [ln], pane: paneName }};
              runs.push(curRun);
            }} else {{
              curRun.layers.push(ln);
            }}
          }} else {{
            curRun = null;
          }}
        }});

        if (!runs.length) {{
          _clearPreviewWmsRunOverlays();
          return;
        }}

        try {{
          const revParam = 'v' + Number(BUNDLE.preview_cache_rev || 1);
          const nextOverlays = [];
          let anyLoading = false;
          runs.forEach((run, rIdx) => {{
            const layersParam = run.layers.join(',');
            let ov = PREVIEW_WMS_RUN_OVERLAYS[rIdx] || null;
            const desiredPane = run.pane || 'overlayPane';
            const samePane = Boolean(ov && ov._qdashPane === desiredPane);
            if (ov && samePane && typeof ov.setParams === 'function') {{
              if (ov._qdashLayers !== layersParam || ov._qdashRev !== revParam) {{
                ov._qdashLayers = layersParam;
                ov._qdashRev = revParam;
                anyLoading = true;
                ov.setParams({{ layers: layersParam, styles: revParam }});
              }}
              if (!map.hasLayer(ov)) {{
                IS_SYNCING_MAP_LAYERS += 1;
                try {{ ov.addTo(map); }} finally {{ IS_SYNCING_MAP_LAYERS -= 1; }}
              }}
            }} else {{
              if (ov && map.hasLayer(ov)) {{
                IS_SYNCING_MAP_LAYERS += 1;
                try {{ map.removeLayer(ov); }} finally {{ IS_SYNCING_MAP_LAYERS -= 1; }}
              }}
              const wmsOpts = {{
                version: '1.1.1',
                layers: layersParam,
                styles: revParam,
                format: 'image/png',
                transparent: true,
                tileSize: 256,
                opacity: 0.90,
                pane: desiredPane,
                zIndex: 1,
                updateWhenIdle: true,
                updateWhenZooming: false,
                keepBuffer: 2,
              }};
              ov = L.tileLayer.wms('/api/tile', wmsOpts);
              ov._qdashPane = desiredPane;
              ov._qdashLayers = layersParam;
              ov._qdashRev = revParam;
              attachMapLayerLoaderEvents(ov, 'preview_wms_' + rIdx, t('map_rendering_layers'));
              anyLoading = true;
              IS_SYNCING_MAP_LAYERS += 1;
              try {{ ov.addTo(map); }} finally {{ IS_SYNCING_MAP_LAYERS -= 1; }}
            }}
            nextOverlays.push(ov);
          }});
          if (PREVIEW_WMS_RUN_OVERLAYS.length > runs.length) {{
            IS_SYNCING_MAP_LAYERS += 1;
            try {{
              for (let j = runs.length; j < PREVIEW_WMS_RUN_OVERLAYS.length; j++) {{
                const oldOv = PREVIEW_WMS_RUN_OVERLAYS[j];
                if (oldOv && map.hasLayer(oldOv)) map.removeLayer(oldOv);
              }}
            }} finally {{
              IS_SYNCING_MAP_LAYERS -= 1;
            }}
          }}
          PREVIEW_WMS_RUN_OVERLAYS = nextOverlays;
          PREVIEW_WMS_OVERLAY = nextOverlays[0] || null;
          PREVIEW_WMS_KEY = runs.map(r => r.layers.join(',')).join('|');
          PREVIEW_WMS_REV = revParam;
          if (anyLoading) _setTileSourceLoading('preview_wms', true, t('map_rendering_layers'));
        }} catch (_e) {{
          _setTileSourceLoading('preview_wms', false);
        }}
        return;
      }}

      const curZoom = (map && typeof map.getZoom === 'function') ? Number(map.getZoom()) : 7;
      const visibleLarge = layerNames.filter(ln => {{
        if (MAP_LAYER_VISIBILITY[ln] === false || !isLayerVisibleAtZoom(ln, curZoom)) return false;
        const st = LAYER_STATS[ln] || {{}};
        const rows = LAYER_RECORDS[ln] || [];
        return Number(st.feature_count || rows.length || 0) > 2500;
      }});
      const visibleNeedsTiles = visibleLarge.filter(ln => {{
        const vp = VECTOR_PYRAMIDS[ln];
        const hasLod0Vec = Boolean(vp && vp.lod0 && Array.isArray(vp.lod0.features) && vp.lod0.features.length > 0);
        return scaleDenom <= 750000 || !hasLod0Vec || EXTENT_FILTER_ENABLED;
      }});
      if (!visibleNeedsTiles.length || scaleDenom <= 55000 || hasAnyFilter) {{
        _clearPreviewWmsRunOverlays();
        return;
      }}
      try {{
        const mb = map.getBounds();
        const sz = map.getSize ? map.getSize() : {{ x: 960, y: 640 }};
        if (!mb || !mb.isValid || !mb.isValid()) return;
        const bboxStr = [
          mb.getWest().toFixed(5),
          mb.getSouth().toFixed(5),
          mb.getEast().toFixed(5),
          mb.getNorth().toFixed(5)
        ].join(',');
        const w = Math.max(256, Math.min(1800, Math.round(sz.x || 960)));
        const h = Math.max(256, Math.min(1400, Math.round(sz.y || 640)));
        const key = `${{visibleLarge.join('|')}}|${{bboxStr}}|${{w}}x${{h}}`;
        if (key === PREVIEW_WMS_KEY && PREVIEW_WMS_OVERLAY && map.hasLayer(PREVIEW_WMS_OVERLAY)) return;
        PREVIEW_WMS_KEY = key;
        const params = new URLSearchParams();
        params.set('layers', visibleLarge.join(','));
        params.set('bbox', bboxStr);
        params.set('width', String(w));
        params.set('height', String(h));
        const imgUrl = '/api/wms?' + params.toString();
        const bounds = [[mb.getSouth(), mb.getWest()], [mb.getNorth(), mb.getEast()]];
        const topIdx = layerNames.indexOf(visibleLarge[0]);
        const topPane = ensureLayerPane(visibleLarge[0], Math.max(0, topIdx), layerNames.length);
        _setTileSourceLoading('preview_wms', true, t('map_rendering_layers'));
        if (PREVIEW_WMS_OVERLAY && typeof PREVIEW_WMS_OVERLAY.setUrl === 'function') {{
          attachMapLayerLoaderEvents(PREVIEW_WMS_OVERLAY, 'preview_wms', t('map_rendering_layers'));
          PREVIEW_WMS_OVERLAY.setBounds(bounds);
          PREVIEW_WMS_OVERLAY.setUrl(imgUrl);
          if (!map.hasLayer(PREVIEW_WMS_OVERLAY)) PREVIEW_WMS_OVERLAY.addTo(map);
        }} else {{
          const imgOpts = {{ opacity: 0.85, interactive: false }};
          if (topPane) imgOpts.pane = topPane;
          PREVIEW_WMS_OVERLAY = L.imageOverlay(imgUrl, bounds, imgOpts);
          attachMapLayerLoaderEvents(PREVIEW_WMS_OVERLAY, 'preview_wms', t('map_rendering_layers'));
          PREVIEW_WMS_OVERLAY.addTo(map);
        }}
      }} catch (_e) {{
        _setTileSourceLoading('preview_wms', false);
      }}
    }}

    function orderedLegendLayerNames() {{
      const mapWidget = getActiveMapWidget();
      const activeNames = orderedMapLayerNames();
      const legPref = (mapWidget && Array.isArray(mapWidget.map_legend_layers) && mapWidget.map_legend_layers.length)
        ? mapWidget.map_legend_layers
        : null;
      if (!legPref) return activeNames;
      const activeSet = new Set(activeNames);
      const out = [];
      legPref.forEach(ln => {{
        if (activeSet.has(ln) && !out.includes(ln)) out.push(ln);
      }});
      activeNames.forEach(ln => {{
        if (!out.includes(ln)) out.push(ln);
      }});
      return out;
    }}

    function resolveStyleFields(custom) {{
      if (!custom) return [];
      const multi = Array.isArray(custom.style_fields) && custom.style_fields.length
        ? custom.style_fields
        : (Array.isArray(custom.legend_fields) && custom.legend_fields.length ? custom.legend_fields : null);
      if (multi) {{
        return multi.map(f => String(f || '').trim()).filter(Boolean);
      }}
      if (custom.style_field && String(custom.style_field).trim()) {{
        return [String(custom.style_field).trim()];
      }}
      return [];
    }}

    function resolveCategoryColor(valKey, qgisStyle) {{
      if (qgisStyle && qgisStyle.category_colors && qgisStyle.category_colors[valKey]) {{
        return qgisStyle.category_colors[valKey];
      }}
      return hashCategoryColor(valKey);
    }}

    function getEffectiveLayerStyleSpec(layerName) {{
      const custom = getMapLayerStyleCfg(layerName);
      const useQgisStyle = String((DASHBOARD && DASHBOARD.canvas_sync_mode) || 'dashboard_only') === 'sync_main_canvas';
      const qgisStyle = useQgisStyle ? ((LAYER_STATS[layerName] || {{}}).qgis_style || null) : null;
      const customFields = resolveStyleFields(custom);
      const explicitMode = (custom && (custom.style_mode || custom.mode)) || '';
      let mode = explicitMode || (qgisStyle && qgisStyle.style_mode) || 'single';
      let styleFields = customFields;
      if (!styleFields.length && mode !== 'single' && explicitMode !== 'single' && qgisStyle && qgisStyle.style_field) {{
        styleFields = [String(qgisStyle.style_field).trim()].filter(Boolean);
      }}
      if (explicitMode === 'single') {{
        mode = 'single';
        styleFields = [];
      }}
      const hasCustomLbl = Boolean(custom && (Array.isArray(custom.label_fields) || custom.label_field !== undefined));
      const rawLblFields = hasCustomLbl
        ? (Array.isArray(custom.label_fields) ? custom.label_fields.map(f => String(f || '').trim()).filter(Boolean) : [])
        : (Array.isArray(qgisStyle && qgisStyle.label_fields) ? qgisStyle.label_fields.map(f => String(f || '').trim()).filter(Boolean) : []);
      const fallbackSingle = hasCustomLbl
        ? String((custom && custom.label_field) || '').trim()
        : String((qgisStyle && qgisStyle.label_field) || '').trim();
      const labelFields = rawLblFields.length ? rawLblFields : (fallbackSingle ? [fallbackSingle] : []);
      const labelField = labelFields[0] || '';
      const labelSize = Math.max(3, Math.min(24, Number((custom && custom.label_size) || (qgisStyle && qgisStyle.label_size) || 10)));
      const labelColor = String((custom && custom.label_color) || (qgisStyle && qgisStyle.label_color) || '#0f172a').trim();
      const rawHaloOp = (custom && custom.label_halo_opacity !== undefined && custom.label_halo_opacity !== null)
        ? Number(custom.label_halo_opacity)
        : ((custom && custom.label_halo !== undefined)
            ? (custom.label_halo ? 90 : 0)
            : ((qgisStyle && qgisStyle.label_halo_opacity !== undefined && qgisStyle.label_halo_opacity !== null)
                ? Number(qgisStyle.label_halo_opacity)
                : ((qgisStyle && qgisStyle.label_halo !== undefined) ? (qgisStyle.label_halo ? 90 : 0) : 90)));
      const labelHaloOpacity = Math.max(0, Math.min(100, Number.isFinite(rawHaloOp) ? rawHaloOp : 90));
      const labelHalo = labelHaloOpacity > 0;
      const labelMultiRow = (labelFields.length <= 1) && Boolean((custom && custom.label_multi_row) || (qgisStyle && qgisStyle.label_multi_row) || false);
      const labelPosition = String((custom && custom.label_position) || (qgisStyle && qgisStyle.label_position) || 'center').trim();
      const rawLblZoom = (custom && custom.label_min_zoom !== undefined)
        ? custom.label_min_zoom
        : ((qgisStyle && qgisStyle.label_min_zoom !== undefined) ? qgisStyle.label_min_zoom : 0);
      const labelMinZoom = Math.max(0, Math.min(18, Number(rawLblZoom) || 0));
      return {{ custom, qgisStyle, mode, styleFields, labelFields, labelField, labelSize, labelColor, labelHalo, labelHaloOpacity, labelMultiRow, labelPosition, labelMinZoom }};
    }}

    function defaultUniformColor(layerName, custom, svc) {{
      if (custom && custom.color && String(custom.color).trim()) return custom.color;
      const useQgisStyle = String((DASHBOARD && DASHBOARD.canvas_sync_mode) || 'dashboard_only') === 'sync_main_canvas';
      const qgisStyle = useQgisStyle ? ((LAYER_STATS[layerName] || {{}}).qgis_style || null) : null;
      if (qgisStyle && qgisStyle.color && String(qgisStyle.color).trim()) return qgisStyle.color;
      const svcCol = (svc && svc.layer_color) ? String(svc.layer_color).trim() : '';
      if (svcCol && svcCol.toLowerCase() !== '#38bdf8') return svcCol;
      if (/natura|elupaik/i.test(layerName)) return '#10b981';
      if (/pria|pärandniit|niit/i.test(layerName)) return '#0ea5e9';
      if (/kaitseala|loodusala|hoiuala|linnuala|püsielupaik/i.test(layerName)) return '#f97316';
      return svcCol || '#10b981';
    }}

    function _hexToRgbaCss(colorStr, alpha) {{
      const a = Math.max(0, Math.min(1, Number(alpha ?? 0.45)));
      const s = String(colorStr || '').trim();
      const m = /^#([0-9a-f]{{3}}|([0-9a-f]{{6}}))$/i.exec(s);
      if (!m) return s || `rgba(16, 185, 129, ${{a}})`;
      let hex = m[1];
      if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
      const r = parseInt(hex.slice(0, 2), 16);
      const g = parseInt(hex.slice(2, 4), 16);
      const b = parseInt(hex.slice(4, 6), 16);
      return `rgba(${{r}},${{g}},${{b}},${{a.toFixed(2)}})`;
    }}

    function _legendSwatchHtml(fillColor, borderColor, outlineOnly, fillOpacity) {{
      const brd = escapeHtml(borderColor || fillColor || '#10b981');
      if (outlineOnly || Number(fillOpacity ?? 0.42) <= 0.01) {{
        return `<span class="legend-dot legend-dot-outline" style="background:transparent;border:2px solid ${{brd}};"></span>`;
      }}
      const fillCss = escapeHtml(_hexToRgbaCss(fillColor || '#10b981', Math.max(0.32, Number(fillOpacity ?? 0.42))));
      return `<span class="legend-dot" style="background:${{fillCss}};border:1.5px solid ${{brd}};"></span>`;
    }}

    function collectMapLegendEntries() {{
      const mapWidget = getActiveMapWidget();
      const titleText = (mapWidget && mapWidget.map_legend_title) ? mapWidget.map_legend_title : t('html_legend_title');
      if (LEGEND_COLLAPSED) {{
        return {{ title: titleText, collapsed: true, entries: [] }};
      }}
      const visibleLayers = orderedLegendLayerNames().filter(ln => MAP_LAYER_VISIBILITY[ln] !== false);
      if (!visibleLayers.length) {{
        return {{ title: titleText, collapsed: false, entries: [] }};
      }}

      const mapZoom = (map && typeof map.getZoom === 'function') ? Number(map.getZoom()) : 7;
      const scaleDenom = (typeof computeMapScaleDenominator === 'function') ? computeMapScaleDenominator() : null;
      let viewBb = null;
      if (map && typeof map.getBounds === 'function') {{
        try {{
          const mb = map.getBounds();
          if (mb && mb.isValid && mb.isValid()) {{
            viewBb = [mb.getWest(), mb.getSouth(), mb.getEast(), mb.getNorth()];
          }}
        }} catch (_vb) {{}}
      }}

      const entries = [];
      visibleLayers.forEach(ln => {{
        const spec = getEffectiveLayerStyleSpec(ln);
        const custom = spec.custom;
        const qgisStyle = spec.qgisStyle;
        if (custom && custom.show_in_legend === false) return;
        if (typeof isLayerVisibleAtZoom === 'function' && !isLayerVisibleAtZoom(ln, mapZoom, scaleDenom)) return;
        const rawRows = LAYER_RECORDS[ln] || [];
        const filteredRows = (typeof filterRecords === 'function')
          ? (filterRecords(ln, null, '__map__') || [])
          : rawRows;
        if (rawRows.length > 0 && filteredRows.length === 0) return;

        let sourceRows = filteredRows;
        if (viewBb && filteredRows.length > 0) {{
          const vx0 = viewBb[0], vy0 = viewBb[1], vx1 = viewBb[2], vy1 = viewBb[3];
          const inView = [];
          for (let ri = 0; ri < filteredRows.length; ri++) {{
            const row = filteredRows[ri];
            if (!row) continue;
            const rbb = (Array.isArray(row._bbox) && row._bbox.length === 4) ? row._bbox : null;
            if (rbb) {{
              if (!(Number(rbb[2]) < vx0 || Number(rbb[0]) > vx1 || Number(rbb[3]) < vy0 || Number(rbb[1]) > vy1)) {{
                inView.push(row);
              }}
            }} else {{
              const fid = (row._feature_id !== undefined && row._feature_id !== null) ? String(row._feature_id) : '';
              const fbb = fid ? getFeatureBbox(ln, fid) : null;
              if (fbb && fbb.length === 4) {{
                if (!(Number(fbb[2]) < vx0 || Number(fbb[0]) > vx1 || Number(fbb[3]) < vy0 || Number(fbb[1]) > vy1)) {{
                  inView.push(row);
                }}
              }} else if (row._lat !== undefined && row._lon !== undefined) {{
                const lat = Number(row._lat), lon = Number(row._lon);
                if (Number.isFinite(lat) && Number.isFinite(lon) && lon >= vx0 && lon <= vx1 && lat >= vy0 && lat <= vy1) {{
                  inView.push(row);
                }}
              }} else {{
                inView.push(row);
              }}
            }}
          }}
          if (inView.length === 0) return;
          sourceRows = inView;
        }} else if (!rawRows.length && LAYER_LIVE_INFO[ln] && Number(LAYER_LIVE_INFO[ln].loaded || 0) === 0) {{
          return;
        }}

        const svc = (BUNDLE.ogc_services || []).find(s => s.name === ln) || {{}};
        const dispName = (custom && custom.legend_label) ? custom.legend_label : ln;
        const mode = spec.mode;
        const styleFields = spec.styleFields;
        const uniformFill = defaultUniformColor(ln, custom, svc);
        const outlineOnly = (custom && custom.outline_only !== undefined)
          ? Boolean(custom.outline_only)
          : Boolean(qgisStyle && (qgisStyle.outline_only || Number(qgisStyle.opacity) === 0));
        const fillOpacity = outlineOnly
          ? 0.0
          : ((custom && custom.opacity !== undefined)
              ? Number(custom.opacity)
              : ((qgisStyle && qgisStyle.opacity !== undefined) ? Number(qgisStyle.opacity) : 0.42));
        const customBrd = (custom && custom.border_color && String(custom.border_color).trim())
          ? String(custom.border_color).trim()
          : '';
        const borderColor = customBrd || ((mode === 'single' && (!custom || !custom.color) && qgisStyle && qgisStyle.stroke_color) ? qgisStyle.stroke_color : uniformFill);

        if (mode !== 'single' && styleFields.length > 0) {{
          const catAgg = new Map();
          for (let i = 0; i < sourceRows.length; i++) {{
            const row = sourceRows[i];
            if (!row) continue;
            const parts = styleFields.map(f => row[f]).filter(v => v !== null && v !== undefined && String(v).trim() !== '').map(v => String(v));
            const key = parts.join(' | ');
            if (!key) continue;
            const areaVal = Math.max(0, Number(row._geom_area_ha !== undefined ? row._geom_area_ha : (row.area_ha || 0)) || 0);
            let entry = catAgg.get(key);
            if (!entry) {{
              entry = {{ key, area: 0, count: 0 }};
              catAgg.set(key, entry);
            }}
            entry.area += areaVal;
            entry.count += 1;
          }}
          let rankedCats = Array.from(catAgg.values()).sort((a, b) => {{
            if (Math.abs(b.area - a.area) > 1e-6) return b.area - a.area;
            if (b.count !== a.count) return b.count - a.count;
            return a.key.localeCompare(b.key);
          }}).map(x => x.key);

          if (!rankedCats.length && !rawRows.length && qgisStyle && qgisStyle.category_colors) {{
            rankedCats = Object.keys(qgisStyle.category_colors).filter(Boolean);
          }}
          if (rankedCats.length) {{
            const MAX_LEGEND_CATS = 40;
            const shownCats = rankedCats.slice(0, MAX_LEGEND_CATS);
            entries.push({{ kind: 'header', label: `${{dispName}} (${{styleFields.join(', ')}})` }});
            shownCats.forEach(v => {{
              const cCol = resolveCategoryColor(v, qgisStyle);
              const cBrd = customBrd || cCol;
              entries.push({{ kind: 'item', label: v, fillColor: cCol, borderColor: cBrd, outlineOnly, fillOpacity }});
            }});
            if (rankedCats.length > MAX_LEGEND_CATS) {{
              entries.push({{ kind: 'note', label: `… (+${{rankedCats.length - MAX_LEGEND_CATS}})` }});
            }}
            return;
          }}
        }}

        entries.push({{ kind: 'item', label: dispName, fillColor: uniformFill, borderColor, outlineOnly, fillOpacity }});
      }});

      return {{ title: titleText, collapsed: false, entries }};
    }}

    function legendHtml() {{
      const data = collectMapLegendEntries();
      const btnIcon = data.collapsed ? '⟨' : '⟩';
      const btnTitle = data.collapsed ? t('html_expand_panel') : t('html_collapse_panel');
      const headerHtml = `<div class="legend-hdr"><b>${{escapeHtml(data.title)}}</b><button type="button" class="panel-right-toggle-btn" onclick="toggleLegendCollapsed()" title="${{escapeHtml(btnTitle)}}">${{btnIcon}}</button></div>`;
      if (data.collapsed) {{
        return headerHtml;
      }}
      if (!data.entries.length) {{
        return headerHtml + `<div class="legend-empty">${{escapeHtml(t('legend_none_in_view'))}}</div>`;
      }}
      const items = data.entries.map(ent => {{
        if (ent.kind === 'header') return `<b>${{escapeHtml(ent.label)}}</b>`;
        if (ent.kind === 'note') return `<span style="opacity:0.75;font-size:0.72rem;">${{escapeHtml(ent.label)}}</span>`;
        return `${{_legendSwatchHtml(ent.fillColor, ent.borderColor, ent.outlineOnly, ent.fillOpacity)}}${{escapeHtml(ent.label)}}`;
      }});
      return headerHtml + items.join('<br/>');
    }}

    function toggleLegendCollapsed() {{
      LEGEND_COLLAPSED = !LEGEND_COLLAPSED;
      updateMapLegend();
    }}

    function toggleLayerControlCollapsed() {{
      LAYER_CONTROL_COLLAPSED = !LAYER_CONTROL_COLLAPSED;
      if (!layerControl || !layerControl.getContainer) return;
      const el = layerControl.getContainer();
      if (!el) return;
      if (el.classList) el.classList.toggle('leaflet-right-collapsed', LAYER_CONTROL_COLLAPSED);
      const btn = el.querySelector('.leaflet-layer-collapse-btn');
      if (btn) {{
        btn.textContent = LAYER_CONTROL_COLLAPSED ? '⟨' : '⟩';
        btn.title = LAYER_CONTROL_COLLAPSED ? t('html_expand_panel') : t('html_collapse_panel');
      }}
    }}

    function updateMapLegend() {{
      if (!legendControl || !legendControl.getContainer) return;
      const el = legendControl.getContainer();
      if (!el) return;
      const mapWidget = getActiveMapWidget();
      const showLegend = !mapWidget || mapWidget.map_show_legend !== false;
      el.style.display = showLegend ? 'block' : 'none';
      if (el.classList) el.classList.toggle('leaflet-right-collapsed', LEGEND_COLLAPSED);
      if (showLegend) el.innerHTML = legendHtml();
    }}

    function applyLanguageUI() {{
      document.documentElement.lang = LANG;
      const titleEl = document.getElementById('brand-title-text');
      if (titleEl) titleEl.textContent = (LANG === 'en' && DASHBOARD.title_en) ? DASHBOARD.title_en : (DASHBOARD.title || '');
      const subEl = document.getElementById('brand-subtitle-text');
      if (subEl) subEl.textContent = (LANG === 'en' && DASHBOARD.subtitle_en) ? DASHBOARD.subtitle_en : (DASHBOARD.subtitle || '');
      const setTxt = (id, key) => {{ const el = document.getElementById(id); if (el) el.textContent = t(key); }};
      setTxt('btn-download-gpkg', 'btn_download_gpkg');
      setTxt('btn-export-png', 'btn_export_png');
      setTxt('btn-export-jpg', 'btn_export_jpg');
      setTxt('btn-scope-dash', 'export_scope_dash');
      setTxt('btn-scope-map', 'export_scope_map');
      setTxt('lbl-settings-export', 'settings_export_sec');
      setTxt('lbl-settings-behavior', 'settings_behavior_sec');
      setTxt('lbl-settings-display', 'settings_display_sec');
      setTxt('lbl-opt-autohome', 'opt_auto_home_clear');
      setTxt('btn-settings-menu', 'settings_menu_btn');
      setTxt('btn-reset-filters', 'html_reset_filters');
      setTxt('btn-reset-dashboard', 'html_reset_dashboard');
      setTxt('btn-mobile-view', MOBILE_VIEW_ENABLED ? 'mobile_view_active' : 'mobile_view_btn');
      setTxt('btn-mobile-fit', 'mobile_fit_btn');
      const minBtnEl = document.getElementById('btn-map-minimize');
      if (minBtnEl) minBtnEl.title = t(MAP_WINDOW_MODE === 'minimized' ? 'map_restore_tip' : 'map_minimize_tip');
      const maxBtnEl = document.getElementById('btn-map-maximize');
      if (maxBtnEl) maxBtnEl.title = t(MAP_WINDOW_MODE === 'maximized' ? 'map_restore_tip' : 'map_maximize_tip');
      const chkAutoHome = document.getElementById('chk-opt-autohome');
      if (chkAutoHome) chkAutoHome.checked = Boolean(AUTO_HOME_ON_FILTER_CLEAR);
      const mLockEl = document.getElementById('btn-mobile-map-lock');
      if (mLockEl) {{
        mLockEl.textContent = t(MOBILE_MAP_LOCKED ? 'mobile_map_lock' : 'mobile_map_unlock');
        mLockEl.title = t('mobile_map_lock_tip');
      }}
      const refLiveEl = document.getElementById('btn-refresh-live');
      if (refLiveEl) {{
        const hasMultiPg = Array.isArray(DASHBOARD.pages) && DASHBOARD.pages.length > 1;
        const baseRefTxt = t('html_refresh_live_btn');
        refLiveEl.textContent = (hasMultiPg && !baseRefTxt.endsWith('▾')) ? `${{baseRefTxt}} ▾` : baseRefTxt;
        refLiveEl.title = t('html_refresh_live_tip');
      }}
      setTxt('btn-theme-toggle', 'html_toggle_theme');
      setTxt('btn-lang', 'lang_toggle');
      setTxt('lbl-map-scroll-smoothness', 'lbl_map_scroll_smoothness');
      const rngSensEl = document.getElementById('rng-map-scroll-smoothness');
      if (rngSensEl) rngSensEl.value = String(MAP_SCROLL_SENSITIVITY);
      const valSensEl = document.getElementById('val-map-scroll-smoothness');
      if (valSensEl) valSensEl.textContent = `${{MAP_SCROLL_SENSITIVITY}}%`;
      const mapWidget = getActiveMapWidget();
      const mapHdr = document.getElementById('map-header-title');
      if (mapHdr) {{
        const hdrTxt = mapWidget ? localizedTitle(mapWidget) : t('html_map_header');
        mapHdr.textContent = hdrTxt;
        mapHdr.title = hdrTxt;
      }}
      if (typeof updateCatalogButtonLabel === 'function') updateCatalogButtonLabel();
      setTxt('btn-reset-home', 'html_reset_home');
      setTxt('btn-map-layers', 'html_map_layers_btn');
      setTxt('btn-addr-search', 'addr_search_btn');
      const addrInp = document.getElementById('map-addr-input');
      if (addrInp) addrInp.placeholder = t('addr_search_ph');
      const layerHdrLbl = document.getElementById('leaflet-layers-panel-title');
      if (layerHdrLbl) layerHdrLbl.textContent = t('html_layers_panel');
      if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
      else setLiveStatus(LIVE_STATUS_STATE.key, LIVE_STATUS_STATE.vars);
      const refScopeEl = document.getElementById('refresh-scope-menu');
      if (refScopeEl && refScopeEl.style && refScopeEl.style.display !== 'none' && typeof renderRefreshScopeMenu === 'function') {{
        renderRefreshScopeMenu();
      }}
      updateExtentButtonUI();
      if (typeof renderMapLayersDrawer === 'function') renderMapLayersDrawer();
      if (typeof renderDataCatalogDrawer === 'function') renderDataCatalogDrawer();
      if (typeof renderPagesBar === 'function') renderPagesBar();
      if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
      if (typeof updateMobileNavBar === 'function') updateMobileNavBar();
      if (typeof updateMapLegend === 'function') {{
        updateMapLegend();
      }} else if (legendControl && legendControl.getContainer()) {{
        legendControl.getContainer().innerHTML = legendHtml();
      }}
      const scaleMenuEl = document.getElementById('map-scale-menu');
      if (scaleMenuEl && scaleMenuEl.style.display === 'flex' && typeof renderMapScaleMenu === 'function') {{
        renderMapScaleMenu();
      }}
      if (typeof updateMapScaleBadge === 'function') {{
        const curS = computeMapScaleDenominator();
        updateMapScaleBadge(curS, targetLodForScale(curS));
      }}
    }}

    function setHostLanguage(nextLang) {{
      const norm = String(nextLang || '').toLowerCase().startsWith('en') ? 'en' : 'et';
      if (LANG === norm) return LANG;
      LANG = norm;
      CURR_LANG = LANG;
      if (typeof DASHBOARD === 'object' && DASHBOARD) DASHBOARD.language = LANG;
      applyLanguageUI();
      buildSlicers();
      renderAll({{ skipAutoZoom: true }});
      saveDashboardSessionState();
      return LANG;
    }}

    function toggleLanguage() {{
      const next = LANG === 'et' ? 'en' : 'et';
      return setHostLanguage(next);
    }}

    const _LCC_3301 = (() => {{
      const a = 6378137.0;
      const f = 1.0 / 298.257222101;
      const e = Math.sqrt(2 * f - f * f);
      const rad = Math.PI / 180.0;
      const p1 = 59.33333333333334 * rad;
      const p2 = 58.0 * rad;
      const p0 = 57.51755393055556 * rad;
      const l0 = 24.0 * rad;
      const mFn = (phi) => Math.cos(phi) / Math.sqrt(1 - Math.pow(e * Math.sin(phi), 2));
      const tFn = (phi) => Math.tan(Math.PI / 4 - phi / 2) / Math.pow((1 - e * Math.sin(phi)) / (1 + e * Math.sin(phi)), e / 2);
      const m1 = mFn(p1), m2 = mFn(p2);
      const t0 = tFn(p0), t1 = tFn(p1), t2 = tFn(p2);
      const n = (Math.log(m1) - Math.log(m2)) / (Math.log(t1) - Math.log(t2));
      const F = m1 / (n * Math.pow(t1, n));
      const rho0 = a * F * Math.pow(t0, n);
      return {{ a, e, rad, l0, n, F, rho0, tFn }};
    }})();

    function projectWgs84ToEstonia3301(lon, lat) {{
      const {{ a, rad, l0, n, F, rho0, tFn }} = _LCC_3301;
      const phi = lat * rad;
      const lam = lon * rad;
      const rho = a * F * Math.pow(tFn(phi), n);
      const th = n * (lam - l0);
      return [500000.0 + rho * Math.sin(th), 6375000.0 + rho0 - rho * Math.cos(th)];
    }}

    function estonia3301ToWgs84(xEast, yNorth) {{
      const {{ a, e, rad, l0, n, F, rho0 }} = _LCC_3301;
      const x = Number(xEast) - 500000.0;
      const y = rho0 - (Number(yNorth) - 6375000.0);
      const rho = (n >= 0 ? 1 : -1) * Math.hypot(x, y);
      if (!Number.isFinite(rho) || rho === 0) return [24.0, 58.65];
      const th = Math.atan2(x, y);
      const lon = (l0 + th / n) / rad;
      const tVal = Math.pow(rho / (a * F), 1.0 / n);
      let phi = Math.PI * 0.5 - 2.0 * Math.atan(tVal);
      for (let it = 0; it < 6; it++) {{
        const es = e * Math.sin(phi);
        phi = Math.PI * 0.5 - 2.0 * Math.atan(tVal * Math.pow((1 - es) / (1 + es), e * 0.5));
      }}
      return [lon, phi / rad];
    }}

    function ringAreaM2(ring) {{
      if (!ring || ring.length < 3) return 0;
      const p0 = ring[0];
      const lon0 = Number(p0 && p0[0]);
      const lat0 = Number(p0 && p0[1]);
      if (Number.isFinite(lon0) && Number.isFinite(lat0) && lon0 >= 19.5 && lon0 <= 30.5 && lat0 >= 56.5 && lat0 <= 61.5) {{
        let area = 0;
        let prev = projectWgs84ToEstonia3301(lon0, lat0);
        const first = prev;
        for (let i = 1; i <= ring.length; i++) {{
          const pt = ring[i % ring.length];
          const cur = (i === ring.length) ? first : projectWgs84ToEstonia3301(Number(pt[0]), Number(pt[1]));
          area += (prev[0] * cur[1]) - (cur[0] * prev[1]);
          prev = cur;
        }}
        return Math.abs(area) / 2;
      }}
      if (Number.isFinite(lon0) && Number.isFinite(lat0) && (Math.abs(lon0) > 180 || Math.abs(lat0) > 90)) {{
        let area = 0;
        let px = 0, py = 0;
        for (let i = 1; i <= ring.length; i++) {{
          const pt = ring[i % ring.length];
          const cx = Number(pt[0]) - lon0;
          const cy = Number(pt[1]) - lat0;
          area += (px * cy) - (cx * py);
          px = cx;
          py = cy;
        }}
        return Math.abs(area) / 2;
      }}
      const rad = Math.PI / 180;
      const R = 6371007.181;
      let area = 0;
      for (let i = 0; i < ring.length; i++) {{
        const p1 = ring[i];
        const p2 = ring[(i + 1) % ring.length];
        area += (p2[0] * rad - p1[0] * rad) * (2 + Math.sin(p1[1] * rad) + Math.sin(p2[1] * rad));
      }}
      return Math.abs((area * R * R) / 2);
    }}

    function computeGeomMeta(geom) {{
      if (!geom || !geom.coordinates) return {{ lat: null, lon: null, area_ha: 0 }};
      let sumLon = 0, sumLat = 0, count = 0, areaM2 = 0;
      const addRing = (ring) => {{
        for (const pt of ring) {{
          sumLon += Number(pt[0]);
          sumLat += Number(pt[1]);
          count++;
        }}
      }};
      if (geom.type === 'Point') {{
        return {{ lon: Number(geom.coordinates[0]), lat: Number(geom.coordinates[1]), area_ha: 0 }};
      }} else if (geom.type === 'Polygon') {{
        const rings = geom.coordinates;
        if (rings.length) {{
          addRing(rings[0]);
          areaM2 += ringAreaM2(rings[0]);
          for (let i = 1; i < rings.length; i++) areaM2 -= ringAreaM2(rings[i]);
        }}
      }} else if (geom.type === 'MultiPolygon') {{
        for (const poly of geom.coordinates) {{
          if (poly.length) {{
            addRing(poly[0]);
            areaM2 += ringAreaM2(poly[0]);
            for (let i = 1; i < poly.length; i++) areaM2 -= ringAreaM2(poly[i]);
          }}
        }}
      }} else if (geom.type === 'LineString') {{
        addRing(geom.coordinates);
      }} else if (geom.type === 'MultiLineString') {{
        for (const line of geom.coordinates) addRing(line);
      }}
      return {{
        lon: count ? sumLon / count : null,
        lat: count ? sumLat / count : null,
        area_ha: Math.max(0, Math.round((areaM2 / 10000) * 10000) / 10000)
      }};
    }}

    function _recordIdCandidates(rec, altFields) {{
      const keys = [];
      for (let i = 0; i < altFields.length; i++) {{
        const fn = altFields[i];
        const v = rec[fn];
        if (v !== undefined && v !== null && String(v).trim() !== '') keys.push(fn + ':' + String(v).trim());
      }}
      return keys;
    }}

    function ingestGeoJsonFeatures(layerName, features, opts) {{
      const options = opts || {{}};
      const store = options.targetStore || null;
      if (!store) {{
        delete _RECORD_BBOX_INDEX[layerName];
        delete _RECORD_BBOX_INDEX['__rec__' + layerName];
        if (!LAYER_GEOMETRIES[layerName]) LAYER_GEOMETRIES[layerName] = {{}};
        if (!LAYER_GEOM_LOD[layerName]) LAYER_GEOM_LOD[layerName] = {{}};
        if (!LAYER_GEOM_BBOXES[layerName]) LAYER_GEOM_BBOXES[layerName] = {{}};
      }}
      const destGeoms = store ? store.geoms : LAYER_GEOMETRIES[layerName];
      const destLods = store ? store.lods : LAYER_GEOM_LOD[layerName];
      const destBboxes = store ? store.bboxes : LAYER_GEOM_BBOXES[layerName];
      const incomingLod = Number(options.lod || 3);
      const fidOffset = Number(options.fidOffset || 0);
      const appendBatch = Boolean(options.appendBatch);
      const existingList = (!appendBatch && options.mergeExisting)
        ? (store ? (Array.isArray(store.records) && store.records.length ? store.records : null)
                 : (Array.isArray(LAYER_RECORDS[layerName]) && LAYER_RECORDS[layerName].length ? LAYER_RECORDS[layerName] : null))
        : null;

      const parsed = (features || []).map((f, idx) => {{
        const fid = (f.id !== undefined && f.id !== null)
          ? f.id
          : ((f.properties && f.properties._feature_id !== undefined && f.properties._feature_id !== null)
              ? f.properties._feature_id
              : `${{layerName}}_${{fidOffset + idx}}`);
        const props = Object.assign({{ _feature_id: fid }}, f.properties || {{}});
        let meta = null;
        let bb = null;
        if (f.geometry) {{
          const gtype = f.geometry.type || '';
          if (gtype) {{
            if (store) {{
              if (!store.geomType || /Point/i.test(store.geomType)) store.geomType = gtype;
            }} else if (!LAYER_GEOM_TYPES[layerName] || /Point/i.test(LAYER_GEOM_TYPES[layerName])) {{
              LAYER_GEOM_TYPES[layerName] = gtype;
            }}
          }}
          meta = computeGeomMeta(f.geometry);
          if (meta.lon !== null && meta.lat !== null) {{
            props._lon = meta.lon;
            props._lat = meta.lat;
          }}
          if (!/Point/i.test(gtype)) {{
            bb = geomBbox(f.geometry);
            if (bb) props._bbox = bb.map(v => Math.round(v * 100000) / 100000);
          }}
          if (gtype === 'Polygon' || gtype === 'MultiPolygon') {{
            if (props._geom_area_ha === undefined) props._geom_area_ha = meta.area_ha;
            if (props.area_ha === undefined) props.area_ha = meta.area_ha;
          }}
        }}
        return {{ fid, props, geometry: f.geometry || null, bbox: bb || props._bbox || null }};
      }});

      const joinedProps = applyExcelJoinsToLayer(layerName, parsed.map(x => x.props));

      if (appendBatch) {{
        const destRecs = store ? store.records : (LAYER_RECORDS[layerName] = Array.isArray(LAYER_RECORDS[layerName]) ? LAYER_RECORDS[layerName] : []);
        const seenFids = (store && store.seenFids) || options.seenFids || new Set();
        if (store && !store.seenFids) store.seenFids = seenFids;
        for (let idx = 0; idx < parsed.length; idx++) {{
          const item = parsed[idx];
          const jrec = joinedProps[idx] || item.props;
          const fidStr = (jrec._feature_id !== undefined && jrec._feature_id !== null) ? String(jrec._feature_id) : String(item.fid);
          if (fidStr) {{
            if (seenFids.has(fidStr)) continue;
            seenFids.add(fidStr);
          }}
          if (item.geometry && fidStr) {{
            const curLod = Number(destLods[fidStr] || 0);
            if (!destGeoms[fidStr] || incomingLod >= curLod) {{
              if (store && !destGeoms[fidStr] && incomingLod >= 3) store.exactGeomCount = Number(store.exactGeomCount || 0) + 1;
              destGeoms[fidStr] = item.geometry;
              destLods[fidStr] = incomingLod;
            }}
            if (item.bbox) destBboxes[fidStr] = item.bbox;
          }}
          destRecs.push(jrec);
        }}
        return;
      }}

      if (existingList) {{
        const byId = new Map();
        const byAltKey = new Map();
        const byCentroidBucket = new Map();
        const altIdFields = ['sys_id', 'kr_kood', 'kood', 'tunnus', 'katastritunnus', 'gml_id', 'objectid', 'gid', 'fid', 'id'];
        existingList.forEach(rec => {{
          if (!rec) return;
          if (rec._feature_id !== undefined && rec._feature_id !== null) byId.set(String(rec._feature_id), rec);
          altIdFields.forEach(fn => {{
            const v = rec[fn];
            if (v !== undefined && v !== null && String(v).trim() !== '') {{
              const k = fn + ':' + String(v).trim();
              if (!byAltKey.has(k)) byAltKey.set(k, []);
              byAltKey.get(k).push(rec);
            }}
          }});
          const rlat = Number(rec._lat), rlon = Number(rec._lon);
          if (Number.isFinite(rlat) && Number.isFinite(rlon)) {{
            const bk = `${{Math.round(rlat * 200)}}_${{Math.round(rlon * 200)}}`;
            if (!byCentroidBucket.has(bk)) byCentroidBucket.set(bk, []);
            byCentroidBucket.get(bk).push(rec);
          }}
        }});

        parsed.forEach((item, idx) => {{
          const jrec = joinedProps[idx] || item.props;
          const k = (jrec._feature_id !== undefined && jrec._feature_id !== null) ? String(jrec._feature_id) : '';
          const jlat = Number(jrec._lat), jlon = Number(jrec._lon);
          const hasJCoords = Number.isFinite(jlat) && Number.isFinite(jlon);
          let existing = byId.get(k);
          if (!existing && k.includes('.')) {{
            const tailHit = byId.get(k.slice(k.lastIndexOf('.') + 1));
            if (tailHit) {{
              const tlat = Number(tailHit._lat), tlon = Number(tailHit._lon);
              if (!hasJCoords || !Number.isFinite(tlat) || !Number.isFinite(tlon) || Math.hypot(tlat - jlat, tlon - jlon) <= 0.015) {{
                existing = tailHit;
              }}
            }}
          }}
          if (!existing) {{
            for (let ai = 0; ai < altIdFields.length; ai++) {{
              const fn = altIdFields[ai];
              const v = jrec[fn];
              if (v !== undefined && v !== null && String(v).trim() !== '') {{
                const hits = byAltKey.get(fn + ':' + String(v).trim());
                if (hits && hits.length) {{
                  if (hits.length === 1 && !hasJCoords) {{ existing = hits[0]; break; }}
                  let bestHit = null, bestHitDist = 1e9;
                  for (let hi = 0; hi < hits.length; hi++) {{
                    const cand = hits[hi];
                    const clat = Number(cand._lat), clon = Number(cand._lon);
                    const dist = (hasJCoords && Number.isFinite(clat) && Number.isFinite(clon)) ? Math.hypot(clat - jlat, clon - jlon) : 0;
                    if (dist < bestHitDist) {{ bestHitDist = dist; bestHit = cand; }}
                  }}
                  if (bestHit && (bestHitDist <= 0.006 || (hits.length === 1 && bestHitDist <= 0.025))) {{
                    existing = bestHit;
                    break;
                  }}
                }}
              }}
            }}
          }}
          // Only match by centroid if neither side carries a conflicting prefixed GeoServer/WFS FID
          if (!existing && hasJCoords) {{
            const kPrefixed = k.includes('.');
            const cLat = Math.round(jlat * 200), cLon = Math.round(jlon * 200);
            const ib = item.bbox;
            let best = null, bestScore = 1e9;
            for (let dLat = -1; dLat <= 1; dLat++) {{
              for (let dLon = -1; dLon <= 1; dLon++) {{
                const arr = byCentroidBucket.get(`${{cLat + dLat}}_${{cLon + dLon}}`);
                if (!arr) continue;
                for (let bi = 0; bi < arr.length; bi++) {{
                  const cand = arr[bi];
                  const candId = String(cand._feature_id ?? '');
                  if (kPrefixed && candId.includes('.') && candId !== k) continue;
                  const dist = Math.hypot(Number(cand._lat) - jlat, Number(cand._lon) - jlon);
                  const candBb = (Array.isArray(cand._bbox) && cand._bbox.length === 4) ? cand._bbox : getFeatureBbox(layerName, candId);
                  const overlaps = Boolean(
                    ib && ib.length === 4 && candBb && candBb.length === 4
                    && Number(candBb[0]) <= ib[2] && Number(candBb[2]) >= ib[0]
                    && Number(candBb[1]) <= ib[3] && Number(candBb[3]) >= ib[1]
                  );
                  if (dist > 0.004 && !overlaps) continue;
                  const penalty = dist + (overlaps ? 0 : 0.004);
                  if (penalty < bestScore) {{ bestScore = penalty; best = cand; }}
                }}
              }}
            }}
            if (best && bestScore < 0.008) existing = best;
          }}

          const targetFid = existing && existing._feature_id !== undefined && existing._feature_id !== null
            ? String(existing._feature_id)
            : k;
          if (item.geometry && targetFid) {{
            const curLod = Number(destLods[targetFid] || 0);
            if (!destGeoms[targetFid] || incomingLod >= curLod) {{
              if (store && !destGeoms[targetFid] && incomingLod >= 3) store.exactGeomCount = Number(store.exactGeomCount || 0) + 1;
              destGeoms[targetFid] = item.geometry;
              destLods[targetFid] = incomingLod;
            }}
            if (item.bbox) destBboxes[targetFid] = item.bbox;
          }}
          if (existing) {{
            Object.keys(jrec).forEach(col => {{
              if (col === '_feature_id') return;
              if (existing[col] === undefined || existing[col] === null || existing[col] === '') existing[col] = jrec[col];
            }});
          }} else if (!options.matchExistingOnly) {{
            if (store) store.records.push(jrec);
            else LAYER_RECORDS[layerName].push(jrec);
            if (targetFid) byId.set(targetFid, jrec);
          }}
        }});
      }} else {{
        const destRecs = [];
        const seenFids = (store && store.seenFids) || options.seenFids || new Set();
        parsed.forEach((item, idx) => {{
          const jrec = joinedProps[idx] || item.props;
          const fidStr = String((jrec._feature_id !== undefined && jrec._feature_id !== null) ? jrec._feature_id : item.fid);
          if (fidStr) {{
            if (seenFids.has(fidStr)) return;
            seenFids.add(fidStr);
          }}
          if (item.geometry && fidStr) {{
            const curLod = Number(destLods[fidStr] || 0);
            if (!destGeoms[fidStr] || incomingLod >= curLod) {{
              if (store && !destGeoms[fidStr] && incomingLod >= 3) store.exactGeomCount = Number(store.exactGeomCount || 0) + 1;
              destGeoms[fidStr] = item.geometry;
              destLods[fidStr] = incomingLod;
            }}
            if (item.bbox) destBboxes[fidStr] = item.bbox;
          }}
          destRecs.push(jrec);
        }});
        if (store) {{
          store.records = destRecs;
          store.seenFids = seenFids;
        }} else {{
          LAYER_RECORDS[layerName] = destRecs;
        }}
      }}
    }}

    function geomBbox(geom) {{
      if (!geom || !geom.coordinates) return null;
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      const scan = arr => {{
        if (!Array.isArray(arr)) return;
        if (typeof arr[0] === 'number' && typeof arr[1] === 'number') {{
          if (arr[0] < minX) minX = arr[0];
          if (arr[1] < minY) minY = arr[1];
          if (arr[0] > maxX) maxX = arr[0];
          if (arr[1] > maxY) maxY = arr[1];
        }} else {{
          for (const child of arr) scan(child);
        }}
      }};
      scan(geom.coordinates);
      return minX <= maxX ? [minX, minY, maxX, maxY] : null;
    }}

    function pointInRing(x, y, ring) {{
      let inside = false;
      for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {{
        const xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
        if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-18) + xi)) {{
          inside = !inside;
        }}
      }}
      return inside;
    }}

    function pointInGeom(x, y, geom) {{
      if (!geom || !geom.coordinates) return false;
      const polys = geom.type === 'Polygon' ? [geom.coordinates] : (geom.type === 'MultiPolygon' ? geom.coordinates : []);
      for (const poly of polys) {{
        if (!poly.length || !pointInRing(x, y, poly[0])) continue;
        let inHole = false;
        for (let h = 1; h < poly.length; h++) {{
          if (pointInRing(x, y, poly[h])) {{ inHole = true; break; }}
        }}
        if (!inHole) return true;
      }}
      return false;
    }}

    function _srPairKey(a, b) {{
      const sa = String(a || '').trim();
      const sb = String(b || '').trim();
      return sa <= sb ? `${{sa}}|||${{sb}}` : `${{sb}}|||${{sa}}`;
    }}

    function _clearCrossLayerCaches() {{
      if (typeof _CROSS_LAYER_FID_CACHE !== 'undefined') _CROSS_LAYER_FID_CACHE.clear();
      if (typeof _CROSS_LAYER_AREA_CACHE !== 'undefined') _CROSS_LAYER_AREA_CACHE.clear();
      if (typeof _CROSS_LAYER_UNAVAIL_CACHE !== 'undefined') _CROSS_LAYER_UNAVAIL_CACHE.clear();
    }}

    function _invalidateRelationsForLayer(layerName, markUnavailable, reason) {{
      _clearCrossLayerCaches();
      const ln = String(layerName || '').trim();
      if (!ln || typeof SPATIAL_RELATIONS === 'undefined') return;
      for (const [k, rel] of Array.from(SPATIAL_RELATIONS.entries())) {{
        const involves = (rel && (rel.layer_a === ln || rel.layer_b === ln)) || k.split('|||').includes(ln);
        if (!involves) continue;
        if (markUnavailable) {{
          SPATIAL_RELATIONS.set(k, Object.assign({{}}, rel || {{}}, {{
            complete: false,
            exact: false,
            reason: reason || 'incomplete_data',
            byA: null,
            byB: null
          }}));
        }} else {{
          SPATIAL_RELATIONS.delete(k);
        }}
      }}
    }}

    function _isPolyGeomType(gt) {{
      return /polygon/i.test(String(gt || ''));
    }}

    function _isSpatialLayer(ln) {{
      if (!ln) return false;
      if (LAYER_GEOM_TYPES[ln]) return true;
      if (Object.keys(LAYER_GEOMETRIES[ln] || {{}}).length > 0) return true;
      if (Object.keys(LAYER_PYRAMID_LOD1[ln] || {{}}).length > 0) return true;
      if (VECTOR_PYRAMIDS[ln]) return true;
      if (typeof SPATIAL_RELATIONS !== 'undefined') {{
        for (const rel of SPATIAL_RELATIONS.values()) {{
          if (rel && (rel.layer_a === ln || rel.layer_b === ln)) return true;
        }}
      }}
      if ((BUNDLE.ogc_services || []).some(s => s && s.name === ln && s.type === 'wfs')) return true;
      const recs = LAYER_RECORDS[ln];
      if (Array.isArray(recs) && recs.length) {{
        const n = Math.min(recs.length, 50);
        for (let i = 0; i < n; i++) {{
          const r = recs[i];
          if (r && ((r._lon !== undefined && r._lat !== undefined) || Array.isArray(r._bbox))) return true;
        }}
      }}
      return false;
    }}

    function _isPointOnlyLayer(ln) {{
      const gt = String(LAYER_GEOM_TYPES[ln] || '');
      if (gt) return /point/i.test(gt) && !/polygon|line/i.test(gt);
      if (VECTOR_PYRAMIDS[ln] || Object.keys(LAYER_PYRAMID_LOD1[ln] || {{}}).length > 0) return false;
      const recs = LAYER_RECORDS[ln];
      if (!Array.isArray(recs) || !recs.length) return false;
      let sawCoord = false;
      const n = Math.min(recs.length, 50);
      for (let i = 0; i < n; i++) {{
        const r = recs[i];
        if (!r) continue;
        if (Array.isArray(r._bbox) && r._bbox.length === 4) {{
          if (Math.abs(Number(r._bbox[2]) - Number(r._bbox[0])) > 1e-9 || Math.abs(Number(r._bbox[3]) - Number(r._bbox[1])) > 1e-9) {{
            return false;
          }}
        }}
        if (Number.isFinite(Number(r._lon)) && Number.isFinite(Number(r._lat))) sawCoord = true;
      }}
      return sawCoord;
    }}

    function _layerHasCompleteExactGeoms(ln) {{
      const recs = LAYER_RECORDS[ln];
      if (!Array.isArray(recs) || !recs.length) return false;
      const cached = LAYER_COMPLETENESS[ln];
      if (cached && cached.complete === false) return false;
      if (cached && cached.complete === true && cached.exactGeoms === true && Number(cached.loaded) === recs.length) {{
        return true;
      }}
      const geoms = LAYER_GEOMETRIES[ln] || {{}};
      const lods = LAYER_GEOM_LOD[ln] || {{}};
      const isPointLayer = _isPointOnlyLayer(ln);
      for (let i = 0; i < recs.length; i++) {{
        const r = recs[i];
        if (!r) return false;
        const fidStr = (r._feature_id !== undefined && r._feature_id !== null) ? String(r._feature_id) : '';
        const hasExact = Boolean(fidStr && geoms[fidStr] && Number(lods[fidStr] || 0) >= 3);
        if (hasExact) continue;
        if (isPointLayer && Number.isFinite(Number(r._lon)) && Number.isFinite(Number(r._lat))) continue;
        LAYER_COMPLETENESS[ln] = {{
          complete: Boolean(cached && cached.complete !== undefined ? cached.complete : true),
          exactGeoms: false,
          loaded: recs.length,
          total: Number((cached && cached.total) || recs.length),
          source: (cached && cached.source) || 'partial_geom'
        }};
        return false;
      }}
      LAYER_COMPLETENESS[ln] = {{
        complete: true,
        exactGeoms: true,
        loaded: recs.length,
        total: Number((cached && cached.total) || recs.length),
        source: (cached && cached.source) || 'exact_geom'
      }};
      return true;
    }}

    async function _decompressSpatialRelation(rel) {{
      if (!rel || !rel.layer_a || !rel.layer_b) return null;
      if (!rel.complete || !rel.exact) {{
        return Object.assign({{}}, rel, {{ complete: false, exact: false, byA: null, byB: null }});
      }}
      const byA = new Map();
      const byB = new Map();
      const b64 = rel.edges_gzip_b64;
      if (!b64) {{
        return Object.assign({{}}, rel, {{ ka: [], kb: [], byA, byB }});
      }}
      try {{
        let parsed = null;
        if (typeof DecompressionStream !== 'undefined') {{
          const bytes = await _b64ToUint8ArrayAsync(b64);
          const ds = new DecompressionStream('gzip');
          const stream = new Blob([bytes]).stream().pipeThrough(ds);
          const txt = await new Response(stream).text();
          parsed = JSON.parse(txt);
        }} else if (typeof require === 'function' && typeof Buffer !== 'undefined') {{
          const zlib = require('zlib');
          const txt = zlib.gunzipSync(Buffer.from(b64, 'base64')).toString('utf-8');
          parsed = JSON.parse(txt);
        }}
        if (!parsed || !Array.isArray(parsed.ka) || !Array.isArray(parsed.kb) || !Array.isArray(parsed.e)) {{
          return Object.assign({{}}, rel, {{ complete: false, exact: false, reason: 'decode_failed', byA: null, byB: null }});
        }}
        const ka = parsed.ka;
        const kb = parsed.kb;
        const edges = parsed.e;
        let lastYield = Date.now();
        for (let i = 0; i < edges.length; i++) {{
          const item = edges[i];
          if (!Array.isArray(item) || item.length < 3) continue;
          const fa = String(ka[Number(item[0])] ?? '');
          const fb = String(kb[Number(item[1])] ?? '');
          const ha = Number(item[2]);
          if (!fa || !fb) continue;
          let listA = byA.get(fa);
          if (!listA) {{ listA = []; byA.set(fa, listA); }}
          listA.push([fb, ha]);
          let listB = byB.get(fb);
          if (!listB) {{ listB = []; byB.set(fb, listB); }}
          listB.push([fa, ha]);
          if ((i & 4095) === 4095 && (Date.now() - lastYield) >= 24) {{
            await _yieldToBrowser();
            lastYield = Date.now();
          }}
        }}
        return Object.assign({{}}, rel, {{ ka, kb, byA, byB }});
      }} catch (err) {{
        console.warn('Failed to decompress spatial relation', rel.layer_a, rel.layer_b, err);
        return Object.assign({{}}, rel, {{ complete: false, exact: false, reason: 'decode_error', byA: null, byB: null }});
      }}
    }}

    async function unpackSpatialRelationsAsync(onProgress) {{
      SPATIAL_RELATIONS.clear();
      _clearCrossLayerCaches();
      const rawList = Array.isArray(BUNDLE.spatial_relations) ? BUNDLE.spatial_relations : [];
      if (!rawList.length) return;
      const total = rawList.length;
      for (let i = 0; i < total; i++) {{
        const rel = rawList[i];
        if (!rel || !rel.layer_a || !rel.layer_b) continue;
        const decoded = await _decompressSpatialRelation(rel);
        if (decoded) {{
          SPATIAL_RELATIONS.set(_srPairKey(decoded.layer_a, decoded.layer_b), decoded);
        }}
        if (typeof onProgress === 'function') onProgress((i + 1) / total);
      }}
    }}

    function _ringSignedArea2(pts) {{
      let s = 0;
      for (let i = 0; i < pts.length - 1; i++) {{
        s += pts[i][0] * pts[i + 1][1] - pts[i + 1][0] * pts[i][1];
      }}
      return s;
    }}

    function _extractPolysProjected(geom, refX, refY, useEst, isPlanar, cosLat) {{
      const gtype = String((geom && geom.type) || '');
      const coords = geom && geom.coordinates;
      if (!coords) return [];
      const polysRaw = gtype === 'Polygon' ? [coords] : (gtype === 'MultiPolygon' ? coords : []);
      const out = [];
      for (let pi = 0; pi < polysRaw.length; pi++) {{
        const poly = polysRaw[pi];
        if (!Array.isArray(poly)) continue;
        const rings = [];
        for (let ri = 0; ri < poly.length; ri++) {{
          const rawRing = poly[ri];
          if (!Array.isArray(rawRing) || rawRing.length < 3) continue;
          const pts = [];
          for (let vi = 0; vi < rawRing.length; vi++) {{
            const pt = rawRing[vi];
            if (!Array.isArray(pt) || pt.length < 2) continue;
            const lon = Number(pt[0]);
            const lat = Number(pt[1]);
            if (!Number.isFinite(lon) || !Number.isFinite(lat)) continue;
            let x, y;
            if (useEst) {{
              const pr = projectWgs84ToEstonia3301(lon, lat);
              x = pr[0] - refX;
              y = pr[1] - refY;
            }} else if (isPlanar) {{
              x = lon - refX;
              y = lat - refY;
            }} else {{
              x = (lon - refX) * 111319.4908 * cosLat;
              y = (lat - refY) * 111132.954;
            }}
            const last = pts.length ? pts[pts.length - 1] : null;
            if (!last || Math.abs(x - last[0]) > 1e-9 || Math.abs(y - last[1]) > 1e-9) {{
              pts.push([x, y]);
            }}
          }}
          if (pts.length < 3) continue;
          const first = pts[0], lastPt = pts[pts.length - 1];
          if (Math.abs(first[0] - lastPt[0]) > 1e-9 || Math.abs(first[1] - lastPt[1]) > 1e-9) {{
            pts.push([first[0], first[1]]);
          }}
          if (pts.length < 4) continue;
          const sa = _ringSignedArea2(pts);
          if (Math.abs(sa) < 1e-10) continue;
          if ((ri === 0 && sa < 0) || (ri > 0 && sa > 0)) pts.reverse();
          rings.push(pts);
        }}
        if (rings.length) out.push(rings);
      }}
      return out;
    }}

    function _polysProjBbox(polys) {{
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (let pi = 0; pi < polys.length; pi++) {{
        const outer = polys[pi][0];
        for (let vi = 0; vi < outer.length; vi++) {{
          const x = outer[vi][0], y = outer[vi][1];
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }}
      }}
      return [minX, minY, maxX, maxY];
    }}

    function _buildEdgeIndex2D(polys, rx0, ry0, rx1, ry1) {{
      const nb = 24;
      const dy = Math.max(1e-6, (ry1 - ry0) / nb);
      const yStrips = new Array(nb);
      for (let b = 0; b < nb; b++) yStrips[b] = [];
      const gxN = 12, gyN = 12;
      const dxg = Math.max(1e-6, (rx1 - rx0) / gxN);
      const dyg = Math.max(1e-6, (ry1 - ry0) / gyN);
      const grid = new Array(gxN * gyN);
      for (let gi = 0; gi < grid.length; gi++) grid[gi] = [];
      const rEdges = [];
      let eid = 0;
      for (let pi = 0; pi < polys.length; pi++) {{
        const rings = polys[pi];
        for (let ri = 0; ri < rings.length; ri++) {{
          const pts = rings[ri];
          for (let i = 0; i < pts.length - 1; i++) {{
            const x0 = pts[i][0], y0 = pts[i][1];
            const x1 = pts[i + 1][0], y1 = pts[i + 1][1];
            const ey0 = y0 < y1 ? y0 : y1;
            const ey1 = y0 > y1 ? y0 : y1;
            const ex0 = x0 < x1 ? x0 : x1;
            const ex1 = x0 > x1 ? x0 : x1;
            if (ey1 >= ry0 - 1e-6 && ey0 <= ry1 + 1e-6 && ex1 >= rx0 - 1e-6) {{
              const edge = [x0, y0, x1, y1, ex0, ey0, ex1, ey1, eid++];
              const b0 = Math.max(0, Math.min(nb - 1, Math.floor((ey0 - ry0) / dy)));
              const b1 = Math.max(0, Math.min(nb - 1, Math.floor((ey1 - ry0) / dy)));
              for (let b = b0; b <= b1; b++) yStrips[b].push(edge);
              if (ex0 <= rx1 + 1e-6) {{
                rEdges.push(edge);
                const g0x = Math.max(0, Math.min(gxN - 1, Math.floor((ex0 - rx0) / dxg)));
                const g1x = Math.max(0, Math.min(gxN - 1, Math.floor((ex1 - rx0) / dxg)));
                const g0y = Math.max(0, Math.min(gyN - 1, Math.floor((ey0 - ry0) / dyg)));
                const g1y = Math.max(0, Math.min(gyN - 1, Math.floor((ey1 - ry0) / dyg)));
                for (let gx = g0x; gx <= g1x; gx++) {{
                  for (let gy = g0y; gy <= g1y; gy++) {{
                    grid[gy * gxN + gx].push(edge);
                  }}
                }}
              }}
            }}
          }}
        }}
      }}
      return {{ yStrips, nb, ry0, dy, rEdges, grid, gxN, gyN, rx0, dxg, dyg, nextEid: eid }};
    }}

    function _edgeIndexPointIn(idxObj, px, py) {{
      const b = Math.max(0, Math.min(idxObj.nb - 1, Math.floor((py - idxObj.ry0) / idxObj.dy)));
      const strip = idxObj.yStrips[b];
      let inside = false;
      for (let i = 0; i < strip.length; i++) {{
        const e = strip[i];
        const y0 = e[1], y1 = e[3];
        if ((y0 > py) !== (y1 > py)) {{
          const xi = e[0] + ((py - y0) * (e[2] - e[0])) / (y1 - y0);
          if (px < xi) inside = !inside;
        }}
      }}
      return inside;
    }}

    function exactPolygonIntersectionAreaHa(geomA, geomB) {{
      if (!geomA || !geomB) return 0.0;
      const bbA = geomBbox(geomA);
      const bbB = geomBbox(geomB);
      if (!bbA || !bbB) return 0.0;
      if (bbA[2] < bbB[0] || bbA[0] > bbB[2] || bbA[3] < bbB[1] || bbA[1] > bbB[3]) return 0.0;
      const ox0 = Math.max(bbA[0], bbB[0]);
      const oy0 = Math.max(bbA[1], bbB[1]);
      const ox1 = Math.min(bbA[2], bbB[2]);
      const oy1 = Math.min(bbA[3], bbB[3]);
      if (ox0 > ox1 || oy0 > oy1) return 0.0;

      const cLon = (ox0 + ox1) * 0.5;
      const cLat = (oy0 + oy1) * 0.5;
      const isPlanar = (Math.abs(cLon) > 180 || Math.abs(cLat) > 90);
      const useEst = !isPlanar && (cLon >= 19.0 && cLon <= 31.0 && cLat >= 56.0 && cLat <= 62.0);
      const cosLat = Math.cos(cLat * (Math.PI / 180.0));
      const refPt = useEst ? projectWgs84ToEstonia3301(cLon, cLat) : [cLon, cLat];
      const refX = refPt[0], refY = refPt[1];

      const pa = _extractPolysProjected(geomA, refX, refY, useEst, isPlanar, cosLat);
      const pb = _extractPolysProjected(geomB, refX, refY, useEst, isPlanar, cosLat);
      if (!pa.length || !pb.length) return 0.0;

      const ma = _polysProjBbox(pa);
      const mb = _polysProjBbox(pb);
      const rx0 = Math.max(ma[0], mb[0]);
      const ry0 = Math.max(ma[1], mb[1]);
      const rx1 = Math.min(ma[2], mb[2]);
      const ry1 = Math.min(ma[3], mb[3]);
      if (rx0 > rx1 || ry0 > ry1) return 0.0;

      const idxA = _buildEdgeIndex2D(pa, rx0, ry0, rx1, ry1);
      const idxB = _buildEdgeIndex2D(pb, rx0, ry0, rx1, ry1);

      const accumulate = (src, other, countCollinearSame) => {{
        const eps = 1e-7;
        let a2 = 0.0;
        const stampArr = new Int32Array(Math.max(1, other.nextEid));
        let stampId = 1;
        const rEdges = src.rEdges;
        for (let ei = 0; ei < rEdges.length; ei++) {{
          const se = rEdges[ei];
          const x0 = se[0], y0 = se[1], x1 = se[2], y1 = se[3];
          const ex0 = se[4], ey0 = se[5], ex1 = se[6], ey1 = se[7];
          const dx = x1 - x0, dy = y1 - y0;
          const length = Math.hypot(dx, dy);
          if (length < 1e-9) continue;
          const g0x = Math.max(0, Math.min(other.gxN - 1, Math.floor((ex0 - other.rx0) / other.dxg)));
          const g1x = Math.max(0, Math.min(other.gxN - 1, Math.floor((ex1 - other.rx0) / other.dxg)));
          const g0y = Math.max(0, Math.min(other.gyN - 1, Math.floor((ey0 - other.ry0) / other.dyg)));
          const g1y = Math.max(0, Math.min(other.gyN - 1, Math.floor((ey1 - other.ry0) / other.dyg)));
          stampId++;
          if (stampId >= 2147483640) {{
            stampArr.fill(0);
            stampId = 1;
          }}
          const ts = [0.0, 1.0];
          const colSpans = [];
          const invL2 = 1.0 / (length * length);
          for (let gx = g0x; gx <= g1x; gx++) {{
            for (let gy = g0y; gy <= g1y; gy++) {{
              const cellList = other.grid[gy * other.gxN + gx];
              for (let ci = 0; ci < cellList.length; ci++) {{
                const oe = cellList[ci];
                const oeid = oe[8];
                if (stampArr[oeid] === stampId) continue;
                stampArr[oeid] = stampId;
                if (!(ex0 <= oe[6] + eps && ex1 >= oe[4] - eps && ey0 <= oe[7] + eps && ey1 >= oe[5] - eps)) continue;
                const ox0 = oe[0], oy0 = oe[1], ox1 = oe[2], oy1 = oe[3];
                const odx = ox1 - ox0, ody = oy1 - oy0;
                const denom = dx * ody - dy * odx;
                const qpx = ox0 - x0, qpy = oy0 - y0;
                if (Math.abs(denom) > 1e-10) {{
                  const t = (qpx * ody - qpy * odx) / denom;
                  const u = (qpx * dy - qpy * dx) / denom;
                  if (t > 1e-9 && t < 1.0 - 1e-9 && u >= -1e-9 && u <= 1.0 + 1e-9) {{
                    ts.push(t);
                  }}
                }} else {{
                  const perp = Math.abs(qpx * dy - qpy * dx) / length;
                  if (perp < 1e-5) {{
                    let t0 = (qpx * dx + qpy * dy) * invL2;
                    let t1 = ((ox1 - x0) * dx + (oy1 - y0) * dy) * invL2;
                    const sameDir = (dx * odx + dy * ody) > 0.0;
                    if (t0 > t1) {{ const tmp = t0; t0 = t1; t1 = tmp; }}
                    const a = Math.max(0.0, t0);
                    const b = Math.min(1.0, t1);
                    if (b - a > 1e-9) {{
                      if (a > 1e-9 && a < 1.0 - 1e-9) ts.push(a);
                      if (b > 1e-9 && b < 1.0 - 1e-9) ts.push(b);
                      colSpans.push([a, b, sameDir]);
                    }}
                  }}
                }}
              }}
            }}
          }}
          if (ts.length > 2) ts.sort((a, b) => a - b);
          for (let ti = 0; ti < ts.length - 1; ti++) {{
            const ta = ts[ti], tb = ts[ti + 1];
            if (tb - ta <= 1e-9) continue;
            const tm = (ta + tb) * 0.5;
            let isCol = false, colSame = false;
            for (let ki = 0; ki < colSpans.length; ki++) {{
              const sp = colSpans[ki];
              if (tm >= sp[0] - 1e-8 && tm <= sp[1] + 1e-8) {{
                isCol = true;
                if (sp[2]) colSame = true;
              }}
            }}
            const include = isCol
              ? Boolean(countCollinearSame && colSame)
              : _edgeIndexPointIn(other, x0 + dx * tm, y0 + dy * tm);
            if (include) {{
              const ax = x0 + dx * ta, ay = y0 + dy * ta;
              const bx = x0 + dx * tb, by = y0 + dy * tb;
              a2 += ax * by - bx * ay;
            }}
          }}
        }}
        return a2;
      }};

      const area2 = accumulate(idxA, idxB, true) + accumulate(idxB, idxA, false);
      return Math.max(0.0, area2 * 0.5) / 10000.0;
    }}

    async function ingestGeoJsonFeaturesAsync(layerName, features, opts, onPct) {{
      const list = Array.isArray(features) ? features : [];
      const options = opts || {{}};
      const store = options.targetStore || null;
      const seenFids = (store && store.seenFids) || options.seenFids || new Set();
      if (store && !store.seenFids) store.seenFids = seenFids;

      const destRecs = store ? store.records : LAYER_RECORDS[layerName];
      const hasExisting = Boolean(options.mergeExisting && !options.appendBatch && Array.isArray(destRecs) && destRecs.length > 0);
      const useAppendMode = Boolean(options.appendBatch || !hasExisting);

      if (useAppendMode && !options.appendBatch) {{
        if (store) {{
          store.records = [];
          store.geoms = {{}};
          store.bboxes = {{}};
          store.lods = {{}};
          store.exactGeomCount = 0;
        }} else {{
          LAYER_RECORDS[layerName] = [];
          LAYER_GEOMETRIES[layerName] = {{}};
          LAYER_GEOM_LOD[layerName] = {{}};
          LAYER_GEOM_BBOXES[layerName] = {{}};
          delete _RECORD_BBOX_INDEX[layerName];
          delete _RECORD_BBOX_INDEX['__rec__' + layerName];
        }}
      }}

      if (list.length <= 1800) {{
        ingestGeoJsonFeatures(layerName, list, Object.assign({{}}, options, {{
          appendBatch: useAppendMode && !options.mergeExisting,
          mergeExisting: hasExisting,
          seenFids,
          fidOffset: Number(options.fidOffset || 0)
        }}));
        if (typeof onPct === 'function') onPct(1);
        return;
      }}

      const chunk = 1800;
      const total = list.length;
      const baseOffset = Number(options.fidOffset || 0);
      for (let start = 0; start < total; start += chunk) {{
        const slice = list.slice(start, start + chunk);
        const subOpts = Object.assign({{}}, options, {{
          appendBatch: useAppendMode,
          mergeExisting: hasExisting,
          seenFids,
          fidOffset: baseOffset + start
        }});
        ingestGeoJsonFeatures(layerName, slice, subOpts);
        if (typeof onPct === 'function') onPct(Math.min(1, (start + slice.length) / total));
        await _yieldToBrowser();
      }}
    }}

    let DATA_CATALOG = [];
    let CATALOG_SEARCH_QUERY = '';
    let CATALOG_SOURCE_FILTER = '__all__';
    let CATALOG_ADD_OPEN = false;
    let CATALOG_ADD_TAB = 'ogc';
    let CATALOG_ADD_MSG = '';
    let CATALOG_CAP_LOADING = false;

    function initDataCatalog() {{
      const servers = [];
      const byKey = new Map();
      const addSrv = (srv) => {{
        if (!srv || !srv.url) return;
        const stype = String(srv.service_type || srv.type || 'wfs').toLowerCase();
        const url = String(srv.url).trim();
        const key = `${{stype}}|${{url.toLowerCase()}}`;
        let entry = byKey.get(key);
        if (!entry) {{
          entry = {{
            id: 'cat_srv_' + servers.length,
            name: String(srv.name || url),
            service_type: stype,
            url: url,
            crs: String(srv.crs || 'EPSG:3301'),
            layers: [],
            custom: Boolean(srv.custom),
          }};
          byKey.set(key, entry);
          servers.push(entry);
        }}
        const seenL = new Set(entry.layers.map(l => String(l.name || '')));
        (srv.layers || []).forEach(l => {{
          const ln = String((l && l.name) || '').trim();
          if (!ln || seenL.has(ln)) return;
          seenL.add(ln);
          entry.layers.push({{
            name: ln,
            title: String((l && l.title) || ln).trim(),
            service_type: String((l && l.service_type) || stype).toLowerCase(),
            crs: String((l && l.crs) || entry.crs || 'EPSG:3301'),
          }});
        }});
      }};

      const rawCat = Array.isArray(BUNDLE.data_catalog) ? BUNDLE.data_catalog : [];
      rawCat.forEach(addSrv);
      if (EELIS_CATALOG.length) {{
        addSrv({{
          name: 'EELIS (Avalik / Keskkonnaagentuur)',
          service_type: 'wfs',
          url: BUNDLE.default_eelis_wfs_url || 'https://gsavalik.envir.ee/geoserver/eelis/ows',
          crs: 'EPSG:3301',
          layers: EELIS_CATALOG.map(x => ({{ name: x.name, title: x.title || x.name, service_type: 'wfs' }})),
        }});
      }}
      (BUNDLE.ogc_services || []).forEach(svc => {{
        if (!svc || svc.is_basemap || !svc.url) return;
        const ln = svc.typename || svc.layers || svc.name;
        if (!ln) return;
        addSrv({{
          name: svc.server_name || svc.name || svc.url,
          service_type: svc.type || 'wfs',
          url: svc.url,
          crs: svc.crs || 'EPSG:3301',
          layers: [{{ name: ln, title: svc.name || ln, service_type: svc.type || 'wfs' }}],
        }});
      }});
      DATA_CATALOG = servers;
      updateCatalogButtonLabel();
    }}

    function totalCatalogLayerCount() {{
      let total = 0;
      (DATA_CATALOG || []).forEach(srv => {{ total += Array.isArray(srv.layers) ? srv.layers.length : 0; }});
      Object.keys(LAYER_RECORDS || {{}}).forEach(ln => {{
        const alreadyListed = (DATA_CATALOG || []).some(srv =>
          (srv.layers || []).some(l => l.title === ln || l.name === ln)
        );
        if (!alreadyListed) total += 1;
      }});
      return total;
    }}

    function updateCatalogButtonLabel() {{
      const btn = document.getElementById('btn-map-catalog');
      if (!btn) return;
      const cnt = totalCatalogLayerCount();
      btn.textContent = (cnt > 0 ? t('html_catalog_btn_count', {{ count: cnt }}) : t('html_catalog_btn')) + ' ▾';
    }}

    function _parseOgcCapabilitiesXml(xmlText, serviceType) {{
      if (typeof DOMParser === 'undefined' || !xmlText) return [];
      const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
      const nodes = doc.getElementsByTagName('*');
      const found = [];
      const seen = new Set();
      if (String(serviceType || 'wfs').toLowerCase() === 'wms') {{
        for (let i = 0; i < nodes.length; i++) {{
          if (nodes[i].localName !== 'Layer') continue;
          let name = '', title = '';
          for (let j = 0; j < nodes[i].children.length; j++) {{
            const c = nodes[i].children[j];
            if (c.localName === 'Name' && !name) name = (c.textContent || '').trim();
            if (c.localName === 'Title' && !title) title = (c.textContent || '').trim();
          }}
          if (name && !seen.has(name)) {{
            seen.add(name);
            found.push({{ name, title: title || name, service_type: 'wms' }});
          }}
        }}
      }} else {{
        for (let i = 0; i < nodes.length; i++) {{
          if (nodes[i].localName !== 'FeatureType') continue;
          let name = '', title = '';
          for (let j = 0; j < nodes[i].children.length; j++) {{
            const c = nodes[i].children[j];
            if (c.localName === 'Name') name = (c.textContent || '').trim();
            if (c.localName === 'Title') title = (c.textContent || '').trim();
          }}
          if (name && !seen.has(name)) {{
            seen.add(name);
            found.push({{ name, title: title || name, service_type: 'wfs' }});
          }}
        }}
      }}
      found.sort((a, b) => a.title.localeCompare(b.title));
      return found;
    }}

    async function loadCatalogCapabilities(forceAll) {{
      if (!DATA_CATALOG.length) initDataCatalog();
      CATALOG_CAP_LOADING = true;
      renderDataCatalogDrawer();
      const targets = forceAll
        ? DATA_CATALOG.filter(s => s && s.url && (s.service_type === 'wfs' || s.service_type === 'wms'))
        : DATA_CATALOG.filter(s => s && s.url && s.url.includes('eelis'));
      await Promise.all(targets.map(async (srv) => {{
        const stype = String(srv.service_type || 'wfs').toLowerCase();
        const sep = srv.url.includes('?') ? '&' : '?';
        const capUrl = stype === 'wms'
          ? `${{srv.url}}${{sep}}service=WMS&request=GetCapabilities`
          : `${{srv.url}}${{sep}}service=WFS&version=2.0.0&request=GetCapabilities`;
        try {{
          const resp = await fetch(capUrl);
          if (!resp.ok) return;
          const xmlText = await resp.text();
          const parsed = _parseOgcCapabilitiesXml(xmlText, stype);
          if (parsed.length > 0) {{
            srv.layers = parsed.map(x => ({{
              name: x.name,
              title: x.title || x.name,
              service_type: stype,
              crs: srv.crs || 'EPSG:3301',
            }}));
            if (srv.url.includes('eelis')) {{
              EELIS_CATALOG.length = 0;
              parsed.forEach(x => EELIS_CATALOG.push({{ name: x.name, title: x.title }}));
              EELIS_CAPS_LOADED = true;
              EELIS_CAPS_COUNT = parsed.length;
            }}
          }}
        }} catch (_err) {{}}
      }}));
      CATALOG_CAP_LOADING = false;
      EELIS_CAPS_LOADED = true;
      EELIS_CAPS_COUNT = totalCatalogLayerCount();
      updateCatalogButtonLabel();
      const catDrawer = document.getElementById('map-catalog-drawer');
      if (catDrawer && catDrawer.style.display === 'flex') {{
        renderDataCatalogListOnly();
      }}
    }}

    function toggleMapCatalogPanel() {{
      const drawer = document.getElementById('map-catalog-drawer');
      if (!drawer) return;
      const show = drawer.style.display === 'none' || !drawer.style.display;
      if (show) {{
        const layDrawer = document.getElementById('map-layers-drawer');
        if (layDrawer) layDrawer.style.display = 'none';
        if (!DATA_CATALOG.length) initDataCatalog();
        renderDataCatalogDrawer();
      }}
      drawer.style.display = show ? 'flex' : 'none';
      const btn = document.getElementById('btn-map-catalog');
      if (btn && btn.classList) btn.classList.toggle('active', show);
      if (map) setTimeout(() => map.invalidateSize(), 40);
    }}

    function renderDataCatalogDrawer() {{
      const drawer = document.getElementById('map-catalog-drawer');
      if (!drawer) return;
      if (!DATA_CATALOG.length) initDataCatalog();
      drawer.innerHTML = '';

      const activeLayerNames = new Set(orderedMapLayerNames());
      const q = String(CATALOG_SEARCH_QUERY || '').trim().toLowerCase();

      // 1. Controls row: Search + Source filter + Sync + Add Data button
      const ctrlRow = document.createElement('div');
      ctrlRow.className = 'cat-controls-row';

      const searchInp = document.createElement('input');
      searchInp.id = 'map-catalog-search';
      searchInp.type = 'search';
      searchInp.placeholder = t('html_catalog_search_ph');
      searchInp.value = CATALOG_SEARCH_QUERY;
      searchInp.oninput = (ev) => {{
        CATALOG_SEARCH_QUERY = ev.target.value || '';
        renderDataCatalogListOnly();
      }};
      ctrlRow.appendChild(searchInp);

      const srcSel = document.createElement('select');
      srcSel.id = 'map-catalog-source-filter';
      const optAll = document.createElement('option');
      optAll.value = '__all__';
      optAll.textContent = t('html_catalog_all_sources');
      srcSel.appendChild(optAll);
      const optAdded = document.createElement('option');
      optAdded.value = '__inmap__';
      optAdded.textContent = t('html_catalog_source_added');
      srcSel.appendChild(optAdded);
      DATA_CATALOG.forEach(srv => {{
        const o = document.createElement('option');
        o.value = srv.id;
        o.textContent = `${{srv.name}} (${{(srv.layers || []).length}})`;
        srcSel.appendChild(o);
      }});
      srcSel.value = CATALOG_SOURCE_FILTER;
      srcSel.onchange = (ev) => {{
        CATALOG_SOURCE_FILTER = ev.target.value || '__all__';
        renderDataCatalogListOnly();
      }};
      ctrlRow.appendChild(srcSel);

      const refBtn = document.createElement('button');
      refBtn.type = 'button';
      refBtn.className = 'btn-mini-icon';
      refBtn.title = t('html_catalog_refresh_tip');
      refBtn.textContent = CATALOG_CAP_LOADING ? '⏳' : '🔄';
      refBtn.disabled = Boolean(CATALOG_CAP_LOADING);
      refBtn.onclick = () => loadCatalogCapabilities(true);
      ctrlRow.appendChild(refBtn);

      const addToggleBtn = document.createElement('button');
      addToggleBtn.type = 'button';
      addToggleBtn.className = 'btn-mini-icon' + (CATALOG_ADD_OPEN ? ' active' : '');
      addToggleBtn.textContent = t('html_catalog_add_data_btn');
      addToggleBtn.onclick = () => {{
        CATALOG_ADD_OPEN = !CATALOG_ADD_OPEN;
        renderDataCatalogDrawer();
      }};
      ctrlRow.appendChild(addToggleBtn);
      drawer.appendChild(ctrlRow);

      // 2. Collapsible "Add Additional Data" panel (OGC WFS/WMS URL or Local GeoJSON/CSV)
      if (CATALOG_ADD_OPEN) {{
        const addBox = document.createElement('div');
        addBox.id = 'cat-add-data-panel';
        addBox.className = 'cat-add-panel';
        addBox.style.display = 'flex';

        const tabsRow = document.createElement('div');
        tabsRow.className = 'cat-add-tabs';
        ['ogc', 'file'].forEach(tabKey => {{
          const tb = document.createElement('button');
          tb.type = 'button';
          tb.className = 'btn-mini-icon' + (CATALOG_ADD_TAB === tabKey ? ' active' : '');
          tb.textContent = t(tabKey === 'ogc' ? 'html_catalog_tab_ogc' : 'html_catalog_tab_file');
          tb.onclick = () => {{ CATALOG_ADD_TAB = tabKey; renderDataCatalogDrawer(); }};
          tabsRow.appendChild(tb);
        }});
        addBox.appendChild(tabsRow);

        if (CATALOG_ADD_TAB === 'ogc') {{
          const r1 = document.createElement('div');
          r1.className = 'cat-add-row';
          const tpSel = document.createElement('select');
          tpSel.id = 'cat-ogc-type';
          tpSel.style.maxWidth = '78px';
          ['wfs', 'wms'].forEach(k => {{
            const op = document.createElement('option');
            op.value = k; op.textContent = k.toUpperCase();
            tpSel.appendChild(op);
          }});
          const urlInp = document.createElement('input');
          urlInp.id = 'cat-ogc-url';
          urlInp.type = 'url';
          urlInp.placeholder = t('html_catalog_ogc_url_ph');
          r1.appendChild(tpSel);
          r1.appendChild(urlInp);
          addBox.appendChild(r1);

          const r2 = document.createElement('div');
          r2.className = 'cat-add-row';
          const nameInp = document.createElement('input');
          nameInp.id = 'cat-ogc-name';
          nameInp.type = 'text';
          nameInp.placeholder = t('html_catalog_ogc_name_ph');
          const lyrInp = document.createElement('input');
          lyrInp.id = 'cat-ogc-layer';
          lyrInp.type = 'text';
          lyrInp.placeholder = t('html_catalog_ogc_layer_ph');
          const discBtn = document.createElement('button');
          discBtn.type = 'button';
          discBtn.className = 'btn-mini-icon';
          discBtn.textContent = t('html_catalog_discover_btn');
          discBtn.onclick = () => discoverOrAddCustomOgcService(true);
          const addOgcBtn = document.createElement('button');
          addOgcBtn.type = 'button';
          addOgcBtn.className = 'btn-mini-icon';
          addOgcBtn.textContent = t('html_catalog_add_ogc_btn');
          addOgcBtn.onclick = () => discoverOrAddCustomOgcService(false);
          r2.appendChild(nameInp);
          r2.appendChild(lyrInp);
          r2.appendChild(discBtn);
          r2.appendChild(addOgcBtn);
          addBox.appendChild(r2);
        }} else {{
          const lbl = document.createElement('div');
          lbl.style.fontSize = '0.72rem';
          lbl.style.color = 'var(--text-secondary)';
          lbl.textContent = t('html_catalog_file_lbl');
          addBox.appendChild(lbl);

          const rf = document.createElement('div');
          rf.className = 'cat-add-row';
          const fileInp = document.createElement('input');
          fileInp.id = 'cat-local-file-input';
          fileInp.type = 'file';
          fileInp.accept = '.geojson,.json,.csv,.tsv,.txt';
          const lnInp = document.createElement('input');
          lnInp.id = 'cat-local-layer-name';
          lnInp.type = 'text';
          lnInp.placeholder = t('html_catalog_file_name_ph');
          const goFileBtn = document.createElement('button');
          goFileBtn.type = 'button';
          goFileBtn.className = 'btn-mini-icon';
          goFileBtn.textContent = t('html_catalog_file_btn');
          goFileBtn.onclick = () => addLocalDataFileToMap();
          rf.appendChild(fileInp);
          rf.appendChild(lnInp);
          rf.appendChild(goFileBtn);
          addBox.appendChild(rf);
        }}

        if (CATALOG_ADD_MSG) {{
          const msgDiv = document.createElement('div');
          msgDiv.id = 'cat-add-status-msg';
          msgDiv.style.fontSize = '0.72rem';
          msgDiv.style.color = CATALOG_ADD_MSG.startsWith('✓') ? 'var(--accent-emerald)' : 'var(--accent-amber)';
          msgDiv.textContent = CATALOG_ADD_MSG;
          addBox.appendChild(msgDiv);
        }}
        drawer.appendChild(addBox);
      }}

      // 3. Status metadata & scrollable grouped layer list
      const metaRow = document.createElement('div');
      metaRow.className = 'cat-controls-meta';
      const metaLeft = document.createElement('span');
      metaLeft.id = 'map-catalog-meta-txt';
      metaRow.appendChild(metaLeft);
      drawer.appendChild(metaRow);

      const listEl = document.createElement('div');
      listEl.id = 'map-catalog-list';
      listEl.className = 'cat-list-scroll';
      drawer.appendChild(listEl);
      renderDataCatalogListOnly();
    }}

    function renderDataCatalogListOnly() {{
      const listEl = document.getElementById('map-catalog-list');
      const metaEl = document.getElementById('map-catalog-meta-txt');
      if (!listEl) return;
      listEl.innerHTML = '';

      const q = String(CATALOG_SEARCH_QUERY || '').trim().toLowerCase();
      const srcFilter = String(CATALOG_SOURCE_FILTER || '__all__');
      const activeSet = new Set(orderedMapLayerNames());
      const groups = [];
      let totalAvail = 0;

      DATA_CATALOG.forEach((srv, srvIdx) => {{
        const srvLayers = Array.isArray(srv.layers) ? srv.layers : [];
        totalAvail += srvLayers.length;
        if (srcFilter !== '__all__' && srcFilter !== '__inmap__' && srv.id !== srcFilter) return;
        const matched = [];
        srvLayers.forEach((lyr, lyrIdx) => {{
          const title = String(lyr.title || lyr.name || '');
          const name = String(lyr.name || '');
          const inMap = activeSet.has(title) || activeSet.has(name);
          if (srcFilter === '__inmap__' && !inMap) return;
          if (q) {{
            const hay = `${{title}} ${{name}} ${{srv.name}} ${{lyr.service_type || srv.service_type}}`.toLowerCase();
            if (!hay.includes(q)) return;
          }}
          matched.push({{ srv, srvIdx, lyr, lyrIdx, inMap }});
        }});
        if (matched.length) groups.push({{ title: srv.name, items: matched }});
      }});

      // Include any dynamic local/file layers already loaded into LAYER_RECORDS not listed under a server
      const localItems = [];
      Object.keys(LAYER_RECORDS || {{}}).forEach(ln => {{
        const listed = DATA_CATALOG.some(s => (s.layers || []).some(l => l.title === ln || l.name === ln));
        if (listed) return;
        totalAvail += 1;
        if (srcFilter !== '__all__' && srcFilter !== '__inmap__') return;
        const inMap = activeSet.has(ln);
        if (srcFilter === '__inmap__' && !inMap) return;
        if (q && !`${{ln}} local fail geojson csv`.toLowerCase().includes(q)) return;
        localItems.push({{
          srv: {{ name: t('html_catalog_source_added'), url: '', service_type: 'file' }},
          srvIdx: -1,
          lyr: {{ name: ln, title: ln, service_type: 'file' }},
          lyrIdx: -1,
          inMap,
        }});
      }});
      if (localItems.length) groups.unshift({{ title: t('html_catalog_source_added'), items: localItems }});

      const totalMatched = groups.reduce((acc, g) => acc + g.items.length, 0);
      const maxRender = q ? 120 : 60;
      let rendered = 0;

      groups.forEach(grp => {{
        if (rendered >= maxRender) return;
        const gh = document.createElement('div');
        gh.className = 'cat-group-hdr';
        gh.textContent = `${{grp.title}} (${{grp.items.length}})`;
        listEl.appendChild(gh);

        for (let i = 0; i < grp.items.length && rendered < maxRender; i++) {{
          const it = grp.items[i];
          rendered++;
          const row = document.createElement('div');
          row.className = 'cat-item-row';

          const info = document.createElement('div');
          info.className = 'cat-item-main';
          const titleEl = document.createElement('div');
          titleEl.className = 'cat-item-title';
          titleEl.textContent = it.lyr.title || it.lyr.name;
          titleEl.title = `${{it.lyr.title || ''}} (${{it.lyr.name || ''}})`;
          const subEl = document.createElement('div');
          subEl.className = 'cat-item-sub';
          subEl.textContent = it.lyr.name;
          info.appendChild(titleEl);
          if (it.lyr.name && it.lyr.name !== it.lyr.title) info.appendChild(subEl);

          const pill = document.createElement('span');
          pill.className = 'cat-type-pill';
          pill.textContent = String(it.lyr.service_type || it.srv.service_type || 'WFS').toUpperCase();

          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'btn-mini-icon' + (it.inMap ? ' active' : '');
          btn.textContent = it.inMap ? t('html_catalog_in_map') : t('html_catalog_add_layer');
          btn.onclick = () => {{
            if (it.inMap) {{
              MAP_LAYER_VISIBILITY[it.lyr.title] = true;
              MAP_LAYER_VISIBILITY[it.lyr.name] = true;
              if (LAYER_RECORDS[it.lyr.title] || LAYER_RECORDS[it.lyr.name]) {{
                const keyName = LAYER_RECORDS[it.lyr.title] ? it.lyr.title : it.lyr.name;
                zoomToLayerExtent(keyName);
              }}
              renderAll({{ skipAutoZoom: true }});
            }} else {{
              addCatalogItemToMap(it.srvIdx, it.lyrIdx);
            }}
          }};

          row.appendChild(info);
          row.appendChild(pill);
          row.appendChild(btn);
          listEl.appendChild(row);
        }}
      }});

      if (!totalMatched) {{
        const empty = document.createElement('div');
        empty.style.opacity = '0.72';
        empty.style.padding = '8px 4px';
        empty.textContent = t('html_catalog_empty');
        listEl.appendChild(empty);
      }} else if (totalMatched > rendered) {{
        const hint = document.createElement('div');
        hint.style.opacity = '0.75';
        hint.style.fontSize = '0.71rem';
        hint.style.padding = '4px';
        hint.textContent = t('html_catalog_more_hint', {{ shown: rendered, total: totalMatched }});
        listEl.appendChild(hint);
      }}
      if (metaEl) {{
        metaEl.textContent = t('html_catalog_status', {{ shown: totalMatched, total: totalAvail }});
      }}
    }}

    function zoomToLayerExtent(layerName) {{
      if (!map || !layerName || typeof safeFitBounds !== 'function') return;
      const pts = [];
      (LAYER_RECORDS[layerName] || []).forEach(r => {{
        const bb = getFeatureBbox(layerName, String(r._feature_id));
        if (bb && bb.length === 4) pts.push([bb[1], bb[0]], [bb[3], bb[2]]);
        else if (r._lat !== undefined && r._lon !== undefined) pts.push([Number(r._lat), Number(r._lon)]);
      }});
      if (pts.length) safeFitBounds(pts, {{ padding: [24, 24], maxZoom: 13 }});
    }}

    async function addCatalogItemToMap(srvIdx, lyrIdx) {{
      const srv = DATA_CATALOG[srvIdx];
      const lyr = srv && srv.layers ? srv.layers[lyrIdx] : null;
      if (!srv || !lyr) return;
      const stype = String(lyr.service_type || srv.service_type || 'wfs').toLowerCase();
      const label = lyr.title || lyr.name;
      const typename = lyr.name;
      const baseUrl = srv.url;
      const sep = baseUrl.includes('?') ? '&' : '?';

      if (stype === 'wms') {{
        let svc = (BUNDLE.ogc_services || []).find(s => s.type === 'wms' && s.layers === typename && s.url === baseUrl);
        if (!svc) {{
          svc = {{
            id: 'wms_' + typename.replace(/[^a-zA-Z0-9_]/g, '_'),
            name: label,
            type: 'wms',
            url: baseUrl,
            layers: typename,
            format: 'image/png',
            version: '1.1.1',
            is_basemap: false,
            crs: srv.crs || 'EPSG:3301',
          }};
          BUNDLE.ogc_services = BUNDLE.ogc_services || [];
          BUNDLE.ogc_services.push(svc);
        }}
        if (!INITIAL_DATA_LAYER_NAMES.has(svc.name) && !INITIAL_OGC_SERVICES.some(s => s && s.name === svc.name)) {{
          DYNAMIC_ADDED_LAYERS.add(svc.name);
        }}
        if (!LAYER_RECORDS[svc.name]) LAYER_RECORDS[svc.name] = [];
        MAP_LAYER_VISIBILITY[svc.name] = true;
        const curOrder = ensureCustomMapLayerOrder().filter(n => n !== svc.name);
        curOrder.unshift(svc.name);
        CUSTOM_MAP_LAYERS = curOrder.slice();
        const mapWidget = getActiveMapWidget();
        if (mapWidget) mapWidget.map_layers = CUSTOM_MAP_LAYERS.slice();
        if (map && typeof L !== 'undefined' && L.tileLayer && typeof L.tileLayer.wms === 'function') {{
          const dynWmsOpts = {{
            version: '1.1.1',
            layers: typename,
            format: 'image/png',
            transparent: true,
            attribution: _deriveWmsAttribution(baseUrl, label || typename)
          }};
          if (_isCorsSafeWmsUrl(baseUrl)) dynWmsOpts.crossOrigin = 'anonymous';
          const wmsLyr = L.tileLayer.wms(baseUrl, dynWmsOpts);
          LAYER_WMS_OVERLAYS[svc.name] = wmsLyr;
          if (!LAYER_OVERLAYS[svc.name]) LAYER_OVERLAYS[svc.name] = L.layerGroup().addTo(map);
          wmsLyr.addTo(map);
        }}
        renderMapLayersDrawer();
        renderDataCatalogListOnly();
        renderAll({{ skipAutoZoom: true }});
        updateCatalogButtonLabel();
        return;
      }}

      const geojsonUrl = `${{baseUrl}}${{sep}}service=WFS&version=2.0.0&request=GetFeature&typeNames=${{encodeURIComponent(typename)}}&outputFormat=application/json&srsName=EPSG:4326&count=5000`;
      let svc = (BUNDLE.ogc_services || []).find(s => s.typename === typename || s.name === label);
      if (!svc) {{
        svc = {{
          id: 'wfs_' + typename.replace(/[^a-zA-Z0-9_]/g, '_'),
          name: label,
          type: 'wfs',
          url: baseUrl,
          geojson_url: geojsonUrl,
          typename: typename,
          crs: srv.crs || 'EPSG:3301',
          page_size: 5000,
          restrict_to_bbox: /(kataster|ky_kehtiv|etak|kitsendus)/i.test(typename),
          layer_color: /kaitseala|loodusala|hoiuala|linnuala|püsielupaik/i.test(typename + ' ' + label)
            ? '#f97316'
            : (/natura|elupaik/i.test(typename + ' ' + label) ? '#10b981' : '#0ea5e9')
        }};
        BUNDLE.ogc_services = BUNDLE.ogc_services || [];
        BUNDLE.ogc_services.push(svc);
      }}
      if (!INITIAL_DATA_LAYER_NAMES.has(svc.name) && !INITIAL_OGC_SERVICES.some(s => s && s.name === svc.name)) {{
        DYNAMIC_ADDED_LAYERS.add(svc.name);
      }}
      MAP_LAYER_VISIBILITY[svc.name] = true;
      const curOrder = ensureCustomMapLayerOrder().filter(n => n !== svc.name);
      curOrder.unshift(svc.name);
      CUSTOM_MAP_LAYERS = curOrder.slice();
      const mapWidget = getActiveMapWidget();
      if (mapWidget) mapWidget.map_layers = CUSTOM_MAP_LAYERS.slice();
      if (!LAYER_OVERLAYS[svc.name] && map) {{
        IS_SYNCING_MAP_LAYERS += 1;
        try {{
          const grp = L.layerGroup().addTo(map);
          LAYER_OVERLAYS[svc.name] = grp;
          if (layerControl && typeof layerControl.addOverlay === 'function') {{
            layerControl.addOverlay(grp, svc.name);
          }}
        }} finally {{
          IS_SYNCING_MAP_LAYERS -= 1;
        }}
        syncLeafletLayerControlActions();
      }}
      await fetchSingleWfsService(svc);
      renderMapLayersDrawer();
      renderDataCatalogListOnly();
      buildSlicers();
      renderAll({{ skipAutoZoom: true }});
      updateCatalogButtonLabel();
    }}

    async function discoverOrAddCustomOgcService(forceDiscover) {{
      const stypeEl = document.getElementById('cat-ogc-type');
      const urlEl = document.getElementById('cat-ogc-url');
      const nameEl = document.getElementById('cat-ogc-name');
      const lyrEl = document.getElementById('cat-ogc-layer');
      const rawUrl = urlEl ? String(urlEl.value || '').trim() : '';
      if (!rawUrl) return;
      const stype = stypeEl ? String(stypeEl.value || 'wfs').toLowerCase() : 'wfs';
      const srvName = (nameEl && String(nameEl.value || '').trim()) || rawUrl.replace(/^https?:\\/\\//i, '').split('/')[0];
      const explicitLayer = lyrEl ? String(lyrEl.value || '').trim() : '';

      let srv = DATA_CATALOG.find(s => s.service_type === stype && s.url.toLowerCase() === rawUrl.toLowerCase());
      if (!srv) {{
        srv = {{
          id: 'cat_custom_' + DATA_CATALOG.length,
          name: srvName,
          service_type: stype,
          url: rawUrl,
          crs: 'EPSG:3301',
          layers: [],
          custom: true,
        }};
        DATA_CATALOG.unshift(srv);
      }}

      if (explicitLayer && !forceDiscover) {{
        let idx = srv.layers.findIndex(l => l.name === explicitLayer);
        if (idx < 0) {{
          srv.layers.unshift({{
            name: explicitLayer,
            title: (nameEl && String(nameEl.value || '').trim()) || explicitLayer,
            service_type: stype,
            crs: 'EPSG:3301',
          }});
          idx = 0;
        }}
        CATALOG_ADD_MSG = `✓ ${{explicitLayer}}`;
        updateCatalogButtonLabel();
        await addCatalogItemToMap(DATA_CATALOG.indexOf(srv), idx);
        renderDataCatalogDrawer();
        return;
      }}

      const sep = rawUrl.includes('?') ? '&' : '?';
      const capUrl = stype === 'wms'
        ? `${{rawUrl}}${{sep}}service=WMS&request=GetCapabilities`
        : `${{rawUrl}}${{sep}}service=WFS&version=2.0.0&request=GetCapabilities`;
      try {{
        const resp = await fetch(capUrl);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const xmlText = await resp.text();
        const found = _parseOgcCapabilitiesXml(xmlText, stype);
        if (!found.length) throw new Error('No layers returned');
        srv.layers = found.map(x => ({{ name: x.name, title: x.title || x.name, service_type: stype, crs: 'EPSG:3301' }}));
        CATALOG_SOURCE_FILTER = srv.id;
        CATALOG_ADD_MSG = t('html_catalog_discovered', {{ count: found.length, name: srv.name }});
      }} catch (err) {{
        CATALOG_ADD_MSG = t('html_catalog_err', {{ msg: (err && err.message) ? err.message : String(err) }});
      }}
      updateCatalogButtonLabel();
      renderDataCatalogDrawer();
    }}

    function _normalizeGeoJsonCoordsWgs84(coords) {{
      if (!Array.isArray(coords)) return coords;
      if (coords.length >= 2 && typeof coords[0] === 'number' && typeof coords[1] === 'number') {{
        const x = Number(coords[0]), y = Number(coords[1]);
        if (Math.abs(x) > 1000 && Math.abs(y) > 1000000) {{
          return estonia3301ToWgs84(x, y);
        }}
        return coords;
      }}
      return coords.map(_normalizeGeoJsonCoordsWgs84);
    }}

    function _parseDelimitedRows(text) {{
      const lines = String(text || '').replace(/^\\uFEFF/, '').split(/\\r?\\n/).filter(l => l.trim() !== '');
      if (lines.length < 2) return [];
      const first = lines[0];
      const delim = (first.split(';').length > first.split(',').length)
        ? ';'
        : ((first.split('\\t').length > first.split(',').length) ? '\\t' : ',');
      const splitLine = (ln) => {{
        const out = [];
        let cur = '', inQ = false;
        for (let i = 0; i < ln.length; i++) {{
          const ch = ln[i];
          if (ch === '"') {{
            if (inQ && ln[i + 1] === '"') {{ cur += '"'; i++; }}
            else inQ = !inQ;
          }} else if (ch === delim && !inQ) {{
            out.push(cur.trim()); cur = '';
          }} else {{
            cur += ch;
          }}
        }}
        out.push(cur.trim());
        return out;
      }};
      const headers = splitLine(lines[0]);
      const rows = [];
      for (let i = 1; i < lines.length; i++) {{
        const vals = splitLine(lines[i]);
        const obj = {{}};
        headers.forEach((h, hi) => {{
          if (h) obj[h] = vals[hi] !== undefined ? vals[hi] : '';
        }});
        rows.push(obj);
      }}
      return rows;
    }}

    function ingestCustomBrowserGeoJson(layerName, features) {{
      if (!layerName || !Array.isArray(features) || !features.length) return 0;
      const normalized = features.map(f => {{
        if (!f || !f.geometry || !f.geometry.coordinates) return f;
        return Object.assign({{}}, f, {{
          geometry: Object.assign({{}}, f.geometry, {{
            coordinates: _normalizeGeoJsonCoordsWgs84(f.geometry.coordinates)
          }})
        }});
      }});
      if (!LAYER_RECORDS[layerName]) LAYER_RECORDS[layerName] = [];
      ingestGeoJsonFeatures(layerName, normalized, {{ mergeExisting: true, lod: 3 }});
      DYNAMIC_ADDED_LAYERS.add(layerName);
      MAP_LAYER_VISIBILITY[layerName] = true;
      const curOrder = ensureCustomMapLayerOrder().filter(n => n !== layerName);
      curOrder.unshift(layerName);
      CUSTOM_MAP_LAYERS = curOrder.slice();
      const mapWidget = getActiveMapWidget();
      if (mapWidget) mapWidget.map_layers = CUSTOM_MAP_LAYERS.slice();
      if (!LAYER_OVERLAYS[layerName] && map) {{
        IS_SYNCING_MAP_LAYERS += 1;
        try {{
          const grp = L.layerGroup().addTo(map);
          LAYER_OVERLAYS[layerName] = grp;
          if (layerControl && typeof layerControl.addOverlay === 'function') layerControl.addOverlay(grp, layerName);
        }} finally {{ IS_SYNCING_MAP_LAYERS -= 1; }}
        syncLeafletLayerControlActions();
      }}
      updateCatalogButtonLabel();
      renderMapLayersDrawer();
      buildSlicers();
      renderAll({{ skipAutoZoom: true }});
      zoomToLayerExtent(layerName);
      return normalized.length;
    }}

    async function addLocalDataFileToMap() {{
      const fileInp = document.getElementById('cat-local-file-input');
      const nameInp = document.getElementById('cat-local-layer-name');
      const file = fileInp && fileInp.files ? fileInp.files[0] : null;
      if (!file) return;
      const fallbackName = String(file.name || 'Lisakiht').replace(/\\.[^.]+$/, '');
      const layerName = (nameInp && String(nameInp.value || '').trim()) || fallbackName;
      try {{
        const rawText = (typeof file.text === 'function')
          ? await file.text()
          : await new Promise((res, rej) => {{
              const fr = new FileReader();
              fr.onload = () => res(String(fr.result || ''));
              fr.onerror = () => rej(fr.error || new Error('File read error'));
              fr.readAsText(file);
            }});
        let feats = [];
        if (/\\.json$/i.test(file.name) || rawText.trim().startsWith('{{') || rawText.trim().startsWith('[')) {{
          const parsed = JSON.parse(rawText);
          if (parsed && parsed.type === 'FeatureCollection' && Array.isArray(parsed.features)) feats = parsed.features;
          else if (parsed && parsed.type === 'Feature') feats = [parsed];
          else if (Array.isArray(parsed)) feats = parsed;
        }} else {{
          const rows = _parseDelimitedRows(rawText);
          if (rows.length) {{
            const cols = Object.keys(rows[0]);
            const xCol = cols.find(c => /^(lon|lng|longitude|x|east|e)$/i.test(c.trim()));
            const yCol = cols.find(c => /^(lat|latitude|y|north|n)$/i.test(c.trim()));
            if (!xCol || !yCol) throw new Error('CSV requires X/Lon & Y/Lat columns');
            rows.forEach((r, idx) => {{
              const xv = Number(String(r[xCol] || '').replace(',', '.'));
              const yv = Number(String(r[yCol] || '').replace(',', '.'));
              if (!Number.isFinite(xv) || !Number.isFinite(yv)) return;
              feats.push({{
                type: 'Feature',
                id: `${{layerName}}_${{idx}}`,
                properties: r,
                geometry: {{ type: 'Point', coordinates: [xv, yv] }}
              }});
            }});
          }}
        }}
        if (!feats.length) throw new Error('No spatial features parsed');
        const nAdded = ingestCustomBrowserGeoJson(layerName, feats);
        CATALOG_ADD_MSG = t('html_catalog_file_added', {{ count: nAdded, name: layerName }});
      }} catch (err) {{
        CATALOG_ADD_MSG = t('html_catalog_err', {{ msg: (err && err.message) ? err.message : String(err) }});
      }}
      renderDataCatalogDrawer();
    }}

    function populateEelisSelect() {{
      if (!DATA_CATALOG.length) initDataCatalog();
      renderDataCatalogDrawer();
    }}

    async function loadEelisCapabilities() {{
      return loadCatalogCapabilities(false);
    }}

    async function addSelectedEelisLayer() {{
      const eelisSrvIdx = DATA_CATALOG.findIndex(s => s && s.url && s.url.includes('eelis'));
      if (eelisSrvIdx >= 0 && DATA_CATALOG[eelisSrvIdx].layers.length) {{
        return addCatalogItemToMap(eelisSrvIdx, 0);
      }}
    }}

    function _deriveWmsAttribution(urlStr, layerName) {{
      const hay = (String(urlStr || '') + ' ' + String(layerName || '')).toLowerCase();
      if (hay.includes('maaamet') || hay.includes('ma-')) return '© Maa- ja Ruumiamet';
      if (hay.includes('envir.ee') || hay.includes('eelis')) return '© EELIS';
      if (hay.includes('pria')) return '© PRIA';
      return '© OGC WMS';
    }}

    function _isCorsSafeWmsUrl(url) {{
      const s = String(url || '').trim();
      if (!s) return false;
      if (s.startsWith('/')) return true;
      try {{
        const baseHref = (typeof window !== 'undefined' && window.location && /^https?:/.test(window.location.protocol))
          ? window.location.href
          : 'https://localhost';
        const u = new URL(s, baseHref);
        if (/(\\.|^)maaamet\\.ee$/i.test(u.hostname)) return true;
        if (typeof window !== 'undefined' && window.location && /^https?:/.test(window.location.protocol) && u.origin === window.location.origin) return true;
      }} catch (_e) {{}}
      return false;
    }}

    function initMap() {{
      const estoniaCrs = (typeof L !== 'undefined' && L.Proj && typeof proj4 !== 'undefined')
        ? new L.Proj.CRS(
            'EPSG:3301',
            '+proj=lcc +lat_1=59.33333333333334 +lat_2=58 +lat_0=57.51755393055556 +lon_0=24 +x_0=500000 +y_0=6375000 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs',
            {{
              resolutions: [4000, 2000, 1000, 500, 250, 125, 62.5, 31.25, 15.625, 7.8125, 3.90625, 1.953125, 0.9765625, 0.48828125, 0.244140625],
              origin: [40500, 5993000],
              bounds: L.bounds([40500, 5993000], [1064500, 7017000])
            }}
          )
        : L.CRS.EPSG3857;

      const mapWidget = getActiveMapWidget();
      const initState = _activateMapWidgetState(mapWidget);
      HOME_MAP_VIEW = Object.assign({{}}, initState.homeView);
      const initLat = Number(HOME_MAP_VIEW.lat || 58.758);
      const initLon = Number(HOME_MAP_VIEW.lon || 23.825);
      const initZoom = Number(HOME_MAP_VIEW.zoom !== undefined ? HOME_MAP_VIEW.zoom : 7);
      LEGEND_COLLAPSED = Boolean(initState.legendCollapsed);
      // "Kihid" layer menu on the map always starts minimized by default
      LAYER_CONTROL_COLLAPSED = true;

      const initSens = Math.max(1, Math.min(100, Number(initState.scrollSens || MAP_SCROLL_SENSITIVITY || 35)));
      const initPxPerZoom = Math.round(480 - (initSens / 100) * 400);
      const initZoomDelta = initSens <= 40 ? 0.25 : (initSens <= 75 ? 0.5 : 1);
      const initDecel = Math.round(1800 + (initSens / 100) * 2400);

      map = L.map('map-canvas', {{
        crs: estoniaCrs,
        preferCanvas: true,
        attributionControl: true,
        minZoom: 0,
        maxZoom: 14,
        zoomSnap: 0.02,
        zoomDelta: initZoomDelta,
        wheelPxPerZoomLevel: initPxPerZoom,
        wheelDebounceTime: 60,
        inertia: true,
        inertiaDeceleration: initDecel
      }}).setView([initLat, initLon], initZoom);
      applyMapScrollSensitivity(initSens);
      if (HOME_MAP_VIEW.bounds && HOME_MAP_VIEW.bounds.every(Number.isFinite)) {{
        IS_PROGRAMMATIC_MOVE = true;
        try {{
          map.fitBounds(
            [[HOME_MAP_VIEW.bounds[0], HOME_MAP_VIEW.bounds[1]], [HOME_MAP_VIEW.bounds[2], HOME_MAP_VIEW.bounds[3]]],
            {{ padding: [6, 6], maxZoom: 14, animate: false }}
          );
        }} finally {{
          setTimeout(() => {{ IS_PROGRAMMATIC_MOVE = false; }}, 120);
        }}
      }}
      if (map.attributionControl) {{
        if (typeof map.attributionControl.setPrefix === 'function') {{
          map.attributionControl.setPrefix(false);
        }}
        if (typeof map.attributionControl._update === 'function') {{
          const _origAttrUpdate = map.attributionControl._update.bind(map.attributionControl);
          map.attributionControl._update = function() {{
            _origAttrUpdate();
            if (!this._container) return;
            const rawHtml = String(this._container.innerHTML || '');
            if (!rawHtml) return;
            const parts = rawHtml.split(/\\s*[,|]\\s*|\\s+\\/\\s+/);
            const seen = new Set();
            const out = [];
            parts.forEach(p => {{
              const clean = p.replace(/^(?:\\x26copy;|©)\\s*/i, '').trim();
              if (!clean) return;
              const norm = clean.toLowerCase().replace(/\\s+/g, ' ');
              if (seen.has(norm)) return;
              seen.add(norm);
              const keepPrefix = (/^(?:\\x26copy;|©)/i.test(p.trim()) && out.length === 0) ? '© ' : '';
              out.push(keepPrefix + clean);
            }});
            if (out.length) {{
              this._container.innerHTML = out.join(' · ');
            }}
          }};
          map.attributionControl._update();
        }}
      }}
      if (typeof L.canvas === 'function') {{
        vectorCanvasRenderer = L.canvas({{ padding: 0.5 }});
      }}

      const mapCardEl = document.querySelector('.map-card');
      if (mapCardEl && typeof ResizeObserver !== 'undefined') {{
        new ResizeObserver(() => {{ if (map) map.invalidateSize(); }}).observe(mapCardEl);
      }}

      const baseMaps = {{}};
      const overlays = {{}};
      const baseLayerIds = {{}};

      // Attach configured Estonian Maa- ja Ruumiamet & corporate WMS layers (unified block; CIR removed #8)
      (BUNDLE.ogc_services || []).forEach(svc => {{
        if (svc.type === 'wms' && svc.url) {{
          const rawLyr = String(svc.layers || '');
          if (rawLyr.toLowerCase() === 'cir_ngr' || /cir\\s*infrapuna/i.test(svc.name || '')) return;
          const normLayers = rawLyr === 'MA-FOTOKAART' ? 'EESTIFOTO' : rawLyr;
          const normUrl = (normLayers === 'EESTIFOTO' || normLayers === 'HYBRID')
            ? 'https://kaart.maaamet.ee/wms/fotokaart'
            : svc.url;
          const normFmt = normLayers === 'EESTIFOTO'
            ? 'image/jpeg'
            : (svc.format || (Boolean(svc.is_basemap) ? 'image/jpeg' : 'image/png'));
          const isBase = Boolean(svc.is_basemap);
          const wmsOpts = {{
            version: svc.version || '1.1.1',
            layers: normLayers,
            format: normFmt,
            transparent: !isBase,
            styles: svc.styles || '',
            attribution: _deriveWmsAttribution(normUrl, svc.name || normLayers)
          }};
          if (_isCorsSafeWmsUrl(normUrl)) wmsOpts.crossOrigin = 'anonymous';
          const wmsLayer = L.tileLayer.wms(normUrl, wmsOpts);
          if (isBase) {{
            baseMaps[svc.name] = wmsLayer;
            baseLayerIds[normLayers] = wmsLayer;
          }} else {{
            overlays[svc.name] = wmsLayer;
            attachMapLayerLoaderEvents(wmsLayer, 'ogc:' + (svc.name || normLayers), svc.name || normLayers);
            if (!/hübriid|hybrid/i.test(svc.name)) wmsLayer.addTo(map);
          }}
        }}
      }});

      // Default Estonian Maa- ja Ruumiamet WMS block (Hallkaart, Põhikaart, Ortofoto + Hübriidkaart) (#8)
      if (Object.keys(baseMaps).length === 0) {{
        baseMaps['Maa- ja Ruumiamet Hallkaart'] = L.tileLayer.wms('https://kaart.maaamet.ee/wms/hallkaart', {{
          version: '1.1.1', layers: 'MA-HALLKAART', format: 'image/png', transparent: false,
          crossOrigin: 'anonymous',
          attribution: '© Maa- ja Ruumiamet'
        }});
        baseLayerIds['MA-HALLKAART'] = baseMaps['Maa- ja Ruumiamet Hallkaart'];
        baseMaps['Maa- ja Ruumiamet Põhikaart'] = L.tileLayer.wms('https://kaart.maaamet.ee/wms/kaart', {{
          version: '1.1.1', layers: 'MA-KAART', format: 'image/png', transparent: false,
          crossOrigin: 'anonymous',
          attribution: '© Maa- ja Ruumiamet'
        }});
        baseLayerIds['MA-KAART'] = baseMaps['Maa- ja Ruumiamet Põhikaart'];
        baseMaps['Maa- ja Ruumiamet Fotokaart (Ortofoto)'] = L.tileLayer.wms('https://kaart.maaamet.ee/wms/fotokaart', {{
          version: '1.1.1', layers: 'EESTIFOTO', format: 'image/jpeg', transparent: false,
          crossOrigin: 'anonymous',
          attribution: '© Maa- ja Ruumiamet'
        }});
        baseLayerIds['EESTIFOTO'] = baseMaps['Maa- ja Ruumiamet Fotokaart (Ortofoto)'];
      }}
      if (!Object.keys(overlays).some(k => /hübriid|hybrid/i.test(k))) {{
        overlays['Maa- ja Ruumiamet Hübriidkaart'] = L.tileLayer.wms('https://kaart.maaamet.ee/wms/fotokaart', {{
          version: '1.1.1', layers: 'HYBRID', format: 'image/png', transparent: true,
          crossOrigin: 'anonymous',
          attribution: '© Maa- ja Ruumiamet'
        }});
      }}

      let desiredBmId = (initState && initState.basemapId) || (mapWidget && mapWidget.map_basemap) || '';
      if (desiredBmId === 'MA-FOTOKAART') desiredBmId = 'EESTIFOTO';
      if (desiredBmId === 'cir_ngr') desiredBmId = 'MA-HALLKAART';
      const firstBase = baseLayerIds[desiredBmId] || Object.values(baseMaps)[0];
      Object.assign(BASE_MAP_LAYERS, baseMaps);
      Object.assign(BASE_MAP_LAYERS_BY_ID, baseLayerIds);
      Object.assign(STATIC_WMS_OVERLAYS, overlays);
      DEFAULT_BASEMAP_LAYER = firstBase || null;
      INITIAL_LAYER_ORDER = (mapWidget && Array.isArray(mapWidget.map_layers) && mapWidget.map_layers.length)
        ? mapWidget.map_layers.slice()
        : null;
      const hybridEntry = Object.entries(overlays).find(([k]) => /hübriid|hybrid/i.test(k));
      HYBRID_LAYER_REF = hybridEntry ? hybridEntry[1] : null;
      INITIAL_HYBRID_ENABLED = Boolean(HYBRID_LAYER_REF && map.hasLayer(HYBRID_LAYER_REF));
      Object.entries(baseMaps).forEach(([bmName, bmLayer]) => {{
        attachMapLayerLoaderEvents(bmLayer, 'basemap:' + bmName, bmName);
      }});
      if (_isFramedSandboxEnv() && BUNDLE.packaged_basemap && BUNDLE.packaged_basemap.data_uri) {{
        ensurePackagedBasemapOverlay('SharePoint iframe sandbox');
      }}
      if (firstBase) firstBase.addTo(map);
      const mapHdrInit = document.getElementById('map-header-title');
      if (mapHdrInit) {{
        const tInit = (mapWidget ? localizedTitle(mapWidget) : '') || t('html_map_header');
        mapHdrInit.textContent = tInit;
        mapHdrInit.title = tInit;
      }}

      // Create toggleable GeoJSON layer groups for all layers, and only register active page map layers (#6)
      ensureLayerOverlaysInitialized();
      const activeInitLayers = orderedMapLayerNames();
      activeInitLayers.forEach(ln => {{
        const grp = LAYER_OVERLAYS[ln];
        if (!grp) return;
        if (MAP_LAYER_VISIBILITY[ln] !== false) grp.addTo(map);
        overlays[ln] = grp;
        _LAYER_CONTROL_TRACKED.add(ln);
      }});

      layerControl = L.control.layers(baseMaps, overlays, {{ collapsed: false, position: 'topright' }}).addTo(map);
      if (layerControl && typeof layerControl.getContainer === 'function' && typeof L.DomUtil !== 'undefined') {{
        const lcEl = layerControl.getContainer();
        if (lcEl && typeof lcEl.insertBefore === 'function') {{
          const bar = document.createElement('div');
          bar.className = 'leaflet-control-layers-collapse-bar';
          bar.innerHTML = `<span id="leaflet-layers-panel-title">${{t('html_layers_panel')}}</span><button type="button" class="panel-right-toggle-btn leaflet-layer-collapse-btn" title="${{LAYER_CONTROL_COLLAPSED ? t('html_expand_panel') : t('html_collapse_panel')}}">${{LAYER_CONTROL_COLLAPSED ? '⟨' : '⟩'}}</button>`;
          lcEl.insertBefore(bar, lcEl.firstChild || null);
          if (lcEl.classList) lcEl.classList.toggle('leaflet-right-collapsed', Boolean(LAYER_CONTROL_COLLAPSED));
          const colBtn = bar.querySelector('.leaflet-layer-collapse-btn');
          bar.style.cursor = 'pointer';
          bar.onclick = ev => {{
            if (ev && ev.stopPropagation) ev.stopPropagation();
            toggleLayerControlCollapsed();
          }};
          if (colBtn) {{
            colBtn.onclick = ev => {{
              if (ev && ev.stopPropagation) ev.stopPropagation();
              toggleLayerControlCollapsed();
            }};
          }}
          if (L.DomEvent && typeof L.DomEvent.disableClickPropagation === 'function') {{
            L.DomEvent.disableClickPropagation(bar);
          }}
        }}
      }}
      syncLeafletLayerControlActions();

      if (typeof map.on === 'function') {{
        map.on('overlayadd', ev => {{
          if (IS_SYNCING_MAP_LAYERS > 0 || !ev || !ev.layer) return;
          const matchName = Object.keys(LAYER_OVERLAYS).find(ln => LAYER_OVERLAYS[ln] === ev.layer);
          if (!matchName) return;
          MAP_LAYER_VISIBILITY[matchName] = true;
          renderMapLayersDrawer();
          scheduleMapRender({{ skipAutoZoom: true }});
        }});
        map.on('overlayremove', ev => {{
          if (IS_SYNCING_MAP_LAYERS > 0 || !ev || !ev.layer) return;
          const matchName = Object.keys(LAYER_OVERLAYS).find(ln => LAYER_OVERLAYS[ln] === ev.layer);
          if (!matchName) return;
          MAP_LAYER_VISIBILITY[matchName] = false;
          if (LAYER_WMS_OVERLAYS[matchName] && map.hasLayer && map.hasLayer(LAYER_WMS_OVERLAYS[matchName])) {{
            IS_SYNCING_MAP_LAYERS += 1;
            try {{ map.removeLayer(LAYER_WMS_OVERLAYS[matchName]); }} finally {{ IS_SYNCING_MAP_LAYERS -= 1; }}
          }}
          renderMapLayersDrawer();
          scheduleMapRender({{ skipAutoZoom: true }});
        }});
      }}
      if (L.control && L.control.scale) {{
        L.control.scale({{ metric: true, imperial: false, position: 'bottomleft' }}).addTo(map);
      }}
      if (typeof L.DomUtil !== 'undefined' && typeof L.control === 'function') {{
        const homeCtrl = L.control({{ position: 'topleft' }});
        homeCtrl.onAdd = () => {{
          const wrap = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
          const a = L.DomUtil.create('a', 'leaflet-home-btn', wrap);
          a.href = '#';
          a.title = t('html_reset_home');
          a.innerHTML = '🏠';
          a.onclick = ev => {{
            if (ev && ev.preventDefault) ev.preventDefault();
            resetMapHomeView();
            return false;
          }};
          return wrap;
        }};
        homeCtrl.addTo(map);
      }}

      legendControl = L.control({{ position: 'bottomright' }});
      legendControl.onAdd = () => {{
        const div = L.DomUtil.create('div', 'map-legend');
        div.innerHTML = legendHtml();
        if (L.DomEvent && typeof L.DomEvent.disableClickPropagation === 'function') {{
          L.DomEvent.disableClickPropagation(div);
        }}
        if (L.DomEvent && typeof L.DomEvent.disableScrollPropagation === 'function') {{
          L.DomEvent.disableScrollPropagation(div);
        }}
        return div;
      }};
      legendControl.addTo(map);
      updateMapLegend();

      map.on('movestart zoomstart', () => {{
        IS_MAP_INTERACTING = true;
        if (VIEWPORT_REFRESH_TIMER) {{
          clearTimeout(VIEWPORT_REFRESH_TIMER);
          VIEWPORT_REFRESH_TIMER = null;
        }}
        if (EXTENT_REFRESH_TIMER) {{
          clearTimeout(EXTENT_REFRESH_TIMER);
          EXTENT_REFRESH_TIMER = null;
        }}
        if (MAP_RENDER_SHOW_TIMER) {{
          clearTimeout(MAP_RENDER_SHOW_TIMER);
          MAP_RENDER_SHOW_TIMER = null;
        }}
      }});

      map.on('zoomend', () => {{
        syncZoomVisibilityImmediate();
        if (typeof renderMapFeatureLabels === 'function') renderMapFeatureLabels();
      }});

      map.on('moveend', () => {{
        IS_MAP_INTERACTING = false;
        const sDenom = computeMapScaleDenominator();
        updateMapScaleBadge(sDenom, targetLodForScale(sDenom));
        saveDashboardSessionState();
        if (MAP_RENDER_OPS > 0 && !MAP_RENDER_SHOW_TIMER) {{
          MAP_RENDER_SHOW_TIMER = setTimeout(() => {{
            MAP_RENDER_SHOW_TIMER = null;
            if (MAP_RENDER_OPS > 0 && !IS_MAP_INTERACTING) _syncMapRenderLoaderDOM();
          }}, MAP_RENDER_LOADER_DELAY_MS);
        }}
        if (typeof renderMapFeatureLabels === 'function') renderMapFeatureLabels();
        if (IS_PROGRAMMATIC_MOVE) {{
          if (typeof updateMapLegend === 'function') updateMapLegend();
          return;
        }}
        if (typeof updateMapLegend === 'function') updateMapLegend();
        if (EXTENT_FILTER_ENABLED) {{
          scheduleExtentFilterRefresh();
        }} else if (!shouldSkipMinorViewportRefresh()) {{
          scheduleMapRefreshOnViewport();
        }}
      }});

      const initScale = computeMapScaleDenominator();
      updateMapScaleBadge(initScale, targetLodForScale(initScale));
      updateExtentButtonUI();
    }}

    function applyExcelJoinsToLayer(layerName, rawRecords) {{
      let records = rawRecords.map(r => Object.assign({{}}, r));
      (DASHBOARD.joins || []).forEach(jn => {{
        const targetDs = (DASHBOARD.data_sources || []).find(d => d.id === jn.target_layer_id);
        const targetName = targetDs ? targetDs.name : jn.target_layer_id;
        if (targetName !== layerName) return;

        const excelRows = EXCEL_TABLES[jn.source_table_id] || [];
        const lookup = {{}};
        excelRows.forEach(ex => {{
          const k = ex[jn.source_key_field];
          if (k !== undefined && k !== null) lookup[String(k).trim()] = ex;
        }});
        const prefix = jn.join_prefix || 'xl_';
        records.forEach(row => {{
          const tk = row[jn.target_key_field];
          const match = tk !== undefined && tk !== null ? lookup[String(tk).trim()] : null;
          if (match) {{
            Object.keys(match).forEach(col => {{
              if (col !== jn.source_key_field) {{
                row[prefix + col] = match[col];
              }}
            }});
          }}
        }});
      }});
      return records;
    }}

    function _buildPaginatedWfsUrl(baseUrl, countVal, startIdx, svc, sortField) {{
      let out = String(baseUrl || '');
      if (!out) return '';
      try {{
        const u = new URL(out);
        const isV1 = /^1\\./i.test(String(u.searchParams.get('version') || ''));
        u.searchParams.delete('count');
        u.searchParams.delete('maxFeatures');
        u.searchParams.delete('startIndex');
        u.searchParams.delete('sortBy');
        if (isV1) {{
          u.searchParams.set('maxFeatures', String(countVal));
        }} else {{
          u.searchParams.set('count', String(countVal));
        }}
        if (startIdx > 0) {{
          u.searchParams.set('startIndex', String(startIdx));
        }}
        if (sortField) {{
          u.searchParams.set('sortBy', String(sortField) + ' A');
        }}
        if (svc && svc.restrict_to_bbox === true && map && typeof map.getBounds === 'function' && !u.searchParams.has('bbox')) {{
          const b = map.getBounds();
          if (b && (!b.isValid || b.isValid())) {{
            u.searchParams.set('bbox', `${{b.getSouth()}},${{b.getWest()}},${{b.getNorth()}},${{b.getEast()}},urn:ogc:def:crs:EPSG::4326`);
          }}
        }}
        return u.toString();
      }} catch (_urlErr) {{
        let cleaned = out.replace(/([?&])(count|maxFeatures|startIndex|sortBy)=[^&]*/gi, '$1').replace(/[?&]$/, '').replace(/&&+/g, '&').replace(/\\?&/, '?');
        const sep = cleaned.includes('?') ? '&' : '?';
        const cntParam = /version=1\\./i.test(cleaned) ? 'maxFeatures' : 'count';
        let res = `${{cleaned}}${{sep}}${{cntParam}}=${{countVal}}`;
        if (startIdx > 0) res += `&startIndex=${{startIdx}}`;
        if (sortField) res += `&sortBy=${{encodeURIComponent(String(sortField) + ' A')}}`;
        if (svc && svc.restrict_to_bbox === true && map && typeof map.getBounds === 'function' && !/bbox=/i.test(res)) {{
          const b = map.getBounds();
          res += `&bbox=${{b.getSouth()}},${{b.getWest()}},${{b.getNorth()}},${{b.getEast()}},urn:ogc:def:crs:EPSG::4326`;
        }}
        return res;
      }}
    }}

    function _pickWfsSortField(features) {{
      if (!Array.isArray(features) || !features.length) return '';
      const props = (features[0] && features[0].properties) || {{}};
      const cands = ['fid', 'id', 'gid', 'objectid', 'ogc_fid', 'sys_id', 'kood', 'tunnus', 'code'];
      for (let i = 0; i < cands.length; i++) {{
        if (props[cands[i]] !== undefined && props[cands[i]] !== null) return cands[i];
      }}
      const keys = Object.keys(props);
      return keys.length ? keys[0] : '';
    }}

    async function _fetchWfsFeaturePages(baseUrl, wfsSvc, pageOpts) {{
      const opts = pageOpts || {{}};
      const rawMax = opts.maxFeatures;
      const hasFiniteCap = rawMax !== null && rawMax !== undefined && rawMax !== '' && Number.isFinite(Number(rawMax)) && Number(rawMax) > 0;
      const maxFeatures = hasFiniteCap ? Math.max(1, Number(rawMax)) : Infinity;
      const pageSize = Math.min(Math.max(100, Number(opts.pageSize || (hasFiniteCap ? Math.min(maxFeatures, 5000) : 5000))), 10000);
      const skipBboxAppend = Boolean(opts.skipBboxAppend);
      const svcName = (wfsSvc && wfsSvc.name) ? String(wfsSvc.name) : 'WFS';
      const parentSignal = opts.signal || null;
      const activeSortField = String(opts.sortField || '');

      let allFeatures = [];
      const seenFids = new Set();
      let startIdx = 0;
      let totalFeatures = 0;
      let hitCap = false;
      let networkError = false;
      let dupSkippedTotal = 0;
      while (true) {{
        if (parentSignal && parentSignal.aborted) {{
          devLog('WARN', 'WFS', `${{svcName}}: aborted by user before page at startIndex=${{startIdx}}`);
          return {{
            features: allFeatures,
            totalFeatures,
            hitCap: true,
            aborted: true,
            dupSkippedTotal,
            countMismatch: Boolean(totalFeatures > 0 && allFeatures.length < totalFeatures),
            networkError
          }};
        }}
        const remaining = Number.isFinite(maxFeatures) ? (maxFeatures - allFeatures.length) : pageSize;
        if (remaining <= 0) {{
          hitCap = true;
          break;
        }}
        const reqCount = Math.min(pageSize, remaining);
        const pageUrl = _buildPaginatedWfsUrl(baseUrl, reqCount, startIdx, skipBboxAppend ? null : wfsSvc, activeSortField);
        const tPage0 = Date.now();
        const pageCtrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        let timeoutId = null;
        let onParentAbort = null;
        if (pageCtrl) {{
          if (parentSignal && typeof parentSignal.addEventListener === 'function') {{
            onParentAbort = () => {{ try {{ pageCtrl.abort(); }} catch (_e) {{}} }};
            parentSignal.addEventListener('abort', onParentAbort, {{ once: true }});
          }}
          if (typeof setTimeout === 'function') {{
            timeoutId = setTimeout(() => {{
              devLog('WARN', 'WFS', `${{svcName}}: page timeout (45s) at startIndex=${{startIdx}}`);
              try {{ pageCtrl.abort(); }} catch (_e) {{}}
            }}, 45000);
          }}
        }}
        const fetchOpts = {{ method: 'GET', cache: 'no-store', headers: {{ 'Accept': 'application/json' }} }};
        if (wfsSvc && wfsSvc.with_credentials) fetchOpts.credentials = 'include';
        if (pageCtrl) fetchOpts.signal = pageCtrl.signal;

        let resp;
        try {{
          resp = await fetch(pageUrl, fetchOpts);
        }} catch (fetchErr) {{
          if (timeoutId && typeof clearTimeout === 'function') clearTimeout(timeoutId);
          if (parentSignal && onParentAbort && typeof parentSignal.removeEventListener === 'function') {{
            parentSignal.removeEventListener('abort', onParentAbort);
          }}
          if (parentSignal && parentSignal.aborted) {{
            return {{
              features: allFeatures,
              totalFeatures,
              hitCap: true,
              aborted: true,
              dupSkippedTotal,
              countMismatch: Boolean(totalFeatures > 0 && allFeatures.length < totalFeatures),
              networkError: true
            }};
          }}
          if (allFeatures.length > 0) {{
            devLog('ERROR', 'WFS', `${{svcName}}: network error at startIndex=${{startIdx}}: ${{fetchErr && fetchErr.message ? fetchErr.message : fetchErr}}`);
            networkError = true;
            hitCap = true;
            break;
          }}
          throw fetchErr;
        }} finally {{
          if (timeoutId && typeof clearTimeout === 'function') clearTimeout(timeoutId);
          if (parentSignal && onParentAbort && typeof parentSignal.removeEventListener === 'function') {{
            parentSignal.removeEventListener('abort', onParentAbort);
          }}
        }}
        const elapsedMs = Date.now() - tPage0;
        if (!resp.ok) {{
          devLog('ERROR', 'WFS', `${{svcName}}: HTTP ${{resp.status}} (${{elapsedMs}}ms) at startIndex=${{startIdx}}`);
          if (allFeatures.length > 0) {{
            networkError = true;
            hitCap = true;
            break;
          }}
          throw new Error('HTTP ' + resp.status);
        }}
        let geojson;
        try {{
          geojson = await resp.json();
        }} catch (jsonErr) {{
          devLog('ERROR', 'WFS', `${{svcName}}: invalid JSON at startIndex=${{startIdx}}: ${{jsonErr && jsonErr.message ? jsonErr.message : jsonErr}}`);
          if (allFeatures.length > 0) {{
            networkError = true;
            hitCap = true;
            break;
          }}
          throw jsonErr;
        }}
        const feats = (geojson && Array.isArray(geojson.features)) ? geojson.features : [];
        const reportedTotal = Number((geojson && (geojson.totalFeatures ?? geojson.numberMatched)) || 0);
        if (reportedTotal > 0) totalFeatures = reportedTotal;

        if (startIdx === 0 && typeof opts.onFirstPageMeta === 'function') {{
          const early = opts.onFirstPageMeta({{ totalFeatures, feats }});
          if (early && early.abort) return early;
        }}

        if (!feats.length) break;
        let addedInPage = 0;
        for (let fi = 0; fi < feats.length; fi++) {{
          const ft = feats[fi];
          const fidKey = (ft && ft.id !== undefined && ft.id !== null) ? String(ft.id) : '';
          if (fidKey && seenFids.has(fidKey)) {{
            dupSkippedTotal++;
            continue;
          }}
          if (fidKey) seenFids.add(fidKey);
          allFeatures.push(ft);
          addedInPage++;
        }}
        devLog('NET', 'WFS', `${{svcName}}: +${{addedInPage}} feats (page=${{feats.length}}, total=${{allFeatures.length}}/${{totalFeatures || '?'}}, ${{elapsedMs}}ms)`);
        if (addedInPage === 0) break;
        if (typeof opts.onPageProgress === 'function') {{
          const estFrac = totalFeatures > 0
            ? Math.min(0.98, allFeatures.length / Math.max(1, totalFeatures))
            : Math.min(0.92, 0.25 + (allFeatures.length / (allFeatures.length + pageSize * 1.5)));
          try {{ opts.onPageProgress({{ loaded: allFeatures.length, totalFeatures, frac: estFrac }}); }} catch (_pe) {{}}
        }}
        if (totalFeatures > 0) {{
          if (allFeatures.length >= totalFeatures) break;
        }} else if (feats.length < reqCount) {{
          break;
        }}
        startIdx += feats.length;
        if (typeof setTimeout === 'function') {{
          await new Promise(r => setTimeout(r, 0));
        }}
      }}
      const expectedTotal = (totalFeatures > 0 && Number.isFinite(maxFeatures))
        ? Math.min(totalFeatures, maxFeatures)
        : totalFeatures;
      let countMismatch = Boolean((expectedTotal > 0 && allFeatures.length < expectedTotal) && !(parentSignal && parentSignal.aborted));
      if (countMismatch && !opts._isSortedRetry && !networkError) {{
        const sf = _pickWfsSortField(allFeatures);
        if (dupSkippedTotal > 0 || sf) {{
          devLog('WARN', 'WFS', `${{svcName}}: loaded ${{allFeatures.length}}/${{expectedTotal}} features (${{dupSkippedTotal}} duplicate FIDs skipped across unsorted pages); retrying sorted fetch (sortBy=${{sf || 'default'}})...`);
          try {{
            const retryOpts = Object.assign({{}}, opts, {{
              sortField: sf,
              _isSortedRetry: true,
              pageSize: Math.min(10000, Math.max(pageSize, 1000))
            }});
            const retryRes = await _fetchWfsFeaturePages(baseUrl, wfsSvc, retryOpts);
            if (retryRes && retryRes.networkError) networkError = true;
            const rFeats = (retryRes && Array.isArray(retryRes.features)) ? retryRes.features : [];
            for (let ri = 0; ri < rFeats.length; ri++) {{
              const rf = rFeats[ri];
              const rFid = (rf && rf.id !== undefined && rf.id !== null) ? String(rf.id) : '';
              if (rFid && seenFids.has(rFid)) continue;
              if (rFid) seenFids.add(rFid);
              allFeatures.push(rf);
            }}
          }} catch (retryErr) {{
            networkError = true;
            devLog('WARN', 'WFS', `${{svcName}}: sorted retry failed: ${{retryErr && retryErr.message ? retryErr.message : retryErr}}`);
          }}
          countMismatch = Boolean(expectedTotal > 0 && allFeatures.length < expectedTotal);
          if (!countMismatch && !networkError) {{
            devLog('INFO', 'WFS', `${{svcName}}: sorted retry recovered all ${{allFeatures.length}}/${{expectedTotal}} features.`);
          }} else {{
            devLog('WARN', 'WFS', `${{svcName}}: count mismatch remains after retry (${{allFeatures.length}}/${{expectedTotal}}).`);
          }}
        }}
      }}
      if (typeof opts.onPageProgress === 'function') {{
        try {{ opts.onPageProgress({{ loaded: allFeatures.length, totalFeatures: totalFeatures || allFeatures.length, frac: 1.0 }}); }} catch (_pe2) {{}}
      }}
      return {{ features: allFeatures, totalFeatures, hitCap, aborted: false, dupSkippedTotal, countMismatch, networkError }};
    }}

    async function _fetchFullViewportGeometriesForGpkg(layerName, viewBb) {{
      if (!layerName || !Array.isArray(viewBb) || viewBb.length !== 4) return false;
      const hadRows = Array.isArray(LAYER_RECORDS[layerName]) && LAYER_RECORDS[layerName].length > 0;
      try {{
        if (HAS_PREVIEW_API) {{
          const params = new URLSearchParams();
          params.set('layer', layerName);
          params.set('zoom', '16');
          params.set('lod', '3');
          params.set('scale', '25000');
          params.set('max', '25000');
          params.set('bbox', viewBb.map(v => Number(v).toFixed(5)).join(','));
          const resp = await fetch('/api/features?' + params.toString(), {{ cache: 'no-store' }});
          if (!resp.ok) return false;
          const fc = await resp.json();
          const feats = (fc && Array.isArray(fc.features)) ? fc.features : [];
          if (feats.length > 0) {{
            ingestGeoJsonFeatures(layerName, feats, {{
              mergeExisting: true,
              matchExistingOnly: hadRows,
              lod: 3
            }});
            return true;
          }}
          return false;
        }}
        const wfsSvc = findLiveWfsService(layerName);
        if (!wfsSvc) return false;
        const pageSize = 5000;
        const bboxUrl = _buildWfsBboxUrl(wfsSvc, viewBb, pageSize);
        if (!bboxUrl) return false;
        const res = await _fetchWfsFeaturePages(bboxUrl, wfsSvc, {{
          maxFeatures: 25000,
          pageSize,
          skipBboxAppend: true
        }});
        const allFeatures = (res && Array.isArray(res.features)) ? res.features : [];
        if (allFeatures.length > 0) {{
          ingestGeoJsonFeatures(layerName, allFeatures, {{
            mergeExisting: true,
            matchExistingOnly: hadRows,
            lod: 3
          }});
          return true;
        }}
      }} catch (err) {{
        console.warn('Full 1:1 viewport geometry fetch failed for ' + layerName, err);
      }}
      return false;
    }}

    async function fetchSingleWfsService(svc, fetchOpts) {{
      const fopts = fetchOpts || {{}};
      if (!svc || !svc.geojson_url) return false;
      if (!fopts.deferStatus && !fopts.silent) setLiveStatus('html_loading_wfs');
      ACTIVE_WFS_SERVICE_FETCH[svc.name] = true;
      if (FETCH_ABORT_CONTROLLERS[svc.name]) {{
        try {{ FETCH_ABORT_CONTROLLERS[svc.name].abort(); }} catch (_abPrev) {{}}
        delete FETCH_ABORT_CONTROLLERS[svc.name];
      }}
      try {{
        devLog('INFO', 'WFS', `Fetching service ${{svc.name}} (forceFull=${{Boolean(fopts.forceFull)}})`);
        const rawDashCap = Number(DASHBOARD.html_live_max_features);
        const isMassiveSvc = Boolean(
          svc.restrict_to_bbox || /(kataster|ky_kehtiv|etak|kitsendus)/i.test(String(svc.typename || svc.name || ''))
        );
        const effectiveCap = isMassiveSvc
          ? 2500
          : ((fopts.forceFull || !Number.isFinite(rawDashCap) || rawDashCap <= 0) ? Infinity : Math.max(1, rawDashCap));
        const rawPage = Number(svc.page_size || 0);
        const pageSize = isMassiveSvc
          ? 400
          : ((rawPage > 1000 && rawPage <= 10000) ? rawPage : (Number.isFinite(effectiveCap) ? Math.min(effectiveCap, 10000) : 10000));
        const existingRows = Array.isArray(LAYER_RECORDS[svc.name]) ? LAYER_RECORDS[svc.name] : [];
        const optsBase = {{ method: 'GET', cache: 'no-store', headers: {{ 'Accept': 'application/json' }} }};
        if (svc.with_credentials) optsBase.credentials = 'include';
        if (fopts.signal) optsBase.signal = fopts.signal;

        if (Number.isFinite(effectiveCap) && !fopts.forceFull && existingRows.length > effectiveCap) {{
          const probeUrl = _buildPaginatedWfsUrl(svc.geojson_url, 1, 0, svc);
          const pResp = await fetch(probeUrl, optsBase);
          if (!pResp.ok) throw new Error('HTTP ' + pResp.status);
          const pJson = await pResp.json();
          const tot = Number((pJson && (pJson.totalFeatures ?? pJson.numberMatched)) ?? existingRows.length);
          LAYER_LIVE_INFO[svc.name] = {{
            status: 'live_streamed',
            label: 'LIVE (stream)',
            loaded: existingRows.length,
            totalFeatures: Number.isFinite(tot) ? tot : existingRows.length,
            complete: false,
            refreshed_at: _formatLiveTimeStamp(new Date())
          }};
          return {{ ok: true, complete: false, live: true, partial: true, failed: false, replaced: false, layerName: svc.name, totalFeatures: tot }};
        }}

        const pageRes = await _fetchWfsFeaturePages(svc.geojson_url, svc, {{
          maxFeatures: effectiveCap,
          pageSize,
          signal: fopts.signal,
          onPageProgress: (meta) => {{
            if (typeof fopts.onProgress === 'function') fopts.onProgress(meta.frac, svc.name, meta);
          }},
          onFirstPageMeta: ({{ totalFeatures }}) => {{
            if (Number.isFinite(effectiveCap) && !fopts.forceFull && totalFeatures > effectiveCap && existingRows.length >= Math.min(totalFeatures, effectiveCap)) {{
              LAYER_LIVE_INFO[svc.name] = {{
                status: 'live_streamed',
                label: 'LIVE (stream)',
                loaded: existingRows.length,
                totalFeatures,
                complete: false,
                refreshed_at: _formatLiveTimeStamp(new Date())
              }};
              return {{ abort: true, earlyReturn: {{ ok: true, complete: false, live: true, partial: true, failed: false, replaced: false, layerName: svc.name, totalFeatures }} }};
            }}
            return null;
          }}
        }});
        if (pageRes && pageRes.aborted && pageRes.earlyReturn) {{
          return pageRes.earlyReturn;
        }}
        const allFeatures = (pageRes && Array.isArray(pageRes.features)) ? pageRes.features : [];
        const totalFeatures = Number((pageRes && pageRes.totalFeatures) || 0);
        const hitCap = Boolean(pageRes && pageRes.hitCap);
        const countMismatch = Boolean(pageRes && pageRes.countMismatch);
        const networkError = Boolean(pageRes && pageRes.networkError);
        const aborted = Boolean(pageRes && pageRes.aborted);

        const staged = {{
          records: [],
          geoms: {{}},
          bboxes: {{}},
          lods: {{}},
          geomType: '',
          seenFids: new Set(),
          exactGeomCount: 0
        }};
        if (allFeatures.length > 0) {{
          await ingestGeoJsonFeaturesAsync(svc.name, allFeatures, {{
            targetStore: staged,
            mergeExisting: false,
            appendBatch: true,
            lod: 3
          }}, frac => {{
            if (!fopts.silent && typeof fopts.onProgress === 'function') {{
              fopts.onProgress(0.82 + frac * 0.16, svc.name);
            }}
          }});
          staged.records = applyExcelJoinsToLayer(svc.name, staged.records || []);
        }}

        const loadedNow = staged.records.length;
        const expectedTotal = Number(totalFeatures || 0);
        const postMismatch = Boolean(
          (expectedTotal > 0 && loadedNow < expectedTotal)
          || (allFeatures.length > 0 && loadedNow < allFeatures.length)
        );
        const anyMismatch = Boolean(countMismatch || postMismatch);
        const isComplete = Boolean(
          !aborted
          && !networkError
          && (!hitCap || (expectedTotal > 0 && loadedNow >= expectedTotal))
          && !anyMismatch
          && (expectedTotal === 0 || loadedNow >= expectedTotal)
        );
        const emptyRejection = Boolean(allFeatures.length === 0 && existingRows.length > 0 && expectedTotal === 0 && !networkError);

        if (isComplete && !emptyRejection && (loadedNow > 0 || (expectedTotal === 0 && allFeatures.length === 0))) {{
          LAYER_RECORDS[svc.name] = staged.records;
          LAYER_GEOMETRIES[svc.name] = staged.geoms;
          LAYER_GEOM_BBOXES[svc.name] = staged.bboxes;
          LAYER_GEOM_LOD[svc.name] = staged.lods;
          if (staged.geomType) LAYER_GEOM_TYPES[svc.name] = staged.geomType;
          delete _RECORD_BBOX_INDEX[svc.name];
          delete _RECORD_BBOX_INDEX['__rec__' + svc.name];
          delete LAYER_LAST_MISSING_KEY[svc.name];
          const refStamp = _formatLiveTimeStamp(new Date());
          const exactOk = (loadedNow === 0) || (staged.exactGeomCount >= loadedNow) || _isPointOnlyLayer(svc.name);
          LAYER_COMPLETENESS[svc.name] = {{
            complete: true,
            exactGeoms: Boolean(exactOk),
            loaded: loadedNow,
            total: expectedTotal || loadedNow,
            source: 'live_wfs'
          }};
          _invalidateRelationsForLayer(svc.name, false);
          LAYER_LIVE_INFO[svc.name] = {{
            status: 'live',
            label: 'LIVE',
            loaded: loadedNow,
            totalFeatures: expectedTotal || loadedNow,
            countMismatch: false,
            complete: true,
            refreshed_at: refStamp
          }};
          devLog('INFO', 'WFS', `Completed ${{svc.name}}: ${{loadedNow}}/${{expectedTotal || loadedNow}} features (complete, exactGeoms=${{exactOk}})`);
          if (!fopts.deferStatus) {{
            setLiveStatus('html_wfs_connected', {{ count: 1, total: 1 }});
          }}
          if (!fopts.deferRender) {{
            renderAll({{ skipAutoZoom: true }});
          }}
          return {{
            ok: true,
            complete: true,
            live: true,
            partial: false,
            countMismatch: false,
            failed: false,
            replaced: true,
            layerName: svc.name,
            loadedCount: loadedNow,
            totalFeatures: expectedTotal || loadedNow
          }};
        }}

        const refStamp = _formatLiveTimeStamp(new Date());
        const keptCnt = existingRows.length;
        const failStatus = (networkError || aborted) ? 'live_failed' : (anyMismatch ? 'live_incomplete' : 'live_partial');
        LAYER_LIVE_INFO[svc.name] = {{
          status: failStatus,
          label: (networkError || aborted)
            ? t('status_source_failed')
            : `⚠️ LIVE (${{loadedNow}}/${{expectedTotal || loadedNow}})`,
          loaded: keptCnt,
          attemptedLoaded: loadedNow,
          totalFeatures: expectedTotal || loadedNow,
          countMismatch: Boolean(anyMismatch || networkError),
          complete: false,
          refreshed_at: refStamp
        }};
        if (keptCnt === 0) {{
          LAYER_COMPLETENESS[svc.name] = {{
            complete: false,
            exactGeoms: false,
            loaded: 0,
            total: expectedTotal || loadedNow,
            source: (networkError || aborted) ? 'failed_wfs' : 'incomplete_wfs'
          }};
          _invalidateRelationsForLayer(svc.name, true, (networkError || aborted) ? 'wfs_failed' : 'wfs_incomplete');
        }}
        devLog(
          (networkError || aborted) ? 'ERROR' : 'WARN',
          'WFS',
          `Rejected incomplete WFS update for ${{svc.name}}: got ${{loadedNow}}/${{expectedTotal || '?'}} features (hitCap=${{hitCap}}, networkError=${{networkError}}, aborted=${{aborted}}). Keeping ${{keptCnt}} existing rows without committing partial data.`
        );
        if (!fopts.deferStatus) {{
          if (networkError || aborted) {{
            setLiveStatus('html_wfs_failed');
          }} else if (anyMismatch) {{
            setLiveStatus('html_wfs_incomplete', {{ loaded: loadedNow, total: expectedTotal || loadedNow }});
          }} else {{
            setLiveStatus('html_live_partial', {{ count: 0, total: 1, cap: effectiveCap }});
          }}
        }}
        if (!fopts.deferRender) {{
          renderAll({{ skipAutoZoom: true }});
        }}
        return {{
          ok: false,
          complete: false,
          live: false,
          partial: Boolean(hitCap && !anyMismatch && !networkError && !aborted),
          countMismatch: Boolean(anyMismatch),
          failed: Boolean(networkError || aborted || allFeatures.length === 0),
          replaced: false,
          layerName: svc.name,
          loadedCount: loadedNow,
          totalFeatures: expectedTotal || loadedNow
        }};
      }} catch (err) {{
        const msg = err && err.message ? err.message : String(err || 'fetch error');
        const cachedCnt = Array.isArray(LAYER_RECORDS[svc.name]) ? LAYER_RECORDS[svc.name].length : 0;
        if (_isFramedSandboxEnv() || IS_EMBEDDED_IFRAME) {{
          devLog(
            'WARN',
            'WFS',
            `${{svc.name}}: outbound WFS fetch blocked by SharePoint/iframe sandbox CSP (${{msg}}).` +
            (cachedCnt > 0 ? ` Retaining ${{cachedCnt}} packaged rows.` : ' Re-export as Single File (.html, no sidecar) with Packaged Layers for SharePoint.')
          );
        }} else {{
          devLog('ERROR', 'WFS', `WFS fetch failed for ${{svc.name}}: ${{msg}}`);
        }}
        console.warn('WFS fetch failed for ' + svc.name, err);
        LAYER_LIVE_INFO[svc.name] = {{
          status: cachedCnt > 0 ? 'retained_snapshot' : 'live_failed',
          label: cachedCnt > 0 ? t('status_source_retained_snapshot') : t('status_source_failed'),
          loaded: cachedCnt,
          complete: false,
          failed: true
        }};
        if (cachedCnt === 0) {{
          LAYER_COMPLETENESS[svc.name] = {{
            complete: false,
            exactGeoms: false,
            loaded: 0,
            total: 0,
            source: 'failed_wfs'
          }};
          _invalidateRelationsForLayer(svc.name, true, 'wfs_failed');
        }}
        return {{
          ok: false,
          complete: false,
          live: false,
          partial: false,
          countMismatch: false,
          failed: true,
          replaced: false,
          layerName: svc.name,
          loadedCount: cachedCnt,
          totalFeatures: 0
        }};
      }} finally {{
        delete ACTIVE_WFS_SERVICE_FETCH[svc.name];
      }}
    }}

    let _HTML_REFRESH_HIDE_TIMER = null;
    let _HTML_REFRESH_SEQ = 0;

    function setHtmlRefreshProgress(pct, label, isDone) {{
      const bar = document.getElementById('html-refresh-bar');
      const txt = document.getElementById('html-refresh-text');
      const fill = document.getElementById('html-refresh-fill');
      const busyText = document.getElementById('html-busy-text');
      const clamped = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
      const msg = label || t('html_refresh_progress', {{ pct: clamped, name: '' }});
      if (bar && bar.style) bar.style.display = 'inline-flex';
      if (txt) txt.textContent = msg;
      if (fill && fill.style) fill.style.width = `${{clamped}}%`;
      if (busyText) busyText.textContent = msg;
      if (isDone && bar && bar.style) {{
        const seq = _HTML_REFRESH_SEQ;
        if (_HTML_REFRESH_HIDE_TIMER && typeof clearTimeout === 'function') clearTimeout(_HTML_REFRESH_HIDE_TIMER);
        if (typeof setTimeout === 'function') {{
          _HTML_REFRESH_HIDE_TIMER = setTimeout(() => {{
            if (_HTML_REFRESH_SEQ === seq && !IS_WFS_REFRESHING && bar.style) bar.style.display = 'none';
          }}, 1800);
        }}
      }}
    }}

    async function refreshLiveWebSource(ds, signal) {{
      if (!ds || !ds.name || !ds.sharepoint_web_url) return false;
      const url = String(ds.sharepoint_web_url || '').trim();
      if (!/^https?:/i.test(url)) return false;
      const t0 = Date.now();
      try {{
        const fopts = {{ method: 'GET', cache: 'no-store', credentials: 'include' }};
        if (signal) fopts.signal = signal;
        const resp = await fetch(url, fopts);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const ct = String(resp.headers && resp.headers.get ? (resp.headers.get('content-type') || '') : '');
        if (/json/i.test(ct) || /\\.(geo)?json(\\?|$)/i.test(url)) {{
          const data = await resp.json();
          if (data && Array.isArray(data.features)) {{
            ingestGeoJsonFeatures(ds.name, data.features, {{ mergeExisting: false, appendBatch: true, lod: 3 }});
            LAYER_RECORDS[ds.name] = applyExcelJoinsToLayer(ds.name, LAYER_RECORDS[ds.name] || []);
            const cntNow = (LAYER_RECORDS[ds.name] || []).length;
            LAYER_COMPLETENESS[ds.name] = {{ complete: true, exactGeoms: true, loaded: cntNow, total: cntNow, source: 'live_web' }};
            _invalidateRelationsForLayer(ds.name, false);
          }} else if (Array.isArray(data)) {{
            LAYER_RECORDS[ds.name] = data;
            _invalidateRelationsForLayer(ds.name, false);
          }} else {{
            return false;
          }}
          LAYER_LIVE_INFO[ds.name] = {{
            status: 'live',
            label: 'LIVE (Web)',
            loaded: (LAYER_RECORDS[ds.name] || []).length,
            complete: true,
            refreshed_at: _formatLiveTimeStamp(new Date())
          }};
          devLog('NET', 'WEB', `Refreshed ${{ds.name}} from web URL in ${{Date.now() - t0}}ms`);
          return true;
        }}
      }} catch (err) {{
        devLog('WARN', 'WEB', `Web URL refresh skipped/failed for ${{ds.name}}: ${{err && err.message ? err.message : err}}`);
      }}
      return false;
    }}

    async function refreshLiveWfs(opts) {{
      const ropts = opts || {{}};
      const onlyLayer = ropts.onlyLayer ? String(ropts.onlyLayer) : '';
      const onlyLayersSet = (Array.isArray(ropts.onlyLayers) || (ropts.onlyLayers instanceof Set))
        ? new Set(Array.from(ropts.onlyLayers).map(x => String(x || '').trim()).filter(Boolean))
        : (onlyLayer ? new Set([onlyLayer]) : null);
      const isSingleExplicit = Boolean(onlyLayersSet && onlyLayersSet.size > 0);
      const allWfsServices = (BUNDLE.ogc_services || []).filter(s => s.type === 'wfs' && s.geojson_url);
      const wfsServices = allWfsServices.filter(s => {{
        if (onlyLayersSet && !onlyLayersSet.has(s.name)) return false;
        if (!onlyLayer && isWfsServicePinnedStatic(s)) {{
          devLog('INFO', 'WFS', `Skipped designer-static WFS layer "${{s.name}}" (unlock via Timestamp menu).`);
          return false;
        }}
        return true;
      }});
      const webSources = (DASHBOARD.data_sources || []).filter(d => {{
        if (!d || !d.name || !d.sharepoint_web_url || !/^https?:/i.test(String(d.sharepoint_web_url))) return false;
        if (onlyLayersSet && !onlyLayersSet.has(d.name)) return false;
        if (String(d.effective_state || 'live').toLowerCase() !== 'live') return false;
        return !allWfsServices.some(s => s.name === d.name);
      }});
      if (!wfsServices.length && !webSources.length) {{
        if (!ropts.silent) {{
          renderAll({{ skipAutoZoom: !ropts.autoZoom }});
          applyArtboardLayout();
        }}
        if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
        return 0;
      }}
      const targetServices = ropts.missingOnly
        ? wfsServices.filter(s => !(LAYER_RECORDS[s.name] && LAYER_RECORDS[s.name].length))
        : wfsServices;
      if (!targetServices.length && !webSources.length) {{
        if (!ropts.silent) renderAll({{ skipAutoZoom: !ropts.autoZoom }});
        if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
        return 0;
      }}
      if (IS_WFS_REFRESHING && !ropts.allowConcurrent) return 0;
      IS_WFS_REFRESHING = true;
      const runRefreshingNames = targetServices.map(s => s.name).concat(webSources.map(d => d.name));
      runRefreshingNames.forEach(nm => {{ if (nm) LAYER_REFRESHING.add(nm); }});
      WFS_REFRESH_ABORT_CONTROLLER = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      _syncDevLogCancelBtn();
      _HTML_REFRESH_SEQ += 1;
      devLog('INFO', 'WFS', `Starting live refresh for ${{runRefreshingNames.join(', ')}}`);
      if (ropts.force) {{
        Object.keys(LAYER_LAST_MISSING_KEY).forEach(k => delete LAYER_LAST_MISSING_KEY[k]);
        Object.keys(LAYER_FETCH_COOLDOWN).forEach(k => delete LAYER_FETCH_COOLDOWN[k]);
        _clearCrossLayerCaches();
      }}
      const hadInitial = targetServices.every(s => Array.isArray(LAYER_RECORDS[s.name]) && LAYER_RECORDS[s.name].length > 0);
      const fracBySvc = {{}};
      targetServices.forEach(s => {{ fracBySvc[s.name] = 0; }});
      if (!ropts.silent) {{
        syncLiveStatusPillFromState();
        const firstLabel = (targetServices[0] && targetServices[0].name) || (webSources[0] && webSources[0].name) || '';
        setHtmlRefreshProgress(0, t('html_refresh_progress', {{ pct: 0, name: firstLabel }}), false);
      }}
      let completeCount = 0;
      let partialCount = 0;
      let incompleteCount = 0;
      let failedCount = 0;
      let anyReplaced = false;
      let mismatchLayer = null;
      const activeSignal = WFS_REFRESH_ABORT_CONTROLLER ? WFS_REFRESH_ABORT_CONTROLLER.signal : undefined;
      try {{
        const results = await Promise.all(
          targetServices.map(svc => fetchSingleWfsService(svc, {{
            deferRender: true,
            deferStatus: true,
            force: Boolean(ropts.force),
            forceFull: Boolean(ropts.forceFull),
            silent: Boolean(ropts.silent),
            signal: activeSignal,
            onProgress: (frac, sname) => {{
              fracBySvc[svc.name] = Math.max(fracBySvc[svc.name] || 0, Math.min(1, Math.max(0, Number(frac) || 0)));
              if (!ropts.silent) {{
                const sumF = Object.values(fracBySvc).reduce((a, b) => a + b, 0);
                const pct = Math.min(92, Math.max(1, Math.round((sumF / Math.max(1, targetServices.length)) * 92)));
                setHtmlRefreshProgress(pct, t('html_refresh_progress', {{ pct, name: sname || svc.name }}), false);
              }}
            }}
          }}))
        );
        results.forEach((res, idx) => {{
          const s = targetServices[idx];
          if (s) fracBySvc[s.name] = 1;
          if (res && res.complete) {{
            completeCount++;
            if (res.replaced) anyReplaced = true;
          }} else if (res && res.countMismatch) {{
            incompleteCount++;
            if (!mismatchLayer) {{
              mismatchLayer = {{
                name: res.layerName || (s && s.name) || '',
                loaded: Number(res.loadedCount || 0),
                totalFeatures: Number(res.totalFeatures || 0)
              }};
            }}
          }} else if (res && res.partial) {{
            partialCount++;
          }} else {{
            failedCount++;
          }}
        }});
        for (let wi = 0; wi < webSources.length; wi++) {{
          const ds = webSources[wi];
          const okWeb = await refreshLiveWebSource(ds, activeSignal);
          if (okWeb) {{
            completeCount++;
            anyReplaced = true;
          }} else {{
            failedCount++;
            const cachedWeb = Array.isArray(LAYER_RECORDS[ds.name]) ? LAYER_RECORDS[ds.name].length : 0;
            LAYER_LIVE_INFO[ds.name] = {{
              status: cachedWeb > 0 ? 'retained_snapshot' : 'live_failed',
              label: cachedWeb > 0 ? t('status_source_retained_snapshot') : t('status_source_failed'),
              loaded: cachedWeb,
              complete: false,
              failed: true
            }};
          }}
        }}
      }} finally {{
        IS_WFS_REFRESHING = false;
        runRefreshingNames.forEach(nm => {{ LAYER_REFRESHING.delete(nm); }});
        WFS_REFRESH_ABORT_CONTROLLER = null;
        _syncDevLogCancelBtn();
      }}
      const totalTargets = Math.max(1, targetServices.length + webSources.length);
      const allComplete = Boolean(completeCount === totalTargets && incompleteCount === 0 && failedCount === 0 && partialCount === 0);
      const dataMode = String(DASHBOARD.html_data_mode || 'cached').toLowerCase();
      const manualForce = Boolean(ropts.force && !ropts.missingOnly && !ropts.silent);

      if (anyReplaced) {{
        LIVE_SESSION_STAMP = _formatLiveTimeStamp(new Date());
        HAS_LIVE_REFRESHED = true;
      }}
      if (ropts.silent && hadInitial && dataMode === 'cached' && !anyReplaced && !isSingleExplicit) {{
        setLiveStatus('html_cached_snapshot');
      }} else {{
        syncLiveStatusPillFromState();
      }}
      if (anyReplaced || !hadInitial || manualForce || incompleteCount > 0 || failedCount > 0) {{
        buildSlicers();
        renderActiveFiltersBanner();
        renderMapLayersDrawer();
        renderAll({{ skipAutoZoom: !ropts.autoZoom }});
        applyArtboardLayout();
      }}
      if (!ropts.silent) {{
        const totalRecs = Object.values(LAYER_RECORDS).reduce((acc, r) => acc + (Array.isArray(r) ? r.length : 0), 0);
        const doneMsg = allComplete
          ? t('html_refresh_done', {{ layers: completeCount, records: totalRecs, time: LIVE_SESSION_STAMP || _formatLiveTimeStamp(new Date()) }})
          : (mismatchLayer
              ? t('html_wfs_incomplete', {{ loaded: mismatchLayer.loaded, total: mismatchLayer.totalFeatures }})
              : t('html_wfs_failed'));
        setHtmlRefreshProgress(100, doneMsg, true);
      }}
      return completeCount;
    }}

    function initAutoRefreshTimer() {{
      if (AUTO_REFRESH_TIMER && typeof clearInterval === 'function') {{
        clearInterval(AUTO_REFRESH_TIMER);
        AUTO_REFRESH_TIMER = null;
      }}
      const mode = String(DASHBOARD.html_data_mode || 'live').toLowerCase();
      if (mode === 'cached') return;
      const dashSec = Number(DASHBOARD.html_auto_refresh_seconds || 0);
      const svcMaxSec = (BUNDLE.ogc_services || []).reduce((acc, s) => Math.max(acc, Number((s && s.auto_refresh_seconds) || 0)), 0);
      const sec = dashSec > 0 ? dashSec : svcMaxSec;
      if (Number.isFinite(sec) && sec >= 10 && typeof setInterval === 'function') {{
        AUTO_REFRESH_TIMER = setInterval(() => {{
          refreshLiveWfs({{ force: true, silent: true }});
        }}, Math.round(sec * 1000));
      }}
    }}

    function normalizeWidgetSourceId(sid) {{
      const s = String(sid || '');
      return s.replace(/^tbl_/, '').replace(/__pane_\\d+$/, '');
    }}

    function getConnectionsFrom(sourceId) {{
      const allConns = DASHBOARD.widget_connections || [];
      const norm = normalizeWidgetSourceId(sourceId);
      return allConns.filter(c => c && c.enabled !== false && c.target_id && (c.source_id === sourceId || normalizeWidgetSourceId(c.source_id) === norm));
    }}

    function mapTargetIdSet() {{
      const s = new Set(['__map__']);
      const am = getActiveMapWidget();
      if (am && am.id) s.add(am.id);
      return s;
    }}

    const _CROSS_LAYER_FID_CACHE = new Map();

    function _bboxOverlaps2D(a, b) {{
      if (!a || !b) return false;
      return !(a[2] < b[0] || a[0] > b[2] || a[3] < b[1] || a[1] > b[3]);
    }}

    function _bboxToPolyGeom(bb) {{
      if (!bb || bb.length !== 4) return null;
      if (Math.abs(bb[2] - bb[0]) <= 1e-12 && Math.abs(bb[3] - bb[1]) <= 1e-12) {{
        return {{ type: 'Point', coordinates: [bb[0], bb[1]] }};
      }}
      return {{
        type: 'Polygon',
        coordinates: [[[bb[0], bb[1]], [bb[2], bb[1]], [bb[2], bb[3]], [bb[0], bb[3]], [bb[0], bb[1]]]]
      }};
    }}

    function _segIntersects2D(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2) {{
      if (Math.max(ax1, ax2) < Math.min(bx1, bx2) || Math.max(bx1, bx2) < Math.min(ax1, ax2)) return false;
      if (Math.max(ay1, ay2) < Math.min(by1, by2) || Math.max(by1, by2) < Math.min(ay1, ay2)) return false;
      const orient = (px, py, qx, qy, rx, ry) => (qx - px) * (ry - py) - (qy - py) * (rx - px);
      const d1 = orient(bx1, by1, bx2, by2, ax1, ay1);
      const d2 = orient(bx1, by1, bx2, by2, ax2, ay2);
      const d3 = orient(ax1, ay1, ax2, ay2, bx1, by1);
      const d4 = orient(ax1, ay1, ax2, ay2, bx2, by2);
      if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return true;
      const eps = 1e-12;
      const onSeg = (px, py, qx, qy, rx, ry) =>
        qx >= Math.min(px, rx) - eps && qx <= Math.max(px, rx) + eps &&
        qy >= Math.min(py, ry) - eps && qy <= Math.max(py, ry) + eps;
      if (Math.abs(d1) <= eps && onSeg(bx1, by1, ax1, ay1, bx2, by2)) return true;
      if (Math.abs(d2) <= eps && onSeg(bx1, by1, ax2, ay2, bx2, by2)) return true;
      if (Math.abs(d3) <= eps && onSeg(ax1, ay1, bx1, by1, ax2, ay2)) return true;
      if (Math.abs(d4) <= eps && onSeg(ax1, ay1, bx2, by2, ax2, ay2)) return true;
      return false;
    }}

    function _extractPtsFromGeom(geom) {{
      if (!geom || !geom.coordinates) return [];
      if (geom.type === 'Point') return [[Number(geom.coordinates[0]), Number(geom.coordinates[1])]];
      if (geom.type === 'MultiPoint') return geom.coordinates.map(c => [Number(c[0]), Number(c[1])]);
      return [];
    }}

    function _extractLinesFromGeom(geom) {{
      if (!geom || !geom.coordinates) return [];
      if (geom.type === 'LineString') return [geom.coordinates];
      if (geom.type === 'MultiLineString') return geom.coordinates;
      return [];
    }}

    function geomIntersectsGeom(g1, g2) {{
      if (!g1 || !g2) return false;
      const b1 = geomBbox(g1), b2 = geomBbox(g2);
      if (!b1 || !b2 || !_bboxOverlaps2D(b1, b2)) return false;
      if (g1.type === 'GeometryCollection') return (g1.geometries || []).some(s => geomIntersectsGeom(s, g2));
      if (g2.type === 'GeometryCollection') return (g2.geometries || []).some(s => geomIntersectsGeom(g1, s));

      const p1 = g1.type === 'Polygon' ? [g1.coordinates] : (g1.type === 'MultiPolygon' ? g1.coordinates : []);
      const p2 = g2.type === 'Polygon' ? [g2.coordinates] : (g2.type === 'MultiPolygon' ? g2.coordinates : []);
      if (p1.length && p2.length) {{
        for (const poly1 of p1) {{
          for (const ring of poly1) {{
            for (const pt of ring) {{
              if (pointInGeom(pt[0], pt[1], g2)) return true;
            }}
          }}
        }}
        for (const poly2 of p2) {{
          for (const ring of poly2) {{
            for (const pt of ring) {{
              if (pointInGeom(pt[0], pt[1], g1)) return true;
            }}
          }}
        }}
        for (const poly1 of p1) {{
          for (const r1 of poly1) {{
            for (let i = 0; i < r1.length; i++) {{
              const a1 = r1[i], a2 = r1[(i + 1) % r1.length];
              for (const poly2 of p2) {{
                for (const r2 of poly2) {{
                  for (let j = 0; j < r2.length; j++) {{
                    const b1p = r2[j], b2p = r2[(j + 1) % r2.length];
                    if (_segIntersects2D(a1[0], a1[1], a2[0], a2[1], b1p[0], b1p[1], b2p[0], b2p[1])) return true;
                  }}
                }}
              }}
            }}
          }}
        }}
        return false;
      }}
      const pts1 = _extractPtsFromGeom(g1), pts2 = _extractPtsFromGeom(g2);
      if (p1.length && pts2.length) return pts2.some(pt => pointInGeom(pt[0], pt[1], g1));
      if (p2.length && pts1.length) return pts1.some(pt => pointInGeom(pt[0], pt[1], g2));

      const ls1 = _extractLinesFromGeom(g1), ls2 = _extractLinesFromGeom(g2);
      if (p1.length && ls2.length) {{
        for (const line of ls2) {{
          for (const pt of line) if (pointInGeom(pt[0], pt[1], g1)) return true;
          for (let i = 0; i < line.length - 1; i++) {{
            for (const poly1 of p1) {{
              for (const r1 of poly1) {{
                for (let j = 0; j < r1.length; j++) {{
                  const c1 = r1[j], c2 = r1[(j + 1) % r1.length];
                  if (_segIntersects2D(line[i][0], line[i][1], line[i + 1][0], line[i + 1][1], c1[0], c1[1], c2[0], c2[1])) return true;
                }}
              }}
            }}
          }}
        }}
        return false;
      }}
      if (p2.length && ls1.length) return geomIntersectsGeom(g2, g1);
      if (ls1.length && ls2.length) {{
        for (const l1 of ls1) {{
          for (let i = 0; i < l1.length - 1; i++) {{
            for (const l2 of ls2) {{
              for (let j = 0; j < l2.length - 1; j++) {{
                if (_segIntersects2D(l1[i][0], l1[i][1], l1[i + 1][0], l1[i + 1][1], l2[j][0], l2[j][1], l2[j + 1][0], l2[j + 1][1])) return true;
              }}
            }}
          }}
        }}
        return false;
      }}
      return true;
    }}

    function getFilterSources(flt) {{
      if (!flt) return [];
      if (Array.isArray(flt.layer_fields) && flt.layer_fields.length) {{
        const out = flt.layer_fields
          .filter(it => it && it.layer_name)
          .map(it => ({{ layer_name: String(it.layer_name), field_name: String(it.field_name || flt.field_name || '') }}));
        if (out.length) return out;
      }}
      return flt.layer_name
        ? [{{ layer_name: String(flt.layer_name), field_name: String(flt.field_name || '') }}]
        : [];
    }}

    function _filterRowMatchesAttr(row, flt, layerName) {{
      if (!row || !flt) return true;
      if (flt.type === 'spatial_geom' || flt.type === 'spatial_bbox') {{
        const shp = _rowSpatialShape(layerName || flt._targetLayer || '', row);
        if (!shp) return false;
        if (Array.isArray(flt.bbox) && flt.bbox.length === 4 && !_bboxOverlaps2D(shp.bbox, flt.bbox.map(Number))) return false;
        if (flt.geometry && typeof geomIntersectsGeom === 'function') {{
          return geomIntersectsGeom(shp.geom, flt.geometry);
        }}
        return true;
      }}
      const srcMatch = layerName ? getFilterSources(flt).find(s => s.layer_name === layerName) : null;
      const effField = (srcMatch && srcMatch.field_name) ? srcMatch.field_name : flt.field_name;
      const val = row[effField];
      if (flt.type === 'category' && flt.values && flt.values.length) {{
        return flt.values.map(String).includes(String(val));
      }}
      if (flt.type === 'numeric_range') {{
        const num = Number(val);
        if (val === null || val === undefined || val === '' || isNaN(num)) return false;
        if (flt.min !== null && flt.min !== undefined && num < flt.min) return false;
        if (flt.max !== null && flt.max !== undefined && num > flt.max) return false;
        return true;
      }}
      if (flt.type === 'date_range') {{
        if (val === null || val === undefined) return false;
        let sval = String(val).trim();
        if (!sval) return false;
        const minStr = (flt.min !== null && flt.min !== undefined) ? String(flt.min).trim() : '';
        const maxStr = (flt.max !== null && flt.max !== undefined) ? String(flt.max).trim() : '';
        if ((minStr.length === 10 || maxStr.length === 10) && sval.length >= 10) {{
          sval = sval.slice(0, 10).replace('/', '-').replace('/', '-');
        }}
        if (minStr && sval < minStr) return false;
        if (maxStr && sval > maxStr) return false;
        return true;
      }}
      return true;
    }}

    function _rowSpatialShape(ln, row) {{
      if (!row) return null;
      const fidStr = (row._feature_id !== undefined && row._feature_id !== null) ? String(row._feature_id) : '';
      let geom = fidStr ? getFeatureGeometry(ln, fidStr) : null;
      let bb = null;
      if (Array.isArray(row._bbox) && row._bbox.length === 4) {{
        bb = row._bbox.map(Number);
      }} else if (fidStr) {{
        bb = getFeatureBbox(ln, fidStr);
      }}
      if (!bb && geom) bb = geomBbox(geom);
      if (!bb && row._lon !== undefined && row._lat !== undefined) {{
        const x = Number(row._lon), y = Number(row._lat);
        if (Number.isFinite(x) && Number.isFinite(y)) bb = [x, y, x, y];
      }}
      if (!bb) return null;
      if (!geom) geom = _bboxToPolyGeom(bb);
      return {{ geom, bbox: bb }};
    }}

    function _rowExactShape(ln, row) {{
      if (!row) return null;
      const fidStr = (row._feature_id !== undefined && row._feature_id !== null) ? String(row._feature_id) : '';
      const geoms = LAYER_GEOMETRIES[ln] || {{}};
      const lods = LAYER_GEOM_LOD[ln] || {{}};
      let geom = null;
      if (fidStr && geoms[fidStr] && Number(lods[fidStr] || 0) >= 3) {{
        geom = geoms[fidStr];
      }} else if (_isPointOnlyLayer(ln) && Number.isFinite(Number(row._lon)) && Number.isFinite(Number(row._lat))) {{
        geom = {{ type: 'Point', coordinates: [Number(row._lon), Number(row._lat)] }};
      }}
      if (!geom) return null;
      const bb = (fidStr && LAYER_GEOM_BBOXES[ln] && LAYER_GEOM_BBOXES[ln][fidStr])
        || (Array.isArray(row._bbox) && row._bbox.length === 4 ? row._bbox.map(Number) : null)
        || geomBbox(geom);
      if (!bb) return null;
      return {{ geom, bbox: bb }};
    }}

    const _CROSS_LAYER_AREA_CACHE = new Map();
    const _CROSS_LAYER_UNAVAIL_CACHE = new Map();

    function resolveCrossLayerResult(flt, layerName) {{
      if (!flt || !layerName || flt.type === 'spatial_geom' || flt.type === 'spatial_bbox') return null;
      const sources = getFilterSources(flt);
      const extSources = sources.filter(s => s.layer_name && s.layer_name !== '__spatial__' && s.layer_name !== layerName);
      if (!extSources.length) return null;
      if (extSources.length > 1 || (Array.isArray(flt.layer_fields) && flt.layer_fields.length > 0)) {{
        const unionAllowed = new Set();
        let unionClipped = null;
        let sawAny = false;
        let unavailReason = '';
        const tgtMaxByFid = new Map();
        const tgtRecsAll = LAYER_RECORDS[layerName] || [];
        for (let ti = 0; ti < tgtRecsAll.length; ti++) {{
          const tr = tgtRecsAll[ti];
          const tfid = (tr && tr._feature_id !== undefined && tr._feature_id !== null) ? String(tr._feature_id) : '';
          if (tfid) {{
            const m = Number(tr._geom_area_ha ?? tr.area_ha ?? 0);
            if (Number.isFinite(m) && m > 0) tgtMaxByFid.set(tfid, m);
          }}
        }}
        for (const src of extSources) {{
          const proxy = Object.assign({{}}, flt, {{
            layer_name: src.layer_name,
            field_name: src.field_name || flt.field_name,
            layer_fields: []
          }});
          const sub = _resolveSingleSourceCrossLayerResult(proxy, layerName);
          if (sub) {{
            sawAny = true;
            if (sub.unavailable) {{
              if (!unavailReason) unavailReason = sub.reason || 'incomplete_exact_geometries';
              continue;
            }}
            if (sub.allowed !== null) {{
              sub.allowed.forEach(fid => unionAllowed.add(fid));
              if (sub.clippedAreas && sub.clippedAreas.size > 0) {{
                if (!unionClipped) unionClipped = new Map();
                sub.clippedAreas.forEach((ha, fid) => {{
                  const prev = unionClipped.get(fid) || 0;
                  const nxt = prev + Number(ha || 0);
                  const maxT = tgtMaxByFid.get(fid) || 0;
                  unionClipped.set(fid, maxT > 0 ? Math.min(maxT, nxt) : nxt);
                }});
              }}
            }}
          }}
        }}
        if (!sawAny) return null;
        if (unavailReason) {{
          return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason: unavailReason }};
        }}
        return {{ allowed: unionAllowed, clippedAreas: unionClipped, unavailable: false }};
      }}
      return _resolveSingleSourceCrossLayerResult(flt, layerName);
    }}

    function _crossLayerCacheKey(flt, srcLayer, layerName) {{
      const srcRecs = LAYER_RECORDS[srcLayer] || [];
      const tgtRecs = LAYER_RECORDS[layerName] || [];
      const srcGeomCount = Object.keys(LAYER_GEOMETRIES[srcLayer] || {{}}).length;
      const tgtGeomCount = Object.keys(LAYER_GEOMETRIES[layerName] || {{}}).length;
      const rel = SPATIAL_RELATIONS.get(_srPairKey(srcLayer, layerName));
      const relStamp = rel ? `${{rel.complete ? 1 : 0}}:${{rel.edge_count || 0}}:${{rel.reason || ''}}` : 'none';
      return `${{srcLayer}}|${{layerName}}|${{flt.field_name}}|${{flt.type}}|${{(flt.values || []).join(',')}}|${{flt.min ?? ''}}|${{flt.max ?? ''}}|${{srcRecs.length}}|${{tgtRecs.length}}|${{srcGeomCount}}|${{tgtGeomCount}}|${{relStamp}}`;
    }}

    function _buildSrcSpatialGrid(srcShapes, cellDeg) {{
      const CELL = cellDeg || 0.03;
      const grid = new Map();
      let u0 = Infinity, u1 = Infinity, u2 = -Infinity, u3 = -Infinity;
      for (let i = 0; i < srcShapes.length; i++) {{
        const s = srcShapes[i];
        const b = s.bbox;
        if (b[0] < u0) u0 = b[0];
        if (b[1] < u1) u1 = b[1];
        if (b[2] > u2) u2 = b[2];
        if (b[3] > u3) u3 = b[3];
        const gx0 = Math.floor(b[0] / CELL), gx1 = Math.floor(b[2] / CELL);
        const gy0 = Math.floor(b[1] / CELL), gy1 = Math.floor(b[3] / CELL);
        for (let gx = gx0; gx <= gx1; gx++) {{
          for (let gy = gy0; gy <= gy1; gy++) {{
            const gk = `${{gx}},${{gy}}`;
            let arr = grid.get(gk);
            if (!arr) {{ arr = []; grid.set(gk, arr); }}
            arr.push(s);
          }}
        }}
      }}
      return {{ CELL, grid, unionBb: [u0, u1, u2, u3] }};
    }}

    function _querySrcSpatialGrid(gridInfo, tShp) {{
      if (!_bboxOverlaps2D(tShp.bbox, gridInfo.unionBb)) return false;
      const CELL = gridInfo.CELL;
      const b = tShp.bbox;
      const gx0 = Math.floor(b[0] / CELL), gx1 = Math.floor(b[2] / CELL);
      const gy0 = Math.floor(b[1] / CELL), gy1 = Math.floor(b[3] / CELL);
      const seen = new Set();
      for (let gx = gx0; gx <= gx1; gx++) {{
        for (let gy = gy0; gy <= gy1; gy++) {{
          const arr = gridInfo.grid.get(`${{gx}},${{gy}}`);
          if (!arr) continue;
          for (let i = 0; i < arr.length; i++) {{
            const sShp = arr[i];
            if (seen.has(sShp)) continue;
            seen.add(sShp);
            if (_bboxOverlaps2D(sShp.bbox, b) && geomIntersectsGeom(sShp.geom, tShp.geom)) {{
              return true;
            }}
          }}
        }}
      }}
      return false;
    }}

    function _querySrcSpatialGridAreaHa(gridInfo, tShp) {{
      if (!_bboxOverlaps2D(tShp.bbox, gridInfo.unionBb)) return -1;
      const CELL = gridInfo.CELL;
      const b = tShp.bbox;
      const gx0 = Math.floor(b[0] / CELL), gx1 = Math.floor(b[2] / CELL);
      const gy0 = Math.floor(b[1] / CELL), gy1 = Math.floor(b[3] / CELL);
      const seen = new Set();
      let haSum = 0.0;
      for (let gx = gx0; gx <= gx1; gx++) {{
        for (let gy = gy0; gy <= gy1; gy++) {{
          const arr = gridInfo.grid.get(`${{gx}},${{gy}}`);
          if (!arr) continue;
          for (let i = 0; i < arr.length; i++) {{
            const sShp = arr[i];
            if (seen.has(sShp)) continue;
            seen.add(sShp);
            if (_bboxOverlaps2D(sShp.bbox, b)) {{
              haSum += exactPolygonIntersectionAreaHa(sShp.geom, tShp.geom);
            }}
          }}
        }}
      }}
      return haSum > 1e-6 ? haSum : 0.0;
    }}

    function _resolveSingleSourceCrossLayerResult(flt, layerName) {{
      const srcLayer = flt && flt.layer_name ? String(flt.layer_name) : '';
      if (!srcLayer || !layerName || srcLayer === layerName || srcLayer === '__spatial__' || flt.type === 'spatial_geom' || flt.type === 'spatial_bbox') return null;
      if (!_isSpatialLayer(srcLayer) || !_isSpatialLayer(layerName)) return null;

      const cacheKey = _crossLayerCacheKey(flt, srcLayer, layerName);
      if (_CROSS_LAYER_UNAVAIL_CACHE.has(cacheKey)) {{
        return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason: _CROSS_LAYER_UNAVAIL_CACHE.get(cacheKey) }};
      }}
      if (_CROSS_LAYER_FID_CACHE.has(cacheKey)) {{
        return {{
          allowed: _CROSS_LAYER_FID_CACHE.get(cacheKey),
          clippedAreas: _CROSS_LAYER_AREA_CACHE.get(cacheKey) || null,
          unavailable: false
        }};
      }}

      const srcRecs = LAYER_RECORDS[srcLayer] || [];
      const tgtRecs = LAYER_RECORDS[layerName] || [];
      if (!srcRecs.length || !tgtRecs.length) {{
        const reason = !srcRecs.length ? 'missing_source_records' : 'missing_target_records';
        _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, reason);
        return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason }};
      }}

      const pairKey = _srPairKey(srcLayer, layerName);
      const rel = SPATIAL_RELATIONS.get(pairKey);
      if (rel && (!rel.complete || !rel.exact)) {{
        const reason = rel.reason || 'incomplete_data';
        _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, reason);
        return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason }};
      }}

      const matchingSrc = srcRecs.filter(r => _filterRowMatchesAttr(r, flt, srcLayer));
      if (!matchingSrc.length) {{
        const empty = new Set();
        _CROSS_LAYER_FID_CACHE.set(cacheKey, empty);
        return {{ allowed: empty, clippedAreas: null, unavailable: false }};
      }}

      const tgtMaxByFid = new Map();
      for (let ti = 0; ti < tgtRecs.length; ti++) {{
        const tr = tgtRecs[ti];
        const fidStr = (tr && tr._feature_id !== undefined && tr._feature_id !== null) ? String(tr._feature_id) : '';
        if (fidStr) {{
          const m = Number(tr._geom_area_ha ?? tr.area_ha ?? 0);
          if (Number.isFinite(m) && m > 0) tgtMaxByFid.set(fidStr, m);
        }}
      }}

      // Tier 0: Exact precomputed spatial relation graph
      if (rel) {{
        if (!rel.complete || !rel.exact) {{
          const reason = rel.reason || 'incomplete_data';
          _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, reason);
          return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason }};
        }}
        const cntA = (LAYER_RECORDS[rel.layer_a] || []).length;
        const cntB = (LAYER_RECORDS[rel.layer_b] || []).length;
        if (rel.byA && rel.byB && Number(rel.count_a) === cntA && Number(rel.count_b) === cntB) {{
          const adj = (srcLayer === rel.layer_a) ? rel.byA : rel.byB;
          const bothPoly = (rel.geom_kind_a === 'polygon' && rel.geom_kind_b === 'polygon');
          const allowed = new Set();
          const clippedAreas = bothPoly ? new Map() : null;
          for (let si = 0; si < matchingSrc.length; si++) {{
            const sr = matchingSrc[si];
            const sfid = (sr && sr._feature_id !== undefined && sr._feature_id !== null) ? String(sr._feature_id) : '';
            if (!sfid) continue;
            const edges = adj.get(sfid);
            if (!edges) continue;
            for (let ei = 0; ei < edges.length; ei++) {{
              const pair = edges[ei];
              const tfid = pair[0];
              const ha = Number(pair[1]);
              allowed.add(tfid);
              if (bothPoly && ha >= 0) {{
                const prev = clippedAreas.get(tfid) || 0;
                const nxt = prev + ha;
                const maxT = tgtMaxByFid.get(tfid) || 0;
                clippedAreas.set(tfid, maxT > 0 ? Math.min(maxT, nxt) : nxt);
              }}
            }}
          }}
          _CROSS_LAYER_FID_CACHE.set(cacheKey, allowed);
          if (clippedAreas) _CROSS_LAYER_AREA_CACHE.set(cacheKey, clippedAreas);
          return {{ allowed, clippedAreas, unavailable: false }};
        }}
      }}

      // Tier 1: Exact on-demand LOD-3 Green's Theorem calculation (never LOD-1 or bbox rects)
      if (!_layerHasCompleteExactGeoms(srcLayer) || !_layerHasCompleteExactGeoms(layerName)) {{
        const reason = 'incomplete_exact_geometries';
        _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, reason);
        return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason }};
      }}

      const srcShapes = [];
      let srcPoly = _isPolyGeomType(LAYER_GEOM_TYPES[srcLayer]);
      for (let si = 0; si < matchingSrc.length; si++) {{
        const shp = _rowExactShape(srcLayer, matchingSrc[si]);
        if (!shp) {{
          _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, 'incomplete_exact_geometries');
          return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason: 'incomplete_exact_geometries' }};
        }}
        if (/polygon/i.test(String(shp.geom.type || ''))) srcPoly = true;
        srcShapes.push(shp);
      }}
      if (!srcShapes.length) {{
        const empty = new Set();
        _CROSS_LAYER_FID_CACHE.set(cacheKey, empty);
        return {{ allowed: empty, clippedAreas: null, unavailable: false }};
      }}

      const gridInfo = _buildSrcSpatialGrid(srcShapes, 0.03);
      const allowed = new Set();
      let tgtPoly = _isPolyGeomType(LAYER_GEOM_TYPES[layerName]);
      const clippedAreas = (srcPoly && tgtPoly) ? new Map() : null;
      for (let ti = 0; ti < tgtRecs.length; ti++) {{
        const tr = tgtRecs[ti];
        const fidStr = (tr && tr._feature_id !== undefined && tr._feature_id !== null) ? String(tr._feature_id) : '';
        const tShp = _rowExactShape(layerName, tr);
        if (!tShp) {{
          _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, 'incomplete_exact_geometries');
          return {{ allowed: new Set(), clippedAreas: null, unavailable: true, reason: 'incomplete_exact_geometries' }};
        }}
        const tIsPolyNow = /polygon/i.test(String(tShp.geom.type || ''));
        if (srcPoly && (tgtPoly || tIsPolyNow)) {{
          const haSum = _querySrcSpatialGridAreaHa(gridInfo, tShp);
          if (haSum > 1e-6 && fidStr) {{
            allowed.add(fidStr);
            const haR = Math.round(haSum * 1000000) / 1000000;
            const maxT = tgtMaxByFid.get(fidStr) || 0;
            const clipVal = maxT > 0 ? Math.min(maxT, haR) : haR;
            if (clippedAreas) clippedAreas.set(fidStr, clipVal);
          }}
        }} else {{
          if (_querySrcSpatialGrid(gridInfo, tShp) && fidStr) {{
            allowed.add(fidStr);
          }}
        }}
      }}
      _CROSS_LAYER_FID_CACHE.set(cacheKey, allowed);
      if (clippedAreas) _CROSS_LAYER_AREA_CACHE.set(cacheKey, clippedAreas);
      return {{ allowed, clippedAreas, unavailable: false }};
    }}

    async function _resolveSingleSourceCrossLayerAsync(flt, layerName, seq, onPct) {{
      const srcLayer = flt && flt.layer_name ? String(flt.layer_name) : '';
      if (!srcLayer || !layerName || srcLayer === layerName || srcLayer === '__spatial__' || flt.type === 'spatial_geom' || flt.type === 'spatial_bbox') return;
      if (!_isSpatialLayer(srcLayer) || !_isSpatialLayer(layerName)) return;

      const cacheKey = _crossLayerCacheKey(flt, srcLayer, layerName);
      if (_CROSS_LAYER_FID_CACHE.has(cacheKey) || _CROSS_LAYER_UNAVAIL_CACHE.has(cacheKey)) return;

      const rel = SPATIAL_RELATIONS.get(_srPairKey(srcLayer, layerName));
      if (rel) {{
        _resolveSingleSourceCrossLayerResult(flt, layerName);
        return;
      }}

      const srcRecs = LAYER_RECORDS[srcLayer] || [];
      const tgtRecs = LAYER_RECORDS[layerName] || [];
      if (!srcRecs.length || !tgtRecs.length) {{
        _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, !srcRecs.length ? 'missing_source_records' : 'missing_target_records');
        return;
      }}

      if (!_layerHasCompleteExactGeoms(srcLayer) || !_layerHasCompleteExactGeoms(layerName)) {{
        _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, 'incomplete_exact_geometries');
        return;
      }}

      if ((srcRecs.length + tgtRecs.length) <= 4500) {{
        _resolveSingleSourceCrossLayerResult(flt, layerName);
        return;
      }}

      const matchingSrc = srcRecs.filter(r => _filterRowMatchesAttr(r, flt, srcLayer));
      if (seq !== _FILTER_RENDER_SEQ) return;
      if (!matchingSrc.length) {{
        _CROSS_LAYER_FID_CACHE.set(cacheKey, new Set());
        return;
      }}

      const srcShapes = [];
      let srcPoly = _isPolyGeomType(LAYER_GEOM_TYPES[srcLayer]);
      let lastYield = Date.now();
      for (let si = 0; si < matchingSrc.length; si++) {{
        const shp = _rowExactShape(srcLayer, matchingSrc[si]);
        if (!shp) {{
          _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, 'incomplete_exact_geometries');
          return;
        }}
        if (/polygon/i.test(String(shp.geom.type || ''))) srcPoly = true;
        srcShapes.push(shp);
        if ((si & 255) === 0 && (Date.now() - lastYield) >= 22) {{
          if (typeof onPct === 'function') onPct(0.2 * (si / matchingSrc.length));
          await _yieldToBrowser();
          lastYield = Date.now();
          if (seq !== _FILTER_RENDER_SEQ) return;
        }}
      }}
      if (!srcShapes.length) {{
        _CROSS_LAYER_FID_CACHE.set(cacheKey, new Set());
        return;
      }}

      const tgtMaxByFid = new Map();
      for (let ti = 0; ti < tgtRecs.length; ti++) {{
        const tr = tgtRecs[ti];
        const fidStr = (tr && tr._feature_id !== undefined && tr._feature_id !== null) ? String(tr._feature_id) : '';
        if (fidStr) {{
          const m = Number(tr._geom_area_ha ?? tr.area_ha ?? 0);
          if (Number.isFinite(m) && m > 0) tgtMaxByFid.set(fidStr, m);
        }}
      }}

      const gridInfo = _buildSrcSpatialGrid(srcShapes, 0.03);
      const allowed = new Set();
      let tgtPoly = _isPolyGeomType(LAYER_GEOM_TYPES[layerName]);
      const clippedAreas = (srcPoly && tgtPoly) ? new Map() : null;
      const nTgt = tgtRecs.length;
      lastYield = Date.now();
      for (let ti = 0; ti < nTgt; ti++) {{
        const tr = tgtRecs[ti];
        const fidStr = (tr && tr._feature_id !== undefined && tr._feature_id !== null) ? String(tr._feature_id) : '';
        const tShp = _rowExactShape(layerName, tr);
        if (!tShp) {{
          _CROSS_LAYER_UNAVAIL_CACHE.set(cacheKey, 'incomplete_exact_geometries');
          return;
        }}
        const tIsPolyNow = /polygon/i.test(String(tShp.geom.type || ''));
        if (srcPoly && (tgtPoly || tIsPolyNow)) {{
          const haSum = _querySrcSpatialGridAreaHa(gridInfo, tShp);
          if (haSum > 1e-6 && fidStr) {{
            allowed.add(fidStr);
            const haR = Math.round(haSum * 1000000) / 1000000;
            const maxT = tgtMaxByFid.get(fidStr) || 0;
            if (clippedAreas) clippedAreas.set(fidStr, maxT > 0 ? Math.min(maxT, haR) : haR);
          }}
        }} else {{
          if (_querySrcSpatialGrid(gridInfo, tShp) && fidStr) {{
            allowed.add(fidStr);
          }}
        }}
        if ((ti & 127) === 0 && (Date.now() - lastYield) >= 20) {{
          if (typeof onPct === 'function') onPct(0.2 + 0.8 * (ti / nTgt));
          await _yieldToBrowser();
          lastYield = Date.now();
          if (seq !== _FILTER_RENDER_SEQ) return;
        }}
      }}
      if (seq === _FILTER_RENDER_SEQ) {{
        _CROSS_LAYER_FID_CACHE.set(cacheKey, allowed);
        if (clippedAreas) _CROSS_LAYER_AREA_CACHE.set(cacheKey, clippedAreas);
      }}
    }}

    async function prepareCrossLayerFiltersAsync(seq, onStep) {{
      const entries = Object.entries(ACTIVE_FILTERS);
      if (!entries.length) return;
      const targetLayers = new Set();
      (typeof orderedMapLayerNames === 'function' ? orderedMapLayerNames() : Object.keys(LAYER_RECORDS)).forEach(ln => targetLayers.add(ln));
      (DASHBOARD.widgets || []).forEach(w => {{
        if (w && w.layer_name && LAYER_RECORDS[w.layer_name]) targetLayers.add(w.layer_name);
      }});
      const pairs = [];
      entries.forEach(([, flt]) => {{
        if (!flt || flt.type === 'spatial_geom' || flt.type === 'spatial_bbox') return;
        const sources = getFilterSources(flt);
        sources.forEach(s => {{
          if (!s.layer_name || s.layer_name === '__spatial__' || !_isSpatialLayer(s.layer_name)) return;
          targetLayers.forEach(tln => {{
            if (!tln || tln === s.layer_name || !_isSpatialLayer(tln)) return;
            const proxy = Object.assign({{}}, flt, {{ layer_name: s.layer_name, field_name: s.field_name || flt.field_name, layer_fields: [] }});
            const ckey = _crossLayerCacheKey(proxy, s.layer_name, tln);
            if (!_CROSS_LAYER_FID_CACHE.has(ckey) && !_CROSS_LAYER_UNAVAIL_CACHE.has(ckey)) {{
              pairs.push({{ proxy, tln }});
            }}
          }});
        }});
      }});
      for (let pi = 0; pi < pairs.length; pi++) {{
        if (seq !== _FILTER_RENDER_SEQ) return;
        const job = pairs[pi];
        await _resolveSingleSourceCrossLayerAsync(job.proxy, job.tln, seq, f => {{
          if (typeof onStep === 'function') onStep(job.tln, (pi + f) / Math.max(1, pairs.length));
        }});
      }}
    }}

    function resolveCrossLayerAllowedFids(flt, layerName) {{
      const res = resolveCrossLayerResult(flt, layerName);
      return res ? res.allowed : null;
    }}

    function shouldFilterApply(srcId, flt, targetWidgetId, layerName) {{
      const outgoing = getConnectionsFrom(srcId);
      const targetWidget = targetWidgetId
        ? (targetWidgetId === '__map__'
            ? getActiveMapWidget()
            : (DASHBOARD.widgets || []).find(w => w.id === targetWidgetId))
        : null;
      const normSrc = normalizeWidgetSourceId(srcId);
      const srcItem = (DASHBOARD.widgets || []).concat(DASHBOARD.slicers || []).find(it => it && it.id === normSrc);
      const fltIsGlobal = Boolean(flt && flt.is_global) || Boolean(srcItem && srcItem.is_global);
      const fltPageId = (flt && flt.page_id) || (srcItem && srcItem.page_id) || '';
      if (targetWidget && fltPageId && !fltIsGlobal) {{
        const tgtPageId = String(targetWidget.page_id || 'page_1');
        if (String(fltPageId) !== tgtPageId) {{
          const mSet = mapTargetIdSet();
          const hasExplicitConn = targetWidgetId === '__map__'
            ? outgoing.some(c => mSet.has(c.target_id) && c.action !== 'zoom_only')
            : outgoing.some(c => c.target_id === targetWidgetId && c.action !== 'zoom_only');
          if (!hasExplicitConn) return false;
        }}
      }}
      const isSpatialFlt = Boolean(flt && (flt.layer_name === '__spatial__' || flt.type === 'spatial_geom' || flt.type === 'spatial_bbox'));
      const srcList = getFilterSources(flt);
      const srcLayerSet = new Set(srcList.map(s => s.layer_name));
      if (outgoing.length > 0 && targetWidgetId) {{
        if (targetWidgetId === '__map__') {{
          const mSet = mapTargetIdSet();
          const mapConns = outgoing.filter(c => mSet.has(c.target_id) && c.action !== 'zoom_only');
          if (!mapConns.length) return false;
          if (isSpatialFlt) return true;
          if (srcLayerSet.size && layerName && !srcLayerSet.has(layerName)) {{
            if (resolveCrossLayerAllowedFids(flt, layerName) !== null) return true;
            const recs = LAYER_RECORDS[layerName] || [];
            return recs.some(r => r && srcList.some(s => s.field_name && r[s.field_name] !== undefined));
          }}
          return true;
        }}
        return outgoing.some(c => c.target_id === targetWidgetId && c.action !== 'zoom_only');
      }}
      if (isSpatialFlt) return true;
      if (srcLayerSet.size && layerName && !srcLayerSet.has(layerName)) return false;
      return true;
    }}

    function filterRecords(layerName, excludeSourceId, targetWidgetId) {{
      const all = LAYER_RECORDS[layerName] || Object.values(LAYER_RECORDS)[0] || [];
      let bounds = null;
      if (EXTENT_FILTER_ENABLED && map) {{
        bounds = map.getBounds();
      }}
      const directFilters = [];
      const crossAllowedSets = [];
      const crossClippedMaps = [];
      let unavailableReason = '';
      const exNorm = excludeSourceId ? normalizeWidgetSourceId(excludeSourceId) : '';
      for (const [srcId, flt] of Object.entries(ACTIVE_FILTERS)) {{
        if (excludeSourceId && (srcId === excludeSourceId || normalizeWidgetSourceId(srcId) === exNorm)) continue;
        if (!shouldFilterApply(srcId, flt, targetWidgetId, layerName)) continue;
        const isSpatialFlt = Boolean(flt && (flt.layer_name === '__spatial__' || flt.type === 'spatial_geom' || flt.type === 'spatial_bbox'));
        const srcLayerSet = new Set(getFilterSources(flt).map(s => s.layer_name));
        if (!isSpatialFlt && srcLayerSet.size && layerName && !srcLayerSet.has(layerName)) {{
          const cres = resolveCrossLayerResult(flt, layerName);
          if (cres && cres.unavailable) {{
            unavailableReason = cres.reason || 'incomplete_exact_geometries';
            continue;
          }}
          if (cres && cres.allowed !== null) {{
            crossAllowedSets.push(cres.allowed);
            if (cres.clippedAreas && cres.clippedAreas.size > 0) crossClippedMaps.push(cres.clippedAreas);
            continue;
          }}
        }}
        directFilters.push(flt);
      }}
      if (unavailableReason) {{
        const emptyRes = [];
        emptyRes._spatialUnavailableReason = unavailableReason;
        return emptyRes;
      }}
      const matched = all.filter(row => {{
        if (bounds && row._lat !== undefined && row._lon !== undefined) {{
          if (!bounds.contains([Number(row._lat), Number(row._lon)])) return false;
        }}
        if (crossAllowedSets.length) {{
          const fidStr = (row._feature_id !== undefined && row._feature_id !== null) ? String(row._feature_id) : '';
          if (!fidStr || crossAllowedSets.some(setObj => !setObj.has(fidStr))) return false;
        }}
        for (const flt of directFilters) {{
          if (!_filterRowMatchesAttr(row, flt, layerName)) return false;
        }}
        return true;
      }});
      if (crossClippedMaps.length && targetWidgetId !== '__map__') {{
        return matched.map(row => {{
          const fidStr = (row._feature_id !== undefined && row._feature_id !== null) ? String(row._feature_id) : '';
          const origHa = Number(row._geom_area_ha ?? row.area_ha ?? 0);
          let clipHa = origHa;
          for (const cmap of crossClippedMaps) {{
            if (cmap.has(fidStr)) clipHa = Math.min(clipHa, Number(cmap.get(fidStr)));
          }}
          if (!Number.isFinite(clipHa) || clipHa === origHa) return row;
          return Object.assign({{}}, row, {{ _geom_area_ha: clipHa, area_ha: clipHa }});
        }});
      }}
      return matched;
    }}

    function computeMetric(vals, agg) {{
      const mode = (agg || 'count').toLowerCase();
      if (mode === 'count') return vals.length;
      if (mode === 'distinct_count') {{
        return new Set(vals.filter(v => v !== null && v !== undefined && v !== '').map(String)).size;
      }}
      const nums = vals.map(v => Number(v)).filter(n => !isNaN(n));
      if (!nums.length) return 0;
      const sum = nums.reduce((a, b) => a + b, 0);
      if (mode === 'sum') return sum;
      if (mode === 'avg' || mode === 'mean') return sum / nums.length;
      if (mode === 'min') return Math.min(...nums);
      if (mode === 'max') return Math.max(...nums);
      if (mode === 'median') {{
        const s = [...nums].sort((a, b) => a - b);
        const mid = Math.floor(s.length / 2);
        return s.length % 2 !== 0 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
      }}
      return vals.length;
    }}

    function resolveFieldVal(row, fieldName) {{
      if (!row || !fieldName) return null;
      const fnLower = String(fieldName).trim().toLowerCase();
      if (
        fieldName === '__calc_count__'
        || fnLower === 'calculate count'
        || fnLower === 'kirjete arv'
      ) {{
        return 1;
      }}
      if (
        fieldName === '__calc_area_ha__'
        || fnLower === 'calculate area (ha)'
        || fnLower === 'arvuta pindala (ha)'
      ) {{
        const candidates = ['_geom_area_ha', 'area_ha', 'pindala_ha', 'natura_overlap_ha', 'pria_overlap_ha', 'pindala', 'shape_area'];
        for (const key of candidates) {{
          const v = row[key];
          if (v !== null && v !== undefined && v !== '' && !isNaN(Number(v))) {{
            const n = Number(v);
            return (key === 'pindala' || key === 'shape_area') ? n / 10000.0 : n;
          }}
        }}
        return 0;
      }}
      return row[fieldName];
    }}

    function friendlyFieldLabel(fieldName) {{
      if (fieldName === '__calc_area_ha__') return CURR_LANG === 'et' ? 'Pindala (ha)' : 'Area (ha)';
      if (fieldName === '__calc_count__') return CURR_LANG === 'et' ? 'Kirjete arv' : 'Record Count';
      return fieldName;
    }}

    function widgetFieldLabel(w, fieldName) {{
      const aliases = (w && w.field_aliases && typeof w.field_aliases === 'object') ? w.field_aliases : null;
      if (aliases && fieldName) {{
        const custom = aliases[fieldName];
        if (custom !== undefined && custom !== null && String(custom).trim() !== '') {{
          return String(custom).trim();
        }}
      }}
      return friendlyFieldLabel(fieldName);
    }}

    function transposeTableMatrix(headers, matrix, cornerLabel) {{
      if (!headers || !headers.length) return {{ headers: [], rows: [], isPivot: false }};
      const rowLabels = matrix.map((r, i) => (r && r.length) ? String(r[0]) : String(i + 1));
      const newHeaders = [cornerLabel || (CURR_LANG === 'et' ? 'Väli' : 'Field'), ...rowLabels];
      const newRows = [];
      for (let c = 1; c < headers.length; c++) {{
        const line = [headers[c]];
        matrix.forEach(r => line.push((c < r.length) ? r[c] : ''));
        newRows.push(line);
      }}
      if (headers.length === 1 && matrix.length) {{
        const line = [headers[0]];
        matrix.forEach(r => line.push(r[0]));
        return {{ headers: [cornerLabel || '#', ...rowLabels], rows: [line], isPivot: false }};
      }}
      return {{ headers: newHeaders, rows: newRows, isPivot: false }};
    }}

    function resolveSpatialPivotRows(w, baseRows) {{
      if (baseRows && baseRows._spatialUnavailableReason) return baseRows;
      const joinName = w.spatial_join_layer;
      if (!joinName || !Array.isArray(baseRows) || !baseRows.length) return baseRows;
      const prefix = `[${{joinName}}] `;
      if (Object.keys(baseRows[0] || {{}}).some(k => k.startsWith(prefix))) return baseRows;

      const joinRecs = LAYER_RECORDS[joinName] || [];
      if (!joinRecs.length) {{
        const unavail = [];
        unavail._spatialUnavailableReason = 'missing_target_records';
        return unavail;
      }}
      const noOverlap = CURR_LANG === 'et' ? '(Kattuvus puudub)' : '(No overlap)';
      const joinKeys = Object.keys(joinRecs[0] || {{}}).filter(k => !k.startsWith('_'));
      const out = [];
      const makeRow = (br, jr, haVal) => {{
        const merged = Object.assign({{}}, br);
        joinKeys.forEach(jk => {{
          merged[`${{prefix}}${{jk}}`] = jr ? jr[jk] : noOverlap;
        }});
        merged._geom_area_ha = haVal;
        merged.area_ha = haVal;
        return merged;
      }};

      const rel = SPATIAL_RELATIONS.get(_srPairKey(w.layer_name, joinName));
      if (rel) {{
        if (!rel.complete || !rel.exact) {{
          const unavail = [];
          unavail._spatialUnavailableReason = rel.reason || 'incomplete_data';
          return unavail;
        }}
        const cntA = (LAYER_RECORDS[rel.layer_a] || []).length;
        const cntB = (LAYER_RECORDS[rel.layer_b] || []).length;
        if (rel.byA && rel.byB && Number(rel.count_a) === cntA && Number(rel.count_b) === cntB) {{
          const adj = (w.layer_name === rel.layer_a) ? rel.byA : rel.byB;
          const bothPoly = (rel.geom_kind_a === 'polygon' && rel.geom_kind_b === 'polygon');
          const joinByFid = new Map();
          joinRecs.forEach(jr => {{
            const jfid = (jr && jr._feature_id !== undefined && jr._feature_id !== null) ? String(jr._feature_id) : '';
            if (jfid) joinByFid.set(jfid, jr);
          }});
          baseRows.forEach(br => {{
            const bfid = String(br._feature_id ?? '');
            const baseHa = Number(br._geom_area_ha ?? br.area_ha ?? 0);
            const edges = bfid ? adj.get(bfid) : null;
            if (!edges || !edges.length) {{
              out.push(makeRow(br, null, baseHa));
              return;
            }}
            let matchedSum = 0;
            edges.forEach(([jfid, ha]) => {{
              const jr = joinByFid.get(jfid);
              if (!jr) return;
              const useHa = (bothPoly && ha >= 0) ? Math.min(baseHa > 0 ? baseHa : ha, ha) : baseHa;
              out.push(makeRow(br, jr, Math.round(useHa * 1000000) / 1000000));
              if (bothPoly && ha >= 0) matchedSum += useHa;
            }});
            if (bothPoly && baseHa - matchedSum > 0.0001) {{
              out.push(makeRow(br, null, Math.round((baseHa - matchedSum) * 1000000) / 1000000));
            }}
          }});
          return out;
        }}
      }}

      if (!_layerHasCompleteExactGeoms(w.layer_name) || !_layerHasCompleteExactGeoms(joinName)) {{
        const unavail = [];
        unavail._spatialUnavailableReason = 'incomplete_exact_geometries';
        return unavail;
      }}

      const joinIndex = [];
      let joinPoly = _isPolyGeomType(LAYER_GEOM_TYPES[joinName]);
      for (let ji = 0; ji < joinRecs.length; ji++) {{
        const jr = joinRecs[ji];
        const shp = _rowExactShape(joinName, jr);
        if (!shp) {{
          const unavail = [];
          unavail._spatialUnavailableReason = 'incomplete_exact_geometries';
          return unavail;
        }}
        if (/polygon/i.test(String(shp.geom.type || ''))) joinPoly = true;
        joinIndex.push({{ rec: jr, geom: shp.geom, bbox: shp.bbox }});
      }}
      const basePoly = _isPolyGeomType(LAYER_GEOM_TYPES[w.layer_name]);
      const bothPolyExact = Boolean(basePoly && joinPoly);

      for (let bi = 0; bi < baseRows.length; bi++) {{
        const br = baseRows[bi];
        const bShp = _rowExactShape(w.layer_name, br);
        if (!bShp) {{
          const unavail = [];
          unavail._spatialUnavailableReason = 'incomplete_exact_geometries';
          return unavail;
        }}
        const baseHa = Number(br._geom_area_ha ?? br.area_ha ?? 0);
        const cands = joinIndex.filter(c => _bboxOverlaps2D(bShp.bbox, c.bbox));
        if (!cands.length) {{
          out.push(makeRow(br, null, baseHa));
          continue;
        }}
        let matchedCount = 0;
        let matchedSum = 0;
        for (let ci = 0; ci < cands.length; ci++) {{
          const c = cands[ci];
          if (bothPolyExact) {{
            const ha = exactPolygonIntersectionAreaHa(bShp.geom, c.geom);
            if (ha > 1e-6) {{
              matchedCount++;
              const haR = Math.round(Math.min(baseHa > 0 ? baseHa : ha, ha) * 1000000) / 1000000;
              matchedSum += haR;
              out.push(makeRow(br, c.rec, haR));
            }}
          }} else if (geomIntersectsGeom(bShp.geom, c.geom)) {{
            matchedCount++;
            out.push(makeRow(br, c.rec, baseHa));
          }}
        }}
        if (matchedCount === 0) {{
          out.push(makeRow(br, null, baseHa));
        }} else if (bothPolyExact && baseHa - matchedSum > 0.0001) {{
          out.push(makeRow(br, null, Math.round((baseHa - matchedSum) * 1000000) / 1000000));
        }}
      }}
      return out;
    }}

    function computeTableData(w, rawRows) {{
      const rows = resolveSpatialPivotRows(w, rawRows);
      const mode = w.table_mode || ((w.pivot_rows && w.pivot_rows.length) || (w.pivot_values && w.pivot_values.length) ? 'pivot' : 'detail');
      const transpose = !!w.table_transpose;
      if (mode !== 'pivot') {{
        const cols = (w.table_columns && w.table_columns.length)
          ? w.table_columns
          : Object.keys(rows[0] || {{}}).filter(k => !k.startsWith('_')).slice(0, 8);
        const headers = cols.map(c => widgetFieldLabel(w, c));
        const matrix = rows.slice(0, 120).map(r => cols.map(c => resolveFieldVal(r, c)));
        const fids = rows.slice(0, 120).map(r => ({{
          fid: r._feature_id ?? '',
          lat: r._lat ?? '',
          lon: r._lon ?? '',
          bbox: Array.isArray(r._bbox) ? r._bbox : null
        }}));
        if (transpose) {{
          const trRes = transposeTableMatrix(headers, matrix, CURR_LANG === 'et' ? 'Veerg' : 'Column');
          return {{ ...trRes, rowMeta: [], transposed: true }};
        }}
        return {{ headers, rows: matrix, rowMeta: fids, isPivot: false, transposed: false }};
      }}

      const pRows = (w.pivot_rows && w.pivot_rows.length) ? w.pivot_rows : (w.category_field ? [w.category_field] : []);
      const pCols = w.pivot_cols || [];
      let pVals = (w.pivot_values && w.pivot_values.length) ? w.pivot_values : [];
      if (!pVals.length) {{
        pVals = [{{ field: w.value_field || '__calc_area_ha__', agg: w.aggregation || 'sum' }}];
      }}
      const rowHeaderLabel = pRows.length ? pRows.map(f => widgetFieldLabel(w, f)).join(' / ') : (CURR_LANG === 'et' ? 'Kategooria' : 'Category');
      const rowKey = r => pRows.length ? pRows.map(f => {{
        const v = resolveFieldVal(r, f);
        return (v !== null && v !== undefined && String(v).trim() !== '') ? String(v) : (CURR_LANG === 'et' ? '(Määramata)' : '(Unassigned)');
      }}).join(' / ') : (CURR_LANG === 'et' ? 'Kokku' : 'All');

      const aggName = a => ({{ sum: 'Σ', count: '#', distinct_count: 'U', avg: 'μ', min: 'Min', max: 'Max', median: 'Med' }}[a] || a);
      const valLabel = sp => {{
        const aliases = (w && w.field_aliases && typeof w.field_aliases === 'object') ? w.field_aliases : {{}};
        const agg = sp.agg || 'sum';
        const fld = sp.field || '';
        const mKey = `${{agg}}:${{fld}}`;
        if (sp.label && String(sp.label).trim() !== '') return String(sp.label).trim();
        if (aliases[mKey] && String(aliases[mKey]).trim() !== '') return String(aliases[mKey]).trim();
        const defLbl = `${{aggName(agg)}} ${{friendlyFieldLabel(fld)}}`;
        if (aliases[defLbl] && String(aliases[defLbl]).trim() !== '') return String(aliases[defLbl]).trim();
        return defLbl;
      }};

      const rowBuckets = new Map();
      const colBuckets = new Map();
      const cellMap = new Map();
      const colSet = new Set();

      rows.forEach(r => {{
        const rk = rowKey(r);
        if (!rowBuckets.has(rk)) rowBuckets.set(rk, []);
        rowBuckets.get(rk).push(r);
        if (pCols.length) {{
          const ck = pCols.map(f => {{
            const v = resolveFieldVal(r, f);
            return (v !== null && v !== undefined && String(v).trim() !== '') ? String(v) : '(Unassigned)';
          }}).join(' / ');
          colSet.add(ck);
          if (!colBuckets.has(ck)) colBuckets.set(ck, []);
          colBuckets.get(ck).push(r);
          const cellKey = rk + '||' + ck;
          if (!cellMap.has(cellKey)) cellMap.set(cellKey, []);
          cellMap.get(cellKey).push(r);
        }}
      }});

      const rowKeys = Array.from(rowBuckets.keys());
      const colKeys = Array.from(colSet).sort();
      let headers = [rowHeaderLabel];
      if (colKeys.length) {{
        colKeys.forEach(ck => pVals.forEach(sp => headers.push(pVals.length === 1 ? ck : `${{ck}} (${{valLabel(sp)}})`)));
      }} else {{
        pVals.forEach(sp => headers.push(valLabel(sp)));
      }}

      const calcSpec = (subset, sp) => {{
        const a = (sp.agg || 'sum').toLowerCase();
        const f = sp.field || '__calc_count__';
        if (a === 'count' && (f === '__calc_count__' || !f)) return subset.length;
        return computeMetric(subset.map(r => resolveFieldVal(r, f)), a);
      }};

      const combinedRows = [];
      rowKeys.forEach(rk => {{
        const line = [rk];
        const grp = rowBuckets.get(rk) || [];
        if (colKeys.length) {{
          colKeys.forEach(ck => {{
            const sub = cellMap.get(rk + '||' + ck) || [];
            pVals.forEach(sp => line.push(sub.length ? calcSpec(sub, sp) : 0));
          }});
        }} else {{
          pVals.forEach(sp => line.push(calcSpec(grp, sp)));
        }}
        combinedRows.push({{
          line,
          meta: {{ filterField: pRows[0] || '', filterVal: rk }}
        }});
      }});
      combinedRows.sort((a, b) => (Number(b.line[1]) || 0) - (Number(a.line[1]) || 0));
      const matrix = combinedRows.map(item => item.line);
      const rowMeta = combinedRows.map(item => item.meta);

      if (w.table_show_totals !== false && matrix.length) {{
        const totLbl = CURR_LANG === 'et' ? 'Kokku' : 'Total';
        const totRow = [totLbl];
        if (colKeys.length) {{
          colKeys.forEach(ck => {{
            const csub = colBuckets.get(ck) || [];
            pVals.forEach(sp => totRow.push(calcSpec(csub, sp)));
          }});
        }} else {{
          pVals.forEach(sp => totRow.push(calcSpec(rows, sp)));
        }}
        matrix.push(totRow);
        rowMeta.push({{ isTotal: true }});
      }}

      if (transpose) {{
        const trRes = transposeTableMatrix(headers, matrix, rowHeaderLabel);
        return {{ ...trRes, rowMeta: [], transposed: true }};
      }}
      return {{ headers, rows: matrix, rowMeta, isPivot: true, transposed: false }};
    }}

    function toggleTableTranspose(wid) {{
      const w = (DASHBOARD.widgets || []).find(x => x.id === wid);
      if (w) {{
        w.table_transpose = !w.table_transpose;
        renderAll();
      }}
    }}

    async function triggerRenderWithBusyFeedback(opts) {{
      const mySeq = ++_FILTER_RENDER_SEQ;
      const totalRecs = Object.values(LAYER_RECORDS).reduce((acc, a) => acc + (Array.isArray(a) ? a.length : 0), 0);
      const hasActiveFilters = Object.keys(ACTIVE_FILTERS).length > 0;
      const showOverlay = (totalRecs >= 2500 && hasActiveFilters) || totalRecs >= 8000;
      beginMapRenderLoader(t('map_rendering_layers'));
      if (showOverlay) {{
        showDashboardLoader(t('loader_stage_filter'), '', 12);
      }}
      try {{
        if (typeof requestAnimationFrame === 'function') await _yieldToBrowser();
        if (mySeq !== _FILTER_RENDER_SEQ) return;
        if (hasActiveFilters && typeof prepareCrossLayerFiltersAsync === 'function') {{
          await prepareCrossLayerFiltersAsync(mySeq, (ln, frac) => {{
            if (showOverlay) {{
              showDashboardLoader(t('loader_stage_filter'), ln || '', 15 + Math.round(frac * 65));
            }}
          }});
        }}
        if (mySeq !== _FILTER_RENDER_SEQ) return;
        if (showOverlay) {{
          showDashboardLoader(t('loader_stage_render'), '', 88);
          await _yieldToBrowser();
          if (mySeq !== _FILTER_RENDER_SEQ) return;
        }}
        renderAll(opts);
        if (showOverlay) showDashboardLoader(t('loader_stage_render'), '', 100);
      }} finally {{
        if (mySeq === _FILTER_RENDER_SEQ && showOverlay) {{
          hideDashboardLoader();
        }}
        endMapRenderLoader(false);
      }}
    }}

    function toggleAutoHomeOnClear(val) {{
      AUTO_HOME_ON_FILTER_CLEAR = Boolean(val);
      const chk = document.getElementById('chk-opt-autohome');
      if (chk) chk.checked = AUTO_HOME_ON_FILTER_CLEAR;
      saveDashboardSessionState();
      return AUTO_HOME_ON_FILTER_CLEAR;
    }}

    function _sessionStorageKey() {{
      try {{
        if (typeof window !== 'undefined' && window.location) {{
          const dashId = (typeof DASHBOARD !== 'undefined' && DASHBOARD && DASHBOARD.id)
            ? String(DASHBOARD.id)
            : '';
          return 'qdash_state:' + String(window.location.pathname || '') + '|' + dashId;
        }}
      }} catch (_e) {{}}
      return '';
    }}

    function saveDashboardSessionState() {{
      try {{
        const key = _sessionStorageKey();
        if (!key || typeof window === 'undefined' || !window.sessionStorage) return;
        let view = null;
        if (map && typeof map.getCenter === 'function' && typeof map.getZoom === 'function') {{
          const c = map.getCenter();
          if (c && Number.isFinite(Number(c.lat)) && Number.isFinite(Number(c.lng))) {{
            view = {{ lat: Number(c.lat), lng: Number(c.lng), zoom: Number(map.getZoom()) }};
          }}
        }}
        window.sessionStorage.setItem(key, JSON.stringify({{
          filters: ACTIVE_FILTERS,
          extent: Boolean(EXTENT_FILTER_ENABLED),
          autoHome: Boolean(AUTO_HOME_ON_FILTER_CLEAR),
          activePageId: ACTIVE_PAGE_ID,
          scrollSens: MAP_SCROLL_SENSITIVITY,
          view: view
        }}));
      }} catch (_e) {{}}
    }}

    function clearDashboardSessionState() {{
      try {{
        const key = _sessionStorageKey();
        if (key && typeof window !== 'undefined' && window.sessionStorage) {{
          window.sessionStorage.removeItem(key);
        }}
      }} catch (_e) {{}}
    }}

    function restoreDashboardSessionState() {{
      try {{
        const key = _sessionStorageKey();
        if (!key || typeof window === 'undefined' || !window.sessionStorage) return false;
        const raw = window.sessionStorage.getItem(key);
        if (!raw) return false;
        const st = JSON.parse(raw);
        if (!st || typeof st !== 'object') return false;
        if (st.filters && typeof st.filters === 'object') {{
          Object.keys(ACTIVE_FILTERS).forEach(k => delete ACTIVE_FILTERS[k]);
          Object.entries(st.filters).forEach(([k, v]) => {{
            if (v && typeof v === 'object') ACTIVE_FILTERS[k] = v;
          }});
        }}
        if (typeof st.extent === 'boolean') {{
          EXTENT_FILTER_ENABLED = st.extent;
          updateExtentButtonUI();
        }}
        if (typeof st.autoHome === 'boolean') {{
          AUTO_HOME_ON_FILTER_CLEAR = st.autoHome;
          const chk = document.getElementById('chk-opt-autohome');
          if (chk) chk.checked = AUTO_HOME_ON_FILTER_CLEAR;
        }}
        if (!_URL_PAGE_ID && st.activePageId && (DASHBOARD.pages || []).some(p => p.id === st.activePageId)) {{
          ACTIVE_PAGE_ID = st.activePageId;
          if (typeof _activateMapWidgetState === 'function') {{
            _activateMapWidgetState(getActiveMapWidget());
          }}
        }}
        if (st.scrollSens !== undefined && typeof applyMapScrollSensitivity === 'function') {{
          applyMapScrollSensitivity(st.scrollSens);
        }}
        const hasConfiguredHome = Boolean(HOME_MAP_VIEW && Array.isArray(HOME_MAP_VIEW.bounds) && HOME_MAP_VIEW.bounds.length === 4);
        if (!hasConfiguredHome && st.view && map && Number.isFinite(Number(st.view.lat)) && Number.isFinite(Number(st.view.lng)) && Number.isFinite(Number(st.view.zoom))) {{
          safeSetView([Number(st.view.lat), Number(st.view.lng)], Number(st.view.zoom));
          return true;
        }}
        return Object.keys(ACTIVE_FILTERS).length > 0;
      }} catch (_e) {{
        return false;
      }}
    }}

    function toggleCategoryFilter(sourceId, layerName, fieldName, value, forceZoom, extraOpts) {{
      const eopts = extraOpts || {{}};
      const wasActiveCount = Object.keys(ACTIVE_FILTERS).length;
      const srcMeta = (DASHBOARD.widgets || []).concat(DASHBOARD.slicers || []).find(it => it && it.id === normalizeWidgetSourceId(sourceId));
      const pageId = srcMeta ? (srcMeta.page_id || ACTIVE_PAGE_ID) : ACTIVE_PAGE_ID;
      const isGlobal = Boolean(srcMeta && srcMeta.is_global);
      const cur = ACTIVE_FILTERS[sourceId];
      const wantsMulti = eopts.multi !== undefined ? Boolean(eopts.multi) : Boolean(cur && cur.multi);
      const layerFields = Array.isArray(eopts.layerFields) && eopts.layerFields.length
        ? eopts.layerFields.map(s => ({{ layer_name: String(s.layer_name || ''), field_name: String(s.field_name || fieldName || '') }}))
        : (cur && Array.isArray(cur.layer_fields) ? cur.layer_fields : []);
      if (cur && cur.values && cur.values.includes(String(value))) {{
        cur.values = cur.values.filter(v => v !== String(value));
        if (layerFields.length) cur.layer_fields = layerFields;
        if (!cur.values.length) {{
          delete ACTIVE_FILTERS[sourceId];
          if (LAST_INTERACTED_FILTER_SOURCE === sourceId) LAST_INTERACTED_FILTER_SOURCE = null;
        }} else {{
          LAST_INTERACTED_FILTER_SOURCE = sourceId;
        }}
      }} else if (cur && wantsMulti) {{
        cur.multi = true;
        if (layerFields.length) cur.layer_fields = layerFields;
        cur.values.push(String(value));
        LAST_INTERACTED_FILTER_SOURCE = sourceId;
      }} else {{
        ACTIVE_FILTERS[sourceId] = {{
          layer_name: layerName,
          field_name: fieldName,
          layer_fields: layerFields,
          type: 'category',
          multi: wantsMulti,
          values: [String(value)],
          page_id: pageId,
          is_global: isGlobal
        }};
        LAST_INTERACTED_FILTER_SOURCE = sourceId;
      }}
      saveDashboardSessionState();
      devLog('INFO', 'FILTER', `Filter toggled: ${{layerName}}.${{fieldName}} = ${{value}}`, `active=${{Object.keys(ACTIVE_FILTERS).length}}`);
      if (srcMeta && srcMeta.drill_to_page_id && ACTIVE_FILTERS[sourceId]) {{
        switchDashboardPage(srcMeta.drill_to_page_id, {{ skipRender: true }});
      }}
      buildSlicers();
      if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
      const willAutoHome = Boolean(wasActiveCount > 0 && Object.keys(ACTIVE_FILTERS).length === 0 && AUTO_HOME_ON_FILTER_CLEAR && !EXTENT_FILTER_ENABLED);
      triggerRenderWithBusyFeedback({{ forceZoom: Boolean(forceZoom) && !willAutoHome, skipAutoZoom: willAutoHome }});
    }}

    function clearWidgetFilter(widgetOrSlicerId) {{
      if (widgetOrSlicerId === '__map_addr__' || String(widgetOrSlicerId || '').endsWith('__addr')) {{
        clearAddressSearchResult();
        return;
      }}
      const rawStr = String(widgetOrSlicerId || '');
      const baseId = normalizeWidgetSourceId(rawStr);
      const isSpecificPane = rawStr !== baseId && rawStr.indexOf('__pane_') >= 0;
      let removed = false;
      Object.keys(ACTIVE_FILTERS).forEach(k => {{
        const match = isSpecificPane
          ? (k === rawStr)
          : (k === rawStr || k === baseId || normalizeWidgetSourceId(k) === baseId || k.startsWith(baseId + '__pane_'));
        if (match) {{
          delete ACTIVE_FILTERS[k];
          removed = true;
        }}
      }});
      if (LAST_INTERACTED_FILTER_SOURCE) {{
        const lastNorm = normalizeWidgetSourceId(LAST_INTERACTED_FILTER_SOURCE);
        if ((isSpecificPane && LAST_INTERACTED_FILTER_SOURCE === rawStr) || (!isSpecificPane && lastNorm === baseId)) {{
          LAST_INTERACTED_FILTER_SOURCE = null;
        }}
      }}
      if (removed) {{
        devLog('INFO', 'FILTER', `Cleared filter: ${{rawStr}}`, `active=${{Object.keys(ACTIVE_FILTERS).length}}`);
        saveDashboardSessionState();
        buildSlicers();
        if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
        triggerRenderWithBusyFeedback({{ skipAutoZoom: true }});
      }}
    }}

    function clearAllFilters() {{
      Object.keys(ACTIVE_FILTERS).forEach(k => delete ACTIVE_FILTERS[k]);
      LAST_INTERACTED_FILTER_SOURCE = null;
      devLog('INFO', 'FILTER', 'Cleared all filters.');
      if (ADDRESS_RESULT_LAYER && map && map.hasLayer && map.hasLayer(ADDRESS_RESULT_LAYER)) {{
        map.removeLayer(ADDRESS_RESULT_LAYER);
      }}
      ADDRESS_RESULT_LAYER = null;
      const addrInp = document.getElementById('map-addr-input');
      if (addrInp) addrInp.value = '';
      saveDashboardSessionState();
      buildSlicers();
      if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
      triggerRenderWithBusyFeedback();
    }}

    function _formatFilterSummaryText(flt) {{
      if (!flt) return '';
      if (flt.display_label) return `${{flt.field_name || ''}}: ${{flt.display_label}}`.replace(/^:\\s*/, '');
      if (flt.type === 'category' && Array.isArray(flt.values) && flt.values.length) {{
        const vals = flt.values.slice(0, 3).join(', ') + (flt.values.length > 3 ? ` (+${{flt.values.length - 3}})` : '');
        return `${{friendlyFieldLabel(flt.field_name)}}: ${{vals}}`;
      }}
      if (flt.type === 'numeric_range' || flt.type === 'date_range') {{
        const lo = (flt.min !== null && flt.min !== undefined && flt.min !== '') ? flt.min : '…';
        const hi = (flt.max !== null && flt.max !== undefined && flt.max !== '') ? flt.max : '…';
        return `${{friendlyFieldLabel(flt.field_name)}}: ${{lo}} – ${{hi}}`;
      }}
      if (flt.type === 'spatial_geom' || flt.type === 'spatial_bbox') {{
        return flt.display_label || t('addr_search_btn');
      }}
      return flt.field_name || '';
    }}

    function _getIncomingFilterBadgeText(targetWidgetId, layerName) {{
      const labels = [];
      for (const [srcId, flt] of Object.entries(ACTIVE_FILTERS)) {{
        if (normalizeWidgetSourceId(srcId) === normalizeWidgetSourceId(targetWidgetId)) continue;
        if (!shouldFilterApply(srcId, flt, targetWidgetId, layerName)) continue;
        const txt = _formatFilterSummaryText(flt);
        if (txt && !labels.includes(txt)) labels.push(txt);
      }}
      if (!labels.length) return '';
      const head = labels.slice(0, 2).join('; ');
      const suffix = labels.length > 2 ? ` (+${{labels.length - 2}})` : '';
      return `⚡ ${{t('filter_badge_prefix')}}: ${{head}}${{suffix}}`;
    }}

    function renderActiveFiltersBanner() {{
      const bar = document.getElementById('active-filters-bar');
      if (!bar) return;
      const entries = Object.entries(ACTIVE_FILTERS);
      if (!entries.length) {{
        bar.classList.remove('visible');
        bar.innerHTML = '';
        return;
      }}
      bar.classList.add('visible');
      bar.innerHTML = '';
      const lbl = document.createElement('span');
      lbl.style.fontWeight = '700';
      lbl.textContent = `⚡ ${{t('active_filters_title')}}:`;
      bar.appendChild(lbl);
      entries.forEach(([srcId, flt]) => {{
        const chip = document.createElement('span');
        chip.className = 'active-filter-chip';
        const srcObj = (DASHBOARD.widgets || []).concat(DASHBOARD.slicers || []).find(it => it && it.id === normalizeWidgetSourceId(srcId));
        const srcPrefix = srcObj ? (localizedTitle(srcObj) + ' · ') : '';
        const txt = document.createElement('span');
        txt.textContent = srcPrefix + _formatFilterSummaryText(flt);
        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.textContent = '✕';
        rmBtn.title = t('btn_clear_filter');
        rmBtn.style.cssText = 'border:none;background:transparent;color:inherit;cursor:pointer;padding:0 4px;min-width:20px;min-height:20px;font-weight:700;';
        rmBtn.onclick = ev => {{
          if (ev && ev.stopPropagation) ev.stopPropagation();
          clearWidgetFilter(srcId);
        }};
        chip.appendChild(txt);
        chip.appendChild(rmBtn);
        bar.appendChild(chip);
      }});
      const clrAll = document.createElement('button');
      clrAll.type = 'button';
      clrAll.className = 'btn-mini-icon';
      clrAll.textContent = t('html_reset_filters');
      clrAll.onclick = () => clearAllFilters();
      bar.appendChild(clrAll);
    }}

    function renderPagesBar() {{
      const bar = document.getElementById('dashboard-pages-bar');
      if (!bar) return;
      const pages = Array.isArray(DASHBOARD.pages) ? DASHBOARD.pages : [];
      if (pages.length <= 1) {{
        bar.classList.remove('visible');
        bar.innerHTML = '';
        return;
      }}
      if (!pages.some(p => p.id === ACTIVE_PAGE_ID)) {{
        ACTIVE_PAGE_ID = pages[0].id;
      }}
      bar.classList.add('visible');
      bar.innerHTML = '';
      pages.forEach(pg => {{
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'page-tab-btn' + (pg.id === ACTIVE_PAGE_ID ? ' active' : '');
        btn.textContent = (LANG === 'en' && pg.title_en) ? pg.title_en : (pg.title || pg.id);
        btn.onclick = () => switchDashboardPage(pg.id);
        bar.appendChild(btn);
      }});
    }}

    function switchDashboardPage(pageId, opts) {{
      if (!pageId || ACTIVE_PAGE_ID === pageId) return;
      if (typeof _saveActiveMapWidgetState === 'function') _saveActiveMapWidgetState();
      ACTIVE_PAGE_ID = String(pageId);
      if (typeof closeRefreshScopeMenu === 'function') closeRefreshScopeMenu();
      const layersDrawer = document.getElementById('map-layers-drawer');
      if (layersDrawer) layersDrawer.style.display = 'none';
      const nextMw = (typeof getActiveMapWidget === 'function') ? getActiveMapWidget() : null;
      const nextSt = (typeof _activateMapWidgetState === 'function') ? _activateMapWidgetState(nextMw) : null;
      if (typeof syncActiveMapLayersAndControl === 'function') {{
        syncActiveMapLayersAndControl(nextSt, {{ applyViewport: !(opts && opts.skipMapViewport) }});
      }}
      saveDashboardSessionState();
      renderPagesBar();
      if (!(opts && opts.skipRender)) {{
        buildSlicers();
        renderActiveFiltersBanner();
        renderMapLayersDrawer();
        renderAll({{ skipAutoZoom: true }});
        updateMapLegend();
        updateMobileNavBar();
        if (map && typeof map.invalidateSize === 'function') {{
          setTimeout(() => {{ try {{ map.invalidateSize(); }} catch (_mi) {{}} }}, 40);
        }}
      }}
      if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
    }}

    function isMobileCardStackActive() {{
      return Boolean(MOBILE_VIEW_ENABLED && !MOBILE_FIT_OVERVIEW);
    }}

    function syncMobileMapTouchLock() {{
      const btn = document.getElementById('btn-mobile-map-lock');
      const canvas = document.getElementById('map-canvas');
      const activeLock = Boolean(isMobileCardStackActive() && MOBILE_MAP_LOCKED);
      if (canvas && canvas.classList) {{
        canvas.classList.toggle('mobile-scroll-locked', activeLock);
      }}
      if (map && map.dragging) {{
        if (activeLock && typeof map.dragging.disable === 'function') {{
          map.dragging.disable();
        }} else if (!activeLock && typeof map.dragging.enable === 'function') {{
          map.dragging.enable();
        }}
      }}
      if (btn) {{
        btn.textContent = t(MOBILE_MAP_LOCKED ? 'mobile_map_lock' : 'mobile_map_unlock');
        btn.title = t('mobile_map_lock_tip');
        if (btn.classList) btn.classList.toggle('active', activeLock);
      }}
    }}

    function toggleMobileMapTouchLock() {{
      MOBILE_MAP_LOCKED = !MOBILE_MAP_LOCKED;
      syncMobileMapTouchLock();
    }}

    function toggleMobileView() {{
      MOBILE_VIEW_ENABLED = !MOBILE_VIEW_ENABLED;
      MOBILE_VIEW_OVERRIDE = MOBILE_VIEW_ENABLED;
      MOBILE_FIT_OVERVIEW = false;
      const ws = document.getElementById('workspace-main');
      if (ws) {{
        ws.style.transform = '';
        ws.style.transformOrigin = '';
        ws.style.marginBottom = '';
        ws.style.marginRight = '';
      }}
      if (typeof document !== 'undefined' && document.body && document.body.classList) {{
        document.body.classList.toggle('mobile-view', isMobileCardStackActive());
      }}
      const btn = document.getElementById('btn-mobile-view');
      if (btn) btn.textContent = MOBILE_VIEW_ENABLED ? t('mobile_view_active') : t('mobile_view_btn');
      applyArtboardLayout();
      updateMobileNavBar();
      syncMobileMapTouchLock();
      if (map && typeof map.invalidateSize === 'function') setTimeout(() => map.invalidateSize(), 60);
      if (typeof document !== 'undefined' && typeof document.querySelectorAll === 'function' && typeof Plotly !== 'undefined' && Plotly && Plotly.Plots) {{
        setTimeout(() => {{
          document.querySelectorAll('.plot-container').forEach(p => {{
            try {{ Plotly.Plots.resize(p); }} catch (_rp) {{}}
          }});
        }}, 80);
      }}
    }}

    let MOBILE_NAV_LOCK_UNTIL = 0;

    function _focusMobileWidgetEl(el) {{
      if (!el) return;
      MOBILE_NAV_LOCK_UNTIL = Date.now() + 550;
      if (typeof el.scrollIntoView === 'function') {{
        el.scrollIntoView({{ behavior: 'smooth', block: 'start' }});
      }}
      if (el.classList) {{
        el.classList.remove('mobile-focus-flash');
        void el.offsetWidth;
        el.classList.add('mobile-focus-flash');
        setTimeout(() => {{
          if (el.classList) el.classList.remove('mobile-focus-flash');
        }}, 900);
      }}
    }}

    function _trimMobileLabel(raw) {{
      const s = String(raw || '').trim();
      if (!s) return 'Widget';
      return s.length > 24 ? s.slice(0, 22).trimEnd() + '…' : s;
    }}

    function _mobileWidgetEls() {{
      const list = [];
      const mapWidget = getActiveMapWidget();
      const mapEl = document.getElementById('map-card');
      if (mapEl && mapEl.style && mapEl.style.display !== 'none') {{
        const rawMapLbl = mapWidget ? localizedTitle(mapWidget) : t('html_map_header');
        list.push({{ el: mapEl, label: _trimMobileLabel(rawMapLbl) }});
      }}
      if (typeof document !== 'undefined' && typeof document.querySelectorAll === 'function') {{
        document.querySelectorAll('#workspace-main [data-widget-id], #workspace-main .slicer-group').forEach(el => {{
          if (!el || el.id === 'map-card' || (el.style && el.style.display === 'none')) return;
          const hdr = el.querySelector ? el.querySelector('.card-header span, .kpi-title, .slicer-label') : null;
          const lbl = hdr ? _trimMobileLabel(hdr.textContent) : ((el.dataset && (el.dataset.widgetId || el.dataset.slicerId)) || 'Widget');
          list.push({{ el, label: lbl }});
        }});
      }}
      return list;
    }}

    function _isEditableEl(el) {{
      if (!el || !el.tagName) return false;
      const tag = String(el.tagName).toUpperCase();
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true;
      return Boolean(el.isContentEditable);
    }}

    function _centerActiveMobilePill(pills, activePill) {{
      if (!pills || !activePill) return;
      const runCenter = () => {{
        const pw = Number(pills.clientWidth || 0);
        const ol = Number(activePill.offsetLeft || 0);
        const ow = Number(activePill.offsetWidth || 0);
        if (pw > 0) {{
          const targetLeft = Math.max(0, Math.round(ol + ow * 0.5 - pw * 0.5));
          if (typeof pills.scrollTo === 'function') {{
            try {{ pills.scrollTo({{ left: targetLeft, behavior: 'smooth' }}); }} catch (_e) {{ pills.scrollLeft = targetLeft; }}
          }}
          pills.scrollLeft = targetLeft;
        }}
      }};
      runCenter();
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(runCenter);
    }}

    function syncMobileScrollBlob() {{
      const rail = document.getElementById('mobile-scroll-rail');
      const blob = document.getElementById('mobile-scroll-blob');
      const scroller = (typeof document !== 'undefined' && typeof document.querySelector === 'function')
        ? document.querySelector('.workspace-scroll')
        : null;
      if (!rail || !blob || !scroller) return;
      const isActive = (typeof isMobileCardStackActive === 'function') ? isMobileCardStackActive() : false;
      const sh = Number(scroller.scrollHeight || 0);
      const ch = Number(scroller.clientHeight || 0);
      const maxScroll = Math.max(0, sh - ch);
      const show = Boolean(isActive && maxScroll > 20);
      if (rail.classList) rail.classList.toggle('visible', show);
      if (!show) return;
      if (typeof scroller.getBoundingClientRect === 'function') {{
        const sRect = scroller.getBoundingClientRect();
        if (sRect && Number.isFinite(sRect.top) && sRect.top >= 0) {{
          rail.style.top = `${{Math.max(4, Math.round(sRect.top) + 6)}}px`;
        }}
      }}
      const railH = Math.max(60, Number(rail.clientHeight || (ch - 20)));
      const blobH = Math.max(40, Math.min(railH * 0.65, Math.round((ch / Math.max(1, sh)) * railH)));
      const ratio = maxScroll > 0 ? Math.max(0, Math.min(1, Number(scroller.scrollTop || 0) / maxScroll)) : 0;
      const topPx = Math.round(ratio * Math.max(0, railH - blobH));
      blob.style.height = `${{blobH}}px`;
      blob.style.top = `${{topPx}}px`;
    }}

    let _MOBILE_SCROLL_SPY_TIMER = null;

    function initMobileScrollControls() {{
      const rail = document.getElementById('mobile-scroll-rail');
      const blob = document.getElementById('mobile-scroll-blob');
      const scroller = (typeof document !== 'undefined' && typeof document.querySelector === 'function')
        ? document.querySelector('.workspace-scroll')
        : null;
      if (!scroller) return;
      if (scroller.dataset && scroller.dataset.mobileScrollBound === '1') {{
        syncMobileScrollBlob();
        return;
      }}
      if (scroller.dataset) scroller.dataset.mobileScrollBound = '1';

      if (typeof scroller.addEventListener === 'function') {{
        scroller.addEventListener('focusin', (ev) => {{
          if (_isEditableEl(ev && ev.target)) {{
            MOBILE_NAV_LOCK_UNTIL = Date.now() + 900;
          }}
        }});
      }}

      scroller.addEventListener('scroll', () => {{
        syncMobileScrollBlob();
        if (!isMobileCardStackActive() || Date.now() < MOBILE_NAV_LOCK_UNTIL) return;
        if (_MOBILE_SCROLL_SPY_TIMER) clearTimeout(_MOBILE_SCROLL_SPY_TIMER);
        _MOBILE_SCROLL_SPY_TIMER = setTimeout(() => {{
          _MOBILE_SCROLL_SPY_TIMER = null;
          if (!isMobileCardStackActive() || Date.now() < MOBILE_NAV_LOCK_UNTIL) return;
          const items = _mobileWidgetEls();
          if (!items.length || typeof scroller.getBoundingClientRect !== 'function') return;
          const sTop = scroller.getBoundingClientRect().top;
          let bestIdx = MOBILE_FOCUS_IDX, bestDist = Infinity;
          items.forEach((it, idx) => {{
            if (!it.el || typeof it.el.getBoundingClientRect !== 'function') return;
            const d = Math.abs(it.el.getBoundingClientRect().top - (sTop + 8));
            if (d < bestDist) {{ bestDist = d; bestIdx = idx; }}
          }});
          if (bestIdx !== MOBILE_FOCUS_IDX) {{
            MOBILE_FOCUS_IDX = bestIdx;
            const pills = document.getElementById('mobile-nav-pills');
            if (pills && typeof pills.querySelectorAll === 'function') {{
              const btns = pills.querySelectorAll('.mobile-nav-pill');
              let activeBtn = null;
              btns.forEach((b, bi) => {{
                const act = bi === MOBILE_FOCUS_IDX;
                if (b.classList) b.classList.toggle('active', act);
                if (act) activeBtn = b;
              }});
              if (activeBtn) _centerActiveMobilePill(pills, activeBtn);
            }}
          }}
        }}, 120);
      }}, {{ passive: true }});

      if (rail && blob && typeof window !== 'undefined') {{
        let dragState = null;
        const setScrollFromClientY = (clientY) => {{
          if (!dragState || typeof rail.getBoundingClientRect !== 'function') return;
          const rRect = rail.getBoundingClientRect();
          const railH = Math.max(40, rRect.height || rail.clientHeight || 200);
          const blobH = Math.max(40, blob.clientHeight || 40);
          const maxTravel = Math.max(1, railH - blobH);
          const desiredTop = Math.max(0, Math.min(maxTravel, (clientY - rRect.top) - dragState.offsetY));
          const maxScroll = Math.max(0, (scroller.scrollHeight || 0) - (scroller.clientHeight || 0));
          scroller.scrollTop = (desiredTop / maxTravel) * maxScroll;
          syncMobileScrollBlob();
        }};
        const startDrag = (clientY, fromBlob) => {{
          if (!rail.getBoundingClientRect || !blob.getBoundingClientRect) return;
          const bRect = blob.getBoundingClientRect();
          dragState = {{ offsetY: fromBlob ? (clientY - bRect.top) : ((bRect.height || 40) * 0.5) }};
          if (rail.classList) rail.classList.add('dragging');
          if (!fromBlob) setScrollFromClientY(clientY);
        }};
        const endDrag = () => {{
          if (!dragState) return;
          dragState = null;
          if (rail.classList) rail.classList.remove('dragging');
        }};
        rail.addEventListener('mousedown', (ev) => {{
          if (ev.button !== 0) return;
          ev.preventDefault();
          startDrag(ev.clientY, ev.target === blob);
        }});
        rail.addEventListener('touchstart', (ev) => {{
          const tch = ev.touches && ev.touches[0];
          if (!tch) return;
          if (ev.cancelable) ev.preventDefault();
          startDrag(tch.clientY, ev.target === blob);
        }}, {{ passive: false }});
        window.addEventListener('mousemove', (ev) => {{
          if (dragState) setScrollFromClientY(ev.clientY);
        }});
        window.addEventListener('touchmove', (ev) => {{
          if (!dragState) return;
          const tch = ev.touches && ev.touches[0];
          if (!tch) return;
          if (ev.cancelable) ev.preventDefault();
          setScrollFromClientY(tch.clientY);
        }}, {{ passive: false }});
        window.addEventListener('mouseup', endDrag);
        window.addEventListener('touchend', endDrag);
        window.addEventListener('touchcancel', endDrag);
      }}
      syncMobileScrollBlob();
    }}

    function updateMobileNavBar() {{
      if (typeof document !== 'undefined' && document.body && document.body.classList) {{
        document.body.classList.toggle('mobile-view', isMobileCardStackActive());
      }}
      const btn = document.getElementById('btn-mobile-view');
      if (btn) btn.textContent = MOBILE_VIEW_ENABLED ? t('mobile_view_active') : t('mobile_view_btn');
      const pills = document.getElementById('mobile-nav-pills');
      if (pills) {{
        const items = _mobileWidgetEls();
        if (MOBILE_FOCUS_IDX >= items.length) MOBILE_FOCUS_IDX = 0;
        pills.innerHTML = '';
        let activePillEl = null;
        items.forEach((it, idx) => {{
          const b = document.createElement('button');
          b.type = 'button';
          const isAct = (idx === MOBILE_FOCUS_IDX);
          b.className = 'mobile-nav-pill' + (isAct ? ' active' : '');
          b.textContent = it.label;
          b.title = it.label;
          b.onclick = () => {{
            MOBILE_FOCUS_IDX = idx;
            _focusMobileWidgetEl(it.el);
            updateMobileNavBar();
          }};
          pills.appendChild(b);
          if (isAct) activePillEl = b;
        }});
        if (activePillEl) _centerActiveMobilePill(pills, activePillEl);
      }}
      const fitBtn = document.getElementById('btn-mobile-fit');
      if (fitBtn) {{
        fitBtn.textContent = t('mobile_fit_btn');
        if (fitBtn.classList) fitBtn.classList.toggle('active', Boolean(MOBILE_FIT_OVERVIEW));
      }}
      syncMobileMapTouchLock();
      initMobileScrollControls();
      if (typeof setTimeout === 'function') setTimeout(syncMobileScrollBlob, 60);
    }}

    function stepMobileWidget(delta) {{
      const items = _mobileWidgetEls();
      if (!items.length) return;
      MOBILE_FOCUS_IDX = (MOBILE_FOCUS_IDX + Number(delta || 0) + items.length) % items.length;
      const target = items[MOBILE_FOCUS_IDX];
      if (target && target.el) _focusMobileWidgetEl(target.el);
      updateMobileNavBar();
    }}

    function _applyMobileFitScale() {{
      const ws = document.getElementById('workspace-main');
      const scrollEl = (typeof document !== 'undefined' && typeof document.querySelector === 'function')
        ? document.querySelector('.workspace-scroll')
        : null;
      if (!ws) return;
      ws.style.transform = '';
      ws.style.transformOrigin = '';
      ws.style.marginBottom = '';
      ws.style.marginRight = '';
      if (!scrollEl || !MOBILE_FIT_OVERVIEW) return;
      const styledW = parseFloat(ws.style.width || '0') || 0;
      const styledH = parseFloat(ws.style.height || '0') || 0;
      const wFull = Math.max(styledW, Number(ws.scrollWidth || 0), Number(DASHBOARD.canvas_width || 1280));
      const wAvail = Math.max(280, (scrollEl.clientWidth || (typeof window !== 'undefined' ? window.innerWidth : 390)) - 16);
      const sc = Math.min(1, wAvail / Math.max(1, wFull));
      ws.style.transformOrigin = 'top left';
      ws.style.transform = sc < 0.99 ? `scale(${{sc.toFixed(3)}})` : '';
      const hFull = Math.max(styledH, Number(ws.scrollHeight || 0), Number(DASHBOARD.canvas_height || 720));
      ws.style.marginBottom = sc < 0.99 ? `${{Math.round(hFull * (sc - 1))}}px` : '';
      ws.style.marginRight = sc < 0.99 ? `${{Math.round(wFull * (sc - 1))}}px` : '';
    }}

    function toggleMobileFitOverview() {{
      MOBILE_FIT_OVERVIEW = !MOBILE_FIT_OVERVIEW;
      const ws = document.getElementById('workspace-main');
      if (ws) {{
        ws.style.transform = '';
        ws.style.transformOrigin = '';
        ws.style.marginBottom = '';
        ws.style.marginRight = '';
      }}
      applyArtboardLayout();
      _applyMobileFitScale();
      updateMobileNavBar();
      syncMobileMapTouchLock();
      if (map && typeof map.invalidateSize === 'function') setTimeout(() => map.invalidateSize(), 60);
      if (typeof document !== 'undefined' && typeof document.querySelectorAll === 'function' && typeof Plotly !== 'undefined' && Plotly && Plotly.Plots) {{
        setTimeout(() => {{
          document.querySelectorAll('.plot-container').forEach(p => {{
            try {{ Plotly.Plots.resize(p); }} catch (_rp) {{}}
          }});
        }}, 80);
      }}
    }}

    // Pure-JS OGC GeoPackage (SQLite3 binary) builder for viewport download (#10)
    function _utf8Bytes(str) {{
      if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(String(str ?? ''));
      const s = unescape(encodeURIComponent(String(str ?? '')));
      const out = new Uint8Array(s.length);
      for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
      return out;
    }}

    function _sqliteVarintBytes(val) {{
      let v = BigInt(val);
      if (v < 0n) v = BigInt.asUintN(64, v);
      if (v <= 0x7fn) return [Number(v)];
      if (v > 0xffffffffffffffn) {{
        const out9 = new Array(9);
        out9[8] = Number(v & 0xffn);
        let hi = v >> 8n;
        for (let i = 7; i >= 0; i--) {{
          out9[i] = Number(hi & 0x7fn) | 0x80;
          hi >>= 7n;
        }}
        return out9;
      }}
      const rev = [Number(v & 0x7fn)];
      v >>= 7n;
      while (v > 0n) {{
        rev.push(Number(v & 0x7fn) | 0x80);
        v >>= 7n;
      }}
      return rev.reverse();
    }}

    function _encodeSqliteRecord(fields) {{
      // fields: array of {{ type: 'null'|'int'|'float'|'text'|'blob', value }}
      const serials = [];
      const bodies = [];
      for (const f of fields) {{
        if (f.value === null || f.value === undefined || f.type === 'null') {{
          serials.push(..._sqliteVarintBytes(0));
        }} else if (f.type === 'int') {{
          const iv = BigInt(Math.trunc(Number(f.value)));
          if (iv === 0n) {{
            serials.push(..._sqliteVarintBytes(8));
          }} else if (iv === 1n) {{
            serials.push(..._sqliteVarintBytes(9));
          }} else if (iv >= -128n && iv <= 127n) {{
            serials.push(..._sqliteVarintBytes(1));
            const b = new Uint8Array(1);
            new DataView(b.buffer).setInt8(0, Number(iv));
            bodies.push(b);
          }} else if (iv >= -32768n && iv <= 32767n) {{
            serials.push(..._sqliteVarintBytes(2));
            const b = new Uint8Array(2);
            new DataView(b.buffer).setInt16(0, Number(iv), false);
            bodies.push(b);
          }} else if (iv >= -2147483648n && iv <= 2147483647n) {{
            serials.push(..._sqliteVarintBytes(4));
            const b = new Uint8Array(4);
            new DataView(b.buffer).setInt32(0, Number(iv), false);
            bodies.push(b);
          }} else {{
            serials.push(..._sqliteVarintBytes(6));
            const b = new Uint8Array(8);
            new DataView(b.buffer).setBigInt64(0, iv, false);
            bodies.push(b);
          }}
        }} else if (f.type === 'float') {{
          const fv = Number(f.value);
          if (!Number.isFinite(fv)) {{
            serials.push(..._sqliteVarintBytes(0));
          }} else {{
            serials.push(..._sqliteVarintBytes(7));
            const b = new Uint8Array(8);
            new DataView(b.buffer).setFloat64(0, fv, false);
            bodies.push(b);
          }}
        }} else if (f.type === 'blob') {{
          const bytes = f.value instanceof Uint8Array ? f.value : new Uint8Array(f.value || 0);
          serials.push(..._sqliteVarintBytes(bytes.length * 2 + 12));
          bodies.push(bytes);
        }} else {{
          const tb = _utf8Bytes(f.value);
          serials.push(..._sqliteVarintBytes(tb.length * 2 + 13));
          bodies.push(tb);
        }}
      }}
      // Header size varint includes itself
      let hdrLen = 1 + serials.length;
      if (hdrLen >= 128) hdrLen = _sqliteVarintBytes(hdrLen + 1).length + serials.length;
      const hdrLenBytes = _sqliteVarintBytes(hdrLen);
      const bodyLen = bodies.reduce((s, b) => s + b.length, 0);
      const out = new Uint8Array(hdrLenBytes.length + serials.length + bodyLen);
      let off = 0;
      out.set(hdrLenBytes, off); off += hdrLenBytes.length;
      out.set(serials, off); off += serials.length;
      for (const b of bodies) {{ out.set(b, off); off += b.length; }}
      return out;
    }}

    function _geojsonGeomToWkbAndBbox(geom) {{
      if (!geom || !geom.type) return null;
      const parts = [];
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      const track = (x, y) => {{
        if (x < minX) minX = x; if (x > maxX) maxX = x;
        if (y < minY) minY = y; if (y > maxY) maxY = y;
      }};
      const pushU32 = n => {{
        const b = new Uint8Array(4);
        new DataView(b.buffer).setUint32(0, n >>> 0, true);
        parts.push(b);
      }};
      const pushPt = pt => {{
        const x = Number(pt[0]), y = Number(pt[1]);
        track(x, y);
        const b = new Uint8Array(16);
        const dv = new DataView(b.buffer);
        dv.setFloat64(0, x, true);
        dv.setFloat64(8, y, true);
        parts.push(b);
      }};
      const pushRing = ring => {{
        const pts = (ring || []).filter(p => Array.isArray(p) && p.length >= 2);
        const closed = pts.length >= 3 && (pts[0][0] !== pts[pts.length - 1][0] || pts[0][1] !== pts[pts.length - 1][1])
          ? pts.concat([pts[0]])
          : pts;
        pushU32(closed.length);
        closed.forEach(pushPt);
      }};
      const writeGeom = g => {{
        parts.push(new Uint8Array([1]));  // little-endian NDR
        if (g.type === 'Point' && Array.isArray(g.coordinates)) {{
          pushU32(1); pushPt(g.coordinates);
        }} else if (g.type === 'LineString' && Array.isArray(g.coordinates)) {{
          pushU32(2);
          const pts = g.coordinates.filter(p => Array.isArray(p) && p.length >= 2);
          pushU32(pts.length);
          pts.forEach(pushPt);
        }} else if (g.type === 'Polygon' && Array.isArray(g.coordinates)) {{
          pushU32(3);
          pushU32(g.coordinates.length);
          g.coordinates.forEach(pushRing);
        }} else if (g.type === 'MultiPoint' && Array.isArray(g.coordinates)) {{
          pushU32(4);
          const pts = g.coordinates.filter(p => Array.isArray(p) && p.length >= 2);
          pushU32(pts.length);
          pts.forEach(c => writeGeom({{ type: 'Point', coordinates: c }}));
        }} else if (g.type === 'MultiLineString' && Array.isArray(g.coordinates)) {{
          pushU32(5);
          pushU32(g.coordinates.length);
          g.coordinates.forEach(line => writeGeom({{ type: 'LineString', coordinates: line }}));
        }} else if (g.type === 'MultiPolygon' && Array.isArray(g.coordinates)) {{
          pushU32(6);
          pushU32(g.coordinates.length);
          g.coordinates.forEach(poly => writeGeom({{ type: 'Polygon', coordinates: poly }}));
        }} else {{
          return false;
        }}
        return true;
      }};
      if (!writeGeom(geom) || !isFinite(minX)) return null;
      const wkbLen = parts.reduce((s, p) => s + p.length, 0);
      // GeoPackage Binary Header (8 bytes) + 2D Envelope [minX, maxX, minY, maxY] (32 bytes)
      const gpb = new Uint8Array(40 + wkbLen);
      const dv = new DataView(gpb.buffer);
      gpb[0] = 0x47; gpb[1] = 0x50; gpb[2] = 0x00; gpb[3] = 0x03;
      dv.setUint32(4, 4326, true);
      dv.setFloat64(8, minX, true);
      dv.setFloat64(16, maxX, true);
      dv.setFloat64(24, minY, true);
      dv.setFloat64(32, maxY, true);
      let off = 40;
      for (const p of parts) {{ gpb.set(p, off); off += p.length; }}
      return {{ gpb, bbox: [minX, minY, maxX, maxY], geomType: geom.type.toUpperCase() }};
    }}

    function buildGeoPackageUint8Array(layersSpec) {{
      const P = 4096;
      const X = P - 35;  // 4061
      const M = Math.floor(((P - 12) * 32) / 255) - 23;  // 489
      const pages = [new Uint8Array(P)];  // Page 1 allocated up front
      const allocPage = () => {{
        pages.push(new Uint8Array(P));
        return pages.length;  // 1-based page number
      }};

      const storeRecordPayload = payload => {{
        const total = payload.length;
        if (total <= X) return {{ inline: payload, overflowPage: 0 }};
        const K = M + ((total - M) % (P - 4));
        const localLen = (K <= X) ? K : M;
        const inline = payload.slice(0, localLen);
        let firstOv = 0;
        let prevOvBytes = null;
        let pos = localLen;
        while (pos < total) {{
          const ovPage = allocPage();
          const ovBytes = pages[ovPage - 1];
          if (!firstOv) firstOv = ovPage;
          if (prevOvBytes) new DataView(prevOvBytes.buffer).setUint32(0, ovPage, false);
          const chunkLen = Math.min(P - 4, total - pos);
          ovBytes.set(payload.slice(pos, pos + chunkLen), 4);
          pos += chunkLen;
          prevOvBytes = ovBytes;
        }}
        return {{ inline, overflowPage: firstOv }};
      }};

      const writeTableBTree = (entries, forceRootPage1) => {{
        // entries: array of {{ rowid: Number|BigInt, payload: Uint8Array }} sorted ascending by rowid
        const sorted = (entries || []).slice().sort((a, b) => (BigInt(a.rowid) < BigInt(b.rowid) ? -1 : (BigInt(a.rowid) > BigInt(b.rowid) ? 1 : 0)));
        const cells = sorted.map(e => {{
          const st = storeRecordPayload(e.payload);
          const lenVar = _sqliteVarintBytes(e.payload.length);
          const rowVar = _sqliteVarintBytes(e.rowid);
          const ovArr = st.overflowPage ? [0, 0, 0, 0] : [];
          if (st.overflowPage) new DataView(new Uint8Array(ovArr).buffer);
          const cell = new Uint8Array(lenVar.length + rowVar.length + st.inline.length + (st.overflowPage ? 4 : 0));
          let o = 0;
          cell.set(lenVar, o); o += lenVar.length;
          cell.set(rowVar, o); o += rowVar.length;
          cell.set(st.inline, o); o += st.inline.length;
          if (st.overflowPage) new DataView(cell.buffer).setUint32(o, st.overflowPage, false);
          return {{ rowid: BigInt(e.rowid), cell }};
        }});

        const packLeaf = (pageNum, pageCells, hdrOff) => {{
          const buf = pages[pageNum - 1];
          const dv = new DataView(buf.buffer);
          buf[hdrOff] = 0x0d;
          dv.setUint16(hdrOff + 1, 0, false);
          dv.setUint16(hdrOff + 3, pageCells.length, false);
          dv.setUint16(hdrOff + 7, 0, false);
          let endPos = P;
          for (let i = 0; i < pageCells.length; i++) {{
            const c = pageCells[i].cell;
            endPos -= c.length;
            buf.set(c, endPos);
            dv.setUint16(hdrOff + 8 + i * 2, endPos, false);
          }}
          dv.setUint16(hdrOff + 5, endPos === 65536 ? 0 : endPos, false);
        }};

        // Split into leaves
        const leaves = [];
        let cur = [];
        let curUsed = (forceRootPage1 ? 100 : 0) + 8;
        for (const item of cells) {{
          const need = 2 + item.cell.length;
          if (cur.length > 0 && curUsed + need > P) {{
            leaves.push(cur);
            cur = [];
            curUsed = 8;
          }}
          cur.push(item);
          curUsed += need;
        }}
        if (cur.length > 0 || !leaves.length) leaves.push(cur);

        if (leaves.length === 1) {{
          const rp = forceRootPage1 ? 1 : allocPage();
          packLeaf(rp, leaves[0], forceRootPage1 ? 100 : 0);
          return rp;
        }}

        let levelNodes = leaves.map(lf => {{
          const pno = allocPage();
          packLeaf(pno, lf, 0);
          return {{ pageNum: pno, maxKey: lf[lf.length - 1].rowid }};
        }});

        const packInterior = (pageNum, childNodes, rightMostPage, hdrOff) => {{
          const buf = pages[pageNum - 1];
          const dv = new DataView(buf.buffer);
          buf[hdrOff] = 0x05;
          dv.setUint16(hdrOff + 1, 0, false);
          dv.setUint16(hdrOff + 3, childNodes.length, false);
          dv.setUint32(hdrOff + 8, rightMostPage, false);
          let endPos = P;
          for (let i = 0; i < childNodes.length; i++) {{
            const nd = childNodes[i];
            const kv = _sqliteVarintBytes(nd.maxKey);
            const cell = new Uint8Array(4 + kv.length);
            new DataView(cell.buffer).setUint32(0, nd.pageNum, false);
            cell.set(kv, 4);
            endPos -= cell.length;
            buf.set(cell, endPos);
            dv.setUint16(hdrOff + 12 + i * 2, endPos, false);
          }}
          dv.setUint16(hdrOff + 5, endPos, false);
        }};

        while (true) {{
          const parents = [];
          let grp = [];
          let used = (forceRootPage1 ? 100 : 0) + 12;
          for (let i = 0; i < levelNodes.length - 1; i++) {{
            const nd = levelNodes[i];
            const cellLen = 4 + _sqliteVarintBytes(nd.maxKey).length + 2;
            if (grp.length > 0 && used + cellLen > P) {{
              parents.push({{ left: grp.slice(0, -1), right: grp[grp.length - 1].pageNum, maxKey: grp[grp.length - 1].maxKey }});
              grp = [];
              used = 12;
            }}
            grp.push(nd);
            used += cellLen;
          }}
          const last = levelNodes[levelNodes.length - 1];
          parents.push({{ left: grp, right: last.pageNum, maxKey: last.maxKey }});
          if (parents.length === 1) {{
            const rp = forceRootPage1 ? 1 : allocPage();
            packInterior(rp, parents[0].left, parents[0].right, forceRootPage1 ? 100 : 0);
            return rp;
          }}
          levelNodes = parents.map(pr => {{
            const pno = allocPage();
            packInterior(pno, pr.left, pr.right, 0);
            return {{ pageNum: pno, maxKey: pr.maxKey }};
          }});
        }}
      }};

      const masterRows = [];
      let masterId = 1;

      // 1. gpkg_spatial_ref_sys
      const srsSql = 'CREATE TABLE gpkg_spatial_ref_sys (srs_name TEXT NOT NULL, srs_id INTEGER NOT NULL PRIMARY KEY, organization TEXT NOT NULL, organization_coordsys_id INTEGER NOT NULL, definition TEXT NOT NULL, description TEXT)';
      const srsEntries = [
        [4326, ['WGS 84 geodetic', null, 'EPSG', 4326, 'GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]', 'WGS 84']],
        [-1, ['Undefined cartesian SRS', null, 'NONE', -1, 'undefined', 'undefined cartesian coordinate reference system']],
        [0, ['Undefined geographic SRS', null, 'NONE', 0, 'undefined', 'undefined geographic coordinate reference system']],
        [3301, ['Estonian Coordinate System of 1997', null, 'EPSG', 3301, 'PROJCS["Estonian Coordinate System of 1997",GEOGCS["EST97",DATUM["Estonia_1997",SPHEROID["GRS 1980",6378137,298.257222101]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]],PROJECTION["Lambert_Conformal_Conic_2SP"],PARAMETER["standard_parallel_1",59.33333333333334],PARAMETER["standard_parallel_2",58],PARAMETER["latitude_of_origin",57.51755393055556],PARAMETER["central_meridian",24],PARAMETER["false_easting",500000],PARAMETER["false_northing",6375000],UNIT["metre",1]]', 'Estonia L-EST97']]
      ].map(([rid, vals]) => ({{
        rowid: rid,
        payload: _encodeSqliteRecord([
          {{ type: 'text', value: vals[0] }},
          {{ type: 'null', value: null }},
          {{ type: 'text', value: vals[2] }},
          {{ type: 'int', value: vals[3] }},
          {{ type: 'text', value: vals[4] }},
          {{ type: 'text', value: vals[5] }}
        ])
      }}));
      const srsRoot = writeTableBTree(srsEntries, false);
      masterRows.push(['table', 'gpkg_spatial_ref_sys', 'gpkg_spatial_ref_sys', srsRoot, srsSql]);

      const contentsEntries = [];
      const geomColsEntries = [];
      const nowIso = new Date().toISOString();
      const usedTableNames = new Set(['gpkg_spatial_ref_sys', 'gpkg_contents', 'gpkg_geometry_columns']);

      (layersSpec || []).forEach((ls, idx) => {{
        let tbl = String(ls.name || ('layer_' + (idx + 1)))
          .normalize('NFD').replace(/[\\u0300-\\u036f]/g, '')
          .replace(/[^a-zA-Z0-9_]+/g, '_')
          .replace(/^_+|_+$/g, '')
          .toLowerCase();
        if (!tbl || /^[0-9]/.test(tbl)) tbl = 'lyr_' + (tbl || (idx + 1));
        while (usedTableNames.has(tbl)) tbl = tbl + '_' + (idx + 1);
        usedTableNames.add(tbl);

        const attrCols = Array.isArray(ls.columns) ? ls.columns : [];
        const colDefs = ['fid INTEGER PRIMARY KEY', 'geom GEOMETRY'];
        const safeColMap = attrCols.map((c, ci) => {{
          let sc = String(c).replace(/[^a-zA-Z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
          if (!sc || sc === 'fid' || sc === 'geom' || /^[0-9]/.test(sc)) sc = 'col_' + ci + '_' + (sc || 'attr');
          colDefs.push(`"${{sc}}" TEXT`);
          return {{ src: c, sqlName: sc }};
        }});
        const createSql = `CREATE TABLE "${{tbl}}" (${{colDefs.join(', ')}})`;

        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        let domGeomType = 'GEOMETRY';
        const featEntries = [];
        const rawFeats = (ls.features || []).filter(f => f && f.geometry && f.geometry.type);
        const typeSet = new Set(rawFeats.map(f => String(f.geometry.type).toUpperCase()));
        let normTarget = '';
        if (typeSet.size === 2) {{
          if (typeSet.has('POLYGON') && typeSet.has('MULTIPOLYGON')) normTarget = 'MultiPolygon';
          else if (typeSet.has('LINESTRING') && typeSet.has('MULTILINESTRING')) normTarget = 'MultiLineString';
          else if (typeSet.has('POINT') && typeSet.has('MULTIPOINT')) normTarget = 'MultiPoint';
        }}
        const normFeats = normTarget ? rawFeats.map(f => {{
          const g = f.geometry;
          const up = String(g.type).toUpperCase();
          if (up === 'POLYGON' && normTarget === 'MultiPolygon') {{
            return Object.assign({{}}, f, {{ geometry: {{ type: 'MultiPolygon', coordinates: [g.coordinates] }} }});
          }}
          if (up === 'LINESTRING' && normTarget === 'MultiLineString') {{
            return Object.assign({{}}, f, {{ geometry: {{ type: 'MultiLineString', coordinates: [g.coordinates] }} }});
          }}
          if (up === 'POINT' && normTarget === 'MultiPoint') {{
            return Object.assign({{}}, f, {{ geometry: {{ type: 'MultiPoint', coordinates: [g.coordinates] }} }});
          }}
          return f;
        }}) : rawFeats;
        normFeats.forEach((feat, fi) => {{
          const conv = _geojsonGeomToWkbAndBbox(feat.geometry);
          if (!conv) return;
          if (domGeomType === 'GEOMETRY') domGeomType = conv.geomType;
          else if (domGeomType !== conv.geomType) domGeomType = 'GEOMETRY';
          if (conv.bbox[0] < minX) minX = conv.bbox[0];
          if (conv.bbox[1] < minY) minY = conv.bbox[1];
          if (conv.bbox[2] > maxX) maxX = conv.bbox[2];
          if (conv.bbox[3] > maxY) maxY = conv.bbox[3];
          const recFields = [
            {{ type: 'null', value: null }},
            {{ type: 'blob', value: conv.gpb }}
          ];
          const props = feat.properties || {{}};
          safeColMap.forEach(cm => {{
            const raw = props[cm.src];
            recFields.push((raw === null || raw === undefined) ? {{ type: 'null', value: null }} : {{ type: 'text', value: String(raw) }});
          }});
          featEntries.push({{ rowid: fi + 1, payload: _encodeSqliteRecord(recFields) }});
        }});

        const lyrRoot = writeTableBTree(featEntries, false);
        masterRows.push(['table', tbl, tbl, lyrRoot, createSql]);

        const cid = contentsEntries.length + 1;
        contentsEntries.push({{
          rowid: cid,
          payload: _encodeSqliteRecord([
            {{ type: 'text', value: tbl }},
            {{ type: 'text', value: 'features' }},
            {{ type: 'text', value: String(ls.label || tbl) }},
            {{ type: 'text', value: 'Exported from QGIS Team Dashboard' }},
            {{ type: 'text', value: nowIso }},
            {{ type: isFinite(minX) ? 'float' : 'null', value: isFinite(minX) ? minX : null }},
            {{ type: isFinite(minY) ? 'float' : 'null', value: isFinite(minY) ? minY : null }},
            {{ type: isFinite(maxX) ? 'float' : 'null', value: isFinite(maxX) ? maxX : null }},
            {{ type: isFinite(maxY) ? 'float' : 'null', value: isFinite(maxY) ? maxY : null }},
            {{ type: 'int', value: 4326 }}
          ])
        }});
        geomColsEntries.push({{
          rowid: cid,
          payload: _encodeSqliteRecord([
            {{ type: 'text', value: tbl }},
            {{ type: 'text', value: 'geom' }},
            {{ type: 'text', value: domGeomType }},
            {{ type: 'int', value: 4326 }},
            {{ type: 'int', value: 0 }},
            {{ type: 'int', value: 0 }}
          ])
        }});
      }});

      const contentsSql = "CREATE TABLE gpkg_contents (table_name TEXT NOT NULL, data_type TEXT NOT NULL DEFAULT 'features', identifier TEXT, description TEXT DEFAULT '', last_change DATETIME NOT NULL, min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE, srs_id INTEGER)";
      const contentsRoot = writeTableBTree(contentsEntries, false);
      masterRows.push(['table', 'gpkg_contents', 'gpkg_contents', contentsRoot, contentsSql]);

      const geomColsSql = 'CREATE TABLE gpkg_geometry_columns (table_name TEXT NOT NULL, column_name TEXT NOT NULL, geometry_type_name TEXT NOT NULL, srs_id INTEGER NOT NULL, z TINYINT NOT NULL, m TINYINT NOT NULL)';
      const geomColsRoot = writeTableBTree(geomColsEntries, false);
      masterRows.push(['table', 'gpkg_geometry_columns', 'gpkg_geometry_columns', geomColsRoot, geomColsSql]);

      const masterEntries = masterRows.map((mr, i) => ({{
        rowid: masterId + i,
        payload: _encodeSqliteRecord([
          {{ type: 'text', value: mr[0] }},
          {{ type: 'text', value: mr[1] }},
          {{ type: 'text', value: mr[2] }},
          {{ type: 'int', value: mr[3] }},
          {{ type: 'text', value: mr[4] }}
        ])
      }}));
      writeTableBTree(masterEntries, true);

      // Write SQLite3 header on Page 1 (keep ASCII literal without raw U+0000 byte so HTML5 parsers never corrupt byte 15)
      const p1 = pages[0];
      p1.set(_utf8Bytes('SQLite format 3'), 0);
      p1[15] = 0;
      const hdv = new DataView(p1.buffer);
      hdv.setUint16(16, P, false);
      p1[18] = 1; p1[19] = 1; p1[20] = 0; p1[21] = 64; p1[22] = 32; p1[23] = 32;
      hdv.setUint32(24, 1, false);
      hdv.setUint32(28, pages.length, false);
      hdv.setUint32(40, 1, false);
      hdv.setUint32(44, 4, false);
      hdv.setUint32(56, 1, false);
      hdv.setUint32(60, 10200, false);       // GeoPackage 1.2 user_version
      hdv.setUint32(68, 0x47504B47, false);  // "GPKG" application_id
      hdv.setUint32(92, 1, false);
      hdv.setUint32(96, 3040000, false);

      const finalBytes = new Uint8Array(pages.length * P);
      pages.forEach((pg, pi) => finalBytes.set(pg, pi * P));
      return finalBytes;
    }}

    async function downloadMapViewportGeoPackage() {{
      if (!map || typeof map.getBounds !== 'function') return;
      beginBusyOp(t('gpkg_building'));
      try {{
        await Promise.all(Object.keys(VECTOR_PYRAMIDS).map(ln => unpackLod1Pyramid(ln)));
        const mb = map.getBounds();
        const viewBb = [mb.getWest(), mb.getSouth(), mb.getEast(), mb.getNorth()];
        const viewGeom = _bboxToPolyGeom(viewBb);
        const visibleLayers = orderedMapLayerNames().filter(ln => MAP_LAYER_VISIBILITY[ln] !== false);

        const layerCandidates = [];
        for (const ln of visibleLayers) {{
          const filtered = filterRecords(ln, null, '__map__');
          const cands = [];
          let needsFullFetch = false;
          let cMinX = Infinity, cMinY = Infinity, cMaxX = -Infinity, cMaxY = -Infinity;
          for (const row of filtered) {{
            if (!row) continue;
            const fidStr = (row._feature_id !== undefined && row._feature_id !== null) ? String(row._feature_id) : '';
            const curLod = fidStr ? Number(((LAYER_GEOM_LOD[ln] || {{}})[fidStr]) || 0) : 0;
            const cachedExact = (fidStr && LAYER_GEOMETRIES[ln]) ? LAYER_GEOMETRIES[ln][fidStr] : null;
            let bb = fidStr ? getFeatureBbox(ln, fidStr) : null;
            if (!bb && Array.isArray(row._bbox) && row._bbox.length === 4) bb = row._bbox.map(Number);
            if (!bb && row._lon !== undefined && row._lat !== undefined) {{
              const x = Number(row._lon), y = Number(row._lat);
              if (Number.isFinite(x) && Number.isFinite(y)) bb = [x, y, x, y];
            }}
            if (!bb || !_bboxOverlaps2D(bb, viewBb)) continue;
            const isPurePoint = (
              !cachedExact
              && row._lon !== undefined && row._lat !== undefined
              && !Array.isArray(row._bbox)
              && !(LAYER_PYRAMID_LOD1[ln] && LAYER_PYRAMID_LOD1[ln][fidStr])
              && !/Polygon|Line/i.test(LAYER_GEOM_TYPES[ln] || '')
            );
            if (!isPurePoint && (!cachedExact || curLod < 3)) {{
              needsFullFetch = true;
              cMinX = Math.min(cMinX, bb[0]); cMinY = Math.min(cMinY, bb[1]);
              cMaxX = Math.max(cMaxX, bb[2]); cMaxY = Math.max(cMaxY, bb[3]);
            }}
            cands.push({{ row, fidStr, bb, isPurePoint }});
          }}
          if (cands.length > 0) {{
            let fetchBb = viewBb;
            if (isFinite(cMinX)) {{
              fetchBb = [
                Math.max(viewBb[0], cMinX - 0.001),
                Math.max(viewBb[1], cMinY - 0.001),
                Math.min(viewBb[2], cMaxX + 0.001),
                Math.min(viewBb[3], cMaxY + 0.001)
              ];
            }}
            layerCandidates.push({{ ln, cands, needsFullFetch, fetchBb }});
          }}
        }}

        if (!layerCandidates.length) {{
          alert(t('gpkg_empty_view'));
          return;
        }}

        const layersNeedingFull = layerCandidates.filter(lc => lc.needsFullFetch && (HAS_PREVIEW_API || findLiveWfsService(lc.ln)));
        if (layersNeedingFull.length > 0) {{
          beginBusyOp(t('gpkg_fetching_full'));
          try {{
            await Promise.all(layersNeedingFull.map(lc => _fetchFullViewportGeometriesForGpkg(lc.ln, lc.fetchBb)));
          }} finally {{
            endBusyOp();
          }}
        }}

        let skippedNoFullCount = 0;
        const layersSpec = [];
        for (const lc of layerCandidates) {{
          const ln = lc.ln;
          const hasLiveSource = Boolean(HAS_PREVIEW_API || findLiveWfsService(ln));
          const colsSet = new Set();
          const feats = [];
          for (const item of lc.cands) {{
            const row = item.row;
            const fidStr = item.fidStr;
            const curLod = fidStr ? Number(((LAYER_GEOM_LOD[ln] || {{}})[fidStr]) || 0) : 0;
            let geom = null;
            if (fidStr && LAYER_GEOMETRIES[ln] && LAYER_GEOMETRIES[ln][fidStr] && curLod >= 3) {{
              geom = LAYER_GEOMETRIES[ln][fidStr];
            }} else if (item.isPurePoint) {{
              geom = {{ type: 'Point', coordinates: [Number(row._lon), Number(row._lat)] }};
            }} else if (!hasLiveSource) {{
              // Static non-WFS offline layer: allow decoded real polygon/line geometry only, NEVER a synthetic bbox rectangle
              const realCached = fidStr ? getFeatureGeometry(ln, fidStr) : null;
              if (realCached) geom = realCached;
            }}
            if (!geom) {{
              skippedNoFullCount++;
              continue;
            }}
            const fb = (fidStr && getFeatureBbox(ln, fidStr)) || geomBbox(geom) || item.bb;
            const insideView = fb && fb[0] >= viewBb[0] && fb[1] >= viewBb[1] && fb[2] <= viewBb[2] && fb[3] <= viewBb[3];
            if (!insideView && viewGeom && !geomIntersectsGeom(geom, viewGeom)) continue;
            const props = {{}};
            Object.entries(row).forEach(([k, v]) => {{
              if (!k.startsWith('_')) {{
                colsSet.add(k);
                props[k] = v;
              }}
            }});
            feats.push({{ geometry: geom, properties: props }});
          }}
          if (feats.length > 0) {{
            layersSpec.push({{
              name: ln,
              label: ln,
              columns: Array.from(colsSet).slice(0, 60),
              features: feats
            }});
          }}
        }}

        if (!layersSpec.length) {{
          alert(skippedNoFullCount > 0 ? t('gpkg_no_full_geom') : t('gpkg_empty_view'));
          return;
        }}
        const gpkgBytes = buildGeoPackageUint8Array(layersSpec);
        const totalSaved = layersSpec.reduce((s, l) => s + l.features.length, 0);
        const doneStatusKey = skippedNoFullCount > 0 ? 'gpkg_skipped_approx' : 'gpkg_saved_status';
        const doneStatusVars = {{ count: totalSaved, skipped: skippedNoFullCount }};
        const rawTitle = String(DASHBOARD.title || 'dashboard').normalize('NFD').replace(/[\\u0300-\\u036f]/g, '').replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_+|_+$/g, '') || 'dashboard';
        let bestRefDate = null;
        let bestRefStamp = '';
        layersSpec.forEach(ls => {{
          const st = (typeof LAYER_LIVE_INFO === 'object' && LAYER_LIVE_INFO && LAYER_LIVE_INFO[ls.name]) ? LAYER_LIVE_INFO[ls.name] : null;
          const refStr = st && st.refreshed_at ? String(st.refreshed_at).trim() : '';
          if (refStr) {{
            const parsed = _parseDisplayStampToDate(refStr);
            if (parsed && (!bestRefDate || parsed.getTime() > bestRefDate.getTime())) {{
              bestRefDate = parsed;
              bestRefStamp = refStr;
            }}
          }}
        }});
        const effectiveStamp = bestRefStamp
          || (HAS_LIVE_REFRESHED && LIVE_SESSION_STAMP ? LIVE_SESSION_STAMP : '')
          || EXPORTED_AT_STAMP
          || LIVE_SESSION_STAMP
          || '';
        const tsSlug = _formatFilenameTimestamp(effectiveStamp);
        const fname = `${{rawTitle}}_viewport_${{tsSlug}}.gpkg`;

        if (typeof window.showSaveFilePicker === 'function') {{
          try {{
            const handle = await window.showSaveFilePicker({{
              suggestedName: fname,
              types: [{{ description: 'OGC GeoPackage', accept: {{ 'application/geopackage+sqlite3': ['.gpkg'] }} }}]
            }});
            const writable = await handle.createWritable();
            await writable.write(gpkgBytes);
            await writable.close();
            setLiveStatus(doneStatusKey, doneStatusVars);
            return;
          }} catch (pickErr) {{
            if (pickErr && pickErr.name === 'AbortError') return;
          }}
        }}
        const blob = new Blob([gpkgBytes], {{ type: 'application/geopackage+sqlite3' }});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fname;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {{
          URL.revokeObjectURL(url);
          if (a.parentNode) a.parentNode.removeChild(a);
        }}, 1000);
        setLiveStatus(doneStatusKey, doneStatusVars);
      }} catch (err) {{
        console.error('GeoPackage export failed', err);
      }} finally {{
        endBusyOp();
      }}
    }}

    function setHostExtentFilter(enabled) {{
      const next = Boolean(enabled);
      EXTENT_FILTER_ENABLED = next;
      if (typeof DASHBOARD === 'object' && DASHBOARD) DASHBOARD.filter_by_map_extent = next;
      saveDashboardSessionState();
      updateExtentButtonUI();
      triggerRenderWithBusyFeedback({{ skipAutoZoom: true }});
      return EXTENT_FILTER_ENABLED;
    }}

    function toggleExtentFilter() {{
      return setHostExtentFilter(!EXTENT_FILTER_ENABLED);
    }}

    function updateExtentButtonUI() {{
      const btn = document.getElementById('btn-extent-filter');
      if (!btn) return;
      btn.textContent = EXTENT_FILTER_ENABLED ? t('html_extent_on') : t('html_extent_off');
      btn.classList.toggle('active', EXTENT_FILTER_ENABLED);
    }}

    function setHostTheme(nextTheme) {{
      const norm = String(nextTheme || '').toLowerCase() === 'light' ? 'light' : 'dark';
      const html = document.documentElement;
      html.dataset.theme = norm;
      if (typeof DASHBOARD === 'object' && DASHBOARD) DASHBOARD.theme = norm;
      renderAll({{ skipAutoZoom: true }});
      return norm;
    }}

    function toggleTheme() {{
      const html = document.documentElement;
      const next = html.dataset.theme === 'light' ? 'dark' : 'light';
      return setHostTheme(next);
    }}

    function closeSettingsMenu() {{
      const pop = document.getElementById('settings-popover');
      if (!pop) return;
      pop.classList.remove('open');
      pop.style.display = 'none';
    }}

    function setExportImageScope(scope) {{
      EXPORT_IMAGE_SCOPE = (scope === 'map') ? 'map' : 'dashboard';
      const bDash = document.getElementById('btn-scope-dash');
      const bMap = document.getElementById('btn-scope-map');
      if (bDash && bDash.classList) bDash.classList.toggle('active', EXPORT_IMAGE_SCOPE === 'dashboard');
      if (bMap && bMap.classList) bMap.classList.toggle('active', EXPORT_IMAGE_SCOPE === 'map');
    }}

    function toggleSettingsMenu(ev) {{
      if (ev && typeof ev.stopPropagation === 'function') ev.stopPropagation();
      const pop = document.getElementById('settings-popover');
      if (!pop) return;
      const isOpen = pop.classList.contains('open') || pop.style.display === 'flex';
      if (isOpen) {{
        closeSettingsMenu();
        return;
      }}
      const lsm = document.getElementById('live-status-menu');
      if (lsm) lsm.style.display = 'none';
      if (typeof closeRefreshScopeMenu === 'function') closeRefreshScopeMenu();
      if (typeof closeMapScaleMenu === 'function') closeMapScaleMenu();
      const btn = document.getElementById('btn-settings-menu');
      if (btn && typeof btn.getBoundingClientRect === 'function') {{
        const r = btn.getBoundingClientRect();
        if (r && r.width > 0) {{
          const vw = (typeof window !== 'undefined' && Number(window.innerWidth)) ? Number(window.innerWidth) : 1280;
          const vh = (typeof window !== 'undefined' && Number(window.innerHeight)) ? Number(window.innerHeight) : 720;
          pop.style.top = Math.max(8, Math.min(vh - 140, Math.round(r.bottom + 6))) + 'px';
          pop.style.right = Math.max(8, Math.round(vw - r.right)) + 'px';
        }}
      }}
      setExportImageScope(EXPORT_IMAGE_SCOPE);
      const chkAuto = document.getElementById('chk-opt-autohome');
      if (chkAuto) chkAuto.checked = Boolean(AUTO_HOME_ON_FILTER_CLEAR);
      pop.style.display = 'flex';
      pop.classList.add('open');
    }}

    function syncMapWindowButtons() {{
      const minBtn = document.getElementById('btn-map-minimize');
      const maxBtn = document.getElementById('btn-map-maximize');
      if (minBtn) {{
        const isMin = (MAP_WINDOW_MODE === 'minimized');
        minBtn.textContent = isMin ? '▢' : '—';
        minBtn.title = t(isMin ? 'map_restore_tip' : 'map_minimize_tip');
        if (minBtn.classList) minBtn.classList.toggle('active', isMin);
      }}
      if (maxBtn) {{
        const isMax = (MAP_WINDOW_MODE === 'maximized');
        maxBtn.textContent = isMax ? '❐' : '⛶';
        maxBtn.title = t(isMax ? 'map_restore_tip' : 'map_maximize_tip');
        if (maxBtn.classList) maxBtn.classList.toggle('active', isMax);
      }}
    }}

    function setMapWindowMode(mode) {{
      const m = (mode === 'minimized' || mode === 'maximized') ? mode : 'normal';
      MAP_WINDOW_MODE = m;
      if (m === 'minimized') {{
        const drawer = document.getElementById('map-layers-drawer');
        if (drawer) drawer.style.display = 'none';
      }}
      syncMapWindowButtons();
      applyArtboardLayout();
      if (map && typeof map.invalidateSize === 'function') {{
        setTimeout(() => {{
          try {{ map.invalidateSize(); }} catch (_mi) {{}}
          if (typeof renderMapFeatureLabels === 'function') renderMapFeatureLabels();
        }}, 50);
      }}
      if (typeof _resizePlotlyChartsIfChanged === 'function') {{
        setTimeout(() => {{ _resizePlotlyChartsIfChanged(); }}, 70);
      }}
      return MAP_WINDOW_MODE;
    }}

    function toggleMapMinimize() {{
      return setMapWindowMode(MAP_WINDOW_MODE === 'minimized' ? 'normal' : 'minimized');
    }}

    function toggleMapMaximize() {{
      return setMapWindowMode(MAP_WINDOW_MODE === 'maximized' ? 'normal' : 'maximized');
    }}

    async function exportDashboardImage(format, scopeOverride) {{
      if (EXPORT_TIER === 'minimal') return null;
      const rawFmt = String(format || 'png').toLowerCase();
      const fmt = (rawFmt === 'jpg' || rawFmt === 'jpeg') ? 'jpeg' : 'png';
      const mime = fmt === 'jpeg' ? 'image/jpeg' : 'image/png';
      const ext = fmt === 'jpeg' ? 'jpg' : 'png';
      const scope = (scopeOverride === 'map' || scopeOverride === 'dashboard') ? scopeOverride : EXPORT_IMAGE_SCOPE;
      const targetEl = document.getElementById(scope === 'map' ? 'map-card' : 'workspace-main');
      if (!targetEl || typeof document === 'undefined' || typeof document.createElement !== 'function') return null;

      if (typeof showDashboardLoader === 'function') {{
        showDashboardLoader(t('export_img_busy'), ext.toUpperCase(), 20);
      }}
      await _yieldToBrowser();
      try {{
        const rootRect = targetEl.getBoundingClientRect ? targetEl.getBoundingClientRect() : {{ left: 0, top: 0, width: 1280, height: 720 }};
        const mapBoxEl = document.getElementById('map-canvas');
        const mapRectInit = (mapBoxEl && mapBoxEl.getBoundingClientRect) ? mapBoxEl.getBoundingClientRect() : null;
        const headerPad = (scope === 'dashboard') ? 54 : 0;
        const w = (scope === 'map' && mapRectInit && mapRectInit.width > 20)
          ? Math.max(320, Math.round(mapRectInit.width))
          : Math.max(320, Math.round(Number(rootRect.width || targetEl.offsetWidth || DASHBOARD.canvas_width || 1280)));
        const h = (scope === 'map' && mapRectInit && mapRectInit.height > 20)
          ? Math.max(240, Math.round(32 + mapRectInit.height + 24))
          : Math.max(240, Math.round(Number(rootRect.height || targetEl.offsetHeight || DASHBOARD.canvas_height || 720) + headerPad));
        const dpr = Math.min(2, Math.max(1, Number((typeof window !== 'undefined' && window.devicePixelRatio) || 1)));
        const pxScale = Math.min(dpr, 3200 / Math.max(w, h, 1));

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(w * pxScale));
        canvas.height = Math.max(1, Math.round(h * pxScale));
        const ctx = canvas.getContext('2d');
        if (!ctx) return null;
        ctx.scale(pxScale, pxScale);

        const isLight = (document.documentElement && document.documentElement.dataset && document.documentElement.dataset.theme === 'light');
        const bgCol = isLight ? '#f8fafc' : '#0f172a';
        const cardBg = isLight ? '#ffffff' : '#1e293b';
        const brdCol = isLight ? '#cbd5e1' : '#334155';
        const subBg = isLight ? '#f1f5f9' : '#0f172a';
        const txtPrimary = isLight ? '#0f172a' : '#f1f5f9';
        const txtSec = isLight ? '#475569' : '#94a3b8';

        ctx.fillStyle = bgCol;
        ctx.fillRect(0, 0, w, h);

        if (scope === 'dashboard') {{
          const titleTxt = (document.getElementById('brand-title-text') && document.getElementById('brand-title-text').textContent) || (DASHBOARD.title || 'GeoDash');
          const subTxt = (document.getElementById('brand-subtitle-text') && document.getElementById('brand-subtitle-text').textContent) || (DASHBOARD.subtitle || '');
          ctx.fillStyle = txtPrimary;
          ctx.font = 'bold 17px system-ui, -apple-system, sans-serif';
          ctx.fillText(String(titleTxt), 14, 24, Math.max(120, w - 28));
          if (subTxt) {{
            ctx.fillStyle = txtSec;
            ctx.font = '12px system-ui, -apple-system, sans-serif';
            ctx.fillText(String(subTxt), 14, 42, Math.max(120, w - 28));
          }}
        }}

        const _roundRectPath = (rx, ry, rw, rh, rad) => {{
          const r = Math.max(0, Math.min(rad || 0, rw / 2, rh / 2));
          ctx.beginPath();
          ctx.moveTo(rx + r, ry);
          ctx.lineTo(rx + rw - r, ry);
          ctx.quadraticCurveTo(rx + rw, ry, rx + rw, ry + r);
          ctx.lineTo(rx + rw, ry + rh - r);
          ctx.quadraticCurveTo(rx + rw, ry + rh, rx + rw - r, ry + rh);
          ctx.lineTo(rx + r, ry + rh);
          ctx.quadraticCurveTo(rx, ry + rh, rx, ry + rh - r);
          ctx.lineTo(rx, ry + r);
          ctx.quadraticCurveTo(rx, ry, rx + r, ry);
          ctx.closePath();
        }};

        const _fitText = (rawStr, maxW) => {{
          const s = String(rawStr ?? '').replace(/\\s+/g, ' ').trim();
          if (!s || maxW <= 6) return '';
          if (ctx.measureText(s).width <= maxW) return s;
          let lo = 0, hi = s.length;
          while (lo < hi) {{
            const mid = (lo + hi + 1) >> 1;
            if (ctx.measureText(s.slice(0, mid) + '…').width <= maxW) lo = mid;
            else hi = mid - 1;
          }}
          return lo > 0 ? (s.slice(0, lo) + '…') : '';
        }};

        let corsSkippedCount = 0;
        const _loadExportSafeImage = async (imgEl) => {{
          if (!imgEl || !imgEl.complete || !imgEl.naturalWidth) return null;
          try {{
            const probe = document.createElement('canvas');
            probe.width = 1;
            probe.height = 1;
            const pCtx = probe.getContext('2d');
            if (!pCtx) return null;
            pCtx.drawImage(imgEl, 0, 0, 1, 1);
            pCtx.getImageData(0, 0, 1, 1);
            return {{ img: imgEl, revoke: null }};
          }} catch (_corsErr) {{
            const srcUrl = String(imgEl.currentSrc || imgEl.src || '').trim();
            if (srcUrl && /^https?:/i.test(srcUrl) && typeof fetch === 'function') {{
              try {{
                const resp = await fetch(srcUrl, {{ mode: 'cors' }});
                if (resp && resp.ok) {{
                  const b = await resp.blob();
                  if (b && b.size > 0 && typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function') {{
                    const objUrl = URL.createObjectURL(b);
                    const loaded = await new Promise((resolve) => {{
                      const im = new Image();
                      im.onload = () => resolve(im);
                      im.onerror = () => resolve(null);
                      im.src = objUrl;
                    }});
                    if (loaded && loaded.naturalWidth > 0) {{
                      return {{ img: loaded, revoke: objUrl }};
                    }}
                    try {{ URL.revokeObjectURL(objUrl); }} catch (_ru) {{}}
                  }}
                }}
              }} catch (_fetchErr) {{}}
            }}
            corsSkippedCount += 1;
            return null;
          }}
        }};

        const _drawImageFit = (img, dx, dy, dw, dh, fitMode) => {{
          const nw = Number(img.naturalWidth || img.width || 0);
          const nh = Number(img.naturalHeight || img.height || 0);
          if (!nw || !nh || dw <= 0 || dh <= 0) return;
          const arImg = nw / nh;
          const arBox = dw / dh;
          if (fitMode === 'cover') {{
            let sx = 0, sy = 0, sw = nw, sh = nh;
            if (arImg > arBox) {{
              sw = nh * arBox;
              sx = (nw - sw) / 2;
            }} else {{
              sh = nw / arBox;
              sy = (nh - sh) / 2;
            }}
            ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
          }} else if (fitMode === 'fill') {{
            ctx.drawImage(img, dx, dy, dw, dh);
          }} else {{
            let rw = dw, rh = dh;
            if (arImg > arBox) rh = dw / arImg;
            else rw = dh * arImg;
            ctx.drawImage(img, dx + (dw - rw) / 2, dy + (dh - rh) / 2, rw, rh);
          }}
        }};

        const cardNodes = (scope === 'map')
          ? [targetEl]
          : Array.from(targetEl.querySelectorAll('.map-card, .widget-card, .kpi-card, .slicer-group'));

        for (let ci = 0; ci < cardNodes.length; ci++) {{
          const card = cardNodes[ci];
          if (!card || (card.classList && card.classList.contains('map-maximized-hidden'))) continue;
          const cs = (typeof getComputedStyle === 'function') ? getComputedStyle(card) : null;
          if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) continue;
          const cr = card.getBoundingClientRect ? card.getBoundingClientRect() : null;
          if (!cr || cr.width <= 4 || cr.height <= 4) continue;

          const cx = (scope === 'map' && card.id === 'map-card') ? 0 : (cr.left - rootRect.left);
          const cy = (scope === 'map' && card.id === 'map-card') ? 0 : ((cr.top - rootRect.top) + headerPad);
          const cw = (scope === 'map' && card.id === 'map-card') ? w : cr.width;
          const ch = (scope === 'map' && card.id === 'map-card') ? h : cr.height;

          ctx.save();
          ctx.beginPath();
          ctx.rect(cx, cy, cw, ch);
          ctx.clip();

          ctx.fillStyle = cardBg;
          ctx.fillRect(cx, cy, cw, ch);
          ctx.strokeStyle = brdCol;
          ctx.lineWidth = 1;
          ctx.strokeRect(cx + 0.5, cy + 0.5, Math.max(1, cw - 1), Math.max(1, ch - 1));

          const hdrEl = card.querySelector ? card.querySelector('.card-header span, .slicer-label, .kpi-title') : null;
          let bodyTop = cy + 12;
          if (hdrEl && hdrEl.textContent) {{
            const hdrTxt = _fitText(String(hdrEl.textContent).trim(), Math.max(40, cw - 20));
            ctx.fillStyle = txtPrimary;
            ctx.font = 'bold 12px system-ui, -apple-system, sans-serif';
            ctx.fillText(hdrTxt, cx + 10, cy + 20);
            if (card.id === 'map-card' || card.querySelector('.table-wrapper') || card.querySelector('.plot-container')) {{
              ctx.strokeStyle = brdCol;
              ctx.beginPath();
              ctx.moveTo(cx, cy + 30.5);
              ctx.lineTo(cx + cw, cy + 30.5);
              ctx.stroke();
            }}
            bodyTop = cy + 33;
          }}

          if (card.id === 'map-card') {{
            const mapBox = document.getElementById('map-canvas');
            const mr = (mapBox && mapBox.getBoundingClientRect) ? mapBox.getBoundingClientRect() : null;
            if (mr && mr.width > 10 && mr.height > 10) {{
              const hdrOffset = 31;
              const footerReserve = 24;
              const availW = (scope === 'map') ? cw : Math.max(40, cw - 2);
              const availH = Math.max(40, ch - hdrOffset - footerReserve);
              const mx = (scope === 'map') ? cx : (cx + 1 + Math.max(0, (availW - mr.width) / 2));
              const my = cy + hdrOffset;
              const mw = Math.min(availW, mr.width);
              const mh = Math.min(availH, mr.height);
              const mapOffX = mx - mr.left;
              const mapOffY = my - mr.top;

              ctx.save();
              ctx.beginPath();
              ctx.rect(mx, my, mw, mh);
              ctx.clip();
              ctx.fillStyle = isLight ? '#e2e8f0' : '#0b1322';
              ctx.fillRect(mx, my, mw, mh);

              // 1. WMS / raster basemap & overlay tiles
              const tileImgs = Array.from(mapBox.querySelectorAll('.leaflet-tile-pane img'));
              for (let ti = 0; ti < tileImgs.length; ti++) {{
                const tileImg = tileImgs[ti];
                const trRect = tileImg.getBoundingClientRect ? tileImg.getBoundingClientRect() : null;
                if (!trRect || trRect.width <= 0 || trRect.height <= 0) continue;
                if (trRect.right < mr.left || trRect.left > mr.right || trRect.bottom < mr.top || trRect.top > mr.bottom) continue;
                const safeTile = await _loadExportSafeImage(tileImg);
                if (!safeTile) continue;
                const lyrNode = tileImg.closest ? tileImg.closest('.leaflet-layer') : tileImg.parentElement;
                const lyrCs = (lyrNode && typeof getComputedStyle === 'function') ? getComputedStyle(lyrNode) : null;
                const tileOp = lyrCs && lyrCs.opacity !== undefined ? Math.max(0, Math.min(1, Number(lyrCs.opacity))) : 1;
                ctx.save();
                ctx.globalAlpha = tileOp;
                ctx.drawImage(safeTile.img, trRect.left + mapOffX, trRect.top + mapOffY, trRect.width, trRect.height);
                ctx.restore();
                if (safeTile.revoke) {{ try {{ URL.revokeObjectURL(safeTile.revoke); }} catch (_rv) {{}} }}
              }}

              // 2. Image overlays (packaged basemap snapshots / preview WMS images)
              const ovImgs = Array.from(mapBox.querySelectorAll('.leaflet-overlay-pane img'));
              for (let oi = 0; oi < ovImgs.length; oi++) {{
                const ovImg = ovImgs[oi];
                const orRect = ovImg.getBoundingClientRect ? ovImg.getBoundingClientRect() : null;
                if (!orRect || orRect.width <= 0 || orRect.height <= 0) continue;
                const safeOv = await _loadExportSafeImage(ovImg);
                if (!safeOv) continue;
                const ovCs = (typeof getComputedStyle === 'function') ? getComputedStyle(ovImg) : null;
                const ovOp = ovCs && ovCs.opacity !== undefined ? Math.max(0, Math.min(1, Number(ovCs.opacity))) : 1;
                ctx.save();
                ctx.globalAlpha = ovOp;
                ctx.drawImage(safeOv.img, orRect.left + mapOffX, orRect.top + mapOffY, orRect.width, orRect.height);
                ctx.restore();
                if (safeOv.revoke) {{ try {{ URL.revokeObjectURL(safeOv.revoke); }} catch (_rv2) {{}} }}
              }}

              // 3. ALL Leaflet vector canvases across custom layer panes (qdash_lyr_*) sorted by pane zIndex
              const paneCanvases = Array.from(mapBox.querySelectorAll('.leaflet-pane canvas')).map(cvs => {{
                const paneEl = cvs.closest ? cvs.closest('.leaflet-pane') : cvs.parentElement;
                const pCs = (paneEl && typeof getComputedStyle === 'function') ? getComputedStyle(paneEl) : null;
                const zVal = pCs ? (parseInt(pCs.zIndex, 10) || 400) : 400;
                return {{ cvs, zVal }};
              }}).sort((a, b) => a.zVal - b.zVal);
              paneCanvases.forEach(({{ cvs }}) => {{
                const orRect = cvs.getBoundingClientRect ? cvs.getBoundingClientRect() : null;
                if (!orRect || orRect.width <= 0 || orRect.height <= 0 || !cvs.width || !cvs.height) return;
                try {{
                  ctx.drawImage(cvs, orRect.left + mapOffX, orRect.top + mapOffY, orRect.width, orRect.height);
                }} catch (_ovErr) {{}}
              }});

              // 4. Active feature labels, outside leader lines, and callout boxes
              if (Array.isArray(ACTIVE_RENDERED_LABELS) && ACTIVE_RENDERED_LABELS.length) {{
                // Pass 1: leader lines & feature anchor dots
                ACTIVE_RENDERED_LABELS.forEach(lbl => {{
                  if (!lbl || !lbl.hasLeader) return;
                  ctx.save();
                  ctx.strokeStyle = lbl.color || '#0f172a';
                  ctx.globalAlpha = 0.85;
                  ctx.lineWidth = 1.3;
                  ctx.beginPath();
                  ctx.moveTo(mx + lbl.anchorX, my + lbl.anchorY);
                  ctx.lineTo(mx + lbl.targetX, my + lbl.targetY);
                  ctx.stroke();
                  ctx.fillStyle = lbl.color || '#0f172a';
                  ctx.beginPath();
                  ctx.arc(mx + lbl.anchorX, my + lbl.anchorY, 2.3, 0, Math.PI * 2);
                  ctx.fill();
                  ctx.restore();
                }});
                // Pass 2: label boxes & text
                ACTIVE_RENDERED_LABELS.forEach(lbl => {{
                  if (!lbl || !Array.isArray(lbl.lines) || !lbl.lines.length) return;
                  const bx = mx + lbl.boxX;
                  const by = my + lbl.boxY;
                  const bw = lbl.boxW;
                  const bh = lbl.boxH;
                  if (bx + bw < mx || bx > mx + mw || by + bh < my || by > my + mh) return;
                  ctx.save();
                  const hOp = Math.max(0, Math.min(100, Number(lbl.haloOpacity !== undefined ? lbl.haloOpacity : (lbl.haloOn === false ? 0 : 90))));
                  const hAlpha = hOp / 100;
                  if (lbl.isBox) {{
                    _roundRectPath(bx, by, bw, bh, 4);
                    ctx.fillStyle = lbl.darkBox ? `rgba(15,23,42,${{(0.92 * hAlpha).toFixed(2)}})` : `rgba(255,255,255,${{hAlpha.toFixed(2)}})`;
                    ctx.fill();
                    ctx.strokeStyle = lbl.darkBox ? `rgba(148,163,184,${{(0.55 * Math.max(0.2, hAlpha)).toFixed(2)}})` : `rgba(15,23,42,${{(0.34 * Math.max(0.2, hAlpha)).toFixed(2)}})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                  }}
                  const fSize = Math.max(3, Number(lbl.fontSize || 10));
                  const lineH = Math.round(fSize * 1.2);
                  ctx.font = `bold ${{fSize}}px system-ui, -apple-system, sans-serif`;
                  ctx.textAlign = 'center';
                  ctx.textBaseline = 'middle';
                  const startY = by + (bh - lbl.lines.length * lineH) / 2 + lineH / 2;
                  lbl.lines.forEach((txtLn, lIdx) => {{
                    const tx = bx + bw / 2;
                    const ty = startY + lIdx * lineH;
                    if (hOp > 0 && !lbl.isBox) {{
                      ctx.lineJoin = 'round';
                      ctx.lineWidth = 2.6;
                      ctx.strokeStyle = lbl.darkHalo ? `rgba(15,23,42,${{hAlpha.toFixed(2)}})` : `rgba(255,255,255,${{hAlpha.toFixed(2)}})`;
                      ctx.strokeText(txtLn, tx, ty);
                    }}
                    ctx.fillStyle = lbl.color || '#0f172a';
                    ctx.fillText(txtLn, tx, ty);
                  }});
                  ctx.restore();
                }});
              }}

              // 5. Styled vector legend with color swatches (no collapse button glyph)
              const legBox = mapBox.querySelector('.map-legend, .legend');
              const legCs = (legBox && typeof getComputedStyle === 'function') ? getComputedStyle(legBox) : null;
              const legData = (typeof collectMapLegendEntries === 'function') ? collectMapLegendEntries() : null;
              if (legBox && (!legCs || legCs.display !== 'none') && legData && !legData.collapsed) {{
                const showEntries = (legData.entries && legData.entries.length)
                  ? legData.entries.slice(0, 16)
                  : [{{ kind: 'note', label: t('legend_none_in_view') }}];
                const maxLegW = Math.min(240, Math.max(120, mw * 0.44));
                ctx.font = 'bold 10.5px system-ui, -apple-system, sans-serif';
                let measW = ctx.measureText(String(legData.title || '')).width + 20;
                ctx.font = '10px system-ui, -apple-system, sans-serif';
                showEntries.forEach(ent => {{
                  const padLeft = ent.kind === 'item' ? 26 : 16;
                  const tw = ctx.measureText(String(ent.label || '')).width + padLeft;
                  if (tw > measW) measW = tw;
                }});
                const legW = Math.min(maxLegW, Math.max(115, Math.ceil(measW)));
                const rowH = 15;
                const legH = Math.min(mh - 16, 28 + showEntries.length * rowH + (legData.entries.length > 16 ? 14 : 0));
                const lx = mx + mw - legW - 10;
                const ly = my + mh - legH - 10;
                if (lx > mx + 6 && ly > my + 6) {{
                  ctx.save();
                  _roundRectPath(lx, ly, legW, legH, 6);
                  ctx.fillStyle = isLight ? 'rgba(255,255,255,0.93)' : 'rgba(15,23,42,0.9)';
                  ctx.fill();
                  ctx.strokeStyle = brdCol;
                  ctx.lineWidth = 1;
                  ctx.stroke();

                  ctx.fillStyle = txtPrimary;
                  ctx.font = 'bold 10.5px system-ui, -apple-system, sans-serif';
                  ctx.fillText(_fitText(legData.title || '', legW - 14), lx + 8, ly + 15);
                  ctx.strokeStyle = brdCol;
                  ctx.beginPath();
                  ctx.moveTo(lx + 6, ly + 21.5);
                  ctx.lineTo(lx + legW - 6, ly + 21.5);
                  ctx.stroke();

                  let curY = ly + 33;
                  showEntries.forEach(ent => {{
                    if (curY > ly + legH - 5) return;
                    if (ent.kind === 'header') {{
                      ctx.fillStyle = txtPrimary;
                      ctx.font = 'bold 9.5px system-ui, -apple-system, sans-serif';
                      ctx.fillText(_fitText(ent.label, legW - 14), lx + 8, curY);
                    }} else if (ent.kind === 'note') {{
                      ctx.fillStyle = txtSec;
                      ctx.font = '9.5px system-ui, -apple-system, sans-serif';
                      ctx.fillText(_fitText(ent.label, legW - 14), lx + 8, curY);
                    }} else {{
                      const sx = lx + 8;
                      const sy = curY - 8;
                      if (!ent.outlineOnly && Number(ent.fillOpacity ?? 0.42) > 0.01) {{
                        ctx.fillStyle = _hexToRgbaCss(ent.fillColor || '#10b981', Math.max(0.35, Number(ent.fillOpacity ?? 0.42)));
                        ctx.fillRect(sx, sy, 10, 10);
                      }}
                      ctx.strokeStyle = ent.borderColor || ent.fillColor || '#10b981';
                      ctx.lineWidth = ent.outlineOnly ? 1.8 : 1.2;
                      ctx.strokeRect(sx + 0.5, sy + 0.5, 9, 9);
                      ctx.fillStyle = txtPrimary;
                      ctx.font = '10px system-ui, -apple-system, sans-serif';
                      ctx.fillText(_fitText(ent.label, legW - 28), lx + 23, curY);
                    }}
                    curY += rowH;
                  }});
                  if (legData.entries.length > 16 && curY <= ly + legH - 4) {{
                    ctx.fillStyle = txtSec;
                    ctx.font = '9px system-ui, -apple-system, sans-serif';
                    ctx.fillText(`… (+${{legData.entries.length - 16}})`, lx + 8, curY);
                  }}
                  ctx.restore();
                }}
              }}

              ctx.restore();
              ctx.strokeStyle = brdCol;
              ctx.lineWidth = 1;
              ctx.strokeRect(mx + 0.5, my + 0.5, Math.max(1, mw - 1), Math.max(1, mh - 1));

              // Clean cartographic footer strip (scale, active features, timestamp, attribution)
              const footY = my + mh;
              const footH = (cy + ch) - footY;
              if (footH >= 18) {{
                ctx.fillStyle = subBg;
                ctx.fillRect(cx + 1, footY, Math.max(1, cw - 2), Math.max(1, footH - 1));
                const scaleTxt = (document.getElementById('map-scale-badge') && document.getElementById('map-scale-badge').textContent)
                  ? String(document.getElementById('map-scale-badge').textContent).replace(/[▾▴]/g, '').trim()
                  : '';
                const cntTxt = (document.getElementById('feature-count-badge') && document.getElementById('feature-count-badge').textContent)
                  ? String(document.getElementById('feature-count-badge').textContent).trim()
                  : '';
                const stampTxt = (HAS_LIVE_REFRESHED && LIVE_SESSION_STAMP) ? LIVE_SESSION_STAMP : EXPORTED_AT_STAMP;
                const leftMeta = [scaleTxt, cntTxt].filter(Boolean).join('  ·  ');
                const rightMeta = [stampTxt, '© Maa- ja Ruumiamet'].filter(Boolean).join('  ·  ');
                const textY = footY + Math.min(15, Math.round(footH * 0.62));
                ctx.font = '10.5px system-ui, -apple-system, sans-serif';
                ctx.fillStyle = txtSec;
                const rightW = rightMeta ? ctx.measureText(rightMeta).width + 18 : 0;
                if (leftMeta) {{
                  ctx.fillText(_fitText(leftMeta, Math.max(40, cw - 20 - rightW)), cx + 10, textY);
                }}
                if (rightMeta) {{
                  ctx.save();
                  ctx.textAlign = 'right';
                  ctx.fillText(_fitText(rightMeta, Math.max(40, cw - 20)), cx + cw - 10, textY);
                  ctx.restore();
                }}
              }}
            }}
          }} else if (card.classList && card.classList.contains('kpi-card')) {{
            const kpiCs = (typeof getComputedStyle === 'function') ? getComputedStyle(card) : null;
            const accentCol = (kpiCs && kpiCs.borderLeftColor) ? kpiCs.borderLeftColor : '#38bdf8';
            ctx.fillStyle = accentCol;
            ctx.fillRect(cx, cy, 4, ch);

            let kY = bodyTop + 2;
            const badgeEl = card.querySelector('.widget-filter-badge');
            if (badgeEl && badgeEl.textContent) {{
              ctx.fillStyle = 'rgba(56, 189, 248, 0.14)';
              ctx.font = '600 9.5px system-ui, -apple-system, sans-serif';
              const bTxt = _fitText(badgeEl.textContent.trim(), cw - 28);
              const bw = Math.min(cw - 24, ctx.measureText(bTxt).width + 12);
              _roundRectPath(cx + 12, kY - 6, bw, 16, 4);
              ctx.fill();
              ctx.fillStyle = isLight ? '#0369a1' : '#38bdf8';
              ctx.fillText(bTxt, cx + 18, kY + 5);
              kY += 20;
            }}
            const valEl = card.querySelector('.kpi-value');
            if (valEl && valEl.textContent) {{
              const vCs = (typeof getComputedStyle === 'function') ? getComputedStyle(valEl) : null;
              const vCol = (vCs && vCs.color) ? vCs.color : accentCol;
              const vStr = String(valEl.textContent).trim();
              const fSize = vStr.length > 16 ? 16 : (vStr.length > 11 ? 20 : 25);
              ctx.fillStyle = vCol;
              ctx.font = `bold ${{fSize}}px system-ui, -apple-system, sans-serif`;
              ctx.fillText(_fitText(vStr, Math.max(40, cw - 26)), cx + 12, kY + Math.round(fSize * 0.9));
              kY += fSize + 12;
            }}
            const fillBarEl = card.querySelector('.expr-progress-fill');
            if (fillBarEl) {{
              const pctW = parseFloat(fillBarEl.style.width || '0') || 0;
              const trkW = Math.max(40, cw - 24);
              _roundRectPath(cx + 12, kY, trkW, 7, 3.5);
              ctx.fillStyle = isLight ? '#e2e8f0' : '#334155';
              ctx.fill();
              if (pctW > 0) {{
                _roundRectPath(cx + 12, kY, Math.max(5, trkW * Math.min(1, pctW / 100)), 7, 3.5);
                ctx.fillStyle = fillBarEl.style.backgroundColor || accentCol;
                ctx.fill();
              }}
              kY += 16;
            }}
            const metaEl = card.querySelector('.kpi-meta, .expr-subtext');
            if (metaEl && metaEl.textContent && kY < cy + ch - 8) {{
              ctx.fillStyle = txtSec;
              ctx.font = '11px system-ui, -apple-system, sans-serif';
              ctx.fillText(_fitText(metaEl.textContent.trim(), Math.max(40, cw - 24)), cx + 12, Math.min(cy + ch - 12, kY + 8));
            }}
          }} else if (card.classList && card.classList.contains('slicer-group')) {{
            let px = cx + 10;
            let py = bodyTop + 2;
            const maxX = cx + cw - 10;
            const pillH = 21;
            const pillGap = 6;
            const chips = [];
            const activeChips = Array.from(card.querySelectorAll('.chip.selected'));
            if (activeChips.length) {{
              activeChips.forEach(c => chips.push({{ text: String(c.textContent || '').trim(), active: true }}));
            }} else {{
              const selOpts = Array.from(card.querySelectorAll('select option:checked')).map(o => String(o.textContent || '').trim()).filter(Boolean);
              const rngInputs = Array.from(card.querySelectorAll('.slicer-range-input')).map(inp => String(inp.value || '').trim()).filter(Boolean);
              if (rngInputs.length >= 2) {{
                chips.push({{ text: `${{rngInputs[0]}} – ${{rngInputs[1]}}`, active: true }});
              }} else if (selOpts.length && !/kõik|all|vali|select/i.test(selOpts[0])) {{
                selOpts.forEach(s => chips.push({{ text: s, active: true }}));
              }} else {{
                const allList = Array.from(card.querySelectorAll('.chip, .slicer-list-item span')).map(el => String(el.textContent || '').trim()).filter(Boolean);
                const uniq = Array.from(new Set(allList));
                if (uniq.length) {{
                  uniq.slice(0, 8).forEach(s => chips.push({{ text: s, active: false }}));
                  if (uniq.length > 8) chips.push({{ text: `+${{uniq.length - 8}}`, active: false }});
                }} else {{
                  chips.push({{ text: t('filter_none') || 'Filter puudub', active: false }});
                }}
              }}
            }}
            ctx.font = '10.5px system-ui, -apple-system, sans-serif';
            for (let pi = 0; pi < chips.length; pi++) {{
              const chp = chips[pi];
              const lbl = _fitText(chp.text, Math.max(40, cw - 36));
              if (!lbl) continue;
              const pw = Math.min(cw - 20, Math.ceil(ctx.measureText(lbl).width) + 16);
              if (px + pw > maxX) {{
                px = cx + 10;
                py += pillH + 5;
              }}
              if (py + pillH > cy + ch - 6) break;
              _roundRectPath(px, py, pw, pillH, 10);
              ctx.fillStyle = chp.active ? (isLight ? '#0284c7' : '#38bdf8') : subBg;
              ctx.fill();
              ctx.strokeStyle = chp.active ? (isLight ? '#0284c7' : '#38bdf8') : brdCol;
              ctx.lineWidth = 1;
              ctx.stroke();
              ctx.fillStyle = chp.active ? (isLight ? '#ffffff' : '#0f172a') : txtSec;
              ctx.fillText(lbl, px + 8, py + 14);
              px += pw + pillGap;
            }}
          }} else {{
            const plotEl = card.querySelector ? card.querySelector('.plot-container') : null;
            let drewPlot = false;
            if (plotEl) {{
              const pr = plotEl.getBoundingClientRect ? plotEl.getBoundingClientRect() : null;
              const pxLeft = pr ? (pr.left - rootRect.left) : (cx + 8);
              const pxTop = pr ? ((pr.top - rootRect.top) + headerPad) : bodyTop;
              const pxW = pr && pr.width > 20 ? pr.width : Math.max(40, cw - 16);
              const pxH = pr && pr.height > 20 ? pr.height : Math.max(40, (cy + ch) - bodyTop - 8);
              if (typeof Plotly !== 'undefined' && Plotly && typeof Plotly.toImage === 'function' && plotEl._fullLayout) {{
                try {{
                  const uri = await Plotly.toImage(plotEl, {{
                    format: 'png',
                    width: Math.round(pxW),
                    height: Math.round(pxH),
                    scale: Math.min(2, pxScale)
                  }});
                  const pImg = await new Promise((resolve, reject) => {{
                    const im = new Image();
                    im.onload = () => resolve(im);
                    im.onerror = reject;
                    im.src = uri;
                  }});
                  ctx.drawImage(pImg, pxLeft, pxTop, pxW, pxH);
                  drewPlot = true;
                }} catch (_plErr) {{}}
              }}
              if (!drewPlot) {{
                const svgEl = plotEl.querySelector('svg');
                if (svgEl && typeof XMLSerializer !== 'undefined') {{
                  try {{
                    const svgStr = new XMLSerializer().serializeToString(svgEl);
                    const svgUri = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgStr);
                    const sImg = await new Promise((resolve, reject) => {{
                      const im = new Image();
                      im.onload = () => resolve(im);
                      im.onerror = reject;
                      im.src = svgUri;
                    }});
                    ctx.drawImage(sImg, pxLeft, pxTop, pxW, pxH);
                    drewPlot = true;
                  }} catch (_svgErr) {{}}
                }}
              }}
            }}
            const tableEl = !drewPlot && card.querySelector ? card.querySelector('table') : null;
            if (!drewPlot && tableEl) {{
              const ths = Array.from(tableEl.querySelectorAll('thead th, tr:first-child th'));
              const headerCells = ths.length ? ths : Array.from((tableEl.querySelector('tr') || {{ children: [] }}).children || []);
              const colCount = Math.max(1, headerCells.length);
              const availTblW = Math.max(60, cw - 16);
              const rawWidths = headerCells.map(th => {{
                const r = th.getBoundingClientRect ? th.getBoundingClientRect() : null;
                return (r && r.width > 12) ? r.width : (availTblW / colCount);
              }});
              const sumW = rawWidths.reduce((a, b) => a + b, 0) || availTblW;
              const colWidths = rawWidths.map(rw => (rw / sumW) * availTblW);

              const bodyRows = Array.from(tableEl.querySelectorAll('tbody tr'));
              const dataRows = bodyRows.length ? bodyRows : Array.from(tableEl.querySelectorAll('tr')).slice(ths.length ? 1 : 0);
              const colIsNumeric = headerCells.map((_, ciIdx) => {{
                if (ciIdx === 0) return false;
                let checked = 0, numCount = 0;
                for (let ri = 0; ri < dataRows.length && checked < 6; ri++) {{
                  const cells = dataRows[ri].children || [];
                  const txt = cells[ciIdx] ? String(cells[ciIdx].textContent || '').trim() : '';
                  if (!txt) continue;
                  checked++;
                  if (/^[-+]?[\\d\\s.,]+%?$/.test(txt) && /\\d/.test(txt)) numCount++;
                }}
                return checked > 0 && numCount >= Math.ceil(checked * 0.7);
              }});

              let ty = bodyTop;
              const hdrH = 22;
              if (headerCells.length && ty + hdrH < cy + ch) {{
                ctx.fillStyle = subBg;
                ctx.fillRect(cx + 8, ty, availTblW, hdrH);
                ctx.strokeStyle = brdCol;
                ctx.beginPath();
                ctx.moveTo(cx + 8, ty + hdrH + 0.5);
                ctx.lineTo(cx + 8 + availTblW, ty + hdrH + 0.5);
                ctx.stroke();
                ctx.fillStyle = txtPrimary;
                ctx.font = 'bold 10.5px system-ui, -apple-system, sans-serif';
                let colX = cx + 8;
                headerCells.forEach((th, ciIdx) => {{
                  const cwCol = colWidths[ciIdx] || (availTblW / colCount);
                  const hTxt = _fitText(th.textContent || '', cwCol - 8);
                  if (colIsNumeric[ciIdx]) {{
                    ctx.save();
                    ctx.textAlign = 'right';
                    ctx.fillText(hTxt, colX + cwCol - 4, ty + 14);
                    ctx.restore();
                  }} else {{
                    ctx.fillText(hTxt, colX + 4, ty + 14);
                  }}
                  colX += cwCol;
                }});
                ty += hdrH + 2;
              }}

              const rowH = 19;
              let drawnRows = 0;
              for (let ri = 0; ri < dataRows.length; ri++) {{
                if (ty + rowH > cy + ch - 12) break;
                const trEl = dataRows[ri];
                const isTotal = trEl.classList && trEl.classList.contains('pivot-total-row');
                const isSel = trEl.classList && trEl.classList.contains('selected-row');
                if (isSel) {{
                  ctx.fillStyle = isLight ? 'rgba(2, 132, 199, 0.14)' : 'rgba(56, 189, 248, 0.18)';
                  ctx.fillRect(cx + 8, ty, availTblW, rowH);
                }} else if (isTotal) {{
                  ctx.fillStyle = isLight ? '#e2e8f0' : '#0f172a';
                  ctx.fillRect(cx + 8, ty, availTblW, rowH);
                }} else if (ri % 2 === 1) {{
                  ctx.fillStyle = isLight ? 'rgba(241, 245, 249, 0.65)' : 'rgba(15, 23, 42, 0.35)';
                  ctx.fillRect(cx + 8, ty, availTblW, rowH);
                }}
                const cells = Array.from(trEl.children || []);
                ctx.font = (isTotal ? 'bold ' : '') + '10.5px system-ui, -apple-system, sans-serif';
                ctx.fillStyle = isTotal ? txtPrimary : txtSec;
                let colX = cx + 8;
                for (let ciIdx = 0; ciIdx < colCount; ciIdx++) {{
                  const cwCol = colWidths[ciIdx] || (availTblW / colCount);
                  const cellTxt = cells[ciIdx] ? String(cells[ciIdx].textContent || '').trim() : '';
                  const isNum = ciIdx > 0 && /^[-+]?[\\d\\s.,]+%?$/.test(cellTxt) && /\\d/.test(cellTxt);
                  const fitted = _fitText(cellTxt, cwCol - 8);
                  if (isNum) {{
                    ctx.save();
                    ctx.textAlign = 'right';
                    ctx.fillText(fitted, colX + cwCol - 4, ty + 13);
                    ctx.restore();
                  }} else {{
                    ctx.fillText(fitted, colX + 4, ty + 13);
                  }}
                  colX += cwCol;
                }}
                ty += rowH;
                drawnRows++;
              }}
              if (dataRows.length > drawnRows && ty + 12 <= cy + ch - 2) {{
                ctx.fillStyle = txtSec;
                ctx.font = '9.5px system-ui, -apple-system, sans-serif';
                ctx.fillText(`… (+${{dataRows.length - drawnRows}})`, cx + 12, Math.min(cy + ch - 5, ty + 10));
              }}
              drewPlot = true;
            }}
            const imgWidgetEl = (!drewPlot && card.classList && card.classList.contains('image-widget-card'))
              ? card.querySelector('img')
              : null;
            if (!drewPlot && imgWidgetEl) {{
              const safeWImg = await _loadExportSafeImage(imgWidgetEl);
              if (safeWImg) {{
                const capEl = card.querySelector('.image-widget-caption');
                const capH = (capEl && capEl.textContent) ? 20 : 0;
                const fitMode = (imgWidgetEl.style && imgWidgetEl.style.objectFit) || 'contain';
                _drawImageFit(safeWImg.img, cx + 8, bodyTop, Math.max(20, cw - 16), Math.max(20, (cy + ch) - bodyTop - 8 - capH), fitMode);
                if (safeWImg.revoke) {{ try {{ URL.revokeObjectURL(safeWImg.revoke); }} catch (_rwi) {{}} }}
                if (capH > 0) {{
                  ctx.fillStyle = txtSec;
                  ctx.font = '10.5px system-ui, -apple-system, sans-serif';
                  ctx.fillText(_fitText(capEl.textContent.trim(), cw - 20), cx + 10, cy + ch - 8);
                }}
                drewPlot = true;
              }}
            }}
            if (!drewPlot) {{
              const textFallback = String(card.innerText || card.textContent || '').split(/\\r?\\n/).map(s => s.trim()).filter(Boolean);
              ctx.fillStyle = txtSec;
              ctx.font = '11px system-ui, -apple-system, sans-serif';
              textFallback.slice(1, 8).forEach((txtLine, li) => {{
                const ly = bodyTop + 14 + li * 16;
                if (ly < (cy + ch - 6)) ctx.fillText(_fitText(txtLine, Math.max(40, cw - 20)), cx + 10, ly);
              }});
            }}
          }}

          ctx.restore();
          if (typeof showDashboardLoader === 'function' && cardNodes.length > 0) {{
            showDashboardLoader(t('export_img_busy'), ext.toUpperCase(), 35 + Math.round(((ci + 1) / cardNodes.length) * 55));
          }}
        }}

        let blob = null;
        if (typeof canvas.toBlob === 'function') {{
          blob = await new Promise(resolve => canvas.toBlob(b => resolve(b), mime, fmt === 'jpeg' ? 0.92 : undefined));
        }}
        const dataUrl = (!blob && typeof canvas.toDataURL === 'function')
          ? canvas.toDataURL(mime, fmt === 'jpeg' ? 0.92 : undefined)
          : '';
        const slug = String((DASHBOARD.title || 'dashboard')).toLowerCase().replace(/[^a-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '') || 'dashboard';
        const filename = `${{slug}}_${{scope}}.${{ext}}`;

        if (typeof document.createElement === 'function') {{
          const a = document.createElement('a');
          let objUrl = '';
          if (blob && typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function') {{
            objUrl = URL.createObjectURL(blob);
            a.href = objUrl;
          }} else if (dataUrl) {{
            a.href = dataUrl;
          }}
          a.download = filename;
          a.style.display = 'none';
          if (document.body) {{
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
          }}
          if (objUrl) setTimeout(() => {{ try {{ URL.revokeObjectURL(objUrl); }} catch (_u) {{}} }}, 1500);
        }}

        const info = {{
          format: fmt,
          scope,
          width: canvas.width,
          height: canvas.height,
          bytes: blob ? Number(blob.size || 0) : dataUrl.length,
          hadCorsSkipped: corsSkippedCount > 0,
          corsSkippedTiles: corsSkippedCount,
          filename
        }};
        if (typeof window !== 'undefined') window.__LAST_EXPORTED_IMAGE_INFO = info;
        devLog('INFO', 'EXPORT', `Snapshot exported: ${{filename}} (${{info.width}}x${{info.height}}, ${{info.bytes}} B)`, corsSkippedCount > 0 ? t('export_img_cors_note') : '');
        return info;
      }} catch (err) {{
        devLog('ERROR', 'EXPORT', 'Image export failed: ' + (err && err.message ? err.message : err));
        return null;
      }} finally {{
        if (typeof hideDashboardLoader === 'function') hideDashboardLoader();
      }}
    }}

    function _inferJsFieldKind(layerName, fieldName) {{
      if (!layerName || !fieldName) return 'unknown';
      const recs = LAYER_RECORDS[layerName] || [];
      let checked = 0;
      let numHits = 0;
      for (let i = 0; i < recs.length && checked < 40; i++) {{
        const r = recs[i];
        if (!r) continue;
        const v = r[fieldName];
        if (v === null || v === undefined || String(v).trim() === '') continue;
        checked++;
        if (typeof v !== 'boolean') {{
          const n = Number(String(v).trim().replace(',', '.'));
          if (Number.isFinite(n)) numHits++;
        }}
      }}
      if (!checked) return 'unknown';
      return numHits >= Math.max(1, Math.floor(0.8 * checked)) ? 'numeric' : 'string';
    }}

    function _groupSlicerPanes(sl) {{
      const rawPanes = Array.isArray(sl && sl.panes) ? sl.panes : [];
      const mergeShared = (sl && sl.merge_shared_fields !== false);
      const fbMode = String((sl && sl.display_mode) || 'list').toLowerCase() === 'chips' ? 'chips' : 'list';
      const fbMulti = (sl && sl.multi_select !== false);
      const groups = [];
      rawPanes.forEach((rawPane, idx) => {{
        if (!rawPane || typeof rawPane !== 'object') return;
        const pType = String(rawPane.pane_type || rawPane.type || 'field').toLowerCase();
        if (pType === 'address') {{
          groups.push(Object.assign({{}}, rawPane, {{ pane_type: 'address', merged: false, pane_indices: [idx] }}));
          return;
        }}
        const lname = String(rawPane.layer_name || sl.layer_name || '').trim();
        const fname = String(rawPane.field_name || sl.field_name || '').trim();
        let disp = String(rawPane.display_mode || fbMode).toLowerCase();
        if (disp !== 'list' && disp !== 'chips') disp = fbMode;
        const multi = (rawPane.multi_select !== undefined) ? Boolean(rawPane.multi_select) : fbMulti;
        const kind = _inferJsFieldKind(lname, fname);
        let matchGrp = null;
        if (mergeShared && fname && lname) {{
          const fnKey = fname.toLowerCase();
          for (let gi = 0; gi < groups.length; gi++) {{
            const g = groups[gi];
            if (g.pane_type !== 'field') continue;
            if (String(g.field_name || '').trim().toLowerCase() !== fnKey) continue;
            if (g._kind === 'unknown' || kind === 'unknown' || g._kind === kind) {{
              matchGrp = g;
              if (g._kind === 'unknown' && kind !== 'unknown') g._kind = kind;
              break;
            }}
          }}
        }}
        if (matchGrp) {{
          if (!matchGrp.sources.some(s => s.layer_name === lname && s.field_name === fname)) {{
            matchGrp.sources.push({{ layer_name: lname, field_name: fname }});
          }}
          matchGrp.pane_indices.push(idx);
          matchGrp.multi_select = Boolean(matchGrp.multi_select || multi);
        }} else {{
          groups.push(Object.assign({{}}, rawPane, {{
            pane_type: 'field',
            layer_name: lname,
            field_name: fname,
            display_mode: disp,
            multi_select: multi,
            sources: lname ? [{{ layer_name: lname, field_name: fname }}] : [],
            pane_indices: [idx],
            _kind: kind
          }}));
        }}
      }});
      return groups.map(g => {{
        const uniqueLayers = Array.from(new Set((g.sources || []).map(s => s.layer_name).filter(Boolean)));
        const out = Object.assign({{}}, g);
        delete out._kind;
        if (out.pane_type === 'field' && uniqueLayers.length >= 2) {{
          out.merged = true;
          out.title = `${{out.field_name}} (${{uniqueLayers.join(' + ')}})`;
        }} else {{
          out.merged = false;
        }}
        return out;
      }});
    }}

    function _collectDistinctCatsForSources(sl, sourceId, sources) {{
      const catSet = new Set();
      (sources || []).forEach(src => {{
        const ln = src && src.layer_name ? String(src.layer_name) : '';
        const fn = src && src.field_name ? String(src.field_name) : '';
        if (!ln || !fn) return;
        const allRows = LAYER_RECORDS[ln] || [];
        const rows = (sl.cascade_filters !== false && typeof filterRecords === 'function')
          ? filterRecords(ln, sourceId, null)
          : allRows;
        rows.forEach(r => {{
          const v = r ? r[fn] : undefined;
          if (v !== null && v !== undefined && String(v).trim() !== '') catSet.add(String(v));
        }});
      }});
      const activeVals = ((ACTIVE_FILTERS[sourceId] && ACTIVE_FILTERS[sourceId].values) || []).map(v => String(v));
      activeVals.forEach(v => {{ if (v !== '') catSet.add(v); }});
      return {{ cats: Array.from(catSet).sort(), activeVals }};
    }}

    function _renderCategorySlicerControl(hostEl, cfg) {{
      const sourceId = String(cfg.sourceId || '');
      const layerName = String(cfg.layerName || '');
      const fieldName = String(cfg.fieldName || '');
      const layerFields = Array.isArray(cfg.layerFields) ? cfg.layerFields : [];
      const cats = Array.isArray(cfg.cats) ? cfg.cats : [];
      const activeVals = Array.isArray(cfg.activeVals) ? cfg.activeVals : [];
      const displayMode = String(cfg.displayMode || 'list').toLowerCase();
      const showSearch = cfg.showSearch !== false;
      const multiSelect = cfg.multiSelect !== false;
      const onDoneRender = cfg.onDoneRender;

      const toggleCat = val => {{
        toggleCategoryFilter(sourceId, layerName, fieldName, String(val), false, {{
          multi: multiSelect,
          layerFields
        }});
      }};
      const clearSlicerOpt = () => {{
        delete ACTIVE_FILTERS[sourceId];
        if (LAST_INTERACTED_FILTER_SOURCE === sourceId) LAST_INTERACTED_FILTER_SOURCE = null;
        saveDashboardSessionState();
        buildSlicers();
        if (typeof onDoneRender === 'function') onDoneRender();
      }};

      if (cfg.includeDropdown) {{
        const sel = document.createElement('select');
        sel.className = 'slicer-select';
        sel.autocomplete = 'off';
        const allOpt = document.createElement('option');
        allOpt.value = '';
        allOpt.textContent = t('slicer_no_filter');
        sel.appendChild(allOpt);
        cats.forEach(cat => {{
          const opt = document.createElement('option');
          opt.value = String(cat);
          opt.textContent = String(cat);
          sel.appendChild(opt);
        }});
        sel.value = activeVals.length ? String(activeVals[0]) : '';
        sel.onchange = () => {{
          if (!sel.value) {{
            clearSlicerOpt();
          }} else {{
            ACTIVE_FILTERS[sourceId] = {{
              layer_name: layerName,
              field_name: fieldName,
              layer_fields: layerFields,
              type: 'category',
              multi: multiSelect,
              values: [sel.value],
              page_id: cfg.pageId || ACTIVE_PAGE_ID,
              is_global: Boolean(cfg.isGlobal)
            }};
            LAST_INTERACTED_FILTER_SOURCE = sourceId;
            saveDashboardSessionState();
            buildSlicers();
            if (typeof onDoneRender === 'function') onDoneRender();
          }}
        }};
        hostEl.appendChild(sel);
      }}

      const countEl = document.createElement('div');
      countEl.className = 'slicer-count-meta';
      const prevQuery = SLICER_SEARCH_QUERIES[sourceId] || '';
      const srch = showSearch ? document.createElement('input') : null;
      if (srch) {{
        srch.type = 'search';
        srch.autocomplete = 'off';
        srch.className = 'slicer-search';
        srch.placeholder = t('ph_slicer_search');
        srch.value = prevQuery;
        hostEl.appendChild(srch);
      }}

      if (displayMode === 'list') {{
        const box = document.createElement('div');
        box.className = 'slicer-list-box';
        const listDiv = document.createElement('div');
        listDiv.className = 'slicer-list-scroll';
        const renderOpts = needle => {{
          const n = (needle || '').trim().toLowerCase();
          listDiv.innerHTML = '';
          const noneLbl = document.createElement('label');
          noneLbl.className = 'slicer-list-item slicer-no-filter-item';
          const noneCb = document.createElement('input');
          noneCb.type = 'checkbox';
          noneCb.autocomplete = 'off';
          noneCb.checked = activeVals.length === 0;
          noneCb.onchange = () => clearSlicerOpt();
          const noneTxt = document.createElement('span');
          noneTxt.textContent = t('slicer_no_filter');
          noneLbl.appendChild(noneCb);
          noneLbl.appendChild(noneTxt);

          const matched = cats.filter(c => !n || String(c).toLowerCase().includes(n));
          if (!(n && matched.length > 0)) listDiv.appendChild(noneLbl);
          countEl.textContent = t('slicer_matches_count', {{ shown: matched.length, total: cats.length }});
          matched.forEach(cat => {{
            const rowLbl = document.createElement('label');
            rowLbl.className = 'slicer-list-item';
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.autocomplete = 'off';
            cb.checked = activeVals.includes(String(cat));
            cb.onchange = () => toggleCat(cat);
            const txt = document.createElement('span');
            txt.textContent = String(cat);
            rowLbl.appendChild(cb);
            rowLbl.appendChild(txt);
            listDiv.appendChild(rowLbl);
          }});
          if (n && matched.length > 0) listDiv.appendChild(noneLbl);
          listDiv.scrollTop = 0;
        }};
        if (srch) {{
          srch.oninput = () => {{
            SLICER_SEARCH_QUERIES[sourceId] = srch.value;
            renderOpts(srch.value);
          }};
        }}
        renderOpts(prevQuery);
        box.appendChild(listDiv);
        box.appendChild(countEl);
        hostEl.appendChild(box);
      }} else {{
        let chipNeedle = prevQuery;
        const chipWrap = document.createElement('div');
        chipWrap.className = 'slicer-chips-scroll';
        const drawChips = () => {{
          chipWrap.innerHTML = '';
          const n = chipNeedle.trim().toLowerCase();
          const matched = cats.filter(c => !n || String(c).toLowerCase().includes(n));
          countEl.textContent = t('slicer_matches_count', {{ shown: matched.length, total: cats.length }});
          matched.forEach(cat => {{
            const chip = document.createElement('span');
            chip.className = 'chip' + (activeVals.includes(String(cat)) ? ' selected' : '');
            chip.textContent = String(cat);
            chip.onclick = () => toggleCat(cat);
            chipWrap.appendChild(chip);
          }});
        }};
        if (srch) {{
          srch.oninput = () => {{
            chipNeedle = srch.value;
            SLICER_SEARCH_QUERIES[sourceId] = srch.value;
            drawChips();
          }};
        }}
        drawChips();
        hostEl.appendChild(chipWrap);
        hostEl.appendChild(countEl);
      }}
    }}

    function buildSlicers() {{
      const bar = document.getElementById('slicer-bar');
      if (!bar) return;
      document.querySelectorAll('#workspace-main > .slicer-group').forEach(el => el.remove());
      bar.innerHTML = '';
      (DASHBOARD.slicers || []).forEach(sl => {{
        if (sl.page_id && !sl.is_global && String(sl.page_id) !== String(ACTIVE_PAGE_ID || 'page_1')) return;
        const group = document.createElement('div');
        group.className = 'slicer-group';
        group.dataset.slicerId = sl.id;
        const hdr = document.createElement('div');
        hdr.style.display = 'flex';
        hdr.style.alignItems = 'center';
        hdr.style.justifyContent = 'space-between';
        hdr.style.gap = '6px';
        hdr.style.width = '100%';
        const lbl = document.createElement('span');
        lbl.className = 'slicer-label';
        lbl.textContent = localizedTitle(sl) + ':';
        hdr.appendChild(lbl);
        const hasSlFilter = Object.keys(ACTIVE_FILTERS).some(k => k === sl.id || k.startsWith(sl.id + '__pane_'));
        if (hasSlFilter) {{
          const clrBtn = document.createElement('button');
          clrBtn.type = 'button';
          clrBtn.className = 'btn-clear-widget';
          clrBtn.textContent = '✕';
          clrBtn.title = t('btn_clear_filter');
          clrBtn.onclick = () => clearWidgetFilter(sl.id);
          hdr.appendChild(clrBtn);
        }}
        group.appendChild(hdr);

        const _triggerSlicerRender = () => {{
          if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
          if (typeof triggerRenderWithBusyFeedback === 'function') triggerRenderWithBusyFeedback();
          else renderAll();
        }};

        if (Array.isArray(sl.panes) && sl.panes.length > 0) {{
          const groupedPanes = _groupSlicerPanes(sl);
          if (groupedPanes.length === 1 && groupedPanes[0].merged && groupedPanes[0].pane_type === 'field') {{
            const g0 = groupedPanes[0];
            const sub = document.createElement('div');
            sub.style.fontSize = '0.72rem';
            sub.style.color = 'var(--text-secondary)';
            sub.textContent = g0.title || '';
            group.appendChild(sub);
            const {{ cats, activeVals }} = _collectDistinctCatsForSources(sl, sl.id, g0.sources);
            _renderCategorySlicerControl(group, {{
              sourceId: sl.id,
              layerName: g0.layer_name || sl.layer_name,
              fieldName: g0.field_name || sl.field_name,
              layerFields: g0.sources,
              cats,
              activeVals,
              displayMode: g0.display_mode || sl.display_mode || 'list',
              showSearch: sl.show_search !== false,
              multiSelect: Boolean(g0.multi_select !== undefined ? g0.multi_select : sl.multi_select),
              pageId: sl.page_id || ACTIVE_PAGE_ID,
              isGlobal: Boolean(sl.is_global),
              includeDropdown: true,
              onDoneRender: _triggerSlicerRender
            }});
            bar.appendChild(group);
            return;
          }}

          const panesWrap = document.createElement('div');
          panesWrap.className = 'slicer-multi-panes';
          groupedPanes.forEach((pane, pi) => {{
            const paneId = (groupedPanes.length === 1 && pane.merged) ? sl.id : `${{sl.id}}__pane_${{pi}}`;
            const paneEl = document.createElement('div');
            paneEl.className = 'slicer-subpane';
            const pTitle = document.createElement('div');
            pTitle.className = 'slicer-subpane-hdr';
            pTitle.textContent = pane.title || pane.field_name || (pane.pane_type === 'address' ? t('addr_pane_title') : `Pane ${{pi + 1}}`);
            paneEl.appendChild(pTitle);

            if (pane.pane_type === 'address') {{
              const addrRow = document.createElement('div');
              addrRow.style.display = 'flex';
              addrRow.style.gap = '4px';
              const aInp = document.createElement('input');
              aInp.type = 'search';
              aInp.className = 'slicer-search';
              aInp.placeholder = t('addr_search_ph');
              const curPaneFlt = ACTIVE_FILTERS[paneId];
              if (curPaneFlt && curPaneFlt.display_label) aInp.value = curPaneFlt.display_label;
              const aBtn = document.createElement('button');
              aBtn.type = 'button';
              aBtn.className = 'btn-mini-icon';
              aBtn.textContent = '🔍';
              const aRes = document.createElement('div');
              aRes.className = 'map-addr-results';
              aRes.style.position = 'static';
              aRes.style.maxHeight = '120px';

              const runPaneAddr = async () => {{
                const q = String(aInp.value || '').trim();
                if (q.length < 2) return;
                const url = 'https://inaadress.maaamet.ee/inaadress/gazetteer?address=' + encodeURIComponent(q) + '&results=8&features=KATASTRIYKSUS,EHITISHOONE,Kinnistu,TANAV,ASULAKOHT';
                try {{
                  const resp = await fetch(url);
                  const data = await resp.json();
                  const cands = Array.isArray(data && data.addresses) ? data.addresses : [];
                  aRes.innerHTML = '';
                  aRes.style.display = cands.length ? 'block' : 'none';
                  cands.slice(0, 8).forEach(cand => {{
                    const optBtn = document.createElement('button');
                    optBtn.type = 'button';
                    optBtn.className = 'map-addr-opt';
                    const disp = cand.ipikkaadress || cand.taisaadress || cand.koodaadress || q;
                    optBtn.textContent = disp;
                    optBtn.onclick = () => {{
                      const geomWgs = cand.geometry ? _convertEstGeomToWgs84(cand.geometry) : null;
                      let bb = geomWgs ? geomBbox(geomWgs) : null;
                      let geom = geomWgs;
                      if (!geom && cand.viitepunkt_b && cand.viitepunkt_l) {{
                        const buf = _pointWgs84BufferGeom(Number(cand.viitepunkt_b), Number(cand.viitepunkt_l));
                        geom = buf.geometry;
                        bb = buf.bbox;
                      }} else if (!geom && cand.viitepunkt_x && cand.viitepunkt_y) {{
                        const ll = _toWgs84Coord(cand.viitepunkt_x, cand.viitepunkt_y);
                        if (ll) {{
                          const buf = _pointWgs84BufferGeom(ll[0], ll[1]);
                          geom = buf.geometry;
                          bb = buf.bbox;
                        }}
                      }}
                      ACTIVE_FILTERS[paneId] = {{
                        layer_name: '__spatial__',
                        field_name: 'address',
                        type: 'spatial_geom',
                        geometry: geom,
                        bbox: bb,
                        display_label: disp,
                        page_id: sl.page_id || ACTIVE_PAGE_ID,
                        is_global: Boolean(sl.is_global)
                      }};
                      LAST_INTERACTED_FILTER_SOURCE = paneId;
                      saveDashboardSessionState();
                      buildSlicers();
                      _triggerSlicerRender();
                    }};
                    aRes.appendChild(optBtn);
                  }});
                }} catch (_e) {{}}
              }};
              aBtn.onclick = runPaneAddr;
              aInp.onkeydown = ev => {{ if (ev.key === 'Enter') {{ ev.preventDefault(); runPaneAddr(); }} }};
              addrRow.appendChild(aInp);
              addrRow.appendChild(aBtn);
              if (curPaneFlt) {{
                const xBtn = document.createElement('button');
                xBtn.type = 'button';
                xBtn.className = 'btn-mini-icon';
                xBtn.textContent = '✕';
                xBtn.onclick = () => {{ delete ACTIVE_FILTERS[paneId]; saveDashboardSessionState(); buildSlicers(); _triggerSlicerRender(); }};
                addrRow.appendChild(xBtn);
              }}
              paneEl.appendChild(addrRow);
              paneEl.appendChild(aRes);
            }} else {{
              const pSources = (Array.isArray(pane.sources) && pane.sources.length)
                ? pane.sources
                : [{{ layer_name: String(pane.layer_name || sl.layer_name || ''), field_name: String(pane.field_name || sl.field_name || '') }}];
              const pLayer = pSources[0] ? pSources[0].layer_name : (pane.layer_name || sl.layer_name);
              const pField = pSources[0] ? pSources[0].field_name : (pane.field_name || sl.field_name);
              const {{ cats, activeVals }} = _collectDistinctCatsForSources(sl, paneId, pSources);
              _renderCategorySlicerControl(paneEl, {{
                sourceId: paneId,
                layerName: pLayer,
                fieldName: pField,
                layerFields: pane.merged ? pSources : [],
                cats,
                activeVals,
                displayMode: pane.display_mode || sl.display_mode || 'list',
                showSearch: sl.show_search !== false,
                multiSelect: Boolean(pane.multi_select !== undefined ? pane.multi_select : sl.multi_select),
                pageId: sl.page_id || ACTIVE_PAGE_ID,
                isGlobal: Boolean(sl.is_global),
                includeDropdown: false,
                onDoneRender: _triggerSlicerRender
              }});
            }}
            panesWrap.appendChild(paneEl);
          }});
          group.appendChild(panesWrap);
          bar.appendChild(group);
          return;
        }}

        const allLayerRows = LAYER_RECORDS[sl.layer_name] || Object.values(LAYER_RECORDS)[0] || [];
        const slType = String(sl.slicer_type || 'category').toLowerCase();
        const rows = (sl.cascade_filters !== false && typeof filterRecords === 'function')
          ? filterRecords(sl.layer_name, sl.id, null)
          : allLayerRows;

        if (slType === 'numeric_range') {{
          const nums = (rows.length ? rows : allLayerRows)
            .map(r => (r && r[sl.field_name] !== null && r[sl.field_name] !== undefined && r[sl.field_name] !== '') ? Number(r[sl.field_name]) : NaN)
            .filter(n => Number.isFinite(n));
          const dMin = nums.length ? Math.min(...nums) : 0;
          const dMax = nums.length ? Math.max(...nums) : 100;
          const curFlt = ACTIVE_FILTERS[sl.id];
          const curMin = (curFlt && curFlt.min !== undefined && curFlt.min !== null) ? curFlt.min : dMin;
          const curMax = (curFlt && curFlt.max !== undefined && curFlt.max !== null) ? curFlt.max : dMax;

          const rangeRow = document.createElement('div');
          rangeRow.className = 'slicer-range-row';
          const minIn = document.createElement('input');
          minIn.type = 'number';
          minIn.autocomplete = 'off';
          minIn.step = 'any';
          minIn.className = 'slicer-range-input';
          minIn.placeholder = t('range_min');
          minIn.value = String(curMin);
          const maxIn = document.createElement('input');
          maxIn.type = 'number';
          maxIn.autocomplete = 'off';
          maxIn.step = 'any';
          maxIn.className = 'slicer-range-input';
          maxIn.placeholder = t('range_max');
          maxIn.value = String(curMax);

          const applyNumRange = () => {{
            const rawLo = minIn.value === '' ? null : Number(minIn.value);
            const rawHi = maxIn.value === '' ? null : Number(maxIn.value);
            const lo = (rawLo !== null && Number.isFinite(rawLo)) ? rawLo : null;
            const hi = (rawHi !== null && Number.isFinite(rawHi)) ? rawHi : null;
            const effLo = (lo !== null && hi !== null) ? Math.min(lo, hi) : lo;
            const effHi = (lo !== null && hi !== null) ? Math.max(lo, hi) : hi;
            if (effLo === null && effHi === null) {{
              delete ACTIVE_FILTERS[sl.id];
            }} else {{
              ACTIVE_FILTERS[sl.id] = {{
                layer_name: sl.layer_name,
                field_name: sl.field_name,
                type: 'numeric_range',
                min: effLo,
                max: effHi,
                page_id: sl.page_id || ACTIVE_PAGE_ID,
                is_global: Boolean(sl.is_global)
              }};
            }}
            saveDashboardSessionState();
            buildSlicers();
            _triggerSlicerRender();
          }};
          const resetNumRange = () => {{
            delete ACTIVE_FILTERS[sl.id];
            saveDashboardSessionState();
            buildSlicers();
            _triggerSlicerRender();
          }};
          minIn.onchange = applyNumRange;
          maxIn.onchange = applyNumRange;
          const btnApply = document.createElement('button');
          btnApply.type = 'button';
          btnApply.className = 'slicer-range-btn slicer-range-btn-primary';
          btnApply.textContent = t('range_apply');
          btnApply.onclick = applyNumRange;
          const btnAll = document.createElement('button');
          btnAll.type = 'button';
          btnAll.className = 'slicer-range-btn';
          btnAll.textContent = t('slicer_all');
          btnAll.onclick = resetNumRange;
          const sep = document.createElement('span');
          sep.textContent = '–';
          rangeRow.appendChild(minIn);
          rangeRow.appendChild(sep);
          rangeRow.appendChild(maxIn);
          rangeRow.appendChild(btnApply);
          rangeRow.appendChild(btnAll);
          group.appendChild(rangeRow);
          bar.appendChild(group);
          return;
        }}

        if (slType === 'date_range') {{
          const dates = (rows.length ? rows : allLayerRows)
            .map(r => (r && r[sl.field_name] !== null && r[sl.field_name] !== undefined) ? String(r[sl.field_name]).trim() : '')
            .filter(s => s.length >= 10)
            .map(s => s.slice(0, 10).replace('/', '-').replace('/', '-'))
            .sort();
          const dMin = dates.length ? dates[0] : '';
          const dMax = dates.length ? dates[dates.length - 1] : '';
          const curFlt = ACTIVE_FILTERS[sl.id];
          const curMin = (curFlt && curFlt.min !== undefined && curFlt.min !== null) ? String(curFlt.min).slice(0, 10) : dMin;
          const curMax = (curFlt && curFlt.max !== undefined && curFlt.max !== null) ? String(curFlt.max).slice(0, 10) : dMax;

          const rangeRow = document.createElement('div');
          rangeRow.className = 'slicer-range-row';
          const minIn = document.createElement('input');
          minIn.type = 'date';
          minIn.autocomplete = 'off';
          minIn.className = 'slicer-range-input';
          minIn.title = t('range_from');
          minIn.value = curMin;
          const maxIn = document.createElement('input');
          maxIn.type = 'date';
          maxIn.autocomplete = 'off';
          maxIn.className = 'slicer-range-input';
          maxIn.title = t('range_to');
          maxIn.value = curMax;

          const applyDateRange = () => {{
            const lo = minIn.value ? String(minIn.value).trim() : null;
            const hi = maxIn.value ? String(maxIn.value).trim() : null;
            const effLo = (lo && hi && lo > hi) ? hi : lo;
            const effHi = (lo && hi && lo > hi) ? lo : hi;
            if (!effLo && !effHi) {{
              delete ACTIVE_FILTERS[sl.id];
            }} else {{
              ACTIVE_FILTERS[sl.id] = {{
                layer_name: sl.layer_name,
                field_name: sl.field_name,
                type: 'date_range',
                min: effLo,
                max: effHi,
                page_id: sl.page_id || ACTIVE_PAGE_ID,
                is_global: Boolean(sl.is_global)
              }};
            }}
            saveDashboardSessionState();
            buildSlicers();
            _triggerSlicerRender();
          }};
          const resetDateRange = () => {{
            delete ACTIVE_FILTERS[sl.id];
            saveDashboardSessionState();
            buildSlicers();
            _triggerSlicerRender();
          }};
          minIn.onchange = applyDateRange;
          maxIn.onchange = applyDateRange;
          const btnApply = document.createElement('button');
          btnApply.type = 'button';
          btnApply.className = 'slicer-range-btn slicer-range-btn-primary';
          btnApply.textContent = t('range_apply');
          btnApply.onclick = applyDateRange;
          const btnAll = document.createElement('button');
          btnAll.type = 'button';
          btnAll.className = 'slicer-range-btn';
          btnAll.textContent = t('slicer_all');
          btnAll.onclick = resetDateRange;
          const sep = document.createElement('span');
          sep.textContent = '→';
          rangeRow.appendChild(minIn);
          rangeRow.appendChild(sep);
          rangeRow.appendChild(maxIn);
          rangeRow.appendChild(btnApply);
          rangeRow.appendChild(btnAll);
          group.appendChild(rangeRow);
          bar.appendChild(group);
          return;
        }}

        const {{ cats, activeVals }} = _collectDistinctCatsForSources(sl, sl.id, [{{ layer_name: sl.layer_name, field_name: sl.field_name }}]);
        _renderCategorySlicerControl(group, {{
          sourceId: sl.id,
          layerName: sl.layer_name,
          fieldName: sl.field_name,
          layerFields: [],
          cats,
          activeVals,
          displayMode: sl.display_mode || 'chips',
          showSearch: sl.show_search !== false,
          multiSelect: Boolean(sl.multi_select),
          pageId: sl.page_id || ACTIVE_PAGE_ID,
          isGlobal: Boolean(sl.is_global),
          includeDropdown: true,
          onDoneRender: _triggerSlicerRender
        }});
        bar.appendChild(group);
      }});
      if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();
      if (typeof applyArtboardLayout === 'function') applyArtboardLayout({{ skipPlotResize: true }});
    }}

    function styleFeatureForLayer(layerName, row, rendererOverride, paneOverride) {{
      const svc = (BUNDLE.ogc_services || []).find(s => s.name === layerName);
      const spec = getEffectiveLayerStyleSpec(layerName);
      const custom = spec.custom;
      const qgisStyle = spec.qgisStyle;
      const props = (row && row.properties) ? row.properties : (row || {{}});
      let color = defaultUniformColor(layerName, custom, svc);
      const outlineOnly = Boolean(custom && custom.outline_only);
      let fillOpacity = outlineOnly
        ? 0.0
        : ((custom && custom.opacity !== undefined)
            ? Number(custom.opacity)
            : ((qgisStyle && qgisStyle.opacity !== undefined) ? Number(qgisStyle.opacity) : 0.42));
      let weight = (custom && custom.stroke_width !== undefined)
        ? Number(custom.stroke_width)
        : ((qgisStyle && qgisStyle.stroke_width !== undefined) ? Number(qgisStyle.stroke_width) : 1.5);
      let dashArray = null;

      const mode = spec.mode;
      const styleFields = spec.styleFields;
      if (mode !== 'single' && styleFields.length > 0) {{
        const parts = styleFields.map(f => props[f]).filter(v => v !== null && v !== undefined && String(v).trim() !== '').map(v => String(v));
        if (parts.length) {{
          color = resolveCategoryColor(parts.join(' | '), qgisStyle);
        }}
      }}
      const strokeColor = (custom && custom.border_color && String(custom.border_color).trim())
        ? String(custom.border_color).trim()
        : ((mode === 'single' && (!custom || !custom.color) && qgisStyle && qgisStyle.stroke_color)
            ? qgisStyle.stroke_color
            : color);
      const st = {{ color: strokeColor, fillColor: color, weight, fillOpacity, opacity: 0.95 }};
      const effRenderer = rendererOverride || LAYER_CANVAS_RENDERERS[layerName] || vectorCanvasRenderer;
      if (effRenderer) st.renderer = effRenderer;
      if (paneOverride) st.pane = paneOverride;
      if (dashArray) st.dashArray = dashArray;
      return st;
    }}

    function buildPopupHtml(layerName, row) {{
      const rowsHtml = Object.entries(row)
        .filter(([k]) => !k.startsWith('_'))
        .slice(0, 14)
        .map(([k, v]) => `<b>${{escapeHtml(k)}}:</b> ${{escapeHtml(v ?? '')}}`)
        .join('<br/>');
      return `<div style="font-size:12px;line-height:1.45;"><b>[${{escapeHtml(layerName)}}]</b><hr style="margin:4px 0"/>${{rowsHtml}}</div>`;
    }}

    function _layerGeomSortRank(ln) {{
      const gt = String(LAYER_GEOM_TYPES[ln] || (LAYER_STATS[ln] && LAYER_STATS[ln].geom_type) || '').toLowerCase();
      if (gt.includes('point')) return 0;
      if (gt.includes('line')) return 1;
      if (gt.includes('poly')) return 2;
      return 3;
    }}

    function _layerFeatureCountEst(ln) {{
      const st = LAYER_STATS[ln] || {{}};
      const rows = LAYER_RECORDS[ln] || [];
      return Number(st.feature_count || rows.length || 0);
    }}

    function orderedMapLayerNames() {{
      const mapWidget = getActiveMapWidget();
      const hasAnyPagedMap = (DASHBOARD.widgets || []).some(w => w && w.widget_type === 'map' && Boolean(w.page_id));
      if (!mapWidget && hasAnyPagedMap && (DASHBOARD.pages || []).length > 1) {{
        return [];
      }}
      const hasLayer = (ln) => Boolean(
        ln && (
          LAYER_RECORDS[ln] ||
          LAYER_OVERLAYS[ln] ||
          (BUNDLE.initial_layer_records && BUNDLE.initial_layer_records[ln]) ||
          (BUNDLE.initial_geojson && BUNDLE.initial_geojson[ln])
        )
      );
      const allNames = Array.from(new Set([...Object.keys(LAYER_RECORDS), ...Object.keys(LAYER_OVERLAYS)]));
      const explicitFromMw = (mapWidget && Array.isArray(mapWidget.map_layers) && mapWidget.map_layers.length)
        ? mapWidget.map_layers
        : ((mapWidget && mapWidget.layer_name && mapWidget.layer_name !== '*') ? [mapWidget.layer_name] : null);
      const preferred = (Array.isArray(CUSTOM_MAP_LAYERS) && CUSTOM_MAP_LAYERS.length)
        ? CUSTOM_MAP_LAYERS
        : explicitFromMw;
      if (preferred && preferred.length) {{
        const seen = new Set();
        const out = [];
        preferred.forEach(ln => {{
          if (hasLayer(ln) && !seen.has(ln)) {{
            seen.add(ln);
            out.push(ln);
          }}
        }});
        return out;
      }}
      // Smart auto-order (#7): Point < Line < Polygon, ascending feature count (smaller layers on top)
      return allNames.slice().sort((a, b) => {{
        const ra = _layerGeomSortRank(a);
        const rb = _layerGeomSortRank(b);
        if (ra !== rb) return ra - rb;
        const ca = _layerFeatureCountEst(a);
        const cb = _layerFeatureCountEst(b);
        if (ca !== cb) return ca - cb;
        return a.localeCompare(b);
      }});
    }}

    function ensureCustomMapLayerOrder() {{
      const order = orderedMapLayerNames();
      CUSTOM_MAP_LAYERS = order.slice();
      const mapWidget = getActiveMapWidget();
      if (mapWidget) mapWidget.map_layers = CUSTOM_MAP_LAYERS.slice();
      return CUSTOM_MAP_LAYERS;
    }}

    function positionMapLayersDrawer() {{
      const drawer = document.getElementById('map-layers-drawer');
      if (!drawer) return;
      const vw = Number((typeof window !== 'undefined' && window.innerWidth) || 1280);
      const vh = Number((typeof window !== 'undefined' && window.innerHeight) || 720);
      const btn = document.getElementById('btn-map-layers');
      const rect = (btn && typeof btn.getBoundingClientRect === 'function') ? btn.getBoundingClientRect() : null;
      const estW = Math.min(740, Math.round(vw * 0.94));
      const estH = Math.min(660, Math.round(vh * 0.82));
      let top = (rect && rect.bottom > 0) ? Math.round(rect.bottom + 8) : Math.max(12, Math.round((vh - estH) * 0.16));
      let left = (rect && rect.right > 0) ? Math.round(rect.right - estW) : Math.max(12, Math.round((vw - estW) * 0.5));
      if (left + estW > vw - 12) left = vw - estW - 12;
      if (left < 12) left = 12;
      if (top + Math.min(360, estH) > vh - 12) top = Math.max(12, vh - Math.min(460, estH) - 12);
      if (top < 12) top = 12;
      drawer.style.left = left + 'px';
      drawer.style.top = top + 'px';
    }}

    function toggleMapLayersPanel() {{
      const drawer = document.getElementById('map-layers-drawer');
      if (!drawer) return;
      const show = drawer.style.display === 'none' || !drawer.style.display;
      if (show) {{
        const catDrawer = document.getElementById('map-catalog-drawer');
        if (catDrawer) catDrawer.style.display = 'none';
        const catBtn = document.getElementById('btn-map-catalog');
        if (catBtn && catBtn.classList) catBtn.classList.remove('active');
        drawer.onclick = ev => {{ if (ev && ev.stopPropagation) ev.stopPropagation(); }};
        renderMapLayersDrawer();
        positionMapLayersDrawer();
      }}
      drawer.style.display = show ? 'flex' : 'none';
    }}

    function moveMapLayerOrder(layerName, delta) {{
      const order = ensureCustomMapLayerOrder();
      const idx = order.indexOf(layerName);
      const nxt = idx + Number(delta || 0);
      if (idx < 0 || nxt < 0 || nxt >= order.length) return;
      const tmp = order[idx];
      order[idx] = order[nxt];
      order[nxt] = tmp;
      CUSTOM_MAP_LAYERS = order.slice();
      const mapWidget = getActiveMapWidget();
      if (mapWidget) {{
        mapWidget.map_layers = CUSTOM_MAP_LAYERS.slice();
        mapWidget.map_layers_custom_order = true;
      }}
      renderMapLayersDrawer();
      scheduleMapRender({{ skipAutoZoom: true }});
    }}

    function toggleMapLayerVisible(layerName, isVisible) {{
      MAP_LAYER_VISIBILITY[layerName] = Boolean(isVisible);
      const grp = LAYER_OVERLAYS[layerName];
      if (grp && map) {{
        IS_SYNCING_MAP_LAYERS += 1;
        try {{
          if (MAP_LAYER_VISIBILITY[layerName]) {{
            if (!map.hasLayer(grp)) grp.addTo(map);
          }} else {{
            if (map.hasLayer(grp)) map.removeLayer(grp);
            if (LAYER_WMS_OVERLAYS[layerName] && map.hasLayer(LAYER_WMS_OVERLAYS[layerName])) {{
              map.removeLayer(LAYER_WMS_OVERLAYS[layerName]);
            }}
          }}
        }} finally {{
          IS_SYNCING_MAP_LAYERS -= 1;
        }}
      }}
      if (layerControl && typeof layerControl._update === 'function') layerControl._update();
      syncLeafletLayerControlActions();
      scheduleMapRender({{ skipAutoZoom: true }});
    }}

    function syncLeafletLayerControlActions() {{
      if (!layerControl || typeof layerControl.getContainer !== 'function') return;
      const lc = layerControl.getContainer();
      if (!lc || typeof lc.querySelectorAll !== 'function') return;
      const labels = lc.querySelectorAll('.leaflet-control-layers-overlays label');
      if (!labels || typeof labels.forEach !== 'function') return;
      labels.forEach(lbl => {{
        const prevBtn = lbl.querySelector ? lbl.querySelector('.leaflet-layer-remove-btn') : null;
        if (prevBtn && typeof prevBtn.remove === 'function') prevBtn.remove();
        const span = lbl.querySelector ? lbl.querySelector('span') : null;
        const lname = span ? String(span.textContent || '').trim() : '';
        if (!lname || !DYNAMIC_ADDED_LAYERS.has(lname)) return;
        if (lbl.style) {{
          lbl.style.display = 'flex';
          lbl.style.alignItems = 'center';
          lbl.style.justifyContent = 'space-between';
          lbl.style.gap = '6px';
        }}
        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.className = 'leaflet-layer-remove-btn';
        rmBtn.title = t('html_remove_layer');
        rmBtn.textContent = '×';
        rmBtn.onclick = ev => {{
          if (ev && ev.preventDefault) ev.preventDefault();
          if (ev && ev.stopPropagation) ev.stopPropagation();
          removeDynamicMapLayer(lname);
        }};
        lbl.appendChild(rmBtn);
      }});
    }}

    function removeDynamicMapLayer(layerName, skipRender) {{
      if (!layerName || !DYNAMIC_ADDED_LAYERS.has(layerName)) return;
      DYNAMIC_ADDED_LAYERS.delete(layerName);
      const grp = LAYER_OVERLAYS[layerName];
      const wms = LAYER_WMS_OVERLAYS[layerName];
      IS_SYNCING_MAP_LAYERS += 1;
      try {{
        if (grp) {{
          if (map && typeof map.hasLayer === 'function' && map.hasLayer(grp)) map.removeLayer(grp);
          if (layerControl && typeof layerControl.removeLayer === 'function') layerControl.removeLayer(grp);
        }}
        if (wms) {{
          if (map && typeof map.hasLayer === 'function' && map.hasLayer(wms)) map.removeLayer(wms);
          if (layerControl && typeof layerControl.removeLayer === 'function') layerControl.removeLayer(wms);
        }}
      }} finally {{
        IS_SYNCING_MAP_LAYERS -= 1;
      }}
      delete LAYER_OVERLAYS[layerName];
      delete LAYER_WMS_OVERLAYS[layerName];
      delete LAYER_RECORDS[layerName];
      delete LAYER_GEOMETRIES[layerName];
      delete LAYER_GEOM_BBOXES[layerName];
      delete LAYER_GEOM_TYPES[layerName];
      delete LAYER_GEOM_LOD[layerName];
      delete LAYER_STATS[layerName];
      delete LAYER_PYRAMID_LOD1[layerName];
      delete VECTOR_PYRAMIDS[layerName];
      delete MAP_LAYER_VISIBILITY[layerName];
      delete LAYER_LAST_MISSING_KEY[layerName];
      delete _RECORD_BBOX_INDEX[layerName];
      delete _RECORD_BBOX_INDEX['__rec__' + layerName];
      const cooldownPrefix = `${{layerName}}|`;
      Object.keys(LAYER_FETCH_COOLDOWN).forEach(k => {{
        if (k.startsWith(cooldownPrefix)) delete LAYER_FETCH_COOLDOWN[k];
      }});
      if (Array.isArray(BUNDLE.ogc_services)) {{
        BUNDLE.ogc_services = BUNDLE.ogc_services.filter(s => s && s.name !== layerName);
      }}
      if (Array.isArray(CUSTOM_MAP_LAYERS)) {{
        CUSTOM_MAP_LAYERS = CUSTOM_MAP_LAYERS.filter(n => n !== layerName);
      }}
      const mapWidget = getActiveMapWidget();
      if (mapWidget && Array.isArray(mapWidget.map_layers)) {{
        mapWidget.map_layers = mapWidget.map_layers.filter(n => n !== layerName);
      }}
      Object.entries(ACTIVE_FILTERS).forEach(([k, flt]) => {{
        if (flt && flt.layer_name === layerName) delete ACTIVE_FILTERS[k];
      }});
      if (layerControl && typeof layerControl._update === 'function') layerControl._update();
      syncLeafletLayerControlActions();
      renderMapLayersDrawer();
      if (!skipRender) {{
        buildSlicers();
        renderAll({{ skipAutoZoom: true }});
      }}
    }}

    function resetDashboardToHome() {{
      if (VIEWPORT_REFRESH_TIMER) {{
        clearTimeout(VIEWPORT_REFRESH_TIMER);
        VIEWPORT_REFRESH_TIMER = null;
      }}
      Array.from(DYNAMIC_ADDED_LAYERS).forEach(ln => removeDynamicMapLayer(ln, true));
      BUNDLE.ogc_services = JSON.parse(JSON.stringify(INITIAL_OGC_SERVICES));
      Object.keys(ACTIVE_FILTERS).forEach(k => delete ACTIVE_FILTERS[k]);
      LAST_INTERACTED_FILTER_SOURCE = null;
      EXTENT_FILTER_ENABLED = false;
      clearDashboardSessionState();
      updateExtentButtonUI();
      clearAddressSearchResult();

      ACTIVE_PAGE_ID = DEFAULT_PAGE_ID;
      Object.keys(MAP_WIDGET_STATES).forEach(k => delete MAP_WIDGET_STATES[k]);
      ACTIVE_MAP_STATE_KEY = '';
      const mapWidget = getActiveMapWidget();
      const rstState = _activateMapWidgetState(mapWidget);
      ACTIVE_STYLE_LAYER = '';
      _clearPreviewWmsRunOverlays();
      syncActiveMapLayersAndControl(rstState, {{ applyViewport: false }});

      if (map && HYBRID_LAYER_REF) {{
        IS_SYNCING_MAP_LAYERS += 1;
        try {{
          if (INITIAL_HYBRID_ENABLED && !map.hasLayer(HYBRID_LAYER_REF)) HYBRID_LAYER_REF.addTo(map);
          else if (!INITIAL_HYBRID_ENABLED && map.hasLayer(HYBRID_LAYER_REF)) map.removeLayer(HYBRID_LAYER_REF);
        }} finally {{
          IS_SYNCING_MAP_LAYERS -= 1;
        }}
        if (layerControl && typeof layerControl._update === 'function') layerControl._update();
      }}
      MAP_WINDOW_MODE = 'normal';
      AUTO_HOME_ON_FILTER_CLEAR = (DASHBOARD && DASHBOARD.auto_home_on_filter_clear !== false);
      _PREV_ACTIVE_FILTER_COUNT = 0;
      const chkAutoReset = document.getElementById('chk-opt-autohome');
      if (chkAutoReset) chkAutoReset.checked = Boolean(AUTO_HOME_ON_FILTER_CLEAR);
      if (typeof syncMapWindowButtons === 'function') syncMapWindowButtons();
      applyArtboardLayout();
      syncLeafletLayerControlActions();
      resetMapHomeView();
      renderMapLayersDrawer();
      renderPagesBar();
      renderActiveFiltersBanner();
      buildSlicers();
      if (typeof closeRefreshScopeMenu === 'function') closeRefreshScopeMenu();
      const lsmRst = document.getElementById('live-status-menu');
      if (lsmRst) lsmRst.style.display = 'none';
      if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
      triggerRenderWithBusyFeedback({{ skipAutoZoom: true, skipAutoHome: true }});
    }}

    function reorderMapLayerDrag(srcName, targetName) {{
      if (!srcName || !targetName || srcName === targetName) return;
      const order = ensureCustomMapLayerOrder().slice();
      const fromIdx = order.indexOf(srcName);
      const toIdx = order.indexOf(targetName);
      if (fromIdx < 0 || toIdx < 0) return;
      order.splice(fromIdx, 1);
      order.splice(toIdx, 0, srcName);
      CUSTOM_MAP_LAYERS = order.slice();
      const mapWidget = getActiveMapWidget();
      if (mapWidget) {{
        mapWidget.map_layers = CUSTOM_MAP_LAYERS.slice();
        mapWidget.map_layers_custom_order = true;
      }}
      renderMapLayersDrawer();
      scheduleMapRender({{ skipAutoZoom: true }});
    }}

    const _LABEL_ONLY_STYLE_KEYS = new Set([
      'label_field', 'label_fields', 'label_size', 'label_color',
      'label_halo', 'label_halo_opacity', 'label_multi_row',
      'label_position', 'label_min_zoom'
    ]);

    function setLocalLayerStyle(layerName, patch) {{
      if (!layerName) return;
      const pObj = patch || {{}};
      LOCAL_LAYER_STYLES[layerName] = Object.assign({{}}, LOCAL_LAYER_STYLES[layerName] || {{}}, pObj);
      const mapWidget = getActiveMapWidget();
      if (mapWidget) {{
        mapWidget.map_layer_styles = mapWidget.map_layer_styles || {{}};
        mapWidget.map_layer_styles[layerName] = Object.assign({{}}, mapWidget.map_layer_styles[layerName] || {{}}, LOCAL_LAYER_STYLES[layerName]);
      }}
      const patchKeys = Object.keys(pObj);
      const isLabelOnly = patchKeys.length > 0 && patchKeys.every(k => _LABEL_ONLY_STYLE_KEYS.has(k));
      if (isLabelOnly && LAYER_RENDERED_FEATURES[layerName] && typeof renderMapFeatureLabels === 'function') {{
        renderMapFeatureLabels();
        return;
      }}
      updateMapLegend();
      scheduleMapRender({{ skipAutoZoom: true }});
    }}

    function renderMapLayersDrawer() {{
      const drawer = document.getElementById('map-layers-drawer');
      if (!drawer) return;
      const order = orderedMapLayerNames();
      if (!ACTIVE_STYLE_LAYER || !order.includes(ACTIVE_STYLE_LAYER)) {{
        ACTIVE_STYLE_LAYER = order[0] || '';
      }}
      drawer.innerHTML = '';

      const hdr = document.createElement('div');
      hdr.className = 'layers-drawer-hdr';
      const hdrTitle = document.createElement('span');
      hdrTitle.textContent = t('map_layers_title');
      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'btn-mini-icon';
      closeBtn.textContent = '✕';
      closeBtn.title = t('close_btn') || 'Close';
      closeBtn.onclick = ev => {{
        if (ev && ev.stopPropagation) ev.stopPropagation();
        drawer.style.display = 'none';
      }};
      hdr.appendChild(hdrTitle);
      hdr.appendChild(closeBtn);
      drawer.appendChild(hdr);

      const grid = document.createElement('div');
      grid.className = 'layers-drawer-grid';
      const leftPane = document.createElement('div');
      leftPane.className = 'layers-drawer-left';
      const rightPane = document.createElement('div');
      rightPane.className = 'layers-drawer-right';
      grid.appendChild(leftPane);
      grid.appendChild(rightPane);
      drawer.appendChild(grid);

      const hint = document.createElement('div');
      hint.className = 'map-layers-hint';
      hint.textContent = t('map_layers_order_short');
      leftPane.appendChild(hint);

      order.forEach((ln, idx) => {{
        const row = document.createElement('div');
        row.className = 'map-layer-row' + (ACTIVE_STYLE_LAYER === ln ? ' active-style-layer' : '');
        row.dataset.layerName = ln;
        row.draggable = true;
        row.ondragstart = ev => {{
          DRAG_LAYER_NAME = ln;
          row.classList.add('dragging');
          if (ev && ev.dataTransfer) {{
            ev.dataTransfer.effectAllowed = 'move';
            ev.dataTransfer.setData('text/plain', ln);
          }}
        }};
        row.ondragover = ev => {{
          if (ev && ev.preventDefault) ev.preventDefault();
          row.classList.add('drag-over');
        }};
        row.ondragleave = () => row.classList.remove('drag-over');
        row.ondrop = ev => {{
          if (ev && ev.preventDefault) ev.preventDefault();
          row.classList.remove('drag-over');
          const src = DRAG_LAYER_NAME || (ev && ev.dataTransfer && ev.dataTransfer.getData('text/plain')) || '';
          DRAG_LAYER_NAME = '';
          reorderMapLayerDrag(src, ln);
        }};
        row.ondragend = () => {{
          DRAG_LAYER_NAME = '';
          row.classList.remove('dragging');
          drawer.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
        }};

        const lbl = document.createElement('label');
        const dragGrip = document.createElement('span');
        dragGrip.textContent = '⋮⋮';
        dragGrip.style.opacity = '0.55';
        dragGrip.style.cursor = 'grab';
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.autocomplete = 'off';
        cb.checked = MAP_LAYER_VISIBILITY[ln] !== false;
        cb.onchange = () => toggleMapLayerVisible(ln, cb.checked);
        const span = document.createElement('span');
        const lyrCfg = getMapLayerStyleCfg(ln);
        const lyrMinZ = (lyrCfg && Number(lyrCfg.min_zoom) > 0) ? Number(lyrCfg.min_zoom) : 0;
        span.textContent = lyrMinZ > 0 ? `${{ln}} (Z≥${{lyrMinZ}})` : ln;
        span.onclick = ev => {{
          if (ev && ev.preventDefault) ev.preventDefault();
          if (ev && ev.stopPropagation) ev.stopPropagation();
          ACTIVE_STYLE_LAYER = ln;
          renderMapLayersDrawer();
        }};
        lbl.appendChild(dragGrip);
        lbl.appendChild(cb);
        lbl.appendChild(span);

        const btns = document.createElement('div');
        btns.className = 'map-layer-order-btns';
        const styleBtn = document.createElement('button');
        styleBtn.type = 'button';
        styleBtn.textContent = '🎨';
        styleBtn.title = t('layer_style_btn');
        if (ACTIVE_STYLE_LAYER === ln) styleBtn.classList.add('active');
        styleBtn.onclick = ev => {{
          if (ev && ev.stopPropagation) ev.stopPropagation();
          ACTIVE_STYLE_LAYER = ln;
          renderMapLayersDrawer();
        }};
        btns.appendChild(styleBtn);

        const upBtn = document.createElement('button');
        upBtn.type = 'button';
        upBtn.textContent = '↑';
        upBtn.disabled = idx === 0;
        upBtn.onclick = ev => {{
          if (ev && ev.stopPropagation) ev.stopPropagation();
          moveMapLayerOrder(ln, -1);
        }};
        const dnBtn = document.createElement('button');
        dnBtn.type = 'button';
        dnBtn.textContent = '↓';
        dnBtn.disabled = idx === order.length - 1;
        dnBtn.onclick = ev => {{
          if (ev && ev.stopPropagation) ev.stopPropagation();
          moveMapLayerOrder(ln, 1);
        }};
        btns.appendChild(upBtn);
        btns.appendChild(dnBtn);
        if (DYNAMIC_ADDED_LAYERS.has(ln)) {{
          const rmBtn = document.createElement('button');
          rmBtn.type = 'button';
          rmBtn.className = 'remove-btn';
          rmBtn.textContent = '×';
          rmBtn.title = t('html_remove_layer');
          rmBtn.onclick = ev => {{
            if (ev && ev.stopPropagation) ev.stopPropagation();
            removeDynamicMapLayer(ln);
          }};
          btns.appendChild(rmBtn);
        }}

        row.appendChild(lbl);
        row.appendChild(btns);
        leftPane.appendChild(row);
      }});

      if (ACTIVE_STYLE_LAYER && (LAYER_RECORDS[ACTIVE_STYLE_LAYER] || LAYER_OVERLAYS[ACTIVE_STYLE_LAYER])) {{
        const ln = ACTIVE_STYLE_LAYER;
        const spec = getEffectiveLayerStyleSpec(ln);
        const custom = spec.custom || {{}};
        const svc = (BUNDLE.ogc_services || []).find(s => s.name === ln);
        const curFill = custom.color || defaultUniformColor(ln, custom, svc) || '#10b981';
        const curBorder = custom.border_color || curFill;
        const curOp = custom.opacity !== undefined ? Math.round(Number(custom.opacity) * 100) : 42;
        const curW = custom.stroke_width !== undefined ? Number(custom.stroke_width) : 1.5;
        const curField = (spec.styleFields && spec.styleFields[0]) || '';
        const sampleRow = (LAYER_RECORDS[ln] || [])[0] || {{}};
        const flds = Object.keys(sampleRow).filter(k => !k.startsWith('_'));

        const tabBar = document.createElement('div');
        tabBar.className = 'layer-style-tabs';
        const styleTabBtn = document.createElement('button');
        styleTabBtn.type = 'button';
        styleTabBtn.className = 'layer-style-tab-btn' + (ACTIVE_LAYER_STYLE_TAB !== 'labels' ? ' active' : '');
        styleTabBtn.dataset.layerTab = 'style';
        styleTabBtn.textContent = t('tab_layer_style');
        styleTabBtn.onclick = ev => {{
          if (ev && ev.stopPropagation) ev.stopPropagation();
          ACTIVE_LAYER_STYLE_TAB = 'style';
          renderMapLayersDrawer();
        }};
        const labelsTabBtn = document.createElement('button');
        labelsTabBtn.type = 'button';
        labelsTabBtn.className = 'layer-style-tab-btn' + (ACTIVE_LAYER_STYLE_TAB === 'labels' ? ' active' : '');
        labelsTabBtn.dataset.layerTab = 'labels';
        labelsTabBtn.textContent = t('tab_layer_labels');
        labelsTabBtn.onclick = ev => {{
          if (ev && ev.stopPropagation) ev.stopPropagation();
          ACTIVE_LAYER_STYLE_TAB = 'labels';
          renderMapLayersDrawer();
        }};
        const activeNameTag = document.createElement('span');
        activeNameTag.style.cssText = 'margin-left:auto;font-size:0.75rem;font-weight:700;opacity:0.8;align-self:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:150px;';
        activeNameTag.textContent = ln;
        activeNameTag.title = ln;
        tabBar.appendChild(styleTabBtn);
        tabBar.appendChild(labelsTabBtn);
        tabBar.appendChild(activeNameTag);
        rightPane.appendChild(tabBar);

        const panel = document.createElement('div');
        panel.id = 'map-layer-style-panel';
        panel.className = 'style-panel-grid';

        const addGridRow = (labelText, tipText, ctrlEl) => {{
          const lEl = document.createElement('label');
          lEl.style.fontSize = '0.76rem';
          lEl.textContent = labelText;
          if (tipText) lEl.title = tipText;
          panel.appendChild(lEl);
          panel.appendChild(ctrlEl);
        }};

        if (ACTIVE_LAYER_STYLE_TAB !== 'labels') {{
          const fillIn = document.createElement('input');
          fillIn.type = 'color';
          fillIn.value = /^#[0-9a-f]{{6}}$/i.test(curFill) ? curFill : '#10b981';
          fillIn.title = t('tip_style_fill');
          fillIn.oninput = () => setLocalLayerStyle(ln, {{ color: fillIn.value }});
          addGridRow(t('style_fill'), t('tip_style_fill'), fillIn);

          const opWrap = document.createElement('div');
          opWrap.style.cssText = 'display:flex;align-items:center;gap:6px;';
          const opIn = document.createElement('input');
          opIn.type = 'range'; opIn.min = '0'; opIn.max = '100'; opIn.value = String(curOp);
          opIn.style.flex = '1';
          opIn.title = t('tip_style_opacity');
          const opChip = document.createElement('span');
          opChip.className = 'style-val-chip';
          opChip.textContent = `${{curOp}}%`;
          opIn.oninput = () => {{
            opChip.textContent = `${{opIn.value}}%`;
            setLocalLayerStyle(ln, {{ opacity: Number(opIn.value) / 100.0 }});
          }};
          opWrap.appendChild(opIn);
          opWrap.appendChild(opChip);
          addGridRow(t('style_opacity'), t('tip_style_opacity'), opWrap);

          const brdIn = document.createElement('input');
          brdIn.type = 'color';
          brdIn.value = /^#[0-9a-f]{{6}}$/i.test(curBorder) ? curBorder : '#10b981';
          brdIn.title = t('tip_style_border');
          brdIn.oninput = () => setLocalLayerStyle(ln, {{ border_color: brdIn.value }});
          addGridRow(t('style_border'), t('tip_style_border'), brdIn);

          const wIn = document.createElement('input');
          wIn.type = 'number'; wIn.min = '0'; wIn.max = '6'; wIn.step = '0.5'; wIn.value = String(curW);
          wIn.title = t('tip_style_width');
          wIn.onchange = () => setLocalLayerStyle(ln, {{ stroke_width: Number(wIn.value) }});
          addGridRow(t('style_width'), t('tip_style_width'), wIn);

          const mzIn = document.createElement('input');
          mzIn.type = 'number'; mzIn.min = '0'; mzIn.max = '14'; mzIn.step = '1';
          mzIn.value = String(Math.max(0, Math.min(14, Number(custom.min_zoom || 0))));
          mzIn.title = t('tip_style_min_zoom');
          mzIn.onchange = () => setLocalLayerStyle(ln, {{ min_zoom: Math.max(0, Math.min(14, Number(mzIn.value) || 0)) }});
          addGridRow(t('style_min_zoom'), t('tip_style_min_zoom'), mzIn);

          const catSel = document.createElement('select');
          catSel.title = t('tip_style_categorized');
          const noneOpt = document.createElement('option');
          noneOpt.value = ''; noneOpt.textContent = '— ' + t('style_single') + ' —';
          catSel.appendChild(noneOpt);
          flds.forEach(fn => {{
            const o = document.createElement('option');
            o.value = fn; o.textContent = fn;
            catSel.appendChild(o);
          }});
          catSel.value = curField;
          catSel.onchange = () => setLocalLayerStyle(ln, {{
            style_mode: catSel.value ? 'categorized' : 'single',
            style_field: catSel.value
          }});
          addGridRow(t('style_categorized'), t('tip_style_categorized'), catSel);

          const outLbl = document.createElement('label');
          outLbl.style.cssText = 'grid-column:1 / -1;display:flex;align-items:center;gap:6px;font-size:0.76rem;cursor:pointer;';
          outLbl.title = t('tip_style_outline_only');
          const outCb = document.createElement('input');
          outCb.type = 'checkbox';
          outCb.checked = Boolean(custom.outline_only);
          outCb.onchange = () => setLocalLayerStyle(ln, {{ outline_only: outCb.checked }});
          outLbl.appendChild(outCb);
          outLbl.appendChild(document.createTextNode(t('style_outline_only')));
          panel.appendChild(outLbl);
        }} else {{
          const curFields = Array.isArray(spec.labelFields) ? spec.labelFields.slice(0, 4) : (spec.labelField ? [spec.labelField] : []);
          const slotCount = Math.max(2, Math.min(4, Math.max(curFields.length, Number(EXTRA_LABEL_SLOTS[ln] || 2))));
          EXTRA_LABEL_SLOTS[ln] = slotCount;
          const slotVals = [];
          for (let i = 0; i < slotCount; i++) slotVals.push(curFields[i] || '');
          const commitSlots = () => {{
            const cleaned = slotVals.map(v => String(v || '').trim()).filter(Boolean);
            setLocalLayerStyle(ln, {{ label_fields: cleaned, label_field: cleaned[0] || '' }});
          }};

          for (let sIdx = 0; sIdx < slotCount; sIdx++) {{
            const lblKey = sIdx === 0 ? t('lbl_label_field_1') : (sIdx === 1 ? t('lbl_label_field_2') : t('lbl_label_field_extra', {{ n: sIdx + 1 }}));
            const sel = document.createElement('select');
            sel.title = t('tip_label_field');
            const emptyOpt = document.createElement('option');
            emptyOpt.value = '';
            emptyOpt.textContent = sIdx === 0 ? t('lbl_no_labels') : '—';
            sel.appendChild(emptyOpt);
            flds.forEach(fn => {{
              const o = document.createElement('option');
              o.value = fn; o.textContent = fn;
              sel.appendChild(o);
            }});
            sel.value = slotVals[sIdx] || '';
            sel.onchange = () => {{
              slotVals[sIdx] = sel.value;
              commitSlots();
            }};
            if (sIdx >= 2) {{
              const rowWrap = document.createElement('div');
              rowWrap.style.cssText = 'display:flex;align-items:center;gap:4px;';
              sel.style.flex = '1';
              const rmFld = document.createElement('button');
              rmFld.type = 'button';
              rmFld.className = 'btn-mini-icon';
              rmFld.textContent = '✕';
              rmFld.onclick = ev => {{
                if (ev && ev.stopPropagation) ev.stopPropagation();
                slotVals.splice(sIdx, 1);
                EXTRA_LABEL_SLOTS[ln] = Math.max(2, slotCount - 1);
                commitSlots();
                renderMapLayersDrawer();
              }};
              rowWrap.appendChild(sel);
              rowWrap.appendChild(rmFld);
              addGridRow(lblKey, t('tip_label_field'), rowWrap);
            }} else {{
              addGridRow(lblKey, t('tip_label_field'), sel);
            }}
          }}

          if (slotCount < 4) {{
            const addBtnWrap = document.createElement('div');
            addBtnWrap.style.cssText = 'grid-column:1 / -1;display:flex;justify-content:flex-start;';
            const addFldBtn = document.createElement('button');
            addFldBtn.type = 'button';
            addFldBtn.className = 'btn-mini-icon';
            addFldBtn.id = 'btn-add-label-field';
            addFldBtn.textContent = t('btn_add_label_field');
            addFldBtn.onclick = ev => {{
              if (ev && ev.stopPropagation) ev.stopPropagation();
              EXTRA_LABEL_SLOTS[ln] = Math.min(4, slotCount + 1);
              renderMapLayersDrawer();
            }};
            addBtnWrap.appendChild(addFldBtn);
            panel.appendChild(addBtnWrap);
          }}

          const lblSzIn = document.createElement('input');
          lblSzIn.type = 'number'; lblSzIn.min = '3'; lblSzIn.max = '24';
          lblSzIn.id = 'inp-layer-label-size';
          lblSzIn.value = String(Math.max(3, Math.min(24, Number(spec.labelSize || 10))));
          lblSzIn.title = t('tip_label_size');
          const applyLblSz = () => setLocalLayerStyle(ln, {{ label_size: Math.max(3, Math.min(24, Number(lblSzIn.value) || 10)) }});
          lblSzIn.oninput = applyLblSz;
          lblSzIn.onchange = applyLblSz;
          addGridRow(t('lbl_label_size'), t('tip_label_size'), lblSzIn);

          const lblColIn = document.createElement('input');
          lblColIn.type = 'color';
          lblColIn.value = /^#[0-9a-f]{{6}}$/i.test(spec.labelColor || '') ? spec.labelColor : '#0f172a';
          lblColIn.title = t('tip_label_color');
          lblColIn.oninput = () => setLocalLayerStyle(ln, {{ label_color: lblColIn.value }});
          addGridRow(t('lbl_label_color'), t('tip_label_color'), lblColIn);

          const curHaloOp = Math.max(0, Math.min(100, Number(spec.labelHaloOpacity !== undefined ? spec.labelHaloOpacity : 90)));
          const haloWrap = document.createElement('div');
          haloWrap.style.cssText = 'display:flex;align-items:center;gap:6px;';
          const haloIn = document.createElement('input');
          haloIn.type = 'range'; haloIn.min = '0'; haloIn.max = '100'; haloIn.value = String(curHaloOp);
          haloIn.id = 'rng-layer-halo-opacity';
          haloIn.style.flex = '1';
          haloIn.title = t('tip_label_halo');
          const haloChip = document.createElement('span');
          haloChip.className = 'style-val-chip';
          haloChip.textContent = `${{curHaloOp}}%`;
          haloIn.oninput = () => {{
            const v = Math.max(0, Math.min(100, Number(haloIn.value) || 0));
            haloChip.textContent = `${{v}}%`;
            setLocalLayerStyle(ln, {{ label_halo_opacity: v, label_halo: v > 0 }});
          }};
          haloWrap.appendChild(haloIn);
          haloWrap.appendChild(haloChip);
          addGridRow(t('lbl_halo_opacity'), t('tip_label_halo'), haloWrap);

          const posSel = document.createElement('select');
          posSel.title = t('tip_label_position');
          [
            ['center', t('lbl_pos_center')],
            ['outside_line', t('lbl_pos_outside_line')],
            ['outside_callout', t('lbl_pos_outside_callout')]
          ].forEach(([val, txt]) => {{
            const o = document.createElement('option');
            o.value = val; o.textContent = txt;
            posSel.appendChild(o);
          }});
          posSel.value = spec.labelPosition || 'center';
          posSel.onchange = () => setLocalLayerStyle(ln, {{ label_position: posSel.value }});
          addGridRow(t('lbl_label_position'), t('tip_label_position'), posSel);

          const lzIn = document.createElement('input');
          lzIn.type = 'number'; lzIn.min = '0'; lzIn.max = '18'; lzIn.value = String(spec.labelMinZoom || 0);
          lzIn.title = t('tip_label_min_zoom');
          const applyLblZoom = () => setLocalLayerStyle(ln, {{ label_min_zoom: Math.max(0, Math.min(18, Number(lzIn.value) || 0)) }});
          lzIn.oninput = applyLblZoom;
          lzIn.onchange = applyLblZoom;
          addGridRow('Z≥', t('tip_label_min_zoom'), lzIn);
        }}

        rightPane.appendChild(panel);
      }}
    }}

    function _wrapLabelTextLines(text, maxChars) {{
      const s = String(text || '').trim();
      if (!s) return '';
      if (s.includes('|') || s.includes('\\n')) {{
        return s.split(/\\||\\r?\\n/).map(p => p.trim()).filter(Boolean).join('\\n');
      }}
      const words = s.split(/\\s+/);
      const lines = [];
      let cur = '';
      const limit = Math.max(10, Number(maxChars || 18));
      for (let i = 0; i < words.length; i++) {{
        const w = words[i];
        if (!cur) cur = w;
        else if ((cur.length + 1 + w.length) <= limit) cur += ' ' + w;
        else {{ lines.push(cur); cur = w; }}
      }}
      if (cur) lines.push(cur);
      return lines.join('\\n');
    }}

    let _LABEL_MEASURE_CTX = null;

    function _measureLabelDimensions(lines, fontSize, isBox) {{
      const fSize = Math.max(3, Math.min(24, Number(fontSize || 10)));
      const lineH = Math.round(fSize * 1.2);
      if (!_LABEL_MEASURE_CTX && typeof document !== 'undefined' && typeof document.createElement === 'function') {{
        try {{
          const c = document.createElement('canvas');
          _LABEL_MEASURE_CTX = c.getContext ? c.getContext('2d') : null;
        }} catch (_e) {{}}
      }}
      let maxW = 16;
      if (_LABEL_MEASURE_CTX) {{
        _LABEL_MEASURE_CTX.font = `bold ${{fSize}}px 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif`;
        for (let i = 0; i < lines.length; i++) {{
          const w = _LABEL_MEASURE_CTX.measureText(String(lines[i] || '')).width;
          if (w > maxW) maxW = w;
        }}
      }} else {{
        for (let i = 0; i < lines.length; i++) {{
          const w = String(lines[i] || '').length * fSize * 0.62;
          if (w > maxW) maxW = w;
        }}
      }}
      const padX = isBox ? 12 : 6;
      const padY = isBox ? 6 : 2;
      return {{
        w: Math.ceil(maxW) + padX,
        h: Math.ceil(lines.length * lineH) + padY
      }};
    }}

    function _isLightLabelColor(hexStr) {{
      const s = String(hexStr || '').trim();
      const m = /^#([0-9a-f]{{3}}|([0-9a-f]{{6}}))$/i.exec(s);
      if (!m) return false;
      let hex = m[1];
      if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
      const r = parseInt(hex.slice(0, 2), 16) / 255;
      const g = parseInt(hex.slice(2, 4), 16) / 255;
      const b = parseInt(hex.slice(4, 6), 16) / 255;
      return (0.299 * r + 0.587 * g + 0.114 * b) > 0.65;
    }}

    function ensureLabelPanes() {{
      if (!map || typeof map.createPane !== 'function') return null;
      let linesPane = (typeof map.getPane === 'function') ? map.getPane('qdash_label_lines') : null;
      if (!linesPane) {{
        linesPane = map.createPane('qdash_label_lines');
      }}
      if (linesPane) {{
        if (linesPane.style) {{
          linesPane.style.zIndex = '610';
          linesPane.style.pointerEvents = 'none';
        }}
        if (linesPane.classList) linesPane.classList.add('leaflet-zoom-hide');
      }}
      let labelsPane = (typeof map.getPane === 'function') ? map.getPane('qdash_labels') : null;
      if (!labelsPane) {{
        labelsPane = map.createPane('qdash_labels');
      }}
      if (labelsPane) {{
        if (labelsPane.style) {{
          labelsPane.style.zIndex = '620';
          labelsPane.style.pointerEvents = 'none';
        }}
        if (labelsPane.classList) labelsPane.classList.add('leaflet-zoom-hide');
      }}
      return {{ linesPane, labelsPane }};
    }}

    function _ringBboxLonLat(ring) {{
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (let i = 0; i < ring.length; i++) {{
        const c = ring[i];
        if (!c || c.length < 2) continue;
        const x = Number(c[0]), y = Number(c[1]);
        if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }}
      return (minX <= maxX && minY <= maxY) ? [minX, minY, maxX, maxY] : null;
    }}

    function _pickVisibleFeatureGeometryPart(geom, viewBb) {{
      if (!geom || !geom.type) return null;
      const t = String(geom.type);
      const coords = geom.coordinates;
      if (!coords) return null;
      if (t === 'Point') {{
        return (Array.isArray(coords) && coords.length >= 2) ? {{ kind: 'point', coords }} : null;
      }}
      if (t === 'MultiPoint' && Array.isArray(coords) && coords.length) {{
        for (let i = 0; i < coords.length; i++) {{
          const pt = coords[i];
          if (!pt || pt.length < 2) continue;
          if (!viewBb || (pt[0] >= viewBb[0] && pt[0] <= viewBb[2] && pt[1] >= viewBb[1] && pt[1] <= viewBb[3])) {{
            return {{ kind: 'point', coords: pt }};
          }}
        }}
        return {{ kind: 'point', coords: coords[0] }};
      }}
      if (t === 'Polygon' && Array.isArray(coords[0]) && coords[0].length >= 3) {{
        return {{ kind: 'poly', coords: coords[0] }};
      }}
      if (t === 'MultiPolygon' && Array.isArray(coords) && coords.length) {{
        let best = null;
        let bestArea = -1;
        let fallback = null;
        let fbArea = -1;
        for (let i = 0; i < coords.length; i++) {{
          const ring = coords[i] && coords[i][0];
          if (!Array.isArray(ring) || ring.length < 3) continue;
          const bb = _ringBboxLonLat(ring);
          if (!bb) continue;
          const area = Math.max(0, (bb[2] - bb[0]) * (bb[3] - bb[1]));
          if (area > fbArea) {{ fbArea = area; fallback = ring; }}
          if (!viewBb || bboxIntersects(bb, viewBb)) {{
            if (area > bestArea) {{ bestArea = area; best = ring; }}
          }}
        }}
        const chosen = best || fallback;
        return chosen ? {{ kind: 'poly', coords: chosen }} : null;
      }}
      if (t === 'LineString' && Array.isArray(coords) && coords.length >= 2) {{
        return {{ kind: 'line', coords }};
      }}
      if (t === 'MultiLineString' && Array.isArray(coords) && coords.length) {{
        let best = null;
        let bestSpan = -1;
        for (let i = 0; i < coords.length; i++) {{
          const ln = coords[i];
          if (!Array.isArray(ln) || ln.length < 2) continue;
          const bb = _ringBboxLonLat(ln);
          if (!bb) continue;
          if (viewBb && !bboxIntersects(bb, viewBb)) continue;
          const sp = Math.hypot(bb[2] - bb[0], bb[3] - bb[1]);
          if (sp > bestSpan) {{ bestSpan = sp; best = ln; }}
        }}
        const chosen = best || coords[0];
        return (Array.isArray(chosen) && chosen.length >= 2) ? {{ kind: 'line', coords: chosen }} : null;
      }}
      return null;
    }}

    function _ptInPolyScreen(px, py, pts) {{
      let inside = false;
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {{
        const xi = pts[i].x, yi = pts[i].y;
        const xj = pts[j].x, yj = pts[j].y;
        const intersect = ((yi > py) !== (yj > py)) && (px < ((xj - xi) * (py - yi)) / ((yj - yi) || 1e-9) + xi);
        if (intersect) inside = !inside;
      }}
      return inside;
    }}

    function _scanlineHorizontalSpans(pts, yVal) {{
      const xs = [];
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {{
        const y1 = pts[j].y, y2 = pts[i].y;
        if ((y1 <= yVal && y2 > yVal) || (y2 <= yVal && y1 > yVal)) {{
          const x = pts[j].x + ((yVal - y1) / ((y2 - y1) || 1e-9)) * (pts[i].x - pts[j].x);
          xs.push(x);
        }}
      }}
      xs.sort((a, b) => a - b);
      return xs;
    }}

    function _scanlineVerticalSpans(pts, xVal) {{
      const ys = [];
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {{
        const x1 = pts[j].x, x2 = pts[i].x;
        if ((x1 <= xVal && x2 > xVal) || (x2 <= xVal && x1 > xVal)) {{
          const y = pts[j].y + ((xVal - x1) / ((x2 - x1) || 1e-9)) * (pts[i].y - pts[j].y);
          ys.push(y);
        }}
      }}
      ys.sort((a, b) => a - b);
      return ys;
    }}

    function _computeScreenFeatureMetrics(item, viewBb, mapW, mapH) {{
      if (!item || !map || typeof map.latLngToContainerPoint !== 'function') return null;
      const props = item.props || {{}};
      let bb = (Array.isArray(props._bbox) && props._bbox.length === 4) ? props._bbox : null;
      if (!bb && item.geom && typeof geomBbox === 'function') bb = geomBbox(item.geom);
      if (bb && viewBb && !bboxIntersects(bb, viewBb)) return null;

      let part = item.geom ? _pickVisibleFeatureGeometryPart(item.geom, viewBb) : null;
      if (!part && Number.isFinite(Number(item.lat)) && Number.isFinite(Number(item.lon))) {{
        part = {{ kind: 'point', coords: [Number(item.lon), Number(item.lat)] }};
      }}
      if (!part) return null;

      if (part.kind === 'point') {{
        const lon = Number(part.coords[0]), lat = Number(part.coords[1]);
        if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
        if (viewBb && (lon < viewBb[0] || lon > viewBb[2] || lat < viewBb[1] || lat > viewBb[3])) return null;
        const p = map.latLngToContainerPoint([lat, lon]);
        if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.y)) return null;
        if (p.x < -12 || p.x > mapW + 12 || p.y < -12 || p.y > mapH + 12) return null;
        return {{
          kind: 'point',
          pts: null,
          fMinX: p.x - 7, fMinY: p.y - 7, fMaxX: p.x + 7, fMaxY: p.y + 7,
          localMinX: p.x - 7, localMaxX: p.x + 7, localMinY: p.y - 7, localMaxY: p.y + 7,
          ax: p.x, ay: p.y,
          areaPx: 196
        }};
      }}

      const rawCoords = part.coords || [];
      const stride = Math.max(1, Math.floor(rawCoords.length / 110));
      const pts = [];
      let fMinX = Infinity, fMinY = Infinity, fMaxX = -Infinity, fMaxY = -Infinity;
      for (let i = 0; i < rawCoords.length; i += stride) {{
        const c = rawCoords[i];
        if (!c || c.length < 2) continue;
        const cp = map.latLngToContainerPoint([Number(c[1]), Number(c[0])]);
        if (!cp || !Number.isFinite(cp.x) || !Number.isFinite(cp.y)) continue;
        pts.push({{ x: cp.x, y: cp.y }});
        if (cp.x < fMinX) fMinX = cp.x;
        if (cp.x > fMaxX) fMaxX = cp.x;
        if (cp.y < fMinY) fMinY = cp.y;
        if (cp.y > fMaxY) fMaxY = cp.y;
      }}
      if (pts.length < 2 || fMaxX < 2 || fMinX > mapW - 2 || fMaxY < 2 || fMinY > mapH - 2) return null;

      if (part.kind === 'line') {{
        const visPts = pts.filter(p => p.x >= 4 && p.x <= mapW - 4 && p.y >= 4 && p.y <= mapH - 4);
        const mid = visPts.length ? visPts[Math.floor(visPts.length / 2)] : pts[Math.floor(pts.length / 2)];
        const spanPx = Math.hypot(fMaxX - fMinX, fMaxY - fMinY);
        return {{
          kind: 'line',
          pts: null,
          fMinX, fMinY, fMaxX, fMaxY,
          localMinX: mid.x - 4, localMaxX: mid.x + 4, localMinY: mid.y - 4, localMaxY: mid.y + 4,
          ax: mid.x, ay: mid.y,
          areaPx: spanPx
        }};
      }}

      // Polygon shoelace area & centroid
      let twiceArea = 0;
      let cxSum = 0;
      let cySum = 0;
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {{
        const cross = pts[j].x * pts[i].y - pts[i].x * pts[j].y;
        twiceArea += cross;
        cxSum += (pts[j].x + pts[i].x) * cross;
        cySum += (pts[j].y + pts[i].y) * cross;
      }}
      const areaPx = Math.abs(twiceArea) * 0.5;
      let ax = (Math.abs(twiceArea) > 1e-3) ? (cxSum / (3 * twiceArea)) : ((fMinX + fMaxX) * 0.5);
      let ay = (Math.abs(twiceArea) > 1e-3) ? (cySum / (3 * twiceArea)) : ((fMinY + fMaxY) * 0.5);

      const inViewAnchor = (ax >= 8 && ax <= mapW - 8 && ay >= 8 && ay <= mapH - 8 && _ptInPolyScreen(ax, ay, pts));
      if (!inViewAnchor) {{
        const cMinY = Math.max(8, fMinY);
        const cMaxY = Math.min(mapH - 8, fMaxY);
        const fracs = [0.5, 0.35, 0.65, 0.2, 0.8];
        let bestSpan = -1;
        for (let fi = 0; fi < fracs.length; fi++) {{
          const yProbe = cMinY + (cMaxY - cMinY) * fracs[fi];
          const xs = _scanlineHorizontalSpans(pts, yProbe);
          for (let si = 0; si + 1 < xs.length; si += 2) {{
            const s0 = Math.max(8, xs[si]);
            const s1 = Math.min(mapW - 8, xs[si + 1]);
            const span = s1 - s0;
            if (span > bestSpan) {{
              bestSpan = span;
              ax = (s0 + s1) * 0.5;
              ay = yProbe;
            }}
          }}
        }}
        if (bestSpan <= 0) {{
          ax = Math.max(8, Math.min(mapW - 8, ax));
          ay = Math.max(8, Math.min(mapH - 8, ay));
        }}
      }}

      const hXs = _scanlineHorizontalSpans(pts, ay);
      const vYs = _scanlineVerticalSpans(pts, ax);
      const localMinX = hXs.length ? hXs[0] : fMinX;
      const localMaxX = hXs.length ? hXs[hXs.length - 1] : fMaxX;
      const localMinY = vYs.length ? vYs[0] : fMinY;
      const localMaxY = vYs.length ? vYs[vYs.length - 1] : fMaxY;

      return {{
        kind: 'poly',
        pts,
        fMinX, fMinY, fMaxX, fMaxY,
        localMinX, localMaxX, localMinY, localMaxY,
        ax, ay,
        areaPx: Math.max(1, areaPx)
      }};
    }}

    function _boxesOverlapPadded(ax0, ay0, ax1, ay1, placedBoxes, pad) {{
      const p = Number(pad || 3);
      for (let i = 0; i < placedBoxes.length; i++) {{
        const b = placedBoxes[i];
        if (ax0 < b[2] + p && ax1 + p > b[0] && ay0 < b[3] + p && ay1 + p > b[1]) return true;
      }}
      return false;
    }}

    function _boxIntersectsPolygonScreen(bx, by, bw, bh, pts) {{
      if (!pts || pts.length < 3) return false;
      const checks = [
        [bx + bw * 0.5, by + bh * 0.5],
        [bx + 1, by + 1],
        [bx + bw - 1, by + 1],
        [bx + 1, by + bh - 1],
        [bx + bw - 1, by + bh - 1]
      ];
      for (let i = 0; i < checks.length; i++) {{
        if (_ptInPolyScreen(checks[i][0], checks[i][1], pts)) return true;
      }}
      return false;
    }}

    function _nearestPointOnBox(px, py, bx, by, bw, bh) {{
      return [
        Math.max(bx, Math.min(px, bx + bw)),
        Math.max(by, Math.min(py, by + bh))
      ];
    }}

    function renderMapFeatureLabels() {{
      ACTIVE_RENDERED_LABELS = [];
      if (!map) return;
      const panes = ensureLabelPanes();
      if (!panes || !panes.linesPane || !panes.labelsPane) return;
      panes.linesPane.innerHTML = '';
      panes.labelsPane.innerHTML = '';

      const mapEl = document.getElementById('map-canvas');
      const mapSize = (typeof map.getSize === 'function') ? map.getSize() : null;
      const mapW = (mapSize && mapSize.x > 10) ? mapSize.x : ((mapEl && mapEl.clientWidth) || 600);
      const mapH = (mapSize && mapSize.y > 10) ? mapSize.y : ((mapEl && mapEl.clientHeight) || 400);
      if (mapW < 20 || mapH < 20) return;

      const mapZoom = (typeof map.getZoom === 'function') ? Number(map.getZoom()) : 7;
      const scaleDenom = computeMapScaleDenominator();
      let viewBb = null;
      if (typeof map.getBounds === 'function') {{
        try {{
          const mb = map.getBounds();
          if (mb && mb.isValid && mb.isValid()) {{
            viewBb = [mb.getWest(), mb.getSouth(), mb.getEast(), mb.getNorth()];
          }}
        }} catch (_vb) {{}}
      }}

      const layerNames = orderedMapLayerNames();
      const candidates = [];
      const viewCx = mapW * 0.5;
      const viewCy = mapH * 0.5;

      layerNames.forEach((ln, layerRank) => {{
        if (MAP_LAYER_VISIBILITY[ln] === false) return;
        if (!isLayerVisibleAtZoom(ln, mapZoom, scaleDenom)) return;
        const spec = getEffectiveLayerStyleSpec(ln);
        const activeLabelFields = (Array.isArray(spec && spec.labelFields) && spec.labelFields.length)
          ? spec.labelFields.map(f => String(f || '').trim()).filter(Boolean)
          : (spec && spec.labelField ? [String(spec.labelField).trim()] : []);
        if (!activeLabelFields.length) return;
        const labelMinZoom = Math.max(0, Number((spec && spec.labelMinZoom) || 0));
        if (mapZoom < labelMinZoom) return;

        const feats = LAYER_RENDERED_FEATURES[ln];
        if (!Array.isArray(feats) || !feats.length) return;

        for (let fi = 0; fi < feats.length; fi++) {{
          const item = feats[fi];
          const props = item && item.props;
          const fieldVals = [];
          if (props) {{
            for (let lfi = 0; lfi < activeLabelFields.length; lfi++) {{
              const rv = props[activeLabelFields[lfi]];
              if (rv !== undefined && rv !== null) {{
                const sv = String(rv).trim();
                if (sv !== '') fieldVals.push(sv);
              }}
            }}
          }}
          if (!fieldVals.length) continue;
          const rawVal = fieldVals.join('\\n');
          const metrics = _computeScreenFeatureMetrics(item, viewBb, mapW, mapH);
          if (!metrics) continue;
          const distCenter = Math.hypot(metrics.ax - viewCx, metrics.ay - viewCy);
          candidates.push({{
            layerRank,
            ln,
            spec,
            rawVal,
            fieldVals,
            metrics,
            distCenter
          }});
        }}
      }});

      if (!candidates.length) return;
      candidates.sort((a, b) => {{
        if (a.layerRank !== b.layerRank) return a.layerRank - b.layerRank;
        if (Math.abs(b.metrics.areaPx - a.metrics.areaPx) > 40) return b.metrics.areaPx - a.metrics.areaPx;
        return a.distCenter - b.distCenter;
      }});

      const SVG_NS = 'http://www.w3.org/2000/svg';
      const svgEl = (typeof document.createElementNS === 'function')
        ? document.createElementNS(SVG_NS, 'svg')
        : null;
      const tlLp = (typeof map.containerPointToLayerPoint === 'function')
        ? map.containerPointToLayerPoint([0, 0])
        : {{ x: 0, y: 0 }};
      if (svgEl) {{
        svgEl.setAttribute('class', 'qdash-label-svg');
        svgEl.setAttribute('width', String(Math.round(mapW)));
        svgEl.setAttribute('height', String(Math.round(mapH)));
        svgEl.setAttribute('viewBox', `0 0 ${{Math.round(mapW)}} ${{Math.round(mapH)}}`);
        svgEl.style.left = Math.round(tlLp.x) + 'px';
        svgEl.style.top = Math.round(tlLp.y) + 'px';
        svgEl.style.width = Math.round(mapW) + 'px';
        svgEl.style.height = Math.round(mapH) + 'px';
        panes.linesPane.appendChild(svgEl);
      }}

      const MAX_VISIBLE_LABELS = 250;
      const placedBoxes = [];
      const padEdge = 4;

      for (let ci = 0; ci < candidates.length && placedBoxes.length < MAX_VISIBLE_LABELS; ci++) {{
        const cand = candidates[ci];
        const st = cand.spec || {{}};
        const m = cand.metrics;
        const posMode = String(st.labelPosition || 'center').trim();
        const isOutside = (posMode === 'outside_line' || posMode === 'outside_callout');
        const hOp = Math.max(0, Math.min(100, Number(st.labelHaloOpacity !== undefined ? st.labelHaloOpacity : (st.labelHalo === false ? 0 : 90))));
        const hAlpha = hOp / 100;
        const haloOn = hOp > 0;
        const isBox = (posMode === 'outside_callout') || (posMode === 'center' && haloOn);
        const fSize = Math.max(3, Math.min(24, Number(st.labelSize || 10)));
        const fColor = /^#[0-9a-f]{{3,8}}$/i.test(String(st.labelColor || '')) ? st.labelColor : '#0f172a';
        const darkText = !_isLightLabelColor(fColor);
        const lines = (st.labelMultiRow && cand.fieldVals && cand.fieldVals.length <= 1)
          ? _wrapLabelTextLines(cand.rawVal, 18).split(/\\n/).map(s => s.trim()).filter(Boolean)
          : (Array.isArray(cand.fieldVals) && cand.fieldVals.length ? cand.fieldVals : [String(cand.rawVal || '').trim()]).filter(Boolean);
        if (!lines.length) continue;

        const dim = _measureLabelDimensions(lines, fSize, isBox);
        const lw = dim.w;
        const lh = dim.h;

        let chosenX = null;
        let chosenY = null;
        let usedLeader = false;

        if (!isOutside) {{
          const bx = Math.round(m.ax - lw * 0.5);
          const by = Math.round(m.ay - lh * 0.5);
          if (bx >= padEdge && by >= padEdge && bx + lw <= mapW - padEdge && by + lh <= mapH - padEdge) {{
            if (!_boxesOverlapPadded(bx, by, bx + lw, by + lh, placedBoxes, 4)) {{
              chosenX = bx;
              chosenY = by;
            }}
          }}
        }} else {{
          const gap = 14;
          const trySpots = [
            // Genuine outside of full feature bbox first
            [m.fMaxX + gap, Math.max(padEdge + 2, m.fMinY - lh * 0.35)],
            [m.fMaxX + gap, m.ay - lh * 0.5],
            [m.ax - lw * 0.5, m.fMinY - gap - lh],
            [m.fMaxX + gap, m.fMaxY + gap * 0.55],
            [m.fMinX - gap - lw, m.ay - lh * 0.5],
            [m.fMinX - gap - lw, Math.max(padEdge + 2, m.fMinY - lh * 0.35)],
            [m.ax - lw * 0.5, m.fMaxY + gap],
            [m.fMinX - gap - lw, m.fMaxY + gap * 0.55],
            // Local polygon cross-section outside edges (handles diagonal/L-shaped polygons cleanly)
            [m.localMaxX + gap, m.ay - lh * 0.5],
            [m.ax - lw * 0.5, m.localMinY - gap - lh],
            [m.localMinX - gap - lw, m.ay - lh * 0.5],
            [m.ax - lw * 0.5, m.localMaxY + gap]
          ];
          for (let si = 0; si < trySpots.length; si++) {{
            const bx = Math.round(trySpots[si][0]);
            const by = Math.round(trySpots[si][1]);
            if (bx < padEdge || by < padEdge || bx + lw > mapW - padEdge || by + lh > mapH - padEdge) continue;
            if (_boxesOverlapPadded(bx, by, bx + lw, by + lh, placedBoxes, 4)) continue;
            if (m.kind === 'poly' && m.pts && _boxIntersectsPolygonScreen(bx, by, lw, lh, m.pts)) continue;
            chosenX = bx;
            chosenY = by;
            usedLeader = true;
            break;
          }}
          // Fallback for huge polygons covering almost the entire viewport: place cleanly offset inside view
          if (chosenX === null) {{
            const fbSpots = [
              [Math.min(mapW - padEdge - lw, m.ax + 22), Math.max(padEdge, m.ay - lh - 14)],
              [Math.max(padEdge, m.ax - lw - 22), Math.max(padEdge, m.ay - lh - 14)],
              [Math.min(mapW - padEdge - lw, m.ax + 22), Math.min(mapH - padEdge - lh, m.ay + 14)]
            ];
            for (let fi = 0; fi < fbSpots.length; fi++) {{
              const bx = Math.round(fbSpots[fi][0]);
              const by = Math.round(fbSpots[fi][1]);
              if (bx < padEdge || by < padEdge || bx + lw > mapW - padEdge || by + lh > mapH - padEdge) continue;
              if (_boxesOverlapPadded(bx, by, bx + lw, by + lh, placedBoxes, 4)) continue;
              chosenX = bx;
              chosenY = by;
              usedLeader = true;
              break;
            }}
          }}
        }}

        if (chosenX === null || chosenY === null) continue;
        placedBoxes.push([chosenX, chosenY, chosenX + lw, chosenY + lh]);

        const [targetX, targetY] = usedLeader
          ? _nearestPointOnBox(m.ax, m.ay, chosenX, chosenY, lw, lh)
          : [m.ax, m.ay];

        if (usedLeader && svgEl) {{
          const lineEl = document.createElementNS(SVG_NS, 'line');
          lineEl.setAttribute('x1', String(Math.round(m.ax * 10) / 10));
          lineEl.setAttribute('y1', String(Math.round(m.ay * 10) / 10));
          lineEl.setAttribute('x2', String(Math.round(targetX * 10) / 10));
          lineEl.setAttribute('y2', String(Math.round(targetY * 10) / 10));
          lineEl.setAttribute('stroke', fColor);
          lineEl.setAttribute('stroke-width', '1.3');
          lineEl.setAttribute('stroke-opacity', '0.85');
          svgEl.appendChild(lineEl);

          const dotEl = document.createElementNS(SVG_NS, 'circle');
          dotEl.setAttribute('cx', String(Math.round(m.ax * 10) / 10));
          dotEl.setAttribute('cy', String(Math.round(m.ay * 10) / 10));
          dotEl.setAttribute('r', '2.3');
          dotEl.setAttribute('fill', fColor);
          dotEl.setAttribute('fill-opacity', '0.9');
          svgEl.appendChild(dotEl);
        }}

        const lblDiv = document.createElement('div');
        const boxCls = isBox
          ? ('qdash-map-label-box' + (darkText ? '' : ' qdash-map-label-darkbox'))
          : 'qdash-map-label-plain';
        lblDiv.className = 'qdash-map-label ' + boxCls;
        const lp = (typeof map.containerPointToLayerPoint === 'function')
          ? map.containerPointToLayerPoint([chosenX, chosenY])
          : {{ x: chosenX, y: chosenY }};
        lblDiv.style.left = Math.round(lp.x) + 'px';
        lblDiv.style.top = Math.round(lp.y) + 'px';
        lblDiv.style.width = lw + 'px';
        lblDiv.style.fontSize = fSize + 'px';
        lblDiv.style.color = fColor;
        if (isBox) {{
          lblDiv.style.backgroundColor = darkText
            ? `rgba(255,255,255,${{hAlpha.toFixed(2)}})`
            : `rgba(15,23,42,${{(0.92 * hAlpha).toFixed(2)}})`;
          lblDiv.style.borderColor = darkText
            ? `rgba(15,23,42,${{(0.34 * Math.max(0.2, hAlpha)).toFixed(2)}})`
            : `rgba(148,163,184,${{(0.55 * Math.max(0.2, hAlpha)).toFixed(2)}})`;
        }}
        if (haloOn && !isBox) {{
          const hc = darkText ? `rgba(255,255,255,${{hAlpha.toFixed(2)}})` : `rgba(15,23,42,${{hAlpha.toFixed(2)}})`;
          lblDiv.style.textShadow = `-1px -1px 0 ${{hc}}, 1px -1px 0 ${{hc}}, -1px 1px 0 ${{hc}}, 1px 1px 0 ${{hc}}`;
        }} else {{
          lblDiv.style.textShadow = 'none';
        }}
        lblDiv.textContent = lines.join('\\n');
        panes.labelsPane.appendChild(lblDiv);

        ACTIVE_RENDERED_LABELS.push({{
          boxX: chosenX,
          boxY: chosenY,
          boxW: lw,
          boxH: lh,
          lines,
          fontSize: fSize,
          color: fColor,
          haloOn,
          haloOpacity: hOp,
          darkHalo: !darkText,
          darkBox: !darkText,
          isBox,
          hasLeader: usedLeader,
          anchorX: m.ax,
          anchorY: m.ay,
          targetX,
          targetY
        }});
      }}
    }}

    function renderMapFeatures(opts) {{
      const options = opts || {{}};
      let totalActive = 0;
      let renderedSimplifiedPoly = 0;
      let renderedFullPoly = 0;
      let missingViewportGeomsTotal = 0;
      let fetchingUpgrade = false;
      const filteredBoundsPoints = [];
      const allBoundsPoints = [];
      const layerNames = orderedMapLayerNames();
      renderMapLayersDrawer();

      let mapZoom = 7;
      let mapBbox = null;
      if (map && typeof map.getZoom === 'function') {{
        const z = Number(map.getZoom());
        if (Number.isFinite(z)) mapZoom = z;
      }}
      const scaleDenom = computeMapScaleDenominator();
      const targetLod = targetLodForScale(scaleDenom);
      updateMapScaleBadge(scaleDenom, targetLod);

      if (map && typeof map.getBounds === 'function') {{
        try {{
          const mb = map.getBounds();
          if (mb && mb.isValid && mb.isValid()) {{
            const w = mb.getWest(), s = mb.getSouth(), e = mb.getEast(), n = mb.getNorth();
            const padX = Math.max(0.01, (e - w) * 0.15);
            const padY = Math.max(0.01, (n - s) * 0.15);
            mapBbox = [w - padX, s - padY, e + padX, n + padY];
          }}
        }} catch (_err) {{}}
      }}

      const mSet = mapTargetIdSet();

      // Pre-compute dedicated Leaflet panes & per-layer Canvas renderers matching layerNames[0]=TOP..bottom
      const layerPaneByName = {{}};
      const layerRendererByName = {{}};
      layerNames.forEach((ln, idx) => {{
        const pName = ensureLayerPane(ln, idx, layerNames.length);
        if (pName) layerPaneByName[ln] = pName;
        const rInst = getLayerCanvasRenderer(ln, pName);
        if (rInst) layerRendererByName[ln] = rInst;
      }});

      // Draw from bottom layer to top layer (layerNames[0] renders visually on top)
      const drawOrder = layerNames.slice().reverse();
      drawOrder.forEach(ln => {{
        LAYER_RENDERED_FEATURES[ln] = [];
        const layerPane = layerPaneByName[ln] || undefined;
        const layerRenderer = layerRendererByName[ln] || vectorCanvasRenderer || undefined;
        let grp = LAYER_OVERLAYS[ln];
        if (!grp && map) {{
          IS_SYNCING_MAP_LAYERS += 1;
          try {{
            grp = L.layerGroup().addTo(map);
            LAYER_OVERLAYS[ln] = grp;
            if (layerControl && typeof layerControl.addOverlay === 'function') layerControl.addOverlay(grp, ln);
          }} finally {{
            IS_SYNCING_MAP_LAYERS -= 1;
          }}
          syncLeafletLayerControlActions();
        }}
        if (!grp) return;
        grp.clearLayers();

        if (MAP_LAYER_VISIBILITY[ln] === false) {{
          IS_SYNCING_MAP_LAYERS += 1;
          try {{
            if (map && map.hasLayer(grp)) map.removeLayer(grp);
            if (LAYER_WMS_OVERLAYS[ln] && map && map.hasLayer(LAYER_WMS_OVERLAYS[ln])) map.removeLayer(LAYER_WMS_OVERLAYS[ln]);
          }} finally {{
            IS_SYNCING_MAP_LAYERS -= 1;
          }}
          return;
        }}
        if (!isLayerVisibleAtZoom(ln, mapZoom, scaleDenom)) {{
          IS_SYNCING_MAP_LAYERS += 1;
          try {{
            if (typeof grp.clearLayers === 'function') grp.clearLayers();
            if (LAYER_WMS_OVERLAYS[ln] && map && map.hasLayer(LAYER_WMS_OVERLAYS[ln])) map.removeLayer(LAYER_WMS_OVERLAYS[ln]);
          }} finally {{
            IS_SYNCING_MAP_LAYERS -= 1;
          }}
          return;
        }}
        if (map && !map.hasLayer(grp)) {{
          IS_SYNCING_MAP_LAYERS += 1;
          try {{ grp.addTo(map); }} finally {{ IS_SYNCING_MAP_LAYERS -= 1; }}
        }}

        const filtered = filterRecords(ln, null, '__map__');
        totalActive += filtered.length;
        const activeEntries = Object.entries(ACTIVE_FILTERS);
        const activeFilterList = activeEntries.map(([, f]) => f);
        const hasAnyFilter = activeFilterList.length > 0;
        const layerMatchesFilter = hasAnyFilter && activeEntries.some(([srcId, f]) => shouldFilterApply(srcId, f, '__map__', ln));
        const geoms = LAYER_GEOMETRIES[ln] || {{}};
        const geomLods = LAYER_GEOM_LOD[ln] || {{}};
        const layerRows = LAYER_RECORDS[ln] || [];
        const statMeta = LAYER_STATS[ln] || {{}};
        const vp = VECTOR_PYRAMIDS[ln] || null;
        const geomTypeHint = String(LAYER_GEOM_TYPES[ln] || statMeta.geom_type || '');
        const isPolyOrLineLayer = (geomTypeHint && !/Point/i.test(geomTypeHint))
          || Object.values(geoms).some(g => g && g.type && !/Point/i.test(g.type))
          || Boolean(vp && vp.lod1)
          || layerRows.some(rec => rec && rec._geom_area_ha !== undefined && rec._geom_area_ha !== null);

        const isLargeLayer = layerRows.length > 2500
          || Number(statMeta.feature_count || 0) > 2500;
        const vpLod0Features = (vp && vp.lod0 && Array.isArray(vp.lod0.features)) ? vp.lod0.features : [];
        const canRasterTileLayer = _canLayerUsePreviewTile(ln, targetLod, scaleDenom, hasAnyFilter);
        if (canRasterTileLayer) {{
          renderedFullPoly++;
          LAYER_RENDERED_FEATURES[ln] = filtered.slice(0, 800).map(r => ({{
            props: r || {{}},
            geom: r && r._feature_id !== undefined ? getFeatureGeometry(ln, String(r._feature_id)) : null,
            lat: r ? r._lat : undefined,
            lon: r ? r._lon : undefined
          }}));
          return;
        }}

        // Toggle companion GeoServer WMS tile layer in Standalone HTML for lag-free wide-scale overview
        const wmsLyr = LAYER_WMS_OVERLAYS[ln];
        if (wmsLyr && map) {{
          if (isLargeLayer && scaleDenom > 55000 && !hasAnyFilter) {{
            if (layerPane && wmsLyr.options && wmsLyr.options.pane !== layerPane) {{
              IS_SYNCING_MAP_LAYERS += 1;
              try {{
                if (map.hasLayer(wmsLyr)) map.removeLayer(wmsLyr);
                wmsLyr.options.pane = layerPane;
              }} finally {{
                IS_SYNCING_MAP_LAYERS -= 1;
              }}
            }}
            if (!map.hasLayer(wmsLyr)) wmsLyr.addTo(map);
          }} else if (map.hasLayer(wmsLyr)) {{
            map.removeLayer(wmsLyr);
          }}
        }}

        // Stage 0 (> 1:750,000): detailed simplified polygon overview on Canvas (falls back to points only for point layers)
        const vpLod0IsPointOnly = vpLod0Features.length > 0
          && vpLod0Features.slice(0, 20).every(f => f && f.geometry && /Point/i.test(String(f.geometry.type || '')));
        if (!hasAnyFilter && !EXTENT_FILTER_ENABLED && targetLod === 0 && isLargeLayer && vpLod0Features.length > 0 && !(isPolyOrLineLayer && vpLod0IsPointOnly)) {{
          const lod0Opts = {{
            pointToLayer: (feat, latlng) => {{
              const props = feat.properties || {{}};
              const base = styleFeatureForLayer(ln, props, layerRenderer, layerPane);
              const cnt = Number(props.count || 1);
              const mOpts = {{
                radius: Math.min(6, Math.max(2, 1.5 + Math.log10(cnt + 1) * 1.8)),
                color: base.color,
                fillColor: base.fillColor,
                weight: 0.8,
                opacity: 0.75,
                fillOpacity: 0.55,
              }};
              if (layerPane) mOpts.pane = layerPane;
              if (layerRenderer) mOpts.renderer = layerRenderer;
              return L.circleMarker(latlng, mOpts);
            }},
            style: feat => {{
              const props = feat.properties || {{}};
              const base = styleFeatureForLayer(ln, props, layerRenderer, layerPane);
              return Object.assign({{}}, base, {{
                weight: 1.0,
                opacity: 0.88,
                fillOpacity: Math.max(0.32, Number(base.fillOpacity || 0.42))
              }});
            }},
            onEachFeature: (feat, lyr) => {{
              const p = feat.properties || {{}};
              const areaVal = p.area_ha !== undefined ? p.area_ha : p._geom_area_ha;
              let pop = `<b>${{escapeHtml(ln)}}</b> (LOD-0)`;
              if (areaVal !== undefined && areaVal !== null && areaVal !== '') {{
                pop += `<br/><b>${{escapeHtml(t('th_area_ha'))}}:</b> ${{escapeHtml(areaVal)}} ha`;
              }}
              if (p.count) pop += `<br/><b>Count:</b> ${{escapeHtml(p.count)}}`;
              let extraShown = 0;
              Object.keys(p).forEach(pk => {{
                if (extraShown >= 3 || !pk || pk.startsWith('_') || pk === 'area_ha' || pk === 'count') return;
                const pv = p[pk];
                if (pv === undefined || pv === null || String(pv).trim() === '') return;
                pop += `<br/><b>${{escapeHtml(pk)}}:</b> ${{escapeHtml(pv)}}`;
                extraShown++;
              }});
              lyr.bindPopup(pop);
            }}
          }};
          if (layerPane) lod0Opts.pane = layerPane;
          if (layerRenderer) lod0Opts.renderer = layerRenderer;
          const gjLod0 = L.geoJSON(vp.lod0, lod0Opts);
          grp.addLayer(gjLod0);
          if (gjLod0.bringToFront) gjLod0.bringToFront();
          LAYER_RENDERED_FEATURES[ln] = vpLod0Features.map(f => ({{
            props: (f && f.properties) || {{}},
            geom: (f && f.geometry) || null,
            lat: f && f.properties ? f.properties._lat : undefined,
            lon: f && f.properties ? f.properties._lon : undefined,
            isLod0: true
          }}));
          return;
        }}

        const geoFeatures = [];
        const renderedLabelList = [];
        const missingFids = [];
        const upgradeFids = [];
        let missingViewportGeoms = 0;
        const maxDrawFeatures = targetLod >= 3 ? 6000 : 3500;
        const useViewportCull = Boolean(filtered.length > maxDrawFeatures && mapBbox);

        for (let i = 0; i < filtered.length; i++) {{
          const r = filtered[i];
          const fidStr = String(r._feature_id);
          const geom = getFeatureGeometry(ln, fidStr);
          const bb = geom
            ? getFeatureBbox(ln, fidStr)
            : ((LAYER_PYRAMID_LOD1[ln] && LAYER_PYRAMID_LOD1[ln][fidStr]) ? LAYER_PYRAMID_LOD1[ln][fidStr][1] : null);

          if (hasAnyFilter && (layerMatchesFilter || !activeFilterList.some(f => f.layer_name))) {{
            if (bb && bb.length === 4) {{
              (layerMatchesFilter ? filteredBoundsPoints : allBoundsPoints).push([bb[1], bb[0]], [bb[3], bb[2]]);
            }} else if (r._lat !== undefined && r._lon !== undefined) {{
              const lat = Number(r._lat), lon = Number(r._lon);
              if (!isNaN(lat) && !isNaN(lon)) {{
                (layerMatchesFilter ? filteredBoundsPoints : allBoundsPoints).push([lat, lon]);
              }}
            }}
          }}

          let inViewport = true;
          if (mapBbox) {{
            if (bb) {{
              inViewport = bboxIntersects(bb, mapBbox);
            }} else if (r._lat !== undefined && r._lon !== undefined) {{
              const lat = Number(r._lat), lon = Number(r._lon);
              if (!isNaN(lat) && !isNaN(lon)) {{
                inViewport = !(lon < mapBbox[0] || lon > mapBbox[2] || lat < mapBbox[1] || lat > mapBbox[3]);
              }}
            }}
          }}
          if (useViewportCull && !inViewport) continue;

          if (geom) {{
            const freshLods = LAYER_GEOM_LOD[ln] || geomLods;
            const curLod = Number(freshLods[fidStr] || (LAYER_PYRAMID_LOD1[ln] && LAYER_PYRAMID_LOD1[ln][fidStr] ? 1 : 2));
            if (inViewport) {{
              if (curLod >= 3) renderedFullPoly++;
              else if (isPolyOrLineLayer) renderedSimplifiedPoly++;
              if (targetLod >= 3 && curLod < 3 && upgradeFids.length < 1500) {{
                upgradeFids.push(fidStr);
              }}
            }}
            if (geoFeatures.length < maxDrawFeatures) {{
              geoFeatures.push({{ type: 'Feature', geometry: geom, properties: r }});
              renderedLabelList.push({{ props: r, geom, lat: r._lat, lon: r._lon }});
            }}
          }} else if (isPolyOrLineLayer) {{
            if (inViewport && missingFids.length < 1200) missingFids.push(fidStr);
            if (inViewport) missingViewportGeoms++;
          }} else if (r._lat !== undefined && r._lon !== undefined) {{
            const lat = Number(r._lat), lon = Number(r._lon);
            if (!isNaN(lat) && !isNaN(lon)) {{
              const st = styleFeatureForLayer(ln, r, layerRenderer, layerPane);
              const mOpts = {{
                radius: 6, fillColor: st.fillColor, color: '#0f172a', weight: 1.2, fillOpacity: 0.88,
              }};
              if (layerPane) mOpts.pane = layerPane;
              if (layerRenderer) mOpts.renderer = layerRenderer;
              const marker = L.circleMarker([lat, lon], mOpts);
              marker.bindPopup(buildPopupHtml(ln, r));
              renderedLabelList.push({{ props: r, geom: {{ type: 'Point', coordinates: [lon, lat] }}, lat, lon }});
              grp.addLayer(marker);
              if (marker.bringToFront) marker.bringToFront();
            }}
          }}
        }}

        if (geoFeatures.length) {{
          const gjOpts = {{
            style: feat => styleFeatureForLayer(ln, feat.properties || {{}}, layerRenderer, layerPane),
            onEachFeature: (feat, lyr) => {{
              const props = feat.properties || {{}};
              lyr.bindPopup(buildPopupHtml(ln, props));
            }}
          }};
          if (layerPane) gjOpts.pane = layerPane;
          if (layerRenderer) gjOpts.renderer = layerRenderer;
          const gjLayer = L.geoJSON({{ type: 'FeatureCollection', features: geoFeatures }}, gjOpts);
          grp.addLayer(gjLayer);
          if (gjLayer.bringToFront) gjLayer.bringToFront();
        }} else if (missingViewportGeoms > 0 && isPolyOrLineLayer && !HAS_PREVIEW_API && !(LAYER_WMS_OVERLAYS[ln] && map && map.hasLayer(LAYER_WMS_OVERLAYS[ln]))) {{
          // Offline non-WMS subtle centroid dots while LOD-1 unpacks / WFS loads
          for (let j = 0; j < filtered.length && j < 1800; j++) {{
            const r = filtered[j];
            const lat = Number(r._lat), lon = Number(r._lon);
            if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
            if (mapBbox && (lon < mapBbox[0] || lon > mapBbox[2] || lat < mapBbox[1] || lat > mapBbox[3])) continue;
            const st = styleFeatureForLayer(ln, r, layerRenderer, layerPane);
            const dotOpts = {{
              radius: 2.5, fillColor: st.fillColor, color: st.color, weight: 0.5, fillOpacity: 0.65,
            }};
            if (layerPane) dotOpts.pane = layerPane;
            if (layerRenderer) dotOpts.renderer = layerRenderer;
            const dot = L.circleMarker([lat, lon], dotOpts);
            grp.addLayer(dot);
            renderedLabelList.push({{ props: r, geom: {{ type: 'Point', coordinates: [lon, lat] }}, lat, lon }});
          }}
        }}
        LAYER_RENDERED_FEATURES[ln] = renderedLabelList;

        missingViewportGeomsTotal += missingViewportGeoms;
        const needHydration = (missingFids.length > 0 || missingViewportGeoms > 0);
        if (needHydration && vp && vp.lod1 && vp.lod1.data_b64 && !LAYER_PYRAMID_LOD1[ln]) {{
          const initFids = (missingFids.length > 0 && (layerMatchesFilter || filtered.length <= 1200))
            ? missingFids
            : undefined;
          requestMissingFeatures(ln, {{
            fids: initFids,
            bbox: mapBbox || undefined,
            zoom: mapZoom,
            lod: targetLod,
            scale: scaleDenom,
            skipAutoZoom: Boolean(options.skipAutoZoom),
            forceZoom: Boolean(options.forceZoom)
          }});
        }} else if ((needHydration || upgradeFids.length > 0) && (HAS_PREVIEW_API || Boolean(findLiveWfsService(ln)))) {{
          const reqFids = missingFids.length > 0 ? missingFids : upgradeFids;
          if (upgradeFids.length > 0 && targetLod >= 3) fetchingUpgrade = true;
          if (reqFids.length > 0 && (layerMatchesFilter || filtered.length <= 1200 || upgradeFids.length > 0)) {{
            requestMissingFeatures(ln, {{
              fids: reqFids,
              bbox: mapBbox || undefined,
              zoom: mapZoom,
              lod: targetLod,
              scale: scaleDenom,
              skipAutoZoom: Boolean(options.skipAutoZoom),
              forceZoom: Boolean(options.forceZoom)
            }});
          }} else if (mapBbox) {{
            requestMissingFeatures(ln, {{
              bbox: mapBbox,
              zoom: mapZoom,
              lod: targetLod,
              scale: scaleDenom,
              skipAutoZoom: Boolean(options.skipAutoZoom),
              forceZoom: Boolean(options.forceZoom)
            }});
          }}
        }}
      }});

      if (targetLod >= 3) {{
        updateMapScaleBadge(scaleDenom, targetLod, {{
          hasExactDetail: (renderedSimplifiedPoly === 0 && missingViewportGeomsTotal === 0),
          actualLod: (renderedSimplifiedPoly > 0) ? 1 : ((missingViewportGeomsTotal > 0) ? 0 : 3),
          fetchingUpgrade
        }});
      }} else {{
        updateMapScaleBadge(scaleDenom, targetLod);
      }}
      updatePreviewWmsOverlay(layerNames, scaleDenom);
      updateMapLegend();
      if (typeof renderMapFeatureLabels === 'function') renderMapFeatureLabels();
      if (typeof _currentViewportSnapshot === 'function') {{
        LAST_RENDER_VIEWPORT = _currentViewportSnapshot();
      }}

      // Collect zoom target bounds from zoom_only or connected filters whose target is Map,
      // prioritizing the most recently interacted filter source and intersecting all active filters.
      const connZoomPts = [];
      const specificConnZoomPts = [];
      const activeEntriesZoom = Object.entries(ACTIVE_FILTERS);
      const lastNormSrc = LAST_INTERACTED_FILTER_SOURCE ? normalizeWidgetSourceId(LAST_INTERACTED_FILTER_SOURCE) : '';
      activeEntriesZoom.forEach(([srcId, flt]) => {{
        const outgoing = getConnectionsFrom(srcId);
        if (!outgoing.some(c => mSet.has(c.target_id) && (c.action === 'filter_and_zoom' || c.action === 'zoom_only'))) return;
        const isLastInteracted = Boolean(LAST_INTERACTED_FILTER_SOURCE) && (
          srcId === LAST_INTERACTED_FILTER_SOURCE || normalizeWidgetSourceId(srcId) === lastNormSrc
        );
        const destArr = isLastInteracted ? specificConnZoomPts : connZoomPts;
        const baseRecs = (flt.layer_name && flt.layer_name !== '__spatial__' ? filterRecords(flt.layer_name, null, '__map__') : []) || [];
        const srcRecs = baseRecs.length ? baseRecs : ((flt.layer_name && flt.layer_name !== '__spatial__' ? LAYER_RECORDS[flt.layer_name] : []) || []);
        srcRecs.forEach(r => {{
          if (!r || !_filterRowMatchesAttr(r, flt, flt.layer_name)) return;
          const bb = getFeatureBbox(flt.layer_name, String(r._feature_id));
          if (bb && bb.length === 4) {{
            destArr.push([bb[1], bb[0]], [bb[3], bb[2]]);
          }} else if (r._lat !== undefined && r._lon !== undefined) {{
            const lat = Number(r._lat), lon = Number(r._lon);
            if (!isNaN(lat) && !isNaN(lon)) destArr.push([lat, lon]);
          }}
        }});
      }});

      const badge = document.getElementById('feature-count-badge');
      if (badge) badge.textContent = t('html_active_features', {{ count: totalActive, layers: layerNames.length }});

      const hasActiveFilters = Object.keys(ACTIVE_FILTERS).length > 0;
      const effectiveConnPts = specificConnZoomPts.length ? specificConnZoomPts : connZoomPts;
      const zoomTargetPts = effectiveConnPts.length ? effectiveConnPts : (filteredBoundsPoints.length ? filteredBoundsPoints : allBoundsPoints);
      const explicitWantsZoom = effectiveConnPts.length > 0;
      const autoZoomOn = DASHBOARD.auto_zoom_on_filter !== false || explicitWantsZoom;
      if ((autoZoomOn || Boolean(options.forceZoom)) && hasActiveFilters && zoomTargetPts.length > 0 && !EXTENT_FILTER_ENABLED && !options.skipAutoZoom && map) {{
        safeFitBounds(zoomTargetPts, {{ padding: [32, 32], maxZoom: 14, refreshAfterZoom: true }});
      }}
    }}

    const CHART_PALETTES = {{
      emerald: ['#34d399', '#059669', '#10b981', '#38bdf8', '#fbbf24', '#a855f7'],
      forest: ['#15803d', '#22c55e', '#166534', '#84cc16', '#0d9488', '#65a30d'],
      meadow: ['#4ade80', '#facc15', '#2dd4bf', '#a3e635', '#38bdf8', '#fb923c'],
      ocean: ['#38bdf8', '#0284c7', '#818cf8', '#22d3ee', '#34d399', '#a78bfa'],
      amber: ['#fbbf24', '#d97706', '#f59e0b', '#fb7185', '#38bdf8', '#34d399'],
      earth: ['#d97706', '#a16207', '#65a30d', '#92400e', '#ca8a04', '#0d9488'],
      rose: ['#f43f5e', '#e11d48', '#fb7185', '#c084fc', '#38bdf8', '#fbbf24'],
      corporate: ['#2563eb', '#0d9488', '#d97706', '#dc2626', '#7c3aed', '#475569'],
    }};
    function _resolveChartPalette(w, count) {{
      const palKey = String((w && w.color_palette) || 'emerald').trim().toLowerCase();
      const prim = (w && w.primary_color) ? String(w.primary_color) : '#34d399';
      const n = Math.max(1, Number(count || 1));
      if (palKey === 'single') {{
        if (!w || (!w.secondary_field && w.widget_type !== 'pie')) {{
          return Array.from({{ length: n }}, () => prim);
        }}
        const base = CHART_PALETTES.emerald;
        return [prim, ...base.filter(c => c.toLowerCase() !== prim.toLowerCase())];
      }}
      const pal = CHART_PALETTES[palKey] || CHART_PALETTES.emerald;
      return Array.from({{ length: n }}, (_, i) => pal[i % pal.length]);
    }}

    const _EXPR_WIDGET_FNS = new Set(['widget','widget_value','widget_count']);
    const _EXPR_AGG_FNS = new Set(['sum','mean','avg','count','count_distinct','minimum','maximum','median','pct_share','layer_sum','layer_mean','layer_avg','layer_count','layer_count_distinct','layer_min','layer_max','layer_median','widget','widget_value','widget_count']);
    const _EXPR_CROSS_FNS = new Set(['layer_sum','layer_mean','layer_avg','layer_count','layer_count_distinct','layer_min','layer_max','layer_median']);
    const _EXPR_KW = new Set(['AND','OR','NOT','IN','LIKE','ILIKE','IS','NULL','TRUE','FALSE','CASE','WHEN','THEN','ELSE','END']);

    function _tokenizeDashExpr(text) {{
      const toks = [];
      let i = 0;
      const n = text.length;
      const isSp = c => c === ' ' || c === '\\t' || c === '\\n' || c === '\\r';
      const isDig = c => c >= '0' && c <= '9';
      const stopCh = '(),+-*/%^=<>!' + String.fromCharCode(39, 34);
      const isIdStart = c => !isSp(c) && !isDig(c) && stopCh.indexOf(c) === -1 && c !== '.';
      const isIdCh = c => !isSp(c) && stopCh.indexOf(c) === -1;
      while (i < n) {{
        const ch = text[i];
        if (isSp(ch)) {{ i++; continue; }}
        if ('(),+-*/%^'.indexOf(ch) !== -1) {{ toks.push([ch, ch, i]); i++; continue; }}
        const two = text.slice(i, i + 2);
        if (two === '||' || two === '<>' || two === '!=' || two === '<=' || two === '>=' || two === '==') {{
          toks.push(['OP', two, i]); i += 2; continue;
        }}
        if ('=<>'.indexOf(ch) !== -1) {{ toks.push(['OP', ch, i]); i++; continue; }}
        if (ch === "'") {{
          const start = i++; let buf = '';
          while (i < n) {{
            if (text[i] === "'" && text[i + 1] === "'") {{ buf += "'"; i += 2; }}
            else if (text[i] === '\\\\' && i + 1 < n) {{ buf += text[i + 1]; i += 2; }}
            else if (text[i] === "'") {{ i++; break; }}
            else {{ buf += text[i++]; }}
          }}
          toks.push(['STR', buf, start]); continue;
        }}
        if (ch === '"') {{
          const start = i++; let buf = '';
          while (i < n) {{
            if (text[i] === '"' && text[i + 1] === '"') {{ buf += '"'; i += 2; }}
            else if (text[i] === '"') {{ i++; break; }}
            else {{ buf += text[i++]; }}
          }}
          toks.push(['FIELD', buf, start]); continue;
        }}
        if (isDig(ch) || (ch === '.' && isDig(text[i + 1] || ''))) {{
          const start = i; let sawDot = false;
          while (i < n) {{
            if (isDig(text[i])) i++;
            else if (text[i] === '.' && !sawDot) {{ sawDot = true; i++; }}
            else break;
          }}
          toks.push(['NUM', parseFloat(text.slice(start, i)), start]); continue;
        }}
        if (isIdStart(ch) || ch === '$' || ch === '@') {{
          const start = i++;
          while (i < n && isIdCh(text[i])) i++;
          const w = text.slice(start, i);
          const up = w.toUpperCase();
          toks.push([_EXPR_KW.has(up) ? 'KW' : 'IDENT', _EXPR_KW.has(up) ? up : w, start]);
          continue;
        }}
        throw new Error('Unexpected token at ' + i + ': ' + ch);
      }}
      toks.push(['EOF', null, n]);
      return toks;
    }}

    function parseDashExpr(text) {{
      const toks = _tokenizeDashExpr(String(text || '').trim());
      let pos = 0;
      const cur = () => toks[pos];
      const match = (k, v) => {{ const t = cur(); if (t[0] !== k || (v !== undefined && t[1] !== v)) return false; pos++; return true; }};
      const expect = (k, v) => {{ const t = cur(); if (t[0] !== k || (v !== undefined && t[1] !== v)) throw new Error('Expected ' + (v || k)); pos++; return t; }};
      const parseOr = () => {{ let l = parseAnd(); while (match('KW', 'OR')) l = ['OR', l, parseAnd()]; return l; }};
      const parseAnd = () => {{ let l = parseNot(); while (match('KW', 'AND')) l = ['AND', l, parseNot()]; return l; }};
      const parseNot = () => match('KW', 'NOT') ? ['NOT', parseNot()] : parseCmp();
      const parseInList = () => {{
        expect('('); const arr = [];
        if (!match(')')) {{ arr.push(parseOr()); while (match(',')) arr.push(parseOr()); expect(')'); }}
        return arr;
      }};
      const parseCmp = () => {{
        let node = parseAdd();
        while (true) {{
          const t = cur();
          if (t[0] === 'KW' && t[1] === 'IS') {{ pos++; const neg = match('KW', 'NOT'); expect('KW', 'NULL'); node = ['IS_NULL', node, neg]; }}
          else if (t[0] === 'KW' && t[1] === 'NOT' && toks[pos + 1] && toks[pos + 1][0] === 'KW' && ['IN','LIKE','ILIKE'].includes(toks[pos + 1][1])) {{
            const kw = toks[pos + 1][1]; pos += 2;
            node = kw === 'IN' ? ['NOT', ['IN', node, parseInList()]] : ['NOT', [kw, node, parseAdd()]];
          }}
          else if (t[0] === 'KW' && t[1] === 'IN') {{ pos++; node = ['IN', node, parseInList()]; }}
          else if (t[0] === 'KW' && (t[1] === 'LIKE' || t[1] === 'ILIKE')) {{ pos++; node = [t[1], node, parseAdd()]; }}
          else if (t[0] === 'OP' && ['=','==','!=','<>','<','<=','>','>='].includes(t[1])) {{ pos++; node = ['CMP', t[1], node, parseAdd()]; }}
          else break;
        }}
        return node;
      }};
      const parseAdd = () => {{
        let l = parseMul();
        while ((cur()[0] === 'OP' && cur()[1] === '||') || cur()[0] === '+' || cur()[0] === '-') {{
          const op = cur()[1]; pos++; l = ['BIN', op, l, parseMul()];
        }}
        return l;
      }};
      const parseMul = () => {{
        let l = parsePow();
        while (cur()[0] === '*' || cur()[0] === '/' || cur()[0] === '%') {{
          const op = cur()[1]; pos++; l = ['BIN', op, l, parsePow()];
        }}
        return l;
      }};
      const parsePow = () => {{ const l = parseUnary(); return match('^') ? ['BIN', '^', l, parsePow()] : l; }};
      const parseUnary = () => match('-') ? ['NEG', parseUnary()] : (match('+') ? parseUnary() : parsePrimary());
      const parsePrimary = () => {{
        const t = cur();
        if (t[0] === 'NUM' || t[0] === 'STR') {{ pos++; return ['LIT', t[1]]; }}
        if (t[0] === 'FIELD') {{ pos++; return ['FIELD', t[1]]; }}
        if (t[0] === 'KW' && t[1] === 'TRUE') {{ pos++; return ['LIT', true]; }}
        if (t[0] === 'KW' && t[1] === 'FALSE') {{ pos++; return ['LIT', false]; }}
        if (t[0] === 'KW' && t[1] === 'NULL') {{ pos++; return ['LIT', null]; }}
        if (t[0] === 'KW' && t[1] === 'CASE') {{
          pos++; const base = (cur()[0] === 'KW' && cur()[1] === 'WHEN') ? null : parseOr();
          const br = [];
          while (match('KW', 'WHEN')) {{ const c = parseOr(); expect('KW', 'THEN'); br.push([c, parseOr()]); }}
          const el = match('KW', 'ELSE') ? parseOr() : ['LIT', null];
          expect('KW', 'END');
          return ['CASE', base, br, el];
        }}
        if (match('(')) {{ const inner = parseOr(); expect(')'); return inner; }}
        if (t[0] === 'IDENT') {{
          pos++; const nm = String(t[1]);
          if (match('(')) {{
            const args = [];
            if (!match(')')) {{ args.push(parseOr()); while (match(',')) args.push(parseOr()); expect(')'); }}
            return ['CALL', nm.toLowerCase(), args];
          }}
          return ['VAR', nm];
        }}
        throw new Error('Unexpected expression token: ' + t[1]);
      }};
      const ast = parseOr();
      if (cur()[0] !== 'EOF') throw new Error('Unexpected trailing token: ' + cur()[1]);
      return ast;
    }}

    function _exprAstHasAgg(node) {{
      if (!Array.isArray(node) || !node.length) return false;
      if (node[0] === 'CALL') return _EXPR_AGG_FNS.has(node[1]) || node[2].some(_exprAstHasAgg);
      if (node[0] === 'VAR') return ['$count','@row_count','@feature_count','@total_count','@filter_count'].includes(String(node[1]).toLowerCase());
      return node.slice(1).some(ch => Array.isArray(ch) ? _exprAstHasAgg(ch) : false);
    }}
    function _exprAstHasField(node) {{
      if (!Array.isArray(node) || !node.length) return false;
      if (node[0] === 'FIELD') return true;
      if (node[0] === 'VAR') return !['$count','@row_count','@feature_count','@total_count','@filter_count','@layer','@layer_name'].includes(String(node[1]).toLowerCase());
      if (node[0] === 'CALL' && _EXPR_AGG_FNS.has(node[1])) return false;
      return node.slice(1).some(ch => Array.isArray(ch) ? _exprAstHasField(ch) : false);
    }}

    function evalWidgetMetricByRef(refKey, mode, visitedSet) {{
      const rk = String(refKey || '').trim();
      if (!rk) return 0;
      const seen = new Set(visitedSet || []);
      const widgets = Array.isArray(DASHBOARD.widgets) ? DASHBOARD.widgets : [];
      let tw = widgets.find(it => String(it.id || '') === rk);
      if (!tw) {{
        const low = rk.toLowerCase();
        tw = widgets.find(it => String(it.title || '').trim().toLowerCase() === low || String(it.title_en || '').trim().toLowerCase() === low);
      }}
      if (!tw || seen.has(String(tw.id || ''))) return 0;
      seen.add(String(tw.id || ''));

      const hasSrc = Boolean(tw.layer_name && (Array.isArray(LAYER_RECORDS[tw.layer_name]) || tw.spatial_join_layer));
      let rows = [];
      if (tw.layer_name && Array.isArray(LAYER_RECORDS[tw.layer_name])) {{
        const baseRows = filterRecords(tw.layer_name, tw.ignore_self_filter ? tw.id : null, tw.id);
        rows = tw.spatial_join_layer ? resolveSpatialPivotRows(tw, baseRows) : baseRows;
      }} else if (!tw.layer_name && hasSrc) {{
        rows = [];
      }}
      const wMode = String(mode || 'value').trim().toLowerCase();
      if (wMode === 'count') return rows.length;

      if (tw.widget_type === 'expression') {{
        const totCnt = (LAYER_RECORDS[tw.layer_name] || []).length || rows.length;
        const r = evaluateDashboardExpression(tw.expression || 'count()', tw.layer_name || '', rows, {{
          totalCount: totCnt,
          fallbackAgg: tw.aggregation || 'sum',
          decimals: (tw.decimals === undefined || tw.decimals === null) ? 1 : Number(tw.decimals),
          ignoreSelfFilter: tw.ignore_self_filter,
          widgetId: tw.id,
          visited: seen
        }});
        return (r && r.ok && r.isNumeric && r.value !== null) ? Number(r.value) : 0;
      }}

      const agg = String(tw.aggregation || 'sum').toLowerCase();
      const vf = String(tw.value_field || '');
      if (agg === 'count' && !vf) return rows.length;
      if (!vf) return rows.length;
      const vals = rows.map(r => resolveFieldVal(r, vf));
      return Number(computeMetric(vals, agg) || 0);
    }}

    function resolveExpressionAccentColor(w, exprRes) {{
      const base = (w && w.primary_color) ? String(w.primary_color) : (_resolveChartPalette(w || {{}}, 1)[0] || '#34d399');
      const mode = String((w && w.expression_color_mode) || 'fixed').trim().toLowerCase();
      if (!exprRes || !exprRes.ok) return '#f43f5e';
      if (mode === 'fixed' || !exprRes.isNumeric || exprRes.value === null) return base;
      const num = Number(exprRes.value);
      if (!Number.isFinite(num)) return base;
      const optF = v => (v === null || v === undefined || v === '') ? null : (Number.isFinite(Number(v)) ? Number(v) : null);

      if (mode === 'target_pct') {{
        const tgt = optF(w.target_value);
        if (tgt === null || tgt <= 0) return base;
        const pct = (num / tgt) * 100;
        const okThr = optF(w.expression_threshold_ok);
        const warnThr = optF(w.expression_threshold_warn);
        const okV = okThr === null ? 100 : okThr;
        const warnV = warnThr === null ? 50 : warnThr;
        if (pct >= okV) return '#10b981';
        if (pct >= warnV) return '#f59e0b';
        return '#f43f5e';
      }}

      if (mode === 'rules') {{
        const rules = Array.isArray(w.expression_rules) ? w.expression_rules : [];
        for (const rule of rules) {{
          if (!rule || typeof rule !== 'object') continue;
          const rop = String(rule.op || '>=').trim();
          const rv = optF(rule.val);
          const col = String(rule.color || '').trim();
          if (rv === null || !col) continue;
          const hit = (
            (rop === '>=' && num >= rv) ||
            (rop === '>' && num > rv) ||
            (rop === '<=' && num <= rv) ||
            (rop === '<' && num < rv) ||
            ((rop === '=' || rop === '==') && num === rv)
          );
          if (hit) return col;
        }}
        const okThr = optF(w.expression_threshold_ok);
        const warnThr = optF(w.expression_threshold_warn);
        if (okThr !== null && num >= okThr) return '#10b981';
        if (warnThr !== null) return num >= warnThr ? '#f59e0b' : '#f43f5e';
        if (okThr !== null) return '#f43f5e';
      }}
      return base;
    }}

    function evaluateDashboardExpression(exprStr, layerName, filteredRows, opts) {{
      const o = opts || {{}};
      const curVisited = new Set(o.visited || []);
      if (o.widgetId) curVisited.add(String(o.widgetId));
      const dec = (o.decimals === undefined || o.decimals === null) ? 1 : Math.max(0, Math.min(6, Number(o.decimals)));
      const prefix = String(o.prefix || '');
      const suffix = String(o.suffix || '');
      const rows = Array.isArray(filteredRows) ? filteredRows : [];
      const totalCount = (o.totalCount !== undefined && o.totalCount !== null) ? Number(o.totalCount) : ((LAYER_RECORDS[layerName] || []).length || rows.length);
      const raw = String(exprStr || '').trim();
      if (!raw) return {{ ok: true, value: 0, formatted: prefix + '0' + suffix, isNumeric: true, error: '' }};
      const toNum = v => {{
        if (v === null || v === undefined || v === '') return null;
        if (typeof v === 'boolean') return v ? 1 : 0;
        if (typeof v === 'number') return Number.isFinite(v) ? v : null;
        const n = Number(String(v).replace(/,/g, '').trim());
        return Number.isFinite(n) ? n : null;
      }};
      const truthy = v => {{
        if (v === null || v === undefined || v === false) return false;
        if (typeof v === 'number') return v !== 0 && !Number.isNaN(v);
        const s = String(v).trim().toLowerCase();
        return s !== '' && s !== '0' && s !== 'false' && s !== 'null';
      }};
      const fmtSpaced = (num, d) => {{
        const dd = Math.max(0, Math.min(6, Math.round(Number(d) || 0)));
        if (dd === 0) return Math.round(num).toLocaleString('en-US').replace(/,/g, ' ');
        return Number(num).toLocaleString('en-US', {{ minimumFractionDigits: dd, maximumFractionDigits: dd }}).replace(/,/g, ' ');
      }};
      const likeMatch = (left, pat, icase) => {{
        const esc = String(pat || '').replace(/[.*+?^${{}}()|[\\]\\\\]/g, '\\\\$&').replace(/%/g, '.*').replace(/_/g, '.');
        return new RegExp('^' + esc + '$', icase ? 'i' : '').test(String(left ?? ''));
      }};
      const aggCompute = (fn, targetRows, valAst, condAst) => {{
        const matched = condAst ? targetRows.filter(r => truthy(evalNode(condAst, r))) : targetRows;
        if (fn === 'count') {{
          if (!valAst) return matched.length;
          return matched.filter(r => {{ const v = evalNode(valAst, r); return v !== null && v !== undefined && String(v) !== ''; }}).length;
        }}
        if (fn === 'count_distinct') {{
          if (!valAst) return 0;
          const s = new Set();
          matched.forEach(r => {{ const v = evalNode(valAst, r); if (v !== null && v !== undefined && String(v) !== '') s.add(String(v)); }});
          return s.size;
        }}
        if (fn === 'pct_share') {{
          if (!condAst) return 0;
          if (!valAst) return targetRows.length ? (matched.length / targetRows.length) * 100 : 0;
          const part = matched.reduce((a, r) => a + (toNum(evalNode(valAst, r)) || 0), 0);
          const whole = targetRows.reduce((a, r) => a + (toNum(evalNode(valAst, r)) || 0), 0);
          return whole > 0 ? (part / whole) * 100 : 0;
        }}
        const nums = valAst ? matched.map(r => toNum(evalNode(valAst, r))).filter(n => n !== null) : [];
        if (!nums.length) return 0;
        if (fn === 'sum') return nums.reduce((a, b) => a + b, 0);
        if (fn === 'mean' || fn === 'avg') return nums.reduce((a, b) => a + b, 0) / nums.length;
        if (fn === 'minimum') return Math.min(...nums);
        if (fn === 'maximum') return Math.max(...nums);
        if (fn === 'median') {{ const s = nums.slice().sort((a, b) => a - b); const m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }}
        return 0;
      }};
      const evalNode = (node, row) => {{
        if (!Array.isArray(node)) return null;
        const op = node[0];
        if (op === 'LIT') return node[1];
        if (op === 'FIELD') {{
          if (!row) return null;
          const fn = node[1];
          return (fn === '$area' || fn === '$area_ha') ? resolveFieldVal(row, '__calc_area_ha__') : resolveFieldVal(row, fn);
        }}
        if (op === 'VAR') {{
          const v = String(node[1]); const low = v.toLowerCase();
          if (low === '$area' || low === '$area_ha') return toNum(resolveFieldVal(row || {{}}, '__calc_area_ha__')) || 0;
          if (low === '$area_m2') return (toNum(resolveFieldVal(row || {{}}, '__calc_area_ha__')) || 0) * 10000;
          if (low === '$count' || low === '@row_count' || low === '@feature_count') return rows.length;
          if (low === '@total_count') return totalCount;
          if (low === '@filter_count') return Object.keys(ACTIVE_FILTERS || {{}}).length;
          if (low === '@layer' || low === '@layer_name') return layerName || '';
          return (row && v in row) ? row[v] : null;
        }}
        if (op === 'NEG') return -(toNum(evalNode(node[1], row)) || 0);
        if (op === 'NOT') return !truthy(evalNode(node[1], row));
        if (op === 'AND') return truthy(evalNode(node[1], row)) && truthy(evalNode(node[2], row));
        if (op === 'OR') return truthy(evalNode(node[1], row)) || truthy(evalNode(node[2], row));
        if (op === 'IS_NULL') {{ const v = evalNode(node[1], row); const isN = (v === null || v === undefined || v === ''); return node[2] ? !isN : isN; }}
        if (op === 'IN') {{
          const l = evalNode(node[1], row); const ln = toNum(l);
          return node[2].some(it => {{ const rv = evalNode(it, row); const rn = toNum(rv); return (ln !== null && rn !== null && ln === rn) || String(l) === String(rv); }});
        }}
        if (op === 'LIKE' || op === 'ILIKE') return likeMatch(evalNode(node[1], row), evalNode(node[2], row), op === 'ILIKE');
        if (op === 'CMP') {{
          const cop = node[1], lv = evalNode(node[2], row), rv = evalNode(node[3], row);
          const ln = toNum(lv), rn = toNum(rv);
          const a = (ln !== null && rn !== null) ? ln : String(lv ?? ''), b = (ln !== null && rn !== null) ? rn : String(rv ?? '');
          const isEq = (lv === null || rv === null) ? (lv === rv) : (a === b);
          if (cop === '=' || cop === '==') return isEq;
          if (cop === '!=' || cop === '<>') return !isEq;
          if (lv === null || rv === null) return false;
          if (cop === '<') return a < b;
          if (cop === '<=') return a <= b;
          if (cop === '>') return a > b;
          if (cop === '>=') return a >= b;
        }}
        if (op === 'BIN') {{
          const bop = node[1];
          if (bop === '||') return String(evalNode(node[2], row) ?? '') + String(evalNode(node[3], row) ?? '');
          const l = toNum(evalNode(node[2], row)) || 0, r = toNum(evalNode(node[3], row)) || 0;
          if (bop === '+') return l + r;
          if (bop === '-') return l - r;
          if (bop === '*') return l * r;
          if (bop === '/') return Math.abs(r) > 1e-12 ? l / r : 0;
          if (bop === '%') return Math.abs(r) > 1e-12 ? l % r : 0;
          if (bop === '^') return Math.pow(l, r) || 0;
        }}
        if (op === 'CASE') {{
          const [, base, branches, el] = node;
          if (base) {{
            const bv = evalNode(base, row); const bn = toNum(bv);
            for (const [ca, ra] of branches) {{
              const cv = evalNode(ca, row); const cn = toNum(cv);
              if ((bn !== null && cn !== null && bn === cn) || String(bv) === String(cv)) return evalNode(ra, row);
            }}
          }} else {{
            for (const [ca, ra] of branches) if (truthy(evalNode(ca, row))) return evalNode(ra, row);
          }}
          return evalNode(el, row);
        }}
        if (op === 'CALL') {{
          const fn = node[1], args = node[2];
          if (_EXPR_WIDGET_FNS.has(fn)) {{
            const rk = args.length ? String(evalNode(args[0], row) || '') : '';
            const wm = fn === 'widget_count' ? 'count' : (args.length >= 2 ? String(evalNode(args[1], row) || 'value') : 'value');
            return evalWidgetMetricByRef(rk, wm, curVisited);
          }}
          if (_EXPR_CROSS_FNS.has(fn)) {{
            const tName = args.length ? String(evalNode(args[0], row) || '') : layerName;
            let tRows;
            if (!tName || tName === layerName) {{
              tRows = rows;
            }} else if (Array.isArray(LAYER_RECORDS[tName])) {{
              tRows = filterRecords(tName, o.ignoreSelfFilter ? o.widgetId : null, o.widgetId);
            }} else {{
              tRows = [];
            }}
            const baseFn = fn.replace('layer_', '').replace(/^min$/, 'minimum').replace(/^max$/, 'maximum');
            if (baseFn === 'count') return aggCompute('count', tRows, null, args[1] || null);
            const fSpec = args.length >= 2 ? String(evalNode(args[1], row) || '') : '';
            const vAst = fSpec === '$area' ? ['VAR', '$area'] : (fSpec ? ['FIELD', fSpec] : null);
            return aggCompute(baseFn, tRows, vAst, args[2] || null);
          }}
          if (['sum','mean','avg','count','count_distinct','minimum','maximum','median'].includes(fn)) {{
            return aggCompute(fn, rows, args[0] || null, args[1] || null);
          }}
          if (fn === 'pct_share') return aggCompute('pct_share', rows, args[1] || null, args[0] || null);
          if (fn === 'min' || fn === 'max') {{
            if (args.length === 1) return aggCompute(fn === 'min' ? 'minimum' : 'maximum', rows, args[0], null);
            if (args.length === 2 && _exprAstHasField(args[0]) && _exprAstHasField(args[1]) && !_exprAstHasAgg(args[0])) {{
              return aggCompute(fn === 'min' ? 'minimum' : 'maximum', rows, args[0], args[1]);
            }}
            const ns = args.map(a => toNum(evalNode(a, row))).filter(n => n !== null);
            return ns.length ? (fn === 'min' ? Math.min(...ns) : Math.max(...ns)) : 0;
          }}
          if (fn === 'if') return truthy(evalNode(args[0], row)) ? (args[1] ? evalNode(args[1], row) : null) : (args[2] ? evalNode(args[2], row) : null);
          if (fn === 'coalesce') {{ for (const a of args) {{ const v = evalNode(a, row); if (v !== null && v !== undefined && String(v) !== '') return v; }} return null; }}
          if (fn === 'is_empty') {{ const v = args[0] ? evalNode(args[0], row) : null; return v === null || v === undefined || String(v).trim() === ''; }}
          if (fn === 'round') {{ const x = toNum(evalNode(args[0], row)) || 0, d = Math.max(0, Math.min(8, Math.round(toNum(args[1] ? evalNode(args[1], row) : 0) || 0))); const f = Math.pow(10, d); return Math.round(x * f) / f; }}
          if (fn === 'floor') return Math.floor(toNum(evalNode(args[0], row)) || 0);
          if (fn === 'ceil') return Math.ceil(toNum(evalNode(args[0], row)) || 0);
          if (fn === 'abs') return Math.abs(toNum(evalNode(args[0], row)) || 0);
          if (fn === 'sqrt') return Math.sqrt(Math.max(0, toNum(evalNode(args[0], row)) || 0));
          if (fn === 'pow') {{ const ex = args[1] ? toNum(evalNode(args[1], row)) : null; return Math.pow(toNum(evalNode(args[0], row)) || 0, ex === null ? 1 : ex) || 0; }}
          if (fn === 'clamp') {{ const v = toNum(evalNode(args[0], row)) || 0, lo = toNum(evalNode(args[1], row)) ?? 0, hi = toNum(evalNode(args[2], row)) ?? 100; return Math.max(lo, Math.min(hi, v)); }}
          if (fn === 'percent') {{ const p = toNum(evalNode(args[0], row)) || 0, t = toNum(evalNode(args[1], row)) || 0; return Math.abs(t) > 1e-12 ? (p / t) * 100 : 0; }}
          if (fn === 'format_number') return fmtSpaced(toNum(evalNode(args[0], row)) || 0, args[1] ? evalNode(args[1], row) : 1);
          if (fn === 'format_ha') return fmtSpaced(toNum(evalNode(args[0], row)) || 0, args[1] ? evalNode(args[1], row) : 1) + ' ha';
          if (fn === 'format_pct') return fmtSpaced(toNum(evalNode(args[0], row)) || 0, args[1] ? evalNode(args[1], row) : 1) + ' %';
          if (fn === 'concat') return args.map(a => String(evalNode(a, row) ?? '')).join('');
          if (fn === 'upper') return String(evalNode(args[0], row) ?? '').toUpperCase();
          if (fn === 'lower') return String(evalNode(args[0], row) ?? '').toLowerCase();
          if (fn === 'title') return String(evalNode(args[0], row) ?? '').replace(/\\b\\w/g, c => c.toUpperCase());
          if (fn === 'trim') return String(evalNode(args[0], row) ?? '').trim();
          if (fn === 'length') return String(evalNode(args[0], row) ?? '').length;
          if (fn === 'left') return String(evalNode(args[0], row) ?? '').slice(0, Math.max(0, Math.round(toNum(evalNode(args[1], row)) || 0)));
          if (fn === 'right') {{ const n = Math.max(0, Math.round(toNum(evalNode(args[1], row)) || 0)); const s = String(evalNode(args[0], row) ?? ''); return n > 0 ? s.slice(-n) : ''; }}
          if (fn === 'substr') {{ const s = String(evalNode(args[0], row) ?? ''), st = Math.max(1, Math.round(toNum(evalNode(args[1], row)) || 1)); const ln = args[2] ? Math.max(0, Math.round(toNum(evalNode(args[2], row)) || s.length)) : s.length; return s.slice(st - 1, st - 1 + ln); }}
          if (fn === 'replace') return String(evalNode(args[0], row) ?? '').split(String(evalNode(args[1], row) ?? '')).join(String(evalNode(args[2], row) ?? ''));
          throw new Error('Unknown function: ' + fn);
        }}
        return null;
      }};
      try {{
        const ast = parseDashExpr(raw);
        let val;
        if (_exprAstHasField(ast) && !_exprAstHasAgg(ast)) {{
          const rVals = rows.map(r => evalNode(ast, r));
          if (rVals.some(v => toNum(v) !== null) || o.fallbackAgg === 'count') val = computeMetric(rVals, o.fallbackAgg || 'sum');
          else val = Array.from(new Set(rVals.filter(v => v !== null && v !== undefined && String(v) !== '').map(String))).slice(0, 5).join(', ');
        }} else {{
          val = evalNode(ast, rows[0] || {{}});
        }}
        if (val === null || val === undefined) return {{ ok: true, value: null, formatted: prefix + '—' + suffix, isNumeric: false, error: '' }};
        if (typeof val === 'boolean') return {{ ok: true, value: val, formatted: prefix + (val ? 'TRUE' : 'FALSE') + suffix, isNumeric: false, error: '' }};
        if (typeof val === 'number') return {{ ok: true, value: val, formatted: prefix + fmtSpaced(val, dec) + suffix, isNumeric: true, error: '' }};
        return {{ ok: true, value: String(val), formatted: prefix + String(val) + suffix, isNumeric: false, error: '' }};
      }} catch (err) {{
        return {{ ok: false, value: null, formatted: '!', isNumeric: false, error: String(err && err.message ? err.message : err) }};
      }}
    }}

    function _wireFallbackChartClicks(plotEl, w) {{
      if (!plotEl || !w || !w.id || w.widget_type === 'scatter' || w.enable_cross_filter === false || !w.category_field) return;
      if (typeof plotEl.querySelectorAll !== 'function') return;
      plotEl.querySelectorAll('[data-cat-val]').forEach(el => {{
        el.onclick = () => {{
          const v = (el.dataset && el.dataset.catVal !== undefined) ? el.dataset.catVal : el.getAttribute('data-cat-val');
          if (v !== undefined && v !== null) {{
            toggleCategoryFilter(w.id, w.layer_name, w.category_field, v, true);
          }}
        }};
      }});
    }}

    function _renderFallbackSvgChart(plotEl, w, pairs, textColor, multiData) {{
      if (!plotEl) return;
      const canFilter = Boolean(w && w.id && w.widget_type !== 'scatter' && w.enable_cross_filter !== false && w.category_field);
      const activeVals = (w && w.id && ACTIVE_FILTERS[w.id] && Array.isArray(ACTIVE_FILTERS[w.id].values))
        ? ACTIVE_FILTERS[w.id].values.map(String)
        : [];
      const hasActiveSel = activeVals.length > 0;
      const curCss = canFilter ? 'cursor:pointer;' : '';
      if (multiData && Array.isArray(multiData.categories) && Array.isArray(multiData.series) && multiData.categories.length && multiData.series.length) {{
        const cats = multiData.categories.slice(0, 12);
        const seriesList = multiData.series;
        const colors = multiData.colors || ['#38bdf8', '#34d399', '#fbbf24', '#f87171', '#a78bfa'];
        const stackMode = String(multiData.stackMode || 'group');
        const legendHtml = `<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:6px;font-size:10px;color:${{textColor}};">` +
          seriesList.map((sn, i) => `<span style="display:inline-flex;align-items:center;gap:4px;"><span style="width:8px;height:8px;border-radius:2px;background:${{colors[i % colors.length]}};display:inline-block;"></span>${{escapeHtml(sn)}}</span>`).join('') +
          `</div>`;
        let maxTotal = 1e-9;
        cats.forEach((_, ci) => {{
          if (stackMode === 'percent') {{
            maxTotal = 100;
          }} else if (stackMode === 'stack') {{
            const s = seriesList.reduce((acc, sn, si) => acc + Math.max(0, Number((multiData.matrix[si] || [])[ci] || 0)), 0);
            if (s > maxTotal) maxTotal = s;
          }} else {{
            seriesList.forEach((_, si) => {{
              const v = Math.abs(Number((multiData.matrix[si] || [])[ci] || 0));
              if (v > maxTotal) maxTotal = v;
            }});
          }}
        }});
        const rowHtml = cats.map((cat, ci) => {{
          const isSel = hasActiveSel && activeVals.includes(String(cat));
          const selCss = `${{curCss}}${{(hasActiveSel && !isSel) ? 'opacity:0.42;' : ''}}${{isSel ? 'font-weight:700;' : ''}}`;
          const catAttr = canFilter ? ` data-cat-val="${{escapeHtml(String(cat))}}"` : '';
          if (stackMode === 'stack' || stackMode === 'percent') {{
            const segs = seriesList.map((sn, si) => {{
              const val = Math.max(0, Number((multiData.matrix[si] || [])[ci] || 0));
              const wPct = Math.max(0, Math.min(100, (val / maxTotal) * 100));
              return `<div title="${{escapeHtml(sn + ': ' + val.toFixed(1))}}" style="width:${{wPct.toFixed(1)}}%;height:100%;background:${{colors[si % colors.length]}};"></div>`;
            }}).join('');
            const rowSum = seriesList.reduce((acc, _, si) => acc + Number((multiData.matrix[si] || [])[ci] || 0), 0);
            return `<div${{catAttr}} style="display:flex;align-items:center;gap:8px;margin:3px 0;font-size:11px;color:${{textColor}};${{selCss}}"><span style="width:92px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${{escapeHtml(cat)}}">${{escapeHtml(cat)}}</span><div style="flex:1;height:12px;display:flex;background:rgba(148,163,184,0.18);border-radius:4px;overflow:hidden;">${{segs}}</div><span style="min-width:44px;text-align:right;">${{escapeHtml(stackMode === 'percent' ? '100%' : rowSum.toLocaleString(undefined, {{ maximumFractionDigits: 1 }}))}}</span></div>`;
          }}
          const subBars = seriesList.map((sn, si) => {{
            const val = Number((multiData.matrix[si] || [])[ci] || 0);
            const pct = Math.max(1, Math.min(100, Math.round((Math.abs(val) / maxTotal) * 100)));
            return `<div style="height:5px;width:${{pct}}%;background:${{colors[si % colors.length]}};border-radius:2px;margin:1px 0;"></div>`;
          }}).join('');
          return `<div${{catAttr}} style="display:flex;align-items:center;gap:8px;margin:4px 0;font-size:11px;color:${{textColor}};${{selCss}}"><span style="width:92px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${{escapeHtml(cat)}}">${{escapeHtml(cat)}}</span><div style="flex:1;">${{subBars}}</div></div>`;
        }}).join('');
        plotEl.innerHTML = `<div style="padding:8px 12px;overflow:auto;height:100%;">${{legendHtml}}${{rowHtml}}</div>`;
        _wireFallbackChartClicks(plotEl, w);
        return;
      }}
      const cleanPairs = Array.isArray(pairs) ? pairs.filter(p => p && p[0] !== undefined) : [];
      if (!cleanPairs.length) {{
        plotEl.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:16px;text-align:center;color:var(--text-secondary);font-size:0.86rem;">${{escapeHtml(t('no_matching'))}}</div>`;
        return;
      }}
      const items = cleanPairs.slice(0, 12);
      const maxVal = Math.max(1e-9, ...items.map(p => Math.abs(Number(p[1] || 0))));
      const svgPal = _resolveChartPalette(w, items.length);
      const rows = items.map(([lbl, val], idx) => {{
        const pct = Math.max(2, Math.min(100, Math.round((Math.abs(Number(val || 0)) / maxVal) * 100)));
        const numTxt = Number(val || 0).toLocaleString(undefined, {{ maximumFractionDigits: 1 }});
        const barCol = svgPal[idx % svgPal.length];
        const isSel = hasActiveSel && activeVals.includes(String(lbl));
        const selCss = `${{curCss}}${{(hasActiveSel && !isSel) ? 'opacity:0.42;' : ''}}${{isSel ? 'font-weight:700;' : ''}}`;
        const catAttr = canFilter ? ` data-cat-val="${{escapeHtml(String(lbl))}}"` : '';
        return `<div${{catAttr}} style="display:flex;align-items:center;gap:8px;margin:3px 0;font-size:11px;color:${{textColor}};${{selCss}}"><span style="width:92px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${{escapeHtml(lbl)}}">${{escapeHtml(lbl)}}</span><div style="flex:1;height:12px;background:rgba(148,163,184,0.18);border-radius:4px;overflow:hidden;"><div style="width:${{pct}}%;height:100%;background:${{barCol}};"></div></div><span style="min-width:44px;text-align:right;font-variant-numeric:tabular-nums;">${{escapeHtml(numTxt)}}</span></div>`;
      }}).join('');
      plotEl.innerHTML = `<div style="padding:8px 12px;overflow:auto;height:100%;">${{rows}}</div>`;
      _wireFallbackChartClicks(plotEl, w);
    }}

    function _applyWidgetBorderStyle(el, w) {{
      if (!el) return;
      if (EXPORT_TIER === 'minimal') {{
        el.style.border = 'none';
        el.style.boxShadow = 'none';
        return;
      }}
      const eff = String((w && w.border_style) || DASHBOARD.widget_border_style || 'solid').toLowerCase();
      if (eff === 'none') {{
        el.style.border = 'none';
        el.style.boxShadow = 'none';
      }} else if (eff === 'dashed') {{
        el.style.borderStyle = 'dashed';
      }} else if (eff === 'shadow') {{
        el.style.boxShadow = '0 8px 24px rgba(15, 23, 42, 0.22)';
      }} else if (eff === 'subtle') {{
        el.style.borderColor = 'rgba(148, 163, 184, 0.22)';
      }}
    }}

    function _syncReusableChartCardHeader(card, wTitle, badgeTxt, clrBtnHtml) {{
      if (!card) return;
      const hdr = card.querySelector('.card-header');
      if (hdr) {{
        const titleSpan = hdr.firstElementChild;
        if (titleSpan) titleSpan.textContent = wTitle;
        const rightSpan = hdr.children && hdr.children[1];
        if (rightSpan) {{
          rightSpan.innerHTML = `${{clrBtnHtml}}<span class="chart-hint" title="${{escapeHtml(t('html_click_filter'))}}">ⓘ ${{escapeHtml(t('html_click_filter'))}}</span>`;
        }}
      }}
      const plotEl = card.querySelector('.plot-container');
      let stripEl = card.querySelector('.card-filter-strip');
      if (badgeTxt) {{
        if (!stripEl) {{
          stripEl = document.createElement('div');
          stripEl.className = 'card-filter-strip';
          if (plotEl && plotEl.parentNode === card) card.insertBefore(stripEl, plotEl);
          else card.appendChild(stripEl);
        }}
        stripEl.innerHTML = `<span class="widget-filter-badge" title="${{escapeHtml(badgeTxt)}}">${{escapeHtml(badgeTxt)}}</span>`;
      }} else if (stripEl && stripEl.parentNode) {{
        stripEl.parentNode.removeChild(stripEl);
      }}
    }}

    function _mountOrUpdatePlotlyChart(plotTargetEl, w, traces, layout, onClickCatFn) {{
      if (!plotTargetEl || typeof Plotly === 'undefined' || !Plotly || typeof Plotly.newPlot !== 'function') return false;
      const cfg = {{ responsive: true, displayModeBar: false }};
      if (plotTargetEl._fullLayout && typeof Plotly.react === 'function') {{
        Plotly.react(plotTargetEl, traces, layout, cfg);
      }} else {{
        plotTargetEl.innerHTML = '';
        Plotly.newPlot(plotTargetEl, traces, layout, cfg);
      }}
      plotTargetEl.dataset.lastPlotW = String(Math.round(plotTargetEl.clientWidth || 0));
      plotTargetEl.dataset.lastPlotH = String(Math.round(plotTargetEl.clientHeight || 0));
      if (!plotTargetEl.dataset.qdashClickBound && typeof plotTargetEl.on === 'function') {{
        plotTargetEl.dataset.qdashClickBound = '1';
        const wid = w.id;
        plotTargetEl.on('plotly_click', data => {{
          const liveW = (DASHBOARD.widgets || []).find(x => x && x.id === wid) || w;
          if (!liveW || !liveW.enable_cross_filter || !data || !data.points || !data.points.length) return;
          const pt = data.points[0];
          const clickedCat = liveW.widget_type === 'pie' ? pt.label : (liveW.horizontal ? pt.y : pt.x);
          if (clickedCat !== 'Other') {{
            toggleCategoryFilter(liveW.id, liveW.layer_name, liveW.category_field, clickedCat);
          }}
        }});
      }}
      return true;
    }}

    function renderWidgetsOnly() {{
      const kpiGrid = document.getElementById('kpi-grid');
      const chartsGrid = document.getElementById('charts-grid');
      const activePg = String(ACTIVE_PAGE_ID || 'page_1');
      const isChartWType = wt => (wt === 'bar' || wt === 'line' || wt === 'pie' || wt === 'scatter');
      const activeChartById = {{}};
      (DASHBOARD.widgets || []).forEach(w => {{
        if (!w || w.widget_type === 'map') return;
        if (w.page_id && String(w.page_id) !== activePg) return;
        if (isChartWType(w.widget_type)) activeChartById[w.id] = w;
      }});

      const reusableChartCards = {{}};
      document.querySelectorAll('[data-widget-id]:not(#map-card)').forEach(el => {{
        const wid = el.dataset ? el.dataset.widgetId : '';
        const wMeta = wid ? activeChartById[wid] : null;
        const pEl = (wid && el.querySelector) ? el.querySelector('.plot-container') : null;
        if (wMeta && pEl && pEl.id === ('plot_' + wid) && el.dataset.widgetType === wMeta.widget_type) {{
          reusableChartCards[wid] = {{ card: el, plotEl: pEl }};
        }} else if (el.parentNode) {{
          el.parentNode.removeChild(el);
        }}
      }});
      if (kpiGrid) kpiGrid.innerHTML = '';
      if (chartsGrid) {{
        Array.from(chartsGrid.children || []).forEach(ch => {{
          const wid = ch && ch.dataset ? ch.dataset.widgetId : '';
          if (!wid || !reusableChartCards[wid]) chartsGrid.removeChild(ch);
        }});
      }}
      if (typeof renderActiveFiltersBanner === 'function') renderActiveFiltersBanner();

      const mapCardEl = document.getElementById('map-card');
      const mapWidgets = (DASHBOARD.widgets || []).filter(w => w.widget_type === 'map');
      const mapOnActivePage = mapWidgets.find(w => !w.page_id || String(w.page_id) === activePg);
      const hasAnyPagedMap = mapWidgets.some(w => Boolean(w.page_id));
      if (mapCardEl) {{
        if (!mapOnActivePage && hasAnyPagedMap && (DASHBOARD.pages || []).length > 1) {{
          mapCardEl.dataset.hiddenPage = '1';
        }} else {{
          delete mapCardEl.dataset.hiddenPage;
          const mapBadgeTxt = mapOnActivePage ? _getIncomingFilterBadgeText(mapOnActivePage.id, mapOnActivePage.layer_name) : '';
          const mapStripEl = document.getElementById('map-filter-strip');
          const mapBadgeEl = document.getElementById('map-filter-badge');
          if (mapStripEl) {{
            mapStripEl.style.display = mapBadgeTxt ? 'flex' : 'none';
          }}
          if (mapBadgeEl) {{
            mapBadgeEl.textContent = mapBadgeTxt;
            mapBadgeEl.title = mapBadgeTxt;
          }}
        }}
      }}

      const isLight = document.documentElement.dataset.theme === 'light';
      const textColor = isLight ? '#0f172a' : '#f8fafc';
      const gridColor = isLight ? '#e2e8f0' : '#334155';
      const pendingChartDraws = [];

      (DASHBOARD.widgets || []).forEach(w => {{
        if (w.widget_type === 'map') return;
        if (w.page_id && String(w.page_id) !== activePg) return;
        const wTitle = localizedTitle(w);
        const wTitleEsc = escapeHtml(wTitle);
        const badgeTxt = _getIncomingFilterBadgeText(w.id, w.layer_name);
        const badgeHtml = badgeTxt ? `<span class="widget-filter-badge" title="${{escapeHtml(badgeTxt)}}">${{escapeHtml(badgeTxt)}}</span>` : '';
        const hasOwnFlt = Object.keys(ACTIVE_FILTERS).some(k => normalizeWidgetSourceId(k) === normalizeWidgetSourceId(w.id));
        const clrBtnHtml = hasOwnFlt
          ? `<button type="button" class="btn-clear-widget" onclick="clearWidgetFilter('${{escapeHtml(w.id)}}')" title="${{escapeHtml(t('btn_clear_filter'))}}">✕</button>`
          : '';
        if (w.widget_type === 'image') {{
          const card = document.createElement('div');
          card.className = 'widget-card image-widget-card' + (w.image_transparent_bg ? ' image-widget-transparent' : '');
          card.dataset.widgetId = w.id;
          _applyWidgetBorderStyle(card, w);
          const imgSrc = w.image_data_uri || w.image_source || '';
          const fit = w.image_fit || 'contain';
          const imgTag = imgSrc
            ? `<img src="${{escapeHtml(imgSrc)}}" alt="${{wTitleEsc}}" style="object-fit:${{escapeHtml(fit)}};" />`
            : `<div style="opacity:0.6;font-size:0.8rem;">${{wTitleEsc}}</div>`;
          const wrapped = (w.image_link_url && imgSrc)
            ? `<a href="${{escapeHtml(w.image_link_url)}}" target="_blank" rel="noopener" style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;">${{imgTag}}</a>`
            : imgTag;
          const capHtml = w.image_caption ? `<div class="image-caption">${{escapeHtml(w.image_caption)}}</div>` : '';
          card.innerHTML = w.image_transparent_bg
            ? `<div class="image-body">${{wrapped}}${{capHtml}}</div>`
            : `<div class="card-header"><span>${{wTitleEsc}}</span></div><div class="image-body">${{wrapped}}${{capHtml}}</div>`;
          if (chartsGrid) chartsGrid.appendChild(card);
          return;
        }}
        const baseRows = filterRecords(w.layer_name, w.ignore_self_filter ? w.id : null, w.id);
        const rows = w.spatial_join_layer ? resolveSpatialPivotRows(w, baseRows) : baseRows;
        const spatialUnavail = Boolean((baseRows && baseRows._spatialUnavailableReason) || (rows && rows._spatialUnavailableReason));
        if (w.widget_type === 'kpi') {{
          const card = document.createElement('div');
          card.className = 'kpi-card';
          card.dataset.widgetId = w.id;
          _applyWidgetBorderStyle(card, w);
          if (EXPORT_TIER !== 'minimal') card.style.borderLeftColor = w.primary_color || '#38bdf8';
          if (spatialUnavail) {{
            card.innerHTML = `
              <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;"><div class="kpi-title">${{wTitleEsc}}</div>${{clrBtnHtml}}</div>
              ${{badgeHtml}}
              <div class="kpi-value">—</div>
              <div class="kpi-meta"><div class="spatial-unavailable-notice">${{escapeHtml(t('spatial_overlap_unavailable'))}}</div></div>
            `;
          }} else {{
            const vals = w.aggregation === 'count' && !w.value_field ? rows.map(() => 1) : rows.map(r => resolveFieldVal(r, w.value_field));
            const val = computeMetric(vals, w.aggregation);
            const dec = (w.decimals === undefined || w.decimals === null) ? 1 : Number(w.decimals);
            const formatted = (w.prefix || '') + (w.aggregation === 'count' || dec === 0 ? Math.round(val).toLocaleString() : val.toLocaleString(undefined, {{ minimumFractionDigits: dec, maximumFractionDigits: dec }})) + (w.suffix || '');
            let deltaHtml = `<span>${{rows.length}} ${{escapeHtml(t('records'))}}</span>`;
            if (w.target_value) {{
              const pct = (((val - w.target_value) / Math.abs(w.target_value)) * 100).toFixed(1);
              const sign = pct >= 0 ? '+' : '';
              deltaHtml += `<span style="color:${{pct >= 0 ? 'var(--accent-emerald)' : 'var(--accent-rose)'}}">${{sign}}${{escapeHtml(pct)}}% ${{escapeHtml(t('vs_target'))}}</span>`;
            }}
            card.innerHTML = `
              <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;"><div class="kpi-title">${{wTitleEsc}}</div>${{clrBtnHtml}}</div>
              ${{badgeHtml}}
              <div class="kpi-value">${{escapeHtml(formatted)}}</div>
              <div class="kpi-meta">${{deltaHtml}}</div>
            `;
          }}
          if (kpiGrid) kpiGrid.appendChild(card);
        }} else if (w.widget_type === 'expression') {{
          const card = document.createElement('div');
          card.className = 'kpi-card expr-card';
          card.dataset.widgetId = w.id;
          _applyWidgetBorderStyle(card, w);
          if (spatialUnavail) {{
            if (EXPORT_TIER !== 'minimal') card.style.borderLeftColor = w.primary_color || '#f59e0b';
            card.innerHTML = `
              <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;"><div class="kpi-title">${{wTitleEsc}}</div>${{clrBtnHtml}}</div>
              ${{badgeHtml}}
              <div class="kpi-value">—</div>
              <div class="kpi-meta"><div class="spatial-unavailable-notice">${{escapeHtml(t('spatial_overlap_unavailable'))}}</div></div>
            `;
          }} else {{
            const dec = (w.decimals === undefined || w.decimals === null) ? 1 : Number(w.decimals);
            const totCnt = (LAYER_RECORDS[w.layer_name] || []).length || rows.length;
            const exprRes = evaluateDashboardExpression(w.expression || 'count()', w.layer_name, rows, {{
              totalCount: totCnt,
              fallbackAgg: w.aggregation || 'sum',
              decimals: dec,
              prefix: w.prefix || '',
              suffix: w.suffix || '',
              ignoreSelfFilter: w.ignore_self_filter,
              widgetId: w.id
            }});
            const dispMode = String(w.expression_display || 'auto').toLowerCase();
            const accent = resolveExpressionAccentColor(w, exprRes);
            let progHtml = '';
            if (exprRes.ok && exprRes.isNumeric && exprRes.value !== null) {{
              let pctBar = null;
              if (w.target_value && Number(w.target_value) > 0 && dispMode !== 'text') {{
                pctBar = Math.max(0, Math.min(100, Math.round((Number(exprRes.value) / Number(w.target_value)) * 100)));
              }} else if (dispMode === 'progress') {{
                pctBar = Math.max(0, Math.min(100, Math.round(Number(exprRes.value))));
              }}
              if (pctBar !== null) {{
                progHtml = `<div class="expr-progress-track"><div class="expr-progress-fill" style="width:${{pctBar}}%;background:${{escapeHtml(accent)}};"></div></div>`;
              }}
            }}
            let subHtml = `<div class="kpi-meta">${{rows.length}} / ${{totCnt}} ${{escapeHtml(t('records'))}}</div>`;
            if (w.expression_subtext && String(w.expression_subtext).trim()) {{
              const subRes = evaluateDashboardExpression(w.expression_subtext, w.layer_name, rows, {{
                totalCount: totCnt,
                fallbackAgg: w.aggregation || 'sum',
                decimals: dec,
                ignoreSelfFilter: w.ignore_self_filter,
                widgetId: w.id
              }});
              subHtml = `<div class="expr-subtext">${{escapeHtml(subRes.ok ? subRes.formatted : subRes.error)}}</div>`;
            }}
            if (EXPORT_TIER !== 'minimal') card.style.borderLeftColor = accent;
            const hasDynCol = String(w.expression_color_mode || 'fixed') !== 'fixed' && exprRes.ok;
            const dynValCol = hasDynCol ? `color:${{escapeHtml(accent)}};` : '';
            const valStyle = !exprRes.ok
              ? 'font-size:0.9rem;color:var(--accent-rose);'
              : ((dispMode === 'text' || (!exprRes.isNumeric && String(exprRes.formatted).length > 14)) ? `font-size:1.05rem;line-height:1.25;${{dynValCol}}` : dynValCol);
            card.innerHTML = `
              <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;"><div class="kpi-title">${{wTitleEsc}}</div>${{clrBtnHtml}}</div>
              ${{badgeHtml}}
              <div class="kpi-value" style="${{valStyle}}">${{escapeHtml(exprRes.ok ? exprRes.formatted : ('⚠ ' + exprRes.error))}}</div>
              ${{progHtml}}
              ${{subHtml}}
            `;
          }}
          if (kpiGrid) kpiGrid.appendChild(card);
        }} else if (w.widget_type === 'table') {{
          const card = document.createElement('div');
          card.className = 'widget-card table-card';
          card.dataset.widgetId = w.id;
          _applyWidgetBorderStyle(card, w);
          const tblStripHtml = badgeTxt ? `<div class="card-filter-strip">${{badgeHtml}}</div>` : '';
          if (spatialUnavail) {{
            card.innerHTML = `
              <div class="card-header"><span>${{wTitleEsc}}</span><span style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">${{clrBtnHtml}}<span>—</span></span></div>
              ${{tblStripHtml}}
              <div class="table-wrapper" style="display:flex;align-items:center;justify-content:center;padding:16px;"><div class="spatial-unavailable-notice">${{escapeHtml(t('spatial_overlap_unavailable'))}}</div></div>
            `;
            if (chartsGrid) chartsGrid.appendChild(card);
            return;
          }}
          const tbl = computeTableData(w, baseRows);
          const selTblVals = ((ACTIVE_FILTERS['tbl_' + w.id] && ACTIVE_FILTERS['tbl_' + w.id].values) || []).map(String);
          const dec = (w.decimals === undefined || w.decimals === null) ? 1 : Number(w.decimals);
          const ths = tbl.headers.map(c => `<th>${{escapeHtml(c)}}</th>`).join('');
          const trs = tbl.rows.map((rVals, idx) => {{
            const meta = tbl.rowMeta[idx] || {{}};
            const isSelRow = Boolean(!meta.isTotal && meta.filterField && selTblVals.includes(String(meta.filterVal || '')));
            const rowCls = [];
            if (meta.isTotal) rowCls.push('pivot-total-row');
            if (isSelRow) rowCls.push('selected-row');
            const cls = rowCls.length ? ` class="${{rowCls.join(' ')}}"` : '';
            const tds = rVals.map(v => {{
              if (typeof v === 'number' && !Number.isInteger(v)) {{
                return `<td>${{escapeHtml(v.toLocaleString(undefined, {{ minimumFractionDigits: dec, maximumFractionDigits: dec }}))}}</td>`;
              }}
              return `<td>${{escapeHtml(v ?? '')}}</td>`;
            }}).join('');
            const bboxStr = Array.isArray(meta.bbox) && meta.bbox.length === 4 ? meta.bbox.join(',') : '';
            return `<tr${{cls}} data-layer="${{escapeHtml(w.layer_name || '')}}" data-fid="${{escapeHtml(meta.fid ?? '')}}" data-lat="${{escapeHtml(meta.lat ?? '')}}" data-lon="${{escapeHtml(meta.lon ?? '')}}" data-bbox="${{escapeHtml(bboxStr)}}" data-filter-field="${{escapeHtml(meta.filterField || '')}}" data-filter-val="${{escapeHtml(meta.filterVal || '')}}">${{tds}}</tr>`;
          }}).join('');
          card.innerHTML = `
            <div class="card-header"><span>${{wTitleEsc}}</span><span style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">${{clrBtnHtml}}<button class="btn-mini-icon${{tbl.transposed ? ' active' : ''}}" onclick="toggleTableTranspose('${{escapeHtml(w.id)}}')" title="Transpose">⇄</button><span>${{tbl.rows.length}} ${{escapeHtml(t('html_rows'))}}</span></span></div>
            ${{tblStripHtml}}
            <div class="table-wrapper"><table><thead><tr>${{ths}}</tr></thead><tbody>${{trs}}</tbody></table></div>
          `;
          card.querySelectorAll('tbody tr').forEach(tr => {{
            tr.onclick = () => {{
              const ff = tr.dataset.filterField, fv = tr.dataset.filterVal;
              if (ff) {{
                toggleCategoryFilter('tbl_' + w.id, w.layer_name, ff, fv, true);
                return;
              }}
              if (w.drill_to_page_id) switchDashboardPage(w.drill_to_page_id);
              const ln = tr.dataset.layer, fid = tr.dataset.fid;
              const rawBbox = tr.dataset.bbox ? tr.dataset.bbox.split(',').map(Number).filter(Number.isFinite) : null;
              const fitFeatureBounds = () => {{
                const gNow = getFeatureGeometry(ln, String(fid));
                if (gNow && map) {{
                  const b = L.geoJSON(gNow).getBounds();
                  if (b.isValid()) {{ safeFitBounds(b, {{ padding: [40, 40], maxZoom: 15 }}); return true; }}
                }}
                const bbNow = (rawBbox && rawBbox.length === 4) ? rawBbox : getFeatureBbox(ln, String(fid));
                if (bbNow && bbNow.length === 4 && map) {{
                  safeFitBounds([[bbNow[1], bbNow[0]], [bbNow[3], bbNow[2]]], {{ padding: [40, 40], maxZoom: 15 }});
                  return true;
                }}
                return false;
              }};
              const hasExactGeom = Boolean(getFeatureGeometry(ln, String(fid)));
              if (!fitFeatureBounds()) {{
                const lat = parseFloat(tr.dataset.lat), lon = parseFloat(tr.dataset.lon);
                if (!isNaN(lat) && !isNaN(lon) && map) safeSetView([lat, lon], 14);
              }}
              if (!hasExactGeom && ln && fid !== undefined && fid !== '') {{
                requestMissingFeatures(ln, {{ fids: [String(fid)], zoom: 14, skipAutoZoom: true }}).then(() => {{
                  const g2 = getFeatureGeometry(ln, String(fid));
                  if (g2 && map) {{
                    const b2 = L.geoJSON(g2).getBounds();
                    if (b2.isValid()) safeFitBounds(b2, {{ padding: [40, 40], maxZoom: 15 }});
                  }}
                }});
              }}
            }};
          }});
          if (chartsGrid) chartsGrid.appendChild(card);
        }} else {{
          const plotId = 'plot_' + w.id;
          const reused = reusableChartCards[w.id] || null;
          let card = null;
          let plotTargetEl = null;
          if (reused) {{
            card = reused.card;
            plotTargetEl = reused.plotEl;
            _applyWidgetBorderStyle(card, w);
            _syncReusableChartCardHeader(card, wTitle, badgeTxt, clrBtnHtml);
          }} else {{
            card = document.createElement('div');
            card.className = 'widget-card';
            card.dataset.widgetId = w.id;
            card.dataset.widgetType = w.widget_type;
            _applyWidgetBorderStyle(card, w);
            const chartStripHtml = badgeTxt ? `<div class="card-filter-strip">${{badgeHtml}}</div>` : '';
            card.innerHTML = `<div class="card-header"><span>${{wTitleEsc}}</span><span style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;justify-content:flex-end;">${{clrBtnHtml}}<span class="chart-hint" title="${{escapeHtml(t('html_click_filter'))}}">ⓘ ${{escapeHtml(t('html_click_filter'))}}</span></span></div>${{chartStripHtml}}<div id="${{plotId}}" class="plot-container"></div>`;
            if (chartsGrid) chartsGrid.appendChild(card);
            plotTargetEl = document.getElementById(plotId) || card.querySelector('.plot-container');
          }}

          pendingChartDraws.push(() => {{
            if (!plotTargetEl) return;
            if (spatialUnavail) {{
              if (plotTargetEl._fullLayout && typeof Plotly !== 'undefined' && Plotly && typeof Plotly.purge === 'function') {{
                try {{ Plotly.purge(plotTargetEl); }} catch (_pg) {{}}
              }}
              plotTargetEl.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:12px;"><div class="spatial-unavailable-notice">${{escapeHtml(t('spatial_overlap_unavailable'))}}</div></div>`;
              return;
            }}
            if (w.widget_type === 'scatter') {{
              const xs = [], ys = [], texts = [];
              rows.forEach(r => {{
                const xv = Number(resolveFieldVal(r, w.category_field)), yv = Number(resolveFieldVal(r, w.value_field));
                if (!isNaN(xv) && !isNaN(yv)) {{
                  xs.push(xv); ys.push(yv); texts.push(String(resolveFieldVal(r, w.secondary_field || w.category_field) || ''));
                }}
              }});
              if (!xs.length) {{
                if (plotTargetEl._fullLayout && typeof Plotly !== 'undefined' && Plotly && typeof Plotly.purge === 'function') {{
                  try {{ Plotly.purge(plotTargetEl); }} catch (_pg2) {{}}
                }}
                plotTargetEl.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:16px;text-align:center;color:var(--text-secondary);font-size:0.86rem;">${{escapeHtml(t('no_matching'))}}</div>`;
                return;
              }}
              if (typeof Plotly === 'undefined' || !Plotly || typeof Plotly.newPlot !== 'function') {{
                _renderFallbackSvgChart(plotTargetEl, w, xs.map((x, idx) => [String(x), ys[idx]]), textColor);
                return;
              }}
              try {{
                _mountOrUpdatePlotlyChart(plotTargetEl, w, [{{
                  x: xs, y: ys, text: texts, mode: 'markers', type: 'scatter',
                  marker: {{ color: w.primary_color || '#38bdf8', size: 10, opacity: 0.85 }}
                }}], {{
                  paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
                  font: {{ color: textColor, size: 11 }},
                  margin: {{ t: 16, r: 16, b: 40, l: 48 }},
                  xaxis: {{ title: friendlyFieldLabel(w.category_field), gridcolor: gridColor }},
                  yaxis: {{ title: friendlyFieldLabel(w.value_field), gridcolor: gridColor }}
                }});
              }} catch (_plotlyErr) {{
                _renderFallbackSvgChart(plotTargetEl, w, xs.map((x, idx) => [String(x), ys[idx]]), textColor);
              }}
              return;
            }}

            const secField = String(w.secondary_field || '').trim();
            const isMultiSeries = Boolean(secField && w.widget_type !== 'pie' && w.widget_type !== 'scatter');
            if (isMultiSeries) {{
              const catBuckets = {{}};
              const cellBuckets = {{}};
              const seriesBuckets = {{}};
              rows.forEach(r => {{
                const rawCat = resolveFieldVal(r, w.category_field);
                const k = (rawCat !== null && rawCat !== undefined && String(rawCat).trim() !== '') ? String(rawCat) : '(Unassigned)';
                const rawSer = resolveFieldVal(r, secField);
                const sKey = (rawSer !== null && rawSer !== undefined && String(rawSer).trim() !== '') ? String(rawSer) : '(Other Series)';
                const val = (w.aggregation === 'count' && !w.value_field) ? 1 : resolveFieldVal(r, w.value_field);
                if (!catBuckets[k]) catBuckets[k] = [];
                catBuckets[k].push(val);
                if (!cellBuckets[k]) cellBuckets[k] = {{}};
                if (!cellBuckets[k][sKey]) cellBuckets[k][sKey] = [];
                cellBuckets[k][sKey].push(val);
                if (!seriesBuckets[sKey]) seriesBuckets[sKey] = [];
                seriesBuckets[sKey].push(val);
              }});

              let catPairs = Object.entries(catBuckets).map(([k, vals]) => [k, computeMetric(vals, w.aggregation)]);
              if (w.sort_by === 'value_asc') catPairs.sort((a, b) => a[1] - b[1]);
              else if (w.sort_by === 'category_asc') catPairs.sort((a, b) => a[0].localeCompare(b[0]));
              else catPairs.sort((a, b) => b[1] - a[1]);

              const topN = Math.max(1, Number(w.top_n || 15));
              let finalCats = catPairs.map(p => p[0]);
              if (finalCats.length > topN) {{
                const headCats = finalCats.slice(0, topN - 1);
                const tailCats = finalCats.slice(topN - 1);
                const otherCells = {{}};
                tailCats.forEach(tc => {{
                  const cells = cellBuckets[tc] || {{}};
                  Object.entries(cells).forEach(([sk, arr]) => {{
                    if (!otherCells[sk]) otherCells[sk] = [];
                    otherCells[sk].push(...arr);
                  }});
                }});
                cellBuckets['Other'] = otherCells;
                headCats.push('Other');
                finalCats = headCats;
              }}

              const seriesNames = Object.entries(seriesBuckets)
                .map(([sk, vals]) => [sk, computeMetric(vals, w.aggregation)])
                .sort((a, b) => b[1] - a[1])
                .slice(0, 12)
                .map(p => p[0]);

              if (!finalCats.length || !seriesNames.length) {{
                if (plotTargetEl._fullLayout && typeof Plotly !== 'undefined' && Plotly && typeof Plotly.purge === 'function') {{
                  try {{ Plotly.purge(plotTargetEl); }} catch (_pg3) {{}}
                }}
                plotTargetEl.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:16px;text-align:center;color:var(--text-secondary);font-size:0.86rem;">${{escapeHtml(t('no_matching'))}}</div>`;
                return;
              }}

              const palette = _resolveChartPalette(w, seriesNames.length);
              const stackMode = String(w.chart_stack_mode || 'group').toLowerCase();

              let matrix = seriesNames.map(sn => finalCats.map(cat => {{
                const arr = (cellBuckets[cat] && cellBuckets[cat][sn]) ? cellBuckets[cat][sn] : [];
                return arr.length ? computeMetric(arr, w.aggregation) : 0;
              }}));

              if (stackMode === 'percent' && w.widget_type !== 'line') {{
                const colSums = finalCats.map((_, ci) => seriesNames.reduce((acc, _sn, si) => acc + Math.max(0, Number(matrix[si][ci] || 0)), 0));
                matrix = matrix.map(rowArr => rowArr.map((v, ci) => colSums[ci] > 0 ? (Math.max(0, Number(v || 0)) / colSums[ci]) * 100 : 0));
              }}

              if (typeof Plotly === 'undefined' || !Plotly || typeof Plotly.newPlot !== 'function') {{
                _renderFallbackSvgChart(plotTargetEl, w, null, textColor, {{
                  categories: finalCats,
                  series: seriesNames,
                  matrix: matrix,
                  colors: palette,
                  stackMode: stackMode
                }});
                return;
              }}

              const traces = seriesNames.map((sn, si) => {{
                const color = palette[si % palette.length];
                const vals = matrix[si];
                if (w.widget_type === 'line') {{
                  return {{
                    name: sn,
                    x: finalCats,
                    y: vals,
                    type: 'scatter',
                    mode: 'lines+markers',
                    line: {{ color, width: 2.5 }},
                    marker: {{ color, size: 6 }}
                  }};
                }}
                return {{
                  name: sn,
                  x: w.horizontal ? vals : finalCats,
                  y: w.horizontal ? finalCats : vals,
                  orientation: w.horizontal ? 'h' : 'v',
                  type: 'bar',
                  marker: {{ color }}
                }};
              }});

              const layout = {{
                paper_bgcolor: 'transparent',
                plot_bgcolor: 'transparent',
                font: {{ color: textColor, size: 11 }},
                margin: {{ t: 20, r: 16, b: 42, l: 58 }},
                legend: {{ orientation: 'h', y: 1.12, font: {{ size: 10 }} }},
                xaxis: {{ gridcolor: gridColor, automargin: true }},
                yaxis: {{ gridcolor: gridColor, automargin: true }}
              }};
              if (w.widget_type !== 'line') {{
                layout.barmode = (stackMode === 'stack' || stackMode === 'percent') ? 'stack' : 'group';
                if (stackMode === 'percent') {{
                  const valAxis = w.horizontal ? layout.xaxis : layout.yaxis;
                  valAxis.range = [0, 100];
                  valAxis.ticksuffix = '%';
                }}
              }}

              try {{
                _mountOrUpdatePlotlyChart(plotTargetEl, w, traces, layout);
              }} catch (_plotlyErr) {{
                _renderFallbackSvgChart(plotTargetEl, w, null, textColor, {{
                  categories: finalCats,
                  series: seriesNames,
                  matrix: matrix,
                  colors: palette,
                  stackMode: stackMode
                }});
              }}
              return;
            }}

            const groups = {{}};
            rows.forEach(r => {{
              const rawCat = resolveFieldVal(r, w.category_field);
              const k = (rawCat !== null && rawCat !== undefined && String(rawCat).trim() !== '') ? String(rawCat) : '(Unassigned)';
              if (!groups[k]) groups[k] = [];
              groups[k].push(w.aggregation === 'count' && !w.value_field ? 1 : resolveFieldVal(r, w.value_field));
            }});
            let pairs = Object.entries(groups).map(([k, vals]) => [k, computeMetric(vals, w.aggregation)]);
            if (w.sort_by === 'value_asc') pairs.sort((a, b) => a[1] - b[1]);
            else if (w.sort_by === 'category_asc') pairs.sort((a, b) => a[0].localeCompare(b[0]));
            else pairs.sort((a, b) => b[1] - a[1]);

            const topN = Math.max(1, Number(w.top_n || 15));
            if (pairs.length > topN) {{
              const head = pairs.slice(0, topN - 1);
              const tailSum = pairs.slice(topN - 1).reduce((s, p) => s + p[1], 0);
              head.push(['Other', tailSum]);
              pairs = head;
            }}

            if (!pairs.length) {{
              if (plotTargetEl._fullLayout && typeof Plotly !== 'undefined' && Plotly && typeof Plotly.purge === 'function') {{
                try {{ Plotly.purge(plotTargetEl); }} catch (_pg4) {{}}
              }}
              plotTargetEl.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;padding:16px;text-align:center;color:var(--text-secondary);font-size:0.86rem;">${{escapeHtml(t('no_matching'))}}</div>`;
              return;
            }}
            if (typeof Plotly === 'undefined' || !Plotly || typeof Plotly.newPlot !== 'function') {{
              _renderFallbackSvgChart(plotTargetEl, w, pairs, textColor);
              return;
            }}

            const labels = pairs.map(p => p[0]);
            const values = pairs.map(p => p[1]);
            const selected = (ACTIVE_FILTERS[w.id] && ACTIVE_FILTERS[w.id].values) || [];

            let trace = {{}};
            const seriesPal = _resolveChartPalette(w, labels.length);
            if (w.widget_type === 'pie') {{
              const totalPositive = values.reduce((s, v) => s + Math.max(0, Number(v) || 0), 0);
              if (labels.length && totalPositive <= 0) {{
                trace = {{
                  labels,
                  values: labels.map(() => 1),
                  customdata: values,
                  text: values.map(v => String(v ?? 0)),
                  textinfo: 'label+text',
                  hovertemplate: '%{{label}}: %{{customdata}}<extra></extra>',
                  type: 'pie',
                  marker: {{ colors: seriesPal }},
                  hole: w.donut ? 0.45 : 0
                }};
              }} else {{
                trace = {{ labels, values, type: 'pie', marker: {{ colors: seriesPal }}, hole: w.donut ? 0.45 : 0 }};
              }}
            }} else if (w.widget_type === 'line') {{
              trace = {{ x: labels, y: values, type: 'scatter', mode: 'lines+markers', line: {{ color: seriesPal[0] || '#34d399', width: 3 }}, marker: {{ color: seriesPal[0] || '#34d399' }} }};
            }} else if (w.widget_type === 'scatter') {{
              trace = {{ x: labels, y: values, type: 'scatter', mode: 'markers', marker: {{ color: seriesPal, size: 10 }} }};
            }} else {{
              const colors = labels.map((l, li) => (!selected.length || selected.includes(l)) ? (seriesPal[li % seriesPal.length] || '#38bdf8') : '#475569');
              trace = {{
                x: w.horizontal ? values : labels,
                y: w.horizontal ? labels : values,
                orientation: w.horizontal ? 'h' : 'v',
                type: 'bar',
                marker: {{ color: colors }}
              }};
            }}

            try {{
              _mountOrUpdatePlotlyChart(plotTargetEl, w, [trace], {{
                paper_bgcolor: 'transparent', plot_bgcolor: 'transparent',
                font: {{ color: textColor, size: 11 }},
                margin: {{ t: 16, r: 16, b: 42, l: 58 }},
                xaxis: {{ gridcolor: gridColor, automargin: true }},
                yaxis: {{ gridcolor: gridColor, automargin: true }}
              }});
            }} catch (_plotlyErr) {{
              _renderFallbackSvgChart(plotTargetEl, w, pairs, textColor);
            }}
          }});
        }}
      }});
      applyArtboardLayout({{ skipPlotResize: true }});
      pendingChartDraws.forEach(drawFn => {{ try {{ drawFn(); }} catch (_cdErr) {{}} }});
    }}

    function renderAll(opts) {{
      const nowFilterCount = Object.keys(ACTIVE_FILTERS).length;
      const triggeredAutoHome = Boolean(
        _PREV_ACTIVE_FILTER_COUNT > 0
        && nowFilterCount === 0
        && AUTO_HOME_ON_FILTER_CLEAR
        && !EXTENT_FILTER_ENABLED
        && !(opts && opts.skipAutoHome)
      );
      _PREV_ACTIVE_FILTER_COUNT = nowFilterCount;
      let effOpts = opts;
      if (triggeredAutoHome) {{
        resetMapHomeView();
        effOpts = Object.assign({{}}, opts || {{}}, {{ skipAutoZoom: true, forceZoom: false }});
      }}
      renderMapFeatures(effOpts);
      renderWidgetsOnly();
    }}

    function hasFreeformLayout() {{
      const items = (DASHBOARD.widgets || []).concat(DASHBOARD.slicers || []);
      return items.some(it => Number(it.layout_w || 0) > 0 && Number(it.layout_h || 0) > 0 && (Number(it.layout_x || 0) > 0 || Number(it.layout_y || 0) > 0 || items.length > 0));
    }}

    function _resizePlotlyChartsIfChanged() {{
      if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function' || typeof Plotly === 'undefined' || !Plotly || !Plotly.Plots) return;
      document.querySelectorAll('.plot-container').forEach(plotEl => {{
        if (!plotEl || !plotEl._fullLayout) return;
        const curW = Math.round(plotEl.clientWidth || 0);
        const curH = Math.round(plotEl.clientHeight || 0);
        if (curW < 20 || curH < 20) return;
        const prevW = Number(plotEl.dataset.lastPlotW || 0);
        const prevH = Number(plotEl.dataset.lastPlotH || 0);
        if (prevW > 0 && prevH > 0 && Math.abs(curW - prevW) <= 2 && Math.abs(curH - prevH) <= 2) return;
        plotEl.dataset.lastPlotW = String(curW);
        plotEl.dataset.lastPlotH = String(curH);
        try {{ Plotly.Plots.resize(plotEl); }} catch (_re) {{}}
      }});
    }}

    function applyArtboardLayout(opts) {{
      const layoutOpts = opts || {{}};
      const ws = document.getElementById('workspace-main');
      const mapCard = document.getElementById('map-card');
      const wp = document.getElementById('widgets-panel');
      const slicerBar = document.getElementById('slicer-bar');
      if (!ws) return;

      const inIframe = Boolean(IS_EMBEDDED_IFRAME);
      const stackMobile = (typeof isMobileCardStackActive === 'function')
        ? isMobileCardStackActive()
        : Boolean(MOBILE_VIEW_ENABLED && !MOBILE_FIT_OVERVIEW);
      const positioned = (DASHBOARD.widgets || []).concat(DASHBOARD.slicers || [])
        .filter(it => Number(it.layout_w || 0) > 0 && Number(it.layout_h || 0) > 0 && (Number(it.layout_x || 0) > 0 || Number(it.layout_y || 0) > 0));
      if (typeof document !== 'undefined' && document.body && document.body.classList) {{
        document.body.classList.toggle('iframe-embedded', inIframe);
        document.body.classList.toggle('mobile-view', stackMobile);
        document.body.classList.remove('iframe-fluid-grid');
      }}
      if (!positioned.length) {{
        ws.classList.remove('freeform');
        ws.classList.toggle('workspace-map-minimized', MAP_WINDOW_MODE === 'minimized');
        ws.classList.toggle('workspace-map-maximized', MAP_WINDOW_MODE === 'maximized');
        if (slicerBar) {{
          slicerBar.style.display = '';
          if (slicerBar.classList) slicerBar.classList.toggle('map-maximized-hidden', MAP_WINDOW_MODE === 'maximized');
        }}
        if (wp && wp.classList) wp.classList.toggle('map-maximized-hidden', MAP_WINDOW_MODE === 'maximized');
        if (mapCard) {{
          mapCard.style.display = mapCard.dataset.hiddenPage === '1' ? 'none' : 'flex';
          if (mapCard.classList) mapCard.classList.toggle('map-minimized', MAP_WINDOW_MODE === 'minimized');
        }}
        if (!MOBILE_FIT_OVERVIEW) {{
          ws.style.transform = '';
          ws.style.transformOrigin = '';
          ws.style.marginBottom = '';
          ws.style.marginRight = '';
        }}
        if (typeof updateMobileNavBar === 'function') updateMobileNavBar();
        if (!layoutOpts.skipPlotResize) _resizePlotlyChartsIfChanged();
        return;
      }}
      if (slicerBar) {{
        const hasNonFreeformSlicer = Array.from(slicerBar.children || []).some(ch => {{
          const sid = ch && ch.dataset ? ch.dataset.slicerId : '';
          const slObj = sid ? (DASHBOARD.slicers || []).find(s => s && s.id === sid) : null;
          return !slObj || Number(slObj.layout_w || 0) <= 0;
        }});
        slicerBar.style.display = hasNonFreeformSlicer ? 'flex' : 'none';
      }}

      ws.classList.add('freeform');
      ws.classList.remove('workspace-map-minimized', 'workspace-map-maximized');
      if (wp) {{
        wp.style.display = 'contents';
        if (wp.classList) wp.classList.remove('map-maximized-hidden');
      }}
      if (slicerBar && slicerBar.classList) slicerBar.classList.remove('map-maximized-hidden');
      if (mapCard && mapCard.classList) mapCard.classList.remove('map-minimized', 'map-maximized-hidden');
      const borderStyle = String(DASHBOARD.canvas_border_style || (DASHBOARD.show_design_border === false ? 'none' : 'dashed')).toLowerCase();
      const borderColor = DASHBOARD.canvas_border_color || 'var(--border-color)';
      const borderWidth = Math.max(0, Number(DASHBOARD.canvas_border_width !== undefined ? DASHBOARD.canvas_border_width : 1));
      const borderRadius = Math.max(0, Number(DASHBOARD.canvas_border_radius !== undefined ? DASHBOARD.canvas_border_radius : 10));
      ws.style.borderRadius = (EXPORT_TIER === 'minimal' ? 0 : borderRadius) + 'px';
      if (EXPORT_TIER === 'minimal' || DASHBOARD.show_design_border === false || borderStyle === 'none' || stackMobile) {{
        ws.style.border = 'none';
        ws.style.boxShadow = 'none';
      }} else if (borderStyle === 'shadow') {{
        ws.style.border = `${{Math.max(1, borderWidth)}}px solid ${{borderColor}}`;
        ws.style.boxShadow = '0 10px 30px rgba(2, 132, 199, 0.16), 0 4px 12px rgba(15, 23, 42, 0.12)';
      }} else {{
        ws.style.border = `${{Math.max(1, borderWidth)}}px ${{borderStyle}} ${{borderColor}}`;
        ws.style.boxShadow = 'none';
      }}

      const activePg = String(ACTIVE_PAGE_ID || 'page_1');
      const mapWidget = getActiveMapWidget();
      const rectItems = [];
      let occMinX = Infinity;
      let occMinY = Infinity;
      let occMaxR = 0;
      let occMaxB = 0;

      if (mapCard) {{
        if (mapCard.dataset.hiddenPage !== '1' && mapWidget && Number(mapWidget.layout_w || 0) > 0) {{
          mapCard.style.display = 'flex';
          mapCard.classList.add('freeform-card');
          const mx = Number(mapWidget.layout_x || 12);
          const my = Number(mapWidget.layout_y || 12);
          const mw = Number(mapWidget.layout_w || 520);
          const mh = Number(mapWidget.layout_h || 400);
          _applyWidgetBorderStyle(mapCard, mapWidget);
          rectItems.push({{ el: mapCard, kind: 'map', isKpi: false, x: mx, y: my, w: mw, h: mh, r: mx + mw, b: my + mh }});
          occMinX = Math.min(occMinX, mx);
          occMinY = Math.min(occMinY, my);
          occMaxR = Math.max(occMaxR, mx + mw);
          occMaxB = Math.max(occMaxB, my + mh);
        }} else {{
          mapCard.style.display = 'none';
        }}
      }}

      (DASHBOARD.slicers || []).forEach(sl => {{
        const el = document.querySelector(`.slicer-group[data-slicer-id="${{sl.id}}"]`);
        if (!el || Number(sl.layout_w || 0) <= 0) return;
        el.classList.add('freeform-card');
        const sx = Number(sl.layout_x || 12);
        const sy = Number(sl.layout_y || 12);
        const sw = Number(sl.layout_w || 240);
        const sh = Number(sl.layout_h || 115);
        rectItems.push({{ el, kind: 'slicer', isKpi: false, hasMultiPanes: Array.isArray(sl.panes) && sl.panes.length > 1, x: sx, y: sy, w: sw, h: sh, r: sx + sw, b: sy + sh }});
        occMinX = Math.min(occMinX, sx);
        occMinY = Math.min(occMinY, sy);
        occMaxR = Math.max(occMaxR, sx + sw);
        occMaxB = Math.max(occMaxB, sy + sh);
      }});
      if (slicerBar && !slicerBar.children.length) slicerBar.style.display = 'none';

      (DASHBOARD.widgets || []).forEach(w => {{
        if (w.widget_type === 'map') return;
        const el = document.querySelector(`[data-widget-id="${{w.id}}"]`);
        if (!el || Number(w.layout_w || 0) <= 0) return;
        el.classList.add('freeform-card');
        const wx = Number(w.layout_x || 12);
        const wy = Number(w.layout_y || 12);
        const ww = Number(w.layout_w || 440);
        const wh = Number(w.layout_h || 280);
        const isKpi = (w.widget_type === 'kpi' || w.widget_type === 'expression');
        rectItems.push({{ el, kind: String(w.widget_type || 'chart'), isKpi, x: wx, y: wy, w: ww, h: wh, r: wx + ww, b: wy + wh }});
        occMinX = Math.min(occMinX, wx);
        occMinY = Math.min(occMinY, wy);
        occMaxR = Math.max(occMaxR, wx + ww);
        occMaxB = Math.max(occMaxB, sy_safe(wy) + wh);
      }});

      function sy_safe(v) {{ return Number.isFinite(v) ? v : 0; }}

      const scrollerEl = (typeof document !== 'undefined' && typeof document.querySelector === 'function')
        ? document.querySelector('.workspace-scroll')
        : null;
      const vpW = (typeof window !== 'undefined' && Number(window.innerWidth)) ? Number(window.innerWidth) : 1280;
      const rawClientW = (scrollerEl && Number(scrollerEl.clientWidth) > 0) ? Number(scrollerEl.clientWidth) : vpW;
      const availW = Math.max(240, rawClientW - (inIframe ? 16 : 20));
      const pad = inIframe ? 6 : 12;
      const minX = Number.isFinite(occMinX) ? occMinX : 0;
      const minY = Number.isFinite(occMinY) ? occMinY : 0;
      const canvasW = Number(DASHBOARD.canvas_width || 1280);
      const canvasH = Number(DASHBOARD.canvas_height || 720);

      rectItems.forEach(it => {{
        if (it.el && it.el.classList) it.el.classList.remove('map-maximized-hidden');
      }});
      const mapItem = rectItems.find(it => it.kind === 'map');
      if (MAP_WINDOW_MODE === 'maximized' && mapItem && mapCard && mapCard.dataset.hiddenPage !== '1') {{
        ws.classList.add('workspace-map-maximized');
        if (slicerBar && slicerBar.classList) slicerBar.classList.add('map-maximized-hidden');
        rectItems.forEach(it => {{
          if (it.kind !== 'map' && it.el && it.el.classList) it.el.classList.add('map-maximized-hidden');
        }});
        const maxW = Math.max(300, availW);
        const maxH = Math.max(540, ((typeof window !== 'undefined' && Number(window.innerHeight)) ? Number(window.innerHeight) : 780) - 130);
        mapCard.style.display = 'flex';
        mapCard.style.gridColumn = '1 / -1';
        mapCard.style.left = '0px';
        mapCard.style.top = '0px';
        mapCard.style.width = maxW + 'px';
        mapCard.style.height = maxH + 'px';
        ws.style.transform = '';
        ws.style.transformOrigin = '';
        ws.style.marginBottom = '';
        ws.style.marginRight = '';
        ws.style.width = maxW + 'px';
        ws.style.height = maxH + 'px';
        if (typeof updateMobileNavBar === 'function') updateMobileNavBar();
        if (map && typeof map.invalidateSize === 'function') setTimeout(() => {{
          map.invalidateSize();
          if (typeof renderMapFeatureLabels === 'function') renderMapFeatureLabels();
        }}, 40);
        return;
      }}
      if (MAP_WINDOW_MODE === 'minimized' && mapItem && mapCard && mapCard.dataset.hiddenPage !== '1') {{
        mapCard.classList.add('map-minimized');
        ws.classList.add('workspace-map-minimized');
        const origY = mapItem.y;
        const origB = mapItem.b;
        const origH = mapItem.h;
        const grpMinX = minX;
        const grpSpanW = Math.max(260, occMaxR - grpMinX);
        mapItem.x = grpMinX;
        mapItem.w = grpSpanW;
        mapItem.r = grpMinX + grpSpanW;
        mapItem.h = 44;
        mapItem.b = origY + 44;
        const siblings = rectItems.filter(it => it !== mapItem);
        const bandItems = siblings.filter(it => it.b > origY + 4 && it.y < origB - 4);
        const belowItems = siblings.filter(it => it.y >= origB - 4);
        if (bandItems.length > 0) {{
          const bandMinX = Math.min(...bandItems.map(i => i.x));
          const bandMaxR = Math.max(...bandItems.map(i => i.r));
          const bandCurW = Math.max(1, bandMaxR - bandMinX);
          const expandHoriz = (bandCurW < (grpSpanW - 20));
          const bandMinY = Math.min(...bandItems.map(i => i.y));
          const bandTargetTop = origY + 54;
          let maxBandB = bandTargetTop;
          bandItems.forEach(it => {{
            if (expandHoriz) {{
              const relX = (it.x - bandMinX) / bandCurW;
              const relW = it.w / bandCurW;
              it.x = grpMinX + Math.round(relX * grpSpanW);
              it.w = Math.max(120, Math.round(relW * grpSpanW));
              it.r = it.x + it.w;
            }}
            it.y = bandTargetTop + Math.max(0, it.y - bandMinY);
            it.b = it.y + it.h;
            if (it.b > maxBandB) maxBandB = it.b;
          }});
          if (belowItems.length > 0) {{
            const minBelowY = Math.min(...belowItems.map(i => i.y));
            const targetBelowTop = maxBandB + 12;
            const deltaY = targetBelowTop - minBelowY;
            belowItems.forEach(it => {{
              it.y = Math.max(origY + 54, it.y + deltaY);
              it.b = it.y + it.h;
            }});
          }}
        }} else if (belowItems.length > 0) {{
          const pullUp = Math.max(0, origH - 54);
          belowItems.forEach(it => {{
            it.y = Math.max(origY + 54, it.y - pullUp);
            it.b = it.y + it.h;
          }});
        }}
        occMaxR = Math.max(...rectItems.map(it => it.r));
        occMaxB = Math.max(...rectItems.map(it => it.b));
      }}

      const shiftX = (!MOBILE_FIT_OVERVIEW && (inIframe || availW < canvasW)) ? Math.max(0, minX - pad) : 0;
      const shiftY = (!MOBILE_FIT_OVERVIEW && (inIframe || availW < canvasH)) ? Math.max(0, minY - pad) : 0;
      const occW = Math.max(260, (occMaxR - minX) + pad * 2);
      const occH = Math.max(200, (occMaxB - minY) + pad * 2);

      let useFluidGrid = false;
      let scaleX = 1.0;
      if (!stackMobile && !MOBILE_FIT_OVERVIEW && rectItems.length && DASHBOARD.auto_fit_frame !== false) {{
        if (availW < occW) {{
          const candScale = availW / occW;
          const tooCramped = rectItems.some(it => (it.w * candScale) < (it.isKpi ? 130 : 210));
          if (candScale < 0.58 || tooCramped) {{
            useFluidGrid = true;
          }} else {{
            scaleX = candScale;
          }}
        }}
      }}

      if (typeof document !== 'undefined' && document.body && document.body.classList) {{
        document.body.classList.toggle('iframe-fluid-grid', useFluidGrid && !stackMobile);
      }}

      const orderItems = (stackMobile || useFluidGrid)
        ? rectItems.slice().sort((a, b) => (Math.round(a.y / 80) - Math.round(b.y / 80)) || (a.x - b.x))
        : rectItems;

      rectItems.forEach(it => {{
        const el = it.el;
        if (stackMobile || useFluidGrid) {{
          el.style.left = '';
          el.style.top = '';
          el.style.width = '';
          el.style.height = '';
          if (useFluidGrid) {{
            if (it.kind === 'map' || it.hasMultiPanes) {{
              el.style.gridColumn = '1 / -1';
            }} else if (it.isKpi) {{
              el.style.gridColumn = availW >= 720 ? 'span 4' : 'span 6';
            }} else if (it.kind === 'slicer') {{
              el.style.gridColumn = (it.w >= occW * 0.55 || availW < 640) ? '1 / -1' : 'span 6';
            }} else {{
              el.style.gridColumn = availW >= 680 ? 'span 6' : '1 / -1';
            }}
          }} else {{
            el.style.gridColumn = '';
          }}
        }} else {{
          el.style.gridColumn = '';
          el.style.left = Math.round((it.x - shiftX) * scaleX) + 'px';
          el.style.top = Math.round(it.y - shiftY) + 'px';
          el.style.width = Math.max(80, Math.floor(it.w * scaleX)) + 'px';
          el.style.height = it.h + 'px';
        }}
      }});

      const maxR = MOBILE_FIT_OVERVIEW
        ? Math.max(canvasW, occMaxR + 16)
        : ((inIframe || scaleX < 0.999)
            ? (scaleX < 0.999 ? availW : Math.min(availW, Math.max(occW, Math.min(canvasW, availW))))
            : Math.max(canvasW, occMaxR + 16));
      const maxB = MOBILE_FIT_OVERVIEW
        ? Math.max(canvasH, occMaxB + 16)
        : ((inIframe || scaleX < 0.999) ? occH : Math.max(canvasH, occMaxB + 16));

      if (!layoutOpts.skipPlotResize) {{
        if (typeof requestAnimationFrame === 'function') {{
          requestAnimationFrame(_resizePlotlyChartsIfChanged);
        }} else {{
          _resizePlotlyChartsIfChanged();
        }}
      }}

      const aeLayout = (typeof document !== 'undefined') ? document.activeElement : null;
      const keepWsFocus = Boolean(aeLayout && _isEditableEl(aeLayout) && (!ws.contains || ws.contains(aeLayout)));
      const targetEls = orderItems.map(it => it.el).filter(Boolean);
      const curCards = Array.from(ws.children || []).filter(ch => ch && ch.id !== 'widgets-panel');
      const needsOrderSync = targetEls.length !== curCards.length || targetEls.some((el, idx) => curCards[idx] !== el);
      if (needsOrderSync && !keepWsFocus) {{
        const savedScrollTop = scrollerEl ? Number(scrollerEl.scrollTop || 0) : 0;
        const getCurCardAt = (pos) => {{
          const ch = ws.children || [];
          let seen = 0;
          for (let k = 0; k < ch.length; k++) {{
            if (ch[k] && ch[k].id === 'widgets-panel') continue;
            if (seen === pos) return ch[k];
            seen++;
          }}
          return (wp && wp.parentNode === ws) ? wp : null;
        }};
        targetEls.forEach((el, idx) => {{
          const curAt = getCurCardAt(idx);
          if (curAt !== el) {{
            if (typeof ws.insertBefore === 'function') ws.insertBefore(el, curAt || null);
            else ws.appendChild(el);
          }}
        }});
        if (scrollerEl && Math.abs(Number(scrollerEl.scrollTop || 0) - savedScrollTop) > 2) {{
          scrollerEl.scrollTop = savedScrollTop;
        }}
      }}

      // Adjacent border dissolve (#5)
      rectItems.forEach(it => it.el.classList.remove('dissolve-adj-top', 'dissolve-adj-right', 'dissolve-adj-bottom', 'dissolve-adj-left'));
      if (DASHBOARD.dissolve_adjacent_borders && !stackMobile && !useFluidGrid && scaleX > 0.98) {{
        const tol = 4;
        for (let i = 0; i < rectItems.length; i++) {{
          for (let j = i + 1; j < rectItems.length; j++) {{
            const a = rectItems[i];
            const b = rectItems[j];
            const vOv = Math.min(a.b, b.b) - Math.max(a.y, b.y);
            const hOv = Math.min(a.r, b.r) - Math.max(a.x, b.x);
            if (vOv > 8) {{
              if (Math.abs(a.r - b.x) <= tol) {{
                a.el.classList.add('dissolve-adj-right');
                b.el.classList.add('dissolve-adj-left');
              }} else if (Math.abs(b.r - a.x) <= tol) {{
                b.el.classList.add('dissolve-adj-right');
                a.el.classList.add('dissolve-adj-left');
              }}
            }}
            if (hOv > 8) {{
              if (Math.abs(a.b - b.y) <= tol) {{
                a.el.classList.add('dissolve-adj-bottom');
                b.el.classList.add('dissolve-adj-top');
              }} else if (Math.abs(b.b - a.y) <= tol) {{
                b.el.classList.add('dissolve-adj-bottom');
                a.el.classList.add('dissolve-adj-top');
              }}
            }}
          }}
        }}
      }}

      if (!stackMobile && !useFluidGrid) {{
        if (!MOBILE_FIT_OVERVIEW) {{
          ws.style.transform = '';
          ws.style.transformOrigin = '';
          ws.style.marginBottom = '';
          ws.style.marginRight = '';
        }}
        ws.style.width = maxR + 'px';
        ws.style.height = maxB + 'px';
      }} else {{
        ws.style.width = '100%';
        ws.style.height = 'auto';
        ws.style.transform = '';
        ws.style.transformOrigin = '';
        ws.style.marginBottom = '';
        ws.style.marginRight = '';
      }}
      if (typeof _applyMobileFitScale === 'function' && MOBILE_FIT_OVERVIEW) _applyMobileFitScale();
      if (typeof updateMobileNavBar === 'function') updateMobileNavBar();
      if (map && typeof map.invalidateSize === 'function') setTimeout(() => map.invalidateSize(), 40);
      if (inIframe && typeof window !== 'undefined' && window.parent && window.parent !== window && typeof window.parent.postMessage === 'function') {{
        try {{
          const totH = Math.max(320, (typeof document !== 'undefined' && document.documentElement) ? document.documentElement.scrollHeight : maxB);
          window.parent.postMessage({{ type: 'geodash:resize', width: availW, height: totH }}, '*');
        }} catch (_pm) {{}}
      }}
    }}

    let _LAST_VP_WIDTH = (typeof window !== 'undefined' && window.innerWidth) ? Number(window.innerWidth) : 0;
    let _LAST_VP_HEIGHT = (typeof window !== 'undefined' && window.innerHeight) ? Number(window.innerHeight) : 0;

    function _handleMobileResponsiveResize(opts) {{
      const force = Boolean(opts && opts.force);
      const curW = (typeof window !== 'undefined' && window.innerWidth) ? Number(window.innerWidth) : _LAST_VP_WIDTH;
      const curH = (typeof window !== 'undefined' && window.innerHeight) ? Number(window.innerHeight) : _LAST_VP_HEIGHT;
      const widthChanged = _LAST_VP_WIDTH > 0 ? (Math.abs(curW - _LAST_VP_WIDTH) > 8) : false;
      const ae = (typeof document !== 'undefined') ? document.activeElement : null;
      const inputFocused = _isEditableEl(ae);

      // Soft keyboard opening/closing or mobile URL bar show/hide changes only viewport height.
      // Running layout reflow / card reordering on height-only resize blurs the input and snaps scrollTop to 0.
      if (!force && !widthChanged && (inputFocused || MOBILE_VIEW_ENABLED)) {{
        _LAST_VP_WIDTH = curW;
        _LAST_VP_HEIGHT = curH;
        if (typeof syncMobileScrollBlob === 'function') syncMobileScrollBlob();
        if (inputFocused && ae && typeof document.querySelector === 'function') {{
          const scroller = document.querySelector('.workspace-scroll');
          if (scroller && (!scroller.contains || scroller.contains(ae))
              && typeof ae.getBoundingClientRect === 'function'
              && typeof scroller.getBoundingClientRect === 'function') {{
            const aRect = ae.getBoundingClientRect();
            const sRect = scroller.getBoundingClientRect();
            if (aRect.bottom > sRect.bottom - 8) {{
              scroller.scrollTop += Math.max(0, Math.round(aRect.bottom - (sRect.bottom - 14)));
            }} else if (aRect.top < sRect.top + 8) {{
              scroller.scrollTop -= Math.max(0, Math.round((sRect.top + 14) - aRect.top));
            }}
          }}
        }}
        return;
      }}
      _LAST_VP_WIDTH = curW;
      _LAST_VP_HEIGHT = curH;

      const nextMobile = (typeof detectMobileDeviceViewport === 'function') ? detectMobileDeviceViewport() : MOBILE_VIEW_ENABLED;
      let changed = false;
      if (MOBILE_VIEW_OVERRIDE === null && nextMobile !== MOBILE_VIEW_ENABLED) {{
        MOBILE_VIEW_ENABLED = nextMobile;
        MOBILE_FIT_OVERVIEW = false;
        changed = true;
      }}
      if (force || changed || widthChanged || MOBILE_VIEW_ENABLED || MOBILE_FIT_OVERVIEW || IS_EMBEDDED_IFRAME) {{
        applyArtboardLayout();
        updateMobileNavBar();
      }}
      if (map && typeof map.invalidateSize === 'function') map.invalidateSize();
      _resizePlotlyChartsIfChanged();
    }}

    window.addEventListener('DOMContentLoaded', async () => {{
      const tbActionsInit = document.querySelector('.toolbar-actions');
      if (tbActionsInit && typeof tbActionsInit.addEventListener === 'function') {{
        tbActionsInit.addEventListener('wheel', (ev) => {{
          if (tbActionsInit.scrollWidth > tbActionsInit.clientWidth && Math.abs(ev.deltaY) > Math.abs(ev.deltaX)) {{
            tbActionsInit.scrollLeft += ev.deltaY;
            ev.preventDefault();
          }}
        }}, {{ passive: false }});
      }}
      if (typeof document.addEventListener === 'function') {{
        document.addEventListener('click', (ev) => {{
          const menu = document.getElementById('map-scale-menu');
          const badgeBtn = document.getElementById('map-scale-badge');
          if (!menu || menu.style.display !== 'flex') return;
          if (menu.contains && menu.contains(ev.target)) return;
          if (badgeBtn && (ev.target === badgeBtn || (badgeBtn.contains && badgeBtn.contains(ev.target)))) return;
          closeMapScaleMenu();
        }});
      }}
      devLog('INFO', 'INIT', `DOMContentLoaded starting (contentType=${{(typeof document !== 'undefined' && document.contentType) || ''}})`);
      const isFramedSandbox = _isFramedSandboxEnv();
      if (BUNDLE.expects_sidecar && !(typeof window !== 'undefined' && window.__QDASH_SIDECAR__)) {{
        const scName = BUNDLE.sidecar_filename || '.qdash.data.js';
        devLog(
          'ERROR',
          'INIT',
          `Sidecar file "${{scName}}" failed to load (blocked by SharePoint/iframe CSP or missing sibling file). Re-export as Single File (.html, no sidecar) with Packaged Layers for SharePoint.`
        );
      }}
      initDataCatalog();
      try {{
        initMap();
      }} catch (mapErr) {{
        devLog('ERROR', 'MAP', 'Map init failed: ' + (mapErr && mapErr.message ? mapErr.message : mapErr));
        console.error(mapErr);
      }}
      applyLanguageUI();
      if (typeof syncMobileMapTouchLock === 'function') syncMobileMapTouchLock();
      const compCount = Object.keys(BUNDLE.initial_layer_records || {{}}).length;
      const pyrKeys = Object.keys(VECTOR_PYRAMIDS || {{}});
      const geoEntries = Object.entries(BUNDLE.initial_geojson || {{}});
      const totalGeoFeats = geoEntries.reduce((acc, kv) => acc + ((kv[1] && Array.isArray(kv[1].features)) ? kv[1].features.length : 0), 0);
      const showInitLoader = Boolean(compCount > 0 || pyrKeys.length > 0 || totalGeoFeats > 500);
      if (showInitLoader && typeof showDashboardLoader === 'function') {{
        showDashboardLoader(t('loader_stage_unpack'), '', 6);
        await _yieldToBrowser();
      }}
      await unpackCompressedLayerRecords((ln, frac) => {{
        if (showInitLoader && typeof showDashboardLoader === 'function') {{
          showDashboardLoader(t('loader_stage_unpack'), ln || '', 8 + Math.round(Number(frac || 0) * 34));
        }}
      }});
      for (let gi = 0; gi < geoEntries.length; gi++) {{
        const [ln, fc] = geoEntries[gi];
        if (fc && Array.isArray(fc.features)) {{
          if (fc.features.length > 400 && typeof ingestGeoJsonFeaturesAsync === 'function') {{
            await ingestGeoJsonFeaturesAsync(ln, fc.features, {{ mergeExisting: true }}, (frac) => {{
              if (showInitLoader && typeof showDashboardLoader === 'function') {{
                showDashboardLoader(t('loader_stage_pyramids'), ln || '', 42 + Math.round(((gi + Number(frac || 0)) / Math.max(1, geoEntries.length)) * 12));
              }}
            }});
          }} else {{
            ingestGeoJsonFeatures(ln, fc.features, {{ mergeExisting: true }});
          }}
        }}
      }}
      for (let pi = 0; pi < pyrKeys.length; pi++) {{
        const pln = pyrKeys[pi];
        if (showInitLoader && typeof showDashboardLoader === 'function') {{
          showDashboardLoader(t('loader_stage_pyramids'), pln || '', 54 + Math.round((pi / Math.max(1, pyrKeys.length)) * 20));
        }}
        await unpackLod1Pyramid(pln);
      }}
      Object.keys(LAYER_RECORDS).forEach(ln => {{
        LAYER_RECORDS[ln] = applyExcelJoinsToLayer(ln, LAYER_RECORDS[ln]);
      }});
      if (typeof unpackSpatialRelationsAsync === 'function') {{
        await unpackSpatialRelationsAsync((frac) => {{
          if (showInitLoader && typeof showDashboardLoader === 'function') {{
            showDashboardLoader(t('loader_stage_filter'), '', 75 + Math.round(Number(frac || 0) * 15));
          }}
        }});
      }}
      Object.keys(LAYER_RECORDS).forEach(ln => {{
        const recs = LAYER_RECORDS[ln];
        if (_isSpatialLayer(ln) && Array.isArray(recs) && recs.length > 0 && !LAYER_COMPLETENESS[ln]) {{
          _layerHasCompleteExactGeoms(ln);
        }}
      }});
      if (typeof SPATIAL_RELATIONS !== 'undefined' && SPATIAL_RELATIONS.size > 0) {{
        devLog('INFO', 'SPATIAL', `Unpacked ${{SPATIAL_RELATIONS.size}} exact spatial relation graph(s)`);
      }}
      const restoredSessionState = restoreDashboardSessionState();
      if (typeof ensureLayerOverlaysInitialized === 'function') ensureLayerOverlaysInitialized();
      const postUnpackMw = (typeof getActiveMapWidget === 'function') ? getActiveMapWidget() : null;
      const postUnpackSt = (typeof _activateMapWidgetState === 'function') ? _activateMapWidgetState(postUnpackMw) : null;
      if (typeof syncActiveMapLayersAndControl === 'function') {{
        syncActiveMapLayersAndControl(postUnpackSt, {{ applyViewport: !restoredSessionState }});
      }}
      _PREV_ACTIVE_FILTER_COUNT = Object.keys(ACTIVE_FILTERS).length;
      const chkAutoInit = document.getElementById('chk-opt-autohome');
      if (chkAutoInit) chkAutoInit.checked = Boolean(AUTO_HOME_ON_FILTER_CLEAR);
      if (typeof syncMapWindowButtons === 'function') syncMapWindowButtons();
      renderPagesBar();
      buildSlicers();
      renderActiveFiltersBanner();
      renderMapLayersDrawer();
      beginMapRenderLoader(t('map_rendering_layers'));
      if (showInitLoader && typeof showDashboardLoader === 'function') {{
        showDashboardLoader(t('loader_stage_render'), '', 94);
      }}
      const hasHomeBounds = Boolean(HOME_MAP_VIEW && Array.isArray(HOME_MAP_VIEW.bounds) && HOME_MAP_VIEW.bounds.length === 4);
      const finishInitRender = () => {{
        try {{
          const baseOpts = (restoredSessionState || hasHomeBounds)
            ? {{ skipAutoZoom: true, skipAutoHome: true }}
            : {{ skipAutoHome: true }};
          renderAll(baseOpts);
          updateMobileNavBar();
        }} finally {{
          endMapRenderLoader(false);
          if (typeof hideDashboardLoader === 'function') hideDashboardLoader();
        }}
      }};
      if (typeof requestAnimationFrame === 'function') {{
        requestAnimationFrame(() => setTimeout(finishInitRender, 0));
      }} else {{
        finishInitRender();
      }}
      if (!isFramedSandbox && EXPORT_TIER === 'full') loadCatalogCapabilities(false);
      if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {{
        let _resizeDeb = null;
        let _pendingForceResize = false;
        const onViewportChange = (forceLayout) => {{
          if (forceLayout) _pendingForceResize = true;
          if (_resizeDeb) clearTimeout(_resizeDeb);
          _resizeDeb = setTimeout(() => {{
            const forceFlag = _pendingForceResize;
            _pendingForceResize = false;
            _resizeDeb = null;
            _handleMobileResponsiveResize({{ force: forceFlag }});
          }}, 120);
        }};
        window.addEventListener('resize', () => onViewportChange(false));
        window.addEventListener('orientationchange', () => onViewportChange(true));
        if (typeof ResizeObserver !== 'undefined') {{
          const wsScrollInit = (typeof document !== 'undefined' && typeof document.querySelector === 'function')
            ? document.querySelector('.workspace-scroll')
            : null;
          if (wsScrollInit) {{
            new ResizeObserver(() => onViewportChange(false)).observe(wsScrollInit);
          }}
        }}
      }}
      if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {{
        document.addEventListener('click', (ev) => {{
          const tgt = ev && ev.target;
          const menu = document.getElementById('live-status-menu');
          const pill = document.getElementById('live-status');
          if (menu && menu.style && menu.style.display !== 'none') {{
            if (!(tgt && ((menu.contains && menu.contains(tgt)) || (pill && pill.contains && pill.contains(tgt))))) {{
              menu.style.display = 'none';
            }}
          }}
          const rMenu = document.getElementById('refresh-scope-menu');
          const rBtn = document.getElementById('btn-refresh-live');
          if (rMenu && rMenu.style && rMenu.style.display !== 'none') {{
            if (!(tgt && ((rMenu.contains && rMenu.contains(tgt)) || (rBtn && rBtn.contains && rBtn.contains(tgt))))) {{
              closeRefreshScopeMenu();
            }}
          }}
          const sPop = document.getElementById('settings-popover');
          const sBtn = document.getElementById('btn-settings-menu');
          if (sPop && (sPop.classList.contains('open') || sPop.style.display === 'flex')) {{
            if (!(tgt && ((sPop.contains && sPop.contains(tgt)) || (sBtn && sBtn.contains && sBtn.contains(tgt))))) {{
              closeSettingsMenu();
            }}
          }}
          const lDrawer = document.getElementById('map-layers-drawer');
          const lBtn = document.getElementById('btn-map-layers');
          if (lDrawer && lDrawer.style && lDrawer.style.display !== 'none') {{
            if (!(tgt && ((lDrawer.contains && lDrawer.contains(tgt)) || (lBtn && lBtn.contains && lBtn.contains(tgt))))) {{
              lDrawer.style.display = 'none';
            }}
          }}
        }});
        document.addEventListener('keydown', (ev) => {{
          if (ev && ev.ctrlKey && ev.shiftKey && String(ev.key || '').toLowerCase() === 'l') {{
            if (EXPORT_TIER === 'full') toggleDevLogDrawer();
          }} else if (ev && String(ev.key || '') === 'Escape') {{
            closeSettingsMenu();
            if (typeof closeRefreshScopeMenu === 'function') closeRefreshScopeMenu();
            const menuEsc = document.getElementById('live-status-menu');
            if (menuEsc && menuEsc.style) menuEsc.style.display = 'none';
            const lDrawer = document.getElementById('map-layers-drawer');
            if (lDrawer && lDrawer.style) lDrawer.style.display = 'none';
            if (MAP_WINDOW_MODE === 'maximized') setMapWindowMode('normal');
          }}
        }});
      }}
      const allWfsServices = (BUNDLE.ogc_services || []).filter(s => s.type === 'wfs' && s.geojson_url);
      const liveWfsServices = allWfsServices.filter(s => !isWfsServicePinnedStatic(s));
      const dataMode = String(DASHBOARD.html_data_mode || 'cached').toLowerCase();
      const pkgLayers = (DASHBOARD.package_layers_in_export !== false);
      const hasMissingWfs = liveWfsServices.some(s => !(LAYER_RECORDS[s.name] && LAYER_RECORDS[s.name].length));
      if (!EXPORTED_AT_STAMP && !pkgLayers) {{
        LIVE_SESSION_STAMP = LIVE_SESSION_STAMP || _formatLiveTimeStamp(new Date());
      }}
      if (allWfsServices.length) {{
        allWfsServices.forEach(s => {{
          const cnt = Array.isArray(LAYER_RECORDS[s.name]) ? LAYER_RECORDS[s.name].length : 0;
          if (cnt > 0 && !LAYER_LIVE_INFO[s.name]) {{
            const isPinned = isWfsServicePinnedStatic(s);
            LAYER_LIVE_INFO[s.name] = {{ status: isPinned ? 'static' : 'cached', label: isPinned ? 'Static WFS' : 'Session RAM', loaded: cnt }};
          }}
        }});
      }}
      devLog('INFO', 'INIT', `Dashboard opened (pkgLayers=${{pkgLayers}}, liveWfs=${{liveWfsServices.length}}, exportedAt=${{EXPORTED_AT_STAMP || '-'}})`);
      if (!pkgLayers && liveWfsServices.length) {{
        setLiveStatus('html_loading_wfs');
        refreshLiveWfs({{ force: true }});
      }} else if (dataMode === 'cached' && !hasMissingWfs) {{
        if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
        else setLiveStatus('html_cached_snapshot');
      }} else if (dataMode === 'cached' && hasMissingWfs) {{
        if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
        else setLiveStatus('html_cached_snapshot');
        refreshLiveWfs({{ force: true, missingOnly: true }});
      }} else if (liveWfsServices.length && (dataMode === 'live' || dataMode === 'hybrid' || hasMissingWfs)) {{
        refreshLiveWfs({{ force: true }});
      }} else {{
        if (typeof syncLiveStatusPillFromState === 'function') syncLiveStatusPillFromState();
        else setLiveStatus('html_cached_snapshot');
      }}
      initAutoRefreshTimer();
    }});
  //]]></script>
</body>
</html>
"""
        return html_out, sidecar_data
